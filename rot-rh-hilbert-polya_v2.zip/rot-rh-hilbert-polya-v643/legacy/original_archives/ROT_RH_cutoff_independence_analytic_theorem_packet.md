# ROT-RH fixed-mode cutoff independence — analytic theorem packet

## 1. Setup

Let \(t=\log L\), and let \(E(t)\) be a continuously continued simple root of the finite-part secular equation

\[
F(t,E(t))=k-\frac12.
\]

Let the canonical \(D\)-master potential be

\[
R(t,E)
=
\int_2^\infty
D(x)\,
\frac{e^{-x/e^t}}{e^t\sqrt{x}\log x}
\cos(E\log x)\,dx,
\qquad
D(x)=\psi(x)-x+2.
\]

Assume the exact first-IBP representation

\[
\pi F_t(t,E)=E\,R(t,E)+\varepsilon(t,E).
\]

## 2. Conditional cutoff-independence theorem

Assume that for some \(t_0\), some \(q>1\), some \(d>0\), and some \(0\le\eta<1\), for every \(t\ge t_0\) along the root:

\[
R(t,E(t))<0,
\]

\[
R_E(t,E(t))\ge0,
\]

\[
tR_t(t,E(t))+qR(t,E(t))\ge0,
\]

\[
F_E(t,E(t))\ge d,
\]

and

\[
|\varepsilon(t,E(t))|
\le
\eta\,E(t)(-R(t,E(t))).
\]

Then \(E(t)\) has a finite limit as \(t\to\infty\).

### Proof

Since \(R<0\) and \(|\varepsilon|\le \eta E(-R)\),

\[
\pi F_t
=
ER+\varepsilon
\le
-(1-\eta)E(-R)<0.
\]

Thus

\[
E'(t)
=
-\frac{F_t}{F_E}
>0.
\]

Define

\[
\Phi_q(t)
=
t^q R(t,E(t)).
\]

Along the root,

\[
\Phi_q'(t)
=
t^{q-1}(tR_t+qR)
+
t^q R_E E'(t)
\ge0.
\]

Since \(R<0\), \(\Phi_q<0\). Hence \(-\Phi_q(t)\) is nonincreasing, so

\[
-R(t,E(t))
\le
C_R t^{-q},
\qquad
C_R=-t_0^qR(t_0,E(t_0)).
\]

The first-IBP estimate gives

\[
0<-F_t
\le
\frac{1+\eta}{\pi}
E(t)C_R t^{-q}.
\]

Therefore

\[
\frac{E'(t)}{E(t)}
\le
\frac{(1+\eta)C_R}{\pi d}t^{-q}.
\]

Because \(q>1\),

\[
\int_{t_0}^{\infty} t^{-q}\,dt
=
\frac{t_0^{1-q}}{q-1}<\infty.
\]

Thus Grönwall gives a finite uniform upper bound

\[
E(t)
\le
E(t_0)
\exp\!\left[
\frac{(1+\eta)C_R}{\pi d(q-1)}
t_0^{1-q}
\right]
=:E_{\max}.
\]

Consequently

\[
0<E'(t)
\le
\frac{(1+\eta)C_R E_{\max}}{\pi d}
t^{-q}.
\]

Hence

\[
\int_{t_0}^{\infty}|E'(t)|\,dt<\infty.
\]

Therefore \(E(t)\) is Cauchy and there exists a finite \(E_\infty\) such that

\[
\boxed{
E(t)\to E_\infty
}
\qquad (t\to\infty).
\]

Moreover,

\[
\boxed{
0\le E_\infty-E(t)
\le
\frac{(1+\eta)C_R E_{\max}}
{\pi d(q-1)}
t^{1-q}.
}
\]

This proves fixed-mode cutoff independence under the stated all-\(t\) hypotheses.

---

## 3. Exact Mellin structure of the \(D\)-master

For \(\Re s>1\),

\[
M_D(s)
:=
\int_2^\infty D(x)x^{-s-1}\,dx
\]

satisfies

\[
\boxed{
M_D(s)
=
-\frac1s\frac{\zeta'(s)}{\zeta(s)}
-\frac{2^{1-s}}{s-1}
+\frac{2^{1-s}}s.
}
\]

This follows from

\[
\sum_{n\ge1}\Lambda(n)n^{-s}
=
-\frac{\zeta'(s)}{\zeta(s)}.
\]

Therefore the nontrivial zeros of \(\zeta\) are poles of the Mellin transform of the prime-error field \(D\).

Using

\[
e^{-x/L}
=
\frac1{2\pi i}
\int_{(c)}
\Gamma(z)L^z x^{-z}\,dz,
\]

the complexified shell transforms admit contour representations whose contour shifts pick up residues from the nontrivial zeros.

Thus any all-\(L\) proof of the master-cone sign must control the complete zero-resonance system, or derive an equivalent cancellation theorem purely from arithmetic.

---

## 4. What is already exact in the ROT-RH pipeline

The global \(R^7\) contraction and adaptive packet theorem give a uniform-in-\(E\) deep Abel tail tending to zero.

This removes the deep recursive packet tail.

It does **not** prove the sign of the finite/head transform. The finite head \(G_7\) remains the dominant unresolved arithmetic mechanism.

Likewise, the self-adjoint/Herglotz completion does not automatically prove \(F_E>0\): the positive atomic completion requires positive root slopes as input, and analytic transversality remains an open step.

---

## 5. Why current unconditional PNT bounds do not close the cone

A magnitude bound

\[
|D(x)|\le B(x)
\]

can produce absolute estimates for \(R\), but it cannot determine the signs

\[
R<0,\qquad R_E\ge0,\qquad tR_t+qR\ge0.
\]

Indeed, the same magnitude bound is satisfied by \(-D\), while all three desired signed conclusions change.

Therefore a proof of the cone must preserve oscillatory arithmetic structure. A phase-free absolute PNT majorant cannot suffice.

The classical explicit formula

\[
\psi(x)
=
x-\frac{\zeta'(0)}{\zeta(0)}
-\sum_\rho\frac{x^\rho}{\rho}
+o(1)
\]

shows why: the signs of the master transform are built from the phases of all nontrivial-zero resonances.

---

## 6. Current theorem status

The implication

\[
\text{all-}L\text{ master cone}
+
F_E\text{ floor}
+
\text{uniform carrier remainder}
\Longrightarrow
\text{fixed-mode cutoff independence}
\]

is proved above.

What is **not** proved is the all-\(L\) premise itself:

\[
R<0,\qquad
R_E\ge0,\qquad
tR_t+qR\ge0,\qquad
F_E\ge d>0.
\]

The existing zero-free computations v379 and v381 provide strong prospective finite evidence, but not a theorem for every sufficiently large \(L\).

Accordingly, the mathematically honest status is:

\[
\boxed{
\text{fixed-mode cutoff independence is conditionally proved,
but not yet unconditionally proved.}
}
\]

A complete unconditional proof requires a new signed arithmetic theorem for the canonical \(D\)-master head (and transversality), not another cutoff extension.
