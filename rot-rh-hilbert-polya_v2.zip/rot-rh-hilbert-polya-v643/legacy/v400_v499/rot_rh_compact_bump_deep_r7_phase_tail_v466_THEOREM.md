# ROT-RH v466 — compact-bump finite-propagation / deep R7 phase-tail theorem

## 1. Inputs

Use the exact recursive fixed point

`x=G7+R^7 x`

with

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`.

The elementary bound `Lambda(n)<=log n` gives a cutoff- and phase-independent
beta-2 factorial four-jet bound

`||x||_J <= Cx`

with

`Cx=2 sqrt(2)(1+1/log2)=6.9089849111333486e+00`.

v402 proves the exact all-support four-jet transfer

`||R^7 u||_J <= Qjet ||u||_J`

with

`Qjet=657981440000000/1853020188851841 ~= 3.5508595316907754e-01`

and support floor multiplied by `128`.

## 2. Compact bump dual estimate

For `b_L(n)=p(log n/L)` and beta=2, v465's exact Abel formula implies

`W2(b_L;s,D) <= (exp(L)/s)^2`.

After `J` R7 packets,

`s_J=2*128^J`

and therefore

`max_(r=0..3) |B_r(L,E;R^(7J)x)|
 <= (Cx/4) exp(2L) rhojet^J`,

where `B_r` denotes the factorially `L^-r` normalized E-jet and

`rhojet=Qjet/128^2
       =40160000000/1853020188851841
       ~=2.1672726633854830e-05`.

## 3. Exponential deep-tail closure

Let

`J(L)=ceil(kappa L)`.

If

`kappa > 2/|log rhojet|
       = 1.8622917342907744e-01`,

then

`max_(r<=3)|B_r|
 <= (Cx/4) exp[-delta(kappa)L]`

with

`delta(kappa)=kappa|log rhojet|-2>0`.

The support-extinction threshold is

`1/log128=2.0609929155556622e-01`.

Since

`1.8622917342907744e-01
 <
 2.0609929155556622e-01`,

the exponential four-jet closure begins before the compact bump becomes
identically blind to the remainder.

The limiting best four-jet exponent at the support edge is

`delta_*=2.1339425784495614e-01`.

For the phase zero-jet alone one may use `Q2` rather than `Qjet`, giving

`kappa_min,0=1.7064431194419277e-01`

and support-edge exponent

`delta_0,*=4.1554247202764794e-01`.

## 4. Exact finite propagation

Iterating the recursion,

`x=sum_(j=0)^(J-1)(R^7)^j G7 + (R^7)^J x`.

If

`2*128^J>=exp(L)`,

the last term contributes exactly zero to the compact bump phase because its
coefficient support begins beyond the bump support.

Thus at each finite `L` the bump observable is exactly a finite recursive packet
sum.

## 5. What v466 changes

The deep recursive tail is no longer part of the bump cutoff-independence
bottleneck.  The unresolved object is the growing packet head

`sum_(j<J(L))(R^7)^j G7`.

The all-L half-plane theorem from v465 must therefore be proved from the
fractional phase of this packet head, using packet-to-packet phase cancellation,
the real arithmetic subspace, or an independent operator/index principle.

v466 does **not** prove that packet-head theorem, fixed-mode cutoff independence,
RH, or the Fredholm-Xi identity.
