#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v483 — HIGH-PASS SECTOR-LOCK ZERO-COUNT COMPLEXITY
==========================================================

PURPOSE
-------
Close the finite-dimensional harmonic lemma left open by v482.

Let

    H(s) = sum_{j=1}^n c_j exp((-delta_j + i gamma_j)s),  0<=s<=h,

with H nonzero on the interval.  Suppose that after one constant rotation and a
bounded carrier nu,

    Z(s) = exp(-i alpha) exp(i nu s) H(s)

stays in a strict half-plane sector

    |arg Z(s)| <= Theta < pi/2.

Put shifted frequencies omega_j=gamma_j+nu and assume

    A=min_j omega_j > 0,  B=max_j omega_j-min_j omega_j.

The theorem proves

    n >= A h / (2 pi).

External theorem input
----------------------
Berenstein--Gay (1995), Corollary 3.2.45, in the form quoted as Lemma 2 in
Mu et al., Automatica 60 (2015), 100--114:

For a nontrivial exponential polynomial

    w(t)=sum_i sum_{r=1}^{n_i} w_{i,r} t^(r-1)/(r-1)! exp(lambda_i t),

with total order N=sum_i n_i, the number of real zeros in [0,T] is at most

    (N-1) + Delta T/(2 pi),

where Delta=max_{i,j}|Im(lambda_i-lambda_j)|.

The proof below is deterministic and coefficient-free.  It is fully compatible
with damping factors exp(-delta_j s).

SCIENTIFIC BOUNDARY
-------------------
This closes the finite n-term HIGH_PASS_SECTOR_LOCK_COMPLEXITY lemma.  To turn
it into full ROT-RH cutoff independence one still has to justify, in the actual
infinite zeta bump family, a finite effective high-pass reduction whose minimum
relevant frequency A tends to infinity while the discarded tail is harmless
relative to the phase/root characteristic.  Persistent amplitude collapse is
exactly where that truncation must be treated carefully.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List

from tqdm import tqdm

VERSION = "2026-08-29-v483-highpass-sector-lock-zero-count"


def symbolic_algebra() -> Dict[str, Any]:
    import sympy as sp

    A, C, h, n = sp.symbols("A C h n", positive=True, real=True)
    m = (A + C) / 2
    B = C - A
    residual = sp.simplify(m - B / 2 - A)
    # lower zeros ~ mh/pi; upper zeros <= 2n-1 + Bh/(2pi)
    # after floor(x)>=x-1 this yields 2n >= Ah/pi.
    rhs = sp.simplify(h * (m - B / 2) / sp.pi)
    target = sp.simplify(A * h / sp.pi)
    return {
        "center_minus_half_bandwidth": str(sp.simplify(m - B / 2)),
        "identity_residual": str(residual),
        "twon_lower_rhs": str(rhs),
        "expected_twon_lower_rhs": str(target),
        "pass": bool(residual == 0 and sp.simplify(rhs - target) == 0),
    }


def complexity_bound(A: float, h: float) -> float:
    return A * h / (2.0 * math.pi)


def diagnostic_panel(h: float) -> List[Dict[str, float]]:
    rows = []
    for A in (10.0, 40.0, 160.0, 640.0, 2560.0):
        lower = complexity_bound(A, h)
        rows.append({
            "minimum_shifted_frequency_A": A,
            "window_h": h,
            "mode_lower_bound_real": lower,
            "mode_lower_bound_integer": math.ceil(lower),
            "ratio_lower_bound_over_A": lower / A,
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    cert = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
        r"""# ROT-RH v483 — high-pass sector-lock zero-count complexity theorem

Let

`H(s)=sum_(j=1)^n c_j exp[(-delta_j+i gamma_j)s]`, `0<=s<=h`,

and assume `H(s) != 0` throughout the window.  Suppose that after one constant
rotation and a bounded carrier `nu`,

`Z(s)=exp(-i alpha) exp(i nu s) H(s)`

obeys

`|arg Z(s)| <= Theta < pi/2`

throughout the window.

Write

`omega_j=gamma_j+nu`,

`A=min_j omega_j > 0`, `C=max_j omega_j`,

`m=(A+C)/2`, `B=C-A`.

Define

`P(s)=exp(-i m s) Z(s)`.

At the sampling points

`s_k=k pi/m`,

we have

`Re P(s_k)=(-1)^k |Z(s_k)| cos(arg Z(s_k))`,

so the signs alternate because `Theta<pi/2`.  Therefore `Re P` has at least

`floor(m h/pi)`

distinct zeros in `[0,h]`.

On the other hand,

`Re P=(P+conj(P))/2`

is an exponential polynomial with at most `2n` exponential modes.  Its exponent
imaginary parts lie in `[-B/2,B/2]`; hence their total imaginary diameter is
`B`.

Berenstein--Gay's real-zero bound for exponential polynomials gives

`N_h(Re P) <= (2n-1) + B h/(2 pi)`.

Combining this with `floor(x)>=x-1` yields

`m h/pi - 1 <= 2n - 1 + B h/(2 pi)`,

therefore

`2n >= (h/pi)(m-B/2) = A h/pi`,

and hence the exact complexity bound

`n >= A h/(2 pi)`.

Thus any finite high-pass family whose minimum shifted frequency escapes to
infinity and which stays in a fixed strict half-plane sector on a fixed physical
window requires a number of modes **linear in the minimum carrier**.

**Verdict:** `FINITE_HIGHPASS_SECTOR_LOCK_LINEAR_COMPLEXITY_PASS`.

This defeats the v477 superoscillation loophole at precisely the level requested
by v482: the v477 construction works only because its number of modes grows much
faster than its carrier.

## Arithmetic corollary

If the relevant zeta modes can be reduced to a finite family with

`n(A)=o(A)`

while the minimum shifted ordinate is `A->infinity`, persistent sector lock is
impossible.

In particular, for a bounded-ratio near-edge band `[A, C A]`, Ingham's
zero-density estimate gives `n(A)=O(A^theta log^5 A)=o(A)` for every fixed
`theta<1`, contradicting the theorem.

## Remaining ROT-RH boundary

The harmonic lemma itself is closed for finite exponential polynomials.  What
is not yet automatically closed is the infinite-family reduction in an
amplitude-collapsed configuration: one must prove that the actual compact-bump
zeta sum admits an effective finite high-pass truncation preserving the sector
lock (or show that failure of such a truncation is negligible in the v419
characteristic).  A genuinely multiscale cancellation chain is therefore the
remaining frontier, not generic finite-dimensional superoscillation.

External input: C. A. Berenstein and R. Gay, *Complex Analysis and Special
Topics in Harmonic Analysis* (1995), Cor. 3.2.45; the bound is also quoted as
Lemma 2 in B. Mu et al., *Automatica* 60 (2015), 100--114.
""",
        encoding="utf-8",
    )

    cert.write_text(
        json.dumps({
            "schema": "ROT_RH_HIGHPASS_SECTOR_LOCK_ZERO_COUNT_V1",
            "closed": {
                "finite_sector_lock_complexity": "n >= A h/(2 pi)",
                "A": "minimum shifted high-pass frequency after bounded carrier removal",
                "coefficient_freedom": "arbitrary complex coefficients allowed",
                "damping": "arbitrary real delta_j allowed",
                "sector": "any fixed Theta<pi/2; shrinking sector is stronger",
                "bounded_ratio_zero_density_corollary": "Ingham n(A)=o(A) contradicts linear complexity"
            },
            "external_theorem": {
                "name": "Berenstein-Gay exponential-polynomial real-zero bound",
                "formula": "N_T <= (N-1)+Delta*T/(2*pi)",
                "reference": "Berenstein & Gay (1995), Cor. 3.2.45; quoted in Mu et al., Automatica 60 (2015), Lemma 2"
            },
            "remaining": {
                "effective_finite_reduction": "justify truncation of the infinite zeta bump family relative to the locked characteristic in the amplitude-collapsed sector",
                "multiscale_chain": "exclude a cancellation chain whose effective minimum frequency is much smaller than its active upper scale, or prove it is v419-negligible",
                "uniform_saddle": "package v473 sectorial saddle remainder as explicit uniform inequalities for publication"
            }
        }, indent=2),
        encoding="utf-8",
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--window", type=float, default=1.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_highpass_sector_lock_zero_count_v483",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.window <= 0:
        raise ValueError("window must be positive")

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 194)
    print("ROT-RH v483 — HIGH-PASS SECTOR-LOCK ZERO-COUNT COMPLEXITY")
    print("=" * 194)

    with tqdm(total=2, desc="v483 theorem", unit="step") as bar:
        sym = symbolic_algebra()
        bar.update(1)
        panel = diagnostic_panel(args.window)
        bar.update(1)

    passed = bool(sym["pass"])
    verdict = (
        "FINITE_HIGHPASS_SECTOR_LOCK_LINEAR_COMPLEXITY_PASS"
        if passed
        else "HIGHPASS_ZERO_COUNT_ALGEBRA_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter() - t0,
        "symbolic": sym,
        "diagnostic_panel": panel,
        "theorem": {
            "hypothesis": "finite n-term damped exponential polynomial, nonzero on [0,h], strict sector lock after bounded carrier",
            "conclusion": "n >= A h/(2 pi)",
            "A": "minimum shifted positive frequency",
        },
        "external_input": {
            "theorem": "Berenstein-Gay real-zero bound for exponential polynomials",
            "bound": "N_T <= (N-1)+Delta*T/(2*pi)",
        },
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_scan_used_as_proof": False,
        },
        "proof_status": (
            "Finite-dimensional high-pass sector-lock complexity lemma closed, "
            "conditional only on the cited classical exponential-polynomial zero-count theorem. "
            "Full ROT-RH application still needs an effective finite reduction/truncation "
            "for the infinite amplitude-collapsed zeta bump family."
        ),
    }

    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("symbolic algebra                :", sym["pass"])
    print("complexity theorem              : n >= A*h/(2*pi)")
    print("summary                         :", str(prefix) + "_SUMMARY.json")
    print("theorem                         :", str(prefix) + "_THEOREM.md")
    print("certificate                     :", str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
