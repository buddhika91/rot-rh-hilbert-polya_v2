# ROT-RH v467 — exact beta=7/2 factorial four-jet R7 theorem

At `beta=7/2`, `a=4` and

`sum_(k>=2)k^-4 < 1/16+1/24=5/48`.

Hence

`B0<5/128`, `B1<5/64`,
`L0<5/192`, `L1<5/96`.

The triangular R majorant is

`R00=10/369`,
`R10=2560/45387`.

The fixed-prefix zero-jet seven-step factor is

`T7=20380000000/114574949514610920747
   ~= 1.7787483290491072e-10`.

The first-four-jet Bernstein lift gives

`rhojet=(8/3)T7=163040000000/343724848543832762241
        ~= 4.7433288774642863e-10`.

The weighted global four-jet contraction is

`Qjet=rhojet*128^(7/2)`.

Exactly,

`Qjet^2=14964359080563377910579200000000000000/118146771506480771373169802022676035342081<1`.

Numerically, only for orientation,

`Qjet~=1.1254290759695213e-02`.

For the compact bump, the deep four-jet remainder with
`J(L)=ceil(kappa L)` decays exponentially whenever

`kappa>1.6302490952695559e-01`,

while exact support extinction occurs at asymptotic depth

`1/log128=2.0609929155556622e-01`.

The support-edge four-jet decay exponent is

`9.2476872115797448e-01`.

For the zero-jet alone the threshold is

`1.5590241418314355e-01`.

This strengthens v402/v466 for the deep bump tail.  The retained growing
packet head and its fractional half-plane phase remain open.
