# ROT-RH v484 — proportional-window complexity amplifier

Assume the v411 lock-transfer hypothesis can be chained as in v478 so that,
after a bounded carrier removal, the relevant collective signal stays in one
strict half-plane sector on a proportional cutoff window

`0 <= s <= T_L`,  with `T_L=c L`, `c>0` fixed.

Suppose first that the signal on that window is represented by a finite
`n_L`-term damped exponential polynomial whose shifted positive frequencies
satisfy

`A_L=min_j(gamma_j+nu_L) >= A_0 > 0`.

v483 gives immediately

`n_L >= A_L T_L/(2 pi) >= A_0 c L/(2 pi)`.

Thus any finite proportional-window lock requires **Omega(L)** modes even when
the minimum shifted carrier is only bounded away from zero.  If `A_L->infinity`
the lower bound is stronger still.

The classical Riemann--von Mangoldt count is

`N(T)=O(T log T)`.

v475 places the bump-specific instantaneous active scale at parabolic height
`O(sqrt L)`. Therefore the TOTAL number of nontrivial zero modes below any fixed
multiple `R sqrt L` is only

`N(R sqrt L)=O(sqrt L log L)=o(L)`.

This already contradicts the v483 proportional-window requirement
`n_L=Omega(L)`.  v482 makes the actual near-edge supply smaller still.
Therefore:

**No finite effective near-edge truncation supported in the parabolic active
strip can sustain the v411/v478 proportional-window sector lock.**

Verdict: `PROPORTIONAL_WINDOW_FINITE_ACTIVE_STRIP_LOCK_EXCLUDED_PASS`.

## What remains

The surviving nonattained mechanism has been narrowed again.  If a full
infinite zeta bump sum still locks, then at least one of the following must be
essential:

1. a bounded shifted-frequency/local resonant component that is not part of the
   escaping high-pass sector; or
2. ultraviolet modes outside every fixed parabolic effective truncation, with
   the finite parabolic partial sum so amplitude-collapsed that an arbitrarily
   small tail controls its phase.

Thus the next certificate is no longer a generic superoscillation-complexity
lemma.  It is a **tail-sensitivity / amplitude-collapse exclusion theorem**.
