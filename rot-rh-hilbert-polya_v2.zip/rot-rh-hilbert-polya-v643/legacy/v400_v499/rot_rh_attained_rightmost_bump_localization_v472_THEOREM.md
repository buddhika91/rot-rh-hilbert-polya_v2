# ROT-RH v472 — attained rightmost bump localization / remote-zero summability

## Endpoint remote-frequency lemma

Let `a_*=beta_*-1/2>0` be an attained maximal right-half exponent and

`A_*(L)=int p(x)e^(a_*Lx)dx/x`.

The endpoint peak has

`1-x_L=Theta(L^(-1/3))`

and width

`w_L=Theta(L^(-2/3))`.

For each fixed `N`,

`||d_x^N f_(a,L)||_1
 <= C_N A_*(L) L^(2N/3)`

uniformly for `a<=a_*` in the relevant right-half sector.

For a remote ordinate separation `Delta!=0` and compact `|u|<=U`, repeated
integration by parts gives

`|I_(a,Delta,u)|/A_*
 <= C_N,U L^(-N/3)|Delta|^(-N)`.

At `N=3`,

`|I_remote|/A_*
 <= C_U/[L |Delta|^3]`.

## Infinite remote-zero sum

The classical count `N(T)=O(T log T)` implies

`sum_(Gamma'!=Gamma) m_(Gamma')/(1+|Gamma'-Gamma|)^3 < infinity`.

Hence

`sup_(|u|<=U)|R_remote|/A_*=O_U(1/L)->0`.

No positive real-part gap below `beta_*` is required.

## Local attained-rightmost phase

At the selected ordinate all maximal-real-part zeros combine into multiplicity
`m_*`; lower-real-part same-ordinate terms and functional-equation reflected
partners are negligible. Therefore

`B_L(u)=sigma m_* A_*(L)S_L(u)+o(A_*)`

uniformly on compact `u`, where v471 gives

`S_L(u)->sin u`,
`S_L'(u)->cos u`.

Thus a persistent root in one `n*pi` cell satisfies

`u_L->n*pi`

and

`E_L=Gamma-n*pi/L+o(1/L)`.

## Improvement over the old attained-cluster theorem

The old v387 route required a uniformly nonvanishing almost-periodic
rightmost cluster and a stable Bohr mean-motion chamber.

For the compact bump, endpoint localization makes all distinct ordinates
remote Fourier modes. Their whole contribution is summably `o(A_*)`.

Therefore the local attained-rightmost lock no longer needs the Bohr chamber
assumption.

## Remaining zero-side obstruction

Only the genuinely nonattained right edge remains:

`sup Re(rho)>1/2` but no zero attains the supremum.

Then the effective endpoint-dominant ordinate may migrate to infinity with L.

Verdict: **ATTAINED_RIGHTMOST_BUMP_REMOTE_SUMMABILITY_REDUCTION_PASS**
