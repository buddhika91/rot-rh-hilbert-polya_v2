#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v458 — FIXED-EXPONENT DYADIC CAUCHY / CONTINUOUS CUTOFF AUDIT
===================================================================

PURPOSE
-------
v457 falsified the current packet-Fourier theorem model, but its independent
root data showed a much stronger direct signal: dyadic endpoint increments and
sampled excursions contract very rapidly.  v458 attacks that direct route with
NO fitted convergence exponent in the decisive theorem gate.

Let L=log X and let E_k(L) be a simple continued branch.  On dyadic intervals
I_j=[L_j,L_j+log 2], define

    S_{k,j} = E_k(L_j+log 2)-E_k(L_j),
    T_{k,j} = int_{I_j} |E'_k(L)| dL.

A sufficient cutoff-independence theorem is

    |S_{k,j}| <= C_k L_j^(-p),       p > 1,
    T_{k,j}   <= D_k L_j^(-q),       q > 0.

Then sum_j |S_{k,j}| < infinity, so dyadic endpoints are Cauchy, while
T_{k,j}->0 squeezes every continuous point in I_j to the same limit.

v458 freezes p and q BEFORE the fresh holdout.  It uses v456 root trajectories
only as historical root data; it does not use the v456 packet mechanism.
It recomputes exact implicit flow on the tail training intervals via

    E'_k(L) = finitepart_L(E_k(L),L)/(pi F_E(E_k(L),L)),

then SHA-freezes the fixed-exponent envelopes.  Only afterward does it build the
prime table and solve a genuinely new doubling, by default

    74,649,600 -> 149,299,200.

SCIENTIFIC BOUNDARY
-------------------
A successful prospective holdout is strong evidence for the exact sufficient
inequalities above.  It is not an all-L proof.  The analytic theorem still has
to establish the frozen fixed-exponent bounds for every sufficiently large j.
No known Riemann zero ordinates, zeta(), Xi(), or xi() are used.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.integrate import simpson
from tqdm import tqdm

VERSION = "2026-08-26-v458-fixed-exponent-dyadic-cauchy"


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, np.integer): return int(x)
    if isinstance(x, np.floating): return float(x)
    if isinstance(x, np.ndarray): return [json_safe(v) for v in x.tolist()]
    if isinstance(x, dict): return {str(k): json_safe(v) for k,v in x.items()}
    if isinstance(x, (list, tuple)): return [json_safe(v) for v in x]
    return x


def read_csv(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8"); return
    fields=[]; seen=set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k); fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


def safe_rel(a: float, b: float, floor: float=1e-12) -> float:
    return abs(float(a)-float(b))/max(abs(float(a)),abs(float(b)),float(floor))


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py beside v458."
        )


def dedupe_sorted(rows: Sequence[dict]) -> List[dict]:
    out=[]
    for r in sorted(rows,key=lambda z:float(z["logX"])):
        if out and abs(float(r["logX"])-float(out[-1]["logX"])) < 1e-11:
            # Prefer HOLDOUT row if duplicated; numerically roots should agree.
            if str(r.get("phase","")).upper()=="HOLDOUT": out[-1]=r
        else:
            out.append(r)
    return out


def historical_interval_rows(nodes: Sequence[dict], cutoffs: Sequence[int], mode: int) -> List[dict]:
    rr=[r for r in nodes if int(r["mode"])==int(mode)]
    out=[]
    tol=2e-8
    for j,(Xa,Xb) in enumerate(zip(cutoffs[:-1],cutoffs[1:])):
        La,Lb=math.log(float(Xa)),math.log(float(Xb))
        z=dedupe_sorted([r for r in rr if La-tol <= float(r["logX"]) <= Lb+tol])
        if len(z)<3:
            raise RuntimeError(f"mode {mode}: interval {Xa}->{Xb} has only {len(z)} historical nodes")
        E=np.asarray([float(r["E"]) for r in z],float)
        L=np.asarray([float(r["logX"]) for r in z],float)
        out.append({
            "interval":j,"Xa":Xa,"Xb":Xb,"L_left":La,"L_right":Lb,
            "nodes":len(z),"E_left":float(E[0]),"E_right":float(E[-1]),
            "abs_delta_E":float(abs(E[-1]-E[0])),
            "sampled_excursion":float(np.max(E)-np.min(E)),
            "sampled_variation":float(np.sum(np.abs(np.diff(E)))),
            "rows":z,"L":L,"E":E,
        })
    return out


def fixed_envelope(intervals: Sequence[dict], quantity: str, exponent: float,
                   development_count: int, safety: float) -> dict:
    if development_count < 2 or development_count >= len(intervals):
        raise ValueError("development_count must leave at least one blocked interval")
    vals=np.asarray([max(float(r[quantity]),1e-300) for r in intervals],float)
    L=np.asarray([float(r["L_left"]) for r in intervals],float)
    scaled=vals*np.power(L,float(exponent))
    C_dev=float(safety*np.max(scaled[:development_count]))
    blocked_bounds=C_dev*np.power(L[development_count:],-float(exponent))
    blocked_pass=bool(np.all(vals[development_count:] <= blocked_bounds))
    blocked_ratios=vals[development_count:]/np.maximum(blocked_bounds,1e-300)
    C_final=float(safety*np.max(scaled))
    return {
        "quantity":quantity,"exponent":float(exponent),"development_count":int(development_count),
        "safety":float(safety),"C_dev":C_dev,"C_final":C_final,
        "training_values":[float(x) for x in vals],"training_L_left":[float(x) for x in L],
        "scaled_values":[float(x) for x in scaled],
        "blocked_pass":blocked_pass,
        "blocked_max_ratio":float(np.max(blocked_ratios)) if blocked_ratios.size else 0.0,
    }


def predict_envelope(model: dict, L_left: float) -> float:
    return float(model["C_final"]*float(L_left)**(-float(model["exponent"])))


def vectorized_phase_quantities(v452, phase, E_values: np.ndarray, modes: Sequence[int],
                                prime_chunk: int) -> dict:
    """Evaluate f, F_E, F_L, and exact dE/dL for all modes with one sin/cos pass/chunk."""
    E=np.asarray(E_values,float); nm=len(E)
    pp=np.zeros(nm); pe=np.zeros(nm); pl=np.zeros(nm)
    logs=np.asarray(phase.logs,float)
    wph=np.asarray(phase.w_phase,float); we=np.asarray(phase.w_E,float); wl=np.asarray(phase.w_L,float)
    pc=int(prime_chunk)
    for a in range(0,len(logs),pc):
        z=min(len(logs),a+pc); lg=logs[a:z]
        ang=np.outer(E,lg)
        s=np.sin(ang); c=np.cos(ang)
        pp += s @ wph[a:z]
        pl += s @ wl[a:z]
        pe += c @ we[a:z]
    angp=np.outer(E,np.asarray(phase.y,float))
    sp=np.sin(angp); cp=np.cos(angp)
    mp=sp @ np.asarray(phase.pnt_phase_w,float)
    ml=sp @ np.asarray(phase.pnt_L_w,float)
    me=cp @ np.asarray(phase.pnt_E_w,float)
    acp=np.asarray([v452.pnt_ac_phase(float(e)) for e in E],float)
    ace=np.asarray([v452.pnt_ac_phase_derivative(float(e)) for e in E],float)
    finite_phase=pp-mp+acp
    finite_E=pe-me+ace
    finite_L=pl-ml
    smooth=np.asarray([v452.smooth_count(float(e)) for e in E],float)
    smoothp=np.asarray([v452.smooth_count_prime(float(e)) for e in E],float)
    kval=np.asarray([float(k)-0.5 for k in modes],float)
    f=smooth-finite_phase/math.pi-kval
    FE=smoothp-finite_E/math.pi
    FL=-finite_L/math.pi
    flow=-FL/FE
    return {"f":f,"FE":FE,"FL":FL,"flow":flow,"finite_L":finite_L}


def make_phase(v452,n_all,lam_all,X,pnt_q,prime_chunk):
    idx=int(np.searchsorted(n_all,float(X),side="left"))
    return v452.FinitePartBump2(n_all[:idx],lam_all[:idx],float(X),int(pnt_q),int(prime_chunk))


def quantize_holdout(v452, phase, modes: Sequence[int], free: np.ndarray,
                     previous: Dict[int,float], root_tol: float,
                     max_newton: int, scan_points: int) -> Tuple[np.ndarray,List[object]]:
    roots=[]; vals=[]; prev_ordered=None
    for k in modes:
        seed=float(previous[int(k)])
        if int(k)==1:
            spacing=float(free[1]-free[0]) if len(free)>1 else 2.0
        elif int(k)<len(free):
            spacing=0.5*float(free[int(k)]-free[int(k)-2])
        else:
            spacing=float(free[-1]-free[-2])
        rr=v452.locate_root(phase,int(k),seed,spacing,prev_ordered,float(root_tol),int(max_newton),int(scan_points))
        if not rr.ok:
            raise RuntimeError(f"fresh holdout root failed mode={k} X={phase.X:.12g}: {rr.reason} residual={rr.residual:.3e}")
        vals.append(float(rr.root)); roots.append(rr); prev_ordered=float(rr.root)
    return np.asarray(vals,float),roots


def recompute_training_flow_tail(v452,n_all,lam_all,historical: Dict[int,List[dict]],
                                 cutoffs: Sequence[int], modes: Sequence[int],
                                 tail_intervals: int,pnt_q:int,prime_chunk:int) -> Tuple[List[dict],float,float]:
    start=max(0,len(cutoffs)-1-int(tail_intervals))
    rows=[]; max_res=0.0; min_FE=float("inf")
    for j in range(start,len(cutoffs)-1):
        Xa,Xb=cutoffs[j],cutoffs[j+1]
        # All modes share the same L grid from historical v456 data.
        z0=historical[int(modes[0])][j]
        Lgrid=np.asarray(z0["L"],float)
        mode_row_maps={k:{round(float(r["logX"]),11):r for r in historical[int(k)][j]["rows"]} for k in modes}
        flow_by={k:[] for k in modes}; E_by={k:[] for k in modes}
        for L in tqdm(Lgrid,desc=f"TRAIN exact flow {Xa}->{Xb}",unit="node"):
            key=round(float(L),11); X=float(math.exp(float(L)))
            E=np.asarray([float(mode_row_maps[int(k)][key]["E"]) for k in modes],float)
            ph=make_phase(v452,n_all,lam_all,X,pnt_q,prime_chunk)
            q=vectorized_phase_quantities(v452,ph,E,modes,prime_chunk)
            max_res=max(max_res,float(np.max(np.abs(q["f"]))))
            min_FE=min(min_FE,float(np.min(np.abs(q["FE"]))))
            for mi,k in enumerate(modes):
                flow_by[int(k)].append(float(q["flow"][mi])); E_by[int(k)].append(float(E[mi]))
        for k in modes:
            v=np.asarray(flow_by[int(k)],float); E=np.asarray(E_by[int(k)],float)
            signed=float(simpson(v,x=Lgrid)); tv=float(simpson(np.abs(v),x=Lgrid)); actual=float(E[-1]-E[0])
            rows.append({
                "stage":"TRAIN","interval":j,"Xa":Xa,"Xb":Xb,"mode":int(k),
                "L_left":fmt(Lgrid[0]),"L_right":fmt(Lgrid[-1]),
                "actual_delta_E":fmt(actual),"abs_delta_E":fmt(abs(actual)),
                "simpson_signed_flow":fmt(signed),"duhamel_abs_gap":fmt(abs(signed-actual)),
                "duhamel_rel_gap":fmt(safe_rel(signed,actual,1e-10)),"total_variation":fmt(tv),
                "variation_to_increment":fmt(tv/max(abs(actual),1e-15)),
            })
    return rows,max_res,min_FE


def main() -> int:
    ap=argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--v452-module",default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--v456-prefix",default="rot_rh_bump2_packet_fourier_cancellation_v456")
    ap.add_argument("--training-cutoffs",default="2332800,4665600,9331200,18662400,37324800,74649600")
    ap.add_argument("--fresh-holdout",type=int,default=149299200)
    ap.add_argument("--modes",default="1,2,4,8,12,16,24,32")
    ap.add_argument("--nodes-per-doubling",type=int,default=9)
    ap.add_argument("--flow-tail-intervals",type=int,default=3)
    ap.add_argument("--pnt-q",type=int,default=3072)
    ap.add_argument("--prime-chunk",type=int,default=100000)
    ap.add_argument("--root-tol",type=float,default=2e-9)
    ap.add_argument("--scan-points",type=int,default=65)
    ap.add_argument("--max-newton",type=int,default=12)
    ap.add_argument("--increment-exponent",type=float,default=1.10,help="Frozen p>1 theorem exponent; NOT fitted.")
    ap.add_argument("--variation-exponent",type=float,default=0.10,help="Frozen q>0 theorem exponent; NOT fitted.")
    ap.add_argument("--development-intervals",type=int,default=3)
    ap.add_argument("--envelope-safety",type=float,default=2.0)
    ap.add_argument("--maximum-holdout-ratio",type=float,default=1.0)
    ap.add_argument("--minimum-transversality",type=float,default=1e-3)
    ap.add_argument("--maximum-root-residual",type=float,default=2e-7)
    ap.add_argument("--maximum-duhamel-relative-gap",type=float,default=1e-2)
    ap.add_argument("--maximum-duhamel-absolute-gap",type=float,default=1e-6)
    ap.add_argument("--priority-modes",default="12,32")
    ap.add_argument("--prefix",default="rot_rh_fixed_exponent_dyadic_cauchy_v458")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()

    started=time.perf_counter(); v452=import_v452(args.v452_module)
    cutoffs=parse_ints(args.training_cutoffs); modes=parse_ints(args.modes); priority=parse_ints(args.priority_modes)
    if len(cutoffs)<5 or cutoffs!=sorted(cutoffs): raise ValueError("need >=5 increasing training cutoffs")
    if args.fresh_holdout <= cutoffs[-1]: raise ValueError("fresh holdout must exceed final training cutoff")
    if abs(args.fresh_holdout/cutoffs[-1]-2.0)>0.02: print("WARNING: fresh holdout is not approximately dyadic")
    if args.increment_exponent<=1.0: raise ValueError("increment exponent must be >1")
    if args.variation_exponent<=0.0: raise ValueError("variation exponent must be >0")
    if args.nodes_per_doubling<5 or args.nodes_per_doubling%2==0: raise ValueError("nodes-per-doubling must be odd >=5")

    vp=Path(args.v456_prefix)
    nodes_path=Path(str(vp)+"_PACKET_PHASE_NODES.csv")
    if not nodes_path.exists(): raise FileNotFoundError(nodes_path)
    nodes=read_csv(nodes_path)
    historical={k:historical_interval_rows(nodes,cutoffs,k) for k in modes}

    print("="*176)
    print("ROT-RH v458 — FIXED-EXPONENT DYADIC CAUCHY / CONTINUOUS CUTOFF AUDIT")
    print("="*176)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("historical source                  : v456 ROOT TRAJECTORY ONLY (packet model ignored)")
    print("training cutoffs                   :",cutoffs)
    print("FRESH held-out interval            :",[cutoffs[-1],args.fresh_holdout])
    print("fixed increment theorem exponent   :",args.increment_exponent,"(must be >1)")
    print("fixed variation theorem exponent   :",args.variation_exponent,"(must be >0)")
    print("theorem target                     : sum |Delta E_j| < inf and T_j -> 0")
    print("="*176)

    # A. Endpoint fixed-exponent blocked validation, no fresh prime table yet.
    print("\n[A] Freezing fixed-exponent endpoint envelopes from historical roots ...")
    endpoint_models={}; endpoint_rows=[]; blocked_endpoint_all=True
    for k in modes:
        ints=historical[k]
        inc=fixed_envelope(ints,"abs_delta_E",args.increment_exponent,args.development_intervals,args.envelope_safety)
        exc=fixed_envelope(ints,"sampled_excursion",args.variation_exponent,args.development_intervals,args.envelope_safety)
        endpoint_models[str(k)]={"increment":inc,"sampled_excursion":exc}
        blocked_endpoint_all &= bool(inc["blocked_pass"] and exc["blocked_pass"])
        endpoint_rows.append({"mode":k,"increment_blocked_pass":inc["blocked_pass"],"increment_blocked_max_ratio":fmt(inc["blocked_max_ratio"]),"excursion_blocked_pass":exc["blocked_pass"],"excursion_blocked_max_ratio":fmt(exc["blocked_max_ratio"])})
        print(f"  k={k:<3d} endpoint blocked inc={inc['blocked_pass']} ratio={inc['blocked_max_ratio']:.3f}  sampled-exc={exc['blocked_pass']} ratio={exc['blocked_max_ratio']:.3f}")

    # B. Recompute exact flow only on tail training intervals using known roots.
    print("\n[B] Recomputing exact implicit flow on tail TRAIN intervals ...")
    # This table is still training-only; fresh holdout table is NOT built yet.
    n_train,lam_train=v452.mangoldt_terms(int(cutoffs[-1]))
    flow_train,max_train_res,min_train_FE=recompute_training_flow_tail(
        v452,n_train,lam_train,historical,cutoffs,modes,args.flow_tail_intervals,args.pnt_q,args.prime_chunk
    )
    print(f"  TRAIN exact-flow max secular residual : {max_train_res:.6e}")
    print(f"  TRAIN exact-flow min |F_E|            : {min_train_FE:.6e}")

    # Build fixed q envelope for total variation. Last tail interval is blocked.
    variation_models={}; blocked_variation_all=True
    for k in modes:
        rr=sorted([r for r in flow_train if int(r["mode"])==k],key=lambda r:int(r["interval"]))
        if len(rr)<3: raise RuntimeError("need >=3 tail flow intervals for variation blocking")
        vals=np.asarray([float(r["total_variation"]) for r in rr],float)
        L=np.asarray([float(r["L_left"]) for r in rr],float)
        q=float(args.variation_exponent)
        dev=len(rr)-1
        Cdev=float(args.envelope_safety*np.max(vals[:dev]*L[:dev]**q))
        pred=Cdev*L[dev:]**(-q); br=vals[dev:]/np.maximum(pred,1e-300)
        bpass=bool(np.all(br<=1.0)); Cfinal=float(args.envelope_safety*np.max(vals*L**q))
        variation_models[str(k)]={"exponent":q,"C_dev":Cdev,"C_final":Cfinal,"blocked_pass":bpass,"blocked_max_ratio":float(np.max(br)),"training_values":[float(x) for x in vals],"training_L_left":[float(x) for x in L]}
        blocked_variation_all &= bpass
        print(f"  k={k:<3d} TV blocked={bpass} ratio={float(np.max(br)):.3f}  T_tail={vals[-1]:.3e}")

    hold_L=math.log(float(cutoffs[-1]))
    frozen_predictions={}
    for k in modes:
        inc=endpoint_models[str(k)]["increment"]
        exc=endpoint_models[str(k)]["sampled_excursion"]
        tv=variation_models[str(k)]
        frozen_predictions[str(k)]={
            "abs_delta_E_upper":predict_envelope(inc,hold_L),
            "sampled_excursion_upper":predict_envelope(exc,hold_L),
            "total_variation_upper":float(tv["C_final"]*hold_L**(-float(tv["exponent"]))),
        }

    freeze={
        "version":VERSION,"frozen_before_fresh_holdout":True,
        "v452_module":args.v452_module,"v452_sha256":sha256_file(Path(v452.__file__).resolve()),
        "v456_nodes":str(nodes_path),"v456_nodes_sha256":sha256_file(nodes_path),
        "training_cutoffs":cutoffs,"fresh_holdout_interval":[cutoffs[-1],args.fresh_holdout],
        "modes":modes,"fixed_exponents":{"increment_p":args.increment_exponent,"variation_q":args.variation_exponent},
        "endpoint_models":endpoint_models,"variation_models":variation_models,"fresh_predictions":frozen_predictions,
        "blocked_endpoint_all_modes":blocked_endpoint_all,"blocked_variation_all_modes":blocked_variation_all,
        "training_exact_flow_max_residual":max_train_res,"training_exact_flow_min_abs_FE":min_train_FE,
        "firewall":{"known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,"fresh_prime_table_built":False,"fresh_interval_solved":False},
        "gates":vars(args),
    }
    prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    freeze_path=Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json"); freeze_path.write_text(json.dumps(json_safe(freeze),indent=2),encoding="utf-8")
    freeze_sha=sha256_file(freeze_path)
    print("\n[C] PRE-HOLDOUT fixed theorem envelopes frozen")
    print("  SHA256                              :",freeze_sha)

    # D. Fresh prime table and new doubling only after freeze.
    print("\n[D] Revealing genuinely FRESH dyadic interval ...")
    n_all,lam_all=v452.mangoldt_terms(int(args.fresh_holdout))
    free=v452.free_archimedean_levels(max(modes))
    Lgrid=np.linspace(math.log(float(cutoffs[-1])),math.log(float(args.fresh_holdout)),args.nodes_per_doubling)
    previous={k:historical[k][-1]["E_right"] for k in modes}
    fresh_nodes=[]; per_mode_E={k:[] for k in modes}; per_mode_v={k:[] for k in modes}
    max_res=0.0; min_FE=float("inf"); order_pass=True
    for ii,L in enumerate(tqdm(Lgrid,desc=f"FRESH flow {cutoffs[-1]}->{args.fresh_holdout}",unit="node")):
        X=float(math.exp(float(L)))
        if ii==0:
            E=np.asarray([previous[k] for k in modes],float)
            ph=make_phase(v452,n_all,lam_all,X,args.pnt_q,args.prime_chunk)
            qv=vectorized_phase_quantities(v452,ph,E,modes,args.prime_chunk)
        else:
            ph=make_phase(v452,n_all,lam_all,X,args.pnt_q,args.prime_chunk)
            E,root_objs=quantize_holdout(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
            qv=vectorized_phase_quantities(v452,ph,E,modes,args.prime_chunk)
        order_pass &= bool(np.all(np.diff(E)>0))
        max_res=max(max_res,float(np.max(np.abs(qv["f"]))))
        min_FE=min(min_FE,float(np.min(np.abs(qv["FE"]))))
        previous={k:float(E[mi]) for mi,k in enumerate(modes)}
        for mi,k in enumerate(modes):
            per_mode_E[k].append(float(E[mi])); per_mode_v[k].append(float(qv["flow"][mi]))
            fresh_nodes.append({"node_index":ii,"L":fmt(L),"X":fmt(X),"mode":k,"E":fmt(E[mi]),"secular_residual":fmt(abs(qv["f"][mi])),"F_E":fmt(qv["FE"][mi]),"dE_dlogX":fmt(qv["flow"][mi])})

    # E. Score exact fresh interval against frozen fixed-exponent envelopes.
    print("\n[E] Scoring fresh interval against frozen theorem envelopes ...")
    score=[]; all_mode_pass=True; priority_pass=True; duhamel_all=True
    for k in modes:
        E=np.asarray(per_mode_E[k],float); v=np.asarray(per_mode_v[k],float)
        actual=float(E[-1]-E[0]); D=abs(actual); exc=float(np.max(E)-np.min(E)); tv=float(simpson(np.abs(v),x=Lgrid)); signed=float(simpson(v,x=Lgrid))
        rel=safe_rel(signed,actual,1e-10); ab=abs(signed-actual); dpass=bool(rel<=args.maximum_duhamel_relative_gap or ab<=args.maximum_duhamel_absolute_gap)
        duhamel_all &= dpass
        pred=frozen_predictions[str(k)]
        rD=D/max(float(pred["abs_delta_E_upper"]),1e-300)
        rA=exc/max(float(pred["sampled_excursion_upper"]),1e-300)
        rT=tv/max(float(pred["total_variation_upper"]),1e-300)
        passD=rD<=args.maximum_holdout_ratio; passA=rA<=args.maximum_holdout_ratio; passT=rT<=args.maximum_holdout_ratio
        mode_pass=bool(passD and passA and passT and dpass)
        all_mode_pass &= mode_pass
        if k in priority: priority_pass &= mode_pass
        score.append({
            "mode":k,"actual_abs_delta_E":fmt(D),"abs_delta_E_upper":fmt(pred["abs_delta_E_upper"]),"increment_ratio":fmt(rD),"increment_pass":passD,
            "actual_sampled_excursion":fmt(exc),"sampled_excursion_upper":fmt(pred["sampled_excursion_upper"]),"excursion_ratio":fmt(rA),"excursion_pass":passA,
            "actual_total_variation":fmt(tv),"total_variation_upper":fmt(pred["total_variation_upper"]),"variation_ratio":fmt(rT),"variation_pass":passT,
            "simpson_signed_flow":fmt(signed),"duhamel_relative_gap":fmt(rel),"duhamel_absolute_gap":fmt(ab),"duhamel_pass":dpass,"mode_pass":mode_pass,
        })
        print(f"  k={k:<3d} |dE|={D:.3e}/{pred['abs_delta_E_upper']:.3e} r={rD:.3f}  T={tv:.3e}/{pred['total_variation_upper']:.3e} r={rT:.3f}  Duh={rel:.2e} pass={mode_pass}")

    root_pass=max_res<=args.maximum_root_residual
    trans_pass=min_FE>=args.minimum_transversality
    training_root_pass=max_train_res<=args.maximum_root_residual
    training_trans_pass=min_train_FE>=args.minimum_transversality

    if not training_root_pass or not root_pass:
        verdict="ROOT_CERTIFICATION_FAILED"
    elif not training_trans_pass or not trans_pass:
        verdict="TRANSVERSALITY_FAILED"
    elif not blocked_endpoint_all:
        verdict="FIXED_ENDPOINT_ENVELOPE_BLOCKED_VALIDATION_FAILED"
    elif not blocked_variation_all:
        verdict="FIXED_VARIATION_ENVELOPE_BLOCKED_VALIDATION_FAILED"
    elif not duhamel_all:
        verdict="FRESH_DUHAMEL_IDENTITY_NOT_RESOLVED"
    elif not all_mode_pass:
        verdict="FRESH_FIXED_EXPONENT_CAUCHY_HOLDOUT_FAILED"
    elif not priority_pass:
        verdict="PRIORITY_MODE_CAUCHY_HOLDOUT_FAILED"
    elif not order_pass:
        verdict="ROOT_ORDERING_FAILED"
    else:
        verdict="FIXED_EXPONENT_DYADIC_CAUCHY_SUPPORTED_PROSPECTIVELY"

    nodes_out=Path(str(prefix)+"_FRESH_FLOW_NODES.csv"); score_out=Path(str(prefix)+"_FRESH_SCORE.csv"); train_flow_out=Path(str(prefix)+"_TRAIN_FLOW_TAIL.csv"); endpoint_out=Path(str(prefix)+"_ENDPOINT_BLOCKED.csv")
    write_csv(nodes_out,fresh_nodes); write_csv(score_out,score); write_csv(train_flow_out,flow_train); write_csv(endpoint_out,endpoint_rows)

    theorem=f"""# ROT-RH v458 — fixed-exponent dyadic Cauchy theorem target

Numerical verdict: **{verdict}**

Let `L_j=L_0+j log 2`, `S_{{k,j}}=E_k(L_{{j+1}})-E_k(L_j)`, and
`T_{{k,j}}=int_[L_j,L_{{j+1}}] |E'_k(L)| dL`.

The frozen theorem exponents are

`p={args.increment_exponent}` and `q={args.variation_exponent}`.

The analytic target is to prove, for each fixed branch k and all sufficiently
large j,

`|S_{{k,j}}| <= C_k L_j^(-p)`

and

`T_{{k,j}} <= D_k L_j^(-q)`.

Because `p>1` and `L_j=L_0+j log 2`, `sum_j |S_{{k,j}}|<infinity`, hence the
dyadic endpoints are Cauchy.  Because `q>0`, `T_{{k,j}}->0`, and for every
`L in [L_j,L_{{j+1}}]`,

`|E_k(L)-E_k(L_j)| <= T_{{k,j}} -> 0`.

Therefore the full continuous branch converges: `E_k(L)->E_k(infinity)`.

v458 is a prospective finite audit of these sufficient inequalities, not their
all-j proof and not an RH proof.
"""
    theorem_out=Path(str(prefix)+"_THEOREM.md"); theorem_out.write_text(theorem,encoding="utf-8")
    summary={
        "version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-started,
        "pre_holdout_freeze_sha256":freeze_sha,"training_cutoffs":cutoffs,"fresh_holdout_interval":[cutoffs[-1],args.fresh_holdout],"modes":modes,
        "fixed_increment_exponent":args.increment_exponent,"fixed_variation_exponent":args.variation_exponent,
        "blocked_endpoint_all_modes":blocked_endpoint_all,"blocked_variation_all_modes":blocked_variation_all,
        "training_max_secular_residual":max_train_res,"fresh_max_secular_residual":max_res,"training_min_abs_FE":min_train_FE,"fresh_min_abs_FE":min_FE,
        "root_pass":root_pass and training_root_pass,"transversality_pass":trans_pass and training_trans_pass,"fresh_duhamel_all_modes":duhamel_all,"fresh_all_modes_pass":all_mode_pass,"priority_modes_pass":priority_pass,"root_ordering_pass":order_pass,
        "scores":score,"scientific_boundary":"Finite prospective evidence for fixed sufficient dyadic Cauchy inequalities. All-j analytic bounds remain to be proved.",
        "outputs":{"fresh_nodes":str(nodes_out),"fresh_score":str(score_out),"training_flow_tail":str(train_flow_out),"endpoint_blocked":str(endpoint_out),"freeze":str(freeze_path),"theorem":str(theorem_out)},
    }
    summary_out=Path(str(prefix)+"_SUMMARY.json"); summary_out.write_text(json.dumps(json_safe(summary),indent=2),encoding="utf-8")

    print("\n"+"="*176); print("KEY RESULTS"); print("="*176)
    print("verdict                                  :",verdict)
    print("pre-holdout freeze SHA256                :",freeze_sha)
    print("fixed endpoint blocked validation all    :",blocked_endpoint_all)
    print("fixed variation blocked validation all   :",blocked_variation_all)
    print(f"training/fresh max secular residual      : {max_train_res:.6e} / {max_res:.6e} pass={root_pass and training_root_pass}")
    print(f"training/fresh min |F_E|                 : {min_train_FE:.6e} / {min_FE:.6e} pass={trans_pass and training_trans_pass}")
    print("fresh Duhamel identity all modes         :",duhamel_all)
    print("fresh fixed-exponent envelopes all modes :",all_mode_pass)
    print("priority modes pass                      :",priority_pass,priority)
    print("root ordering pass                       :",order_pass)
    print("fixed theorem exponents                  : p=",args.increment_exponent,"q=",args.variation_exponent)
    print("summary                                  :",summary_out)
    print("theorem target                           :",theorem_out)
    print("="*176)
    if args.strict and verdict!="FIXED_EXPONENT_DYADIC_CAUCHY_SUPPORTED_PROSPECTIVELY": return 2
    return 0


if __name__=="__main__":
    raise SystemExit(main())
