# ROT-RH v440 — operator-limit promotion theorem

## A. Strong-resolvent promotion

On the fixed action Hilbert space \(\ell^2(J)\), define

\[
H_X e_j=E_{j,X}e_j,\qquad F_X(E_{j,X})=\pi(j+\tfrac12).
\]

Assume that for every fixed action label \(j\),

\[
E_{j,X}\to E_j.
\]

Define \(H_\infty e_j=E_j e_j\). For \(z\notin\mathbb R\),

\[
(H_X-z)^{-1}e_j=(E_{j,X}-z)^{-1}e_j.
\]

Hence for every \(f=(f_j)\in\ell^2\),

\[
\|(H_X-z)^{-1}f-(H_\infty-z)^{-1}f\|^2
=\sum_j |f_j|^2
\left|(E_{j,X}-z)^{-1}-(E_j-z)^{-1}\right|^2.
\]

Each summand tends to zero and is bounded by
\(4|f_j|^2/|\operatorname{Im}z|^2\). Dominated convergence gives

\[
\boxed{H_X\xrightarrow{\rm strong\ resolvent}H_\infty.}
\]

No convergence rate uniform in \(j\) is required. Therefore a proof of the
v438 fixed-mode theorem for every fixed mode already promotes to an infinite
self-adjoint operator limit.

## B. Trace-class promotion

Assume additionally positivity and uniform inverse-square tail tightness:

\[
\lim_{M\to\infty}\sup_{X\ge X_0}\sum_{j>M}E_{j,X}^{-2}=0.
\]

Set \(K_X=H_X^{-2}\), \(K_\infty=H_\infty^{-2}\). Then

\[
\|K_X-K_\infty\|_1
\le \sum_{j\le M}|E_{j,X}^{-2}-E_j^{-2}|
+\sum_{j>M}E_{j,X}^{-2}+\sum_{j>M}E_j^{-2}.
\]

First send \(X\to\infty\) at fixed \(M\), then \(M\to\infty\). Thus

\[
\boxed{K_X\to K_\infty\ \text{in trace norm}.}
\]

A sufficient stronger hypothesis is a cutoff-uniform Weyl lower bound

\[
E_{j,X}\ge c\,j/\log(j+1),
\]

because \(\sum_j(\log(j+1)/j)^2<\infty\).

## C. Fredholm consequence

Trace-norm convergence gives, locally uniformly in \(t\),

\[
\boxed{\det(I-t^2K_X)\to\det(I-t^2K_\infty).}
\]

So cutoff independence of the operator reduces to two scalar obligations:

1. **T_MODE:** prove the v438 fixed-mode convergence for every fixed action label.
2. **T_TAIL:** prove uniform inverse-square tail tightness (or a cutoff-uniform
   Weyl lower bound).

Only after those remain the separate entire-function identity
\(\det(I-t^2K_\infty)=\Xi(t)/\Xi(0)\).

## D. Why not take \(G_X=F'_X(D)\) as the limit?

v438 uses the stiffness growth \(F'_X\gtrsim c_k\log X\) near locked modes to
make root motion summable. Thus \(G_X\) is a transversality generator, not the
quantity expected to approach the final Hilbert-Pólya Hamiltonian. The correct
limit object is the spectral/action-angle family \(H_X\).
