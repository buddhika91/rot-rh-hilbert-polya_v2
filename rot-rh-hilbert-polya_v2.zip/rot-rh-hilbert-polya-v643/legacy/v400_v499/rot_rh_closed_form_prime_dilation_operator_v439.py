#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v439 — CLOSED-FORM PRIME-DILATION / ACTION-ANGLE OPERATOR AUDIT
=====================================================================

PURPOSE
-------
Identify and audit a continuum closed-form operator underlying the current
zero-ordinate-free ROT-RH Riesz/PNT-centered secular law.

Let

    D = (xp+px)/2 = -i (x d/dx + 1/2)

on L^2(R_+, dx).  Mellin waves

    phi_E(x) = x^(-1/2+iE)

satisfy D phi_E = E phi_E.  Therefore, for any real a,

    cos(aD) phi_E = cos(aE) phi_E,

and, in x-space,

    cos(aD) f(x)
      = 1/2 [ exp(-a/2) f(exp(-a)x)
              + exp(+a/2) f(exp(+a)x) ].

For a=log n this is a multiplicative hop x <-> nx.

For the v71 Riesz/PNT-centered phase

    F_X(E) = theta(E) - P_X^R(E) + M_X^R(E),

we define the CLOSED-FORM DENSITY OPERATOR

    G_X := F'_X(D)

          = theta'(D)
            - sum_{n<X} c_{n,X} cos((log n)D)
            + int_2^X c_X(t) cos((log t)D) dt,

where

    c_{n,X} = Lambda(n)/sqrt(n) * (1-log n/log X),
    c_X(t)   = t^(-1/2) * (1-log t/log X).

The Archimedean part is

    theta'(D)
      = 1/4 [ psi(1/4+iD/2) + psi(1/4-iD/2) ]
        - 1/2 log pi.

Thus G_X is energy-independent and self-adjoint at finite X (on the natural
domain of theta'(D)); its generalized Mellin symbol is EXACTLY F'_X(E).

The corresponding phase operator is Phi_X = F_X(D).  The secular law is

    cos(F_X(E)) = 0,

or F_X(E) = pi(j+1/2).  On an action-angle Hilbert space with number operator

    N_{1/2}|j> = (j+1/2)|j>,

a direct energy-independent Hamiltonian realization is, branchwise,

    H_X^AA = F_X^{-1}(pi N_{1/2}).

This is exact wherever the chosen branch of F_X is one-to-one.  It is a
functional-calculus/action-angle realization of the arithmetic levels, not a
claim that the L->infinity theorem or Xi identity has been proved.

WHAT THIS SCRIPT AUDITS
-----------------------
1. Reconstructs the v71 phase and phase derivative without Xi/zeta/zeros.
2. Independently evaluates the PNT derivative as a Gauss-Legendre dilation
   integral and checks it against the v71 analytic formula.
3. Verifies the prime-dilation symbol against phase_prime_grid.
4. Checks F'_X by a finite-difference derivative of F_X.
5. Finds secular crossings cos(F_X)=0 and assigns the exact half-integer action
   labels j+1/2.
6. Builds the finite action-angle Hamiltonian diag(E_j), conjugates it by a DFT
   into an angle-grid representation, and checks Hermiticity/eigenvalue
   preservation.
7. Measures cutoff drift of common action labels across successive X.

SCIENTIFIC FIREWALL
-------------------
NO Xi evaluations.
NO zeta evaluations.
NO known Riemann-zero ordinates.
NO target-zero fitting.
NO finite PASS is promoted to the L->infinity theorem.

Version: 439
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.optimize import brentq
from tqdm import tqdm

VERSION = 439
EPS = 1.0e-300
LOG2 = math.log(2.0)


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(',') if x.strip()]


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    fields: List[str] = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                fields.append(k)
    with path.open('w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def pnt_prime_quadrature(E: np.ndarray, X: int, q: int) -> np.ndarray:
    """Independent quadrature of int_{log2}^{logX}(1-u/L)e^{u/2}cos(Eu)du."""
    E = np.asarray(E, dtype=float)
    L = math.log(float(X))
    z, w = leggauss(int(q))
    u = 0.5 * (L - LOG2) * z + 0.5 * (L + LOG2)
    W = 0.5 * (L - LOG2) * w
    amp = (1.0 - u / L) * np.exp(0.5 * u) * W
    return np.cos(np.outer(E, u)) @ amp


def phase_prime_closed(base, E: np.ndarray, X: int, logs: np.ndarray, weights: np.ndarray,
                       pnt_quad_order: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Closed-form Mellin symbol of G_X=F'_X(D), split into channels."""
    E = np.asarray(E, dtype=float)
    arch = np.asarray(base.theta_prime(E), dtype=float)
    deriv_weights = weights * logs
    prime = -(np.cos(np.outer(E, logs)) @ deriv_weights)
    pnt_q = pnt_prime_quadrature(E, X, pnt_quad_order)
    total_q = arch + prime + pnt_q
    pnt_exact = np.asarray(base.riesz_pnt_main_prime(E, X), dtype=float)
    return total_q, arch, prime, pnt_exact


def finite_difference_phase(base, E: np.ndarray, X: int, logs: np.ndarray, weights: np.ndarray,
                            h: float) -> np.ndarray:
    E = np.asarray(E, dtype=float)
    return (
        np.asarray(base.phase_grid(E + h, X, logs, weights), dtype=float)
        - np.asarray(base.phase_grid(E - h, X, logs, weights), dtype=float)
    ) / (2.0 * h)


def scan_crossings(base, X: int, logs: np.ndarray, weights: np.ndarray,
                   emin: float, emax: float, step: float, max_levels: int) -> List[Dict[str, float]]:
    grid = np.arange(float(emin), float(emax) + float(step), float(step), dtype=float)
    phase = np.asarray(base.phase_grid(grid, X, logs, weights), dtype=float)
    c = np.cos(phase)
    idx = np.flatnonzero(c[:-1] * c[1:] < 0.0)
    rows: List[Dict[str, float]] = []

    for i in idx:
        a = float(grid[i])
        b = float(grid[i + 1])

        def fn(x: float) -> float:
            return math.cos(float(base.phase_scalar(x, X, logs, weights)))

        try:
            r = float(brentq(fn, a, b, xtol=2e-13, rtol=2e-13, maxiter=200))
        except ValueError:
            continue
        if rows and abs(r - rows[-1]['energy']) < 1e-9:
            continue
        ph = float(base.phase_scalar(r, X, logs, weights))
        q = ph / math.pi
        # q must be half-integer.  j may be negative at very low E; preserve it.
        j = int(round(q - 0.5))
        target = j + 0.5
        rows.append({
            'energy': r,
            'phase': ph,
            'action_label_j': j,
            'action_target': target,
            'quantization_residual': abs(q - target),
            'cos_residual': abs(math.cos(ph)),
            'slope': float(base.phase_prime_grid(np.asarray([r]), X, logs, weights)[0]),
        })
        if len(rows) >= int(max_levels):
            break
    return rows


def dft_conjugated_hamiltonian(energies: np.ndarray) -> Tuple[np.ndarray, float, float]:
    """H_angle = U diag(E) U^*, with unitary DFT U."""
    e = np.asarray(energies, dtype=float)
    n = len(e)
    j = np.arange(n, dtype=float)
    U = np.exp(2j * math.pi * np.outer(j, j) / float(n)) / math.sqrt(float(n))
    H = U @ np.diag(e) @ U.conj().T
    herm = float(np.linalg.norm(H - H.conj().T, ord='fro') / max(np.linalg.norm(H, ord='fro'), EPS))
    ev = np.linalg.eigvalsh(0.5 * (H + H.conj().T))
    spec = float(np.max(np.abs(np.sort(ev) - np.sort(e)))) if n else float('nan')
    return H, herm, spec


def operator_theorem_text() -> str:
    return r"""# ROT-RH v439 — Closed-form prime-dilation operator candidate

Let

\[
D=\frac12(xp+px)=-i\left(x\frac{d}{dx}+\frac12\right)
\]

on \(L^2(\mathbb R_+,dx)\).  The Mellin waves
\(\phi_E(x)=x^{-1/2+iE}\) satisfy \(D\phi_E=E\phi_E\).

For finite \(X\), put \(L=\log X\) and

\[
c_{n,X}=\frac{\Lambda(n)}{\sqrt n}\left(1-\frac{\log n}{L}\right)_+.
\]

The exact Riesz/PNT-centered phase derivative is

\[
F'_X(E)=\theta'(E)
-\sum_{n<X}c_{n,X}\cos(E\log n)
+\int_2^X \frac{1-\log t/L}{\sqrt t}\cos(E\log t)\,dt.
\]

Therefore define the energy-independent continuum operator

\[
\boxed{
\mathcal G_X
=\theta'(D)
-\sum_{n<X}c_{n,X}\cos((\log n)D)
+\int_2^X\frac{1-\log t/L}{\sqrt t}\cos((\log t)D)\,dt
}
\]

with

\[
\theta'(D)=\frac14\left[
\psi\!\left(\frac14+\frac{iD}{2}\right)
+\psi\!\left(\frac14-\frac{iD}{2}\right)
\right]-\frac12\log\pi.
\]

Then, by spectral functional calculus,

\[
\boxed{\mathcal G_X\phi_E=F'_X(E)\phi_E.}
\]

Using

\[
e^{-iaD}f(x)=e^{-a/2}f(e^{-a}x),
\]

the prime channel is explicitly a multiplicative hopping operator:

\[
(\mathcal G_{X,\rm prime}f)(x)
=-\frac12\sum_{n<X}\Lambda(n)\left(1-\frac{\log n}{L}\right)
\left[\frac1n f\!\left(\frac{x}{n}\right)+f(nx)\right].
\]

The PNT counterchannel is the matching continuum of dilations:

\[
(\mathcal G_{X,\rm PNT}f)(x)
=\frac12\int_2^X\left(1-\frac{\log t}{L}\right)
\left[\frac1t f\!\left(\frac{x}{t}\right)+f(tx)\right]dt.
\]

Thus the centered arithmetic interaction is literally

\[
\boxed{\text{prime-power dilation hops} - \text{smooth continuum dilation background}.}
\]

The phase operator is \(\Phi_X=F_X(D)\).  Since the secular law is
\(F_X(E)=\pi(j+1/2)\), introduce the half-integer action operator

\[
N_{1/2}=-i\partial_\varphi+\frac12
\]

(on the positive Hardy/action sector).  Wherever the chosen secular branch is
one-to-one, define

\[
\boxed{H_X^{AA}=F_X^{-1}(\pi N_{1/2}).}
\]

Its eigenvalues are exactly the zero-free arithmetic secular levels.

This is a genuine energy-independent functional-calculus realization, but it
is not yet the final Hilbert-Polya theorem.  The remaining hard statements are:

1. prove branchwise/all-mode cutoff removal strongly enough to define
   \(H_\infty^{AA}\);
2. prove self-adjoint/operator convergence in a suitable resolvent topology;
3. prove its Fredholm/characteristic function equals \(\Xi/\Xi(0)\).

No Xi, zeta numerical values, known zero ordinates, or RH assumption enter v439.
"""


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument('--base-module', default='rot_rh_v69_regularized_prime_colligation_local_fredholm_v71')
    ap.add_argument('--cutoffs', default='30000,100000,300000,1000000')
    ap.add_argument('--emin', type=float, default=7.0)
    ap.add_argument('--emax', type=float, default=120.0)
    ap.add_argument('--energy-points', type=int, default=161)
    ap.add_argument('--levels', type=int, default=48)
    ap.add_argument('--scan-step', type=float, default=0.02)
    ap.add_argument('--pnt-quad-order', type=int, default=512)
    ap.add_argument('--finite-difference-h', type=float, default=2e-6)
    ap.add_argument('--maximum-symbol-absolute', type=float, default=2e-9)
    ap.add_argument('--maximum-pnt-quadrature-absolute', type=float, default=2e-9)
    ap.add_argument('--maximum-fd-relative', type=float, default=2e-5)
    ap.add_argument('--maximum-quantization-residual', type=float, default=2e-10)
    ap.add_argument('--maximum-hermitian-relative', type=float, default=5e-13)
    ap.add_argument('--maximum-spectrum-absolute', type=float, default=5e-10)
    ap.add_argument('--prefix', default='rot_rh_closed_form_prime_dilation_operator_v439')
    ap.add_argument('--strict', action='store_true')
    args = ap.parse_args()

    started = time.time()
    base = importlib.import_module(args.base_module)
    cutoffs = parse_ints(args.cutoffs)
    if not cutoffs:
        raise SystemExit('No cutoffs supplied.')
    maxX = max(cutoffs)
    primes = base.sieve_primes(maxX)
    Egrid = np.linspace(args.emin, args.emax, int(args.energy_points))

    print('=' * 190)
    print('ROT-RH v439 — CLOSED-FORM PRIME-DILATION / ACTION-ANGLE OPERATOR AUDIT')
    print('=' * 190)
    print('Xi / zeta / known zero ordinates : NONE')
    print('base module                       :', args.base_module)
    print('cutoffs                           :', cutoffs)
    print('prime count to max cutoff         :', len(primes))
    print('closed form                       : G_X = F_X\'(D), D=(xp+px)/2')
    print('=' * 190)

    summary_rows: List[Dict[str, object]] = []
    level_rows: List[Dict[str, object]] = []
    spectra_by_X: Dict[int, Dict[int, float]] = {}
    all_pass = True

    for X in tqdm(cutoffs, desc='cutoff operators', unit='X'):
        logs, weights, exponents = base.prime_power_riesz_terms(primes, X)

        closed_q, arch, prime_chan, pnt_exact = phase_prime_closed(
            base, Egrid, X, logs, weights, args.pnt_quad_order
        )
        direct = np.asarray(base.phase_prime_grid(Egrid, X, logs, weights), dtype=float)
        pnt_q = pnt_prime_quadrature(Egrid, X, args.pnt_quad_order)
        fd = finite_difference_phase(base, Egrid, X, logs, weights, args.finite_difference_h)

        symbol_abs = float(np.max(np.abs(closed_q - direct)))
        pnt_abs = float(np.max(np.abs(pnt_q - pnt_exact)))
        fd_rel = float(np.max(np.abs(fd - direct) / np.maximum(1.0, np.abs(direct))))

        roots = scan_crossings(
            base, X, logs, weights,
            args.emin, args.emax, args.scan_step, args.levels,
        )
        if not roots:
            raise RuntimeError(f'No secular crossings found for X={X}.')

        qres = float(max(r['quantization_residual'] for r in roots))
        energies = np.asarray([r['energy'] for r in roots], dtype=float)
        _, herm, spec = dft_conjugated_hamiltonian(energies)

        labels = {int(r['action_label_j']): float(r['energy']) for r in roots}
        spectra_by_X[X] = labels

        pass_symbol = symbol_abs <= args.maximum_symbol_absolute
        pass_pnt = pnt_abs <= args.maximum_pnt_quadrature_absolute
        pass_fd = fd_rel <= args.maximum_fd_relative
        pass_quant = qres <= args.maximum_quantization_residual
        pass_herm = herm <= args.maximum_hermitian_relative
        pass_spec = spec <= args.maximum_spectrum_absolute
        pass_X = bool(pass_symbol and pass_pnt and pass_fd and pass_quant and pass_herm and pass_spec)
        all_pass = all_pass and pass_X

        summary_rows.append({
            'cutoff_X': X,
            'logX': math.log(float(X)),
            'prime_power_terms': len(logs),
            'levels': len(roots),
            'max_symbol_abs': symbol_abs,
            'max_pnt_quad_abs': pnt_abs,
            'max_fd_relative': fd_rel,
            'max_quantization_residual': qres,
            'H_angle_hermitian_relative': herm,
            'H_angle_spectrum_abs': spec,
            'min_slope': float(min(r['slope'] for r in roots)),
            'median_slope_over_logX': float(np.median([r['slope'] for r in roots]) / math.log(float(X))),
            'pass': pass_X,
        })

        for r in roots:
            level_rows.append({'cutoff_X': X, **r})

        print(
            f'\nX={X:<10d} terms={len(logs):<8d} levels={len(roots):<4d} '
            f'| symbol={symbol_abs:.3e} PNTquad={pnt_abs:.3e} fdrel={fd_rel:.3e} '
            f'| qres={qres:.3e} Herm={herm:.3e} spec={spec:.3e} | pass={pass_X}'
        )

    drift_rows: List[Dict[str, object]] = []
    for Xa, Xb in zip(cutoffs[:-1], cutoffs[1:]):
        A = spectra_by_X[Xa]
        B = spectra_by_X[Xb]
        common = sorted(set(A).intersection(B))
        if not common:
            continue
        diffs = np.asarray([B[j] - A[j] for j in common], dtype=float)
        rel = np.asarray([abs(B[j] - A[j]) / max(abs(B[j]), EPS) for j in common], dtype=float)
        drift_rows.append({
            'lower_cutoff': Xa,
            'upper_cutoff': Xb,
            'common_action_labels': len(common),
            'rms_energy_drift': float(np.sqrt(np.mean(diffs * diffs))),
            'max_abs_energy_drift': float(np.max(np.abs(diffs))),
            'rms_relative_drift': float(np.sqrt(np.mean(rel * rel))),
            'first_common_j': int(common[0]),
            'last_common_j': int(common[-1]),
        })

    prefix = Path(args.prefix)
    summary_csv = Path(str(prefix) + '_SUMMARY.csv')
    levels_csv = Path(str(prefix) + '_LEVELS.csv')
    drift_csv = Path(str(prefix) + '_CUTOFF_DRIFT.csv')
    theorem_md = Path(str(prefix) + '_THEOREM.md')
    verdict_json = Path(str(prefix) + '_VERDICT.json')

    write_csv(summary_csv, summary_rows)
    write_csv(levels_csv, level_rows)
    write_csv(drift_csv, drift_rows)
    theorem_md.write_text(operator_theorem_text(), encoding='utf-8')

    verdict = 'CLOSED_FORM_PRIME_DILATION_ACTION_ANGLE_AUDIT_PASS' if all_pass else 'CLOSED_FORM_AUDIT_HAS_FAILED_GATES'
    payload = {
        'version': VERSION,
        'verdict': verdict,
        'this_is_an_RH_proof': False,
        'cutoff_independence_proved': False,
        'Xi_used': False,
        'zeta_used': False,
        'known_zero_ordinates_used': False,
        'closed_form_density_operator': "G_X = theta'(D) - sum c_n cos(log(n)D) + int c_X(t) cos(log(t)D) dt",
        'dilation_generator': 'D=(xp+px)/2=-i(x d/dx + 1/2)',
        'action_angle_candidate': 'H_X^AA = F_X^{-1}(pi N_{1/2}) branchwise',
        'key_interpretation': 'prime-power multiplicative hopping minus smooth PNT continuum hopping',
        'summary': summary_rows,
        'cutoff_drift': drift_rows,
        'next_theorem': (
            'Prove all-mode branchwise convergence of F_X^{-1}(pi(j+1/2)) and promote it to '
            'strong/norm-resolvent convergence of H_X^AA; then prove the cutoff-independent '
            'Fredholm characteristic equals Xi/Xi(0).'
        ),
        'runtime_seconds': time.time() - started,
    }
    verdict_json.write_text(json.dumps(payload, indent=2), encoding='utf-8')

    print('\n' + '=' * 190)
    print('VERDICT                           :', verdict)
    print('CLOSED-FORM DENSITY OPERATOR      : G_X = F_X\'(D), D=(xp+px)/2')
    print('PRIME CHANNEL                     : discrete multiplicative dilation hops')
    print('PNT CHANNEL                       : continuum multiplicative dilation background')
    print('ACTION-ANGLE HAMILTONIAN          : H_X^AA = F_X^{-1}(pi N_{1/2}) (branchwise)')
    print('CUTOFF-INDEPENDENT H_INFINITY     : NOT YET PROVED')
    print('XI IDENTITY                       : NOT TESTED HERE')
    print('outputs                           :', summary_csv, levels_csv, drift_csv, theorem_md, verdict_json)
    print('=' * 190)

    if args.strict and not all_pass:
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
