#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v499 — MINIMAL GAUSSIAN RH TARGET / UNIFORM INVERSE-SQUARE TRACE
======================================================================

v498 shows the Gaussian program no longer needs full fixed-mode convergence as
the first RH-bearing target.  It is enough to prove
    sup_L Tr(H_L^-2)<infinity.

Three sufficient operator routes are recorded:
  A. cutoff-uniform Weyl lower bound E_k(L)>=c k/log(k+e);
  B. cutoff-uniform free-level displacement |E_k(L)-A_k|<=D;
  C. trace-norm Cauchy cutoff sequence.

A or B also supplies the summable high-mode domination needed later for
trace-norm cutoff removal.  Thus the uniform trace bound is both an RH
criterion and a bridge back to the operator-limit program.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v499-minimal-gaussian-rh-target"

def tail_majorant(c,N):
    import math
    d=math.log(1+math.e/N)
    return ((math.log(N)+d)**2+2*(math.log(N)+d)+2)/(c*c*N)

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    cfile=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v499 — minimal Gaussian RH target: uniform inverse-square trace

v498 reduces the Gaussian RH problem to one positive operator estimate:

`sup_(L>=L0) Tr(H_L^-2)<infinity`.

This is weaker than proving trace-norm cutoff convergence and does not require
first proving convergence of every fixed eigenvalue.

There are three clean sufficient routes.

## Route A — uniform Weyl lower bound

If

`E_k(L)>=c k/log(k+e)`

for all sufficiently large `k,L`, then

`E_k(L)^-2`
` <=c^-2 [log(k+e)/k]^2`

and the right side is summable.  Together with the finitely many low modes this
gives the required uniform trace bound.  This is exactly the theorem shape
already isolated in v223/v230.

## Route B — uniform displacement from the free Archimedean levels

v232 gives

`A_k>=2k/log(k+e)`

eventually.  If one proves the v235 target

`sup_(L,k)|E_k(L)-A_k|<=D<infinity`,

then eventually

`E_k(L)>=k/log(k+e)`,

which again gives a uniform inverse-square trace bound.

Thus, **for the Gaussian regulator**, the old v235 uniform displacement target
would not merely prove the high-mode trace tail: combined with v497-v498, it
would force RH.

## Route C — trace-norm Cauchy directly

If the Gaussian

`K_L=H_L^-2`

form a trace-norm Cauchy family, norm boundedness is automatic and v498 forces
RH.  Fixed-mode convergence and the Fredholm-Xi identity may then be proved
afterward for the stronger Hilbert-Pólya conclusion.

### New strategic ordering

The most economical Gaussian attack is now:

1. prove `sup_L Tr(H_L^-2)<infinity` zero-blind;
2. v497-v498 then force RH;
3. with the off-critical sector eliminated, prove fixed-mode Gaussian cutoff
   convergence using only critical-line collision geometry plus the v494 remote
   primitive;
4. prove the uniform Weyl/trace-tail theorem and trace-norm convergence;
5. establish regulator universality / Fredholm-Xi identity.

This avoids spending the hardest analysis on an off-critical sector that a
positive trace estimate would already rule out.

**Verdict:** `UNIFORM_GAUSSIAN_INVERSE_SQUARE_TRACE_IS_MINIMAL_RH_TARGET_PASS`.

What remains open is the actual zero-blind proof of the uniform trace bound.
Existing v223/v230/v235/v443 results provide exact conditional transfer
theorems and strong numerical evidence, but their all-scale premises have not
been proved analytically.
""",encoding="utf-8")
    cfile.write_text(json.dumps({
        "schema":"ROT_RH_MINIMAL_GAUSSIAN_RH_TARGET_V1",
        "target":"sup_L Tr(H_L^-2)<infinity",
        "sufficient_routes":{
            "A":"uniform Weyl E_k>=c k/log(k+e)",
            "B":"uniform free-level displacement |E_k-A_k|<=D",
            "C":"trace-norm Cauchy of H_L^-2"
        },
        "consequence":"by v497-v498, target implies RH for the Gaussian regulator",
        "next_attack":"derive the uniform trace bound directly from the zero-blind Gaussian arithmetic/recursive operator, preferably through a global free-level displacement or positive trace identity"
    },indent=2),encoding="utf-8")
    return s,t,cfile

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--c",type=float,default=1.)
    ap.add_argument("--prefix",default="rot_rh_minimal_gaussian_rh_target_v499")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v499 target",unit="step") as bar:
        tails=[{"N":N,"tail":tail_majorant(args.c,N)} for N in (100,1000,10000,100000)];bar.update(1)
        routes=True;bar.update(1)
    ok=bool(routes and tails[-1]["tail"]<tails[0]["tail"])
    verdict="UNIFORM_GAUSSIAN_INVERSE_SQUARE_TRACE_IS_MINIMAL_RH_TARGET_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-t0,
             "tail_demo":tails,
             "target":"sup_L Tr(H_L^-2)<infinity",
             "proof_status":"Reduction theorem only; uniform trace bound remains the next analytic target."}
    prefix=Path(args.prefix).resolve()
    s,t,cfile=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",cfile)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
