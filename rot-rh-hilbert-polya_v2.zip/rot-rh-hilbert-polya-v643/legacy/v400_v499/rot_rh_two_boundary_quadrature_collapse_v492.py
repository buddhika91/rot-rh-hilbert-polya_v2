#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v492 — TWO-BOUNDARY QUADRATURE / COHERENCE-COLLAPSE REDUCTION
====================================================================

Let S_0 be the escaping off-critical saddle packet at the center of a local
critical collision cell and W_0=sum |b_j| its absolute mass.

For a fixed scaled energy displacement u, v473's universal E-carrier gives,
after discarding an asymptotically negligible low-frequency mass,

    S_{+u} = exp(+iu) S_0 + R_+,
    S_{-u} = exp(-iu) S_0 + R_-,

with

    |R_+|+|R_-| <= 2 eps_L W_0,

where eps_L->0 follows from the uniform carrier error
O(u (L Gamma_min)^(-1/3)) on an escaping high-frequency packet.

Choose

    U = n*pi + pi/4,

so |sin U|=|cos U|=1/sqrt(2).

If the off-critical additive phase projections on BOTH boundaries are bounded,

    |Im S_{+U}| <= C,
    |Im S_{-U}| <= C,

then elementary two-quadrature inversion gives

    |S_0|/W_0 <= 2 eps_L + 2 C/W_0.

After including a discarded low-frequency absolute-mass fraction tau_L,

    |S_0,total|/W_0,total
      <= 2 eps_L + O(tau_L) + 2C/W_0,total.

Thus simultaneous fixed-winding control on the two v470 boundaries forces
quantitative coherence collapse of the central escaping packet.

This is a reduction, not an exclusion of the collapsed packet.
"""
from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v492-two-boundary-quadrature-collapse"

def quadrature_bound(C:float, eps:float, W:float):
    if C<0 or eps<0 or W<=0:
        raise ValueError("need C>=0, eps>=0, W>0")
    # U=n*pi+pi/4 -> |sin U|=|cos U|=1/sqrt(2).
    # Each coordinate is <= sqrt(2)(C+eps W), hence modulus <=2(C+eps W).
    bound=2.0*eps+2.0*C/W
    return {
        "coherence_upper":bound,
        "formula":"|S0|/W0 <= 2 eps + 2 C/W0",
        "pass":bound>=0,
    }

def carrier_proxy(L:float,Gmin:float,U:float):
    if L<=0 or Gmin<=0:
        raise ValueError("L,Gmin positive")
    eps=abs(U)*(L*Gmin)**(-1.0/3.0)
    return {
        "L":L,"Gamma_min":Gmin,"U":U,
        "carrier_error_proxy":eps,
        "asymptotic":"O(U*(L*Gamma_min)^(-1/3))"
    }

def write(prefix:Path,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v492 — two-boundary quadrature / coherence-collapse reduction

Let `S_0(L)` denote the escaping off-critical complex saddle packet at the
center of a local collision cell and

`W_0(L)=sum_j |b_j(L)|`.

After removing a low-frequency absolute-mass fraction `tau_L`, v473's universal
energy carrier gives on the high packet, for fixed scaled displacement `u`,

`S_(+u)=e^(+iu) S_0 + R_+`,
`S_(-u)=e^(-iu) S_0 + R_-`,

with

`|R_+|, |R_-| <= eps_L W_0`

and, on a uniformly escaping packet,

`eps_L=O(|u|(L Gamma_min)^(-1/3)) -> 0`.

Choose

`U=n*pi+pi/4`.

Then

`|sin U|=|cos U|=1/sqrt(2)`.

Write `S_0=x+iy`.  Ignoring the controlled remainders,

`Im S_(+U)= sin(U)x + cos(U)y`,
`Im S_(-U)=-sin(U)x + cos(U)y`.

These are two independent quadratures.  If both off-critical boundary phase
projections are bounded,

`|Im S_(+U)| <= C`,
`|Im S_(-U)| <= C`,

then including the remainders gives

`|x| <= sqrt(2)(C+eps_L W_0)`,
`|y| <= sqrt(2)(C+eps_L W_0)`,

and therefore

`|S_0|/W_0 <= 2 eps_L + 2C/W_0`.

After restoring the discarded low-frequency packet,

`coherence_total
 <= 2 eps_L + O(tau_L) + 2C/W_0,total`.

In the genuinely nonattained sector, absolute-frequency escape allows a
diagonal `Gamma_min(L)->infinity` with `tau_L->0`.  The off-critical absolute
mass also has a growing unfactored baseline, so `C/W_0,total->0`.  Hence
simultaneous bounded **unwrapped** phase on the two boundaries forces

`|S_0|/W_0 -> 0`.

### Meaning for v491

v491 showed that a strict half-plane gap fixes the unwrapped winding class on
each boundary.  Once the already-closed/static channels are removed, this makes
the off-critical boundary projections bounded.  Therefore a successful v470
two-boundary barrier in the nonattained sector can occur only together with
quantitative collective coherence collapse.

This does **not** exclude that collapse.  It sharpens the final dichotomy:

1. boundary winding escapes / hits the bad half-integer set, so the v470
   half-plane barrier fails; or
2. both boundaries stay in fixed winding classes, which forces the central
   nonattained packet into the coherence-collapse regime.

**Verdict:** `TWO_BOUNDARY_QUADRATURE_FORCES_COHERENCE_COLLAPSE_REDUCTION_PASS`.

The carrier estimate uses the v473/v475 sectorial saddle asymptotic; a
publication proof still needs its already-identified uniform remainder
inequalities.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_TWO_BOUNDARY_QUADRATURE_COLLAPSE_V1",
        "closed":{
            "quadrature_choice":"U=n*pi+pi/4 gives |sin U|=|cos U|=1/sqrt(2)",
            "linear_algebra":"bounded Im S_+ and Im S_- implies |S0|/W0 <= 2 eps_L + 2C/W0",
            "carrier_error":"eps_L=O(U*(L Gamma_min)^(-1/3)) on uniformly escaping saddle packet",
            "low_frequency_diagonal":"absolute-frequency escape permits Gamma_min(L)->infinity with discarded mass fraction tau_L->0"
        },
        "remaining":{
            "collapsed_packet":
                "exclude the resulting coherence-collapse mechanism, or prove its moving-boundary generator has v419 subquadratic primitive",
            "uniform_saddle":
                "package the v473 E-carrier asymptotic as a uniform inequality on the chosen escaping packet"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--n",type=int,default=1)
    ap.add_argument("--C",type=float,default=1.0)
    ap.add_argument("--eps",type=float,default=1e-2)
    ap.add_argument("--W",type=float,default=1e4)
    ap.add_argument("--L",type=float,default=1e6)
    ap.add_argument("--Gamma-min",type=float,default=100.0)
    ap.add_argument("--prefix",default="rot_rh_two_boundary_quadrature_collapse_v492")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    U=args.n*math.pi+math.pi/4.0
    t0=time.perf_counter()
    with tqdm(total=3,desc="v492 quadrature",unit="step") as bar:
        trig=abs(abs(math.sin(U))-1/math.sqrt(2))<1e-14 and abs(abs(math.cos(U))-1/math.sqrt(2))<1e-14
        bar.update(1)
        qb=quadrature_bound(args.C,args.eps,args.W);bar.update(1)
        cp=carrier_proxy(args.L,args.Gamma_min,U);bar.update(1)
    ok=bool(trig and qb["pass"])
    verdict="TWO_BOUNDARY_QUADRATURE_FORCES_COHERENCE_COLLAPSE_REDUCTION_PASS" if ok else "FAILED"
    payload={
        "version":VERSION,
        "verdict":verdict,
        "runtime_seconds":time.perf_counter()-t0,
        "U":U,
        "trig_pass":trig,
        "quadrature":qb,
        "carrier_proxy":cp,
        "firewall":{
            "RH_assumed":False,
            "known_zero_ordinates_used":False,
            "numerical_zeta_used":False
        },
        "proof_status":
            "Exact two-projection linear algebra combined with the v473/v475 carrier asymptotic. "
            "Coherence-collapse exclusion remains open."
    }
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    print("U:",U)
    print("coherence upper demo:",qb["coherence_upper"])
    print("carrier error proxy:",cp["carrier_error_proxy"])
    print("summary:",s)
    print("theorem:",t)
    print("certificate:",c)
    if args.strict and not ok:
        raise SystemExit(2)

if __name__=="__main__":
    main()
