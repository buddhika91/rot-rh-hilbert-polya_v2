#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v432 — COMPLEX DYADIC FORCING / LAPLACE-POLE RH-EQUIVALENCE
===================================================================

Purpose
-------
v431 reduced the OLD-HISTORY carrier to a local dyadic forcing

    J_L^sin(E)
      = int_L^(L+h)
          A(u) d/du[e^(-u/2) sin(Eu)] du,
      h=log 2,

and found the local centered Mangoldt shell to be the dominant finite
mechanism.

The pointwise bound |J_L^sin|=O(1) is sufficient but stronger than needed
for the v431 renewal.  Before attempting to prove it, v432 asks a more
fundamental question:

    What theorem class is local dyadic forcing boundedness?

Define the COMPLEX forcing at fixed real E

    s_E = 1/2 + i E,
    G_E(u)=exp(-s_E u),

    J_L^C(E)
      := int_L^(L+h) A(u) G'_E(u) du
       = -s_E int_L^(L+h) A(u)e^(-s_E u) du.

Since

    Im G'_E(u)
      = -d/du[e^(-u/2)sin(Eu)],

we have exactly

    J_L^sin(E) = -Im J_L^C(E).

Prime-side exact identity
-------------------------
Let

    C_L^C(E)
      := int_(log2)^L e^(-s_E u) dDelta_psi(u)

       = sum_(n<e^L) Lambda(n)n^(-s_E)
         - int_(log2)^L e^((1-s_E)u)du.

Then on any late dyadic shell [L,L+h],

    J_L^C(E)
      = A(L+h)e^(-s_E(L+h))
        - A(L)e^(-s_E L)
        - [C_(L+h)^C(E)-C_L^C(E)].

The last bracket contains ONLY X<=n<2X plus its smooth PNT integral.

Classical explicit-formula reduction
------------------------------------
Using the standard explicit formula for Chebyshev psi (with the usual
symmetric/half-weight convention at jumps),

    A(u)
      = B(u) - sum_rho e^(rho u)/rho,

where B(u) is the explicit elementary/trivial-zero background.

For one nontrivial zero rho, its contribution to J_L^C(E) is

    J_(rho,L)^C(E)
      = c_rho(E) exp[(rho-s_E)L],

where

    c_rho(E)
      = (s_E/rho) W_h(rho-s_E),

    W_h(a)
      = (exp(h a)-1)/a,
    W_h(0)=h.

For Re(rho-s_E)>0,

    W_h(rho-s_E) != 0

because |exp(h(rho-s_E))|>1.

Also, for |gamma| large and fixed E,

    |c_rho(E)| = O_E(1/gamma^2).

Since N(T)=O(T log T),

    sum_rho |c_rho(E)| < infinity.

Laplace-pole theorem
--------------------
Assume J_L^C(E) is bounded for all sufficiently large L.

Then its Laplace transform

    L[J](z)=int_(L0)^infinity e^(-zL)J_L^C(E)dL

is analytic for Re z>0.

For Re z greater than sup_rho(Re rho-1/2), termwise integration of the
absolutely convergent zero expansion gives

    L[J](z)
      = analytic_background(z)
        + sum_rho
            c_rho(E)
            exp[-(z-(rho-s_E))L0]
            / [z-(rho-s_E)].

The meromorphic zero sum has a pole at

    z=rho-s_E

for every zero with Re rho>1/2, and its residue is nonzero.
Normal convergence away from the poles gives its meromorphic continuation.

But the Laplace transform of a bounded forcing is analytic throughout
Re z>0.  Hence no such pole can exist:

    Re rho <= 1/2 for every nontrivial zero.

The functional equation gives symmetry rho <-> 1-rho, so

    Re rho = 1/2

for every nontrivial zero: RH.

Conversely, under RH every rho-s_E is purely imaginary and the
O(1/gamma^2) coefficients are absolutely summable, so the zero contribution
to J_L^C is uniformly bounded in L; the elementary/trivial-zero background
is also bounded.  Thus

    RH  <=>  J_L^C(E) is bounded in L

for any fixed real E, under the classical explicit-formula framework.

IMPORTANT
---------
v432 does NOT prove that J_L^C is bounded.  It proves/reduces the theorem
class: a proof of uniform complex local-forcing boundedness is already an
RH proof.

Therefore the next non-circular Hilbert-Polya step must obtain this
boundedness from an INDEPENDENT operator property (e.g. a cutoff-independent
self-adjoint/contractive transfer structure), not from an RH-equivalent
prime-discrepancy estimate.

Scientific firewall
-------------------
The numerical audit uses NO Xi, NO zeta values, NO known zero ordinates.
The analytic theorem invokes the classical explicit formula only as a
proved background theorem; it does not numerically evaluate zeros.

Version: 432
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 432
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def sha256_file(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists():
        return None
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (np.complexfloating,)):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, Path):
        return str(x)
    raise TypeError(type(x).__name__)


def call_trig_sum(
    base,
    energies: np.ndarray,
    logs: np.ndarray,
    weights: np.ndarray,
    trig: str,
    *,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}

    try:
        return np.asarray(
            fn(energies, logs, weights, trig, **kwargs),
            float,
        )
    except TypeError:
        return np.asarray(
            fn(energies, logs, weights, trig),
            float,
        )


def support_count(logs: np.ndarray, L: float) -> int:
    return int(
        np.searchsorted(
            logs,
            float(L)-1.0e-14,
            side="left",
        )
    )


# -----------------------------------------------------------------------------
# Symbolic theorem checks
# -----------------------------------------------------------------------------

def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    u, E, L, h = sp.symbols(
        "u E L h",
        real=True,
        positive=True,
    )
    s = sp.Rational(1, 2) + sp.I*E
    G = sp.exp(-s*u)
    Gp = sp.diff(G, u)

    gsin = sp.exp(-u/2)*sp.sin(E*u)
    relation = sp.simplify(
        sp.im(sp.expand_complex(Gp)) + sp.diff(gsin, u)
    )

    rho = sp.symbols("rho")
    a = sp.symbols("a")
    W = (sp.exp(h*a)-1)/a
    zero_integral = sp.simplify(
        (s/rho)
        * sp.integrate(
            sp.exp((rho-s)*u),
            (u, L, L+h),
        )
    )
    expected = sp.simplify(
        (s/rho)
        * sp.exp((rho-s)*L)
        * (
            sp.exp((rho-s)*h)-1
        )
        /(rho-s)
    )
    zero_resid = sp.simplify(zero_integral-expected)

    W0 = sp.limit(W, a, 0)

    z, lam, c, L0, R = sp.symbols(
        "z lam c L0 R"
    )
    # Avoid asking SymPy to infer a generic complex half-plane condition.
    # Verify the finite-interval antiderivative exactly; the R->infinity
    # limit is then the standard elementary implication under
    # Re(z-lam)>0.
    lap_finite = sp.simplify(
        c
        * (
            sp.exp(-(z-lam)*L0)
            - sp.exp(-(z-lam)*R)
        )
        /(z-lam)
    )
    lap_antiderivative = sp.simplify(
        -c*sp.exp(-(z-lam)*L)/(z-lam)
    )
    lap_finite_from_F = sp.simplify(
        lap_antiderivative.subs(L, R)
        - lap_antiderivative.subs(L, L0)
    )
    lap_resid = sp.simplify(
        lap_finite_from_F-lap_finite
    )
    expected_lap = (
        c*sp.exp(-(z-lam)*L0)/(z-lam)
    )

    return {
        "imaginary_part_relation_residual": str(relation),
        "zero_kernel_residual": str(zero_resid),
        "W_h_at_zero": str(W0),
        "laplace_finite_interval_residual": str(lap_resid),
        "laplace_half_plane_limit": (
            "Re(z-lambda)>0 => exp(-(z-lambda)R)->0, "
            "hence integral_[L0,infinity)=c exp(-(z-lambda)L0)/(z-lambda)"
        ),
        "zero_coefficient": (
            "c_rho(E)=(s_E/rho) W_h(rho-s_E)"
        ),
        "pole_location": "z=rho-s_E",
        "positive_delta_nonvanishing": (
            "Re(rho-s_E)>0 => |exp(h(rho-s_E))|>1 "
            "=> W_h(rho-s_E)!=0"
        ),
        "pass": bool(
            relation == 0
            and zero_resid == 0
            and W0 == h
            and lap_resid == 0
        ),
    }


# -----------------------------------------------------------------------------
# Prime-side complex forcing
# -----------------------------------------------------------------------------

def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)
    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]
    lambda_w = logs/exponents
    lambda_cumsum = np.cumsum(lambda_w, dtype=np.float64)
    return primes, logs, exponents, lambda_w, lambda_cumsum


def psi_minus(
    logs: np.ndarray,
    lambda_cumsum: np.ndarray,
    L: float,
) -> float:
    k = support_count(logs, L)
    return (
        float(lambda_cumsum[k-1])
        if k > 0
        else 0.0
    )


def A_of_L(
    logs: np.ndarray,
    lambda_cumsum: np.ndarray,
    L: float,
) -> float:
    return (
        psi_minus(logs, lambda_cumsum, L)
        - LOG2
        - (math.exp(L)-2.0)
    )


def complex_smooth_shell(
    E: np.ndarray,
    L0: float,
    L1: float,
) -> np.ndarray:
    """
    Integral_L0^L1 exp((1-s_E)u) du,
    s_E=1/2+iE.
    """
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5-1j*E
    return (
        np.exp(a*L1)-np.exp(a*L0)
    )/a


def complex_prime_shell(
    *,
    base,
    logs: np.ndarray,
    lambda_w: np.ndarray,
    L0: float,
    L1: float,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    k0 = support_count(logs, L0)
    k1 = support_count(logs, L1)
    l = logs[k0:k1]
    lam = lambda_w[k0:k1]

    # n^{-1/2-iE}=e^{-log n/2}[cos(Elogn)-i sin(Elogn)]
    amp = lam*np.exp(-0.5*l)
    cos_part = call_trig_sum(
        base,
        E,
        l,
        amp,
        "cos",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    sin_part = call_trig_sum(
        base,
        E,
        l,
        amp,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    return cos_part-1j*sin_part


def complex_local_forcing(
    *,
    base,
    logs: np.ndarray,
    lambda_w: np.ndarray,
    lambda_cumsum: np.ndarray,
    X0: int,
    X1: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> Dict[str, np.ndarray]:
    L0 = math.log(float(X0))
    L1 = math.log(float(X1))
    s = 0.5+1j*np.asarray(E, float)

    A0 = A_of_L(logs, lambda_cumsum, L0)
    A1 = A_of_L(logs, lambda_cumsum, L1)

    G0 = np.exp(-s*L0)
    G1 = np.exp(-s*L1)

    prime_shell = complex_prime_shell(
        base=base,
        logs=logs,
        lambda_w=lambda_w,
        L0=L0,
        L1=L1,
        E=E,
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    smooth_shell = complex_smooth_shell(
        E, L0, L1
    )
    deltaC = prime_shell-smooth_shell

    endpoint = A1*G1-A0*G0
    Jc = endpoint-deltaC

    return {
        "J_complex": Jc,
        "endpoint_complex": endpoint,
        "deltaC_complex": deltaC,
        "A0": np.full(len(E), A0, float),
        "A1": np.full(len(E), A1, float),
        "prime_shell_complex": prime_shell,
        "smooth_shell_complex": smooth_shell,
    }


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v431-points",
        default="rot_rh_old_history_dyadic_renewal_local_forcing_v431_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v431-summary",
        default="rot_rh_old_history_dyadic_renewal_local_forcing_v431_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--energy-chunk", type=int, default=6)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument(
        "--maximum-imaginary-reconstruction",
        type=float,
        default=2.0e-9,
    )
    ap.add_argument(
        "--maximum-A-reconstruction",
        type=float,
        default=2.0e-6,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_complex_dyadic_forcing_laplace_pole_v432",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    v431 = load_json(args.v431_summary)
    v431_ok = bool(
        v431 is not None
        and v431.get("verdict")
        == "EXACT_OLD_HISTORY_DYADIC_RENEWAL_LOCAL_FORCING_REDUCTION_PASS"
    )

    print("="*232)
    print("ROT-RH v432 — COMPLEX DYADIC FORCING / LAPLACE-POLE RH-EQUIVALENCE")
    print("="*232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed in numerical audit             : NO")
    print("new roots / larger cutoffs                 : NONE")
    print("classical explicit formula used analytically: YES")
    print("bounded forcing assumed                    : NO")
    print("="*232)

    print("[1] Upstream")
    print(
        "v431 exact local-forcing reduction       :",
        v431_ok,
        None if v431 is None else v431.get("verdict"),
    )

    print("\n[2] Exact complex forcing algebra")
    sym = symbolic_checks()
    print("symbolic identities pass                  :", sym.get("pass"))
    print("zero coefficient                          :", sym.get("zero_coefficient"))
    print("Laplace pole                              :", sym.get("pole_location"))
    print(
        "positive-delta residue nonzero            :",
        sym.get("positive_delta_nonvanishing"),
    )
    if not sym.get("pass") and args.strict:
        return 2

    p = Path(args.v431_points)
    if not p.exists():
        raise FileNotFoundError(p)
    df = pd.read_csv(p)
    required = {
        "set", "shell_index", "X0", "X1", "L0", "L1",
        "root_index", "tube_coordinate", "E_fixed",
        "A0_reconstructed", "A1_reconstructed", "J_total",
    }
    missing = sorted(required-set(df.columns))
    if missing:
        raise KeyError(f"v431 points missing columns: {missing}")

    max_X1 = int(df["X1"].max())
    base = importlib.import_module(args.v71_module)

    print("\n[3] Prime-side zero-free complex forcing")
    t0 = time.time()
    (
        primes, logs, exponents, lambda_w, lambda_cumsum
    ) = build_cache(base, max_X1)
    print("maximum reused cutoff                    :", f"{max_X1:,}")
    print("primes                                   :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    parts = []
    max_imag_resid = 0.0
    max_A_resid = 0.0

    groups = list(
        df.groupby(
            ["set","shell_index","X0","X1","L0","L1"],
            sort=True,
            dropna=False,
        )
    )
    bar = tqdm(
        total=len(groups),
        desc="complex dyadic forcing",
        unit="shell",
    )

    for key, g in groups:
        setname, shell_index, X0, X1, L0, L1 = key
        gg = g.copy().reset_index(drop=True)
        E = gg["E_fixed"].to_numpy(float)

        res = complex_local_forcing(
            base=base,
            logs=logs,
            lambda_w=lambda_w,
            lambda_cumsum=lambda_cumsum,
            X0=int(X0),
            X1=int(X1),
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        Jc = res["J_complex"]
        Jsin = gg["J_total"].to_numpy(float)

        # Exact relation J_sin = -Im J_complex.
        imag_resid = np.abs(
            Jsin + np.imag(Jc)
        )
        max_imag_resid = max(
            max_imag_resid,
            float(np.max(imag_resid)),
        )

        A0_old = gg["A0_reconstructed"].to_numpy(float)
        A1_old = gg["A1_reconstructed"].to_numpy(float)
        Ares = np.maximum(
            np.abs(A0_old-res["A0"]),
            np.abs(A1_old-res["A1"]),
        )
        max_A_resid = max(
            max_A_resid,
            float(np.max(Ares)),
        )

        gg["J_complex_real"] = np.real(Jc)
        gg["J_complex_imag"] = np.imag(Jc)
        gg["J_complex_abs"] = np.abs(Jc)
        gg["minus_imag_J_complex"] = -np.imag(Jc)
        gg["sin_forcing_reconstruction_abs"] = imag_resid
        gg["endpoint_complex_real"] = np.real(res["endpoint_complex"])
        gg["endpoint_complex_imag"] = np.imag(res["endpoint_complex"])
        gg["deltaC_complex_real"] = np.real(res["deltaC_complex"])
        gg["deltaC_complex_imag"] = np.imag(res["deltaC_complex"])
        gg["prime_shell_complex_abs"] = np.abs(res["prime_shell_complex"])
        gg["smooth_shell_complex_abs"] = np.abs(res["smooth_shell_complex"])
        parts.append(gg)
        bar.update(1)

    bar.close()
    out = pd.concat(parts, ignore_index=True)

    reconstruction_pass = bool(
        max_imag_resid <= args.maximum_imaginary_reconstruction
        and max_A_resid <= args.maximum_A_reconstruction
    )

    print("\n[4] Complex/real forcing reconstruction")
    print(
        "maximum |-Im J_complex - J_sin|          :",
        f"{max_imag_resid:.12e}",
    )
    print(
        "maximum A endpoint reconstruction         :",
        f"{max_A_resid:.12e}",
    )
    print(
        "prime-side complex forcing pass           :",
        reconstruction_pass,
    )

    shell_rows = []
    for key, g in out.groupby(
        ["set","shell_index","X0","X1"],
        sort=True,
        dropna=False,
    ):
        setname, shell_index, X0, X1 = key
        shell_rows.append({
            "set": str(setname),
            "shell_index": int(shell_index),
            "X0": int(X0),
            "X1": int(X1),
            "max_abs_J_complex": float(g["J_complex_abs"].max()),
            "max_abs_Re_J_complex": float(
                np.max(np.abs(g["J_complex_real"].to_numpy(float)))
            ),
            "max_abs_Im_J_complex": float(
                np.max(np.abs(g["J_complex_imag"].to_numpy(float)))
            ),
            "max_abs_J_sin": float(
                np.max(np.abs(g["J_total"].to_numpy(float)))
            ),
        })
    shell_df = pd.DataFrame(shell_rows).sort_values(
        ["X0","shell_index"]
    )

    print("\nFinite complex forcing summary (EVIDENCE ONLY):")
    print(
        shell_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    exact_pass = bool(
        sym.get("pass")
        and v431_ok
        and reconstruction_pass
    )

    verdict = (
        "EXACT_COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_PASS"
        if exact_pass
        else
        "COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_INCOMPLETE"
    )

    theorem_class = (
        "UNIFORM_BOUNDED_COMPLEX_DYADIC_FORCING_IS_RH_EQUIVALENT"
        if exact_pass
        else
        "NOT_CERTIFIED"
    )
    next_theorem = (
        "DERIVE_COMPLEX_DYADIC_FORCING_BOUNDEDNESS_FROM_INDEPENDENT_SELF_ADJOINT_OPERATOR_STRUCTURE"
    )

    print("\n" + "="*232)
    print("VERDICT                                   :", verdict)
    print("THEOREM CLASS                             :", theorem_class)
    print(
        "BOUND |J_complex| PROVED                  :",
        "NO",
    )
    print(
        "NUMBER-THEORY ROUTE STATUS                :",
        "RH-EQUIVALENT CORE REACHED",
    )
    print(
        "HILBERT-POLYA ROUTE REQUIRED              :",
        "YES — obtain bound from independent operator structure",
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*232)

    prefix = Path(args.prefix)
    points_out = Path(str(prefix)+"_POINTS.csv.gz")
    shell_out = Path(str(prefix)+"_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix)+"_SUMMARY.json")
    theorem_out = Path(str(prefix)+"_THEOREM.md")
    cert_out = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    out.to_csv(points_out, index=False, compression="gzip")
    shell_df.to_csv(shell_out, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used_numerically": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed_numerically": False,
            "new_root_solves": False,
            "larger_cutoff": False,
        },
        "upstream": {
            "v431_ok": v431_ok,
            "v431_verdict": None if v431 is None else v431.get("verdict"),
        },
        "exact_symbolic_checks": sym,
        "prime_side_reconstruction": {
            "maximum_imaginary_relation_residual": max_imag_resid,
            "maximum_A_endpoint_residual": max_A_resid,
            "pass": reconstruction_pass,
        },
        "analytic_theorem": {
            "classical_input": [
                "Chebyshev psi explicit formula over nontrivial zeros",
                "zero-counting N(T)=O(T log T)",
                "functional-equation symmetry rho <-> 1-rho",
            ],
            "complex_forcing": (
                "J_L^C(E)=int_L^(L+log2) A(u) d/du[e^{-(1/2+iE)u}] du"
            ),
            "zero_term": (
                "c_rho(E)e^{(rho-s_E)L}, "
                "c_rho=(s_E/rho)(e^{h(rho-s_E)}-1)/(rho-s_E)"
            ),
            "coefficient_summability_on_RH": (
                "|c_rho(E)|=O_E(gamma^-2), hence absolute summability"
            ),
            "boundedness_implies_RH": (
                "bounded J gives Laplace transform analytic for Re z>0; "
                "any beta>1/2 creates a nonzero pole at z=rho-s_E"
            ),
            "RH_implies_boundedness": (
                "on RH all exponents are purely imaginary and coefficients "
                "are absolutely summable; elementary background is bounded"
            ),
            "equivalence": theorem_class,
            "boundedness_proved_here": False,
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_out.write_text(
        json.dumps(payload, indent=2, default=json_safe),
        encoding="utf-8",
    )

    theorem_text = r"""# ROT-RH v432 — complex dyadic forcing / Laplace-pole theorem

Fix real `E` and let

`s_E=1/2+iE`.

Define

`J_L^C(E)
 =int_L^(L+h) A(u) d/du[e^(-s_E u)] du`,
`h=log 2`.

Then

`J_L^sin(E)=-Im J_L^C(E)`,

so the v431 sine forcing is one component of the complex forcing.

Using the classical explicit formula

`A(u)=B(u)-sum_rho e^(rho u)/rho`,

the nontrivial-zero contribution is

`J_L^C(E)
 =B_E(L)
  +sum_rho c_rho(E)e^((rho-s_E)L)`,

where

`c_rho(E)
 =(s_E/rho) W_h(rho-s_E)`,

`W_h(a)=(e^(ha)-1)/a`, `W_h(0)=h`.

For fixed E,

`|c_rho(E)|=O_E(|gamma|^-2)`,

and the zero-counting estimate `N(T)=O(T log T)` gives absolute coefficient
summability.

If RH holds, `Re(rho-s_E)=0` for every nontrivial zero, hence the zero sum
is uniformly bounded in L; the elementary/trivial-zero background is also
bounded.

Conversely, suppose `J_L^C(E)` is bounded for all sufficiently large L.
Its Laplace transform is analytic on `Re z>0`.

For `Re z` initially to the right of all zero exponents,

`Laplace[J](z)
 =analytic_background
  +sum_rho
    c_rho(E)e^(-(z-(rho-s_E))L0)
    /(z-(rho-s_E))`.

The series is normally convergent away from its poles.  If any zero has
`beta>1/2`, then `z=rho-s_E` lies in `Re z>0`.

Its residue is nonzero: when `delta=beta-1/2>0`,

`|e^(h(rho-s_E))|=e^(h delta)>1`,

so `W_h(rho-s_E)!=0`.

This contradicts analyticity of the Laplace transform on `Re z>0`.
Therefore every zero satisfies `beta<=1/2`.  Functional-equation symmetry
about the critical line then forces every nontrivial zero to satisfy

`beta=1/2`.

Thus, within the standard explicit-formula framework,

`RH <=> J_L^C(E) is uniformly bounded in L`

for any fixed real E.

v432 does NOT prove the boundedness.  It identifies the theorem class.
A non-circular Hilbert-Polya proof must now derive bounded complex dyadic
forcing from an independent operator property rather than assume or reprove
an equivalent prime-discrepancy statement.
"""
    theorem_out.write_text(theorem_text, encoding="utf-8")

    cert = {
        "schema": "ROT_RH_OPERATOR_TO_COMPLEX_FORCING_CERTIFICATE_V1",
        "already_proved_reduction": theorem_class,
        "required_independent_operator_claim": {
            "proved": False,
            "statement": (
                "Derive sup_L |J_L^C(E)|<infinity for each fixed real E "
                "from an operator property established without RH, Xi fitting, "
                "known zero ordinates, or an RH-equivalent prime error estimate."
            ),
        },
        "acceptable_operator_sources": [
            "cutoff-independent self-adjoint resolvent bound",
            "unitary/contractive transfer theorem for the full centered system",
            "uniform operator-norm or strong-resolvent cutoff convergence implying the forcing bound",
        ],
        "forbidden_circular_sources": [
            "assume RH",
            "assume psi(x)=x+O(x^(1/2+epsilon))",
            "assume bounded complex dyadic forcing",
            "known zero ordinates",
            "Xi fitting",
        ],
        "consequence": (
            "operator-derived bounded complex forcing + v432 Laplace-pole theorem => RH"
        ),
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_out)
    print(" ", shell_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
