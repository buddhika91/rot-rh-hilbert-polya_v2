#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v400 — PROSPECTIVE REGULAR-JET SHAPE ENVELOPE / SINGLE-AMPLITUDE REDUCTION
================================================================================

Purpose
-------
Use ONLY already-frozen v398 constants plus fresh v399 output.

v398 froze four constants before v399:

    C_0, C_1, C_2, C_3.

Define the frozen shape ratios

    rho_m = C_m / C_0,
    rho_0 = 1.

If the fresh v399 rows satisfy

    Q_m / Q_0 <= rho_m,    m=1,2,3,

then the derivative-jet SHAPE survived prospectively even if the old scalar
amplitude ceiling Q_0<=C_0 failed.

In that case,

    Q_m <= rho_m A,
    A := Q_0,

and the regular four-jet matrix satisfies

    q_reg <= H A,

where

    H = max_(0<=r<=3)
          sum_(m=0)^r binom(r,m) rho_m.

Thus a SINGLE scalar amplitude condition

    A < A_crit := 1/H

is sufficient for strict regular-jet contraction.

This script also combines the old v398 DETAIL rows and fresh v399 DETAIL rows
to diagnose the scale and energy behavior of A=Q0.  Those diagnostics are NOT
accepted as proof and are never used to change the frozen rho_m.

Scientific firewall
-------------------
NO Xi.
NO zeta numerical evaluations.
NO known-zero ordinates.
NO refit of frozen shape ratios from v399.
No regression is accepted as proof.

Version: 400
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 400


def induced_shape_rows(rho):
    rows = []
    for r in range(4):
        val = 0.0
        for m in range(r + 1):
            val += math.comb(r, m) * rho[m]
        rows.append(val)
    return np.asarray(rows, dtype=float)


def safe_log_ratio(y2, y1, x2, x1):
    if min(y1, y2, x1, x2) <= 0:
        return float("nan")
    den = math.log(x2 / x1)
    if abs(den) < 1e-300:
        return float("nan")
    return math.log(y2 / y1) / den


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v398-summary",
        default="rot_rh_regular_jet_scalar_envelope_v398_SUMMARY.json",
    )
    ap.add_argument(
        "--v398-detail",
        default="rot_rh_regular_jet_scalar_envelope_v398_DETAIL.csv",
    )
    ap.add_argument(
        "--v399-summary",
        default="rot_rh_fresh_regular_jet_holdout_v399_SUMMARY.json",
    )
    ap.add_argument(
        "--v399-detail",
        default="rot_rh_fresh_regular_jet_holdout_v399_DETAIL.csv",
    )
    ap.add_argument(
        "--shape-tol",
        type=float,
        default=1e-12,
    )
    ap.add_argument(
        "--contraction-gate",
        type=float,
        default=1.0,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_regular_jet_shape_amplitude_v400",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()

    p398s = Path(args.v398_summary)
    p399s = Path(args.v399_summary)
    p399d = Path(args.v399_detail)

    if not p398s.exists():
        raise FileNotFoundError(p398s)
    if not p399s.exists():
        raise FileNotFoundError(p399s)
    if not p399d.exists():
        raise FileNotFoundError(p399d)

    v398 = json.loads(p398s.read_text(encoding="utf-8"))
    v399 = json.loads(p399s.read_text(encoding="utf-8"))
    fresh = pd.read_csv(p399d)

    C = np.asarray(
        v398["all_panel_empirical"]["C_all_safe"],
        dtype=float,
    )
    if C.shape != (4,) or not np.all(np.isfinite(C)) or C[0] <= 0:
        raise RuntimeError("Invalid frozen v398 C_m.")

    rho = C / C[0]
    shape_rows = induced_shape_rows(rho)
    H = float(np.max(shape_rows))
    Acrit = float(args.contraction_gate / H)

    required = {
        "Q0", "Q1", "Q2", "Q3",
        "q_raw_inf",
        "depth", "lambda",
        "energy_offset_fraction",
        "output_M", "region",
    }
    missing = sorted(required - set(fresh.columns))
    if missing:
        raise KeyError(f"v399 DETAIL missing columns: {missing}")

    print("=" * 222)
    print("ROT-RH v400 — PROSPECTIVE REGULAR-JET SHAPE ENVELOPE / SINGLE-AMPLITUDE REDUCTION")
    print("=" * 222)
    print("Xi / zeta / known-zero data             : NONE")
    print("fresh v399 data used to refit shape     : NO")
    print("v398 verdict                             :", v398.get("verdict"))
    print("v399 verdict                             :", v399.get("verdict"))
    print("frozen C_m                               :", [float(x) for x in C])
    print("frozen rho_m=C_m/C_0                    :", [float(x) for x in rho])
    print("shape induced rows                      :", [float(x) for x in shape_rows])
    print("H=max shape row sum                     :", f"{H:.15e}")
    print("single-amplitude critical A=1/H         :", f"{Acrit:.15e}")
    print("=" * 222)

    # ------------------------------------------------------------------
    # 1. Prospective fresh shape test
    # ------------------------------------------------------------------
    print("[1] Prospective fresh shape-envelope test")

    for m in tqdm(range(4), desc="shape ratios", unit="jet"):
        fresh[f"R{m}"] = (
            fresh[f"Q{m}"].to_numpy(float)
            / np.maximum(fresh["Q0"].to_numpy(float), 1e-300)
        )
        fresh[f"R{m}_over_rho"] = (
            fresh[f"R{m}"].to_numpy(float)
            / max(float(rho[m]), 1e-300)
        )

    max_shape_ratio = np.asarray(
        [
            float(fresh[f"R{m}_over_rho"].max())
            for m in range(4)
        ],
        dtype=float,
    )

    shape_pass = bool(
        np.all(max_shape_ratio <= 1.0 + abs(args.shape_tol))
    )

    print("max fresh (Q_m/Q0)/rho_m                :", [float(x) for x in max_shape_ratio])
    print("prospective frozen shape pass            :", shape_pass)

    print("\nWorst fresh shape rows:")
    worst_shape = []
    for m in range(1, 4):
        idx = int(fresh[f"R{m}_over_rho"].idxmax())
        rr = fresh.loc[idx]
        item = {
            "jet": m,
            "R_m": float(rr[f"R{m}"]),
            "rho_m": float(rho[m]),
            "ratio_to_frozen_shape": float(rr[f"R{m}_over_rho"]),
            "depth": int(rr["depth"]),
            "lambda": float(rr["lambda"]),
            "energy_offset_fraction": float(rr["energy_offset_fraction"]),
            "output_M": int(rr["output_M"]),
            "region": str(rr["region"]),
        }
        worst_shape.append(item)
        print(
            f"m={m}  "
            f"R_m={item['R_m']:.12e}  "
            f"rho={item['rho_m']:.12e}  "
            f"R/rho={item['ratio_to_frozen_shape']:.9f}  "
            f"depth={item['depth']}  "
            f"lambda={item['lambda']:g}  "
            f"Eoff={item['energy_offset_fraction']:+.3f}  "
            f"M={item['output_M']:,}"
        )

    # ------------------------------------------------------------------
    # 2. Single-amplitude contraction
    # ------------------------------------------------------------------
    print("\n[2] Single-amplitude contraction reduction")

    A_fresh_max = float(fresh["Q0"].max())
    q_shape_bound = float(H * A_fresh_max)
    max_actual_q = float(fresh["q_raw_inf"].max())
    amplitude_margin_factor = float(Acrit / A_fresh_max)

    amplitude_current_pass = bool(
        A_fresh_max < Acrit
    )

    print("fresh A_max=max Q0                      :", f"{A_fresh_max:.15e}")
    print("shape-derived q bound H*A_max           :", f"{q_shape_bound:.15e}")
    print("maximum actual fresh q_raw              :", f"{max_actual_q:.15e}")
    print("critical amplitude Acrit                :", f"{Acrit:.15e}")
    print("Acrit / fresh A_max                     :", f"{amplitude_margin_factor:.9f}")
    print("fresh amplitude below contraction limit  :", amplitude_current_pass)

    q_bound_dominates_actual = bool(
        max_actual_q <= q_shape_bound + 1e-12
    )
    print("shape q bound dominates actual fresh q   :", q_bound_dominates_actual)

    # ------------------------------------------------------------------
    # 3. Energy dependence of A=Q0 on fresh cells
    # ------------------------------------------------------------------
    print("\n[3] Fresh energy dependence of A=Q0")

    energy_rows = []
    group_cols = ["depth", "lambda", "output_M"]
    for keys, z in fresh.groupby(group_cols):
        z = z.sort_values("energy_offset_fraction")
        central = z[
            np.abs(z["energy_offset_fraction"].to_numpy(float)) <= 1e-15
        ]
        if len(central) != 1:
            continue
        A0 = float(central["Q0"].iloc[0])
        for _, rr in z.iterrows():
            item = {
                "depth": int(keys[0]),
                "lambda": float(keys[1]),
                "output_M": int(keys[2]),
                "energy_offset_fraction": float(rr["energy_offset_fraction"]),
                "Q0": float(rr["Q0"]),
                "Q0_over_central": float(rr["Q0"]) / max(A0, 1e-300),
            }
            energy_rows.append(item)

    energy_df = pd.DataFrame(energy_rows)

    if len(energy_df):
        for off, z in energy_df.groupby("energy_offset_fraction"):
            print(
                f"Eoff={float(off):+.3f}  "
                f"max Q0/central={float(z['Q0_over_central'].max()):.9f}  "
                f"min Q0/central={float(z['Q0_over_central'].min()):.9f}"
            )

    # ------------------------------------------------------------------
    # 4. Historical + fresh central depth-0 scale law diagnostics
    # ------------------------------------------------------------------
    print("\n[4] Central-E depth-0 amplitude scale diagnostics")

    scale_rows = []
    p398d = Path(args.v398_detail)

    frames = []

    if p398d.exists():
        old = pd.read_csv(p398d)
        old["source"] = "v398_historical"
        frames.append(old)

    f2 = fresh.copy()
    f2["source"] = "v399_fresh"
    frames.append(f2)

    combined = pd.concat(frames, ignore_index=True, sort=False)

    needed_scale = {
        "depth", "lambda", "output_M",
        "energy_offset_fraction", "Q0",
    }

    if needed_scale.issubset(combined.columns):
        z = combined[
            (combined["depth"].astype(int) == 0)
            & (
                np.abs(
                    combined["energy_offset_fraction"].to_numpy(float)
                ) <= 1e-15
            )
        ].copy()

        # Deduplicate same M: prefer fresh row if repeated.
        z["source_rank"] = (
            z["source"].astype(str) == "v399_fresh"
        ).astype(int)

        z = (
            z.sort_values(["output_M", "source_rank"])
             .drop_duplicates("output_M", keep="last")
             .sort_values("output_M")
             .reset_index(drop=True)
        )

        for i in range(len(z)):
            rr = z.iloc[i]
            item = {
                "index": i,
                "source": str(rr["source"]),
                "lambda": float(rr["lambda"]),
                "M": int(rr["output_M"]),
                "logM": math.log(float(rr["output_M"])),
                "Q0": float(rr["Q0"]),
                "local_power_lambda": float("nan"),
                "local_power_M": float("nan"),
                "local_log_power": float("nan"),
                "Q0_ratio_prev": float("nan"),
            }

            if i > 0:
                prev = z.iloc[i - 1]

                item["Q0_ratio_prev"] = (
                    float(rr["Q0"]) / float(prev["Q0"])
                )

                item["local_power_lambda"] = safe_log_ratio(
                    float(rr["Q0"]),
                    float(prev["Q0"]),
                    float(rr["lambda"]),
                    float(prev["lambda"]),
                )

                item["local_power_M"] = safe_log_ratio(
                    float(rr["Q0"]),
                    float(prev["Q0"]),
                    float(rr["output_M"]),
                    float(prev["output_M"]),
                )

                logM2 = math.log(float(rr["output_M"]))
                logM1 = math.log(float(prev["output_M"]))

                item["local_log_power"] = safe_log_ratio(
                    float(rr["Q0"]),
                    float(prev["Q0"]),
                    logM2,
                    logM1,
                )

            scale_rows.append(item)

        for item in scale_rows:
            print(
                f"M={item['M']:>10,d}  "
                f"lambda={item['lambda']:>8g}  "
                f"Q0={item['Q0']:.12e}  "
                f"ratio={item['Q0_ratio_prev']:.6f}  "
                f"alpha_M={item['local_power_M']:.6f}  "
                f"p_log={item['local_log_power']:.6f}  "
                f"{item['source']}"
            )
    else:
        print("Required columns unavailable; scale diagnostic skipped.")

    scale_df = pd.DataFrame(scale_rows)

    # ------------------------------------------------------------------
    # 5. Geometry/depth comparison at same fresh M
    # ------------------------------------------------------------------
    print("\n[5] Fresh geometry comparison at central E")

    geometry_rows = []
    central_fresh = fresh[
        np.abs(
            fresh["energy_offset_fraction"].to_numpy(float)
        ) <= 1e-15
    ].copy()

    for M, z in central_fresh.groupby("output_M"):
        base = z[z["depth"].astype(int) == 0]
        if len(base) != 1:
            continue
        qbase = float(base["Q0"].iloc[0])

        for _, rr in z.sort_values("depth").iterrows():
            item = {
                "output_M": int(M),
                "depth": int(rr["depth"]),
                "lambda": float(rr["lambda"]),
                "Q0": float(rr["Q0"]),
                "Q0_over_depth0": float(rr["Q0"]) / max(qbase, 1e-300),
            }
            geometry_rows.append(item)
            print(
                f"M={int(M):>10,d}  "
                f"depth={item['depth']}  "
                f"lambda={item['lambda']:g}  "
                f"Q0={item['Q0']:.12e}  "
                f"Q0/depth0={item['Q0_over_depth0']:.9f}"
            )

    geometry_df = pd.DataFrame(geometry_rows)

    # ------------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------------
    theorem_reduction_pass = bool(
        shape_pass
        and q_bound_dominates_actual
        and amplitude_current_pass
    )

    if theorem_reduction_pass:
        verdict = "FRESH_REGULAR_JET_SHAPE_ENVELOPE_PASS_AMPLITUDE_ONLY_OPEN"
        next_theorem = (
            "Prove or certify a single all-scale amplitude bound "
            "Q0=V0 < Acrit, while retaining the prospectively frozen shape "
            "ratios rho_m. The four-jet regular contraction then follows."
        )
    elif amplitude_current_pass:
        verdict = "SINGLE_AMPLITUDE_REDUCTION_NEEDS_SHAPE_REFINEMENT"
        next_theorem = (
            "The amplitude is far below contraction threshold, but the frozen "
            "shape envelope failed. Inspect the offending derivative ratio."
        )
    else:
        verdict = "SINGLE_AMPLITUDE_CONTRACTION_NOT_CERTIFIED"
        next_theorem = (
            "Fresh Q0 reached the shape-derived critical amplitude; regular "
            "contraction route requires stronger structure."
        )

    print("\n" + "=" * 222)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 222)

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)

    fresh_path = Path(str(prefix) + "_FRESH_SHAPE.csv")
    energy_path = Path(str(prefix) + "_ENERGY.csv")
    scale_path = Path(str(prefix) + "_SCALE.csv")
    geometry_path = Path(str(prefix) + "_GEOMETRY.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_NEXT_THEOREM.md")

    fresh.to_csv(fresh_path, index=False)
    energy_df.to_csv(energy_path, index=False)
    scale_df.to_csv(scale_path, index=False)
    geometry_df.to_csv(geometry_path, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "v399_used_to_refit_shape": False,
            "regression_accepted_as_proof": False,
        },
        "upstream": {
            "v398_verdict": v398.get("verdict"),
            "v399_verdict": v399.get("verdict"),
        },
        "frozen_shape": {
            "C_m": C.tolist(),
            "rho_m": rho.tolist(),
            "shape_induced_rows": shape_rows.tolist(),
            "H": H,
            "A_critical_for_gate": Acrit,
            "contraction_gate": args.contraction_gate,
        },
        "fresh_shape_test": {
            "max_R_over_rho_by_jet": max_shape_ratio.tolist(),
            "pass": shape_pass,
            "worst_shape_rows": worst_shape,
        },
        "single_amplitude": {
            "A_definition": "A=Q0=V0",
            "fresh_A_max": A_fresh_max,
            "shape_q_bound": q_shape_bound,
            "maximum_actual_fresh_q": max_actual_q,
            "q_bound_dominates_actual": q_bound_dominates_actual,
            "Acrit_over_fresh_Amax": amplitude_margin_factor,
            "fresh_below_critical": amplitude_current_pass,
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Prospective finite shape test plus exact algebraic single-amplitude "
            "reduction. The remaining all-scale theorem is a scalar amplitude "
            "bound Q0<Acrit; scale/energy diagnostics are descriptive only."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v400 — single-amplitude regular-jet reduction

The frozen v398 constants define

`rho_m=C_m/C_0`.

Fresh v399 data are NOT used to refit these ratios.

If

`Q_m <= rho_m Q_0`

for `m=0,1,2,3`, then the regular four-jet satisfies

`q_reg <= H Q_0`

with

`H=max_r sum_(m=0)^r binom(r,m)rho_m`.

For the frozen v398 shape,

`rho = {rho.tolist()}`

and

`H = {H:.16e}`.

Therefore the strict contraction threshold is

`Q_0 < Acrit = {Acrit:.16e}`.

The fresh maximum is

`Q_0,max = {A_fresh_max:.16e}`,

so the current finite margin factor is

`Acrit/Q_0,max = {amplitude_margin_factor:.12f}`.

Prospective fresh shape pass:

`{shape_pass}`

Verdict:

`{verdict}`

The remaining regular-jet theorem is now scalar:
prove an all-scale bound `Q_0=V_0 < Acrit` while retaining the frozen
shape ratios.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", fresh_path)
    print(" ", energy_path)
    print(" ", scale_path)
    print(" ", geometry_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and not theorem_reduction_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
