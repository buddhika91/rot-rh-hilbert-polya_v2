#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v475 — NONATTAINED PARABOLIC HEIGHT / ADIABATIC WINDOW THEOREM
====================================================================

PURPOSE
-------
Combine v473's flat-bump saddle with nonattained support migration.

Let

    a_* = sup_j a_j > 0,
    a_j = beta_j-1/2,

and suppose a_* is not attained.

For a zero j at ordinate Gamma_j, v473 gives the logarithmic bump magnitude

    log |K_j(L)|
      = a_j L
        - c L^(2/3) Re[(a_j+i Gamma_j)^(2/3)]
        + O(L^(1/3)|a_j+iGamma_j|^(1/3)+log L),

where c=3*2^(-2/3).

For large |Gamma|,

    Re[(a+iGamma)^(2/3)]
      >= c0 |Gamma|^(2/3)

for a fixed c0>0 in the closed right-half sector.

A. Parabolic active-height bound
--------------------------------
Fix any baseline off-critical zero j0 with a0>0 and finite Gamma0.

Its amplitude has

    log |K_0(L)| >= a0 L - C0 L^(2/3)

for all sufficiently large L.

Any instantaneous winner w must beat this baseline.  Its upper saddle envelope
has the form

    log |K_w(L)|
      <= a_* L
         - c1 L^(2/3)|Gamma_w|^(2/3)
         + C1 L^(1/3)|Gamma_w|^(1/3)
         + C2 L^(2/3).

Use Young's inequality

    C1 y <= (c1/2)y^2 + C1^2/(2c1),

with

    y=L^(1/3)|Gamma_w|^(1/3).

Then winner >= baseline implies

    (c1/2)L^(2/3)|Gamma_w|^(2/3)
      <= (a_*-a0)L + C L^(2/3)+C',

hence

    |Gamma_w(L)| <= C_* sqrt(L)

eventually.

Together with v473 overtaking,

    |Gamma_w(L)| -> infinity,
    a_*-a_w(L) -> 0.

Thus the bump-specific nonattained active support lives in the parabolic strip

    1 << |Gamma_active(L)| <<~ sqrt(L).

B. Fixed-window adiabatic separation
-------------------------------------
Put

    delta_w(L)=a_*-a_w(L).

Then

    delta_w(L)->0,
    |Gamma_w(L)|->infinity.

On every fixed window |Delta L|<=h with h>0,

AMPLITUDE:
    exp[-delta_w Delta L] = 1+o(1)

uniformly.

PHASE:
    the number of winner oscillations across the same window is

        |Gamma_w| h/(2pi) -> infinity.

BUMP CARRIER:
    v473 gives

        partial_E phase / L = 1+o(1)

because

        (L |Gamma_w|)^(-1/3) -> 0.

Therefore each large-L fixed window is simultaneously:

  * adiabatic in the active amplitudes;
  * infinitely oscillatory in the active phases;
  * asymptotically rigid in the E carrier.

C. Strengthened nonattained frontier
------------------------------------
v410 showed that a bounded physical branch could in principle hit an exceptional
cancellation POINT of the frozen Bohr geometry.

v475 shows the current bump problem is stronger:

    a persistent fixed branch must track the exceptional cancellation set
    THROUGH EVERY FIXED O(1) WINDOW while the active amplitudes are frozen
    to o(1) but the escaping phases execute infinitely many cycles.

Thus the remaining theorem is an ADIABATIC EXCEPTIONAL-WINDOW theorem, not a
single-sample typicality statement.

Combined with v474, any bounded nonattained branch must, on every late fixed
window, maintain either:

  1. amplitude collapse |H|/W0 small enough to compensate frequency escape; or
  2. genuinely broad-band relative frequency support;

and it must do so throughout a window containing an unbounded number of phase
oscillations.

This is a substantially smaller exceptional class.

Scientific boundary
-------------------
The parabolic bound uses the uniform sectorial saddle bounds corresponding to
v473.  A publication proof should package those bounds as explicit inequalities
rather than only an asymptotic steepest-descent statement.

This theorem does not yet exclude the adiabatic broad-band/collapse mechanism.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v475-parabolic-height-adiabatic-window"


def symbolic_young() -> Dict[str, Any]:
    import sympy as sp
    c, C, y = sp.symbols("c C y", positive=True, real=True)
    # (sqrt(c/2)y - C/sqrt(2c))^2 >= 0
    square = sp.expand(
        (sp.sqrt(c/2)*y - C/sp.sqrt(2*c))**2
    )
    target = c*y**2/2 - C*y + C**2/(2*c)
    resid = sp.simplify(square-target)

    L, G, A = sp.symbols("L G A", positive=True, real=True)
    # If G^(2/3) <= A L^(1/3), then G <= A^(3/2) L^(1/2).
    implication_resid = sp.simplify(
        (A*L**sp.Rational(1,3))**sp.Rational(3,2)
        - A**sp.Rational(3,2)*sp.sqrt(L)
    )

    return {
        "young_square_residual": str(resid),
        "parabolic_power_residual": str(implication_resid),
        "pass": bool(resid == 0 and implication_resid == 0),
    }


def adiabatic_panel():
    # Illustrative admissible sequences only; theorem is analytic.
    rows = []
    for L in (1e2, 1e4, 1e6, 1e8):
        gamma = L**0.4
        delta = 1.0/math.log(L+math.e)
        carrier_err = (L*gamma)**(-1.0/3.0)
        rows.append({
            "L": L,
            "example_gamma": gamma,
            "gamma_over_sqrtL": gamma/math.sqrt(L),
            "example_delta": delta,
            "unit_window_amplitude_change": 1.0-math.exp(-delta),
            "unit_window_cycles": gamma/(2.0*math.pi),
            "carrier_relative_error_proxy": carrier_err,
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v475 — nonattained parabolic height / adiabatic window theorem

Using the v473 sectorial saddle envelope, compare an instantaneous winner with
one fixed off-critical baseline `a0>0`.

After absorbing the `L^(1/3)|Gamma|^(1/3)` term by Young's inequality,

`winner >= baseline`

implies

`L^(2/3)|Gamma_w|^(2/3) <= C L + O(L^(2/3))`.

Therefore

`|Gamma_w(L)| <= C_* sqrt(L)`.

v473's nonattained overtaking simultaneously gives

`|Gamma_w(L)|->infinity`

and

`delta_w(L)=a_*-a_w(L)->0`.

Hence the active bump support satisfies

`1 << |Gamma_w(L)| <= C_* sqrt(L)`.

On any fixed cutoff window `|Delta|<=h`:

`exp(-delta_w Delta)=1+o(1)`

uniformly, while

`|Gamma_w|h/(2pi)->infinity`.

And v473 gives the common energy-carrier law

`partial_E phase / L = 1+o(1)`.

So every late fixed window is adiabatic in amplitude and infinitely oscillatory
in phase.

**Verdict:** {payload['verdict']}

The remaining nonattained theorem is therefore stronger than v410's
single-point exceptional-sampling question: a bounded fixed branch must remain
on an exceptional broad-band/amplitude-collapse set throughout every fixed
window containing infinitely many active oscillations.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_NONATTAINED_ADIABATIC_WINDOW_V1",
        "closed": {
            "active_height": "|Gamma_active(L)|=O(sqrt L)",
            "active_escape": "|Gamma_active(L)|->infinity",
            "deficit": "delta_active(L)->0",
            "fixed_window_amplitude": "relative variation ->0",
            "fixed_window_cycles": "number of active cycles ->infinity",
            "energy_carrier": "partial_E phase/L ->1",
        },
        "combined_with_v474": {
            "bounded_branch":
                "must remain broad-band or amplitude-collapsed throughout every late fixed window",
        },
        "remaining": {
            "adiabatic_exceptional_window":
                "exclude persistent cancellation over every fixed window, or derive a signed primitive-beta law for it",
        },
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="rot_rh_nonattained_adiabatic_window_v475")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*190)
    print("ROT-RH v475 — NONATTAINED PARABOLIC HEIGHT / ADIABATIC WINDOW")
    print("="*190)
    with tqdm(total=2, desc="v475 theorem", unit="step") as bar:
        sym = symbolic_young()
        bar.update(1)
        panel = adiabatic_panel()
        bar.update(1)

    passed = bool(sym["pass"])
    verdict = (
        "NONATTAINED_PARABOLIC_HEIGHT_ADIABATIC_WINDOW_REDUCTION_PASS"
        if passed else
        "NONATTAINED_ADIABATIC_WINDOW_ALGEBRA_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic_panel": panel,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "diagnostic_used_as_proof": False,
        },
        "proof_status":
            "Reduction conditional only on the uniform sectorial saddle inequalities underlying v473; exceptional-window cancellation remains open.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("algebra                         :", sym["pass"])
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
