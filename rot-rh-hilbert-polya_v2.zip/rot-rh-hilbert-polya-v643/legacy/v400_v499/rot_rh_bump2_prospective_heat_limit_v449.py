#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v449 — FROZEN BUMP-2 PROSPECTIVE HEAT-LIMIT / HOLDOUT AUDIT
====================================================================

PURPOSE
-------
v448 found that the compact smooth regulator

    W_X(n) = exp(-[x/(1-x)]^2) 1_{x<1},   x = log(n)/log(X),

was the strongest prime-side heat realization in the tested family, while the
multiplicative recursive-clock regulator behaved as a cutoff outlier.

v449 does NOT search regulator shape or tune its parameter.  It freezes bump-2
before construction and asks one question:

    Does the bump-2 prime operator genuinely approach the theta heat semigroup,
    or was the v448 result another unusually accurate finite cutoff?

The arithmetic phase law is frozen as

    theta(E)/pi + 1
      - (1/pi) sum_{n<X} Lambda(n)/(log(n)*sqrt(n)) W_X(n) sin(E log n)
      = k - 1/2.

For each cutoff X we construct the spectrum at the MAXIMUM requested depth once,
then reuse prefixes to audit several spectral depths.  The heat observable is

    h_{X,D}(u) = sum_{k<=D} exp(-u E_k(X)^2).

The direct zero-ordinate-free theta target is

    M(z) = d/dz log[Xi(i sqrt(z))/Xi(0)]
         = integral_0^infinity exp(-z u) K_Xi(u) du,

with K_Xi recovered independently by Stehfest and de Hoog inverse Laplace.
Known Riemann zero ordinates, zeta(), xi(), and Xi() are NEVER used.

PROSPECTIVE HOLDOUT DESIGN
--------------------------
All cutoffs except the largest are DEVELOPMENT/TRAINING cutoffs.  Before the
largest cutoff is constructed, v449:

  1. fits two frozen convergence model classes to the training target errors:
         C X^(-p),  C (log X)^(-p),
  2. fits the same two classes to successive cutoff heat-vector drifts,
  3. chooses the lower training log-RMS model among fits with p>0,
  4. creates a multiplicative prediction envelope from the training residuals,
  5. uses the target-FREE drift exponent to extrapolate each heat component to
     an infinite-cutoff vector and predict the held-out heat vector,
  6. writes and SHA256-freezes the prediction manifest,
  7. ONLY THEN constructs and scores the largest cutoff.

This prevents a lucky largest-cutoff result from feeding back into the model.

SCIENTIFIC TARGETS
------------------
A convincing finite precursor to cutoff independence should simultaneously show

    A_X = ||h_X - K_Xi|| -> 0,                  target convergence,
    B_X = ||h_{2X} - h_X|| -> 0,                cutoff Cauchy convergence,
    depth drift -> 0,                            spectral truncation stability,
    held-out A_X and B_X inside frozen envelopes,
    held-out h_X close to the target-free extrapolated prediction.

Even a PASS is NOT an RH proof and NOT an analytic operator-limit theorem.
The desired next theorem would be uniform heat convergence on compact u-windows,
followed by a positive-operator convergence upgrade.

Required local modules:
    rot_rh_clock_theta_jacobi_v445.py
    rot_rh_stieltjes_thorin_heat_v446.py
    rot_rh_regulator_universality_heat_v448.py

Recommended PowerShell run:
    python .\\rot_rh_bump2_prospective_heat_limit_v449.py `
      --depths 48,64,96 `
      --cutoffs 291600,583200,1166400,2332800,4665600 `
      --grid-points 64 `
      --moment-order 32 `
      --jacobi-dim 16 `
      --mp-dps 130 `
      --heat-u 0.008,0.010,0.0125,0.015,0.020,0.030 `
      --stehfest-degree 22 `
      --dehoog-degree 34 `
      --prediction-safety 2.0 `
      --prefix rot_rh_bump2_prospective_heat_limit_v449
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import numpy as np
from tqdm import tqdm

VERSION = "2026-08-25-v449-frozen-bump2-prospective-heat-limit"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_required(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place v445, v446, v448 and v449 in the same directory, or pass "
            "the corresponding --v445-module/--v446-module/--v448-module options."
        )


def module_sha(module) -> Dict[str, str]:
    p = Path(module.__file__).resolve()
    return {"path": str(p), "sha256": sha256_file(p)}


def rms(values: Iterable[float]) -> float:
    a = np.asarray(list(values), dtype=float)
    return float(np.sqrt(np.mean(a * a))) if a.size else float("nan")


def vector_rel_rms(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum(np.abs(bb), floor)
    return float(np.sqrt(np.mean(((aa - bb) / scale) ** 2)))


def symmetric_vector_drift(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum.reduce([np.abs(aa), np.abs(bb), np.full_like(aa, floor)])
    return float(np.sqrt(np.mean(((aa - bb) / scale) ** 2)))


def spectral_heat(levels: np.ndarray, u: float) -> float:
    e = np.asarray(levels, dtype=float)
    return float(np.sum(np.exp(-float(u) * e * e)))


# =============================================================================
# Frozen convergence model classes
# =============================================================================

def _basis_value(x: np.ndarray, model: str) -> np.ndarray:
    if model == "power_X":
        return np.log(x)
    if model == "power_logX":
        return np.log(np.log(x))
    raise ValueError(model)


def fit_decay_model(x: Sequence[float], y: Sequence[float], model: str, safety: float) -> dict:
    xx = np.asarray(x, dtype=float)
    yy = np.asarray(y, dtype=float)
    if len(xx) < 3 or len(xx) != len(yy):
        raise ValueError("Need >=3 matched points for a decay fit")
    if np.any(xx <= math.e) or np.any(yy <= 0) or not np.all(np.isfinite(yy)):
        return {
            "model": model, "valid": False, "reason": "nonpositive/nonfinite data",
            "C": float("nan"), "p": float("nan"), "log_rms": float("inf"),
            "envelope_factor": float("inf"), "residuals_log": [],
        }

    t = _basis_value(xx, model)
    ly = np.log(yy)
    A = np.column_stack([np.ones_like(t), -t])
    beta, *_ = np.linalg.lstsq(A, ly, rcond=None)
    logC, p = float(beta[0]), float(beta[1])
    fitted = A @ beta
    resid = ly - fitted
    lrms = float(np.sqrt(np.mean(resid * resid)))
    # Frozen finite-sample multiplicative envelope.  The safety factor is user-
    # supplied prospectively, while exp(max |residual|) is training-only.
    env = float(max(1.0, safety * math.exp(float(np.max(np.abs(resid))))))
    return {
        "model": model,
        "valid": bool(math.isfinite(p) and math.isfinite(logC)),
        "C": float(math.exp(logC)),
        "p": p,
        "log_rms": lrms,
        "envelope_factor": env,
        "residuals_log": [float(v) for v in resid],
    }


def decay_predict(fit: dict, x: float) -> float:
    if not fit.get("valid", False):
        return float("nan")
    C, p = float(fit["C"]), float(fit["p"])
    if fit["model"] == "power_X":
        return C * float(x) ** (-p)
    if fit["model"] == "power_logX":
        return C * math.log(float(x)) ** (-p)
    raise ValueError(fit["model"])


def choose_decay_model(fits: Sequence[dict]) -> dict:
    positive = [f for f in fits if f.get("valid") and float(f.get("p", -1)) > 0]
    pool = positive if positive else [f for f in fits if f.get("valid")]
    if not pool:
        return {"valid": False, "model": "none", "p": float("nan"), "log_rms": float("inf")}
    return min(pool, key=lambda f: float(f["log_rms"]))


def phi(x: float, fit: dict) -> float:
    p = float(fit["p"])
    if fit["model"] == "power_X":
        return float(x) ** (-p)
    if fit["model"] == "power_logX":
        return math.log(float(x)) ** (-p)
    raise ValueError(fit["model"])


def extrapolate_limit_and_holdout(
    x1: int,
    x2: int,
    xh: int,
    h1: Sequence[float],
    h2: Sequence[float],
    decay_fit: dict,
) -> Tuple[List[float], List[float]]:
    """Two-point h_X = h_inf + c phi(X), using a TRAINING-only drift exponent."""
    if not decay_fit.get("valid", False) or float(decay_fit.get("p", -1)) <= 0:
        return [float("nan")] * len(h1), [float("nan")] * len(h1)
    f1, f2, fh = phi(x1, decay_fit), phi(x2, decay_fit), phi(xh, decay_fit)
    den = f1 - f2
    if abs(den) < 1e-300:
        return [float("nan")] * len(h1), [float("nan")] * len(h1)
    lim, pred = [], []
    for a, b in zip(h1, h2):
        hinf = (b * f1 - a * f2) / den
        c = (a - b) / den
        lim.append(float(hinf))
        pred.append(float(hinf + c * fh))
    return lim, pred


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v449 frozen bump-2 prospective heat-limit holdout audit",
    )
    ap.add_argument("--v445-module", default="rot_rh_clock_theta_jacobi_v445")
    ap.add_argument("--v446-module", default="rot_rh_stieltjes_thorin_heat_v446")
    ap.add_argument("--v448-module", default="rot_rh_regulator_universality_heat_v448")

    ap.add_argument("--depths", default="48,64,96")
    ap.add_argument("--cutoffs", default="291600,583200,1166400,2332800,4665600")
    ap.add_argument("--grid-points", type=int, default=64)
    ap.add_argument("--prime-chunk", type=int, default=20000)

    ap.add_argument("--moment-order", type=int, default=32)
    ap.add_argument("--jacobi-dim", type=int, default=16)
    ap.add_argument("--mp-dps", type=int, default=130)

    ap.add_argument("--heat-u", default="0.008,0.010,0.0125,0.015,0.020,0.030")
    ap.add_argument("--theta-quad-order", type=int, default=22)
    ap.add_argument("--theta-breakpoints", default="0,0.5,1,1.5,2,2.5,3,3.5,4,5,6")
    ap.add_argument("--stehfest-degree", type=int, default=22)
    ap.add_argument("--dehoog-degree", type=int, default=34)

    # Prospective, frozen gates.  They are deliberately not optimized to this run.
    ap.add_argument("--prediction-safety", type=float, default=2.0)
    ap.add_argument("--maximum-target-method-relative-gap", type=float, default=5e-4)
    ap.add_argument("--maximum-jacobi-target-relative-rms", type=float, default=1e-8)
    ap.add_argument("--maximum-holdout-target-relative-rms", type=float, default=5e-4)
    ap.add_argument("--maximum-holdout-cutoff-drift", type=float, default=5e-4)
    ap.add_argument("--maximum-holdout-depth-drift", type=float, default=1e-6)
    ap.add_argument("--maximum-holdout-vector-prediction-drift", type=float, default=5e-3)
    ap.add_argument("--maximum-missing-cells", type=int, default=0)
    ap.add_argument("--maximum-quantization-residual", type=float, default=1e-8)

    ap.add_argument("--prefix", default="rot_rh_bump2_prospective_heat_limit_v449")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    depths = parse_ints(args.depths)
    if len(depths) < 2 or depths != sorted(set(depths)) or min(depths) < 8:
        raise ValueError("--depths must contain >=2 unique increasing integers >=8")
    max_depth = depths[-1]

    cutoffs = parse_ints(args.cutoffs)
    if len(cutoffs) < 5 or cutoffs != sorted(set(cutoffs)):
        raise ValueError("--cutoffs must contain >=5 unique increasing values")
    # The experiment is designed around multiplicative/dyadic scaling.  We do
    # not require exact doubling, but enforce increasing ratios >1.
    ratios = [cutoffs[i+1] / cutoffs[i] for i in range(len(cutoffs)-1)]
    if min(ratios) <= 1:
        raise ValueError("cutoff ratios must exceed 1")

    heat_u = parse_floats(args.heat_u)
    if not heat_u or any(u <= 0 for u in heat_u):
        raise ValueError("--heat-u must contain positive values")
    if args.moment_order < 2 * args.jacobi_dim:
        raise ValueError("--moment-order must be >= 2*--jacobi-dim")
    if args.prediction_safety <= 1.0:
        raise ValueError("--prediction-safety must exceed 1")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    v445 = import_required(args.v445_module)
    v446 = import_required(args.v446_module)
    v448 = import_required(args.v448_module)
    mp.mp.dps = int(args.mp_dps)

    # Frozen law: NO regulator or parameter search in v449.
    reg = v448.Regulator("bump", 2.0, "bump_2")
    train_cutoffs = cutoffs[:-1]
    holdout_X = cutoffs[-1]

    print("=" * 162)
    print("ROT-RH v449 — FROZEN BUMP-2 PROSPECTIVE HEAT-LIMIT / HOLDOUT AUDIT")
    print("=" * 162)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("frozen prime regulator             : bump_2 ONLY")
    print("window                             : exp(-(x/(1-x))^2) 1_{x<1}")
    print("depths                             :", depths)
    print("training cutoffs                   :", train_cutoffs)
    print("HELD-OUT cutoff                    :", holdout_X)
    print("prospective model classes          : C X^-p ; C (log X)^-p")
    print("scientific target                  : heat target + cutoff Cauchy + depth stability + blind holdout")
    print("=" * 162)

    # ------------------------------------------------------------------
    # A. Direct theta target, dual numerical inversion.
    # ------------------------------------------------------------------
    print("\n[A] Building zero-ordinate-free theta heat target ...")
    target = v448.DirectThetaTarget(
        dps=args.mp_dps,
        quad_order=args.theta_quad_order,
        breakpoints=parse_floats(args.theta_breakpoints),
    )
    target_rows: List[dict] = []
    target_heat: List[float] = []
    target_gaps: List[float] = []
    target_positive = True
    for uu in tqdm(heat_u, desc="theta inverse Laplace (Stehfest + de Hoog)", unit="u"):
        u = mp.mpf(str(uu))
        ks = target.heat(u, "stehfest", args.stehfest_degree)
        kd = target.heat(u, "dehoog", args.dehoog_degree)
        gap = float(abs(ks-kd) / max(abs(kd), mp.mpf("1e-100")))
        positive = bool(mp.re(kd) > 0 and abs(mp.im(kd)) < mp.mpf("1e-45"))
        target_positive = target_positive and positive
        target_heat.append(float(mp.re(kd)))
        target_gaps.append(gap)
        target_rows.append({
            "u": f"{uu:.17g}",
            "K_stehfest": mp.nstr(ks, 70),
            "K_dehoog": mp.nstr(kd, 70),
            "relative_method_gap": f"{gap:.17g}",
            "dehoog_positive": positive,
        })
    target_path = Path(str(prefix) + "_THETA_HEAT_DUAL.csv")
    write_csv(target_path, list(target_rows[0].keys()), target_rows)
    max_target_gap = max(target_gaps)
    target_numerics_pass = target_positive and max_target_gap <= args.maximum_target_method_relative_gap

    # ------------------------------------------------------------------
    # B. v446 positive Stieltjes/Jacobi consistency route.
    # ------------------------------------------------------------------
    print("\n[B] Building v446 positive Jacobi heat consistency check ...")
    c, unit, q = v446.theta_data(args.moment_order, args.mp_dps)
    q1 = q[0]
    support_scale, hankel_rows, J, lamJ, wJ, multJ = v446.stieltjes_jacobi(q, args.jacobi_dim)
    jac_vec = [float(v446.heat_trace_from_quadrature(q1, lamJ, wJ, mp.mpf(str(u)))) for u in heat_u]
    jac_rms = vector_rel_rms(jac_vec, target_heat)
    jac_rows = [{
        "u": f"{u:.17g}",
        "K_jacobi": f"{kj:.17g}",
        "K_theta_dehoog": f"{kt:.17g}",
        "relative_error": f"{abs(kj-kt)/max(abs(kt),1e-300):.17g}",
    } for u, kj, kt in zip(heat_u, jac_vec, target_heat)]
    jac_path = Path(str(prefix) + "_JACOBI_HEAT.csv")
    write_csv(jac_path, list(jac_rows[0].keys()), jac_rows)
    jac_pass = jac_rms <= args.maximum_jacobi_target_relative_rms

    # ------------------------------------------------------------------
    # C. Free levels once at maximum depth.
    # ------------------------------------------------------------------
    print("\n[C] Building free Gamma cells at maximum depth ...")
    free_ext = v445.free_archimedean_levels(max_depth)

    vectors: Dict[Tuple[int, int], List[float]] = {}
    records: Dict[int, Dict[str, object]] = {}
    heat_rows: List[dict] = []
    cutoff_rows: List[dict] = []
    depth_rows: List[dict] = []
    root_rows: List[dict] = []

    def construct_cutoff(X: int, stage: str) -> None:
        print(f"\n  [Mangoldt cache/{stage}] X={X}")
        n, mang = v445.mangoldt_terms(int(X))
        rec = v448.quantize_regulator(
            v445=v445,
            depth=max_depth,
            X=int(X),
            reg=reg,
            free_ext=free_ext,
            n=n,
            lam=mang,
            grid_points=args.grid_points,
            prime_chunk=args.prime_chunk,
        )
        records[X] = rec
        roots = np.asarray(rec["roots"], dtype=float)

        for k, (rr, res, cnt) in enumerate(zip(roots, rec["residuals"], rec["counts"]), 1):
            root_rows.append({
                "stage": stage, "cutoff": X, "k": k,
                "root": f"{float(rr):.17g}",
                "residual": f"{float(res):.17g}",
                "crossings": int(cnt),
            })

        for D in depths:
            vec = [spectral_heat(roots[:D], u) for u in heat_u]
            vectors[(X, D)] = vec
            er = vector_rel_rms(vec, target_heat)
            for uu, km, kt in zip(heat_u, vec, target_heat):
                heat_rows.append({
                    "stage": stage, "cutoff": X, "depth": D, "u": f"{uu:.17g}",
                    "K_model": f"{km:.17g}", "K_theta_target": f"{kt:.17g}",
                    "relative_error": f"{abs(km-kt)/max(abs(kt),1e-300):.17g}",
                })
            cutoff_rows.append({
                "stage": stage, "cutoff": X, "depth": D,
                "heat_relative_rms": f"{er:.17g}",
                "max_quantization_residual": f"{float(np.max(rec['residuals'])):.17g}",
                "missing_cells": int(np.sum(np.asarray(rec["counts"]) == 0)),
                "ambiguous_cells": int(np.sum(np.asarray(rec["counts"]) > 1)),
                "term_count": int(rec["term_count"]),
            })

        for da, db in zip(depths[:-1], depths[1:]):
            dd = symmetric_vector_drift(vectors[(X, da)], vectors[(X, db)])
            depth_rows.append({
                "stage": stage, "cutoff": X, "depth_from": da, "depth_to": db,
                "heat_vector_relative_rms": f"{dd:.17g}",
            })

    # ------------------------------------------------------------------
    # D. TRAINING construction only.
    # ------------------------------------------------------------------
    print("\n[D] Constructing TRAINING cutoffs only ...")
    for X in train_cutoffs:
        construct_cutoff(X, "TRAIN")

    # Training drift data at maximum depth.
    maxD = max_depth
    train_target_errors = [vector_rel_rms(vectors[(X, maxD)], target_heat) for X in train_cutoffs]
    train_drift_x: List[int] = []
    train_drifts: List[float] = []
    drift_rows: List[dict] = []
    for xa, xb in zip(train_cutoffs[:-1], train_cutoffs[1:]):
        d = symmetric_vector_drift(vectors[(xa, maxD)], vectors[(xb, maxD)])
        train_drift_x.append(xb)
        train_drifts.append(d)
        drift_rows.append({
            "stage": "TRAIN", "cutoff_from": xa, "cutoff_to": xb, "depth": maxD,
            "heat_vector_relative_rms": f"{d:.17g}",
        })

    # ------------------------------------------------------------------
    # E. Fit frozen prospective models BEFORE holdout construction.
    # ------------------------------------------------------------------
    print("\n[E] Fitting and FREEZING prospective convergence models ...")
    target_fits = [
        fit_decay_model(train_cutoffs, train_target_errors, name, args.prediction_safety)
        for name in ("power_X", "power_logX")
    ]
    drift_fits = [
        fit_decay_model(train_drift_x, train_drifts, name, args.prediction_safety)
        for name in ("power_X", "power_logX")
    ]
    target_fit = choose_decay_model(target_fits)
    drift_fit = choose_decay_model(drift_fits)

    pred_target = decay_predict(target_fit, holdout_X)
    pred_drift = decay_predict(drift_fit, holdout_X)
    target_upper = pred_target * float(target_fit.get("envelope_factor", float("inf")))
    drift_upper = pred_drift * float(drift_fit.get("envelope_factor", float("inf")))

    # Target-free vector extrapolation from the last two TRAINING cutoffs using
    # the TRAINING-only drift exponent.
    x1, x2 = train_cutoffs[-2], train_cutoffs[-1]
    extrapolated_limit, predicted_holdout_vector = extrapolate_limit_and_holdout(
        x1, x2, holdout_X,
        vectors[(x1, maxD)], vectors[(x2, maxD)], drift_fit,
    )
    extrapolated_limit_target_rms = vector_rel_rms(extrapolated_limit, target_heat) if np.all(np.isfinite(extrapolated_limit)) else float("inf")

    fit_rows: List[dict] = []
    for quantity, fits in (("target_error", target_fits), ("cutoff_drift", drift_fits)):
        chosen_name = target_fit.get("model") if quantity == "target_error" else drift_fit.get("model")
        for f in fits:
            fit_rows.append({
                "quantity": quantity,
                "model": f["model"],
                "chosen": f["model"] == chosen_name,
                "valid": f.get("valid", False),
                "C": f"{float(f.get('C',float('nan'))):.17g}",
                "p": f"{float(f.get('p',float('nan'))):.17g}",
                "training_log_rms": f"{float(f.get('log_rms',float('inf'))):.17g}",
                "envelope_factor": f"{float(f.get('envelope_factor',float('inf'))):.17g}",
                "holdout_prediction": f"{decay_predict(f,holdout_X):.17g}" if f.get("valid") else "nan",
            })
    fits_path = Path(str(prefix) + "_TRAIN_FITS.csv")
    write_csv(fits_path, list(fit_rows[0].keys()), fit_rows)

    prediction_rows = []
    for uu, hinf, hp in zip(heat_u, extrapolated_limit, predicted_holdout_vector):
        prediction_rows.append({
            "u": f"{uu:.17g}",
            "extrapolated_infinite_heat": f"{hinf:.17g}",
            "predicted_holdout_heat": f"{hp:.17g}",
            "theta_target_for_postfreeze_scoring": f"{target_heat[heat_u.index(uu)]:.17g}",
        })
    prediction_vector_path = Path(str(prefix) + "_PREDICTED_HOLDOUT_VECTOR.csv")
    write_csv(prediction_vector_path, list(prediction_rows[0].keys()), prediction_rows)

    prediction_manifest = {
        "version": VERSION,
        "stage": "PRE_HOLDOUT_FREEZE",
        "frozen_regulator": {"family": "bump", "parameter": 2.0, "name": "bump_2"},
        "training_cutoffs": train_cutoffs,
        "held_out_cutoff": holdout_X,
        "depths": depths,
        "heat_u": heat_u,
        "training_target_errors_at_max_depth": train_target_errors,
        "training_cutoff_drift_right_endpoints": train_drift_x,
        "training_cutoff_drifts_at_max_depth": train_drifts,
        "target_models": target_fits,
        "selected_target_model": target_fit,
        "drift_models": drift_fits,
        "selected_drift_model": drift_fit,
        "predicted_holdout_target_error": pred_target,
        "predicted_holdout_target_error_upper_envelope": target_upper,
        "predicted_holdout_cutoff_drift": pred_drift,
        "predicted_holdout_cutoff_drift_upper_envelope": drift_upper,
        "training_only_extrapolated_limit_target_rms_for_diagnostic": extrapolated_limit_target_rms,
        "predicted_holdout_vector_file": prediction_vector_path.name,
        "parameters": vars(args),
        "firewall": {
            "known_zero_ordinates_used": False,
            "largest_cutoff_constructed_before_this_manifest": False,
            "regulator_parameter_selected_in_v449": False,
        },
    }
    prediction_manifest_path = Path(str(prefix) + "_PRE_HOLDOUT_FREEZE.json")
    prediction_manifest_path.write_text(json.dumps(prediction_manifest, indent=2), encoding="utf-8")
    prediction_sha = sha256_file(prediction_manifest_path)
    print("  PRE-HOLDOUT FREEZE SHA256:", prediction_sha)
    print("  selected target model     :", target_fit.get("model"), "p=", f"{float(target_fit.get('p',float('nan'))):.6g}")
    print("  selected drift model      :", drift_fit.get("model"), "p=", f"{float(drift_fit.get('p',float('nan'))):.6g}")
    print("  predicted holdout A_X     :", f"{pred_target:.6e}", " upper=", f"{target_upper:.6e}")
    print("  predicted holdout B_X     :", f"{pred_drift:.6e}", " upper=", f"{drift_upper:.6e}")

    # ------------------------------------------------------------------
    # F. HELD-OUT construction — only after frozen prediction manifest.
    # ------------------------------------------------------------------
    print("\n[F] Revealing and constructing HELD-OUT cutoff ...")
    construct_cutoff(holdout_X, "HOLDOUT")

    holdout_target_error = vector_rel_rms(vectors[(holdout_X, maxD)], target_heat)
    holdout_cutoff_drift = symmetric_vector_drift(
        vectors[(train_cutoffs[-1], maxD)], vectors[(holdout_X, maxD)]
    )
    drift_rows.append({
        "stage": "HOLDOUT", "cutoff_from": train_cutoffs[-1], "cutoff_to": holdout_X, "depth": maxD,
        "heat_vector_relative_rms": f"{holdout_cutoff_drift:.17g}",
    })

    holdout_depth_drifts = []
    for da, db in zip(depths[:-1], depths[1:]):
        holdout_depth_drifts.append(symmetric_vector_drift(vectors[(holdout_X, da)], vectors[(holdout_X, db)]))
    holdout_final_depth_drift = holdout_depth_drifts[-1]

    holdout_vector_prediction_drift = (
        symmetric_vector_drift(predicted_holdout_vector, vectors[(holdout_X, maxD)])
        if np.all(np.isfinite(predicted_holdout_vector)) else float("inf")
    )

    rec_h = records[holdout_X]
    holdout_missing = int(np.sum(np.asarray(rec_h["counts"]) == 0))
    holdout_ambiguous = int(np.sum(np.asarray(rec_h["counts"]) > 1))
    holdout_max_residual = float(np.max(rec_h["residuals"]))

    # Holdout checks against information frozen before holdout construction.
    target_prediction_pass = bool(
        target_fit.get("valid", False) and float(target_fit.get("p", -1)) > 0
        and math.isfinite(target_upper) and holdout_target_error <= target_upper
    )
    drift_prediction_pass = bool(
        drift_fit.get("valid", False) and float(drift_fit.get("p", -1)) > 0
        and math.isfinite(drift_upper) and holdout_cutoff_drift <= drift_upper
    )
    absolute_target_pass = holdout_target_error <= args.maximum_holdout_target_relative_rms
    absolute_drift_pass = holdout_cutoff_drift <= args.maximum_holdout_cutoff_drift
    depth_pass = holdout_final_depth_drift <= args.maximum_holdout_depth_drift
    vector_prediction_pass = holdout_vector_prediction_drift <= args.maximum_holdout_vector_prediction_drift
    root_pass = holdout_missing <= args.maximum_missing_cells and holdout_max_residual <= args.maximum_quantization_residual
    target_tail_improved = holdout_target_error < train_target_errors[-1]
    drift_tail_improved = holdout_cutoff_drift < train_drifts[-1]

    # Refit post-holdout ONLY for scientific diagnostics, never to change PASS.
    all_target_errors = [vector_rel_rms(vectors[(X, maxD)], target_heat) for X in cutoffs]
    all_drifts = train_drifts + [holdout_cutoff_drift]
    post_target_fits = [fit_decay_model(cutoffs, all_target_errors, m, args.prediction_safety) for m in ("power_X","power_logX")]
    post_drift_fits = [fit_decay_model(cutoffs[1:], all_drifts, m, args.prediction_safety) for m in ("power_X","power_logX")]
    post_target_fit = choose_decay_model(post_target_fits)
    post_drift_fit = choose_decay_model(post_drift_fits)

    # ------------------------------------------------------------------
    # G. Write complete tables.
    # ------------------------------------------------------------------
    heat_path = Path(str(prefix) + "_DEPTH_HEAT.csv")
    write_csv(heat_path, list(heat_rows[0].keys()), heat_rows)
    cutoff_path = Path(str(prefix) + "_CUTOFF_SUMMARY.csv")
    write_csv(cutoff_path, list(cutoff_rows[0].keys()), cutoff_rows)
    depth_path = Path(str(prefix) + "_DEPTH_DRIFT.csv")
    write_csv(depth_path, list(depth_rows[0].keys()), depth_rows)
    drift_path = Path(str(prefix) + "_CUTOFF_DRIFT.csv")
    write_csv(drift_path, list(drift_rows[0].keys()), drift_rows)
    roots_path = Path(str(prefix) + "_ROOT_DIAGNOSTICS.csv")
    write_csv(roots_path, list(root_rows[0].keys()), root_rows)

    holdout_score_rows = []
    for uu, pred, actual, targetv in zip(heat_u, predicted_holdout_vector, vectors[(holdout_X,maxD)], target_heat):
        holdout_score_rows.append({
            "u": f"{uu:.17g}",
            "predicted_holdout_heat": f"{pred:.17g}",
            "actual_holdout_heat": f"{actual:.17g}",
            "theta_target": f"{targetv:.17g}",
            "symmetric_prediction_drift_component": f"{abs(pred-actual)/max(abs(pred),abs(actual),1e-300):.17g}",
            "actual_relative_target_error_component": f"{abs(actual-targetv)/max(abs(targetv),1e-300):.17g}",
        })
    holdout_score_path = Path(str(prefix) + "_HOLDOUT_SCORE.csv")
    write_csv(holdout_score_path, list(holdout_score_rows[0].keys()), holdout_score_rows)

    # ------------------------------------------------------------------
    # H. Verdict.
    # ------------------------------------------------------------------
    core_pass = all([
        target_numerics_pass,
        jac_pass,
        target_prediction_pass,
        drift_prediction_pass,
        absolute_target_pass,
        absolute_drift_pass,
        depth_pass,
        vector_prediction_pass,
        root_pass,
        target_tail_improved,
        drift_tail_improved,
    ])

    if not target_numerics_pass:
        verdict = "THETA_TARGET_NUMERICS_NOT_STABLE"
    elif not jac_pass:
        verdict = "THETA_TARGET_OK_BUT_JACOBI_HEAT_CONSISTENCY_FAILED"
    elif not target_prediction_pass or not drift_prediction_pass:
        verdict = "PROSPECTIVE_HOLDOUT_MISSED_FROZEN_CONVERGENCE_ENVELOPE"
    elif not root_pass:
        verdict = "HOLDOUT_ROOT_QUANTIZATION_NOT_CLEAN"
    elif not depth_pass:
        verdict = "HOLDOUT_CUTOFF_PROMISING_BUT_DEPTH_CONVERGENCE_FAILED"
    elif not vector_prediction_pass:
        verdict = "SCALAR_HOLDOUT_OK_BUT_TARGET_FREE_VECTOR_PREDICTION_FAILED"
    elif not absolute_target_pass or not absolute_drift_pass:
        verdict = "HOLDOUT_PREDICTED_BUT_ABSOLUTE_CONVERGENCE_GATES_NOT_MET"
    elif not target_tail_improved or not drift_tail_improved:
        verdict = "HOLDOUT_INSIDE_ENVELOPE_BUT_TAIL_NOT_IMPROVING"
    else:
        verdict = "FROZEN_BUMP2_PROSPECTIVE_HEAT_LIMIT_SUPPORTED"

    # Full manifest after experiment; pre-holdout prediction hash remains the
    # audit anchor demonstrating that the held-out cutoff could not feed back.
    manifest = {
        "version": VERSION,
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "modules": {"v445": module_sha(v445), "v446": module_sha(v446), "v448": module_sha(v448)},
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_function_called": False,
            "theta_integral_used": True,
            "regulator_frozen_before_v449": "bump_2",
            "pre_holdout_prediction_manifest": prediction_manifest_path.name,
            "pre_holdout_prediction_sha256": prediction_sha,
        },
        "parameters": vars(args),
    }
    manifest_path = Path(str(prefix) + "_FREEZE.json")
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time() - t0,
        "verdict": verdict,
        "scientific_boundary": (
            "Finite prospective zero-ordinate-free evidence only. A successful holdout does not prove uniform heat convergence, "
            "operator convergence, all-order Stieltjes positivity, or RH."
        ),
        "frozen_law": {
            "regulator": "bump_2",
            "window": "exp(-(x/(1-x))^2) for x<1, else 0; x=log(n)/log(X)",
        },
        "theta_target": {
            "reference_method": "dehoog",
            "maximum_stehfest_dehoog_relative_gap": max_target_gap,
            "positive": bool(target_positive),
            "pass": bool(target_numerics_pass),
        },
        "jacobi": {
            "dim": args.jacobi_dim,
            "heat_relative_rms_to_dehoog": jac_rms,
            "pass": bool(jac_pass),
            "minimum_final_H0_pivot": hankel_rows[-1]["min_cholesky_pivot_H0"],
            "minimum_final_H1_pivot": hankel_rows[-1]["min_cholesky_pivot_H1"],
        },
        "prospective_freeze": {
            "training_cutoffs": train_cutoffs,
            "held_out_cutoff": holdout_X,
            "prediction_manifest": prediction_manifest_path.name,
            "prediction_manifest_sha256": prediction_sha,
            "selected_target_model": target_fit,
            "selected_drift_model": drift_fit,
            "predicted_holdout_target_error": pred_target,
            "target_error_upper_envelope": target_upper,
            "predicted_holdout_cutoff_drift": pred_drift,
            "cutoff_drift_upper_envelope": drift_upper,
            "training_only_extrapolated_limit_target_rms": extrapolated_limit_target_rms,
        },
        "holdout": {
            "target_relative_rms": holdout_target_error,
            "successive_cutoff_drift": holdout_cutoff_drift,
            "depth_drifts": holdout_depth_drifts,
            "final_depth_drift": holdout_final_depth_drift,
            "target_free_vector_prediction_drift": holdout_vector_prediction_drift,
            "missing_cells": holdout_missing,
            "ambiguous_cells": holdout_ambiguous,
            "maximum_quantization_residual": holdout_max_residual,
            "target_prediction_envelope_pass": bool(target_prediction_pass),
            "drift_prediction_envelope_pass": bool(drift_prediction_pass),
            "absolute_target_gate_pass": bool(absolute_target_pass),
            "absolute_drift_gate_pass": bool(absolute_drift_pass),
            "depth_gate_pass": bool(depth_pass),
            "vector_prediction_gate_pass": bool(vector_prediction_pass),
            "root_gate_pass": bool(root_pass),
            "target_tail_improved": bool(target_tail_improved),
            "drift_tail_improved": bool(drift_tail_improved),
        },
        "trajectories": {
            "target_error_by_cutoff_at_max_depth": {str(X): all_target_errors[i] for i,X in enumerate(cutoffs)},
            "successive_cutoff_drift": {str(cutoffs[i+1]): all_drifts[i] for i in range(len(all_drifts))},
        },
        "post_holdout_diagnostic_fits_not_used_for_verdict": {
            "target": post_target_fit,
            "drift": post_drift_fit,
        },
        "gates": {
            "maximum_target_method_relative_gap": args.maximum_target_method_relative_gap,
            "maximum_jacobi_target_relative_rms": args.maximum_jacobi_target_relative_rms,
            "maximum_holdout_target_relative_rms": args.maximum_holdout_target_relative_rms,
            "maximum_holdout_cutoff_drift": args.maximum_holdout_cutoff_drift,
            "maximum_holdout_depth_drift": args.maximum_holdout_depth_drift,
            "maximum_holdout_vector_prediction_drift": args.maximum_holdout_vector_prediction_drift,
            "maximum_missing_cells": args.maximum_missing_cells,
            "maximum_quantization_residual": args.maximum_quantization_residual,
        },
        "outputs": {
            "theta_heat_dual": target_path.name,
            "jacobi_heat": jac_path.name,
            "training_fits": fits_path.name,
            "predicted_holdout_vector": prediction_vector_path.name,
            "pre_holdout_freeze": prediction_manifest_path.name,
            "depth_heat": heat_path.name,
            "cutoff_summary": cutoff_path.name,
            "depth_drift": depth_path.name,
            "cutoff_drift": drift_path.name,
            "root_diagnostics": roots_path.name,
            "holdout_score": holdout_score_path.name,
            "freeze_manifest": manifest_path.name,
        },
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n" + "=" * 162)
    print("KEY RESULTS")
    print("=" * 162)
    print("verdict                                  :", verdict)
    print("theta dual inversion stable              :", target_numerics_pass)
    print("max Stehfest/de Hoog gap                 :", f"{max_target_gap:.6e}")
    print("Jacobi heat RMS vs de Hoog               :", f"{jac_rms:.6e}")
    print("pre-holdout freeze SHA256                :", prediction_sha)
    print("selected target convergence model        :", target_fit.get("model"), "p=", f"{float(target_fit.get('p',float('nan'))):.6g}")
    print("selected cutoff-drift model              :", drift_fit.get("model"), "p=", f"{float(drift_fit.get('p',float('nan'))):.6g}")
    print("\ntraining target RMS trajectory (D=max)   :")
    for X, e in zip(train_cutoffs, train_target_errors):
        print(f"  X={X:<10d} {e:.6e}")
    print("training successive cutoff drift         :")
    for X, d in zip(train_drift_x, train_drifts):
        print(f"  -> X={X:<10d} {d:.6e}")
    print("\nHELD-OUT cutoff                          :", holdout_X)
    print("predicted target error / upper envelope  :", f"{pred_target:.6e} / {target_upper:.6e}")
    print("actual target error                      :", f"{holdout_target_error:.6e}", " pass=", target_prediction_pass)
    print("predicted cutoff drift / upper envelope  :", f"{pred_drift:.6e} / {drift_upper:.6e}")
    print("actual cutoff drift                      :", f"{holdout_cutoff_drift:.6e}", " pass=", drift_prediction_pass)
    print("target-free holdout vector prediction    :", f"{holdout_vector_prediction_drift:.6e}", " pass=", vector_prediction_pass)
    print("final depth drift                        :", f"{holdout_final_depth_drift:.6e}", " pass=", depth_pass)
    print("holdout missing / ambiguous cells        :", holdout_missing, "/", holdout_ambiguous)
    print("holdout max quantization residual        :", f"{holdout_max_residual:.6e}")
    print("target tail improved                     :", target_tail_improved)
    print("cutoff drift tail improved               :", drift_tail_improved)
    print("summary                                  :", summary_path)
    print("=" * 162)

    if args.strict and not core_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
