# ROT-RH v486 — UV height barrier / explicit collapse scale

Assume the v478/v411 nonattained lock persists on a proportional cutoff window
of length `h=cL`, after removing the finite set of genuinely local shifted-frequency
collisions.  Let `A0>0` be the resulting fixed lower shifted-frequency gap.

v483 gives for every **finite** strict-sector-locked truncation

`n >= A0 c L/(2 pi)`.

Hence any such truncation needs `Omega(L)` zeta modes.

The classical Riemann-von Mangoldt count gives `N(T)=O(T log T)`.  For any fixed
`eta>0`, choose

`T_eta(L)=L/(log L)^(1+eta)`.

Then

`N(T_eta)=O(L/(log L)^eta)=o(L)`.

Therefore the truncation through `T_eta(L)` cannot inherit the proportional-window
sector lock for all large `L`.

If the **full infinite** resonance sum remains in the narrower sector, the sector
perturbation lemma from v485 forces the full amplitude down to the omitted-tail
scale somewhere on every late proportional window.

The uniform sectorial v473 saddle gives

`Tail(>T) <= poly(L,T) exp[-k L^(2/3) T^(2/3)]`.

At `T=T_eta`,

`L^(2/3) T_eta^(2/3)
 = L^(4/3)/(log L)^(0.833333333333)`.

Thus for every fixed `eta>0`, a surviving nonattained infinite-family lock must
satisfy, at some point of every sufficiently late proportional window,

`|H_L| <= poly(L) exp[-c_eta L^(4/3)/(log L)^(2(1+eta)/3)]`

after the common right-edge normalization.

In particular the required cancellation is not merely exponential in `L`; it is
stretched-superexponential with a universal `L^(4/3)` power (up to logarithms).

**Verdict:** `UV_HEIGHT_BARRIER_4OVER3_COLLAPSE_REDUCTION_PASS`.

## Scientific boundary

This still does not exclude the survivor.  It proves that any survivor needs a
moving ultraviolet truncation of at least almost `L/log L` and forces the finite
lower-frequency sector to cancel to the corresponding v473 tail scale.  Closing
cutoff independence now requires either:

1. a zero/fold/arithmetical lower-bound theorem ruling out this precision for the
   fixed zeta geometry; or
2. a proof that the exact canonical cutoff generator has a v419-subquadratic
   signed primitive despite this amplitude collapse.

The summed tail estimate is conditional on upgrading v473 to publication-grade
uniform sectorial inequalities.
