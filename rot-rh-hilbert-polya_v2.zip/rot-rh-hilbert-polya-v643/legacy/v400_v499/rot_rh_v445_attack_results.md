# ROT–RH v445 attack results

## A. Recursive-clock multiplicative regulator

Tested depth 120 with

\[
a_X(n)=\frac{\Lambda(n)}{\log n\sqrt n}\,n^{-1/\log X}
\]

and the fixed Gamma-cell root rule. No zero ordinates were used to construct the roots.

| X | epsilon=1/log X | crossing structure | RMSE | relative RMSE* |
|---:|---:|---|---:|---:|
| 36,450 | 0.0952045765 | 120/120 cells have exactly 1 crossing | 0.0121269930 | 0.00698681% |
| 72,900 | 0.0893108815 | 120/120 exactly 1 | 0.0148650231 | 0.00856429% |
| 145,800 | 0.0841043523 | 120/120 exactly 1 | 0.0134015599 | 0.00772114% |
| 291,600 | 0.0794714306 | 119 cells exactly 1; one cell has 16 crossings (256-point confirmation) | 0.0216687702† | 0.01248419%† |
| 583,200 | 0.0753222732 | 118 cells exactly 1; one missing; one has 33 crossings (128-point confirmation) | 0.0362165537† | 0.02086571%† |

\* Same normalization as the frozen Riesz result: RMSE divided by RMS of the first 120 target ordinates.

† Once a cell is ambiguous or missing, the reported nearest-cell selection is diagnostic only and is not a valid unique quantization result.

### Riesz-1 control

\[
W_X^{(1)}(n)=\left(1-\frac{\log n}{\log X}\right)_+.
\]

| X | crossing structure | RMSE | relative RMSE |
|---:|---|---:|---:|
| 72,900 | 120/120 exactly 1 | 0.00859388581 | 0.00495126% |
| 145,800 | 120/120 exactly 1 | 0.00749238932 | 0.00431665% |
| 291,600 | 120/120 exactly 1 | 0.00654837968 | 0.00377277% |
| 583,200 | 120/120 exactly 1 | 0.00587228641 | 0.00338324% |

Conclusion: the naive multiplicative clock damping is composition-compatible, but it does not preserve the successful large-cutoff root structure. Riesz-1 remains the better boundary summation law.

## B. Riesz-1 has a direct recursive-clock interpretation

Set recursive clock time \(\tau=\log n\) and horizon \(T=\log X\). Then

\[
W_X^{(1)}(n)=\left(1-\frac{\tau}{T}\right)_+
=\frac1T\int_0^T \mathbf 1_{\{\tau\le u\}}\,du.
\]

So Riesz-1 is exactly the Cesaro average of sharp finite recursive-clock horizons. It is therefore ROT-clock-native in a different sense than exponential damping: it is finite-observation-time averaging.

## C. Theta-only Xi power sums

Using only the Jacobi-theta heat kernel before freeze,

\[
\psi(x)=\sum_{n\ge1}e^{-\pi n^2x},
\]

\[
\Xi(t)=\frac12-\left(\frac14+t^2\right)
\int_1^\infty \psi(x)x^{-3/4}
\cos\left(\frac t2\log x\right)dx.
\]

For

\[
G(x)=\frac{\Xi(\sqrt x)}{\Xi(0)},\qquad
\log G(x)=-\sum_{m\ge1}\frac{q_m}{m}x^m,
\]

180-digit arithmetic gave

- q1 = 0.02310499311541897078893381043033901400338
- q2 = 0.00003717259928526968616486626247174057845365
- q3 = 0.0000001441739314009732796953815560948209070369
- q4 = 0.0000000006630316802529908698732720819613572484737
- q5 = 0.000000000003213664150616601216102116599834655141563

The asymptotic moment ratio at order 50 is

\[
r=q_{50}/q_{49}=0.0050052441235941160438019024380735274\ldots
\]

and hence

\[
r^{-1/2}=14.13472514173469383988754560887\ldots.
\]

No zero ordinate was used in this calculation.

## D. Stieltjes positivity

Define the shifted normalized moments

\[
\mu_k=\frac{q_{k+1}}{q_1}.
\]

After support scaling by r for conditioning, both

\[
H_N=[\mu_{i+j}]_{i,j=0}^{N-1},\qquad
H_N^{(1)}=[\mu_{i+j+1}]_{i,j=0}^{N-1}
\]

were strictly positive through N=24 at 180 digits.

At N=24 the scaled minimum eigenvalues were approximately

- lambda_min(H_24) = 1.45375285874447e-65
- lambda_min(H_24^(1)) = 2.12253599871055e-67

The earlier apparent sign failure at order 18 under 100-digit arithmetic disappeared at higher precision and was numerical conditioning.

## E. 24-dimensional Jacobi reconstruction

The Stieltjes moment matrix gives a positive Jacobi multiplication matrix. Its largest nodes lambda_j map to candidate ordinates via gamma_j=lambda_j^{-1/2}.

Post-freeze scoring:

| j | Jacobi gamma | known gamma | absolute error |
|---:|---:|---:|---:|
| 1 | 14.13472514173469379045725 | 14.13472514173469379045725 | ~5.6e-64 |
| 2 | 21.02203963877155499262848 | 21.02203963877155499262848 | ~4.5e-45 |
| 3 | 25.01085758014568876321379 | 25.01085758014568876321379 | ~1.1e-36 |
| 4 | 30.42487612585951321031190 | 30.42487612585951321031190 | ~5.0e-27 |
| 5 | 32.93506158773918969066240 | 32.93506158773918969066237 | ~3.0e-23 |
| 6 | 37.58617815882567128289837 | 37.58617815882567125721776 | ~2.6e-17 |
| 7 | 40.91871901214779049162346 | 40.91871901214749518739813 | ~3.0e-13 |
| 8 | 43.32707328097231220024606 | 43.32707328091499951949612 | ~5.7e-11 |
| 9 | 48.00515185362781807195744 | 48.00515088116715972794247 | ~9.7e-7 |
| 10 | 49.77385651887179534528257 | 49.77383247767230218191678 | ~2.4e-5 |

This is not an independent zero predictor: the construction uses the theta representation of Xi itself. Its significance is operator reconstruction without inserting zero ordinates.

## F. Self-weight / unit-multiplicity diagnostic

Let w_j be the spectral weight of the Jacobi node lambda_j at the cyclic vector e0. For the desired trace-class determinant operator, the shifted moment measure should satisfy

\[
w_j=\frac{\lambda_j}{q_1}
\]

for simple unit-multiplicity eigenvalues. Equivalently

\[
M_j=\frac{q_1 w_j}{\lambda_j}=1.
\]

For the 24-dimensional reconstruction, the leading ratios are

1. 1 + 4.3e-63
2. 1 + 2.5e-44
3. 1 + 4.7e-36
4. 1 + 2.1e-26
5. 1 + 8.5e-23
6. 1 + 7.8e-17
7. 1 + 8.0e-13
8. 1 + 9.5e-11
9. 1 + 2.6e-6
10. 1 + 2.3e-5
11. 1 + 8.9e-4
12. 1 + 3.57e-2

The leading nodes therefore exhibit the exact self-weight law expected from a simple trace-class spectrum, to the accuracy at which the finite Gaussian quadrature has resolved those atoms.

## G. New theorem target

The computation points to a sharper route to the Fredholm identity. Prove from ROT/theta data, without zero ordinates, that:

1. the full sequence q_m is a Stieltjes trace-moment sequence;
2. the corresponding shifted measure is determinate and pure point on (0,infinity), accumulating only at zero;
3. every atom obeys the self-weight law mu({lambda})=lambda/q1 (or integer multiples for multiplicity);
4. sum lambda < infinity.

Then the positive compact operator K with eigenvalues lambda_j satisfies

\[
\operatorname{Tr}K^m=q_m
\]

for every m>=1, and therefore near zero

\[
\log\det(I-xK)=-\sum_{m\ge1}\frac{q_m}{m}x^m
=\log\frac{\Xi(\sqrt x)}{\Xi(0)}.
\]

Analytic continuation then gives the exact Fredholm identity globally.

The prime-side result suggests that the successful Riesz-1 boundary law should be interpreted as a Cesaro average over finite recursive-clock horizons, while the safe-half-plane transfer operator supplies the exact Euler-product determinant structure.
