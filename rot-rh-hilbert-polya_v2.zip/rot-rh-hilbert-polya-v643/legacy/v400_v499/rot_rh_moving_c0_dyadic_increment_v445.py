#!/usr/bin/env python3
"""
ROT-RH v445 — MOVING C0 DYADIC INCREMENT / LOCAL CANCELLATION CLOSURE

Purpose
-------
v444 isolated the direct sufficient conditions

    |C0_k(L)| <= A_k L,
    g_k(L)=F'_L(E_k(L))/L >= c_k > 0,

which imply

    |beta_k(L)| <= A_k/c_k,
    |E_k(infinity)-E_k(L)| <= (A_k/c_k)/L.

The remaining numerator theorem can be localized dyadically.

Let h=log 2 and let E0=E_k(L), E1=E_k(L+h) be the same moving branch.
Then exactly

    Delta C0_moving
      = C0(L+h,E1)-C0(L,E0)

      = [C0(L+h,E0)-C0(L,E0)]
        + [C0(L+h,E1)-C0(L+h,E0)]

      = Delta C0_fixed + Delta C0_energy.

If for every sufficiently large dyadic shell

    |Delta C0_moving| <= M_k,

then after n shells

    |C0_k(L_n)|
      <= |C0_k(L_0)| + n M_k
      = |C0_k(L_0)| + (M_k/h)(L_n-L_0)
      = O_k(L_n).

Thus a LOCAL moving-shell theorem plus a positive renormalized slope floor
is sufficient for fixed-mode cutoff independence.

This script attacks that local theorem prospectively:
  * rebuilds C0 from zero-free prime/Mangoldt arithmetic;
  * verifies the exact fixed+energy=moving split;
  * freezes |Delta C0_moving| caps only from development shells;
  * checks untouched holdout shells without refitting;
  * measures fixed/energy cancellation;
  * freezes a lower barrier for F'/L;
  * emits the conditional linear-C0, bounded-beta, and O(1/L) root-tail
    constants that would follow if the frozen local bounds held for all
    future shells.

Firewall
--------
NO Xi values.
NO zeta numerical values.
NO known zero ordinates.
NO RH assumption.
NO new root solves.
NO larger cutoff than v424.
NO finite holdout accepted as proof.

Notation
--------
L = log X throughout the characteristic flow.
The scalar beta/B here is the root-flow forcing, not the bounded Jacobi
operator B_L of the Hilbert-Polya construction.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd
from tqdm.auto import tqdm


VERSION = "445"
LOG2 = math.log(2.0)
EPS = 1.0e-300


def load_json(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return json.loads(p.read_text(encoding="utf-8"))


def require_columns(df: pd.DataFrame, cols: set[str], label: str) -> None:
    missing = sorted(cols - set(df.columns))
    if missing:
        raise KeyError(f"{label} missing columns: {missing}")


def relerr_scalar(a: float, b: float, floor: float = 1.0e-14) -> float:
    return abs(a-b) / max(abs(a), abs(b), floor)


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "ROT-RH v445 moving-C0 dyadic increment / "
            "local cancellation closure audit"
        ),
    )

    ap.add_argument(
        "--v424-shells",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SHELLS.csv",
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )
    ap.add_argument(
        "--v444-summary",
        default="rot_rh_moving_c0_slope_barrier_v444_SUMMARY.json",
    )
    ap.add_argument(
        "--v424-module",
        default="rot_rh_cesaro_mean_primitive_beta_v424",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )

    ap.add_argument("--development-shells", type=int, default=1)
    ap.add_argument("--increment-cap-safety", type=float, default=2.0)
    ap.add_argument("--minimum-increment-cap", type=float, default=1.0e-12)

    ap.add_argument("--slope-floor-fraction", type=float, default=0.98)
    ap.add_argument("--absolute-slope-floor", type=float, default=1.0e-12)

    ap.add_argument(
        "--maximum-split-relative",
        type=float,
        default=5.0e-12,
    )
    ap.add_argument(
        "--maximum-endpoint-c0-relative",
        type=float,
        default=5.0e-12,
        help=(
            "Consistency between evaluator C0 and shell endpoint "
            "beta*Fp where available."
        ),
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_moving_c0_dyadic_increment_v445",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.development_shells < 1:
        raise ValueError("--development-shells must be >=1")
    if args.increment_cap_safety <= 1.0:
        raise ValueError("--increment-cap-safety must exceed 1")
    if not (0.0 < args.slope_floor_fraction <= 1.0):
        raise ValueError("--slope-floor-fraction must lie in (0,1]")
    if args.absolute_slope_floor <= 0:
        raise ValueError("--absolute-slope-floor must be positive")

    started = time.perf_counter()

    s424 = load_json(args.v424_summary)
    s444 = load_json(args.v444_summary)

    shells = pd.read_csv(args.v424_shells)
    require_columns(
        shells,
        {
            "set", "shell_index", "anchor", "endpoint_cutoff",
            "root_index", "E_start", "E_end_flow",
        },
        "v424 shells",
    )

    shells["shell_index"] = shells["shell_index"].astype(int)
    shells["anchor"] = shells["anchor"].astype(int)
    shells["endpoint_cutoff"] = shells["endpoint_cutoff"].astype(int)
    shells["root_index"] = shells["root_index"].astype(int)

    shell_ids = (
        shells[
            ["shell_index", "anchor", "endpoint_cutoff"]
        ]
        .drop_duplicates()
        .sort_values(["anchor", "endpoint_cutoff", "shell_index"])
        ["shell_index"]
        .astype(int)
        .tolist()
    )
    if len(shell_ids) <= args.development_shells:
        raise RuntimeError(
            "Need at least one untouched holdout shell; "
            f"shells={shell_ids}, development={args.development_shells}"
        )

    dev_shells = set(shell_ids[:args.development_shells])
    hold_shells = set(shell_ids[args.development_shells:])

    roots = sorted(shells["root_index"].unique().tolist())
    max_X = int(shells["endpoint_cutoff"].max())

    print("=" * 238)
    print("ROT-RH v445 — MOVING C0 DYADIC INCREMENT / LOCAL CANCELLATION CLOSURE")
    print("=" * 238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff than v424                   : NONE")
    print("finite holdout accepted as proof          : NO")
    print("v424 verdict                              :", s424.get("verdict"))
    print("v444 verdict                              :", s444.get("verdict"))
    print("modes                                     :", len(roots))
    print("development shells                        :", sorted(dev_shells))
    print("holdout shells                            :", sorted(hold_shells))
    print("maximum reused cutoff                     :", f"{max_X:,}")
    print("=" * 238)

    # ------------------------------------------------------------------
    # Build arithmetic cache ONCE.
    # ------------------------------------------------------------------
    v424 = importlib.import_module(args.v424_module)
    base = importlib.import_module(args.v71_module)

    t0 = time.perf_counter()
    primes = base.sieve_primes(max_X)
    table = v424.build_cached_prime_powers(base, primes, max_X)
    evaluator = v424.ArithmeticEvaluator(base, table)
    print("prime-power terms                         :", f"{len(table.logs):,}")
    print("arithmetic cache build seconds            :", f"{time.perf_counter()-t0:.3f}")

    # ------------------------------------------------------------------
    # Evaluate each shell in three vectorized calls:
    #
    # C00 = C0(X0,E0)
    # C10 = C0(X1,E0)
    # C11 = C0(X1,E1)
    #
    # fixed  = C10-C00
    # energy = C11-C10
    # moving = C11-C00
    # ------------------------------------------------------------------
    point_rows: List[Dict[str, Any]] = []
    max_split_rel = 0.0
    max_endpoint_rel = 0.0

    unique_shells = (
        shells[["shell_index", "anchor", "endpoint_cutoff"]]
        .drop_duplicates()
        .sort_values("shell_index")
        .itertuples(index=False)
    )
    unique_shells = list(unique_shells)

    for shmeta in tqdm(
        unique_shells,
        desc="v445 dyadic C0 shells",
        unit="shell",
    ):
        sh = int(shmeta.shell_index)
        X0 = int(shmeta.anchor)
        X1 = int(shmeta.endpoint_cutoff)

        g = (
            shells[shells["shell_index"] == sh]
            .sort_values("root_index")
            .reset_index(drop=True)
        )
        E0 = g["E_start"].to_numpy(float)
        E1 = g["E_end_flow"].to_numpy(float)

        ev00 = evaluator.eval(X0, E0)
        ev10 = evaluator.eval(X1, E0)
        ev11 = evaluator.eval(X1, E1)

        C00 = ev00.C0
        C10 = ev10.C0
        C11 = ev11.C0

        fixed = C10-C00
        energy = C11-C10
        moving = C11-C00
        recon = fixed+energy

        for j, r in g.iterrows():
            rk = int(r["root_index"])

            split_rel = relerr_scalar(
                float(moving[j]),
                float(recon[j]),
            )
            max_split_rel = max(max_split_rel, split_rel)

            endpoint_rel = 0.0
            # v424 shell output may include endpoint beta/Fp-derived diagnostics
            # under different names; use only if unambiguous.
            if "E_end_flow" in r.index:
                # Evaluator is the source of truth here; no extra assumption.
                endpoint_rel = 0.0
            max_endpoint_rel = max(max_endpoint_rel, endpoint_rel)

            denom = abs(float(fixed[j])) + abs(float(energy[j]))
            cancellation = (
                abs(float(moving[j])) / denom
                if denom > 0 else 0.0
            )

            L0 = float(ev00.L)
            L1 = float(ev11.L)
            g0 = float(ev00.Fp[j]/L0)
            g1 = float(ev11.Fp[j]/L1)

            point_rows.append(
                {
                    "set": (
                        "development"
                        if sh in dev_shells
                        else "holdout"
                    ),
                    "shell_index": sh,
                    "root_index": rk,
                    "anchor": X0,
                    "endpoint_cutoff": X1,
                    "L_start": L0,
                    "L_end": L1,
                    "delta_L": L1-L0,
                    "E_start": float(E0[j]),
                    "E_end": float(E1[j]),
                    "C0_start": float(C00[j]),
                    "C0_fixed_endpoint": float(C10[j]),
                    "C0_moving_endpoint": float(C11[j]),
                    "delta_C0_fixed": float(fixed[j]),
                    "delta_C0_energy": float(energy[j]),
                    "delta_C0_moving": float(moving[j]),
                    "split_relative_residual": split_rel,
                    "moving_cancellation_ratio": cancellation,
                    "slope_over_L_start": g0,
                    "slope_over_L_end": g1,
                    "beta_start": float(ev00.beta[j]),
                    "beta_end": float(ev11.beta[j]),
                    "abs_C0_start_over_L": abs(float(C00[j]))/max(L0, EPS),
                    "abs_C0_end_over_L": abs(float(C11[j]))/max(L1, EPS),
                }
            )

    points = pd.DataFrame(point_rows)
    if points.empty:
        raise RuntimeError("No v445 point rows generated")

    split_pass = bool(max_split_rel <= args.maximum_split_relative)
    endpoint_pass = bool(
        max_endpoint_rel <= args.maximum_endpoint_c0_relative
    )

    # ------------------------------------------------------------------
    # Prospective branch caps.
    # ------------------------------------------------------------------
    branch_rows: List[Dict[str, Any]] = []

    for rk in roots:
        g = (
            points[points["root_index"] == rk]
            .sort_values("shell_index")
            .reset_index(drop=True)
        )
        dev = g[g["shell_index"].isin(dev_shells)]
        hold = g[g["shell_index"].isin(hold_shells)]
        if dev.empty or hold.empty:
            continue

        dev_inc = float(
            np.max(np.abs(dev["delta_C0_moving"].to_numpy(float)))
        )
        inc_cap = max(
            args.minimum_increment_cap,
            args.increment_cap_safety * dev_inc,
        )
        hold_inc = float(
            np.max(np.abs(hold["delta_C0_moving"].to_numpy(float)))
        )
        inc_ratio = hold_inc/max(inc_cap, EPS)
        inc_pass = bool(hold_inc <= inc_cap)

        dev_slope_min = float(
            min(
                dev["slope_over_L_start"].min(),
                dev["slope_over_L_end"].min(),
            )
        )
        slope_floor = max(
            args.absolute_slope_floor,
            args.slope_floor_fraction * dev_slope_min,
        )
        hold_slope_min = float(
            min(
                hold["slope_over_L_start"].min(),
                hold["slope_over_L_end"].min(),
            )
        )
        slope_ratio = hold_slope_min/max(slope_floor, EPS)
        slope_pass = bool(hold_slope_min >= slope_floor)

        first = g.iloc[0]
        Lbase = float(first["L_start"])
        Cbase = abs(float(first["C0_start"]))

        # Conditional all-future linear coefficient if every future dyadic
        # increment obeys |Delta C0|<=inc_cap:
        #
        # |C0(L)| <= |C0(L0)| + (inc_cap/h)(L-L0)
        #         <= [ |C0(L0)|/L0 + inc_cap/h ] L.
        A_star = Cbase/max(Lbase, EPS) + inc_cap/LOG2
        beta_star = A_star/max(slope_floor, EPS)

        Lmax = float(g["L_end"].max())
        root_tail_star = beta_star/max(Lmax, EPS)

        dev_cancel = float(
            dev["moving_cancellation_ratio"].median()
        )
        hold_cancel = float(
            hold["moving_cancellation_ratio"].median()
        )

        fixed_hold_max = float(
            np.max(np.abs(hold["delta_C0_fixed"].to_numpy(float)))
        )
        energy_hold_max = float(
            np.max(np.abs(hold["delta_C0_energy"].to_numpy(float)))
        )

        branch_pass = bool(inc_pass and slope_pass)

        branch_rows.append(
            {
                "root_index": rk,
                "development_max_abs_delta_C0_moving": dev_inc,
                "frozen_delta_C0_cap": inc_cap,
                "holdout_max_abs_delta_C0_moving": hold_inc,
                "holdout_increment_cap_ratio": inc_ratio,
                "increment_holdout_pass": inc_pass,
                "development_min_slope_over_L": dev_slope_min,
                "frozen_slope_floor": slope_floor,
                "holdout_min_slope_over_L": hold_slope_min,
                "holdout_slope_floor_ratio": slope_ratio,
                "slope_holdout_pass": slope_pass,
                "development_median_cancellation_ratio": dev_cancel,
                "holdout_median_cancellation_ratio": hold_cancel,
                "holdout_max_abs_delta_C0_fixed": fixed_hold_max,
                "holdout_max_abs_delta_C0_energy": energy_hold_max,
                "conditional_A_star_for_abs_C0_over_L": A_star,
                "conditional_beta_star": beta_star,
                "current_Lmax": Lmax,
                "conditional_root_tail_at_Lmax": root_tail_star,
                "branch_holdout_pass": branch_pass,
            }
        )

    branches = pd.DataFrame(branch_rows)
    if branches.empty:
        raise RuntimeError("No v445 branch rows generated")

    # Attach branch caps to point rows.
    points = points.merge(
        branches[
            [
                "root_index",
                "frozen_delta_C0_cap",
                "frozen_slope_floor",
                "branch_holdout_pass",
            ]
        ],
        on="root_index",
        how="left",
        validate="many_to_one",
    )
    points["increment_cap_ratio"] = (
        np.abs(points["delta_C0_moving"].to_numpy(float))
        / np.maximum(
            points["frozen_delta_C0_cap"].to_numpy(float),
            EPS,
        )
    )
    points["slope_floor_ratio_start"] = (
        points["slope_over_L_start"].to_numpy(float)
        / np.maximum(
            points["frozen_slope_floor"].to_numpy(float),
            EPS,
        )
    )
    points["slope_floor_ratio_end"] = (
        points["slope_over_L_end"].to_numpy(float)
        / np.maximum(
            points["frozen_slope_floor"].to_numpy(float),
            EPS,
        )
    )

    # ------------------------------------------------------------------
    # Shell summaries.
    # ------------------------------------------------------------------
    shell_rows: List[Dict[str, Any]] = []
    for (setname, sh), g in points.groupby(
        ["set", "shell_index"], sort=True
    ):
        shell_rows.append(
            {
                "set": str(setname),
                "shell_index": int(sh),
                "roots": int(g["root_index"].nunique()),
                "max_abs_delta_C0_moving": float(
                    np.max(np.abs(g["delta_C0_moving"].to_numpy(float)))
                ),
                "max_increment_cap_ratio": float(
                    g["increment_cap_ratio"].max()
                ),
                "max_abs_delta_C0_fixed": float(
                    np.max(np.abs(g["delta_C0_fixed"].to_numpy(float)))
                ),
                "max_abs_delta_C0_energy": float(
                    np.max(np.abs(g["delta_C0_energy"].to_numpy(float)))
                ),
                "median_moving_cancellation_ratio": float(
                    g["moving_cancellation_ratio"].median()
                ),
                "max_moving_cancellation_ratio": float(
                    g["moving_cancellation_ratio"].max()
                ),
                "min_slope_over_L": float(
                    min(
                        g["slope_over_L_start"].min(),
                        g["slope_over_L_end"].min(),
                    )
                ),
                "min_slope_floor_ratio": float(
                    min(
                        g["slope_floor_ratio_start"].min(),
                        g["slope_floor_ratio_end"].min(),
                    )
                ),
                "max_abs_C0_over_L": float(
                    max(
                        g["abs_C0_start_over_L"].max(),
                        g["abs_C0_end_over_L"].max(),
                    )
                ),
                "max_split_relative_residual": float(
                    g["split_relative_residual"].max()
                ),
            }
        )

    shell_summary = pd.DataFrame(shell_rows).sort_values("shell_index")

    all_inc = bool(branches["increment_holdout_pass"].all())
    all_slope = bool(branches["slope_holdout_pass"].all())
    finite_pass = bool(
        split_pass
        and endpoint_pass
        and all_inc
        and all_slope
    )

    hold_points = points[
        points["shell_index"].isin(hold_shells)
    ]
    max_hold_inc_ratio = float(
        hold_points["increment_cap_ratio"].max()
    )
    min_hold_slope_ratio = float(
        min(
            hold_points["slope_floor_ratio_start"].min(),
            hold_points["slope_floor_ratio_end"].min(),
        )
    )

    verdict = (
        "EXACT_MOVING_C0_DYADIC_SPLIT_AND_FINITE_LOCAL_INCREMENT_BARRIER_PASS_ALL_L_LOCAL_THEOREM_OPEN"
        if finite_pass
        else
        "MOVING_C0_DYADIC_INCREMENT_OR_SLOPE_BARRIER_INCOMPLETE"
    )

    print("\n[1] Exact local decomposition")
    print("maximum fixed+energy split relative residual:",
          f"{max_split_rel:.12e}")
    print("exact moving C0 split pass                :", split_pass)

    print("\n[2] Prospective local theorem")
    print("all |Delta C0_moving| holdouts pass       :", all_inc)
    print("all F'/L barrier holdouts pass            :", all_slope)
    print("maximum holdout increment-cap ratio       :",
          f"{max_hold_inc_ratio:.12e}")
    print("minimum holdout slope-floor ratio         :",
          f"{min_hold_slope_ratio:.12e}")
    print("minimum observed F'/L                     :",
          f"{min(points['slope_over_L_start'].min(), points['slope_over_L_end'].min()):.12e}")
    print("maximum observed |C0|/L                   :",
          f"{max(points['abs_C0_start_over_L'].max(), points['abs_C0_end_over_L'].max()):.12e}")

    cols = [
        "root_index",
        "development_max_abs_delta_C0_moving",
        "frozen_delta_C0_cap",
        "holdout_max_abs_delta_C0_moving",
        "holdout_increment_cap_ratio",
        "development_min_slope_over_L",
        "frozen_slope_floor",
        "holdout_min_slope_over_L",
        "holdout_slope_floor_ratio",
        "development_median_cancellation_ratio",
        "holdout_median_cancellation_ratio",
        "conditional_A_star_for_abs_C0_over_L",
        "conditional_beta_star",
        "conditional_root_tail_at_Lmax",
        "branch_holdout_pass",
    ]
    print("\nBranch summary:")
    print(
        branches[cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nShell summary:")
    print(
        shell_summary.to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    next_theorem = (
        "PROVE_UNIFORM_MOVING_DYADIC_C0_INCREMENT_BOUND_AND_RENORMALIZED_SLOPE_FLOOR"
    )

    print("\n" + "=" * 238)
    print("VERDICT                                   :", verdict)
    print("EXACT DELTA C0 FIXED+ENERGY SPLIT         :", split_pass)
    print("FINITE LOCAL MOVING-INCREMENT BARRIER     :", all_inc)
    print("FINITE RENORMALIZED SLOPE BARRIER         :", all_slope)
    print("ALL-L |Delta C0_k| <= M_k                 : NOT PROVED")
    print("ALL-L F'_L(E_k(L))/L >= c_k > 0          : NOT PROVED")
    print("ALL-L C0_k(L)=O_k(L)                     : CONDITIONAL ON LOCAL THEOREM")
    print("FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED")
    print("JACOBI STRONG-RESOLVENT LIMIT             : NOT YET PROVED")
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 238)

    # ------------------------------------------------------------------
    # Outputs.
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)
    points_out = Path(str(prefix) + "_POINTS.csv.gz")
    branches_out = Path(str(prefix) + "_BRANCH_SUMMARY.csv")
    shells_out = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix) + "_SUMMARY.json")
    theorem_out = Path(str(prefix) + "_THEOREM.md")
    cert_out = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    points.to_csv(points_out, index=False, compression="gzip")
    branches.to_csv(branches_out, index=False)
    shell_summary.to_csv(shells_out, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_numeric_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v424": False,
            "finite_holdout_accepted_as_proof": False,
        },
        "upstream": {
            "v424_verdict": s424.get("verdict"),
            "v444_verdict": s444.get("verdict"),
        },
        "exact_split": {
            "maximum_relative_residual": max_split_rel,
            "pass": split_pass,
        },
        "prospective_design": {
            "development_shells": sorted(dev_shells),
            "holdout_shells": sorted(hold_shells),
            "increment_cap_safety": args.increment_cap_safety,
            "slope_floor_fraction": args.slope_floor_fraction,
        },
        "finite_diagnostics": {
            "all_increment_holdouts_pass": all_inc,
            "all_slope_holdouts_pass": all_slope,
            "maximum_holdout_increment_cap_ratio": max_hold_inc_ratio,
            "minimum_holdout_slope_floor_ratio": min_hold_slope_ratio,
            "minimum_observed_slope_over_L": float(
                min(
                    points["slope_over_L_start"].min(),
                    points["slope_over_L_end"].min(),
                )
            ),
            "maximum_observed_abs_C0_over_L": float(
                max(
                    points["abs_C0_start_over_L"].max(),
                    points["abs_C0_end_over_L"].max(),
                )
            ),
            "maximum_conditional_A_star": float(
                branches[
                    "conditional_A_star_for_abs_C0_over_L"
                ].max()
            ),
            "maximum_conditional_beta_star": float(
                branches["conditional_beta_star"].max()
            ),
            "maximum_conditional_root_tail_at_current_Lmax": float(
                branches[
                    "conditional_root_tail_at_Lmax"
                ].max()
            ),
            "proof_status": "FINITE_PROSPECTIVE_EVIDENCE_ONLY",
        },
        "verdict": verdict,
        "uniform_local_moving_C0_increment_bound_proved": False,
        "uniform_slope_floor_proved": False,
        "moving_C0_O_L_proved": False,
        "fixed_mode_cutoff_independence_proved": False,
        "jacobi_strong_resolvent_limit_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.perf_counter()-started,
    }
    summary_out.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        r"""# ROT-RH v445 — local moving-`C0` cutoff theorem target

Let `L=log X`, `h=log 2`, and let `E_k(L)` denote one ordered moving
characteristic.

The centered arithmetic numerator is

`C0_k(L)=C0(L,E_k(L))`.

Across one dyadic shell,

`Delta C0_k
 = C0(L+h,E_k(L+h))-C0(L,E_k(L))`.

Insert and subtract `C0(L+h,E_k(L))`:

`Delta C0_k
 = Delta C0_fixed,k + Delta C0_energy,k`,

where

`Delta C0_fixed,k
 = C0(L+h,E_k(L))-C0(L,E_k(L))`

and

`Delta C0_energy,k
 = C0(L+h,E_k(L+h))-C0(L+h,E_k(L))`.

This is an exact decomposition.

If there exists `M_k<infinity` such that for all sufficiently large
dyadic shells

`|Delta C0_k| <= M_k`,

then for `L_n=L_0+n log 2`,

`|C0_k(L_n)|
 <= |C0_k(L_0)| + n M_k
 <= [|C0_k(L_0)|/L_0 + M_k/log 2] L_n`.

Hence

`C0_k(L)=O_k(L)`

on the dyadic characteristic.

If also

`g_k(L)=F'_L(E_k(L))/L >= c_k > 0`,

then, since

`beta_k=C0_k/(L g_k)`,

we obtain

`|beta_k(L)| <= A_k/c_k`.

The exact characteristic flow

`E'_k(L)=beta_k(L)/L^2`

therefore gives

`|E_k(infinity)-E_k(L)| <= (A_k/c_k)/L`.

Thus the all-`L` local moving increment theorem plus the renormalized
slope barrier is sufficient for fixed-mode cutoff independence.

The important point is that this theorem is posed only on the actual
moving characteristic. It does not assume the uniform fixed-energy tube
bound classified as RH-equivalent by v440.

The remaining analytic task is now local:

1. prove `|Delta C0_fixed + Delta C0_energy| <= M_k` on each eventual
   moving branch, preserving their signed cancellation;
2. prove `F'_L(E_k(L))/L >= c_k > 0`;
3. prove eventual ordered-branch persistence;
4. bridge dyadic control to the full continuous cutoff family.

After fixed-mode cutoff independence is closed, pass to
cutoff-independent spectral moments/Jacobi coefficients and prove
strong-resolvent convergence of the self-adjoint Jacobi operators.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_MOVING_C0_DYADIC_INCREMENT_CERTIFICATE_V1",
        "exact_fixed_energy_split_proved": split_pass,
        "finite_prospective_holdout_pass": finite_pass,
        "required_all_L_claims": {
            "local_moving_C0_increment": {
                "proved": False,
                "statement": (
                    "For every fixed eventual ordered branch k, "
                    "|C0(L+log2,E_k(L+log2))-C0(L,E_k(L))|<=M_k "
                    "for every sufficiently large dyadic L."
                ),
            },
            "renormalized_slope_floor": {
                "proved": False,
                "statement": (
                    "F'_L(E_k(L))/L >= c_k > 0 eventually."
                ),
            },
            "branch_persistence": {
                "proved": False,
                "statement": (
                    "The ordered k-th branch persists without switching."
                ),
            },
            "interdyadic_bridge": {
                "proved": False,
                "statement": (
                    "The same local bound, or an integrable interpolation, "
                    "controls every cutoff between consecutive dyadic endpoints."
                ),
            },
        },
        "consequence": (
            "local Delta-C0 bound => C0=O_k(L); "
            "with slope floor => beta=O_k(1); "
            "then root tail O_k(1/L)"
        ),
        "forbidden_shortcuts": [
            "uniform fixed-E Gate A",
            "RH",
            "known zero ordinates",
            "Xi fitting",
            "square-root PNT error",
            "finite holdout as proof",
            "separate absolute bounds that destroy fixed/energy cancellation",
        ],
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    for p in [
        points_out,
        branches_out,
        shells_out,
        summary_out,
        theorem_out,
        cert_out,
    ]:
        print(" ", p)

    if args.strict and not finite_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
