# ROT-RH v491 — half-plane gap / fixed winding class

Write the normalized collision-subtracted regular multiplier on one moving
boundary as

`U(L)=R(L)/|R(L)|=exp(i*pi*epsilon(L))`

with `epsilon(L)` chosen as a continuous **unwrapped** normalized phase.

Assume a strict half-plane gap

`|Re U(L)| >= h > 0`

for all sufficiently large `L`.

By v465,

`dist(epsilon(L), Z+1/2) >= d`,
`d=asin(h)/pi > 0`.

The complement of the `d`-neighborhood of the bad half-integers is the disjoint
union

`union_(n in Z) [n-1/2+d, n+1/2-d]`.

Because `epsilon(L)` is continuous on a connected tail interval, it cannot move
from one component to another without crossing a bad half-integer neighborhood.
Hence there exists **one fixed integer** `n_*` such that

`|epsilon(L)-n_*| <= 1/2-d`

for every sufficiently large `L`.

So eventual half-plane avoidance is not merely a statement modulo `pi`: it
forbids all future integer winding of the unwrapped boundary phase.

For the two v470 boundaries `u=+U` and `u=-U`, simultaneous half-plane gaps fix
two winding classes `n_+` and `n_-`.  The finite collision saturation error is

`2m(1+sqrt(pi))/(pi U)`

in normalized units.  Therefore the clean sufficient condition is

`2m(1+sqrt(pi))/(pi U) < asin(h)/pi`.

Equivalently,

`U > 2m(1+sqrt(pi))/asin(h)`.

Under that condition, the v470 two-boundary barrier traps the associated fixed
label:

`|E(L)-gamma| < U/L`.

### Consequence for the remaining nonattained sector

Any off-critical mechanism whose **unwrapped** boundary phase has arbitrarily
large winding cannot coexist with a strict v470 half-plane gap.  It must hit the
bad half-integer set infinitely often.

Thus the final boundary problem may be stated without asking for convergence to
the completed sign:

> prove either bounded fixed winding class on both moving boundaries, or prove
> that every nonattained off-critical collective mechanism necessarily develops
> unbounded boundary winding / bad half-integer crossings.

The second alternative is now the natural contradiction target after v490,
because beta-reflection does not cancel the additive bump phase.

**Verdict:** `EXACT_HALFPLANE_FIXED_WINDING_CLASS_PASS`.

This theorem is topological/elementary.  It does not itself prove the required
half-plane gap or exclude the nonattained many-mode cancellation.
