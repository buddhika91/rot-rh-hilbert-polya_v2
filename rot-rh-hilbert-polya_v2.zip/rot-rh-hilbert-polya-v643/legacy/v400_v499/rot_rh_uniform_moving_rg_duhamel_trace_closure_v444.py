#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v444 — UNIFORM MOVING-RG / DUHAMEL TRACE-CLOSURE ATTACK
==============================================================

This is a theorem-facing, zero-blind postprocessor of an EXISTING arithmetic
root family.  It does not rebuild a different finite-cutoff phase.

Why v444 exists
---------------
v443 showed that the uniform dyadic step

    |E_k(L+h)-E_k(L)| <= C_E/[L(L+h)],   h=log 2,

is enough to obtain:
    * uniform free-level displacement,
    * the uniform inverse-square trace tail,
    * and, with modewise convergence, trace-norm cutoff removal.

The original v438 route obtained this through a whole-segment MVT floor.
v444 records a cleaner moving-characteristic route that makes the whole-segment
floor unnecessary.

Exact moving characteristic
---------------------------
For a Riesz/log-Cesaro phase satisfying

    partial_L F(L,E) = -C0(L,E)/L^2,

on an ordered quantized branch F(L,E_k(L))=constant,

    E_k'(L) = B_k(L)/L^2,
    B_k(L)  = C0(L,E_k(L))/F_E(L,E_k(L)).

Define the root-point stiffness

    J_k(L) = F_E(L,E_k(L))

and the v425 RG coordinate

    kappa_k(L) = 1 + partial_E B_k(L)/L,
    Q_k(L)     = integral_(L0)^L kappa_k(s)/s ds.

Then EXACTLY

    J_k(L)/L
      = [J_k(L0)/L0] exp(-Q_k(L)).

Thus only an UPPER bound on Q is required for no-fold:

    Q_k(L) <= Q_*    for all k,L

implies

    J_k(L)/L >= c0 exp(-Q_*),

where

    c0 = inf_k J_k(L0)/L0 > 0.

Duhamel coordinate
------------------
Let

    Y_k(L) = L exp(-Q_k(L)) B_k(L).

In the smooth pieces,

    dY_k/dL = exp(-Q_k(L)) S_k(L),

where S=L partial_L B is the fixed-cutoff beta source evaluated on the moving
characteristic.  Because the arithmetic cutoff has prime jumps, the natural
theorem is measure/primitive valued, not a classical pointwise derivative.

A sufficient UNIFORM signed Duhamel theorem is:

    U_Q:
      sup_(k,L) Q_k(L) <= Q_* < infinity,

    U_D:
      |Y_k(L)-Y_k(L0)| <= M (L-L0)
      uniformly in k,L,

or, equivalently, for the distributional source dSigma_k,

      | integral_(L0,L] exp(-Q_k(s)) dSigma_k(s) | <= M (L-L0).

If also at one fixed reference cutoff

    B0 = sup_k |B_k(L0)| < infinity,

then

    |Y_k(L)| <= L0 B0 + M(L-L0) <= (B0+M)L,

and therefore

    |B_k(L)|
      = exp(Q_k(L)) |Y_k(L)|/L
      <= exp(Q_*) (B0+M)
      =: B_*.

This gives, WITHOUT a whole-segment MVT denominator,

    |E_k(L+h)-E_k(L)|
      <= B_* integral_L^(L+h) s^(-2) ds
      = B_* h/[L(L+h)].

So v443 U_STEP holds with C_E=h B_*.

Moreover

    |E_k(infinity)-E_k(L)| <= B_*/L,

so the same two moving-RG bounds also give fixed-mode convergence.  They do not
merely provide the high-mode tail.

What can be reconstructed from a native root table
---------------------------------------------------
If the table stores the phase derivative J_k(L), v425 gives the integrated RG
coordinate directly, without finite-differencing kappa:

    Q_k(L)
      = -log[
          (J_k(L)/L) / (J_k(L0)/L0)
        ].

For adjacent cutoffs La<Lb, the exact root displacement defines the weighted
effective beta

    B_eff(k;La,Lb)
      = [E_k(Lb)-E_k(La)] / [1/La - 1/Lb].

If E'=B/L^2 on that native phase, B_eff is the s^(-2)-weighted signed average
of B over the shell.  It obeys exactly

    La Lb |Delta E| = h |B_eff|

on a dyadic shell h=Lb-La=log 2.

IMPORTANT:
  * bounded B_eff on finite shells is evidence for the characteristic mechanism;
  * it is NOT a proof that pointwise B is bounded;
  * it is NOT a substitute for U_D;
  * the deep remaining analytic theorem is the signed Duhamel primitive U_D,
    together with the one-sided RG bound U_Q.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO new root solves.
NO alternate phase evaluator.
NO larger cutoffs.
NO finite holdout is accepted as proof.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v444 requires tqdm: pip install tqdm") from exc


VERSION = 444
LOG2 = math.log(2.0)
EE = math.e
EPS = 1.0e-300


def native(x):
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, list):
        return [native(v) for v in x]
    if isinstance(x, tuple):
        return [native(v) for v in x]
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, float) and not math.isfinite(x):
        return None
    return x


def canonicalize(df: pd.DataFrame) -> pd.DataFrame:
    aliases = {
        "cutoff": ["cutoff", "X", "xcut", "regulator"],
        "mode": ["index", "k", "mode", "root_index", "level"],
        "energy": ["energy", "E", "root", "eigenvalue"],
        "Fp": ["phase_derivative", "Fp", "Fprime", "phase_prime"],
    }
    out = df.copy()
    rename = {}
    for target, names in aliases.items():
        if target in out.columns:
            continue
        hit = next((c for c in names if c in out.columns), None)
        if hit is None:
            raise KeyError(
                f"Could not locate required column {target!r}; "
                f"columns={list(out.columns)}"
            )
        rename[hit] = target
    out = out.rename(columns=rename)

    for c in ["cutoff", "mode", "energy", "Fp"]:
        out[c] = pd.to_numeric(out[c], errors="coerce")

    good = (
        np.isfinite(out["cutoff"])
        & np.isfinite(out["mode"])
        & np.isfinite(out["energy"])
        & np.isfinite(out["Fp"])
        & (out["cutoff"] > 1)
        & (out["energy"] > 0)
        & (out["Fp"] > 0)
    )
    out = out[good].copy()
    out["cutoff"] = out["cutoff"].astype(np.int64)
    out["mode"] = out["mode"].astype(np.int64)

    out = (
        out.sort_values(["cutoff", "mode", "energy"])
        .drop_duplicates(["cutoff", "mode"], keep="first")
        .reset_index(drop=True)
    )
    return out


def cap_stats(values: np.ndarray, cap: float) -> Dict:
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return {
            "rows": 0,
            "maximum": float("nan"),
            "cap": float(cap),
            "margin": float("nan"),
            "failures": 0,
            "pass": False,
        }
    m = float(np.max(x))
    return {
        "rows": int(len(x)),
        "maximum": m,
        "cap": float(cap),
        "margin": float(cap / max(m, EPS)),
        "failures": int(np.sum(x > cap)),
        "pass": bool(np.all(x <= cap)),
    }


def floor_stats(values: np.ndarray, floor: float) -> Dict:
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return {
            "rows": 0,
            "minimum": float("nan"),
            "floor": float(floor),
            "margin": float("nan"),
            "failures": 0,
            "pass": False,
        }
    m = float(np.min(x))
    return {
        "rows": int(len(x)),
        "minimum": m,
        "floor": float(floor),
        "margin": float(m / max(floor, EPS)),
        "failures": int(np.sum(x < floor)),
        "pass": bool(np.all(x >= floor)),
    }


def tail_majorant(N: int, c: float = 1.0) -> float:
    if N < 3 or c <= 0:
        return float("inf")
    d = math.log1p(EE / float(N))
    u = math.log(float(N)) + d
    return (u*u + 2*u + 2) / (float(N) * c*c)


def symbolic_packet() -> Dict:
    """
    Record the exact implications. Sympy is optional; the theorem does not depend
    on numerical symbolic simplification.
    """
    packet = {
        "rg_identity": (
            "J_k(L)/L=[J_k(L0)/L0] exp(-Q_k(L))"
        ),
        "one_sided_Q_consequence": (
            "Q_k(L)<=Q* => J_k(L)/L>=c0 exp(-Q*)>0"
        ),
        "duhamel_coordinate": (
            "Y_k=L exp(-Q_k) B_k"
        ),
        "signed_duhamel_gate": (
            "|Y_k(L)-Y_k(L0)|<=M(L-L0)"
        ),
        "uniform_beta_bound": (
            "|B_k(L)|<=exp(Q*)[B0+M]=B*"
        ),
        "root_tail": (
            "|E_k(infinity)-E_k(L)|<=B*/L"
        ),
        "dyadic_step": (
            "|E_k(L+h)-E_k(L)|<=B*h/[L(L+h)]"
        ),
        "v443_constant": "C_E=h B*",
        "whole_segment_MVT_needed": False,
    }
    try:
        import sympy as sp

        L, h, B = sp.symbols("L h B", positive=True)
        integ = sp.integrate(sp.Symbol("s")**-2, (
            sp.Symbol("s"), L, L+h
        ))
        packet["sympy_integral_s_minus2"] = str(sp.simplify(integ))
        packet["sympy_pass"] = bool(
            sp.simplify(integ - h/(L*(L+h))) == 0
        )
    except Exception as exc:
        packet["sympy_pass"] = None
        packet["sympy_error"] = str(exc)
    return packet


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots",
        default="rot_rh_direct_riesz1_depth320_roots.csv",
        help="Native zero-blind root table with cutoff,index,energy,phase_derivative.",
    )
    ap.add_argument(
        "--development-pairs",
        type=int,
        default=3,
        help="Earliest dyadic transitions used to freeze cutoff-direction caps.",
    )
    ap.add_argument(
        "--development-mode-fraction",
        type=float,
        default=0.70,
        help="Lower fraction of modes used for independent mode-direction diagnostics.",
    )
    ap.add_argument(
        "--Q-cutoff-safety",
        type=float,
        default=1.75,
    )
    ap.add_argument(
        "--Q-mode-safety",
        type=float,
        default=2.00,
    )
    ap.add_argument(
        "--beta-effective-safety",
        type=float,
        default=1.25,
    )
    ap.add_argument(
        "--slope-floor-safety",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--dyadic-log-tol",
        type=float,
        default=5e-12,
    )
    ap.add_argument(
        "--quantization-residual-gate",
        type=float,
        default=1e-9,
    )
    ap.add_argument(
        "--tail-N-values",
        default="32,64,128,256,512,1024,4096,16384,65536",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_uniform_moving_rg_duhamel_trace_closure_v444",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if not (0 < args.development_mode_fraction < 1):
        raise ValueError("--development-mode-fraction must lie in (0,1)")
    if args.development_pairs < 1:
        raise ValueError("--development-pairs must be >=1")

    started = time.time()
    src = Path(args.roots)
    if not src.exists():
        raise FileNotFoundError(src)

    raw = pd.read_csv(src)
    df = canonicalize(raw)

    cutoffs = np.asarray(sorted(df["cutoff"].unique()), dtype=np.int64)
    modes = np.asarray(sorted(df["mode"].unique()), dtype=np.int64)
    if len(cutoffs) < args.development_pairs + 2:
        raise RuntimeError("Need at least one holdout cutoff after development.")
    if len(modes) < 10:
        raise RuntimeError("Too few modes for a uniform-mode diagnostic.")

    # Require a rectangular common mode panel. This avoids mode-selection leakage.
    common_modes = None
    for X in cutoffs:
        ms = set(df.loc[df["cutoff"] == X, "mode"].astype(int).tolist())
        common_modes = ms if common_modes is None else common_modes.intersection(ms)
    common_modes = np.asarray(sorted(common_modes), dtype=np.int64)
    if len(common_modes) == 0:
        raise RuntimeError("No modes common to all cutoffs.")

    df = df[df["mode"].isin(common_modes)].copy()
    modes = common_modes

    # ------------------------------------------------------------------
    # Native root-point RG reconstruction from the exact stored F'.
    # ------------------------------------------------------------------
    df["L"] = np.log(df["cutoff"].to_numpy(float))
    df["slope_over_L"] = df["Fp"].to_numpy(float) / df["L"].to_numpy(float)

    X0 = int(cutoffs[0])
    ref = (
        df[df["cutoff"] == X0]
        .set_index("mode")["slope_over_L"]
        .to_dict()
    )
    df["reference_slope_over_L"] = df["mode"].map(ref).astype(float)
    ratio = (
        df["slope_over_L"].to_numpy(float)
        / df["reference_slope_over_L"].to_numpy(float)
    )
    if np.any(~np.isfinite(ratio)) or np.any(ratio <= 0):
        raise RuntimeError("Nonpositive/nonfinite native stiffness ratio.")
    df["Q_native"] = -np.log(ratio)

    # Exact finite identity by construction:
    reconstructed = (
        df["reference_slope_over_L"].to_numpy(float)
        * np.exp(-df["Q_native"].to_numpy(float))
    )
    rg_identity_abs = float(
        np.max(np.abs(reconstructed - df["slope_over_L"].to_numpy(float)))
    )

    # ------------------------------------------------------------------
    # Adjacent dyadic root flow and weighted effective beta.
    # ------------------------------------------------------------------
    pair_rows: List[Dict] = []
    mode_rows: List[Dict] = []

    for pair_idx, (Xa, Xb) in enumerate(
        tqdm(
            list(zip(cutoffs[:-1], cutoffs[1:])),
            desc="Native moving-characteristic shells",
            unit="pair",
        )
    ):
        a = df[df["cutoff"] == Xa].set_index("mode")
        b = df[df["cutoff"] == Xb].set_index("mode")
        common = np.asarray(sorted(a.index.intersection(b.index)), dtype=np.int64)

        La = math.log(float(Xa))
        Lb = math.log(float(Xb))
        h = Lb-La
        denom = 1.0/La - 1.0/Lb

        Ea = a.loc[common, "energy"].to_numpy(float)
        Eb = b.loc[common, "energy"].to_numpy(float)
        dE = Eb-Ea
        B_eff = dE/denom
        scaled_step = np.abs(dE)*La*Lb

        Qa = a.loc[common, "Q_native"].to_numpy(float)
        Qb = b.loc[common, "Q_native"].to_numpy(float)

        for j, k in enumerate(common):
            mode_rows.append({
                "pair_index": int(pair_idx),
                "Xa": int(Xa),
                "Xb": int(Xb),
                "La": La,
                "Lb": Lb,
                "h": h,
                "mode": int(k),
                "Ea": float(Ea[j]),
                "Eb": float(Eb[j]),
                "delta_E": float(dE[j]),
                "B_effective_weighted": float(B_eff[j]),
                "abs_B_effective_weighted": float(abs(B_eff[j])),
                "scaled_step_LaLb_abs_deltaE": float(scaled_step[j]),
                "Q_start": float(Qa[j]),
                "Q_end": float(Qb[j]),
                "delta_Q": float(Qb[j]-Qa[j]),
                "slope_over_L_start": float(a.loc[k, "slope_over_L"]),
                "slope_over_L_end": float(b.loc[k, "slope_over_L"]),
            })

        pair_rows.append({
            "pair_index": int(pair_idx),
            "Xa": int(Xa),
            "Xb": int(Xb),
            "La": La,
            "Lb": Lb,
            "h": h,
            "dyadic_log_error": abs(h-LOG2),
            "common_modes": int(len(common)),
            "max_abs_delta_E": float(np.max(np.abs(dE))),
            "max_abs_B_effective": float(np.max(np.abs(B_eff))),
            "q99_abs_B_effective": float(np.quantile(np.abs(B_eff), 0.99)),
            "median_abs_B_effective": float(np.median(np.abs(B_eff))),
            "max_scaled_step": float(np.max(scaled_step)),
            "identity_max_scaled_minus_hBeff": float(
                np.max(np.abs(scaled_step - abs(h)*np.abs(B_eff)))
            ),
            "max_Q_end": float(np.max(Qb)),
            "min_slope_over_L_end": float(
                np.min(b.loc[common, "slope_over_L"].to_numpy(float))
            ),
        })

    pair_df = pd.DataFrame(pair_rows)
    mode_df = pd.DataFrame(mode_rows)

    dyadic = pair_df["dyadic_log_error"].to_numpy(float) <= args.dyadic_log_tol
    if not np.all(dyadic):
        raise RuntimeError("Adjacent cutoff chain is not purely dyadic.")

    ndev_pairs = min(int(args.development_pairs), len(pair_df)-1)
    dev_pair_ids = set(range(ndev_pairs))
    hold_pair_ids = set(range(ndev_pairs, len(pair_df)))

    ndev_modes = int(math.floor(args.development_mode_fraction * len(modes)))
    ndev_modes = max(1, min(ndev_modes, len(modes)-1))
    dev_modes = set(modes[:ndev_modes].tolist())
    high_modes = set(modes[ndev_modes:].tolist())

    # ------------------------------------------------------------------
    # Prospective cutoff-direction caps (all modes, early cutoffs only).
    # ------------------------------------------------------------------
    dev_pairs = pair_df[pair_df["pair_index"].isin(dev_pair_ids)]
    hold_pairs = pair_df[pair_df["pair_index"].isin(hold_pair_ids)]

    beta_train = float(dev_pairs["max_abs_B_effective"].max())
    beta_cap = args.beta_effective_safety * beta_train
    beta_hold = cap_stats(
        mode_df.loc[
            mode_df["pair_index"].isin(hold_pair_ids),
            "abs_B_effective_weighted",
        ].to_numpy(float),
        beta_cap,
    )

    # Q cutoff cap: reference + endpoints of development pairs, all modes.
    last_dev_cutoff_idx = ndev_pairs
    dev_cutoff_set = set(cutoffs[:last_dev_cutoff_idx+1].tolist())
    future_cutoff_set = set(cutoffs[last_dev_cutoff_idx+1:].tolist())

    Q_cut_train = float(
        np.max(
            np.maximum(
                df.loc[df["cutoff"].isin(dev_cutoff_set), "Q_native"].to_numpy(float),
                0.0,
            )
        )
    )
    Q_cut_cap = args.Q_cutoff_safety * Q_cut_train
    Q_future_stats = cap_stats(
        np.maximum(
            df.loc[df["cutoff"].isin(future_cutoff_set), "Q_native"].to_numpy(float),
            0.0,
        ),
        Q_cut_cap,
    )

    slope_dev_min = float(
        df.loc[df["cutoff"].isin(dev_cutoff_set), "slope_over_L"].min()
    )
    slope_floor = args.slope_floor_safety * slope_dev_min
    slope_future_stats = floor_stats(
        df.loc[df["cutoff"].isin(future_cutoff_set), "slope_over_L"].to_numpy(float),
        slope_floor,
    )

    # ------------------------------------------------------------------
    # Independent mode-direction diagnostic at early cutoffs.
    # ------------------------------------------------------------------
    early = df[df["cutoff"].isin(dev_cutoff_set)]
    Q_mode_train = float(
        np.max(
            np.maximum(
                early.loc[early["mode"].isin(dev_modes), "Q_native"].to_numpy(float),
                0.0,
            )
        )
    )
    Q_mode_cap = args.Q_mode_safety * Q_mode_train
    Q_highmode_stats = cap_stats(
        np.maximum(
            early.loc[early["mode"].isin(high_modes), "Q_native"].to_numpy(float),
            0.0,
        ),
        Q_mode_cap,
    )

    beta_mode_train = float(
        mode_df.loc[
            mode_df["pair_index"].isin(dev_pair_ids)
            & mode_df["mode"].isin(dev_modes),
            "abs_B_effective_weighted",
        ].max()
    )
    beta_mode_cap = args.beta_effective_safety * beta_mode_train
    beta_highmode_stats = cap_stats(
        mode_df.loc[
            mode_df["pair_index"].isin(dev_pair_ids)
            & mode_df["mode"].isin(high_modes),
            "abs_B_effective_weighted",
        ].to_numpy(float),
        beta_mode_cap,
    )

    # Future-high corner, evaluated against the cutoff-frozen caps.
    Q_corner_stats = cap_stats(
        np.maximum(
            df.loc[
                df["cutoff"].isin(future_cutoff_set)
                & df["mode"].isin(high_modes),
                "Q_native",
            ].to_numpy(float),
            0.0,
        ),
        Q_cut_cap,
    )
    beta_corner_stats = cap_stats(
        mode_df.loc[
            mode_df["pair_index"].isin(hold_pair_ids)
            & mode_df["mode"].isin(high_modes),
            "abs_B_effective_weighted",
        ].to_numpy(float),
        beta_cap,
    )

    # ------------------------------------------------------------------
    # Quantization / native data quality.
    # ------------------------------------------------------------------
    max_quant_resid = float("nan")
    quant_pass = True
    if "quantization_residual" in df.columns:
        qres = pd.to_numeric(
            df["quantization_residual"], errors="coerce"
        ).to_numpy(float)
        qres = np.abs(qres[np.isfinite(qres)])
        if len(qres):
            max_quant_resid = float(np.max(qres))
            quant_pass = bool(max_quant_resid <= args.quantization_residual_gate)

    min_slope_all = float(df["slope_over_L"].min())
    max_Q_all = float(df["Q_native"].max())
    min_Q_all = float(df["Q_native"].min())
    max_beta_eff_all = float(mode_df["abs_B_effective_weighted"].max())
    max_scaled_all = float(mode_df["scaled_step_LaLb_abs_deltaE"].max())

    # If a future analytic U_D gives M and reference B0, the theorem constant is
    # B*=exp(Q*)[B0+M]. We do not fabricate M from this table.
    theorem = symbolic_packet()

    gates = {
        "quantization_residuals_small": quant_pass,
        "native_RG_reconstruction_identity": bool(rg_identity_abs <= 5e-14),
        "all_native_root_slopes_positive": bool(min_slope_all > 0),
        "future_cutoff_Q_holdout": bool(Q_future_stats["pass"]),
        "early_high_mode_Q_holdout": bool(Q_highmode_stats["pass"]),
        "future_high_corner_Q_holdout": bool(Q_corner_stats["pass"]),
        "future_cutoff_weighted_beta_holdout": bool(beta_hold["pass"]),
        "early_high_mode_weighted_beta_holdout": bool(beta_highmode_stats["pass"]),
        "future_high_corner_weighted_beta_holdout": bool(beta_corner_stats["pass"]),
    }
    failed = [k for k, v in gates.items() if not v]

    if not failed:
        verdict = (
            "UNIFORM_MOVING_RG_Q_AND_WEIGHTED_BETA_STRONGLY_SUPPORTED_"
            "SIGNED_DUHAMEL_PRIMITIVE_OPEN"
        )
    else:
        verdict = (
            "UNIFORM_MOVING_RG_DUHAMEL_TRACE_CLOSURE_TARGET_UNRESOLVED"
        )

    # Cutoff summary.
    cutoff_rows = []
    for X, g in df.groupby("cutoff", sort=True):
        cutoff_rows.append({
            "cutoff": int(X),
            "L": float(g["L"].iloc[0]),
            "modes": int(len(g)),
            "Q_min": float(g["Q_native"].min()),
            "Q_max": float(g["Q_native"].max()),
            "Q_positive_max": float(np.maximum(g["Q_native"].to_numpy(float), 0).max()),
            "minimum_slope_over_L": float(g["slope_over_L"].min()),
            "maximum_slope_over_L": float(g["slope_over_L"].max()),
        })
    cutoff_df = pd.DataFrame(cutoff_rows)

    tail_rows = []
    for token in str(args.tail_N_values).split(","):
        token = token.strip()
        if not token:
            continue
        N = int(token)
        tail_rows.append({
            "N": N,
            "single_operator_tail_majorant_c1": tail_majorant(N, 1.0),
            "pairwise_two_operator_tail_majorant_c1": 2.0*tail_majorant(N, 1.0),
        })
    tail_df = pd.DataFrame(tail_rows)

    prefix = Path(args.prefix)
    nodes_path = Path(str(prefix) + "_NODES.csv.gz")
    modes_path = Path(str(prefix) + "_SHELL_MODES.csv.gz")
    pairs_path = Path(str(prefix) + "_PAIRS.csv")
    cutoffs_path = Path(str(prefix) + "_CUTOFFS.csv")
    tail_path = Path(str(prefix) + "_TAIL_MAJORANTS.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    df.to_csv(nodes_path, index=False, compression="gzip")
    mode_df.to_csv(modes_path, index=False, compression="gzip")
    pair_df.to_csv(pairs_path, index=False)
    cutoff_df.to_csv(cutoffs_path, index=False)
    tail_df.to_csv(tail_path, index=False)

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "new_root_solves": False,
            "alternate_phase_evaluator_used": False,
            "larger_cutoff_used": False,
        },
        "input": str(src),
        "rows": int(len(df)),
        "cutoffs": cutoffs.tolist(),
        "modes": {
            "count": int(len(modes)),
            "minimum": int(modes.min()),
            "maximum": int(modes.max()),
            "development_count": int(len(dev_modes)),
            "high_mode_holdout_count": int(len(high_modes)),
        },
        "exact_theorem": theorem,
        "native_rg": {
            "definition": (
                "Q_k(L)=-log[(F'_k(L)/L)/(F'_k(L0)/L0)]"
            ),
            "maximum_reconstruction_absolute": rg_identity_abs,
            "minimum_Q": min_Q_all,
            "maximum_Q": max_Q_all,
            "minimum_slope_over_L": min_slope_all,
            "cutoff_direction": {
                "development_cutoffs": sorted(dev_cutoff_set),
                "holdout_cutoffs": sorted(future_cutoff_set),
                "training_positive_Q_max": Q_cut_train,
                "safety": float(args.Q_cutoff_safety),
                "frozen_Q_upper_cap": Q_cut_cap,
                "future_holdout": Q_future_stats,
                "slope_development_min": slope_dev_min,
                "slope_floor_safety": float(args.slope_floor_safety),
                "frozen_slope_floor": slope_floor,
                "future_slope_holdout": slope_future_stats,
            },
            "mode_direction": {
                "development_mode_max": int(max(dev_modes)),
                "high_mode_min": int(min(high_modes)),
                "training_positive_Q_max": Q_mode_train,
                "safety": float(args.Q_mode_safety),
                "frozen_Q_upper_cap": Q_mode_cap,
                "high_mode_holdout": Q_highmode_stats,
            },
            "future_high_corner_against_cutoff_cap": Q_corner_stats,
        },
        "weighted_effective_beta": {
            "definition": (
                "B_eff=(E_b-E_a)/(1/L_a-1/L_b); "
                "if E'=B/L^2 this is the signed s^-2 weighted shell average"
            ),
            "exact_dyadic_identity": (
                "L_a L_b |Delta E|=h |B_eff|"
            ),
            "global_max_abs_B_eff": max_beta_eff_all,
            "global_max_scaled_step": max_scaled_all,
            "cutoff_direction": {
                "development_pairs": int(ndev_pairs),
                "training_max_abs_B_eff": beta_train,
                "safety": float(args.beta_effective_safety),
                "frozen_cap": beta_cap,
                "future_holdout": beta_hold,
            },
            "mode_direction": {
                "training_max_abs_B_eff": beta_mode_train,
                "frozen_cap": beta_mode_cap,
                "high_mode_holdout": beta_highmode_stats,
            },
            "future_high_corner_against_cutoff_cap": beta_corner_stats,
            "scientific_boundary": (
                "Finite bounded B_eff is direct evidence for U_STEP / bounded "
                "weighted root-flow, but it does not prove pointwise B or U_D."
            ),
        },
        "quantization": {
            "maximum_abs_residual": max_quant_resid,
            "gate": float(args.quantization_residual_gate),
            "pass": quant_pass,
        },
        "gates": gates,
        "failed_gates": failed,
        "analytic_closure": {
            "fixed_reference_requirements": [
                "c0=inf_k F'_L0(E_k(L0))/L0>0",
                "B0=sup_k |B_k(L0)|<infinity",
                "D0=sup_k |E_k(L0)-A_k|<infinity (v238 route)",
            ],
            "deep_uniform_gates": [
                "U_Q: sup_(k,L) Q_k(L)<=Q*<infinity",
                (
                    "U_D: |Y_k(L)-Y_k(L0)|<=M(L-L0), "
                    "Y=L exp(-Q)B, in the arithmetic measure sense"
                ),
            ],
            "consequences": [
                "root-point no-fold: F'_k(L)/L>=c0 exp(-Q*)",
                "uniform beta: |B_k(L)|<=exp(Q*)[B0+M]=B*",
                "fixed-mode tail: |E_k(infinity)-E_k(L)|<=B*/L",
                "v443 U_STEP with C_E=log(2) B*",
                "uniform free-level displacement <=D0+B*/L0",
                "uniform Weyl inverse-square majorant",
                "trace-norm K_L=H_L^-2 cutoff removal by dominated convergence",
            ],
            "whole_segment_transversality_required": False,
            "separate_fixed_mode_v438_theorem_required_after_UQ_UD": False,
        },
        "proof_status": (
            "OPEN. v444 proves the reduction U_Q + U_D => uniform B => no-fold + "
            "modewise O(1/L) convergence + v443 U_STEP + T_TAIL + trace-norm "
            "cutoff removal. The finite native data strongly test the observable "
            "Q and weighted-beta consequences. The missing theorem is the all-k/all-L "
            "SIGNED DUHAMEL PRIMITIVE U_D, together with an all-scale one-sided U_Q "
            "bound. No fixed-energy tube bound is assumed."
        ),
        "runtime_seconds": time.time()-started,
    }
    summary_path.write_text(
        json.dumps(native(summary), indent=2),
        encoding="utf-8",
    )

    theorem_text = f"""# ROT-RH v444 — uniform moving-RG / Duhamel trace-closure theorem

## 1. Exact theorem

Let `L=log X`, and let the ordered arithmetic branches satisfy

`F(L,E_k(L)) = q_k`

and

`partial_L F = -C0/L^2`.

Define

`J_k(L)=partial_E F(L,E_k(L))`

and

`B_k(L)=C0(L,E_k(L))/J_k(L)`.

Then

`E_k'(L)=B_k(L)/L^2`.

Define

`kappa_k=1+(partial_E B_k)/L`

and

`Q_k(L)=int_(L0)^L kappa_k(s)/s ds`.

The v425 RG identity is

`J_k(L)/L = [J_k(L0)/L0] exp(-Q_k(L))`.

Therefore the ONE-SIDED estimate

`Q_k(L)<=Q_*`

implies the root-point no-fold floor

`J_k(L)/L >= c0 exp(-Q_*)`

where

`c0=inf_k J_k(L0)/L0`.

No whole root-to-root segment estimate is needed.

Now define

`Y_k(L)=L exp(-Q_k(L)) B_k(L)`.

Across the arithmetic jump measure let the signed Duhamel theorem be

`|Y_k(L)-Y_k(L0)| <= M(L-L0)`

uniformly in `k,L`.

If

`B0=sup_k |B_k(L0)|<infinity`,

then

`|Y_k(L)| <= L0 B0 + M(L-L0) <= (B0+M)L`

and hence

`|B_k(L)| <= exp(Q_*)[B0+M] =: B_*`.

Thus

`|E_k(infinity)-E_k(L)|
 <= B_* int_L^infinity s^-2 ds
 = B_*/L`.

So fixed-mode convergence is automatic.

For `h=log 2`,

`|E_k(L+h)-E_k(L)|
 <= B_* int_L^(L+h) s^-2 ds
 = B_* h/[L(L+h)]`.

Therefore v443 `U_STEP` holds with

`C_E=h B_*`.

This gives the uniform moving displacement

`sup_(k,L>=L0)|E_k(L)-E_k(L0)| <= B_*/L0`.

Together with the fixed-reference v238 theorem

`D0=sup_k|E_k(L0)-A_k|<infinity`,

we get

`sup_(k,L)|E_k(L)-A_k| <= D0+B_*/L0`.

The free Archimedean Weyl lower bound then gives eventually, uniformly in `L`,

`E_k(L)>=k/log(k+e)`,

hence

`E_k(L)^(-2)<= [log(k+e)/k]^2`.

The majorant is summable. Since the uniform beta theorem already gave

`E_k(L)->E_k(infinity)`

for every fixed `k`, dominated convergence yields

`||H_L^(-2)-H_infinity^(-2)||_1 -> 0`.

Therefore **U_Q + U_D close both the fixed-mode and high-mode parts of the
trace-norm cutoff-removal problem simultaneously.**

## 2. Why this is better than whole-segment v438 transversality

The discrete MVT proof required

`inf_(E between roots) F'_L(E)/L > 0`.

The moving-RG proof does not.

It requires only the root-point stiffness, whose exact evolution is already

`J_k(L)/L=[J_k(L0)/L0] exp(-Q_k(L))`.

So the transversality obstruction becomes the one-sided characteristic theorem

`sup_(k,L) Q_k(L)<infinity`.

This is strictly closer to the physical moving root and avoids asking for
control of a whole fixed-energy interval.

## 3. Why U_D is the right arithmetic target

A pointwise bound on the fixed-energy source is unnecessarily strong and can
destroy the prime/PNT cancellation. Because the cutoff has prime jumps, the
natural object is the signed distributional primitive:

`int_(L0,L] exp(-Q_k(s)) dSigma_k(s)`.

The required statement is only linear signed growth:

`|int exp(-Q)dSigma| <= M(L-L0)`.

This is a moving-characteristic theorem. It does not assert polynomial control
on a nonempty fixed-E tube, so it does not invoke the v440 RH-equivalent
shortcut.

## 4. Native 320-mode finite evidence

The table contains `{len(modes)}` common modes and cutoffs

`{cutoffs.tolist()}`.

The native RG coordinate was reconstructed only from the stored phase
derivatives:

`Q=-log[(F'/L)/(F'_0/L0)]`.

Observed:

- `max Q = {max_Q_all:.12g}`
- `min Q = {min_Q_all:.12g}`
- `min F'/L = {min_slope_all:.12g}`

Cutoff-direction Q cap frozen from the first `{ndev_pairs}` transitions:

- training positive `Q_max = {Q_cut_train:.12g}`
- frozen cap = `{Q_cut_cap:.12g}`
- future maximum = `{Q_future_stats["maximum"]:.12g}`
- future pass = `{Q_future_stats["pass"]}`

The exact weighted root-flow observable

`B_eff=(E_b-E_a)/(1/L_a-1/L_b)`

has global finite maximum

`max |B_eff| = {max_beta_eff_all:.12g}`.

Development-frozen cutoff cap:

`{beta_cap:.12g}`

Future maximum:

`{beta_hold["maximum"]:.12g}`

Future pass:

`{beta_hold["pass"]}`.

These are strong finite all-mode diagnostics. They are **not** U_D.

## 5. Remaining theorem

The deepest remaining analytic target has now been compressed to:

### U_Q
`sup_(k,L) Q_k(L) < infinity`.

### U_D
`sup_(k,L) |Y_k(L)-Y_k(L0)|/(L-L0) < infinity`

with

`Y_k=L exp(-Q_k)B_k`

interpreted using the exact arithmetic jump measure.

If those two statements are proved, the trace-norm cutoff-removal theorem
follows by the chain above. No additional whole-segment transversality theorem
and no separate fixed-mode convergence theorem are needed.

This does not prove RH or the Xi/Fredholm identity.
"""
    theorem_path.write_text(theorem_text, encoding="utf-8")

    cert = {
        "schema": "ROT_RH_UNIFORM_MOVING_RG_DUHAMEL_TRACE_CLOSURE_CERTIFICATE_V1",
        "already_exact": {
            "root_flow": "E_k'=B_k/L^2",
            "RG_stiffness": "J_k/L=(J_k(L0)/L0) exp(-Q_k)",
            "Duhamel_coordinate": "Y_k=L exp(-Q_k)B_k",
            "U_Q_plus_U_D_implication": (
                "uniform B => no-fold + O(1/L) root tails + v443 U_STEP + "
                "uniform Weyl tail + trace-norm cutoff removal"
            ),
        },
        "fixed_reference_claims": {
            "positive_reference_slope_floor": {
                "proved_here": False,
                "statement": "c0=inf_k F'_L0(E_k(L0))/L0>0",
            },
            "bounded_reference_beta": {
                "proved_here": False,
                "statement": "B0=sup_k |B_k(L0)|<infinity",
            },
            "bounded_reference_free_displacement": {
                "proved_here": False,
                "statement": "D0=sup_k |E_k(L0)-A_k|<infinity",
                "route": "v238",
            },
        },
        "deep_uniform_claims": {
            "U_Q": {
                "proved": False,
                "statement": "sup_(k,L) Q_k(L)<=Q*<infinity",
            },
            "U_D": {
                "proved": False,
                "statement": (
                    "|int_(L0,L] exp(-Q_k(s)) dSigma_k(s)|<=M(L-L0) "
                    "uniformly in k,L"
                ),
            },
        },
        "forbidden_shortcuts": [
            "uniform fixed-E tube polynomial bound",
            "absolute-value PNT majorant replacing signed source",
            "known zero ordinates",
            "Xi fitting",
            "finite Q cap as proof",
            "finite weighted beta cap as proof",
        ],
    }
    cert_path.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("="*204)
    print("ROT-RH v444 — UNIFORM MOVING-RG / DUHAMEL TRACE-CLOSURE ATTACK")
    print("="*204)
    print("Xi / zeta / known zeros                 : NONE")
    print("alternate phase evaluator                : NONE")
    print("cutoffs                                  :", cutoffs.tolist())
    print("common modes                             :", len(modes))
    print()
    print("NATIVE ROOT-POINT RG")
    print("-"*204)
    print(f"max Q                                    : {max_Q_all:.12e}")
    print(f"min Q                                    : {min_Q_all:.12e}")
    print(f"min F'/L                                 : {min_slope_all:.12e}")
    print(f"RG reconstruction abs error              : {rg_identity_abs:.3e}")
    print(f"frozen future Q cap                      : {Q_cut_cap:.12e}")
    print(f"future Q max                             : {Q_future_stats['maximum']:.12e}")
    print(f"future Q holdout pass                    : {Q_future_stats['pass']}")
    print(f"early high-mode Q holdout pass           : {Q_highmode_stats['pass']}")
    print(f"future-high Q corner pass                : {Q_corner_stats['pass']}")
    print()
    print("WEIGHTED MOVING-BETA OBSERVABLE")
    print("-"*204)
    print(f"global max |B_eff|                       : {max_beta_eff_all:.12e}")
    print(f"frozen future |B_eff| cap                : {beta_cap:.12e}")
    print(f"future max |B_eff|                       : {beta_hold['maximum']:.12e}")
    print(f"future beta holdout pass                 : {beta_hold['pass']}")
    print(f"early high-mode beta holdout pass        : {beta_highmode_stats['pass']}")
    print(f"future-high beta corner pass             : {beta_corner_stats['pass']}")
    print()
    print("THEOREM REDUCTION")
    print("-"*204)
    print("U_Q + U_D => uniform B                   : PROVED ALGEBRAICALLY")
    print("uniform B => root-point no-fold          : PROVED")
    print("uniform B => fixed-mode O(1/L) tail      : PROVED")
    print("uniform B => v443 U_STEP                 : PROVED")
    print("U_STEP + v238 => uniform trace tail      : PROVED REDUCTION")
    print("=> trace-norm K_L cutoff removal         : PROVED CONDITIONAL ON U_Q + U_D")
    print("whole-segment transversality needed      : NO")
    print("separate fixed-mode v438 theorem needed  : NO")
    print()
    print("="*204)
    print("FAILED FINITE GATES                      :", failed if failed else "none")
    print("FINITE VERDICT                           :", verdict)
    print("PROOF VERDICT                            : U_Q AND SIGNED DUHAMEL U_D STILL OPEN")
    print("="*204)
    print("Files written:")
    for p in [
        nodes_path, modes_path, pairs_path, cutoffs_path, tail_path,
        summary_path, theorem_path, cert_path,
    ]:
        print(" ", p)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
