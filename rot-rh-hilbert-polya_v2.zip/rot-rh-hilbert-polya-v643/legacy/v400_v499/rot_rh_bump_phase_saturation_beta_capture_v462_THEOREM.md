# ROT-RH v462 — bump phase-saturation / exact beta capture theorem

## 1. Exact bump collision identities

Let

`p(x)=exp(-(x/(1-x))^2)`, `q(x)=-p'(x)`,

and define

`P_c(u)=int_0^1 p(x)cos(ux)dx`,

`Q_s(u)=int_0^1 q(x)sin(ux)dx`,

`S_p(u)=int_0^1 p(x)sin(ux)/x dx`.

Then

`S_p'(u)=P_c(u)`.

Integration by parts gives exactly

`Q_s(u)=u P_c(u)`.

Therefore the recombined bump collision beta function is

`B_coll=Q_s/P_c=u`

with removable continuation across common zeros.

Multiplicity cancels from this ratio.

## 2. Collision phase as a q-weighted sine integral

Because

`p(x)=int_x^1 q(t)dt`,

Fubini gives

`S_p(u)=int_0^1 q(t) Si(ut) dt`.

Also

`int_0^1 q(t)dt=1`

and, with `r=t/(1-t)`,

`int_0^1 q(t)/t dt = 1+sqrt(pi)`.

Using the elementary Dirichlet remainder

`|Si(z)-pi/2| <= 2/z`, `z>0`,

we obtain

`|S_p(u)-pi/2| <= 2(1+sqrt(pi))/u`, `u>0`.

By oddness,

`|S_p(u)+pi/2| <= 2(1+sqrt(pi))/|u|`, `u<0`.

The exact saturation constant used here is

`C_sat=2(1+sqrt(pi)) ~= 5.5449077018110318e+00`.

## 3. Non-saturation capture theorem

Suppose a persistent recombined multiplicity-`m` collision branch satisfies

`sigma*m*S_p(u(L)) + R_k(L) = C_k`,

where

`u(L)=(gamma-E_k(L))L`

and `sigma=+/-1`.

Assume that for some `delta>0`, eventually

`dist(C_k-R_k(L), {+sigma*m*pi/2,-sigma*m*pi/2}) >= m delta`.

Then the saturation estimate forces

`|u(L)| <= 2(1+sqrt(pi))/delta`.

Therefore

`|E_k(L)-gamma| <= 2(1+sqrt(pi))/(delta L)`,

and hence

`E_k(L) -> gamma`.

This proves cutoff independence in this isolated recombined collision chamber
without differentiating the root equation.

## 4. Why this is stronger than v461

v461 asked for separate all-`L` estimates on the regular numerator and
transversality denominator.  v462 shows that, in an isolated collision chamber,
those are unnecessary for convergence.

The only new phase theorem required is a **non-saturation margin** for the
complete recombined remainder.

In the bump-2 secular normalization the root label is half-integer while a
multiplicity-`m` collision has normalized saturation plateaus `+/-m/2`.
This makes the next analytic target naturally an **index / phase-jump interior
theorem**, not another source-growth envelope.

## 5. Multiplicity safety

The collision must be extracted from the recombined fixed point.  Singular
`G7` and `R^7X` cannot be analytically continued separately for multiplicity
`m>1`.

## 6. Remaining theorem

Prove, for each eventual fixed ordered branch, one of:

1. **isolated collision chamber:** the recombined residual phase has a uniform
   positive distance from the two saturation labels;

2. **attained finite cluster:** reduce the other collisions to their saturated
   integer/half-integer jumps and retain one interior collision;

3. **nonattained infinite cluster:** use the v411/v419 signed collective
   phase/primitive-beta theorem.

v462 proves the exact local bump algebra only.  It does not prove RH or the
Fredholm-Xi identity.
