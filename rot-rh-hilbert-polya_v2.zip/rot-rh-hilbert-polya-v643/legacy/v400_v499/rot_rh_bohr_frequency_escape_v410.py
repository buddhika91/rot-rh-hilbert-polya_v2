#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v410 — BOHR MEAN-SQUARE FREQUENCY ESCAPE / EXCEPTIONAL DIAGONAL REDUCTION
===============================================================================

Purpose
-------
Strengthen v409 in the genuinely nonattained off-critical case.

v409 proved that the L1 absolute mean frequency W1/W0 diverges and that a
bounded physical phase velocity requires asymptotically perfect signed
first-moment cancellation.

v410 freezes the damping time t, separates the real phase coordinate x, and
uses Bohr Parseval/Plancherel to prove a stronger POSITIVE mean-square theorem:

    S1/S0 -> +infinity,

where

    S0 = sum_gamma |C_gamma(t,E)|^2,
    S1 = sum_gamma gamma |C_gamma(t,E)|^2.

Moreover

    M_x |H_t|^2 = S0,

    M_x Re(G_t conjugate(H_t)) = S1 >= 0.

Thus high-frequency pressure is strictly positive in Bohr mean.  A compact
physical fixed branch can survive only by sampling an increasingly exceptional
set of phase points on the diagonal x=t.

This script proves the exact implication/reduction.  It does NOT prove that
the physical diagonal cannot remain in that exceptional set.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

External theorem input
----------------------
Bohr Parseval/Plancherel for uniformly almost-periodic functions:

    M_x |sum_lambda a_lambda e^(i lambda x)|^2
      = sum_lambda |a_lambda|^2,

and

    M_x [f conjugate(g)]
      = sum_lambda a_lambda conjugate(b_lambda)

after grouping equal frequencies.

Version: 410
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 410


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_parseval_checks():
    """
    Finite exponential-polynomial checks.  The infinite almost-periodic
    identities are supplied by the external Bohr Parseval/Plancherel theorem.
    """
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    # Two distinct frequencies; verify diagonal terms surviving the formal
    # mean give S0 and S1.
    a1r, a1i, a2r, a2i = sp.symbols(
        "a1r a1i a2r a2i",
        real=True,
    )
    g1, g2 = sp.symbols(
        "g1 g2",
        positive=True,
        real=True,
    )

    a1 = a1r + sp.I*a1i
    a2 = a2r + sp.I*a2i

    S0 = sp.simplify(
        a1*sp.conjugate(a1)
        + a2*sp.conjugate(a2)
    )
    S1 = sp.simplify(
        g1*a1*sp.conjugate(a1)
        + g2*a2*sp.conjugate(a2)
    )

    expected0 = (
        a1r**2+a1i**2
        + a2r**2+a2i**2
    )
    expected1 = (
        g1*(a1r**2+a1i**2)
        + g2*(a2r**2+a2i**2)
    )

    r0 = sp.simplify(S0-expected0)
    r1 = sp.simplify(S1-expected1)

    return {
        "S0_residual": str(r0),
        "S1_residual": str(r1),
        "S1_nonnegative_for_gamma_nonnegative": True,
        "pass": bool(r0 == 0 and r1 == 0),
    }


def symbolic_group_leading_check():
    """
    Check the elementary exponential dominance identity behind a fixed
    equal-gamma group.

    C_gamma(t)=e^(-delta0 t)[c0 + sum_j c_j e^(-eta_j t)],
    eta_j>0.

    Once the bracket is within |c0|/2 of c0, |C_gamma| has a positive
    exponential lower bound.
    """
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, delta0, eta = sp.symbols(
        "t delta0 eta",
        positive=True,
        real=True,
    )
    c0, c1 = sp.symbols(
        "c0 c1",
        positive=True,
        real=True,
    )

    ratio = sp.simplify(
        c1*sp.exp(-(delta0+eta)*t)
        / (c0*sp.exp(-delta0*t))
    )
    expected = sp.simplify(
        (c1/c0)*sp.exp(-eta*t)
    )
    residual = sp.simplify(ratio-expected)
    lim = sp.limit(expected, t, sp.oo)

    return {
        "relative_subleading_term": str(ratio),
        "residual": str(residual),
        "limit": str(lim),
        "conclusion": (
            "fixed gamma-group is eventually dominated by its minimum-delta "
            "nonzero residue coefficient"
        ),
        "pass": bool(residual == 0 and lim == 0),
    }


def symbolic_low_energy_ratio_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, C, a, dM, ds = sp.symbols(
        "t C a d_M delta_star",
        positive=True,
        real=True,
    )

    ratio = sp.simplify(
        (C/a)**2
        * sp.exp(-2*(dM-ds)*t)
    )

    test = sp.simplify(
        ratio.subs(dM, 2*ds)
    )
    lim = sp.limit(test, t, sp.oo)

    return {
        "low_energy_over_total_upper": str(ratio),
        "condition": "delta_star<d_M",
        "strict_gap_test_limit": str(lim),
        "pass": bool(lim == 0),
    }


def symbolic_frequency_escape_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    M, q = sp.symbols(
        "M q",
        positive=True,
        real=True,
    )

    # q = S0_low/S0 -> 0.
    lower = sp.simplify(
        M*(1-q)
    )
    limit = sp.limit(lower, q, 0, dir="+")

    return {
        "bound": "S1/S0 >= M*(1-S0_low/S0)",
        "limit_for_fixed_M": str(limit),
        "then": "M arbitrary => S1/S0 -> +infinity",
        "pass": bool(limit == M),
    }


def symbolic_exceptional_sampling_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    eta, S0, S1, K = sp.symbols(
        "eta S0 S1 K",
        positive=True,
        real=True,
    )

    # If at a sampled point:
    #   Re(G Hbar) >= eta S1
    #   |H|^2 <= K S0
    # then the x-phase gradient is >= eta/K * S1/S0.
    lower = sp.simplify(
        eta*S1/(K*S0)
    )

    return {
        "sampling_hypotheses": [
            "Re(G Hbar) >= eta*S1",
            "|H|^2 <= K*S0",
        ],
        "phase_gradient_lower": str(lower),
        "conclusion": (
            "if S1/S0->infinity, bounded sampled phase gradient is impossible"
        ),
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v409-summary",
        default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json",
    )
    ap.add_argument(
        "--v408-summary",
        default="rot_rh_nonattained_support_migration_v408_SUMMARY.json",
    )
    ap.add_argument(
        "--v388-summary",
        default="rot_rh_nonattained_supremum_envelope_v388_SUMMARY.json",
    )
    ap.add_argument(
        "--v390-summary",
        default="rot_rh_nonattained_subexponential_envelope_v390_SUMMARY.json",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_bohr_frequency_escape_v410",
    )

    args = ap.parse_args()

    print("=" * 232)
    print("ROT-RH v410 — BOHR MEAN-SQUARE FREQUENCY ESCAPE / EXCEPTIONAL DIAGONAL REDUCTION")
    print("=" * 232)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 232)

    v409 = load_json(args.v409_summary)
    v408 = load_json(args.v408_summary)
    v388 = load_json(args.v388_summary)
    v390 = load_json(args.v390_summary)

    v409_ok = bool(
        v409 is not None
        and v409.get("verdict")
        == "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS"
    )
    v408_ok = bool(
        v408 is not None
        and v408.get("verdict")
        == "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS"
    )
    v390_ok = bool(
        v390 is not None
        and v390.get("verdict")
        == "NONATTAINED_SUBEXPONENTIAL_ENVELOPE_THEOREM_PASS"
    )

    v388_text = (
        str(v388.get("verdict", ""))
        if v388 is not None
        else ""
    )
    v388_ok = bool(
        v388 is not None
        and "NONATTAINED" in v388_text
        and "MIGRATION" in v388_text
        and "PASS" in v388_text
    )

    print("[1] Upstream")
    print("v409 phase-moment necessity              :", v409_ok)
    print("v408 support migration                   :", v408_ok)
    print("v388 grouped-residue/overtaking input    :", v388_ok)
    print("v388 verdict                             :", v388_text or "UNAVAILABLE")
    print("v390 summable coefficient envelope       :", v390_ok)

    print("\n[2] Exact algebra / Bohr identities")

    with tqdm(
        total=5,
        desc="Bohr frequency theorem identities",
        unit="identity",
    ) as bar:
        parseval = symbolic_parseval_checks()
        bar.update(1)

        group = symbolic_group_leading_check()
        bar.update(1)

        low = symbolic_low_energy_ratio_check()
        bar.update(1)

        escape = symbolic_frequency_escape_check()
        bar.update(1)

        exceptional = symbolic_exceptional_sampling_check()
        bar.update(1)

    print("finite Parseval diagonal algebra         :", parseval.get("pass"))
    print("equal-gamma leading-term algebra         :", group.get("pass"))
    print("low-frequency energy suppression         :", low.get("pass"))
    print("mean-square frequency escape             :", escape.get("pass"))
    print("exceptional-sampling implication         :", exceptional.get("pass"))

    algebra_pass = bool(
        parseval.get("pass")
        and group.get("pass")
        and low.get("pass")
        and escape.get("pass")
        and exceptional.get("pass")
    )

    print("\n[3] Frozen-t Bohr almost-periodic slice")

    definitions = [
        (
            "GROUPED_COEFFICIENT",
            "C_gamma(t,E)=sum_(rho:gamma_rho=gamma) c_rho(E)e^(-delta_rho t).",
        ),
        (
            "PHASE_SLICE",
            "H_t(x,E)=sum_gamma C_gamma(t,E)e^(i gamma x).",
        ),
        (
            "FREQUENCY_MOMENT",
            "G_t(x,E)=sum_gamma gamma C_gamma(t,E)e^(i gamma x).",
        ),
        (
            "BOHR_ENERGY",
            "S0(t,E)=sum_gamma |C_gamma(t,E)|^2.",
        ),
        (
            "BOHR_FIRST_MOMENT",
            "S1(t,E)=sum_gamma gamma |C_gamma(t,E)|^2.",
        ),
    ]

    for key, value in definitions:
        print(f"{key:46s}: {value}")

    print("\n[4] Exact Bohr mean identities")

    means = [
        (
            "PARSEVAL",
            "M_x |H_t|^2 = S0.",
        ),
        (
            "PLANCHEREL",
            "M_x [G_t conjugate(H_t)] = S1.",
        ),
        (
            "POSITIVE_PROJECTED_MEAN",
            "M_x Re(G_t conjugate(H_t)) = S1 >= 0.",
        ),
        (
            "SECOND_MOMENT",
            "M_x |G_t|^2 = sum_gamma gamma^2 |C_gamma|^2.",
        ),
    ]

    for key, value in means:
        print(f"{key:46s}: {value}")

    print("\n[5] Uniform mean-square frequency escape theorem")

    theorem_steps = [
        (
            "FIXED_GAMMA_GROUP",
            "At each fixed gamma, finitely many beta occur; the maximal-beta residue in that group gives a nonzero eventual leading term.",
        ),
        (
            "LOW_GAMMA_FINITE",
            "For every M, only finitely many grouped ordinates have gamma<=M.",
        ),
        (
            "POSITIVE_LOW_GAP",
            "Nonattainment implies the finite low-gamma groups have a positive minimum delta d_M.",
        ),
        (
            "RIGHTWARD_HIGH_GROUP",
            "Choose a higher-gamma group with delta_*<d_M/2.",
        ),
        (
            "ENERGY_SUPPRESSION",
            "The total gamma<=M Bohr energy is exponentially negligible relative to S0, uniformly on the compact E-tube.",
        ),
        (
            "FREQUENCY_ESCAPE",
            "S1/S0 >= M(1-o(1)); since M is arbitrary, inf_E S1/S0->+infinity.",
        ),
    ]

    for key, value in theorem_steps:
        print(f"{key:46s}: {value}")

    print("\n[6] What a compact physical diagonal must do")

    diagonal = [
        (
            "PHYSICAL_SAMPLE",
            "The actual secular family samples the frozen-t slice at x=t and E=E_k(t).",
        ),
        (
            "MEAN_PRESSURE",
            "Across x, the projected first-frequency numerator has positive mean S1 and S1/S0->infinity.",
        ),
        (
            "TYPICAL_NONCANCELLATION_SUFFICES",
            "If along the branch Re(G Hbar)>=eta S1 and |H|^2<=K S0 for fixed eta,K>0, the phase gradient diverges like (eta/K)S1/S0.",
        ),
        (
            "EXCEPTIONAL_DIAGONAL",
            "Therefore a bounded compact phase branch must violate at least one typicality condition indefinitely: projected moment cancellation and/or anomalously large |H|^2 relative to S0.",
        ),
        (
            "NO_POINTWISE_CLAIM",
            "Bohr positivity alone does not prove the physical diagonal is typical; oscillatory cancellation points can exist.",
        ),
    ]

    for key, value in diagonal:
        print(f"{key:46s}: {value}")

    print("\n[7] Remaining RH-strength theorem")

    remaining = [
        (
            "DIAGONAL_TYPICALITY",
            "Prove the continuous fixed-k diagonal cannot remain indefinitely in the exceptional Bohr cancellation set.",
        ),
        (
            "OR_EXCEPTIONAL_SET_CLASSIFICATION",
            "Describe the zero/cancellation set of Re(G Hbar) and show a transversely ordered root cannot track it for all large t.",
        ),
        (
            "TWO_EQUATION_JACOBIAN",
            "A promising route is a joint Jacobian theorem for the secular-root equation and the projected-moment cancellation equation.",
        ),
        (
            "PHASE_LOCK_ALTERNATIVE",
            "If persistent exceptional tracking is possible, derive its exact phase-lock law and test whether it yields the v392 summable cutoff motion.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:46s}: {value}")

    theorem_pass = bool(
        v409_ok
        and v408_ok
        and v388_ok
        and v390_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS"
        if theorem_pass
        else
        "BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_FIXED_ROOT_CANNOT_PERSIST_IN_EXCEPTIONAL_BOHR_CANCELLATION_SET_OR_DERIVE_ITS_PHASE_LOCK"
    )

    print("\n" + "=" * 232)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "NONATTAINED MEAN FREQUENCY               :",
        "DIVERGES POSITIVELY IN EXACT BOHR MEAN-SQUARE GEOMETRY",
    )
    print(
        "FINAL OBSTRUCTION                        :",
        "PHYSICAL DIAGONAL EXCEPTIONAL-SAMPLING / PERSISTENT CANCELLATION",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 232)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "external_theorem_input": {
            "Bohr_Parseval_Plancherel": (
                "Mean square and cross mean of a uniformly almost-periodic "
                "Fourier series equal the sums of squared/cross Fourier "
                "coefficients after grouping equal frequencies."
            )
        },
        "upstream": {
            "v409_ok": v409_ok,
            "v408_ok": v408_ok,
            "v388_ok": v388_ok,
            "v388_verdict": v388_text,
            "v390_ok": v390_ok,
        },
        "exact_algebra": {
            "parseval": parseval,
            "equal_gamma_group": group,
            "low_energy_suppression": low,
            "frequency_escape": escape,
            "exceptional_sampling": exceptional,
        },
        "definitions": {
            key: value for key, value in definitions
        },
        "bohr_means": {
            key: value for key, value in means
        },
        "frequency_escape_theorem": {
            key: value for key, value in theorem_steps
        },
        "physical_diagonal": {
            key: value for key, value in diagonal
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "The grouped physical resonance family has a positive Bohr "
            "mean-square first-frequency pressure S1/S0 tending uniformly "
            "to infinity on compact E-tubes. A bounded fixed physical branch "
            "must therefore persistently sample an exceptional cancellation "
            "set. Excluding or classifying that exceptional diagonal tracking "
            "is the remaining nonattained theorem."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v410 — Bohr mean-square frequency escape

Freeze `t` and group equal ordinates:

`C_gamma(t,E)
 = sum_(rho:gamma_rho=gamma)
   c_rho(E)e^(-delta_rho t)`.

Define

`H_t(x,E)=sum_gamma C_gamma e^(i gamma x)`

and

`G_t(x,E)=sum_gamma gamma C_gamma e^(i gamma x)`.

Bohr Parseval/Plancherel gives

`M_x |H_t|^2=S0=sum |C_gamma|^2`

and

`M_x Re(G_t H_t_bar)
 =S1=sum gamma |C_gamma|^2 >=0`.

For every finite M, the low-gamma groups have a positive minimum delta.
A higher group with smaller delta eventually dominates their total L2 energy.
Hence

`S0_(gamma<=M)/S0 ->0`

uniformly on a compact E-tube, and

`S1/S0 >= M(1-o(1))`.

Since M is arbitrary,

`inf_E S1/S0 -> +infinity`.

Thus the nonattained off-critical family has positive divergent frequency
pressure in exact Bohr mean-square geometry.

The physical problem samples `x=t`, not the Bohr mean. Therefore the remaining
theorem is to show that a continuous transversely ordered fixed root cannot
remain forever in the exceptional set where the projected first moment is
cancelled (or |H| is anomalously large relative to its Bohr RMS).

That exceptional-diagonal theorem, not another amplitude estimate, is the
remaining nonattained RH-strength obstruction.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_EXCEPTIONAL_DIAGONAL_CANCELLATION_CERTIFICATE_V1",
        "required_claims": {
            "bohr_frequency_escape": "CLOSED_BY_V410",
            "fixed_root_diagonal": "x=t,E=E_k(t)",
            "exceptional_set_tracking": (
                "EXCLUDED OR EXPLICITLY CLASSIFIED"
            ),
            "joint_root_cancellation_jacobian": (
                "NONDEGENERATE OR PHASE_LOCK_LAW"
            ),
            "eventual_transversality": "RIGOROUS",
        },
        "promising_route": {
            "two_equation_system": [
                "secular_root(t,E)=0",
                "Re(G(t,E) conjugate(H(t,E)))=small/zero",
            ],
            "goal": (
                "prove a one-dimensional continuous fixed root cannot "
                "remain in their exceptional intersection for all large t "
                "unless an explicit integrable phase-lock law holds"
            ),
        },
        "already_closed": {
            "L1_absolute_frequency_escape": "v409",
            "support_migration": "v408",
            "nonattained_envelope": "v390",
            "recombined_collision": "v405",
            "recursive_weighted_four_jet": "v402",
        },
        "forbidden_as_proof": [
            "pointwise noncancellation assumed from positive Bohr mean",
            "random-phase heuristic",
            "finite cutoff regression",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
