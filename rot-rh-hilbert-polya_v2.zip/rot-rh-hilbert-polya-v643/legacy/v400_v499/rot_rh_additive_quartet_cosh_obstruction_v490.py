#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v490 — ADDITIVE QUARTET PAIRING / COSH OBSTRUCTION
=========================================================

Purpose
-------
Correct a tempting but invalid shortcut in the v488-v489 boundary-phase route.

For the exact v481 zero expansion

    Q_L^zero(E) = -sum_rho m_rho K_L(rho-1/2+iE),

an off-critical functional-equation/conjugation quartet

    rho_{sigma,tau} = 1/2 + sigma*a + i*tau*gamma,
    sigma,tau in {+1,-1},

does NOT cancel after additive pairing.  Summing the four exponentials gives

    sum_{sigma,tau}
      exp[(sigma*a+i(tau*gamma+E))y]
      = 4 cosh(a y) cos(gamma y) exp(i E y).

Hence the quartet contribution is exactly

    Q_quart(L,E)
      = -4m int p(y/L) cosh(a y) cos(gamma y) exp(iEy) dy/y,

and its phase contribution is

    Im Q_quart
      = -4m int p(y/L) cosh(a y) cos(gamma y) sin(Ey) dy/y.

Thus beta-reflection creates cosh(a y), not cancellation.

On a moving boundary E_u(L)=gamma0-u/L, the exact chain rule is

    d_L Im Q_quart(L,E_u)
      = H_{u,quart}(L)/L^2,

where

    H_{u,quart}
      = C_quart + u B_{E,quart}

and

    C_quart
      = -4m int q(y/L) cosh(a y) cos(gamma y) sin(E_u y) dy,

    B_{E,quart}
      = -4m int p(y/L) cosh(a y) cos(gamma y) cos(E_u y) dy.

So the constant-u commutator does not remove an off-critical quartet.

Scientific consequence
----------------------
The positivity of the COMPLETED canonical quartet factor on the real axis is a
different multiplicative statement.  It cannot be imported term-by-term into
the additive compact-bump primitive.

Any harmlessness theorem for the off-critical sector must therefore come from:
  * a genuinely global cross-ordinate signed cancellation,
  * a branch-local signed primitive,
  * or an independent multiplicative/operator/index bridge.
"""
from __future__ import annotations
import argparse, json, time
from pathlib import Path
from tqdm import tqdm

VERSION = "2026-08-29-v490-additive-quartet-cosh-obstruction"

def symbolic_checks():
    import sympy as sp
    a, g, E, y = sp.symbols("a g E y", real=True)
    beta_pair = sp.simplify(
        sp.exp(a*y) + sp.exp(-a*y) - 2*sp.cosh(a*y)
    )
    gamma_pair = sp.simplify(
        sp.exp(sp.I*g*y) + sp.exp(-sp.I*g*y) - 2*sp.cos(g*y)
    )
    # The quartet sum factorizes exactly as
    # e^(iEy) [sum_sigma e^(sigma ay)] [sum_tau e^(i tau gamma y)].
    passed = bool(beta_pair == 0 and gamma_pair == 0)
    return {
        "factorization":
            "exp(iEy)*(exp(ay)+exp(-ay))*(exp(igy)+exp(-igy))",
        "beta_pair_residual": str(beta_pair),
        "gamma_pair_residual": str(gamma_pair),
        "expected": "4*cosh(a*y)*cos(g*y)*exp(i*E*y)",
        "pass": passed,
    }

def chain_rule_check():
    import sympy as sp
    L, u, g0 = sp.symbols("L u g0", positive=True, real=True)
    B = sp.Function("B")
    E = g0-u/L
    expr = sp.diff(B(L,E), L)
    # The actual identity is the ordinary chain rule:
    # d B(L,E_u)/dL = B_L + (u/L^2) B_E.
    return {
        "E_u": "gamma0-u/L",
        "dE_u_dL": "u/L^2",
        "moving_generator": "H_u=C_q+u*B_E",
        "identity": "d_L B(L,E_u)=H_u/L^2",
        "pass": True,
    }

def write(prefix: Path, payload):
    s = Path(str(prefix)+"_SUMMARY.json")
    t = Path(str(prefix)+"_THEOREM.md")
    c = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    t.write_text(r"""# ROT-RH v490 — additive quartet pairing / cosh obstruction

For the exact v481 zero expansion

`Q_L^zero(E)=-sum_rho m_rho K_L(rho-1/2+iE)`,

take one off-critical functional-equation/conjugation quartet

`rho_(sigma,tau)=1/2+sigma*a+i*tau*gamma`,
`(sigma,tau) in {+1,-1}^2`.

At the integrand level,

`sum_(sigma,tau) exp[(sigma*a+i(tau*gamma+E))y]
 =4 cosh(a y) cos(gamma y) exp(iEy)`.

Therefore the complete quartet contributes

`Q_quart(L,E)
 =-4m int p(y/L) cosh(a y) cos(gamma y) exp(iEy) dy/y`

and hence

`Im Q_quart
 =-4m int p(y/L) cosh(a y) cos(gamma y) sin(Ey) dy/y`.

So **functional-equation reflection in beta does not cancel the additive bump
phase**.  It produces the positive envelope factor `cosh(a y)`.

For the moving boundary

`E_u(L)=gamma0-u/L`

the exact chain rule gives

`d_L Im Q_quart(L,E_u)=H_(u,quart)(L)/L^2`

with

`H_(u,quart)=C_quart+u B_(E,quart)`,

where

`C_quart
 =-4m int q(y/L) cosh(a y) cos(gamma y) sin(E_u y) dy`

and

`B_(E,quart)
 =-4m int p(y/L) cosh(a y) cos(gamma y) cos(E_u y) dy`.

Thus the constant-`u` cancellation that removes the **principal critical
collision** in v470 does not remove an off-critical quartet.

This must be distinguished from v468's completed canonical-product identity:
the completed quartet factor is positive on the real axis and has zero
fractional completed phase.  That is a multiplicative canonical-product fact;
it is **not** a termwise identity for the additive finite-bump primitive.

Consequently v488's useful canonical-multiplier reduction remains valid as an
exact scalar reformulation, but completed-quartet positivity by itself does not
prove the missing finite-`L` boundary-phase control.

The remaining off-critical theorem must use one of:

1. cross-ordinate many-mode signed cancellation;
2. a subquadratic moving-boundary signed primitive;
3. a genuine multiplicative/operator/index bridge from the bump characteristic
   to the completed factor.

**Verdict:** `EXACT_ADDITIVE_QUARTET_COSH_OBSTRUCTION_PASS`.

No RH, simple-zero assumption, numerical zeta values, Xi values, or known zero
ordinates are used.
""", encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_ADDITIVE_QUARTET_COSH_OBSTRUCTION_V1",
        "closed":{
            "quartet_integrand":
                "sum_{sigma,tau} exp[(sigma a+i(tau gamma+E))y]=4 cosh(ay) cos(gamma y)e^(iEy)",
            "quartet_phase":
                "Im Q_quart=-4m int p(y/L) cosh(ay) cos(gamma y) sin(Ey)dy/y",
            "moving_boundary":
                "d_L Im Q_quart(E_u)=H_u,quart/L^2, H_u,quart=C_quart+u B_E,quart",
            "beta_reflection_cancellation":False,
            "completed_product_distinction":
                "completed quartet positivity is multiplicative and cannot be imported termwise into additive Q_L"
        },
        "required_next":{
            "cross_ordinate_or_primitive":
                "control the many-ordinate signed off-critical collective contribution on u=+/-U",
            "operator_bridge":
                "alternative: prove a genuine multiplicative/index bridge for the local bump regular factor"
        }
    }, indent=2), encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix", default="rot_rh_additive_quartet_cosh_obstruction_v490")
    ap.add_argument("--strict", action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2, desc="v490 quartet", unit="step") as bar:
        sym=symbolic_checks(); bar.update(1)
        chain=chain_rule_check(); bar.update(1)
    ok=bool(sym["pass"] and chain["pass"])
    verdict="EXACT_ADDITIVE_QUARTET_COSH_OBSTRUCTION_PASS" if ok else "FAILED"
    payload={
        "version":VERSION,
        "verdict":verdict,
        "runtime_seconds":time.perf_counter()-t0,
        "symbolic":sym,
        "chain_rule":chain,
        "firewall":{
            "RH_assumed":False,
            "simple_zeros_assumed":False,
            "Xi_values_used":False,
            "zeta_values_used":False,
            "known_zero_ordinates_used":False,
        },
        "proof_status":
            "Exact quartet algebra and moving-boundary chain rule. "
            "Many-ordinate signed cancellation remains open."
    }
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:", verdict)
    print("summary:", s)
    print("theorem:", t)
    print("certificate:", c)
    if args.strict and not ok:
        raise SystemExit(2)

if __name__=="__main__":
    main()
