#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v426 — NONATTAINED RIESZ LOW/HIGH-FREQUENCY RELATIVE DECOMPOSITION
============================================================================

Purpose
-------
Make the final fixed-mode cutoff-removal obstruction mathematically explicit.
This is an ANALYTIC proof-audit, not another larger-cutoff experiment.

The current exact characteristic is

    E_k'(L) = B_k(L)/L^2,
    B_k(L)  = C0(L,E_k(L))/F'_L(E_k(L)),
    L       = log X.

v419 proves that a subquadratic signed primitive

    Pi_k(L) = int_(L0)^L B_k(s) ds = O_k(L^(2-epsilon))

implies fixed-mode cutoff convergence; Pi_k=O_k(L) gives the natural O(1/L)
tail. v425 gives the exact renormalized-stiffness identity

    d/dL log(F'_L/L) = -kappa_k(L)/L,
    kappa = 1 + (partial_E B)/L.

v421 leaves only the genuinely nonattained / forever-switching Riesz sector.
For that sector, after factoring the unattained right edge, use the abstract
Riesz resonance family

    H(L,E) = sum_j c_j(E) exp(-delta_j L) exp(i gamma_j L),

with

    delta_j > 0, inf_j delta_j = 0,
    local finiteness in gamma,
    |c_j(E)|      << (1+gamma_j^2)^(-1),
    |partial_E c_j(E)| << (1+|gamma_j|^3)^(-1).

This script proves/checks the following exact reductions.

A. RIESZ TAILS FROM RIEMANN-von MANGOLDT
   N(T)=O(T log T) implies

       sum_(gamma>G) 1/gamma^2 = O(log G/G),
       sum_(gamma>G) 1/gamma^3 = O(log G/G^2).

B. MOVING LOW/HIGH SPLIT EXISTS
   Local finiteness gives a positive delta_G on every fixed low-frequency
   window. Combining this with the Riesz tails gives a diagonal sequence
   G(L)->infinity for which BOTH the low-frequency amplitude and the
   high-frequency coefficient tail vanish. The same holds for the E-derivative.

C. IMPORTANT NO-GO
   Absolute amplitude closure does NOT control H_L/H. Even

       H_G(L)=G^(-2) exp(i G L)

   has |H_G|->0 and |d_L H_G|->0 as G->infinity, while

       |(d_L H_G)/H_G| = G -> infinity.

   Thus the proposed low/high-frequency argument cannot finish fixed-mode
   cutoff removal unless it is upgraded to a RELATIVE / logarithmic-derivative
   theorem. This is not a numerical issue; it is a genuine denominator issue.

D. SHELL-LOCAL TARGET
   To obtain Pi_k(L)=O_k(L), it is enough to prove, for h=log 2,

       | int_L^(L+h) B_k(s) ds | <= C_k

   for all sufficiently large L. Summing shells gives Pi_k=O_k(L).
   This is the analytic version of the bounded shell-mean beta seen in v424.

E. RELATIVE PACKET DICHOTOMY
   If on a shell H=P+R with |R/P|<=eta<1, then a continuous logarithm gives

       log H = log P + log(1+R/P).

   Therefore the unwrapped phase transfer of H differs from that of P by a
   uniformly bounded endpoint correction. If the moving packet P carries an
   escaping mean motion, such a stable relative chamber excludes a bounded
   fixed root. Hence a persistent nonattained fixed branch must live in the
   complementary switching/dark-cancellation set. The still-open theorem is
   to prove that this exceptional set has uniformly bounded B-shell primitive
   (and bounded cumulative kappa/L primitive), or else cannot persist.

Scientific firewall
-------------------
NO Xi evaluation.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite cutoff scan accepted as proof.
NO Abel/Riesz identification.
NO magnitude-only estimate promoted to a logarithmic-derivative bound.

Version: 426
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

from tqdm import tqdm

VERSION = 426


def load_json(path: str) -> Optional[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def verdict_of(obj: Optional[Dict[str, Any]]) -> Optional[str]:
    if obj is None:
        return None
    return obj.get("verdict")


def expected_verdict_ok(obj: Optional[Dict[str, Any]], expected) -> bool:
    if obj is None:
        return False
    v = obj.get("verdict")
    if isinstance(expected, str):
        return v == expected
    return v in set(expected)


def symbolic_riesz_tail_check() -> Dict[str, Any]:
    """Check the partial-summation majorants from N(T)<=C T log T."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    G, C, t = sp.symbols("G C t", positive=True, real=True)

    # Avoid SymPy's unnecessary Piecewise/Meijer-G form for the improper
    # integrals by verifying the elementary antiderivatives directly.
    F2 = -(sp.log(t) + 1) / t
    F3 = -(2 * sp.log(t) + 1) / (4 * t**2)
    antideriv2_resid = sp.simplify(sp.diff(F2, t) - sp.log(t) / t**2)
    antideriv3_resid = sp.simplify(sp.diff(F3, t) - sp.log(t) / t**3)

    # F2,F3 -> 0 as t->infinity, so integral_G^infinity = -F(G).
    i2 = (sp.log(G) + 1) / G
    i3 = (2 * sp.log(G) + 1) / (4 * G**2)
    u2 = sp.simplify(2 * C * i2)
    u3 = sp.simplify(3 * C * i3)

    e2 = 2 * C * (sp.log(G) + 1) / G
    e3 = 3 * C * (2 * sp.log(G) + 1) / (4 * G**2)

    r2 = sp.simplify(u2 - e2)
    r3 = sp.simplify(u3 - e3)

    return {
        "assumption": "N(T)<=C*T*log(T) eventually",
        "tail2_upper": str(u2),
        "tail3_upper": str(u3),
        "antiderivative2_residual": str(antideriv2_resid),
        "antiderivative3_residual": str(antideriv3_resid),
        "tail2_residual": str(r2),
        "tail3_residual": str(r3),
        "conclusion": [
            "sum_{gamma>G} gamma^-2 = O(log G/G)",
            "sum_{gamma>G} gamma^-3 = O(log G/G^2)",
        ],
        "pass": bool(antideriv2_resid == 0 and antideriv3_resid == 0 and r2 == 0 and r3 == 0),
    }


def symbolic_absolute_split_check() -> Dict[str, Any]:
    """Algebra for low/high absolute decomposition."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    A, AE, delta, L, T2, T3 = sp.symbols(
        "A AE delta L T2 T3", positive=True, real=True
    )

    low = A * sp.exp(-delta * L)
    low_E = AE * sp.exp(-delta * L)
    total = sp.simplify(low + T2)
    total_E = sp.simplify(low_E + T3)

    return {
        "low_amplitude_bound": str(low),
        "high_amplitude_bound": str(T2),
        "combined_amplitude_bound": str(total),
        "low_E_derivative_bound": str(low_E),
        "high_E_derivative_bound": str(T3),
        "combined_E_derivative_bound": str(total_E),
        "diagonal_choice": (
            "Choose G_n->infinity with T2(G_n),T3(G_n)<=eps_n; "
            "local finiteness gives delta_{G_n}>0 and finite low masses A_n,AE_n; "
            "then choose L_n so max(A_n,AE_n)*exp(-delta_{G_n} L_n)<=eps_n. "
            "Piecewise G(L)=G_n on [L_n,L_{n+1}) makes both pieces ->0."
        ),
        "pass": True,
    }


def symbolic_log_derivative_counterexample() -> Dict[str, Any]:
    """Prove absolute smallness cannot control a logarithmic derivative."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    G, L = sp.symbols("G L", positive=True, real=True)
    H = G**-2 * sp.exp(sp.I * G * L)
    HL = sp.diff(H, L)
    ratio = sp.simplify(HL / H)

    amp_limit = sp.limit(G**-2, G, sp.oo)
    deriv_amp_limit = sp.limit(G**-1, G, sp.oo)
    ratio_growth = sp.simplify(sp.Abs(ratio))

    ok = bool(amp_limit == 0 and deriv_amp_limit == 0 and ratio == sp.I * G)

    return {
        "family": "H_G(L)=G^-2 exp(i G L)",
        "H_L": str(HL),
        "H_L_over_H": str(ratio),
        "abs_H_limit": str(amp_limit),
        "abs_H_L_limit": str(deriv_amp_limit),
        "abs_log_derivative": str(ratio_growth),
        "conclusion": (
            "Riesz-like 1/G^2 amplitude decay, even together with |H_L|->0, "
            "does not bound H_L/H. A relative noncancellation/logarithmic-derivative "
            "lemma is indispensable."
        ),
        "pass": ok,
    }


def symbolic_relative_packet_check() -> Dict[str, Any]:
    """Exact H=P(1+r) logarithmic derivative / phase-transfer reduction."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    P, r, PL, rL = sp.symbols("P r PL rL", nonzero=True)
    H = P * (1 + r)
    HL = PL * (1 + r) + P * rL
    ratio = sp.simplify(HL / H)
    expected = sp.simplify(PL / P + rL / (1 + r))
    resid = sp.simplify(ratio - expected)

    return {
        "identity": "H=P(1+r) => H_L/H=P_L/P+r_L/(1+r)",
        "residual": str(resid),
        "relative_chamber": "|r|<=eta<1",
        "phase_endpoint_correction": (
            "A continuous branch of log(1+r) exists in the disk |r|<1; "
            "its endpoint imaginary-part correction is uniformly bounded by a constant depending only on eta."
        ),
        "meaning": (
            "If a moving packet P has controlled/nonzero relative dominance, H inherits its unwrapped phase transfer up to O_eta(1). "
            "With escaping packet mean motion this excludes a bounded fixed-root lock; therefore a persistent nonattained branch must stay in the complementary switching/dark set."
        ),
        "pass": bool(resid == 0),
    }


def symbolic_shell_primitive_check() -> Dict[str, Any]:
    """Uniform shell primitive => Pi(L)=O(L)."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    h, C, L, L0 = sp.symbols("h C L L0", positive=True, real=True)
    N = sp.symbols("N", integer=True, nonnegative=True)
    shell_sum = sp.simplify(N * C)
    # N <= (L-L0)/h + 1
    envelope = sp.simplify(C * ((L - L0) / h + 1))

    return {
        "shell_target": "|int_L^(L+h) B_k(s) ds|<=C_k, h=log 2",
        "N_shell_sum": str(shell_sum),
        "global_envelope": str(envelope),
        "conclusion": "Pi_k(L)=O_k(L), hence v419 gives E_k(infinity)-E_k(L)=O_k(1/L)",
        "pass": True,
    }


def symbolic_rg_check() -> Dict[str, Any]:
    """Re-record the v425 renormalized-stiffness identity algebraically."""
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, BE = sp.symbols("L BE", positive=True, real=True)
    kappa = 1 + BE / L
    rhs1 = -(BE + L) / L**2
    rhs2 = -kappa / L
    resid = sp.simplify(rhs1 - rhs2)

    return {
        "kappa": "1+(partial_E B)/L",
        "identity": "d log(F'/L)/dL=-kappa/L",
        "residual": str(resid),
        "needed_global_claim": "sup_L int_(L0)^L kappa_k(s)/s ds < infinity",
        "pass": bool(resid == 0),
    }


def make_theorem_markdown(payload: Dict[str, Any]) -> str:
    return r"""# ROT-RH v426 — nonattained Riesz low/high-frequency relative decomposition

## 1. What is proved in v426

Work on a compact `E`-tube with the genuinely nonattained Riesz resonance family

`H(L,E)=sum_j c_j(E) exp(-delta_j L) exp(i gamma_j L)`,

where `delta_j>0`, `inf delta_j=0`, the ordinates are locally finite, and the
Riesz coefficients satisfy the v421 summability scale

`|c_j| << (1+gamma_j^2)^(-1)`,

`|partial_E c_j| << (1+|gamma_j|^3)^(-1)`.

The Riemann-von Mangoldt count `N(T)=O(T log T)` gives by partial summation

`sum_(gamma>G) gamma^(-2) = O(log G/G)`,

`sum_(gamma>G) gamma^(-3) = O(log G/G^2)`.

For every fixed `G`, local finiteness gives a positive low-frequency gap

`delta_G=min_(gamma<=G) delta_gamma > 0`.

Therefore a diagonal moving split can be chosen: take `G_n->infinity` so the
high-frequency coefficient tails are at most `eps_n`, and then take `L_n`
large enough that the finite low-frequency mass times `exp(-delta_Gn L_n)` is
also at most `eps_n`. With `G(L)=G_n` on `[L_n,L_(n+1))`, both the low-frequency
and high-frequency amplitude pieces tend to zero. The same is true for the
coefficient `E` derivative.

This rigorously closes the **absolute** low/high-frequency decomposition.

## 2. Why this still does not prove fixed-mode cutoff removal

The physical phase uses a logarithmic derivative. Absolute smallness is not a
relative estimate. The one-mode family

`H_G(L)=G^(-2) exp(i G L)`

has

`|H_G| -> 0`,

`|d_L H_G| -> 0`,

but

`(d_L H_G)/H_G = i G`,

whose magnitude diverges. Thus neither the Riesz `1/gamma^2` tail nor absolute
control of its differentiated amplitude can by itself bound the phase velocity.
This is exactly the denominator obstruction already signaled by v409-v411.

So a proof that simply says "the high-frequency Riesz tail is small" is invalid.

## 3. Relative packet identity

If on a shell

`H=P+R=P(1+r)`, `r=R/P`,

then exactly

`H_L/H = P_L/P + r_L/(1+r)`.

If `|r|<=eta<1`, the disk `|r|<1` admits a continuous logarithm and the
unwrapped phase transfer of `H` differs from that of `P` by a uniformly bounded
endpoint correction depending only on `eta`.

Consequently a stable relatively dominant packet with escaping mean motion
cannot support a bounded fixed-root phase lock. A persistent genuinely
nonattained branch must therefore live in the complementary **switching/dark
cancellation set** where no such relative packet chamber persists.

This is a rigorous dichotomy, but it does not yet bound the exceptional set.

## 4. The minimal remaining primitive-beta theorem

Let

`B_k(L)=C0(L,E_k(L))/F'_L(E_k(L))`.

It is enough to prove the shell-local signed estimate

`|int_L^(L+log 2) B_k(s) ds| <= C_k`

for all sufficiently large `L`.

Summing `O(L)` fixed-width shells gives

`Pi_k(L)=int_(L0)^L B_k(s) ds = O_k(L)`.

Then v419 yields

`E_k(infinity)-E_k(L)=O_k(1/L)`.

For no-fold, v425 gives exactly

`d/dL log(F'_L/L)=-kappa_k(L)/L`,

`kappa_k=1+(partial_E B_k)/L`.

Thus it is enough in addition to prove

`sup_L int_(L0)^L kappa_k(s)/s ds < infinity`.

## 5. Final v426 conclusion

The low/high-frequency Riesz decomposition **does close absolutely**, but that
is not the missing theorem. The final fixed-mode obstruction is now localized
to one relative statement:

**RELATIVE DIAGONAL SWITCHING LEMMA.** On every persistent bounded fixed ordered
nonattained Riesz branch, either

1. a relatively nonvanishing moving packet chamber occurs and escaping mean
   motion contradicts the fixed-root lock; or
2. the complementary switching/dark set satisfies uniformly

   `|int_L^(L+log 2) B_k(s) ds|=O_k(1)`

   and has bounded cumulative `int kappa_k(s)/s ds`.

Proving that lemma finishes fixed-mode cutoff removal. The present upstream
results do not yet imply it automatically.

No RH proof is claimed. No Xi/zeta values or known zero ordinates are used.
"""


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--v408-summary", default="rot_rh_nonattained_support_migration_v408_SUMMARY.json")
    ap.add_argument("--v409-summary", default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json")
    ap.add_argument("--v410-summary", default="rot_rh_bohr_frequency_escape_v410_SUMMARY.json")
    ap.add_argument("--v411-summary", default="rot_rh_collective_phase_lock_v411_SUMMARY.json")
    ap.add_argument("--v419-summary", default="rot_rh_primitive_beta_renormalization_v419_SUMMARY.json")
    ap.add_argument("--v420-summary", default="rot_rh_attained_nofold_rg_characteristic_v420_SUMMARY.json")
    ap.add_argument("--v421-summary", default="rot_rh_riesz_attained_cluster_regulator_repair_v421_SUMMARY.json")
    ap.add_argument("--v424-summary", default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json")
    ap.add_argument("--v425-summary", default="rot_rh_renormalized_stiffness_rg_v425_SUMMARY.json")
    ap.add_argument("--strict", action="store_true", help="Exit nonzero unless every upstream lineage file is present and the analytic reduction is internally consistent. This does NOT turn the remaining relative lemma into a proof.")
    ap.add_argument("--prefix", default="rot_rh_nonattained_riesz_low_high_relative_v426")
    args = ap.parse_args()

    started = time.perf_counter()

    print("=" * 224)
    print("ROT-RH v426 — NONATTAINED RIESZ LOW/HIGH-FREQUENCY RELATIVE DECOMPOSITION")
    print("=" * 224)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("simple zeros assumed                      : NO")
    print("finite cutoff extrapolation as proof      : NO")
    print("Abel/Riesz identified                     : NO")
    print("goal                                       : analytic fixed-mode cutoff-removal reduction")
    print("=" * 224)

    files = {
        "v408": load_json(args.v408_summary),
        "v409": load_json(args.v409_summary),
        "v410": load_json(args.v410_summary),
        "v411": load_json(args.v411_summary),
        "v419": load_json(args.v419_summary),
        "v420": load_json(args.v420_summary),
        "v421": load_json(args.v421_summary),
        "v424": load_json(args.v424_summary),
        "v425": load_json(args.v425_summary),
    }

    expected = {
        "v408": "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS",
        "v409": "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS",
        "v410": "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS",
        "v411": "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS",
        "v419": "EXACT_PRIMITIVE_BETA_NONPERTURBATIVE_CUTOFF_REDUCTION_PASS",
        "v420": "EXACT_ATTAINED_NOFOLD_RG_CHARACTERISTIC_COMPLETION_PASS",
        "v421": "EXACT_RIESZ_ATTAINED_CLUSTER_REGULATOR_REPAIR_PASS",
        "v424": "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS",
        "v425": "RENORMALIZED_STIFFNESS_RG_PROSPECTIVE_NOFOLD_PASS",
    }

    print("[1] Upstream lineage")
    upstream_rows = {}
    for key in expected:
        obj = files[key]
        ok = expected_verdict_ok(obj, expected[key])
        upstream_rows[key] = {
            "available": obj is not None,
            "verdict": verdict_of(obj),
            "expected": expected[key],
            "pass": ok,
        }
        print(f"{key:8s} available={str(obj is not None):5s} pass={str(ok):5s} verdict={verdict_of(obj)}")

    print("\n[2] Exact analytic reductions")
    checks = {}
    funcs = [
        ("riesz_tail_partial_summation", symbolic_riesz_tail_check),
        ("moving_absolute_low_high_split", symbolic_absolute_split_check),
        ("log_derivative_no_go", symbolic_log_derivative_counterexample),
        ("relative_packet_identity", symbolic_relative_packet_check),
        ("shell_primitive_implication", symbolic_shell_primitive_check),
        ("renormalized_stiffness_rg", symbolic_rg_check),
    ]

    with tqdm(total=len(funcs), desc="v426 analytic lemmas", unit="lemma") as bar:
        for name, fn in funcs:
            checks[name] = fn()
            bar.update(1)

    for name, result in checks.items():
        print(f"{name:42s}: {result.get('pass')}")

    algebra_ok = all(bool(x.get("pass")) for x in checks.values())

    print("\n[3] What the low/high split actually proves")
    print("Riesz amplitude tail                       : O(log G/G)")
    print("Riesz E-derivative tail                    : O(log G/G^2)")
    print("fixed low-frequency window                 : exponential decay from delta_G>0")
    print("moving diagonal split                      : EXISTS; absolute H and H_E pieces ->0")
    print("absolute H_L high-frequency tail           : NOT summable in general (gamma/gamma^2 ~ 1/gamma)")
    print("signed integral of H_L over fixed packet   : endpoint-controlled")
    print("logarithmic derivative H_L/H               : NOT controlled by absolute split")

    print("\n[4] Decisive denominator counterexample")
    ce = checks["log_derivative_no_go"]
    print("family                                     :", ce.get("family"))
    print("|H| -> 0                                   : True")
    print("|H_L| -> 0                                 : True")
    print("H_L/H                                      :", ce.get("H_L_over_H"))
    print("meaning                                    : absolute Riesz-tail closure alone cannot prove phase/root flow control")

    print("\n[5] Minimal all-L theorem after v426")
    print("ROOT PRIMITIVE SHELL TARGET                : |int_L^(L+log2) B_k(s) ds| <= C_k")
    print("consequence                                : Pi_k(L)=O_k(L) => E_k(inf)-E_k(L)=O_k(1/L)")
    print("NO-FOLD RG TARGET                          : sup_L int_(L0)^L kappa_k(s)/s ds < infinity")
    print("relative packet alternative               : stable relative packet + escaping mean motion => branch exclusion")
    print("only unresolved set                        : forever-switching / dark relative-cancellation diagonal")

    absolute_theorem_pass = bool(algebra_ok)
    lineage_complete = all(r["pass"] for r in upstream_rows.values())

    # We intentionally do NOT mark global fixed-mode cutoff removal proved.
    verdict = (
        "EXACT_NONATTAINED_RIESZ_ABSOLUTE_LOW_HIGH_DECOMPOSITION_PASS_RELATIVE_RATIO_OPEN"
        if absolute_theorem_pass
        else
        "NONATTAINED_RIESZ_LOW_HIGH_DECOMPOSITION_INCOMPLETE"
    )
    next_theorem = (
        "PROVE_RELATIVE_DIAGONAL_SWITCHING_SHELL_PRIMITIVE_AND_KAPPA_BOUND_OR_EXCLUDE_BRANCH"
    )

    print("\n" + "=" * 224)
    print("VERDICT                                   :", verdict)
    print("ABSOLUTE LOW/HIGH RIESZ DECOMPOSITION     :", "PROVED" if absolute_theorem_pass else "INCOMPLETE")
    print("RELATIVE LOG-DERIVATIVE BOOTSTRAP         : OPEN")
    print("FIXED-MODE CUTOFF REMOVAL                 : NOT YET UNCONDITIONALLY PROVED")
    print("NEXT THEOREM                              :", next_theorem)
    if not lineage_complete:
        missing = [k for k, r in upstream_rows.items() if not r["pass"]]
        print("LINEAGE NOTE                              : missing/mismatched upstream summaries:", ",".join(missing))
    print("=" * 224)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_cutoff_extrapolation_accepted_as_proof": False,
            "Abel_Riesz_identified": False,
        },
        "upstream": upstream_rows,
        "analytic_checks": checks,
        "proved": {
            "riesz_gamma_minus2_tail": "O(log G/G)",
            "riesz_gamma_minus3_tail": "O(log G/G^2)",
            "fixed_low_frequency_gap": "delta_G>0 for every finite G by local finiteness/nonattainment",
            "moving_absolute_split": True,
            "absolute_H_and_E_derivative_split_vanish": True,
            "absolute_smallness_does_not_bound_log_derivative": True,
            "relative_packet_log_identity": True,
            "uniform_B_shell_primitive_implies_Pi_O_L": True,
            "v425_RG_identity": True,
        },
        "not_proved": {
            "relative_nonattained_packet_chamber": "not guaranteed",
            "switching_dark_set_B_shell_primitive": "open",
            "switching_dark_set_kappa_over_L_cumulative_bound": "open",
            "global_fixed_mode_cutoff_removal": "open until the preceding relative lemma is proved or the branch is excluded",
        },
        "minimal_remaining_theorem": {
            "branch_dichotomy": [
                "Stable relatively nonvanishing moving packet with escaping mean motion => bounded fixed branch impossible",
                "Otherwise prove the switching/dark set has uniformly bounded signed B primitive on every log2 shell and bounded cumulative kappa/L primitive",
            ],
            "root_shell_target": "sup_L |int_L^(L+log2) B_k(s) ds| < infinity",
            "root_consequence": "Pi_k(L)=O_k(L), hence E_k(infinity)-E_k(L)=O_k(1/L)",
            "nofold_target": "sup_L int_(L0)^L kappa_k(s)/s ds < infinity",
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "v426 rigorously closes the absolute nonattained Riesz low/high-frequency decomposition and proves that this alone cannot control the logarithmic derivative. "
            "The final fixed-mode obstruction is a relative denominator/switching theorem on the physical diagonal."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }

    summary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    theorem_path.write_text(make_theorem_markdown(payload), encoding="utf-8")

    cert = {
        "schema": "ROT_RH_RELATIVE_DIAGONAL_SWITCHING_FIXED_MODE_CERTIFICATE_V1",
        "regulator": "Riesz/log-Cesaro only",
        "already_closed": {
            "nonattained_support_migration": "v408",
            "projected_first_moment_cancellation_necessity": "v409",
            "Bohr_frequency_escape": "v410",
            "collective_phase_lock_reduction": "v411",
            "primitive_beta_implication": "v419",
            "RG_characteristic": "v420/v425",
            "attained_Riesz_sector": "v421 under stable chamber",
            "finite_arithmetic_Pi_O_L_evidence": "v424",
            "finite_arithmetic_renormalized_nofold_evidence": "v425",
            "absolute_nonattained_low_high_split": "v426",
        },
        "required_claims": {
            "relative_packet_dichotomy": (
                "For each sufficiently large shell on a persistent bounded fixed branch, either a stable relative packet chamber forces phase-speed contradiction, or the shell lies in a quantitatively controlled switching/dark set."
            ),
            "switching_shell_beta_primitive": "sup_L |int_L^(L+log2) C0/F' ds| < infinity",
            "switching_kappa_primitive": "sup_L int_(L0)^L [1+(partial_E(C0/F'))/s] ds/s < infinity",
            "or_branch_exclusion": "No persistent bounded ordered nonattained Riesz branch exists",
        },
        "forbidden_as_proof": [
            "absolute Riesz tail small => logarithmic derivative small",
            "magnitude-only PNT bound",
            "Bohr typicality on the physical diagonal",
            "finite cutoff extrapolation",
            "known zero ordinates",
            "Xi fitting",
            "Abel/Riesz regulator identification",
        ],
    }
    cert_path.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and (not algebra_ok or not lineage_complete):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
