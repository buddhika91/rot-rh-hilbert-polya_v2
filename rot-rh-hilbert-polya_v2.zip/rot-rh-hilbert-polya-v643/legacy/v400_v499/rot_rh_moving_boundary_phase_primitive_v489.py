#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v489 — MOVING-BOUNDARY PHASE / SIGNED-PRIMITIVE EQUIVALENCE
==================================================================

Let phi_u(L) be an unwrapped recombined regular boundary phase along
E_u(L)=gamma-u/L, and let

    phi_u'(L) = -H_u(L)/L^2.

If phi_* is the completed midpoint/sign phase and q(L)=phi_u(L)-phi_*, then

    H_u(L) = -L^2 q'(L).

Hence its signed primitive satisfies exactly

    Pi_u(L)
      = -L^2 q(L)
        + 2 int_{L0}^L s q(s) ds
        + constant.

Consequences:
* q(L)=O(L^-alpha), 0<alpha<2  => Pi_u=O(L^(2-alpha)).
* q(L)=O(1/L)                  => Pi_u=O(L).
* q(L)->0                      => Pi_u=o(L^2).

Thus ANY algebraic rate of boundary-phase convergence is already a v419
subquadratic primitive certificate.  Conversely, for v470 trapping one does not
need a rate at all: eventual entry into a fixed safe half-plane is sufficient.
"""
from __future__ import annotations
import argparse, json, time
from pathlib import Path
from tqdm import tqdm

VERSION = "2026-08-29-v489-moving-boundary-phase-primitive-equivalence"

def algebra(alpha: float):
    if not (0.0 < alpha < 2.0):
        raise ValueError("need 0<alpha<2")
    return {
        "phase_error": f"O(L^-{alpha})",
        "primitive": f"O(L^{2.0-alpha})",
        "epsilon_v419": alpha,
        "sharp_alpha_1": abs(alpha-1.0) < 1e-15,
        "pass": True,
    }

def write(prefix: Path, payload):
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    cert = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    theorem.write_text(r"""# ROT-RH v489 — moving-boundary phase / primitive equivalence

Let the recombined moving-boundary regular phase satisfy

`phi_u'(L)=-H_u(L)/L^2`

and let `phi_*` be the completed midpoint/sign target.  Set

`q_u(L)=phi_u(L)-phi_*`.

Then

`H_u(L)=-L^2 q_u'(L)`.

Therefore, exactly,

`Pi_u(L)=int_(L0)^L H_u(s) ds
        =-L^2 q_u(L)+L0^2 q_u(L0)
          +2 int_(L0)^L s q_u(s) ds`.

Hence:

* if `q_u(L)=O(L^-alpha)` for any `0<alpha<2`, then
  `Pi_u(L)=O(L^(2-alpha))`;
* if `q_u(L)=O(1/L)`, then `Pi_u(L)=O(L)`;
* if merely `q_u(L)->0`, then `Pi_u(L)=o(L^2)`.

So **any positive algebraic rate of recombined boundary-phase convergence is
already enough for the v419 signed-primitive theorem**.

There is an even weaker direct route.  v470's two-boundary barrier does not
require convergence to zero: if both `u=+U` and `u=-U` boundary phase errors
eventually remain inside one fixed safe half-plane margin, the ordered branch is
trapped and

`|E(L)-gamma|<U/L`.

Therefore the final analytic target is weaker than an amplitude lower bound and
weaker than excluding all UV superoscillation:

> prove quartet-recombined boundary-phase stabilization (with any algebraic
> rate for a v419 certificate, or merely a fixed safe margin for direct v470
> trapping).

**Verdict:** `EXACT_MOVING_PHASE_PRIMITIVE_EQUIVALENCE_PASS`.

The theorem does not prove that stabilization itself occurs.
""", encoding="utf-8")
    cert.write_text(json.dumps({
        "schema": "ROT_RH_MOVING_BOUNDARY_PHASE_PRIMITIVE_EQUIVALENCE_V1",
        "closed": {
            "identity": "Pi=-L^2 q(L)+L0^2 q(L0)+2 int s q(s) ds",
            "algebraic_rate": "q=O(L^-alpha), 0<alpha<2 => Pi=O(L^(2-alpha))",
            "sharp_rate": "q=O(1/L) => Pi=O(L)",
            "rate_free": "q->0 => Pi=o(L^2)",
            "direct_barrier": "eventual fixed safe phase margin on both boundaries => |E-gamma|<U/L",
        },
        "required_next": {
            "quartet_recombined_phase_stabilization":
                "prove the off-critical collective boundary phase enters/stays in the completed midpoint half-plane, preferably with any algebraic rate",
        }
    }, indent=2), encoding="utf-8")
    return summary,theorem,cert

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--alpha",type=float,default=1.0)
    ap.add_argument("--prefix",default="rot_rh_moving_boundary_phase_primitive_v489")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v489 equivalence",unit="step") as bar:
        a=algebra(args.alpha); bar.update(1)
        rate_free=True; bar.update(1)
    verdict="EXACT_MOVING_PHASE_PRIMITIVE_EQUIVALENCE_PASS" if a["pass"] and rate_free else "FAILED"
    payload={
        "version":VERSION,
        "verdict":verdict,
        "runtime_seconds":time.perf_counter()-t0,
        "algebra":a,
        "rate_free_convergence_implies_o_L2":rate_free,
        "firewall":{
            "RH_assumed":False,
            "known_zero_ordinates_used":False,
            "numerical_zeta_used":False,
        },
        "proof_status":"Exact integration-by-parts identity. Boundary-phase stabilization remains the only new theorem."
    }
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s)
    print("theorem:",t)
    print("certificate:",c)
    if args.strict and verdict=="FAILED":
        raise SystemExit(2)

if __name__=="__main__":
    main()
