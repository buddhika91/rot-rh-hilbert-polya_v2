#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v469 — CANONICAL COMPLEX BUMP-2 HALF-PHASE CHARACTERISTIC
================================================================

PURPOSE
-------
Construct the exact multiplicative scalar phase object underlying the v452-v465
bump-2 secular law.

This is the bump analogue of the older v435 Riesz characteristic, but it uses
the current C-infinity compact bump

    p(x)=exp(-(x/(1-x))^2), 0<=x<1,
    q(x)=-p'(x).

Let a=log 2 and let

    dmu(y)=d psi(e^y) - e^y dy.

For complex z define the centered bump primitive

    Q_L(z)
      = int_[a,L)
          p(y/L) e^(-y/2+i z y) / y  dmu(y)

      = sum_(n<e^L)
          Lambda(n)/(sqrt(n) log n)
          p(log n/L) exp(i z log n)

        - int_a^L
          e^(y/2) p(y/L) exp(i z y)/y dy.

For real E,

    Q_L(-E)=conj(Q_L(E))

and

    Im Q_L(E)=P_L(E)-M_L(E).

The v452 finite-part phase is

    P_L^FP(E)=P_L(E)-M_L(E)+M_inf^AC(E),

so with the L-independent reference phase

    Phi_ref(E)=theta(E)+pi-M_inf^AC(E),

the secular count obeys

    pi F_L(E)=Phi_ref(E)-Im Q_L(E).

Define the CANONICAL HALF-PHASE MULTIPLIER

    r_L(z)
      = exp( -[Q_L(z)-Q_L(-z)]/2 ).

Then on the real axis

    r_L(E)=exp(-i Im Q_L(E)),

hence

    V_L(E)
      := exp(i Phi_ref(E)) r_L(E)
       = exp(i pi F_L(E)).

Therefore the exact secular law

    F_L(E)=k-1/2

is equivalent to

    cos(pi F_L(E))=0

or, equivalently,

    V_L(E)^2=-1.

This gives a genuine multiplicative lift of the CURRENT bump-2 secular phase.
It is a canonical scalar characteristic/phase multiplier; it is NOT yet a
Fredholm determinant or an energy-independent operator colligation.

---------------------------------------------------------------------------
EXACT CUTOFF ODE
---------------------------------------------------------------------------

Since p is flat at x=1, no boundary distribution occurs and

    partial_L p(y/L)=y q(y/L)/L^2.

Therefore

    partial_L Q_L(z)
      = C_q^C(L,z)/L^2,

where

    C_q^C(L,z)
      = int_[a,L)
          q(y/L)e^(-y/2+i z y) dmu(y).

Thus

    partial_L log r_L(z)
      = -[C_q^C(L,z)-C_q^C(L,-z)]/(2L^2).

For real E,

    partial_L log r_L(E)
      = - i C_q(L,E)/L^2,

with the exact v459 signed bump-wavelet generator

    C_q(L,E)
      = Im C_q^C(L,E).

Hence the v465 phase factor has an explicit signed logarithmic generator.

---------------------------------------------------------------------------
EXACT REGULAR/COLLISION FACTORIZATION
---------------------------------------------------------------------------

Suppose on a local recombined collision chart the signed finite-part phase is
decomposed additively as

    Im Q_L(E)
      = B_coll(L,E) + B_reg(L,E).

Then the multiplicative half-phase factor splits EXACTLY:

    r_L(E)
      = exp(-i B_coll(L,E))
        exp(-i B_reg(L,E)).

No approximation or determinant assumption is needed.

If B_reg differs from the canonical midpoint background by pi*epsilon_L in
phase units, the relative regular multiplier is

    R_L/|R_L| = exp(i pi epsilon_L)

up to the fixed sign convention.

Therefore v465's half-plane condition

    Re R_L != 0

is exactly the statement that the canonical bump regular multiplier does not
hit a half-integer phase plateau.

This closes the missing multiplicative lift behind v464-v465.

---------------------------------------------------------------------------
SIGNED-PRIMITIVE PHASE CRITERION
---------------------------------------------------------------------------

At fixed real E, let the collision-subtracted regular generator be C_reg(L,E)
and write

    phi_reg'(L,E) = -C_reg(L,E)/L^2.

Let

    Pi_reg(L,E)
      = int_(L0)^L C_reg(s,E) ds.

Integration by parts gives exactly

    int_L^T C_reg(s,E)/s^2 ds
      = Pi_reg(T,E)/T^2
        - Pi_reg(L,E)/L^2
        + 2 int_L^T Pi_reg(s,E)/s^3 ds,

where Pi_reg is based at L0; the harmless base constant may equivalently be
absorbed into the phase anchor.

Consequences:

  * If |Pi_reg(L,E)| <= C L^(2-eps), eps>0, then the regular cutoff phase has
    a convergent tail O(L^-eps).

  * If |Pi_reg(L,E)| <= C L, the phase tail is O(1/L).

This is the phase-characteristic analogue of the primitive-beta mechanism:
pointwise |C_reg|=O(L) is NOT enough for absolute integrability, but signed
primitive control is.

A tube-uniform version of the same estimate is sufficient for the v465
half-plane theorem once one anchor phase class is fixed.

---------------------------------------------------------------------------
SCIENTIFIC BOUNDARY
---------------------------------------------------------------------------

This theorem does NOT prove the signed primitive bound, the all-L half-plane
margin, fixed-mode cutoff independence, RH, or the Fredholm-Xi identity.

It does prove that the remaining phase problem is attached to a canonical
explicit scalar multiplier.  No hypothetical local determinant factor is
required.

No Xi values, zeta numerical values, known zero ordinates, or finite regression
are used.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v469-canonical-complex-bump2-half-phase"


def p_bump(x: float) -> float:
    x = float(x)
    if x < 0.0:
        return math.nan
    if x >= 1.0:
        return 0.0
    z = x/(1.0-x)
    a = -(z*z)
    return 0.0 if a < -745.0 else math.exp(a)


def q_bump(x: float) -> float:
    x = float(x)
    if x <= 0.0 or x >= 1.0:
        return 0.0
    return 2.0*x*p_bump(x)/(1.0-x)**3


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available": False, "pass": False, "error": str(exc)}

    y, L, z = sp.symbols("y L z", positive=True)
    x = y/L
    # Use an abstract p with q=-p' for the chain rule.
    p = sp.Function("p")
    q = sp.Function("q")

    chain = sp.diff(p(x), L)
    expected = -y*sp.diff(p(x), x) / L**2 if False else None

    # Direct symbolic bump formula.
    xb = sp.symbols("xb", positive=True)
    pb = sp.exp(-(xb/(1-xb))**2)
    qb = sp.simplify(-sp.diff(pb, xb))
    qb_expected = 2*xb*pb/(1-xb)**3
    q_pass = bool(sp.simplify(qb-qb_expected) == 0)

    # d/dL p(y/L) = y q(y/L)/L^2.
    p_yL = sp.exp(-((y/L)/(1-y/L))**2)
    dL = sp.simplify(sp.diff(p_yL, L))
    q_yL = 2*(y/L)*p_yL/(1-y/L)**3
    dL_expected = sp.simplify(y*q_yL/L**2)
    chain_pass = bool(sp.simplify(dL-dL_expected) == 0)

    Qp, Qm, Czp, Czm = sp.symbols("Qp Qm Czp Czm")
    r = sp.exp(-(Qp-Qm)/2)
    # logarithmic derivative under Q'_pm=C_pm/L^2.
    log_derivative = sp.simplify(-(Czp-Czm)/(2*L**2))

    return {
        "available": True,
        "q_formula": str(qb),
        "q_identity_pass": q_pass,
        "cutoff_chain_rule": str(dL),
        "cutoff_chain_rule_pass": chain_pass,
        "log_r_cutoff_derivative": str(log_derivative),
        "pass": bool(q_pass and chain_pass),
    }


def conjugation_demo() -> Dict[str, Any]:
    # Pure finite deterministic self-check of Q(-E)=conj Q(E) for a real signed
    # measure represented by arbitrary real atoms.  This checks the algebraic
    # implementation pattern, not arithmetic/RH.
    atoms = [
        (math.log(2.0), 1.25),
        (math.log(3.0), -0.70),
        (math.log(5.0), 0.33),
        (math.log(7.0), -0.11),
    ]
    L = 3.0
    E = 2.75

    def Q(Ev: float) -> complex:
        total = 0j
        for y, w in atoms:
            if y < L:
                total += w*p_bump(y/L)*complex(
                    math.cos(Ev*y), math.sin(Ev*y)
                )/y
        return total

    qp = Q(E)
    qm = Q(-E)
    err = abs(qm-qp.conjugate())

    r = math.e**0  # placeholder to make explicit this is unit-modulus via exp
    phase = qp.imag
    half = complex(math.cos(-phase), math.sin(-phase))

    return {
        "Q_plus_real": qp.real,
        "Q_plus_imag": qp.imag,
        "Q_minus_real": qm.real,
        "Q_minus_imag": qm.imag,
        "conjugation_error": err,
        "half_phase_abs": abs(half),
        "pass": err <= 1e-14 and abs(abs(half)-1.0) <= 1e-14,
    }


def primitive_tail_bound(eps: float, C: float, L: float) -> Dict[str, Any]:
    """
    If |Pi(s)| <= C s^(2-eps), then from integration by parts
      |tail| <= C L^-eps + 2 C int_L^inf s^(-1-eps) ds
             = C(1+2/eps)L^-eps.
    """
    if eps <= 0.0:
        raise ValueError("eps must be positive")
    if C < 0.0 or L <= 0.0:
        raise ValueError("need C>=0 and L>0")
    bound = C*(1.0+2.0/eps)*L**(-eps)
    return {
        "eps": eps,
        "C": C,
        "L": L,
        "tail_bound": bound,
        "formula": "C*(1+2/eps)*L^(-eps)",
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
r"""# ROT-RH v469 — canonical complex bump-2 half-phase characteristic

## 1. Canonical complex primitive

Let `a=log2` and

`dmu(y)=dpsi(e^y)-e^y dy`.

Define

`Q_L(z)
 = int_[a,L) p(y/L)e^(-y/2+i z y)dmu(y)/y`.

For real `E`,

`Q_L(-E)=conj(Q_L(E))`

and

`Im Q_L(E)=P_L(E)-M_L(E)`.

The current bump finite-part law is

`P_L^FP=P_L-M_L+M_inf^AC`.

Therefore, with

`Phi_ref(E)=theta(E)+pi-M_inf^AC(E)`,

we have exactly

`pi F_L(E)=Phi_ref(E)-Im Q_L(E)`.

## 2. Multiplicative half-phase lift

Define

`r_L(z)=exp(-(Q_L(z)-Q_L(-z))/2)`.

For real `E`,

`r_L(E)=exp(-i Im Q_L(E))`

and hence

`V_L(E)=exp(i Phi_ref(E)) r_L(E)=exp(i pi F_L(E))`.

Therefore

`F_L(E)=k-1/2`

iff

`cos(pi F_L(E))=0`

iff

`V_L(E)^2=-1`.

This is the exact scalar multiplicative lift of the bump-2 secular phase.

## 3. Exact cutoff ODE

Because `q=-p'` and the bump is flat at its endpoint,

`partial_L Q_L(z)=C_q^C(L,z)/L^2`.

Consequently

`partial_L log r_L(z)
 =-[C_q^C(L,z)-C_q^C(L,-z)]/(2L^2)`.

On the real axis,

`partial_L log r_L(E)=-i C_q(L,E)/L^2`.

Thus the signed v459 wavelet generator is literally the logarithmic cutoff
generator of the canonical half-phase characteristic.

## 4. Collision/regular factorization

If

`Im Q_L=B_coll+B_reg`,

then exactly

`r_L=e^(-iB_coll)e^(-iB_reg)`.

So the v465 relative phase

`R_L/|R_L|=e^(i pi epsilon_L)`

has a canonical realization as the collision-subtracted bump half-phase
multiplier, up to the fixed secular sign convention.

No Fredholm/determinant assumption is needed for this scalar factorization.

## 5. Signed-primitive criterion

At fixed real `E`, write

`phi_reg'(L,E)=-C_reg(L,E)/L^2`

and

`Pi_reg(L,E)=int_(L0)^L C_reg(s,E) ds`.

Integration by parts gives

`int_L^T C_reg(s,E)/s^2 ds
 =Pi_reg(T,E)/T^2-Pi_reg(L,E)/L^2
  +2 int_L^T Pi_reg(s,E)/s^3 ds`.

Hence

* `Pi_reg=O(L^(2-eps))`, `eps>0`, gives a phase tail `O(L^-eps)`;
* `Pi_reg=O(L)` gives a phase tail `O(1/L)`.

This is the correct signed target. A pointwise `|C_reg|=O(L)` estimate alone
would give only a logarithmic absolute bound and is not the right theorem.

## 6. Status

The multiplicative lift and cutoff ODE are exact.

Still open:

1. a branch-local/tube-uniform signed primitive estimate for the recombined
   regular generator;
2. identification of its limiting phase class with the canonical midpoint;
3. fixed-mode cutoff independence;
4. operator promotion and the Fredholm-Xi identity.

No Xi values, numerical zeta values, known zero ordinates, or finite regression
enter this theorem.
""",
        encoding="utf-8",
    )

    cert.write_text(
        json.dumps({
            "schema": "ROT_RH_CANONICAL_BUMP2_HALF_PHASE_V1",
            "closed": {
                "complex_bump_primitive":
                    "Q_L(z)=int p(y/L)e^(-y/2+izy)dmu(y)/y",
                "real_axis_conjugation":
                    "Q_L(-E)=conj(Q_L(E))",
                "centered_phase":
                    "Im Q_L=P_L-M_L",
                "half_phase_multiplier":
                    "r_L=exp(-(Q_L(z)-Q_L(-z))/2)",
                "secular_characteristic":
                    "V_L=e^(iPhi_ref)r_L=e^(ipi F_L); roots satisfy V_L^2=-1",
                "cutoff_ode":
                    "partial_L log r_L=-[CqC(z)-CqC(-z)]/(2L^2)",
                "real_cutoff_ode":
                    "partial_L log r_L(E)=-i C_q(L,E)/L^2",
                "regular_factorization":
                    "additive collision/regular phase becomes exact multiplicative factorization",
                "primitive_phase_tail":
                    "Pi_reg=O(L^(2-eps)) => phase tail O(L^-eps)",
            },
            "required_next": {
                "tube_uniform_primitive":
                    "bound the signed primitive of the recombined collision-subtracted C_q generator on the shrinking collision tube",
                "midpoint_phase_class":
                    "identify the limiting regular multiplier with the canonical integer/midpoint class",
                "moving_branch_barrier":
                    "use the phase margin on tube boundaries to trap the fixed half-integer branch at O(1/L)",
            },
            "warning": (
                "Do not replace signed primitive control by a magnitude-only "
                "|C_q|=O(L) bound; that is not integrable after division by L^2."
            ),
        }, indent=2),
        encoding="utf-8",
    )


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--eps", type=float, default=1.0)
    ap.add_argument("--primitive-C", type=float, default=1.0)
    ap.add_argument("--L", type=float, default=100.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_canonical_complex_bump2_half_phase_v469",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*194)
    print("ROT-RH v469 — CANONICAL COMPLEX BUMP-2 HALF-PHASE CHARACTERISTIC")
    print("="*194)
    print("Xi / numerical zeta / known zeros : NONE")
    print("Fredholm realization assumed       : NO")
    print("="*194)

    with tqdm(total=3, desc="v469 exact lift", unit="step") as bar:
        sym = symbolic_checks()
        bar.update(1)
        conj = conjugation_demo()
        bar.update(1)
        tail = primitive_tail_bound(
            args.eps,
            args.primitive_C,
            args.L,
        )
        bar.update(1)

    passed = bool(sym.get("pass") and conj.get("pass"))
    verdict = (
        "EXACT_CANONICAL_COMPLEX_BUMP2_HALF_PHASE_LIFT_PASS"
        if passed else
        "BUMP2_HALF_PHASE_LIFT_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "Fredholm_realization_assumed": False,
        },
        "symbolic": sym,
        "conjugation_self_check": conj,
        "primitive_tail_example": tail,
        "exact_statements": {
            "Q": "centered complex compact-bump primitive",
            "r": "exp(-(Q(z)-Q(-z))/2)",
            "real_axis_r": "exp(-i(P_L-M_L))",
            "full_half_phase":
                "exp(i[theta+pi-MinfAC]) r = exp(i pi F_L)",
            "cutoff_generator":
                "partial_L log r(E)=-i C_q(L,E)/L^2",
        },
        "proof_status": (
            "Exact scalar multiplicative lift and signed cutoff ODE. "
            "Tube-uniform regular primitive/midpoint identification remains open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*194)
    print("verdict                                  :", verdict)
    print("q=-p' symbolic identity                  :", sym.get("q_identity_pass"))
    print("cutoff chain rule                        :", sym.get("cutoff_chain_rule_pass"))
    print("real-axis conjugation                    :", conj.get("pass"))
    print("|half-phase multiplier|                  :", f"{conj.get('half_phase_abs', float('nan')):.16e}")
    print("primitive example tail bound             :", f"{tail['tail_bound']:.16e}")
    print("summary                                  :", str(prefix)+"_SUMMARY.json")
    print("theorem                                  :", str(prefix)+"_THEOREM.md")
    print("next certificate                         :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*194)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
