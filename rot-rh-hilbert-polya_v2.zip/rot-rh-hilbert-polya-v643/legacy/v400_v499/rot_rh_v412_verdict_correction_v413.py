#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v413 — v412 VERDICT CORRECTION / PER-MODE MICRO-FREEZE LOCALIZATION
=========================================================================

Purpose
-------
Post-process v412 WITHOUT recomputing arithmetic and WITHOUT refitting any
prospective bound.

v412 tested two theorem-relevant finite quantities:

  GLOBAL TRANSFER:
    max_{tested k,Y} log(X)|F_Y(E_{k,X})-F_X(E_{k,X})|

  GLOBAL TRANSVERSALITY:
    min_{tested k,Y,E in tube} F'_Y(E)/log(X)

and also imposed an EXTRA diagnostic gate:

  every mode's holdout transfer must lie below
  1.5 * that same mode's single-anchor development maximum.

With only one development anchor, the per-mode gate is fragile: a mode can
have an accidentally tiny development transfer and fail its personal cap even
while the prospectively frozen GLOBAL theorem bound survives.

For the finite tested panel, a single prospectively frozen global C satisfying

    log(X)|Delta F| <= C

for every tested mode is STRONGER than merely having separate C_k values for
those modes.  Therefore a failure of the single-anchor per-k micro-freeze is
not, by itself, a failure of the theorem-scale finite holdout.

v413:
  * preserves the original v412 frozen global cap/floor exactly;
  * does NOT refit from holdout;
  * reports the logically corrected finite verdict;
  * localizes every failed per-k micro-freeze;
  * identifies whether any failed mode actually violated the global frozen cap;
  * reports the safety factor that each failed mode would have needed
    descriptively only (NOT as a new frozen theorem constant).

Scientific firewall
-------------------
NO Xi.
NO zeta.
NO known zero ordinates.
NO arithmetic recomputation.
NO holdout refit.
NO finite test accepted as proof.

Version: 413
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 413


def load_json(path: str):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v412-detail",
        default="rot_rh_arithmetic_dyadic_lock_holdout_v412_DETAIL.csv",
    )
    ap.add_argument(
        "--v412-per-k",
        default="rot_rh_arithmetic_dyadic_lock_holdout_v412_PER_K_FREEZE_HOLDOUT.csv",
    )
    ap.add_argument(
        "--v412-summary",
        default="rot_rh_arithmetic_dyadic_lock_holdout_v412_SUMMARY.json",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_v412_verdict_correction_v413",
    )
    args = ap.parse_args()

    detail_path = Path(args.v412_detail)
    perk_path = Path(args.v412_per_k)

    if not detail_path.exists():
        raise FileNotFoundError(detail_path)
    if not perk_path.exists():
        raise FileNotFoundError(perk_path)

    df = pd.read_csv(detail_path)
    pk = pd.read_csv(perk_path)
    s = load_json(args.v412_summary)

    transfer_col = "scaled_lock_transfer_logX_times_abs"
    slope_col = "transfer_tube_min_slope_over_logX"

    required_detail = {
        "set", "X", "Y", "Y_over_X", "root_index",
        "E_k_X", transfer_col, slope_col,
        "signed_phase_transfer",
    }
    missing = required_detail - set(df.columns)
    if missing:
        raise KeyError(f"DETAIL missing columns: {sorted(missing)}")

    required_pk = {
        "root_index",
        "development_transfer_max",
        "frozen_transfer_cap",
        "holdout_transfer_max",
        "holdout_transfer_ratio_to_cap",
        "transfer_holdout_pass",
        "development_slope_min",
        "frozen_slope_floor",
        "holdout_slope_min",
        "slope_holdout_pass",
    }
    missing_pk = required_pk - set(pk.columns)
    if missing_pk:
        raise KeyError(f"PER_K missing columns: {sorted(missing_pk)}")

    freeze = s.get("freeze", {})
    holdout = s.get("holdout", {})

    global_dev_T = float(freeze["global_development_transfer_max"])
    global_cap = float(freeze["global_frozen_transfer_cap"])
    global_dev_c = float(freeze["global_development_slope_min"])
    global_floor = float(freeze["global_frozen_slope_floor"])

    global_hold_T = float(holdout["maximum_scaled_lock_transfer"])
    global_hold_c = float(holdout["minimum_transfer_tube_slope_over_logX"])

    global_T_pass = bool(holdout["global_transfer_pass"])
    global_c_pass = bool(holdout["global_slope_pass"])
    perk_T_pass = bool(holdout["every_fixed_k_transfer_pass"])
    perk_c_pass = bool(holdout["every_fixed_k_slope_pass"])

    print("=" * 224)
    print("ROT-RH v413 — v412 VERDICT CORRECTION / PER-MODE MICRO-FREEZE LOCALIZATION")
    print("=" * 224)
    print("Xi / zeta / known-zero data             : NONE")
    print("arithmetic recomputed                    : NO")
    print("holdout used to refit global cap/floor   : NO")
    print("v412 original verdict                    :", s.get("verdict"))
    print("=" * 224)

    print("[1] The theorem-scale prospective quantities")
    print(
        "development max logX*|DeltaF|            :",
        f"{global_dev_T:.15e}",
    )
    print(
        "holdout max logX*|DeltaF|                :",
        f"{global_hold_T:.15e}",
    )
    print(
        "holdout/dev ratio                        :",
        f"{global_hold_T/global_dev_T:.12f}",
    )
    print(
        "relative change                          :",
        f"{100*(global_hold_T/global_dev_T-1):+.6f}%",
    )
    print(
        "prospectively frozen global cap          :",
        f"{global_cap:.15e}",
    )
    print(
        "holdout/global cap                       :",
        f"{global_hold_T/global_cap:.12f}",
    )
    print("global transfer pass                     :", global_T_pass)
    print()
    print(
        "development min tube slope/logX          :",
        f"{global_dev_c:.15e}",
    )
    print(
        "holdout min tube slope/logX              :",
        f"{global_hold_c:.15e}",
    )
    print(
        "holdout/dev ratio                        :",
        f"{global_hold_c/global_dev_c:.12f}",
    )
    print(
        "relative change                          :",
        f"{100*(global_hold_c/global_dev_c-1):+.6f}%",
    )
    print(
        "prospectively frozen global slope floor  :",
        f"{global_floor:.15e}",
    )
    print(
        "holdout / collision coefficient 1/2      :",
        f"{global_hold_c/0.5:.12f}",
    )
    print("global slope pass                        :", global_c_pass)

    print("\n[2] Logical gate correction")
    print(
        "every fixed-k single-anchor transfer cap :",
        perk_T_pass,
    )
    print(
        "every fixed-k slope floor                :",
        perk_c_pass,
    )
    print(
        "CORRECTION                               :",
        "per-k single-anchor transfer caps are diagnostic extras, not necessary once the prospectively frozen global transfer cap passes every tested mode.",
    )
    print(
        "FINITE THEOREM-SCALE HOLDOUT             :",
        bool(global_T_pass and global_c_pass),
    )

    failed_pk = pk[~pk["transfer_holdout_pass"].astype(bool)].copy()

    print("\n[3] Localizing per-k micro-freeze failures")
    print("failed mode count                        :", len(failed_pk))

    localized = []

    iterator = tqdm(
        failed_pk.itertuples(index=False),
        total=len(failed_pk),
        desc="localizing failed modes",
        unit="mode",
    )

    for row in iterator:
        k = int(row.root_index)
        d = df[
            (df["set"] == "development")
            & (df["root_index"].astype(int) == k)
        ].copy()
        h = df[
            (df["set"] == "holdout")
            & (df["root_index"].astype(int) == k)
        ].copy()

        if d.empty or h.empty:
            continue

        di = d[transfer_col].idxmax()
        hi = h[transfer_col].idxmax()

        dr = d.loc[di]
        hr = h.loc[hi]

        devmax = float(row.development_transfer_max)
        holdmax = float(row.holdout_transfer_max)

        needed_safety = (
            holdmax / devmax
            if devmax > 0
            else math.inf
        )

        localized.append({
            "root_index": k,
            "development_E": float(dr["E_k_X"]),
            "development_X": int(dr["X"]),
            "development_worst_Y": int(dr["Y"]),
            "development_worst_Y_over_X": float(dr["Y_over_X"]),
            "development_transfer_max": devmax,
            "development_signed_phase_transfer_at_worst": float(
                dr["signed_phase_transfer"]
            ),
            "holdout_E": float(hr["E_k_X"]),
            "holdout_X": int(hr["X"]),
            "holdout_worst_Y": int(hr["Y"]),
            "holdout_worst_Y_over_X": float(hr["Y_over_X"]),
            "holdout_transfer_max": holdmax,
            "holdout_signed_phase_transfer_at_worst": float(
                hr["signed_phase_transfer"]
            ),
            "holdout_over_development": (
                holdmax/devmax if devmax > 0 else math.inf
            ),
            "single_anchor_safety_needed": needed_safety,
            "holdout_over_global_development_max": (
                holdmax/global_dev_T
            ),
            "holdout_over_frozen_global_cap": (
                holdmax/global_cap
            ),
            "within_prospective_global_cap": bool(
                holdmax <= global_cap
            ),
            "development_slope_min": float(row.development_slope_min),
            "holdout_slope_min": float(row.holdout_slope_min),
            "slope_still_passes": bool(row.slope_holdout_pass),
        })

    loc = pd.DataFrame(localized)

    if not loc.empty:
        show = loc.sort_values(
            "holdout_over_development",
            ascending=False,
        )
        cols = [
            "root_index",
            "development_transfer_max",
            "holdout_transfer_max",
            "holdout_over_development",
            "single_anchor_safety_needed",
            "holdout_over_global_development_max",
            "holdout_over_frozen_global_cap",
            "development_worst_Y_over_X",
            "holdout_worst_Y_over_X",
            "within_prospective_global_cap",
            "slope_still_passes",
        ]
        print(
            show[cols].to_string(
                index=False,
                float_format=lambda x: f"{x:.9e}",
            )
        )

        all_failed_within_global = bool(
            loc["within_prospective_global_cap"].all()
        )
        all_failed_slope_ok = bool(
            loc["slope_still_passes"].all()
        )
    else:
        all_failed_within_global = True
        all_failed_slope_ok = True
        print("No per-k transfer failures.")

    print(
        "all failed modes still inside global cap :",
        all_failed_within_global,
    )
    print(
        "all failed modes retain slope floor      :",
        all_failed_slope_ok,
    )

    print("\n[4] Y/X shape at global level")
    qrows = []
    for (set_name, q), g in df.groupby(["set", "Y_over_X"]):
        qrows.append({
            "set": set_name,
            "Y_over_X": float(q),
            "max_scaled_transfer": float(g[transfer_col].max()),
            "median_scaled_transfer": float(g[transfer_col].median()),
            "min_slope_over_logX": float(g[slope_col].min()),
        })

    qdf = pd.DataFrame(qrows).sort_values(
        ["Y_over_X", "set"]
    )
    print(
        qdf.to_string(
            index=False,
            float_format=lambda x: f"{x:.12e}",
        )
    )

    finite_global_pass = bool(
        global_T_pass
        and global_c_pass
        and all_failed_within_global
    )

    if finite_global_pass and not perk_T_pass:
        verdict = (
            "PROSPECTIVE_GLOBAL_FINAL_HYPOTHESES_PASS__"
            "PER_K_SINGLE_ANCHOR_MICROFREEZE_BREAK_ONLY"
        )
        next_theorem = (
            "PROVE_ALL_X_GLOBAL_OR_FIXED_K_RIESZ_CROSS_CUTOFF_TRANSFER_BOUND_AND_COLLISION_NORMALIZED_SLOPE"
        )
    elif finite_global_pass:
        verdict = (
            "PROSPECTIVE_FINAL_HYPOTHESES_HOLDOUT_PASS"
        )
        next_theorem = (
            "PROVE_ALL_X_RIESZ_CROSS_CUTOFF_TRANSFER_BOUND_AND_COLLISION_NORMALIZED_SLOPE"
        )
    else:
        verdict = (
            "THEOREM_SCALE_PROSPECTIVE_HOLDOUT_FAILURE"
        )
        next_theorem = (
            "LOCALIZE_GLOBAL_TRANSFER_OR_SLOPE_FAILURE_BEFORE_ANALYTIC_CLOSURE"
        )

    print("\n" + "=" * 224)
    print("CORRECTED VERDICT                        :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "FINITE EVIDENCE                          :",
        "GLOBAL O(1/logX) TRANSFER SCALE + POSITIVE LINEAR-IN-logX SLOPE SURVIVED"
        if finite_global_pass
        else "ONE OR MORE THEOREM-SCALE GLOBAL GATES FAILED",
    )
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT PROVED — FINITE HOLDOUT ONLY",
    )
    print("=" * 224)

    prefix = Path(args.prefix)
    loc_path = Path(str(prefix) + "_FAILED_MODES.csv")
    q_path = Path(str(prefix) + "_Y_FRACTION_SHAPE.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    loc.to_csv(loc_path, index=False)
    qdf.to_csv(q_path, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "arithmetic_recomputed": False,
            "holdout_refit": False,
            "finite_test_accepted_as_proof": False,
        },
        "v412_original_verdict": s.get("verdict"),
        "theorem_scale": {
            "development_transfer_max": global_dev_T,
            "holdout_transfer_max": global_hold_T,
            "holdout_over_development_transfer": (
                global_hold_T/global_dev_T
            ),
            "frozen_global_transfer_cap": global_cap,
            "holdout_over_global_cap": global_hold_T/global_cap,
            "global_transfer_pass": global_T_pass,
            "development_slope_min": global_dev_c,
            "holdout_slope_min": global_hold_c,
            "holdout_over_development_slope": (
                global_hold_c/global_dev_c
            ),
            "frozen_global_slope_floor": global_floor,
            "global_slope_pass": global_c_pass,
        },
        "extra_diagnostic": {
            "per_k_single_anchor_transfer_pass": perk_T_pass,
            "per_k_slope_pass": perk_c_pass,
            "failed_mode_count": int(len(failed_pk)),
            "all_failed_modes_within_global_cap": (
                all_failed_within_global
            ),
            "all_failed_modes_slope_ok": all_failed_slope_ok,
        },
        "corrected_finite_global_pass": finite_global_pass,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "This is only a logical correction/post-processing of v412. "
            "It does not strengthen the data. The prospectively frozen global "
            "transfer cap and slope floor are theorem-relevant finite tests; "
            "the per-k cap extrapolated from one development anchor is an extra "
            "micro-freeze diagnostic and is not logically required."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v413 — corrected interpretation of v412

v412 prospectively froze the global development bounds

`max log(X)|Delta F| = {global_dev_T:.16e}`

and

`min F'_Y/log(X) = {global_dev_c:.16e}`.

The fresh holdout gave

`max log(X)|Delta F| = {global_hold_T:.16e}`

and

`min F'_Y/log(X) = {global_hold_c:.16e}`.

Thus the theorem-scale global transfer changed by

`{100*(global_hold_T/global_dev_T-1):+.8f}%`

and the theorem-scale minimum slope changed by

`{100*(global_hold_c/global_dev_c-1):+.8f}%`.

The prospectively frozen global cap/floor were NOT refit and both passed.

The only v412 failure was the extra requirement that every individual mode's
holdout transfer fit below 1.5 times that same mode's value at a single
development anchor. With one development anchor this is a brittle diagnostic:
an accidentally tiny development value can fail its personal cap even while
the prospectively frozen GLOBAL bound holds for every tested mode.

Corrected finite verdict:

`{verdict}`

This is still finite arithmetic evidence, not an all-X proof.

The analytic theorem remains:

`|F_Y(E_(k,X))-F_X(E_(k,X))| <= C_k/log X`

uniformly for `X<=Y<=2X`, together with

`inf_tube F'_Y(E) >= c_k log X`.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", loc_path)
    print(" ", q_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and not finite_global_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
