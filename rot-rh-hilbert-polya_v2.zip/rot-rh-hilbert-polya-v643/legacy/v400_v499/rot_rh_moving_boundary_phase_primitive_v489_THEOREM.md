# ROT-RH v489 — moving-boundary phase / primitive equivalence

Let the recombined moving-boundary regular phase satisfy

`phi_u'(L)=-H_u(L)/L^2`

and let `phi_*` be the completed midpoint/sign target.  Set

`q_u(L)=phi_u(L)-phi_*`.

Then

`H_u(L)=-L^2 q_u'(L)`.

Therefore, exactly,

`Pi_u(L)=int_(L0)^L H_u(s) ds
        =-L^2 q_u(L)+L0^2 q_u(L0)
          +2 int_(L0)^L s q_u(s) ds`.

Hence:

* if `q_u(L)=O(L^-alpha)` for any `0<alpha<2`, then
  `Pi_u(L)=O(L^(2-alpha))`;
* if `q_u(L)=O(1/L)`, then `Pi_u(L)=O(L)`;
* if merely `q_u(L)->0`, then `Pi_u(L)=o(L^2)`.

So **any positive algebraic rate of recombined boundary-phase convergence is
already enough for the v419 signed-primitive theorem**.

There is an even weaker direct route.  v470's two-boundary barrier does not
require convergence to zero: if both `u=+U` and `u=-U` boundary phase errors
eventually remain inside one fixed safe half-plane margin, the ordered branch is
trapped and

`|E(L)-gamma|<U/L`.

Therefore the final analytic target is weaker than an amplitude lower bound and
weaker than excluding all UV superoscillation:

> prove quartet-recombined boundary-phase stabilization (with any algebraic
> rate for a v419 certificate, or merely a fixed safe margin for direct v470
> trapping).

**Verdict:** `EXACT_MOVING_PHASE_PRIMITIVE_EQUIVALENCE_PASS`.

The theorem does not prove that stabilization itself occurs.
