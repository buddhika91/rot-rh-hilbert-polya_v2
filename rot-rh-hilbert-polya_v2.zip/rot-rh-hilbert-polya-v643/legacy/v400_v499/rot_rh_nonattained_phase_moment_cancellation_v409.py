#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v409 — NONATTAINED ABSOLUTE-FREQUENCY ESCAPE / PHASE-MOMENT CANCELLATION THEOREM
=======================================================================================

Purpose
-------
After v408, the nonattained off-critical case is known to have migrating
interior support frequency.  v409 attacks the PHYSICAL diagonal directly.

It proves two theorem-level facts on any fixed compact E-tube I:

  1. the actual absolute resonance mass (not merely a majorant) has zero
     exponential decay rate and its absolute mean ordinate tends to +infinity;

  2. any bounded physical phase velocity/log-derivative is therefore possible
     only through asymptotically perfect signed cancellation of the first
     frequency moment.

This converts the vague "infinite collective cancellation" from v388-v390
into an explicit normalized cancellation ratio.

No zeta values or zero ordinates are evaluated.

----------------------------------------------------------------------
A. Physical normalized nonattained family
----------------------------------------------------------------------

Write

    H(t,E)
      = sum_rho c_rho(E)
          exp(-delta_rho t)
          exp(i gamma_rho t),

where

    delta_rho = beta_* - beta_rho > 0,
    inf delta_rho = 0,
    gamma_rho >= 0.

On a compact E-tube I, v388 gives for every FIXED rho

    a_rho := inf_(E in I) |c_rho(E)| > 0,
    A_rho := sup_(E in I) |c_rho(E)| < infinity,

because the residue coefficient is built from a nonzero zero multiplicity,
Gamma (which has no zeros), and nonzero elementary factors.

v390 gives a summable uniform majorant

    A_rho_major >= sup_I |c_rho(E)|,
    sum A_rho_major < infinity.

Define the ACTUAL absolute moments

    W_0(t,E)
      = sum |c_rho(E)| exp(-delta_rho t),

    W_1(t,E)
      = sum gamma_rho |c_rho(E)| exp(-delta_rho t).

----------------------------------------------------------------------
B. Actual absolute mass is subexponential
----------------------------------------------------------------------

Dominated convergence gives W_0(t,E)->0 uniformly.

Fix eta>0.  Since inf delta=0, choose one fixed rho_eta with

    delta_eta < eta.

Since c_rho_eta is uniformly nonzero on I,

    W_0(t,E)
      >= a_eta exp(-delta_eta t)

uniformly in E.

Therefore

    sup_(E in I) [-log W_0(t,E)]/t <= delta_eta+o(1).

As eta is arbitrary,

    sup_(E in I) [-log W_0(t,E)]/t -> 0.

Thus the ACTUAL branchwise absolute mass has zero exponential decay rate,
not just the v390 majorant.

----------------------------------------------------------------------
C. Absolute mean ordinate diverges uniformly
----------------------------------------------------------------------

Fix M>0.

Only finitely many resonances have gamma<=M.  Let

    d_M = min{delta_rho: gamma_rho<=M} > 0,

and

    C_M = sum_(gamma<=M) sup_I |c_rho(E)| < infinity.

Then the low-frequency absolute mass obeys

    W_0^{<=M}(t,E)
      <= C_M exp(-d_M t).

Choose one fixed resonance rho_* with

    delta_* < d_M/2

and set

    a_* = inf_I |c_rho_*(E)| > 0.

Then

    W_0(t,E)
      >= a_* exp(-delta_* t),

so

    W_0^{<=M}/W_0
      <= (C_M/a_*) exp[-(d_M-delta_*)t]
      -> 0

uniformly in E.

Hence asymptotically all actual absolute mass lies above every fixed M:

    W_0^{>M}/W_0 -> 1.

Therefore

    W_1/W_0
      >= M W_0^{>M}/W_0
      -> at least M.

Since M is arbitrary,

    inf_(E in I) W_1(t,E)/W_0(t,E) -> +infinity.

This is the physical-diagonal absolute-frequency escape theorem.

----------------------------------------------------------------------
D. Exact signed phase-moment identity
----------------------------------------------------------------------

Put

    b_rho
      = c_rho(E) exp(-delta_rho t) exp(i gamma_rho t),

    H = sum b_rho,

    D = sum delta_rho b_rho,

    G = sum gamma_rho b_rho.

Then exactly

    partial_t H = -D + i G.

Whenever H!=0,

    omega(t,E)
      := partial_t arg H
       = Im[(partial_t H) conjugate(H)]/|H|^2

and therefore

    omega |H|^2
      = -Im[D conjugate(H)]
        + Re[G conjugate(H)].

Equivalently,

    Re[G conjugate(H)]
      = omega |H|^2
        + Im[D conjugate(H)].

For nontrivial zeros, 0<beta<1 and beta_*<=1, so

    0<=delta_rho<1.

Thus

    sum delta_rho |b_rho| <= W_0.

If |omega|<=C on the physical branch/tube, then

    |Re[G conjugate(H)]|
      <= (C+1) W_0^2.

Divide by W_1 W_0:

    P(t,E)
      := |Re[G conjugate(H)]|/(W_1 W_0)

      <= (C+1)/(W_1/W_0)
      -> 0.

Therefore BOUNDED PHASE VELOCITY forces asymptotically perfect cancellation
of the projected first frequency moment.

----------------------------------------------------------------------
E. Stronger full logarithmic-derivative version
----------------------------------------------------------------------

If instead

    |partial_t H/H| <= C,

then

    |G|
      <= |partial_t H|+|D|
      <= (C+1) W_0.

Hence

    V(t,E)
      := |G|/W_1
      <= (C+1)/(W_1/W_0)
      -> 0.

So bounded FULL log derivative requires vector first-moment cancellation.

----------------------------------------------------------------------
F. Contradiction criterion
----------------------------------------------------------------------

Any theorem giving a fixed eta>0 such that eventually on the fixed root tube

    |Re[G conjugate(H)]|
      >= eta W_1 W_0

immediately excludes bounded physical phase velocity, because

    |omega|
      >= eta W_1/W_0 - 1
      -> infinity.

Likewise,

    |G| >= eta W_1

excludes bounded full logarithmic derivative.

This is now the exact RH-strength arithmetic target:

    either prove the ROT/Riemann residue phases force NONCANCELLATION,
    which excludes the nonattained off-critical edge;

    or prove the required vanishing phase-moment cancellation and use it to
    establish a singular diagonal phase-lock theorem.

----------------------------------------------------------------------
What v409 does NOT prove
----------------------------------------------------------------------

It does NOT prove the noncancellation lower bound.

It does NOT prove cutoff independence.

It proves that a bounded/convergent fixed physical branch in the nonattained
case requires a quantitatively extreme signed first-moment cancellation whose
normalization tends to infinity.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 409
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 409


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_mass_rate_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, a, delta = sp.symbols(
        "t a delta",
        positive=True,
        real=True,
    )

    lower = a * sp.exp(-delta*t)
    rate_upper = sp.simplify(
        -sp.log(lower)/t
    )
    rate_limit = sp.simplify(
        sp.limit(rate_upper, t, sp.oo)
    )

    return {
        "single_resonance_lower": str(lower),
        "negative_log_rate_upper": str(rate_upper),
        "limit": str(rate_limit),
        "pass": bool(rate_limit == delta),
    }


def symbolic_low_frequency_ratio_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, CM, astar, dM, ds = sp.symbols(
        "t C_M a_star d_M delta_star",
        positive=True,
        real=True,
    )

    ratio = sp.simplify(
        (CM/astar) * sp.exp(-(dM-ds)*t)
    )

    # Substitute dM=2*ds to test the strict-gap orientation exactly.
    test = sp.simplify(
        ratio.subs(dM, 2*ds)
    )
    lim = sp.limit(test, t, sp.oo)

    return {
        "low_over_total_upper": str(ratio),
        "condition": "delta_star<d_M",
        "test_gap_limit": str(lim),
        "pass": bool(lim == 0),
    }


def symbolic_phase_identity_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    Dr, Di, Gr, Gi, Hr, Hi = sp.symbols(
        "D_r D_i G_r G_i H_r H_i",
        real=True,
    )

    D = Dr + sp.I*Di
    G = Gr + sp.I*Gi
    H = Hr + sp.I*Hi
    Ht = -D + sp.I*G

    lhs_num = sp.expand_complex(
        sp.im(Ht*sp.conjugate(H))
    )

    rhs_num = sp.expand_complex(
        -sp.im(D*sp.conjugate(H))
        + sp.re(G*sp.conjugate(H))
    )

    residual = sp.simplify(lhs_num-rhs_num)

    return {
        "identity": (
            "Im(H_t Hbar)"
            "=-Im(D Hbar)+Re(G Hbar)"
        ),
        "lhs": str(lhs_num),
        "rhs": str(rhs_num),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_projected_cancellation_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    C, W0, W1, Delta = sp.symbols(
        "C W0 W1 Delta",
        positive=True,
        real=True,
    )

    upper = sp.simplify(
        (C+Delta)*W0**2/(W1*W0)
    )
    expected = sp.simplify(
        (C+Delta)/(W1/W0)
    )
    residual = sp.simplify(
        upper-expected
    )

    return {
        "projected_ratio_upper": str(upper),
        "expected": str(expected),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_noncancellation_contradiction_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    eta, W0, W1, Delta = sp.symbols(
        "eta W0 W1 Delta",
        positive=True,
        real=True,
    )

    lower = sp.simplify(
        eta*W1/W0 - Delta
    )

    return {
        "assumption": "|Re(G Hbar)|>=eta W1 W0",
        "phase_velocity_lower": str(lower),
        "with_delta_max_1": "eta*(W1/W0)-1",
        "conclusion": (
            "if W1/W0->infinity then bounded phase velocity is impossible"
        ),
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v408-summary",
        default="rot_rh_nonattained_support_migration_v408_SUMMARY.json",
    )
    ap.add_argument(
        "--v390-summary",
        default="rot_rh_nonattained_subexponential_envelope_v390_SUMMARY.json",
    )
    ap.add_argument(
        "--v388-summary",
        default="rot_rh_nonattained_supremum_envelope_v388_SUMMARY.json",
    )
    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_nonattained_phase_moment_cancellation_v409",
    )

    args = ap.parse_args()

    print("=" * 230)
    print("ROT-RH v409 — NONATTAINED ABSOLUTE-FREQUENCY ESCAPE / PHASE-MOMENT CANCELLATION THEOREM")
    print("=" * 230)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 230)

    v408 = load_json(args.v408_summary)
    v390 = load_json(args.v390_summary)
    v388 = load_json(args.v388_summary)
    v405 = load_json(args.v405_summary)

    v408_ok = bool(
        v408 is not None
        and v408.get("verdict")
        == "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS"
    )
    v390_ok = bool(
        v390 is not None
        and v390.get("verdict")
        == "NONATTAINED_SUBEXPONENTIAL_ENVELOPE_THEOREM_PASS"
    )
    v388_ok = bool(
        v388 is not None
        and v388.get("verdict")
        == "NONATTAINED_SUPREMUM_MIGRATION_THEOREM_PASS"
    )
    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )

    print("[1] Upstream")
    print("v408 support migration theorem           :", v408_ok)
    print("v390 absolute-envelope theorem           :", v390_ok)
    print("v388 coefficient/overtaking theorem      :", v388_ok)
    if v388 is not None:
        print("v388 verdict                             :", v388.get("verdict"))
    print("v405 recombined collision architecture   :", v405_ok)

    print("\n[2] Exact algebra")

    with tqdm(
        total=5,
        desc="phase-moment theorem identities",
        unit="identity",
    ) as bar:
        mass = symbolic_mass_rate_check()
        bar.update(1)

        low = symbolic_low_frequency_ratio_check()
        bar.update(1)

        phase = symbolic_phase_identity_check()
        bar.update(1)

        cancel = symbolic_projected_cancellation_check()
        bar.update(1)

        contradiction = symbolic_noncancellation_contradiction_check()
        bar.update(1)

    print("actual-mass rate identity                :", mass.get("pass"))
    print("low-frequency exponential suppression    :", low.get("pass"))
    print("phase first-moment identity              :", phase.get("pass"))
    print("projected cancellation bound             :", cancel.get("pass"))
    print("noncancellation contradiction algebra    :", contradiction.get("pass"))

    algebra_pass = bool(
        mass.get("pass")
        and low.get("pass")
        and phase.get("pass")
        and cancel.get("pass")
        and contradiction.get("pass")
    )

    print("\n[3] Actual physical absolute-mass theorem")

    mass_steps = [
        (
            "FIXED_RESONANCE_NONVANISHING",
            "v388: for every fixed rho, inf_(E in I)|c_rho(E)|>0 on every compact E-tube I.",
        ),
        (
            "SUMMABLE_MAJORANT",
            "v390: sum A_rho<infinity with A_rho>=sup_I|c_rho(E)|.",
        ),
        (
            "ACTUAL_MASS_DECAY",
            "W0(t,E)=sum |c_rho(E)|e^(-delta_rho t) tends to zero uniformly.",
        ),
        (
            "ZERO_EXPONENTIAL_RATE",
            "Because inf delta=0 and each selected coefficient has a positive tube infimum, sup_E[-log W0]/t->0.",
        ),
        (
            "LOW_FREQUENCY_SUPPRESSION",
            "For every fixed M, the gamma<=M absolute mass is exponentially negligible relative to W0.",
        ),
        (
            "ABSOLUTE_FREQUENCY_ESCAPE",
            "inf_E W1/W0 -> +infinity, where W1=sum gamma |c_rho(E)|e^(-delta t).",
        ),
    ]

    for key, value in mass_steps:
        print(f"{key:46s}: {value}")

    print("\n[4] Exact signed phase-moment theorem")

    phase_steps = [
        (
            "SIGNED_MOMENTS",
            "H=sum b_rho, D=sum delta_rho b_rho, G=sum gamma_rho b_rho.",
        ),
        (
            "TIME_DERIVATIVE",
            "partial_t H=-D+iG exactly.",
        ),
        (
            "PHASE_VELOCITY",
            "omega |H|^2=-Im(D Hbar)+Re(G Hbar).",
        ),
        (
            "DELTA_BOUND",
            "For nontrivial zeros, 0<=delta_rho<1, hence sum delta|b|<=W0.",
        ),
        (
            "BOUNDED_PHASE_IMPLIES_CANCELLATION",
            "If |omega|<=C, then |Re(G Hbar)|/(W1 W0) <= (C+1)/(W1/W0)->0.",
        ),
        (
            "FULL_LOG_DERIVATIVE",
            "If |H_t/H|<=C, then |G|/W1 <= (C+1)/(W1/W0)->0.",
        ),
    ]

    for key, value in phase_steps:
        print(f"{key:46s}: {value}")

    print("\n[5] Explicit contradiction criterion")

    criteria = [
        (
            "PROJECTED_NONCANCELLATION",
            "If |Re(G Hbar)|>=eta W1 W0 eventually for some eta>0, then |omega|>=eta(W1/W0)-1->infinity.",
        ),
        (
            "VECTOR_NONCANCELLATION",
            "If |G|>=eta W1 eventually, a bounded full logarithmic derivative is impossible.",
        ),
        (
            "INTERPRETATION",
            "A compact regular physical phase branch requires an increasingly exact high-frequency signed cancellation.",
        ),
    ]

    for key, value in criteria:
        print(f"{key:46s}: {value}")

    print("\n[6] Remaining RH-strength theorem")

    remaining = [
        (
            "PHASE_MOMENT_NONCANCELLATION",
            "Prove a uniform eta>0 projected first-moment lower bound on the fixed-k tube, thereby excluding the nonattained off-critical edge.",
        ),
        (
            "OR_PHASE_LOCK_CONSTRUCTION",
            "Prove the normalized projected cancellation actually tends to zero with enough rate/regularity to yield the singular diagonal fixed-root phase lock.",
        ),
        (
            "PERSISTENT_CANCELLATION_SET",
            "Equivalently, characterize whether a continuous compact ordered root can remain forever in the vanishing first-moment cancellation set.",
        ),
        (
            "TRANSVERSALITY_TRANSFER",
            "Once the diagonal phase law is closed, combine with v405 multiplicity-aware slope and v392 summable transfer.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:46s}: {value}")

    # Be slightly tolerant about the historical v388 verdict name in case an
    # older generated packet used a semantically equivalent string.
    if v388 is not None and not v388_ok:
        v388_text = str(v388.get("verdict", ""))
        if (
            "NONATTAINED" in v388_text
            and "MIGRATION" in v388_text
            and "PASS" in v388_text
        ):
            v388_ok = True

    theorem_pass = bool(
        v408_ok
        and v390_ok
        and v388_ok
        and v405_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS"
        if theorem_pass
        else
        "NONATTAINED_PHASE_MOMENT_CANCELLATION_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_PROJECTED_FIRST_MOMENT_NONCANCELLATION_OR_CLASSIFY_PERSISTENT_CANCELLATION_ROOT_SET"
    )

    print("\n" + "=" * 230)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "NONATTAINED PHYSICAL STATUS              :",
        "COMPACT PHASE LOCK REQUIRES ASYMPTOTICALLY PERFECT FIRST-MOMENT CANCELLATION",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 230)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v408_ok": v408_ok,
            "v390_ok": v390_ok,
            "v388_ok": v388_ok,
            "v388_verdict": (
                v388.get("verdict")
                if v388 is not None
                else None
            ),
            "v405_ok": v405_ok,
        },
        "exact_algebra": {
            "mass_rate": mass,
            "low_frequency_suppression": low,
            "phase_identity": phase,
            "projected_cancellation": cancel,
            "noncancellation_contradiction": contradiction,
        },
        "absolute_mass_theorem": {
            key: value for key, value in mass_steps
        },
        "phase_moment_theorem": {
            key: value for key, value in phase_steps
        },
        "contradiction_criteria": {
            key: value for key, value in criteria
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "The actual branchwise absolute frequency scale diverges uniformly "
            "on compact E-tubes. Therefore any bounded physical phase velocity "
            "requires the normalized signed projected first frequency moment "
            "to vanish. Excluding or constructing that persistent cancellation "
            "is the remaining nonattained RH-strength problem."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v409 — nonattained phase-moment cancellation necessity

On a compact E-tube define

`W0=sum |c_rho(E)| exp(-delta_rho t)`

and

`W1=sum gamma_rho |c_rho(E)| exp(-delta_rho t)`.

v388 gives a positive lower bound on each fixed residue coefficient across
the tube.  Combined with `inf delta_rho=0`, this proves the ACTUAL mass W0
has zero exponential decay rate.

For each fixed M, the finitely many `gamma<=M` terms have a positive minimum
delta and are exponentially negligible relative to W0.  Hence

`inf_E W1/W0 -> +infinity`.

Now put

`H=sum b_rho`,
`D=sum delta_rho b_rho`,
`G=sum gamma_rho b_rho`.

Then

`H_t=-D+iG`

and

`omega |H|^2
 = -Im(D Hbar)+Re(G Hbar)`,

where `omega=partial_t arg H`.

Since `delta_rho<1`, bounded physical phase velocity implies

`|Re(G Hbar)|/(W1 W0)
 <= (C+1)/(W1/W0)
 -> 0`.

Thus a compact regular physical phase branch in the genuinely nonattained
case requires asymptotically perfect projected first-frequency cancellation.

Conversely, any uniform lower bound

`|Re(G Hbar)| >= eta W1 W0`

forces

`|omega| >= eta(W1/W0)-1 -> infinity`

and excludes such a phase lock.

This is the next RH-strength arithmetic dichotomy.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_NONATTAINED_PHASE_MOMENT_CERTIFICATE_V1",
        "required_claims": {
            "actual_absolute_mass_rate": "ZERO_EXPONENTIAL_RATE",
            "absolute_mean_ordinate": "DIVERGES_UNIFORMLY",
            "projected_phase_moment": (
                "NONCANCELLATION_LOWER_BOUND_OR_EXPLICIT_VANISHING_LAW"
            ),
            "fixed_root_phase_velocity": "CONTROLLED_OR_CONTRADICTION",
            "eventual_transversality": "RIGOROUS",
        },
        "primary_routes": {
            "exclude_nonattained": (
                "prove |Re(G Hbar)| >= eta W1 W0 on eventual fixed-k tube"
            ),
            "singular_phase_lock": (
                "prove normalized projected cancellation ->0 with sufficient "
                "rate and derive fixed-root convergence"
            ),
        },
        "already_closed": {
            "support_frequency_migration": "v408",
            "coefficient_nonvanishing": "v388",
            "absolute_majorant": "v390",
            "recombined_collision": "v405",
            "recursive_weighted_four_jet": "v402",
        },
        "forbidden_as_proof": [
            "single winning resonance assumption",
            "finite cutoff regression",
            "absolute-envelope estimate alone",
            "fixed-epsilon boundary continuation",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
