# ROT-RH v478 — half-plane lock / vanishing coherence duty cycle

Let

`H(s)=sum a_j e^(-delta_j s)e^(i gamma_j s)`

and `W0=sum|a_j|`.

After one constant rotation and a bounded carrier `nu`, suppose the whole
window lies in a sector

`|arg Z(s)|<=Theta<pi/2`.

Then

`Re Z>=cos(Theta)|H|`.

The exponential integral is exact:

`int_0^T e^((-delta+i omega)s)ds
 =[e^((-delta+i omega)T)-1]/(-delta+i omega)`,

so

`|int_0^T e^((-delta+i omega)s)ds|
 <=2/|omega|`.

Consequently

`int_0^T |H|ds/W0
 <=2 sec(Theta)
   [sum |a_j|/|gamma_j+nu|]/W0`.

The right side contains no factor `T`.

Nonattained absolute-frequency escape implies the weighted inverse-frequency
moment tends to zero. Hence the total normalized coherence area tends to zero
on ANY locked window.

For every `kappa>0`,

`measure{s:|H(s)|>=kappa W0}
 <=2 sec(Theta) I_-1/kappa
 ->0`.

If the v411 `O(1/t)` short-window lock estimate is chained from `t` to
`(1+c)t`, its total phase excursion is

`(C/h)log(1+c)+o(1)`.

Choosing `c` so this is `<pi/2` produces a locked window of length `c t`.

Thus any bounded nonattained branch satisfying v411 must track a normalized
high-coherence set whose **absolute t-thickness tends to zero inside a
linearly growing window**.

**Verdict:** EXACT_HALFPLANE_LOCK_VANISHING_DUTY_CYCLE_PASS

The remaining theorem is necessarily joint in `(t,E)`: exclude a transverse
ordered root from tracking this vanishing-duty-cycle set, or realize the
tracking through the arithmetic/Fredholm structure.
