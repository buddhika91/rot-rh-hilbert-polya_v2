# ROT-RH v471 — bump off-critical endpoint lock / attained-resonance dichotomy

## 1. Endpoint probability measure

For a right-half zero with `a=beta-1/2>0`, set

`u=(Gamma-E)L`

and

`A_L=int p(x)e^(aLx)dx/x`.

Normalize

`dnu_L=p(x)e^(aLx)dx/(x A_L)`.

For every fixed `eps>0`, comparison of the regions
`x<=1-eps` and `x>=1-eps/2` gives

`nu_L([0,1-eps]) <= K_eps e^(-a eps L/2)`.

Hence

`nu_L => delta_1`.

Therefore, uniformly for `|u|<=U`,

`int sin(ux)dnu_L -> sin u`

and

`int x cos(ux)dnu_L -> cos u`.

## 2. Resonance amplitude

For every `c<1`,

`A_L >= C_(a,c)e^(a c L)`.

So the resonant amplitude dominates every polynomial background.

## 3. Root-lock theorem

Suppose on a fixed compact `u`-cell the full secular equation is

`sigma A_L S_L(u)+R_L(u)=C_k`

with

`sup |R_L|/A_L -> 0`.

Then every root sequence in the cell satisfies

`sin u_L -> 0`.

If the branch remains in one cell around `n*pi`, it follows that

`u_L -> n*pi`

and therefore

`E_L=Gamma-n*pi/L+o(1/L)`.

If also

`sup |partial_u R_L|/A_L ->0`,

the normalized derivative tends to `sigma cos u`, giving eventual local
transversality and uniqueness near each `n*pi`.

## 4. Internal quartet remainder

The left-half reflected partner is exponentially negligible relative to `A_L`.

For the same-right-half nonresonant channel at fixed nonzero frequency
`delta`, the flat-bump endpoint Fourier lemma gives

`|I_L(delta)|/A_L=O(L^(-1/3))`.

The mechanism is an eventually unimodal endpoint peak:
distance to the endpoint `Theta(L^(-1/3))`, width `Theta(L^(-2/3))`,
followed by one integration by parts at frequency `delta L`.

Thus an isolated strictly rightmost quartet is asymptotically governed by its
low resonant channel.

## 5. Interpretation

This proves the bump-specific form of the old off-critical pinning mechanism:

`u -> n*pi`, so `E -> Gamma`.

Therefore an off-critical quartet does not automatically destroy cutoff
independence.  Cutoff removal and RH must remain logically separate:
the Fredholm-Xi identity, or an equivalent global spectral uniqueness property,
is still required to exclude nonreal Xi zeros.

## 6. Status

Verdict: **BUMP_SINGLE_DOMINANT_OFFCRITICAL_ENDPOINT_LOCK_THEOREM_PASS**

Closed here: strict single-dominant off-critical bump resonance.

Still open: tied rightmost clusters, nonattained/switching right edge, global
branch ordering, and the Fredholm-Xi identity.
