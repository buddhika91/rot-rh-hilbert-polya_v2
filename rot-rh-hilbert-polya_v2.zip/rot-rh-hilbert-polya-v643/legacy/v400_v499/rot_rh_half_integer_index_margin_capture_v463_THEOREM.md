# ROT-RH v463 — half-integer index-margin / multiplicity capture theorem

## 1. Collision plateaus

For the normalized bump phase

`s_p(u)=S_p(u)/pi`,

v462 gives

`|s_p(u)-sgn(u)/2| <= 2(1+sqrt(pi))/(pi|u|)`.

Therefore a multiplicity-`m` collision has saturation plateaus

`-m/2` and `+m/2`.

## 2. Half-integer labels are uniformly interior

Let the canonical local counting jump be

`N_- -> N_-+m`.

Its midpoint is

`B_mid=N_-+m/2`.

The `m` action labels are

`lambda_j=N_-+j-1/2`, `j=1,...,m`.

Hence

`lambda_j-B_mid=j-(m+1)/2`.

The distances to the two collision plateaus are exactly

`j-1/2`

and

`m-j+1/2`.

Both are at least `1/2`.

Thus the minimum index margin is exactly

`1/2`,

independently of multiplicity.

## 3. Finite-L midpoint error

Assume the recombined regular background satisfies on the associated branch

`B_reg(L,E_j(L))=B_mid+epsilon_j(L)`

with

`|epsilon_j(L)|<=epsilon<0.5`.

Then the required collision phase remains at distance at least

`d=1/2-epsilon=4.0000000000000002e-01`

from either saturation plateau.

Using v462,

`|u_j(L)|
 <= 2m(1+sqrt(pi))/[pi(1/2-epsilon)]`.

Therefore

`|E_j(L)-gamma|
 <= 2m(1+sqrt(pi))
    /[pi(1/2-epsilon)L]`.

Every multiplicity branch converges to the same collision ordinate.

For exact midpoint alignment `epsilon=0`,

`|u_j| <= [4(1+sqrt(pi))/pi] m
        ~= 3.5299978789261877e+00 m`.

## 4. Important logical gain

The collision-capture problem is no longer an arbitrary transversality theorem.

It has been reduced to the **midpoint-background estimate**

`sup_j |B_reg-(N_-+m/2)| < 1/2`.

A natural stronger target is

`B_reg(L,E_j(L))-(N_-+m/2) -> 0`.

If that is proved from the recombined finite-part/index structure, fixed-mode
cutoff independence follows immediately from the v462/v463 phase geometry.

No derivative of the root branch and no no-fold condition are required for
this implication.

## 5. Remaining analytic theorem

Prove the local recombined background midpoint law without known zero
ordinates:

1. isolate the multiplicity-`m` principal collision from the full recombined
   fixed point;
2. show the remaining regular phase carries the midpoint count
   `N_-+m/2`;
3. prove its finite-bump error is eventually `<1/2`, preferably `o(1)`;
4. combine with this theorem to obtain the `O(1/L)` collision packet capture.

This is still an analytic obligation; v463 does not prove RH or the exact
Fredholm identity.
