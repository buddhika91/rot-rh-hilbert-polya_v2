# ROT-RH v468 — completed quartet phase / local midpoint target bridge

## A. Off-critical quartet phase cancellation

Let

`Xi(t)=xi(1/2+i t)`.

An off-critical zero

`rho=1/2+a+i gamma`, `a!=0`,

maps to

`tau=gamma-i a`.

The standard symmetries give the quartet

`tau, conj(tau), -tau, -conj(tau)`.

Group its even canonical factor as

`Q_(a,gamma)(t)
 =(1-t^2/tau^2)(1-t^2/conj(tau)^2)`.

For real `t`,

`Q_(a,gamma)(t)
 = |1-t^2/tau^2|^2
 >0`.

Equivalently, the symbolic computation gives the manifest form

`Q
 = [ (gamma^2-a^2-t^2)^2 + 4a^2 gamma^2 ]
   / (gamma^2+a^2)^2`.

So an off-critical quartet changes the completed magnitude but contributes zero
fractional real-axis phase modulo `pi`.

No RH or simplicity assumption is used.

## B. Critical collision

A critical-line zero of multiplicity `m` at `gamma` contributes

`(1-t^2/gamma^2)^m`.

After removing that local factor,

`G_gamma(t)=Xi(t)/(1-t^2/gamma^2)^m`

is real and nonzero on a sufficiently small isolated real tube.

Therefore

`|Re G_gamma|/|G_gamma|=1`.

The exact completed target therefore satisfies the strongest possible v465
half-plane condition.

## C. Relative-convergence theorem

Let `R_L(t)` be the collision-subtracted finite bump regular factor and let
`sigma_gamma=sign G_gamma` on the tube.

If

`sup_I | sigma_gamma R_L/|R_L| - 1 | <= eta_L < 1`,

then

`|Re R_L|/|R_L| >= sqrt(1-eta_L^2)`

and the v465 angular half-plane gap is at least

`arccos(eta_L)`.

Consequently,

`|E_L-gamma|
 <= 2m(1+sqrt(pi))
    / [L arccos(eta_L)]`.

Any eventual uniform `eta_L<=eta<1` gives `O(1/L)` cutoff capture.

If `eta_L->0`,

`|E_L-gamma|
 <= [4m(1+sqrt(pi))/pi+o(1)]/L`.

For multiplicity one the midpoint constant is

`3.5299978789261877e+00`.

## D. New analytic target

The midpoint/half-plane problem is no longer an abstract phase-density theorem.

It is enough to prove the weaker phase statement

`R_L/|R_L| -> sign(G_gamma)`

uniformly on each eventual isolated critical collision tube.

A sufficient derivative form is

`anchor angular error + int_I |Im(R_L'/R_L)| -> 0`.

This target must preserve the functional-equation quartet recombination.
Bounding individual off-critical Mellin residues separately is structurally
wrong for fractional phase.

## E. Scope

This does not prove the relative-convergence theorem itself, global cutoff
independence, RH, or the Fredholm-Xi identity.

It also shows why phase-root cutoff independence alone cannot prove RH:
off-critical quartets are strictly positive on the real t-axis and are
therefore invisible to the completed fractional phase.
