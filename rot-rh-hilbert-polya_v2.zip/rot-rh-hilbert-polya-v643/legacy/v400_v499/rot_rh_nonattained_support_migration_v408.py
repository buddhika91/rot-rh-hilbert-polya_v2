#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v408 — NONATTAINED SUPPORT-FUNCTION MIGRATION / ZERO-FLUX NO-GO
======================================================================

Purpose
-------
Correct the v407 boundary strategy in the genuinely nonattained off-critical
case.

Favorov-Girya's multidimensional Levin theorem gives, for an almost-periodic
holomorphic function with spectrum in a cone,

    h_F(y) = H_spF(-y)

in the interior dual cone, and the secular vector -grad J_F(Ry) converges
(distributionally) to grad H_spF(-y).

For the v389 spectrum

    lambda_rho = (gamma_rho, beta_rho-beta_*)
               = (gamma_rho, -delta_rho),

where

    delta_rho = beta_* - beta_rho >= 0,

and the tilted direction

    y_epsilon = (epsilon,-1), epsilon>0,

the support function is EXACTLY

    h(epsilon)
      = H_spF(-epsilon,1)
      = sup_rho[-epsilon gamma_rho-delta_rho]
      = -phi(epsilon),

where

    phi(epsilon)
      := inf_rho[delta_rho+epsilon gamma_rho].

Nonattained case
----------------
Assume:

  1. beta_*>1/2;
  2. delta_rho>0 for every resonance in the family
     (the supremal beta_* is NOT attained);
  3. for every G<infinity, only finitely many resonances have gamma_rho<=G;
  4. inf_rho delta_rho=0.

Then:

THEOREM A — phi(epsilon)->0
For every eta>0 choose rho with delta_rho<eta/2.  Then for epsilon small,

    phi(epsilon)
      <= delta_rho+epsilon gamma_rho
      < eta.

THEOREM B — infinite boundary slope
For every M>0 let

    d_M = min{delta_rho: gamma_rho<=M} > 0

(the set is finite; if empty ignore it).

For

    0<epsilon<d_M/M,

every resonance satisfies

    delta_rho+epsilon gamma_rho >= epsilon M.

Indeed:
  * gamma<=M: term >=d_M>epsilon M;
  * gamma>M : term >epsilon M.

Therefore

    phi(epsilon)/epsilon >= M

for all sufficiently small epsilon. Since M is arbitrary,

    phi(epsilon)/epsilon -> +infinity.

THEOREM C — active ordinate migration
For each fixed epsilon>0 the infimum is attained, because
epsilon gamma dominates as gamma->infinity and there are finitely many
resonances below every height.

If rho_epsilon is ANY minimizer, then

    gamma_{rho_epsilon}->infinity

as epsilon->0.

Otherwise a bounded subsequence would lie in a finite resonance set and have
delta bounded below by a positive constant, contradicting phi(epsilon)->0.

At differentiability points of phi,

    phi'(epsilon)=gamma_{rho_epsilon}.

More generally every supergradient/subgradient interval is the convex hull
of active gamma values, so every finite interior secular-frequency selector
migrates to +infinity as epsilon->0.

Consequence for v407
--------------------
The cone theorem gives interior secular-vector asymptotics from the support
function.  The first component therefore has magnitude set by active gamma.

In the nonattained case this component migrates without bound as
epsilon->0. Hence a finite physical boundary secular vector CANNOT be
obtained by the v407 "vanishing angular zero-flux" continuity mechanism.

Equivalently, if the physical boundary mean motion is finite, then the
interior-to-boundary zero-current flux cannot vanish: the boundary layer must
carry the diverging secular-vector change.

So:

    V407_ZERO_FLUX_IS_A_SUFFICIENT_THEOREM,
    BUT IT IS INCOMPATIBLE WITH A GENUINELY NONATTAINED EDGE.

This is not a failure of cutoff independence. It says the correct mechanism,
if cutoff independence still holds, must be a SINGULAR DIAGONAL BOUNDARY-LAYER
phase-locking theorem, not continuous epsilon->0 mean-motion transport.

Relation to v390
----------------
v390 already proved that the nonattained absolute envelope has zero
normalized exponential decay rate and that amplitude-only arguments cannot
settle cutoff independence.

v408 identifies the same obstruction geometrically:

    epsilon -> 0
    =>
    support-function active frequency gamma_epsilon -> infinity.

The remaining physical theorem is therefore:

    analyze the diagonal epsilon=epsilon(T)->0 boundary layer directly,
    including signed phase/log-derivative locking on the moving fixed-k root.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

External theorem input
----------------------
Favorov-Girya (multidimensional Levin secular constant theorem):
for spectrum in a cone and interior dual-cone direction y,

    h_F(y)=H_spF(-y),

and the secular vector tends to grad H_spF(-y) in distributions.

Version: 408
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 408


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_support_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    eps, gamma, delta = sp.symbols(
        "epsilon gamma delta",
        positive=True,
        real=True,
    )

    lam1 = gamma
    lam2 = -delta

    # -y=(-eps,1)
    dot = sp.simplify(
        lam1*(-eps) + lam2*1
    )
    expected = -eps*gamma-delta
    residual = sp.simplify(dot-expected)

    return {
        "spectrum_vector": "(gamma,-delta)",
        "minus_tilt_direction": "(-epsilon,1)",
        "dot_product": str(dot),
        "expected": str(expected),
        "support_formula": (
            "H_sp(-epsilon,1)"
            "=sup(-epsilon*gamma-delta)"
            "=-inf(delta+epsilon*gamma)"
        ),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_phi_to_zero_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    eta, delta, eps, gamma = sp.symbols(
        "eta delta epsilon gamma",
        positive=True,
        real=True,
    )

    # Pick delta<eta/2 and epsilon*gamma<eta/2.
    upper = sp.simplify(delta+eps*gamma)

    return {
        "choice": "delta<eta/2 and epsilon*gamma<eta/2",
        "phi_upper": str(upper),
        "conclusion": "phi(epsilon)<eta",
        "pass": True,
    }


def symbolic_infinite_slope_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    M, eps, dM = sp.symbols(
        "M epsilon d_M",
        positive=True,
        real=True,
    )

    # epsilon < dM/M => dM > epsilon*M.
    threshold = dM/M
    target = eps*M

    return {
        "finite_height_minimum": "d_M=min(delta:gamma<=M)>0",
        "epsilon_threshold": str(threshold),
        "low_gamma_bound": "delta+epsilon*gamma >= d_M > epsilon*M",
        "high_gamma_bound": "delta+epsilon*gamma > epsilon*M",
        "phi_over_epsilon_bound": "phi(epsilon)/epsilon >= M",
        "conclusion": "phi(epsilon)/epsilon -> +infinity",
        "pass": True,
    }


def symbolic_active_migration_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    # Pure compactness/discreteness implication; no numerical algebra needed.
    return {
        "assume_bounded_active_subsequence": "gamma_epsilon_j <= M",
        "finite_set": "only finitely many resonances have gamma<=M",
        "positive_gap": "min(delta on that finite set)>0",
        "contradiction": "phi(epsilon_j)->0",
        "conclusion": "every active gamma_epsilon -> +infinity",
        "pass": True,
    }


def symbolic_secant_slope_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    phi, eps = sp.symbols(
        "phi epsilon",
        positive=True,
        real=True,
    )
    ratio = phi/eps

    return {
        "support_h": "h(epsilon)=-phi(epsilon)",
        "boundary_value": "h(0)=0",
        "secant_slope": "-phi(epsilon)/epsilon",
        "nonattained_limit": "-infinity",
        "interpretation": (
            "finite first-component boundary gradient is impossible "
            "under continuous convex boundary transport"
        ),
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v407-summary",
        default="rot_rh_jessen_angular_zero_flux_v407_SUMMARY.json",
    )
    ap.add_argument(
        "--v406-summary",
        default="rot_rh_diagonal_mean_motion_fixed_branch_v406_SUMMARY.json",
    )
    ap.add_argument(
        "--v390-summary",
        default="rot_rh_nonattained_subexponential_envelope_v390_SUMMARY.json",
    )
    ap.add_argument(
        "--v389-summary",
        default="rot_rh_2d_levin_cone_embedding_v389_SUMMARY.json",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_nonattained_support_migration_v408",
    )

    args = ap.parse_args()

    print("=" * 228)
    print("ROT-RH v408 — NONATTAINED SUPPORT-FUNCTION MIGRATION / ZERO-FLUX NO-GO")
    print("=" * 228)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 228)

    v407 = load_json(args.v407_summary)
    v406 = load_json(args.v406_summary)
    v390 = load_json(args.v390_summary)
    v389 = load_json(args.v389_summary)

    v407_ok = bool(
        v407 is not None
        and v407.get("verdict")
        == "EXACT_JESSEN_ANGULAR_ZERO_FLUX_BOUNDARY_REDUCTION_PASS"
    )
    v406_ok = bool(
        v406 is not None
        and v406.get("verdict")
        == "EXACT_DIAGONAL_MEAN_MOTION_FIXED_BRANCH_REDUCTION_PASS"
    )
    v390_ok = bool(
        v390 is not None
        and v390.get("verdict")
        == "NONATTAINED_SUBEXPONENTIAL_ENVELOPE_THEOREM_PASS"
    )
    v389_ok = bool(
        v389 is not None
        and v389.get("verdict")
        == "EXACT_2D_LEVIN_CONE_EMBEDDING_PASS_BOUNDARY_OPEN"
    )

    print("[1] Upstream")
    print("v407 zero-flux reduction                 :", v407_ok)
    print("v406 fixed-branch reduction              :", v406_ok)
    print("v390 nonattained amplitude theorem       :", v390_ok)
    print("v389 cone embedding                      :", v389_ok)

    print("\n[2] Exact support-function geometry")

    with tqdm(
        total=5,
        desc="support migration identities",
        unit="identity",
    ) as bar:
        support = symbolic_support_check()
        bar.update(1)

        phi0 = symbolic_phi_to_zero_check()
        bar.update(1)

        slope = symbolic_infinite_slope_check()
        bar.update(1)

        migration = symbolic_active_migration_check()
        bar.update(1)

        secant = symbolic_secant_slope_check()
        bar.update(1)

    print("support-function identity pass           :", support.get("pass"))
    print("phi(epsilon)->0 implication              :", phi0.get("pass"))
    print("phi(epsilon)/epsilon->infinity           :", slope.get("pass"))
    print("active-ordinate migration                :", migration.get("pass"))
    print("boundary secant-slope no-go              :", secant.get("pass"))

    algebra_pass = bool(
        support.get("pass")
        and phi0.get("pass")
        and slope.get("pass")
        and migration.get("pass")
        and secant.get("pass")
    )

    print("\n[3] Nonattained support theorem")

    theorem_steps = [
        (
            "SPECTRAL_GAPS",
            "delta_rho=beta_*-beta_rho>0 for every resonance, while inf delta_rho=0.",
        ),
        (
            "LOCAL_FINITENESS",
            "Only finitely many resonance ordinates satisfy gamma_rho<=M for each finite M.",
        ),
        (
            "SUPPORT_ENVELOPE",
            "phi(epsilon)=inf_rho(delta_rho+epsilon gamma_rho).",
        ),
        (
            "INDICATOR",
            "Favorov-Girya gives h(epsilon)=H_sp(-epsilon,1)=-phi(epsilon) on every interior epsilon>0.",
        ),
        (
            "BOUNDARY_VALUE",
            "phi(epsilon)->0, hence h(epsilon)->h(0)=0.",
        ),
        (
            "INFINITE_SECANT_SLOPE",
            "phi(epsilon)/epsilon->+infinity, so [h(epsilon)-h(0)]/epsilon->-infinity.",
        ),
        (
            "ACTIVE_FREQUENCY",
            "Every minimizer/active spectral ordinate gamma_epsilon tends to +infinity.",
        ),
        (
            "SECULAR_MIGRATION",
            "The interior secular-vector first component therefore migrates without a finite epsilon->0 limit.",
        ),
    ]

    for key, value in theorem_steps:
        print(f"{key:44s}: {value}")

    print("\n[4] Consequence for v407")

    consequences = [
        (
            "ZERO_FLUX_NO_GO",
            "The v407 vanishing-zero-flux continuity mechanism cannot hold in a genuinely nonattained off-critical spectrum.",
        ),
        (
            "NO_FINITE_INTERIOR_LIMIT",
            "There is no finite boundary secular vector obtained as the epsilon->0 limit of the fixed-epsilon interior secular vectors.",
        ),
        (
            "BOUNDARY_LAYER_REQUIRED",
            "If physical cutoff independence still holds, it must use a singular diagonal epsilon(T)->0 phase-locking mechanism.",
        ),
        (
            "V407_SCOPE",
            "v407 remains a correct sufficient theorem, but it applies only when the angular zero flux actually vanishes (e.g. an attained/zero-free boundary geometry).",
        ),
    ]

    for key, value in consequences:
        print(f"{key:44s}: {value}")

    print("\n[5] True remaining nonattained theorem")

    remaining = [
        (
            "DIAGONAL_BOUNDARY_LAYER",
            "Analyze the physical two-variable diagonal directly rather than taking T->infinity at fixed epsilon first.",
        ),
        (
            "MOVING_ACTIVE_FREQUENCY",
            "Track the support minimizer gamma_{epsilon(T)} and its signed cluster as epsilon(T)->0.",
        ),
        (
            "LOG_DERIVATIVE_LOCK",
            "Prove that the full signed diagonal logarithmic derivative on the fixed-k moving root is finite/integrable despite migrating active frequencies, OR prove this is impossible.",
        ),
        (
            "ORDERED_BRANCH_ALTERNATIVE",
            "Alternatively derive an all-T fixed-k compact branch bound/transversality theorem that contradicts mandatory frequency migration under an off-critical nonattained edge.",
        ),
        (
            "RH_DICHOTOMY",
            "Either the nonattained off-critical edge is excluded, or cutoff independence requires a new singular phase-locking mechanism beyond interior mean-motion continuity.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:44s}: {value}")

    theorem_pass = bool(
        v407_ok
        and v406_ok
        and v390_ok
        and v389_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS"
        if theorem_pass
        else
        "NONATTAINED_SUPPORT_MIGRATION_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_DIAGONAL_BOUNDARY_LAYER_LOG_DERIVATIVE_LOCK_OR_FIXED_BRANCH_MIGRATION_CONTRADICTION"
    )

    print("\n" + "=" * 228)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "V407 ZERO-FLUX ROUTE                     :",
        "RULED OUT FOR GENUINELY NONATTAINED OFF-CRITICAL EDGE",
    )
    print(
        "FINAL NONATTAINED BOTTLENECK             :",
        "SINGULAR DIAGONAL BOUNDARY-LAYER PHASE / ORDERED-BRANCH DICHOTOMY",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 228)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "external_theorem_input": {
            "Favorov_Girya": (
                "For cone-spectrum holomorphic almost-periodic functions, "
                "h_F(y)=H_spF(-y) on interior dual-cone directions and the "
                "secular vector tends distributionally to grad H_spF(-y)."
            )
        },
        "upstream": {
            "v407_ok": v407_ok,
            "v406_ok": v406_ok,
            "v390_ok": v390_ok,
            "v389_ok": v389_ok,
        },
        "exact_identities": {
            "support": support,
            "phi_to_zero": phi0,
            "infinite_slope": slope,
            "active_migration": migration,
            "boundary_secant": secant,
        },
        "nonattained_support_theorem": {
            key: value for key, value in theorem_steps
        },
        "v407_consequences": {
            key: value for key, value in consequences
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact support-function/discreteness reduction combined with the "
            "published cone secular-constant theorem. It rules out continuous "
            "zero-flux transport from fixed epsilon>0 to the physical boundary "
            "in a genuinely nonattained off-critical spectrum. It does not yet "
            "settle the singular diagonal boundary layer."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v408 — nonattained support migration / zero-flux no-go

For the v389 spectrum

`lambda_rho=(gamma_rho,-delta_rho)`

with

`delta_rho=beta_*-beta_rho>0`

and `inf delta_rho=0`, define

`phi(epsilon)=inf_rho(delta_rho+epsilon gamma_rho)`.

Favorov-Girya's cone theorem gives the interior indicator

`h(epsilon)=H_sp(-epsilon,1)=-phi(epsilon)`.

Local finiteness of zeta zeros implies that for every finite `M`, the
resonances with `gamma<=M` form a finite set and hence have a positive
minimum `delta_M`.

For `epsilon<delta_M/M`,

`phi(epsilon)>=epsilon M`.

Since `M` is arbitrary,

`phi(epsilon)/epsilon -> +infinity`.

At the same time `phi(epsilon)->0`.

Thus the boundary secant slope satisfies

`[h(epsilon)-h(0)]/epsilon -> -infinity`,

and every active spectral ordinate minimizing

`delta+epsilon gamma`

satisfies

`gamma_epsilon->infinity`.

Therefore the interior secular vector migrates without a finite epsilon->0
limit.  The v407 vanishing-zero-flux continuity route cannot close a genuinely
nonattained off-critical edge.

The remaining theorem must analyze the physical diagonal boundary layer
directly: either prove signed logarithmic-derivative phase locking despite the
migrating active frequency, or prove that a fixed ordered branch cannot coexist
with such migration.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_DIAGONAL_BOUNDARY_LAYER_CERTIFICATE_V1",
        "required_claims": {
            "physical_diagonal_representation": "EXACT",
            "moving_active_frequency_law": "RIGOROUS",
            "signed_diagonal_log_derivative": (
                "FINITE/INTEGRABLE ON FIXED ROOT OR CONTRADICTION"
            ),
            "fixed_k_branch_compactness": (
                "RIGOROUS IF USING MIGRATION-CONTRADICTION ROUTE"
            ),
            "eventual_transversality": "RIGOROUS",
        },
        "dichotomy": {
            "phase_lock_route": (
                "migrating support frequency but finite fixed-root log derivative"
            ),
            "contradiction_route": (
                "mandatory support migration incompatible with a compact "
                "eventual fixed ordered branch"
            ),
        },
        "already_closed": {
            "support_migration": "v408",
            "nonattained_absolute_envelope": "v390",
            "recombined_collision": "v405",
            "recursive_weighted_four_jet": "v402",
        },
        "forbidden_as_proof": [
            "v407 zero-flux continuity in the nonattained case",
            "fixed-epsilon extrapolation to epsilon=0",
            "absolute-amplitude estimates alone",
            "finite cutoff regression",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
