# ROT-RH v470 — constant-u moving-cell commutator / barrier theorem

## 1. Exact moving-cell generator

For `E_u(L)=gamma-u/L` and `B_L=P_L-M_L`,

`d/dL B_L(E_u)=[C_q(L,E_u)+u B_E(L,E_u)]/L^2`.

Define `H_u=C_q+u B_E`. By v469,

`d/dL log r_L(E_u)=-i H_u/L^2`.

## 2. Principal collision cancellation

For `B_coll=sigma m S_p((gamma-E)L)`, on `E=E_u`,

`C_coll=sigma m u L P_c(u)`,

`B_E,coll=-sigma m L P_c(u)`,

therefore `C_coll+u B_E,coll=0` exactly.

The constant-u observable is collision-subtracted by geometry, without splitting
singular G7 and R7X continuations.

## 3. Remote critical-line sector

For `Delta=gamma'-gamma`,

`d phase_gamma'/dL=sigma' m' Delta P_c(Delta L+u)`.

Four integrations by parts give

`P_c(v)=[p'''(0)+int_0^1 p''''(x)cos(vx)dx]/v^4`,

with `p'''(0)=-12`. Hence `|P_c(v)|<=C4/|v|^4`, where
`C4=12+||p''''||_1`.

For `L>=2|u|/|Delta|`,

`|phase_gamma'(infinity)-phase_gamma'(L)|
 <=16m'C4/(3|Delta|^3L^3)`.

Since `N(T)=O(T log T)`, the sum `sum m'/|gamma'-gamma|^3` converges. Thus the
complete remote critical-line sector has an absolutely summable `O(L^-3)`
boundary-phase tail.

## 4. Two-boundary barrier

If a continuous local branch starts inside `|u|<U` and both boundaries satisfy

`|epsilon_L(+/-U)|<=eta`

with

`eta+2m(1+sqrt(pi))/(pi U)<1/2`,

then no local half-integer label occurs on either boundary. The branch cannot
leave the moving cell, hence

`|E(L)-gamma|<U/L`.

For selected multiplicity the exact midpoint threshold as `eta->0` is

`U>3.5299978789261877e+00`.

Selected test: `U=5.0`, `eta=0.05`, margin
`9.7000212107381245e-02`, barrier closes `True`.

## 5. Remaining target

Only two explicit signed primitives are needed:

`Pi_(+U)(L)=int H_(+U)(s)ds`,

`Pi_(-U)(L)=int H_(-U)(s)ds`.

The principal collision is absent exactly and every other critical-line collision
is already summable. The remaining dangerous zero-side sector is the
off-critical/collective sector.

If `Pi_(+/-U)=O(L^(2-eps))` and the limiting phase class is the completed midpoint
class, the barrier gives fixed-mode `O(1/L)` capture.

## 6. Scope

Verdict: **EXACT_CONSTANT_U_COLLISION_COMMUTATOR_AND_BARRIER_PASS**.

This is an exact reduction theorem, not RH and not the Fredholm-Xi identity.
