# ROT–RH v446 attack: Riesz → Fredholm → Fejér → Thorin

## Main result

The successful Riesz-1 prime phase and the determinant-native primitive-prime clock are not competing constructions.

Let

\[
\tau_n=\log n,\qquad T=\log X,
\]

and

\[
W_T(\tau)=\left(1-\frac{\tau}{T}\right)_+.
\]

Then the following identities are exact.

### 1. Riesz-1 is uniform recursive-horizon averaging

\[
W_T(\tau)
=
\frac1T\int_0^T {\bf 1}_{\tau\le u}\,du.
\]

Therefore

\[
P_T(E)
=
\sum_n
\frac{\Lambda(n)}{\log n\sqrt n}
W_T(\log n)\sin(E\log n)
\]

is exactly the Cesàro average of the sharp recursive-clock prime phase over all observation horizons \(0\le u\le T\).

### 2. Riesz-1 is an observer Gram kernel

After symmetrization,

\[
w_T(u)=\left(1-\frac{|u|}{T}\right)_+.
\]

Let

\[
v_\tau(x)=T^{-1/2}{\bf 1}_{[\tau,\tau+T]}(x).
\]

Then

\[
w_T(\tau-\sigma)
=
\langle v_\tau,v_\sigma\rangle.
\]

Hence every finite matrix

\[
[w_T(\tau_i-\tau_j)]_{i,j}
\]

is positive semidefinite. Its Fourier transform is

\[
\widehat w_T(E)
=
T\left(\frac{\sin(ET/2)}{ET/2}\right)^2\ge0.
\]

Thus the regulator selected numerically by the zero-free audit has an exact ROT interpretation as overlap of finite observation windows.

### 3. Riesz-1 is a Cesàro regularization of the exact prime-cycle Fredholm determinant

On

\[
\mathcal H_P=\ell^2(\mathbb P)
\]

define

\[
C|p\rangle=(\log p)|p\rangle,\qquad
T_P(s)=e^{-sC}.
\]

For \(\Re s>1\),

\[
\det(I-T_P(s))
=
\prod_p(1-p^{-s})
=
\frac1{\zeta(s)}.
\]

The Bromwich identity

\[
\left(1-\frac{\tau}{T}\right)_+
=
\frac{1}{2\pi iT}
\int_{c-i\infty}^{c+i\infty}
\frac{e^{w(T-\tau)}}{w^2}\,dw
\]

gives, for \(c>1/2\),

\[
P_T(E)
=
\Im\frac{1}{2\pi iT}
\int_{c-i\infty}^{c+i\infty}
\frac{e^{wT}}{w^2}
\log\zeta\!\left(\frac12+w-iE\right)\,dw.
\]

Equivalently,

\[
P_T(E)
=
-\Im\frac{1}{2\pi iT}
\int
\frac{e^{wT}}{w^2}
\log\det\!\left(I-T_P\!\left(\frac12+w-iE\right)\right)dw.
\]

So the successful finite secular phase is an exact log-clock/Cesàro regularization of a genuine Fredholm Euler determinant in the safe half-plane.

## 4. The self-weight theorem disappears

Define the entire function

\[
H(z)=\frac{\xi(1/2+\sqrt z)}{\xi(1/2)}
=\frac{\Xi(i\sqrt z)}{\Xi(0)}
\]

and

\[
M(z)=\frac{H'(z)}{H(z)}
=
\frac{1}{2\sqrt z}
\frac{\xi'}{\xi}\left(\frac12+\sqrt z\right).
\]

The exact Hilbert–Pólya target is equivalent to:

\[
\boxed{M\ \text{is a Stieltjes function}.}
\]

Suppose

\[
M(z)=a+\int_0^\infty\frac{d\nu(t)}{z+t},
\qquad \nu\ge0.
\]

But \(M=H'/H\) is meromorphic on the whole plane. By Stieltjes inversion, any continuous part of \(\nu\) would create a cut on the negative real axis. Therefore \(\nu\) must be purely atomic:

\[
\nu=\sum_j m_j\delta_{t_j}.
\]

At \(z=-t_j\), the residue of \(H'/H\) equals the multiplicity of the zero of \(H\), so

\[
m_j\in\mathbb N.
\]

Thus the numerical “self-weight” relation is forced automatically once Stieltjes positivity is proved; it is not a second independent theorem.

With

\[
\lambda_j=t_j^{-1},
\]

we obtain

\[
M(0)=\sum_j m_j\lambda_j<\infty,
\]

so the diagonal operator containing each \(\lambda_j\) with multiplicity \(m_j\) is positive trace class. Integration gives

\[
H(z)=\det(I+zK_{\rm ROT}),
\]

hence

\[
\boxed{
\frac{\Xi(t)}{\Xi(0)}
=
\det(I-t^2K_{\rm ROT}).
}
\]

## 5. What is still open

Riesz/Fejér positivity is positivity in recursive-clock **difference space**.

Stieltjes/Thorin positivity is positivity in the squared spectral **heat space**.

They are not the same positivity. In particular the compactly-supported triangular Riesz window is not completely monotone as a function of \(\tau\); therefore it cannot itself be a positive mixture of exponential clock regulators.

The remaining mathematical problem is now singular and precise:

\[
\boxed{
M(z)=
\frac{1}{2\sqrt z}
\frac{\xi'}{\xi}\left(\frac12+\sqrt z\right)
\quad\text{is Stieltjes.}
}
\]

Equivalently, \(\log H\) must be a Thorin–Bernstein function, or \(1/H\) must be the Laplace transform of a generalized gamma convolution with positive Thorin measure.

This criterion is RH-strength, not an easier theorem in disguise. The useful ROT question is therefore whether the recursive observation dynamics supplies an independent reason for the required Thorin positivity.
