# ROT-RH v493 — analytic Gaussian regulator / exact collision theorem

Set

`p_G(x)=exp(-x^2)`, `q_G(x)=2x exp(-x^2)` for `x>=0`.

The scale derivative remains exactly

`partial_L p_G(y/L)=y q_G(y/L)/L^2`.

Define

`P_G(u)=int_0^infty p_G(x) cos(ux) dx`,
`Q_G(u)=int_0^infty q_G(x) sin(ux) dx`,
`S_G(u)=int_0^infty p_G(x) sin(ux)/x dx`.

Then

`P_G(u)=sqrt(pi)/2 exp(-u^2/4)>0`

for every real `u`, and integration by parts gives

`Q_G(u)=u P_G(u)`.

Since `S_G'(u)=P_G(u)` and `S_G(0)=0`,

`S_G(u)=pi/2 erf(u/2)`.

Consequences:

1. **global collision transversality:** `P_G` has no real zeros;
2. **constant-u principal-collision cancellation:** `C_coll+u B_E,coll=0` exactly;
3. **monotone collision saturation:** `S_G` increases strictly from `-pi/2` to `+pi/2`, with no oscillatory side lobes;
4. the v462-v470 moving-cell geometry survives with a cleaner regulator.

This is the analytic-regulator route suggested by the v487 compact-Gevrey
barrier. It does not prove regulator universality back to the current compact
bump and does not yet control the remote off-critical quartet sector.

**Verdict:** `EXACT_ANALYTIC_GAUSSIAN_COLLISION_KERNEL_PASS`.
