#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v461 — BUMP-COLLISION / REGULAR-R7 CUTOFF-INDEPENDENCE BRIDGE
=====================================================================

PURPOSE
-------
Replace the overly strong standalone bump-wavelet target

    |C_q(L,E_k(L))| = O(L^b),  b<1

used by the conservative a=0 v459 route with a coupled numerator/denominator
theorem that exploits the bump regulator's OWN critical-collision stiffness.

For

    p(x) = exp(-(x/(1-x))^2),    0 <= x < 1,
    q(x) = -p'(x) = 2x/(1-x)^3 p(x),

v459 proved the exact cutoff identity

    partial_L P_L^FP(E) = C_q(L,E)/L^2.

The same bump p appears in the E-derivative of the secular phase.  For a
recombined critical zero-pair collision of multiplicity m and scaled detuning

    u = (gamma-E)L,

the low-frequency local kernels are

    P_c(u) = int_0^1 p(x) cos(u x) dx,
    Q_s(u) = int_0^1 q(x) sin(u x) dx.

The low-frequency local contributions therefore scale as

    F_E,coll  = +(m L/pi) P_c(u),                  [up to the fixed secular sign]
    |F_L,coll| <= (m/(pi L)) |Q_s(u)|,

with the conjugate high-frequency term and every other channel assigned to the
REGULAR RECOMBINED remainder.

On the exact collision window |u| <= pi/2:

  * q >= 0 and int_0^1 q = p(0)-p(1) = 1, hence |Q_s(u)| <= 1.
  * on 0 <= x <= 1/2:
        p(x) >= exp(-1),
        cos(u x) >= cos(pi/4)=1/sqrt(2),
    so
        P_c(u) >= c_bump := 1/(2 sqrt(2) e).

Thus, if the recombined regular remainder obeys

    |C_q,reg(L,E)| <= K_q L,

and

    |F_E,reg(L,E)| <= eta * (m c_bump/pi) L,      0 <= eta < 1,

then

    |F_E| >= (1-eta) (m c_bump/pi) L,

    |F_L| <= (m+K_q)/(pi L),

and therefore the exact root flow satisfies

    |E_k'(L)|
      <= [(m+K_q)/((1-eta)m c_bump)] L^(-2).

This is absolutely integrable and gives

    |E_k(infinity)-E_k(L)|
      <= [(m+K_q)/((1-eta)m c_bump)] / L.

WHY THIS MATTERS
----------------
The G7 head no longer needs the v459 O(L^0.90) bound.  O(L) is enough once
the bump collision supplies F_E ~ L.

For a coefficient sequence u, define the phase-prefix function

    A_u(M;E) = sum_{n<=M} u_n exp(i E log n).

If ||u||_pref,E <= C, discrete Abel summation with

    b_L(n) = log(n) q(log(n)/L) = L f(log(n)/L),
    f(x)=x q(x),

gives

    |sum u_n exp(iElogn) b_L(n)|
      <= C * TV(b_L)
      = C * L * TV(f).

Hence a bounded G7 phase-prefix norm implies

    C_q,G7 = O(L),

which is sufficient in the collision-ratio theorem.

For the regular R7 tail, v402 already proves the exact beta=2 factorial
four-jet contraction

    Q_jet = 657981440000000 / 1853020188851841 < 1,

with fixed-prefix packet factor

    rho_jet = Q_jet / 128^2.

The bump-wavelet E-jets have only an overall O(L) size after v402's
factorial log-scale normalization, because each E derivative contributes
at most y^r <= L^r while the jet norm divides by (log M)^r.

SCIENTIFIC BOUNDARY
-------------------
This script proves/checks the elementary bump-kernel inequalities and records
the exact theorem reduction.  It does NOT prove:

  1. eventual collision capture |(gamma_k-E_k(L))L| <= pi/2;
  2. the all-L G7 phase-prefix bound;
  3. the beta=2 bump-wavelet embedding for the complete regular R7 remainder;
  4. the stated regular F_E remainder domination;
  5. cutoff independence, the Fredholm-Xi identity, or RH.

Multiplicity safety:
The singular analytic continuation of G7 and R^7 X MUST NOT be separated.
v405/v417 show that for multiplicity m their principal residues recombine only
in the full fixed point X.  v402 is used here only for the REGULAR coefficient-
space R7 transfer.

No Xi values, zeta numerical values, zeta derivatives, or known zero ordinates
are used.

Version: 2026-08-28-v461-bump-collision-regular-r7-bridge
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v461-bump-collision-regular-r7-bridge"

QJET_NUM = 657981440000000
QJET_DEN = 1853020188851841
RHOJET_NUM = 40160000000
RHOJET_DEN = 1853020188851841


def p_bump(x: float) -> float:
    x = float(x)
    if x < 0.0 or x >= 1.0:
        return 0.0 if x >= 1.0 else math.nan
    r = x / (1.0 - x)
    e = -(r * r)
    if e < -745.0:
        return 0.0
    return math.exp(e)


def q_bump(x: float) -> float:
    x = float(x)
    if x < 0.0 or x >= 1.0:
        return 0.0 if x >= 1.0 else math.nan
    p = p_bump(x)
    if p == 0.0:
        return 0.0
    return 2.0 * x * p / ((1.0 - x) ** 3)


def analytic_constants() -> Dict[str, Any]:
    c_bump = 1.0 / (2.0 * math.sqrt(2.0) * math.e)
    qjet = QJET_NUM / QJET_DEN
    rhojet = RHOJET_NUM / RHOJET_DEN
    return {
        "collision_window_U": math.pi / 2.0,
        "c_bump_exact": "1/(2*sqrt(2)*e)",
        "c_bump_decimal": c_bump,
        "Qjet_fraction": f"{QJET_NUM}/{QJET_DEN}",
        "Qjet_decimal": qjet,
        "Qjet_below_one": qjet < 1.0,
        "rhojet_fraction": f"{RHOJET_NUM}/{RHOJET_DEN}",
        "rhojet_decimal": rhojet,
        "rhojet_below_one": rhojet < 1.0,
        "q_mass_exact": "int_0^1 q(x) dx = p(0)-p(1) = 1",
    }


def numerical_kernel_diagnostics() -> Dict[str, Any]:
    """
    Numerical diagnostics only.  None of these values is needed for the analytic
    lower bound c_bump or the exact q-mass identity.
    """
    try:
        from scipy.integrate import quad
    except Exception as exc:
        return {"available": False, "error": str(exc)}

    U = math.pi / 2.0

    def Pc(u: float) -> float:
        return quad(lambda x: p_bump(x) * math.cos(u * x),
                    0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300)[0]

    def Qs(u: float) -> float:
        return quad(lambda x: q_bump(x) * math.sin(u * x),
                    0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300)[0]

    qmass = quad(lambda x: q_bump(x), 0.0, 1.0,
                 epsabs=2e-13, epsrel=2e-13, limit=300)[0]

    grid = [(-U + 2.0 * U * j / 256.0) for j in range(257)]
    pc_vals = []
    qs_vals = []
    for u in tqdm(grid, desc="bump collision kernel", unit="u", leave=False):
        pc_vals.append(Pc(u))
        qs_vals.append(Qs(u))

    # Variation of f=x q(x), useful only as a diagnostic for the Abel bridge.
    def f(x: float) -> float:
        return x * q_bump(x)

    # Numerical total variation by a dense monotone partition.
    n = 20000
    vals = [f(j / n) for j in range(n + 1)]
    tv_f = sum(abs(vals[j+1] - vals[j]) for j in range(n))

    return {
        "available": True,
        "q_mass_numeric": qmass,
        "q_mass_abs_error": abs(qmass - 1.0),
        "Pc_min_on_abs_u_le_pi_over_2": min(pc_vals),
        "Pc_at_zero": Pc(0.0),
        "max_abs_Qs_on_abs_u_le_pi_over_2": max(abs(x) for x in qs_vals),
        "TV_xq_numeric": tv_f,
        "analytic_Pc_lower_bound": 1.0 / (2.0 * math.sqrt(2.0) * math.e),
    }


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available": False, "error": str(exc)}

    x, L, y = sp.symbols("x L y", positive=True)
    p = sp.exp(-(x / (1 - x))**2)
    q = 2*x/(1-x)**3 * p
    derivative_residual = sp.simplify(-sp.diff(p, x) - q)

    # d/dL p(y/L) = y/L^2 q(y/L)
    z = y / L
    pz = sp.exp(-(z / (1-z))**2)
    qz = 2*z/(1-z)**3 * pz
    cutoff_residual = sp.simplify(sp.diff(pz, L) - y*qz/L**2)

    return {
        "available": True,
        "minus_pprime_minus_q": str(derivative_residual),
        "cutoff_identity_residual": str(cutoff_residual),
        "pass": derivative_residual == 0 and cutoff_residual == 0,
    }


def theorem_bound(m: float, K_regular: float, eta: float) -> Dict[str, Any]:
    if m <= 0:
        raise ValueError("multiplicity m must be positive")
    if K_regular < 0:
        raise ValueError("K_regular must be nonnegative")
    if not (0.0 <= eta < 1.0):
        raise ValueError("eta must satisfy 0<=eta<1")

    c = 1.0 / (2.0 * math.sqrt(2.0) * math.e)
    C_flow = (m + K_regular) / ((1.0 - eta) * m * c)
    return {
        "assumed_multiplicity": m,
        "assumed_regular_Cq_constant": K_regular,
        "assumed_FE_remainder_fraction_eta": eta,
        "flow_constant_C": C_flow,
        "root_flow_bound": f"|E'(L)| <= {C_flow:.17g} / L^2",
        "root_tail_bound": f"|E(infinity)-E(L)| <= {C_flow:.17g} / L",
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    certificate = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    c = payload["analytic_constants"]["c_bump_decimal"]
    qjet = payload["analytic_constants"]["Qjet_decimal"]
    rhojet = payload["analytic_constants"]["rhojet_decimal"]

    theorem.write_text(
f"""# ROT-RH v461 — bump-collision / regular-R7 cutoff-independence bridge

## Exact bump identities

For

`p(x)=exp(-(x/(1-x))^2)`, `q(x)=-p'(x)`,

the exact cutoff identity is

`partial_L p(y/L) = y q(y/L)/L^2`.

Moreover `q>=0` and

`int_0^1 q(x) dx = 1`.

## Collision kernel

Let `u=(gamma-E)L` and define

`P_c(u)=int_0^1 p(x) cos(u x) dx`.

For `|u|<=pi/2`, restrict the integral to `0<=x<=1/2`.  There,

`p(x)>=e^-1` and `cos(ux)>=1/sqrt(2)`.

Hence

`P_c(u) >= c_bump = 1/(2 sqrt(2)e) ~= {c:.16e}`.

The corresponding wavelet kernel satisfies

`|int_0^1 q(x) sin(ux) dx| <= int_0^1 q(x)dx = 1`.

For a multiplicity-`m` recombined critical collision this gives the local scales

`F_E,coll >= (m c_bump/pi)L`

and

`|F_L,coll| <= m/(pi L)`,

with every high-frequency conjugate term and nonlocal channel assigned to the
regular recombined remainder.

## Regular-remainder theorem

If eventually on the fixed branch tube

`|C_q,reg(L,E)| <= K_q L`

and

`|F_E,reg(L,E)| <= eta (m c_bump/pi)L`, `eta<1`,

then

`|E'(L)| <= [(m+K_q)/((1-eta)m c_bump)] L^-2`.

Therefore `E(L)` converges and the tail is `O(1/L)`.

This is a stronger route than requiring the total bump-wavelet generator to be
`O(L^0.90)` under a merely constant transversality floor.

## G7 head bridge

For

`A_u(M;E)=sum_(n<=M) u_n exp(iElog n)`

and `||u||_pref,E=sup_M |A_u(M;E)|`, discrete Abel summation with

`b_L(n)=log(n)q(log(n)/L)=L f(log(n)/L)`, `f(x)=xq(x)`,

gives

`|<b_L e^(iElog n),u>| <= ||u||_pref,E * L * TV(f)`.

Thus an all-`N` bounded phase-prefix theorem for `G7` gives

`C_q,G7=O(L)`,

which is sufficient in the collision-ratio theorem.

## R7 regular tail

v402 gives the exact beta-2 factorial four-jet contraction

`Qjet = {QJET_NUM}/{QJET_DEN} ~= {qjet:.16e} < 1`

and the fixed-prefix packet factor

`rhojet = Qjet/128^2 ~= {rhojet:.16e}`.

The remaining bridge is to embed the bump-wavelet test family into this weighted
four-jet geometry.  Its normalized `E`-jets have only overall `O(L)` size, so
the expected regular R7 contribution is also `O(L)` after geometric contraction.

## Multiplicity safety

Do **not** analytically continue singular `G7` and `R^7X` separately.  The
v405/v417 residue bookkeeping is safe only after recombination in the full
fixed point.  v402 is used only for the regular coefficient-space R7 transfer.

## Still open

1. Prove eventual collision capture, or an alternative transversality theorem,
   for each fixed branch.
2. Prove the all-`N` G7 phase-prefix bound needed by the Abel bridge.
3. Prove the beta-2 bump-wavelet embedding / regular R7 remainder bound.
4. Control the regular `F_E` remainder by a strict fraction of the collision
   stiffness.
5. Promote fixed-mode convergence to the infinite operator using the existing
   uniform high-mode tail theorem.

This v461 packet is an analytic reduction.  It is not an RH proof and does not
claim the Fredholm identity.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_BUMP_COLLISION_REGULAR_R7_CERTIFICATE_V1",
        "already_closed": {
            "bump_derivative_identity": "q=-p'",
            "bump_cutoff_identity": "partial_L p(y/L)=y q(y/L)/L^2",
            "q_mass": "int_0^1 q=1",
            "collision_window": "|u|<=pi/2",
            "collision_Pc_lower": "P_c(u)>=1/(2sqrt(2)e)",
            "collision_Qs_upper": "|Q_s(u)|<=1",
            "R7_weighted_four_jet_contraction": f"Qjet={QJET_NUM}/{QJET_DEN}<1",
            "R7_fixed_prefix_packet_factor": f"rhojet={RHOJET_NUM}/{RHOJET_DEN}",
        },
        "required_claims": {
            "collision_capture_or_equivalent_transversality":
                "|(gamma_k-E_k(L))L|<=pi/2 eventually, or a replacement lower bound",
            "G7_prefix":
                "sup_M |sum_(n<=M) G7_n exp(iE_k(L)log n)| <= C_k on the moving tube",
            "bump_to_beta2_fourjet_embedding":
                "regular bump-wavelet functional has O(L) norm in v402 geometry",
            "regular_Cq":
                "|C_q,reg(L,E)|<=K_q L",
            "regular_FE":
                "|F_E,reg(L,E)|<=eta*(m c_bump/pi)L with eta<1",
            "branch_persistence": "eventual ordered branch/no-fold",
        },
        "forbidden_as_proof": [
            "separate singular G7 analytic continuation",
            "simple-zero assumption",
            "finite cutoff regression as all-L proof",
            "importing Riesz F_E~L directly into bump2 without a bridge",
        ],
    }
    certificate.write_text(json.dumps(cert, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--multiplicity", type=float, default=1.0)
    ap.add_argument("--regular-Cq-constant", type=float, default=1.0)
    ap.add_argument("--FE-remainder-fraction", type=float, default=0.5)
    ap.add_argument(
        "--prefix",
        default="rot_rh_bump_collision_regular_r7_bridge_v461",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 176)
    print("ROT-RH v461 — BUMP-COLLISION / REGULAR-R7 CUTOFF-INDEPENDENCE BRIDGE")
    print("=" * 176)
    print("Xi / zeta values / zeta derivatives / known zero ordinates : NONE")
    print("singular G7 and R7 analytic continuation separated          : NEVER")
    print("collision window                                             : |u| <= pi/2")
    print("=" * 176)

    with tqdm(total=4, desc="v461 analytic bridge", unit="step") as bar:
        const = analytic_constants()
        bar.update(1)
        sym = symbolic_checks()
        bar.update(1)
        diag = numerical_kernel_diagnostics()
        bar.update(1)
        bound = theorem_bound(
            float(args.multiplicity),
            float(args.regular_Cq_constant),
            float(args.FE_remainder_fraction),
        )
        bar.update(1)

    kernel_pass = (
        bool(sym.get("pass", False))
        and const["Qjet_below_one"]
        and const["rhojet_below_one"]
    )
    if diag.get("available"):
        kernel_pass = kernel_pass and (
            diag["q_mass_abs_error"] <= 1e-9
            and diag["Pc_min_on_abs_u_le_pi_over_2"]
                >= 0.999999 * const["c_bump_decimal"]
            and diag["max_abs_Qs_on_abs_u_le_pi_over_2"] <= 1.0 + 1e-10
        )

    verdict = (
        "EXACT_BUMP_COLLISION_KERNEL_BRIDGE_CLOSED__"
        "REGULAR_REMAINDER_AND_COLLISION_CAPTURE_OPEN"
        if kernel_pass else
        "BUMP_COLLISION_KERNEL_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter() - started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "zeta_derivatives_used": False,
            "known_zero_ordinates_used": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "analytic_constants": const,
        "symbolic_checks": sym,
        "numerical_diagnostics": diag,
        "illustrative_conditional_bound": bound,
        "proof_status": (
            "Exact elementary bump-collision kernel inequalities plus exact v402 "
            "regular-R7 contraction constants.  All-L regular-remainder embedding "
            "and collision capture remain open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-" * 176)
    print("verdict                               :", verdict)
    print("c_bump                                :", f"{const['c_bump_decimal']:.16e}")
    print("Qjet                                  :", f"{const['Qjet_decimal']:.16e}")
    print("rhojet                                :", f"{const['rhojet_decimal']:.16e}")
    if diag.get("available"):
        print("numeric int q                         :", f"{diag['q_mass_numeric']:.16e}")
        print("min P_c on |u|<=pi/2                 :", f"{diag['Pc_min_on_abs_u_le_pi_over_2']:.16e}")
        print("max |Q_s| on |u|<=pi/2               :", f"{diag['max_abs_Qs_on_abs_u_le_pi_over_2']:.16e}")
        print("numeric TV[x q(x)]                   :", f"{diag['TV_xq_numeric']:.16e}")
    print("conditional flow bound               :", bound["root_flow_bound"])
    print("summary                               :", str(prefix) + "_SUMMARY.json")
    print("theorem                               :", str(prefix) + "_THEOREM.md")
    print("next certificate                      :", str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    print("=" * 176)

    if args.strict and not kernel_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
