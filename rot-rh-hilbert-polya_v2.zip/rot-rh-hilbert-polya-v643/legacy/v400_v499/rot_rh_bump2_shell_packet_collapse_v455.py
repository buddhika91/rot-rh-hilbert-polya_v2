#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v455 — BUMP-2 FINITE-PART SHELL-PACKET COLLAPSE AUDIT
================================================================

PURPOSE
-------
v454 falsified a sparse three-shell harmonic carrier, but exposed a more stable
object: the absolute finite-part source packet in normalized logarithmic
coordinate

    x = log(n)/log(X) in [0,1].

The training and held-out |shell|-centroids were close even though the identity
of the largest individual bins migrated.  v455 therefore stops fitting sparse
shell resonances and asks a more invariant question:

    Does the WHOLE finite-part shell packet collapse after centering/scaling?

For each tracked mode k and node L=log X, split the exact source

    S_k(L) = partial_L P_L(E_k) - partial_L M_L(E_k)

into fixed x-bins.  Let

    A_{k,L}(x_b) = |S_{k,b}(L)|,
    p_b = A_b / sum_j A_j.

Compute the packet centroid and width

    mu_k(L)    = sum_b x_b p_b,
    sigma_k^2  = sum_b (x_b-mu)^2 p_b,

plus x-quantiles q10,q25,q50,q75,q90.  Standardize bin centers by

    y_b = (x_b-mu)/sigma,

and represent packet shape by its CDF on a fixed y-grid.  A true transported
packet should have a stable standardized CDF even when its dominant bins move.

PROSPECTIVE DESIGN
------------------
The final doubling is untouched until all of the following are frozen:

  * centroid/width extrapolation models and their validation envelopes,
  * a standardized training CDF template for every mode,
  * validation-derived CDF/Wasserstein and quantile envelopes,
  * the exact held-out prediction grid and all gates,
  * a SHA256 manifest.

Only then is the prime table above the final training cutoff constructed.

The intended full run trains through X=18,662,400 and holds out

    18,662,400 -> 37,324,800.

SCIENTIFIC BOUNDARY
-------------------
This is a finite prospective packet-structure audit.  A PASS is evidence for a
stable transported finite-part source packet.  It is not an all-L packet
existence theorem, source integrability theorem, cutoff-independence proof, or
proof of RH.

Required local module:
    rot_rh_bump2_finite_part_source_flow_v452.py
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.special import roots_legendre
from tqdm import tqdm

VERSION = "2026-08-26-v455-bump2-shell-packet-collapse"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames=[]
    seen=set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key); fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def rms(x: Sequence[float]) -> float:
    a = np.asarray(x, float)
    return float(np.sqrt(np.mean(a*a))) if a.size else float("nan")


def safe_rel(a: float, b: float, floor: float = 1e-14) -> float:
    return abs(float(a)-float(b))/max(abs(float(a)), abs(float(b)), float(floor))


def json_safe(obj):
    if isinstance(obj, (np.integer,)): return int(obj)
    if isinstance(obj, (np.floating,)): return float(obj)
    if isinstance(obj, np.ndarray): return [json_safe(x) for x in obj.tolist()]
    if isinstance(obj, dict): return {str(k): json_safe(v) for k,v in obj.items()}
    if isinstance(obj, (list,tuple)): return [json_safe(x) for x in obj]
    return obj


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py beside v455, "
            "or pass --v452-module."
        )


# =============================================================================
# Root / phase helpers
# =============================================================================

def make_phase(v452, n_all: np.ndarray, lam_all: np.ndarray, X: float,
               pnt_q: int, prime_chunk: int):
    idx = int(np.searchsorted(n_all, float(X), side="left"))
    return v452.FinitePartBump2(
        n_all[:idx], lam_all[:idx], float(X), int(pnt_q), int(prime_chunk)
    )


def quantize_silent(v452, phase, modes: Sequence[int], free: np.ndarray,
                    previous: Dict[int,float] | None,
                    root_tol: float, max_newton: int,
                    scan_points: int) -> Dict[int,object]:
    out: Dict[int,object] = {}
    previous_ordered: float | None = None
    for k in modes:
        seed = float(previous[int(k)]) if previous and int(k) in previous else float(free[int(k)-1])
        if int(k) == 1:
            spacing = float(free[1]-free[0]) if len(free)>1 else 2.0
        elif int(k) < len(free):
            spacing = 0.5*float(free[int(k)]-free[int(k)-2])
        else:
            spacing = float(free[-1]-free[-2])
        rr = v452.locate_root(
            phase, int(k), seed, spacing, previous_ordered,
            float(root_tol), int(max_newton), int(scan_points)
        )
        out[int(k)] = rr
        if rr.ok:
            previous_ordered = float(rr.root)
    return out


# =============================================================================
# Exact finite-part shell packet
# =============================================================================

def shell_decompose_source(v452, phase, E_values: np.ndarray,
                           bin_edges: np.ndarray, shell_q: int,
                           prime_chunk: int) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    """Return prime_L, pnt_L, finite_L arrays, shape (nmodes, nbins)."""
    E_values = np.asarray(E_values,float)
    nb = len(bin_edges)-1
    nm = len(E_values)
    prime = np.zeros((nm,nb),float)
    pnt = np.zeros((nm,nb),float)
    L = float(phase.L)

    logs = np.asarray(phase.logs,float)
    wL = np.asarray(phase.w_L,float)
    for b in range(nb):
        lo_y = float(bin_edges[b])*L
        hi_y = float(bin_edges[b+1])*L
        ia = int(np.searchsorted(logs,lo_y,side="left"))
        ib = int(np.searchsorted(logs,hi_y,side="left"))
        for a in range(ia,ib,int(prime_chunk)):
            z = min(ib,a+int(prime_chunk))
            if z<=a: continue
            lg=logs[a:z]; ww=wL[a:z]
            prime[:,b] += np.sin(np.outer(E_values,lg)) @ ww

    zg,wg = roots_legendre(int(shell_q))
    y_floor = math.log(2.0)
    for b in range(nb):
        a = max(y_floor,float(bin_edges[b])*L)
        c = min(L,float(bin_edges[b+1])*L)
        if c<=a: continue
        y = 0.5*(c-a)*zg + 0.5*(c+a)
        jac = 0.5*(c-a)
        _,dphi = v452.bump2_and_dL(y,L)
        ww = jac*wg*np.exp(0.5*y)*dphi/y
        pnt[:,b] = np.sin(np.outer(E_values,y)) @ ww
    return prime,pnt,prime-pnt


def weighted_quantile(x: np.ndarray, w: np.ndarray, q: float) -> float:
    x=np.asarray(x,float); w=np.asarray(w,float)
    s=float(np.sum(w))
    if not np.isfinite(s) or s<=0: return float("nan")
    order=np.argsort(x); xx=x[order]; ww=w[order]/s
    c=np.cumsum(ww)
    return float(np.interp(float(q), c, xx, left=xx[0], right=xx[-1]))


def packet_stats(centers: np.ndarray, finite_shell: np.ndarray,
                 quantiles: Sequence[float], y_grid: np.ndarray) -> dict:
    amp=np.abs(np.asarray(finite_shell,float))
    mass=float(np.sum(amp))
    if not np.isfinite(mass) or mass<=1e-300:
        raise RuntimeError("degenerate zero shell packet")
    p=amp/mass
    mu=float(np.sum(centers*p))
    var=float(np.sum((centers-mu)**2*p))
    sig=math.sqrt(max(var,1e-18))
    y=(centers-mu)/sig
    order=np.argsort(y); yy=y[order]; pp=p[order]; cdf=np.cumsum(pp)
    # Discrete right-continuous CDF on a fixed standardized grid.
    idx=np.searchsorted(yy,y_grid,side="right")-1
    F=np.zeros_like(y_grid,float)
    m=idx>=0
    F[m]=cdf[np.minimum(idx[m],len(cdf)-1)]
    qs={float(q):weighted_quantile(centers,amp,float(q)) for q in quantiles}
    yqs={float(q):(qs[float(q)]-mu)/sig for q in quantiles}
    return {
        "mass":mass,"mu":mu,"sigma":sig,"p":p,"y":y,"cdf":F,
        "quantiles":qs,"std_quantiles":yqs,
    }


def cdf_l1(F: np.ndarray,G: np.ndarray,y_grid: np.ndarray) -> float:
    return float(np.trapezoid(np.abs(np.asarray(F)-np.asarray(G)),np.asarray(y_grid)))


def cdf_sup(F: np.ndarray,G: np.ndarray) -> float:
    return float(np.max(np.abs(np.asarray(F)-np.asarray(G))))


# =============================================================================
# Low-complexity moment extrapolation
# =============================================================================

def design(t: np.ndarray,family: str) -> np.ndarray:
    t=np.asarray(t,float)
    if family=="constant": return np.ones((len(t),1),float)
    if family=="invL": return np.column_stack([np.ones(len(t)),1.0/t])
    if family=="invL2": return np.column_stack([np.ones(len(t)),1.0/(t*t)])
    raise ValueError(family)


def fit_linear_family(L: np.ndarray,y: np.ndarray,family: str) -> dict:
    A=design(L,family)
    beta=np.linalg.lstsq(A,np.asarray(y,float),rcond=None)[0]
    pred=A@beta
    return {"family":family,"beta":[float(x) for x in beta],"train_rmse":rms(np.asarray(y)-pred)}


def predict_linear(fit: dict,L: np.ndarray) -> np.ndarray:
    return design(np.asarray(L,float),fit["family"]) @ np.asarray(fit["beta"],float)


def choose_moment_model(L: np.ndarray,y: np.ndarray,interval_idx: np.ndarray,
                        families: Sequence[str]) -> dict:
    val=int(np.max(interval_idx))
    fitmask=interval_idx<val; valmask=interval_idx==val
    rec=[]
    for fam in families:
        f=fit_linear_family(L[fitmask],y[fitmask],fam)
        pv=predict_linear(f,L[valmask]); yy=y[valmask]
        rec.append({**f,"validation_rmse":rms(yy-pv),"validation_max_abs":float(np.max(np.abs(yy-pv)))})
    best=min(rec,key=lambda r:(r["validation_rmse"],len(r["beta"])))
    final=fit_linear_family(L,y,best["family"])
    return {"selected_family":best["family"],"blocked_validation":best,"final_fit":final,"candidates":rec}


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--v452-module",default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--cutoffs",default="1166400,2332800,4665600,9331200,18662400,37324800")
    ap.add_argument("--modes",default="1,2,4,8,12,16,24,32")
    ap.add_argument("--nodes-per-doubling",type=int,default=33)
    ap.add_argument("--shell-bins",type=int,default=64)
    ap.add_argument("--shell-pnt-q",type=int,default=48)
    ap.add_argument("--pnt-q",type=int,default=3072)
    ap.add_argument("--prime-chunk",type=int,default=100000)
    ap.add_argument("--root-tol",type=float,default=2e-9)
    ap.add_argument("--scan-points",type=int,default=65)
    ap.add_argument("--max-newton",type=int,default=12)
    ap.add_argument("--quantiles",default="0.10,0.25,0.50,0.75,0.90")
    ap.add_argument("--y-min",type=float,default=-4.0)
    ap.add_argument("--y-max",type=float,default=4.0)
    ap.add_argument("--y-points",type=int,default=161)
    ap.add_argument("--prediction-safety",type=float,default=2.0)
    ap.add_argument("--minimum-centroid-envelope",type=float,default=0.012)
    ap.add_argument("--minimum-width-envelope",type=float,default=0.010)
    ap.add_argument("--minimum-shape-l1-envelope",type=float,default=0.12)
    ap.add_argument("--minimum-shape-sup-envelope",type=float,default=0.10)
    ap.add_argument("--minimum-std-quantile-envelope",type=float,default=0.35)
    ap.add_argument("--maximum-shell-reconstruction-relative",type=float,default=2e-5)
    ap.add_argument("--minimum-supported-mode-fraction",type=float,default=0.75)
    ap.add_argument("--priority-modes",default="12,32")
    ap.add_argument("--prefix",default="rot_rh_bump2_shell_packet_collapse_v455")
    args=ap.parse_args()

    started=time.perf_counter()
    v452=import_v452(args.v452_module)
    cutoffs=parse_ints(args.cutoffs); modes=parse_ints(args.modes)
    quantiles=parse_floats(args.quantiles); priority=parse_ints(args.priority_modes)
    if len(cutoffs)<6 or cutoffs!=sorted(cutoffs):
        raise ValueError("Need at least six increasing cutoffs (five training nodes + one holdout endpoint).")
    if args.nodes_per_doubling<9 or args.nodes_per_doubling%2==0:
        raise ValueError("--nodes-per-doubling must be odd and >=9.")
    if args.shell_bins<16: raise ValueError("--shell-bins must be >=16.")
    if args.y_points<41: raise ValueError("--y-points must be >=41.")
    if any(q<=0 or q>=1 for q in quantiles): raise ValueError("quantiles must lie in (0,1)")

    prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    train_cutoffs=cutoffs[:-1]; hold_lo=cutoffs[-2]; hold_hi=cutoffs[-1]; train_max=train_cutoffs[-1]
    edges=np.linspace(0.0,1.0,args.shell_bins+1); centers=0.5*(edges[:-1]+edges[1:])
    y_grid=np.linspace(args.y_min,args.y_max,args.y_points)

    print("="*178)
    print("ROT-RH v455 — BUMP-2 FINITE-PART SHELL-PACKET COLLAPSE AUDIT")
    print("="*178)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("finite-part packet                 : |bump2 prime-shell - bump2 PNT-shell|")
    print("training cutoff ladder             :",train_cutoffs)
    print("HELD-OUT interval                  :",[hold_lo,hold_hi])
    print("modes                              :",modes)
    print("nodes per doubling                 :",args.nodes_per_doubling)
    print("normalized shell bins              :",args.shell_bins)
    print("standardized packet y-grid         :",f"[{args.y_min}, {args.y_max}] / {args.y_points} points")
    print("packet quantiles                   :",quantiles)
    print("holdout prime table policy         : NOT BUILT until pre-holdout SHA freeze")
    print("prospective target                 : centroid + width + standardized CDF/quantile collapse")
    print("="*178)

    print("\n[A] Building TRAINING-only prime-power table and free levels ...")
    n_train,lam_train=v452.mangoldt_terms(int(train_max))
    free=v452.free_archimedean_levels(max(modes))
    print("training Mangoldt terms             :",len(n_train))

    packet_rows: List[dict]=[]; shell_rows: List[dict]=[]
    packet_cache: Dict[Tuple[int,int],dict]={}
    previous: Dict[int,float]|None=None
    max_recon=0.0; global_node=0

    print("\n[B] Resolving TRAINING packet field ...")
    for j,(xa,xb) in enumerate(zip(train_cutoffs[:-1],train_cutoffs[1:])):
        La,Lb=math.log(xa),math.log(xb)
        Lgrid=np.linspace(La,Lb,args.nodes_per_doubling)
        if j>0: Lgrid=Lgrid[1:]
        for local_i,L in enumerate(tqdm(Lgrid,desc=f"TRAIN packets {xa}->{xb}",unit="node")):
            X=float(math.exp(float(L)))
            ph=make_phase(v452,n_train,lam_train,X,args.pnt_q,args.prime_chunk)
            roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
            bad=[k for k,r in roots.items() if not r.ok]
            if bad: raise RuntimeError(f"training roots failed X={X:.12g}: {bad}")
            E=np.asarray([roots[k].root for k in modes],float)
            prime,pnt,finite=shell_decompose_source(v452,ph,E,edges,args.shell_pnt_q,args.prime_chunk)
            root_map={}
            for mi,k in enumerate(modes):
                sv=ph.sources(float(E[mi])); shell_sum=float(np.sum(finite[mi]))
                recon=safe_rel(shell_sum,float(sv.finitepart_L),1e-10); max_recon=max(max_recon,recon)
                st=packet_stats(centers,finite[mi],quantiles,y_grid)
                packet_cache[(global_node,k)]={"cdf":st["cdf"],"std_quantiles":st["std_quantiles"]}
                row={
                    "phase":"TRAIN","interval_index":j,"global_node":global_node,
                    "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"E":f"{E[mi]:.17g}",
                    "root_residual":f"{roots[k].residual:.6e}","packet_mass":f"{st['mass']:.17g}",
                    "centroid_x":f"{st['mu']:.17g}","width_x":f"{st['sigma']:.17g}",
                    "shell_reconstruction_relative":f"{recon:.6e}",
                }
                for q in quantiles:
                    tag=int(round(100*q)); row[f"q{tag:02d}_x"]=f"{st['quantiles'][q]:.17g}"; row[f"q{tag:02d}_y"]=f"{st['std_quantiles'][q]:.17g}"
                packet_rows.append(row)
                den=st["mass"]
                for b in range(args.shell_bins):
                    shell_rows.append({
                        "phase":"TRAIN","interval_index":j,"global_node":global_node,
                        "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"bin":b,
                        "x_center":f"{centers[b]:.17g}","finite_source":f"{finite[mi,b]:.17g}",
                        "abs_fraction":f"{abs(finite[mi,b])/den:.17g}",
                    })
                root_map[k]=float(E[mi])
            previous=root_map; global_node+=1

    # Need at least last training interval as blocked validation.
    val_interval=len(train_cutoffs)-2
    fit_intervals=list(range(val_interval))
    if len(fit_intervals)<2: raise ValueError("Need >=3 training intervals for blocked packet validation")

    print("\n[C] Building blocked-validation packet templates and FREEZING holdout ...")
    fit_rows=[]; template_rows=[]; pred_rows=[]; manifest_modes={}
    Lh=np.linspace(math.log(hold_lo),math.log(hold_hi),args.nodes_per_doubling)

    for k in modes:
        rows=[r for r in packet_rows if int(r["mode"])==k]
        Larr=np.asarray([float(r["logX"]) for r in rows],float)
        iarr=np.asarray([int(r["interval_index"]) for r in rows],int)
        mu=np.asarray([float(r["centroid_x"]) for r in rows],float)
        sig=np.asarray([float(r["width_x"]) for r in rows],float)

        mu_model=choose_moment_model(Larr,mu,iarr,["constant","invL","invL2"])
        sig_model=choose_moment_model(Larr,sig,iarr,["constant","invL","invL2"])
        mu_pred=predict_linear(mu_model["final_fit"],Lh)
        sig_pred=predict_linear(sig_model["final_fit"],Lh)
        mu_upper=max(args.minimum_centroid_envelope,args.prediction_safety*mu_model["blocked_validation"]["validation_max_abs"])
        sig_upper=max(args.minimum_width_envelope,args.prediction_safety*sig_model["blocked_validation"]["validation_max_abs"])

        fit_nodes=[int(r["global_node"]) for r in rows if int(r["interval_index"])<val_interval]
        val_nodes=[int(r["global_node"]) for r in rows if int(r["interval_index"])==val_interval]
        all_nodes=[int(r["global_node"]) for r in rows]
        template_pre=np.mean(np.vstack([packet_cache[(g,k)]["cdf"] for g in fit_nodes]),axis=0)
        val_l1=[]; val_sup=[]; val_q=[]
        stdq_pre={q:float(np.mean([packet_cache[(g,k)]["std_quantiles"][q] for g in fit_nodes])) for q in quantiles}
        for g in val_nodes:
            F=packet_cache[(g,k)]["cdf"]
            val_l1.append(cdf_l1(F,template_pre,y_grid)); val_sup.append(cdf_sup(F,template_pre))
            val_q.append(max(abs(packet_cache[(g,k)]["std_quantiles"][q]-stdq_pre[q]) for q in quantiles))
        l1_upper=max(args.minimum_shape_l1_envelope,args.prediction_safety*max(val_l1))
        sup_upper=max(args.minimum_shape_sup_envelope,args.prediction_safety*max(val_sup))
        q_upper=max(args.minimum_std_quantile_envelope,args.prediction_safety*max(val_q))

        template_final=np.mean(np.vstack([packet_cache[(g,k)]["cdf"] for g in all_nodes]),axis=0)
        stdq_final={q:float(np.mean([packet_cache[(g,k)]["std_quantiles"][q] for g in all_nodes])) for q in quantiles}
        for y,F in zip(y_grid,template_final):
            template_rows.append({"mode":k,"y":f"{y:.17g}","template_cdf":f"{F:.17g}"})
        for ii,L in enumerate(Lh):
            pred_rows.append({"mode":k,"node_index":ii,"logX":f"{L:.17g}","X":f"{math.exp(L):.17g}","predicted_centroid_x":f"{mu_pred[ii]:.17g}","predicted_width_x":f"{sig_pred[ii]:.17g}"})

        manifest_modes[str(k)]={
            "centroid_model":mu_model,"width_model":sig_model,
            "centroid_holdout_envelope_abs":mu_upper,"width_holdout_envelope_abs":sig_upper,
            "shape_validation_max_l1":max(val_l1),"shape_validation_max_sup":max(val_sup),
            "std_quantile_validation_max_abs":max(val_q),
            "shape_holdout_l1_upper":l1_upper,"shape_holdout_sup_upper":sup_upper,
            "std_quantile_holdout_upper":q_upper,
            "std_quantile_template":{str(q):stdq_final[q] for q in quantiles},
        }
        fit_rows.append({
            "mode":k,
            "centroid_family":mu_model["selected_family"],"centroid_validation_max_abs":f"{mu_model['blocked_validation']['validation_max_abs']:.17g}","centroid_holdout_upper":f"{mu_upper:.17g}",
            "width_family":sig_model["selected_family"],"width_validation_max_abs":f"{sig_model['blocked_validation']['validation_max_abs']:.17g}","width_holdout_upper":f"{sig_upper:.17g}",
            "shape_validation_max_l1":f"{max(val_l1):.17g}","shape_l1_holdout_upper":f"{l1_upper:.17g}",
            "shape_validation_max_sup":f"{max(val_sup):.17g}","shape_sup_holdout_upper":f"{sup_upper:.17g}",
            "std_quantile_validation_max_abs":f"{max(val_q):.17g}","std_quantile_holdout_upper":f"{q_upper:.17g}",
        })
        print(f"  k={k:<3d} mu={mu_model['selected_family']:<8s} width={sig_model['selected_family']:<8s} shapeL1<= {l1_upper:.3e} shapeSup<= {sup_upper:.3e}")

    template_path=Path(str(prefix)+"_PACKET_TEMPLATE.csv"); write_csv(template_path,template_rows)
    pred_path=Path(str(prefix)+"_PREDICTED_HOLDOUT_MOMENTS.csv"); write_csv(pred_path,pred_rows)
    freeze={
        "version":VERSION,"frozen_before_holdout":True,
        "training_cutoffs":train_cutoffs,"holdout_interval":[hold_lo,hold_hi],"modes":modes,
        "nodes_per_doubling":args.nodes_per_doubling,"shell_bins":args.shell_bins,
        "shell_edges":[float(x) for x in edges],"y_grid":[float(y) for y in y_grid],"quantiles":quantiles,
        "prediction_safety":args.prediction_safety,"mode_models":manifest_modes,
        "template_file":template_path.name,"template_sha256":sha256_file(template_path),
        "prediction_file":pred_path.name,"prediction_sha256":sha256_file(pred_path),
        "gates":{
            "maximum_shell_reconstruction_relative":args.maximum_shell_reconstruction_relative,
            "minimum_supported_mode_fraction":args.minimum_supported_mode_fraction,
            "priority_modes":priority,
        },
        "firewall":{"known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,"holdout_prime_table_built":False,"holdout_packet_evaluated":False},
    }
    freeze_path=Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json"); freeze_path.write_text(json.dumps(json_safe(freeze),indent=2),encoding="utf-8")
    freeze_sha=sha256_file(freeze_path)
    print("  PRE-HOLDOUT FREEZE SHA256:",freeze_sha)

    print("\n[D] Revealing HELD-OUT prime table and packet field ...")
    n_all,lam_all=v452.mangoldt_terms(int(hold_hi)); print("full Mangoldt terms                 :",len(n_all))
    hold_packet=[]; hold_shell=[]; hold_cache={}; previous={k:float([r for r in packet_rows if int(r["mode"])==k][-1]["E"]) for k in modes}
    max_hold_recon=0.0
    for ii,L in enumerate(tqdm(Lh,desc=f"HOLDOUT packets {hold_lo}->{hold_hi}",unit="node")):
        X=float(math.exp(float(L))); ph=make_phase(v452,n_all,lam_all,X,args.pnt_q,args.prime_chunk)
        roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
        bad=[k for k,r in roots.items() if not r.ok]
        if bad: raise RuntimeError(f"holdout roots failed X={X:.12g}: {bad}")
        E=np.asarray([roots[k].root for k in modes],float)
        prime,pnt,finite=shell_decompose_source(v452,ph,E,edges,args.shell_pnt_q,args.prime_chunk)
        root_map={}
        for mi,k in enumerate(modes):
            sv=ph.sources(float(E[mi])); shell_sum=float(np.sum(finite[mi])); recon=safe_rel(shell_sum,float(sv.finitepart_L),1e-10); max_hold_recon=max(max_hold_recon,recon)
            st=packet_stats(centers,finite[mi],quantiles,y_grid); hold_cache[(ii,k)]=st
            row={"phase":"HOLDOUT","node_index":ii,"X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"E":f"{E[mi]:.17g}","root_residual":f"{roots[k].residual:.6e}","packet_mass":f"{st['mass']:.17g}","centroid_x":f"{st['mu']:.17g}","width_x":f"{st['sigma']:.17g}","shell_reconstruction_relative":f"{recon:.6e}"}
            for q in quantiles:
                tag=int(round(100*q)); row[f"q{tag:02d}_x"]=f"{st['quantiles'][q]:.17g}"; row[f"q{tag:02d}_y"]=f"{st['std_quantiles'][q]:.17g}"
            hold_packet.append(row)
            for b in range(args.shell_bins):
                hold_shell.append({"phase":"HOLDOUT","node_index":ii,"X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"bin":b,"x_center":f"{centers[b]:.17g}","finite_source":f"{finite[mi,b]:.17g}","abs_fraction":f"{abs(finite[mi,b])/st['mass']:.17g}"})
            root_map[k]=float(E[mi])
        previous=root_map

    print("\n[E] Scoring held-out packet collapse against ORIGINAL frozen template/envelopes ...")
    scores=[]; supported=[]
    template_by_mode={}
    for k in modes:
        template_by_mode[k]=np.asarray([float(r["template_cdf"]) for r in template_rows if int(r["mode"])==k],float)
    for k in modes:
        hr=[r for r in hold_packet if int(r["mode"])==k]
        pr=[r for r in pred_rows if int(r["mode"])==k]
        actual_mu=np.asarray([float(r["centroid_x"]) for r in hr]); actual_sig=np.asarray([float(r["width_x"]) for r in hr])
        pred_mu=np.asarray([float(r["predicted_centroid_x"]) for r in pr]); pred_sig=np.asarray([float(r["predicted_width_x"]) for r in pr])
        mm=manifest_modes[str(k)]
        mu_err=float(np.max(np.abs(actual_mu-pred_mu))); sig_err=float(np.max(np.abs(actual_sig-pred_sig)))
        l1=[]; sup=[]; qerr=[]
        qtempl={float(q):float(mm["std_quantile_template"][str(q)]) for q in quantiles}
        for ii in range(args.nodes_per_doubling):
            st=hold_cache[(ii,k)]; F=st["cdf"]
            l1.append(cdf_l1(F,template_by_mode[k],y_grid)); sup.append(cdf_sup(F,template_by_mode[k])); qerr.append(max(abs(st["std_quantiles"][q]-qtempl[q]) for q in quantiles))
        max_l1=max(l1); max_sup=max(sup); max_q=max(qerr)
        passes={
            "centroid":mu_err<=float(mm["centroid_holdout_envelope_abs"]),
            "width":sig_err<=float(mm["width_holdout_envelope_abs"]),
            "shape_l1":max_l1<=float(mm["shape_holdout_l1_upper"]),
            "shape_sup":max_sup<=float(mm["shape_holdout_sup_upper"]),
            "quantiles":max_q<=float(mm["std_quantile_holdout_upper"]),
        }
        ok=bool(all(passes.values())); supported.append(ok)
        scores.append({
            "mode":k,"max_centroid_abs_error":f"{mu_err:.17g}","centroid_upper":f"{mm['centroid_holdout_envelope_abs']:.17g}","centroid_pass":passes["centroid"],
            "max_width_abs_error":f"{sig_err:.17g}","width_upper":f"{mm['width_holdout_envelope_abs']:.17g}","width_pass":passes["width"],
            "max_shape_l1":f"{max_l1:.17g}","shape_l1_upper":f"{mm['shape_holdout_l1_upper']:.17g}","shape_l1_pass":passes["shape_l1"],
            "max_shape_sup":f"{max_sup:.17g}","shape_sup_upper":f"{mm['shape_holdout_sup_upper']:.17g}","shape_sup_pass":passes["shape_sup"],
            "max_std_quantile_error":f"{max_q:.17g}","std_quantile_upper":f"{mm['std_quantile_holdout_upper']:.17g}","std_quantile_pass":passes["quantiles"],
            "holdout_mean_centroid_x":f"{float(np.mean(actual_mu)):.17g}","holdout_mean_width_x":f"{float(np.mean(actual_sig)):.17g}","pass":ok,
        })

    reconstruction_pass=bool(max(max_recon,max_hold_recon)<=args.maximum_shell_reconstruction_relative)
    frac=float(np.mean(supported)); priority_pass=all(supported[modes.index(k)] for k in priority if k in modes)
    all_roots_clean=all(float(r["root_residual"])<=max(1e-7,50*args.root_tol) for r in hold_packet)
    if reconstruction_pass and all_roots_clean and frac>=args.minimum_supported_mode_fraction and priority_pass:
        verdict="FINITE_PART_SHELL_PACKET_COLLAPSE_SUPPORTED_PROSPECTIVELY"
    elif reconstruction_pass and all_roots_clean and frac>0:
        verdict="FINITE_PART_SHELL_PACKET_COLLAPSE_PARTIAL__NOT_ALL_GATES"
    else:
        verdict="FINITE_PART_SHELL_PACKET_COLLAPSE_NOT_SUPPORTED"

    paths={
        "packet_nodes":Path(str(prefix)+"_PACKET_NODES.csv"),
        "shell_nodes":Path(str(prefix)+"_SHELL_NODES.csv"),
        "moment_fits":Path(str(prefix)+"_MOMENT_FITS.csv"),
        "template":template_path,
        "predictions":pred_path,
        "holdout_score":Path(str(prefix)+"_HOLDOUT_SCORE.csv"),
        "summary":Path(str(prefix)+"_SUMMARY.json"),
        "theorem":Path(str(prefix)+"_THEOREM.md"),
    }
    write_csv(paths["packet_nodes"],packet_rows+hold_packet); write_csv(paths["shell_nodes"],shell_rows+hold_shell); write_csv(paths["moment_fits"],fit_rows); write_csv(paths["holdout_score"],scores)

    summary={
        "version":VERSION,"verdict":verdict,"pre_holdout_freeze_sha256":freeze_sha,
        "training_cutoffs":train_cutoffs,"holdout_interval":[hold_lo,hold_hi],"modes":modes,
        "max_shell_reconstruction_relative":max(max_recon,max_hold_recon),"shell_reconstruction_pass":reconstruction_pass,
        "holdout_roots_clean":all_roots_clean,"supported_mode_fraction":frac,"priority_modes":priority,"priority_modes_pass":priority_pass,
        "mode_scores":scores,"runtime_seconds":time.perf_counter()-started,"outputs":{k:str(v) for k,v in paths.items()},
        "scope_limit":"Finite prospective packet-collapse evidence only; no all-L packet theorem, source-integrability theorem, operator cutoff-independence proof, or RH proof.",
    }
    paths["summary"].write_text(json.dumps(json_safe(summary),indent=2),encoding="utf-8")
    theorem=f"""# ROT-RH v455 — finite-part shell-packet theorem target\n\nVerdict: **{verdict}**\n\nLet `S_{{k,b}}(L)` be the bump-2 finite-part source in normalized logarithmic bin `b`, and let `p_{{k,b}}=|S_{{k,b}}|/sum_j|S_{{k,j}}|`.  Define centroid `mu_k(L)`, width `sigma_k(L)`, and standardized packet coordinate `y=(x-mu)/sigma`.\n\nThe numerical target tested here is prospective stability of `mu_k`, `sigma_k`, and the standardized packet CDF on a completely unseen final doubling.  A future analytic theorem would seek a limiting probability profile `Q_k` such that the push-forward measures of `p_{{k,b}}` under `x -> (x-mu_k(L))/sigma_k(L)` converge weakly (ideally in Wasserstein-1), together with controlled limits/scaling laws for `mu_k(L)` and `sigma_k(L)`.\n\nIf such a packet theorem is established, the next step is to reinsert the signed phase and derive the oscillatory source-flow carrier from the packet rather than guessing sparse shell harmonics.\n\nThis file does not claim that theorem or RH.\n"""
    paths["theorem"].write_text(theorem,encoding="utf-8")

    print("\n"+"="*178); print("KEY RESULTS"); print("="*178)
    print("verdict                                  :",verdict)
    print("pre-holdout freeze SHA256                :",freeze_sha)
    print("holdout prime table built after freeze   : True")
    print("max shell reconstruction relative        :",f"{max(max_recon,max_hold_recon):.6e}","pass=",reconstruction_pass)
    print("holdout roots clean                      :",all_roots_clean)
    print("prospectively supported mode fraction    :",f"{frac:.3f}")
    print("priority modes pass                      :",priority_pass,priority)
    print("holdout mode diagnostics                 :")
    for r in scores:
        print(f"  k={int(r['mode']):<3d} muerr={float(r['max_centroid_abs_error']):.3e}/{float(r['centroid_upper']):.3e} "
              f"sigerr={float(r['max_width_abs_error']):.3e}/{float(r['width_upper']):.3e} "
              f"L1={float(r['max_shape_l1']):.3e}/{float(r['shape_l1_upper']):.3e} "
              f"sup={float(r['max_shape_sup']):.3e}/{float(r['shape_sup_upper']):.3e} "
              f"qerr={float(r['max_std_quantile_error']):.3e}/{float(r['std_quantile_upper']):.3e} pass={r['pass']}")
    print("summary                                  :",paths["summary"])
    print("="*178)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
