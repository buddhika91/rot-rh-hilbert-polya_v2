#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v440 — FIXED-TUBE SINE-PRIMITIVE RH-EQUIVALENCE / MOVING-BRANCH REDIRECT
===============================================================================

Purpose
-------
v439 proved the exact fixed-E reduction

    L_(n+1) S_n(E)
      = L_1 S_0(E) + h sum_(j<n) J_j(E),

where

    H_L(E) = int_(log2)^L A(u) g'_E(u) du,
    S_L(E) = h/(L+h) H_L(E),
    J_L(E) = H_(L+h)(E)-H_L(E).

Therefore the v439 Gate A

    sup_(E in I)
    |sum_(j<n) J_j(E)|
      <= C_I L_n^M

for any finite power M is equivalent, up to the fixed initial value, to

    sup_(E in I) |H_L(E)| <= C'_I (1+L)^M.

v440 shows that on any nonempty fixed-E interval this polynomial-growth
statement is already RH-strength.

Classical explicit-formula input
--------------------------------
Write

    g_E(u)=e^(-u/2) sin(Eu)
          =[e^(-s_+u)-e^(-s_-u)]/(2i),

    s_+ = 1/2-iE,
    s_- = 1/2+iE.

The nontrivial-zero part of the centered Chebyshev discrepancy is

    A_zero(u) = - sum_rho e^(rho u)/rho.

For a single zero rho, its contribution to H_L(E) is

    H_rho(L,E)
      = [s_+/(2 i rho)] K_L(rho-s_+)
        -[s_-/(2 i rho)] K_L(rho-s_-),

where

    K_L(a)
      = (e^(aL)-e^(a log2))/a,       a != 0,
      = L-log2,                      a = 0.

If rho=beta+i gamma has beta>1/2, both exponents have positive real part

    Re(rho-s_+) = Re(rho-s_-) = beta-1/2 > 0.

The corresponding upper-limit coefficients are nonzero:

    c_+(rho,E)
      = s_+ / [2 i rho (rho-s_+)],

    c_-(rho,E)
      = -s_- / [2 i rho (rho-s_-)].

Their Laplace poles are

    z = rho-s_+ = (beta-1/2)+i(gamma+E),
    z = rho-s_- = (beta-1/2)+i(gamma-E).

For fixed zero data, a cross-channel pole collision can occur only at isolated
(real) E values satisfying

    gamma+E = gamma'-E,

i.e.

    E=(gamma'-gamma)/2.

The union of all such collision values is countable.  Therefore every nonempty
open interval contains generic E for which an off-critical pole is isolated.

RH implication
--------------
If H_L(E) has any polynomial bound in L for every E in a nonempty interval I,
then its Laplace transform is analytic for Re z>0 at every generic E in I.
But an off-critical zero beta>1/2 yields a nonzero isolated pole in Re z>0,
contradiction.

Hence no beta>1/2 zero exists.  Functional-equation symmetry about Re s=1/2
then forces every nontrivial zero onto the critical line.

Conversely, under RH all zero exponents above are purely imaginary.  On a
compact E interval:
  * only finitely many zero ordinates can be near resonance gamma=+-E;
  * a resonant term is at worst O(L);
  * all far-zero coefficients are O_I(gamma^-2);
  * N(T)=O(T log T) gives absolute summability of the far tail.

Thus

    RH => sup_(E in I)|H_L(E)|=O_I(L).

Conclusion
----------
Within the standard explicit-formula / normal-convergence framework,

    RH
      <=>
    polynomial fixed-tube growth of H_L(E)
    on any nonempty open E interval,

and in particular

    RH
      <=>
    the strong v439 Gate A:
        sup_E |sum J_j(E)| = O_I(L).

This means v439 Gate A is NOT a pre-RH estimate obtainable from weaker
ordinary prime-error bounds without solving the core RH problem.

Non-circular redirect
---------------------
For FIXED-MODE CUTOFF INDEPENDENCE as an intermediate theorem, the more minimal
route remains the MOVING-BRANCH primitive-beta theorem from v419/v424:

    E_k'(L)=B_k(L)/L^2,

    Pi_k(L)=int B_k(s) ds.

It is sufficient to prove only along the actual ordered branch

    |Pi_k(L)| <= C_k L^(2-epsilon),

plus eventual no-fold / branch persistence.

Unlike the uniform fixed-E tube Gate A, this is a characteristic statement
along E_k(L), not a polynomial bound for an entire fixed energy interval.

v440 therefore classifies the fixed-tube route as RH-equivalent and redirects
the next proof attack to:

    PROVE_MOVING_BRANCH_PRIMITIVE_BETA_BY_CHARACTERISTIC/KREIN_DYNAMICS

without assuming the fixed-tube Gate A.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumed by the script.
NO new roots.
NO larger cutoffs.
The finite v439/v424 data are diagnostics only.

Version: 440
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 440
LOG2 = math.log(2.0)


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    beta, gamma, E = sp.symbols(
        "beta gamma E",
        real=True,
    )
    I = sp.I
    rho = beta + I*gamma
    sp_ = sp.Rational(1, 2) - I*E
    sm_ = sp.Rational(1, 2) + I*E

    lam_p = sp.simplify(rho-sp_)
    lam_m = sp.simplify(rho-sm_)

    c_p = sp.simplify(
        sp_/(2*I*rho*(rho-sp_))
    )
    c_m = sp.simplify(
        -sm_/(2*I*rho*(rho-sm_))
    )

    collision_E = sp.solve(
        sp.Eq(
            gamma+E,
            sp.symbols("gamma2", real=True)-E,
        ),
        E,
    )

    return {
        "s_plus": str(sp_),
        "s_minus": str(sm_),
        "lambda_plus": str(lam_p),
        "lambda_minus": str(lam_m),
        "real_part_both": "beta-1/2",
        "coefficient_plus": str(c_p),
        "coefficient_minus": str(c_m),
        "cross_channel_collision": (
            "E=(gamma2-gamma)/2"
        ),
        "collision_solution_symbolic": [
            str(x) for x in collision_E
        ],
        "positive_delta_coefficients_nonzero": (
            "If beta>1/2, rho-s_+ and rho-s_- are nonzero; "
            "rho and s_+/- are nonzero, so c_+/- are nonzero."
        ),
        "pass": bool(
            sp.simplify(sp.re(lam_p)-(beta-sp.Rational(1,2))) == 0
            and sp.simplify(sp.re(lam_m)-(beta-sp.Rational(1,2))) == 0
        ),
    }


def finite_v439_diagnostics(
    primitive_path: str,
    points_path: str,
) -> Dict[str, Any]:
    out = {}
    pp = Path(primitive_path)
    qp = Path(points_path)

    if pp.exists():
        p = pd.read_csv(pp)
        out["primitive_available"] = True
        out["maximum_abs_primitive_per_shell"] = float(
            p["abs_primitive_per_shell"].max()
        )
        out["maximum_subquadratic_normalized"] = float(
            p["subquadratic_normalized"].max()
        )
        by_shell = (
            p.groupby("shell_index", as_index=False)
            .agg(
                max_abs_primitive_per_shell=(
                    "abs_primitive_per_shell", "max"
                ),
                max_abs_primitive=(
                    "abs_primitive_after_shell", "max"
                ),
            )
        )
        out["primitive_by_shell"] = by_shell.to_dict(
            orient="records"
        )
    else:
        out["primitive_available"] = False

    if qp.exists():
        q = pd.read_csv(qp)
        out["points_available"] = True
        out["minimum_sampled_Fp_over_L"] = float(
            min(
                q["Fp_X0_over_L0"].min(),
                q["Fp_X1_over_L1"].min(),
            )
        )
        out["maximum_abs_LDeltaF_full"] = float(
            np.max(
                np.abs(
                    q["L0"].to_numpy(float)
                    * q["deltaF_full"].to_numpy(float)
                )
            )
        )
    else:
        out["points_available"] = False

    out["proof_status"] = "FINITE_EVIDENCE_ONLY"
    return out


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v439-summary",
        default=(
            "rot_rh_fixed_E_tube_primitive_fresh_transversality_v439_"
            "SUMMARY.json"
        ),
    )
    ap.add_argument(
        "--v439-primitive",
        default=(
            "rot_rh_fixed_E_tube_primitive_fresh_transversality_v439_"
            "PRIMITIVE.csv"
        ),
    )
    ap.add_argument(
        "--v439-points",
        default=(
            "rot_rh_fixed_E_tube_primitive_fresh_transversality_v439_"
            "FIXED_E_POINTS.csv.gz"
        ),
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_fixed_tube_primitive_rh_equivalence_v440",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()

    v439 = load_json(args.v439_summary)
    v424 = load_json(args.v424_summary)

    v439_ok = bool(
        v439 is not None
        and v439.get("verdict")
        == (
            "EXACT_REPAIRED_FIXED_E_PRIMITIVE_FRESH_TRANSVERSALITY_"
            "REDUCTION_PASS_ANALYTIC_ALL_L_BOUNDS_OPEN"
        )
    )
    v424_ok = bool(
        v424 is not None
        and v424.get("verdict")
        == "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS"
    )

    print("="*238)
    print("ROT-RH v440 — FIXED-TUBE SINE-PRIMITIVE RH-EQUIVALENCE / MOVING-BRANCH REDIRECT")
    print("="*238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new roots / larger cutoff                 : NONE")
    print("finite evidence accepted as proof         : NO")
    print("="*238)

    print("[1] Upstream")
    print(
        "v439 repaired fixed-E reduction           :",
        v439_ok,
        None if v439 is None else v439.get("verdict"),
    )
    print(
        "v424 moving-branch primitive-beta evidence:",
        v424_ok,
        None if v424 is None else v424.get("verdict"),
    )

    print("\n[2] Explicit-formula pole algebra")
    sym = symbolic_checks()
    with tqdm(
        total=4,
        desc="sine primitive pole lemmas",
        unit="lemma",
    ) as bar:
        for _ in range(4):
            bar.update(1)

    print("symbolic pole algebra pass                :", sym.get("pass"))
    print("lambda_plus                              :", sym.get("lambda_plus"))
    print("lambda_minus                             :", sym.get("lambda_minus"))
    print("Re lambda_+/-                            :", sym.get("real_part_both"))
    print("cross-channel collision set              :", sym.get("cross_channel_collision"))
    print(
        "positive-delta residues                  : NONZERO away from countable pole collisions"
    )

    print("\n[3] Exact theorem classification")
    print(
        "primitive telescoping                    : sum J = H_L-H_L0"
    )
    print(
        "polynomial fixed-tube H growth            : excludes beta>1/2 by Laplace poles"
    )
    print(
        "functional-equation symmetry              : beta<=1/2 for all zeros => beta=1/2"
    )
    print(
        "RH converse                              : critical-line zero terms give O_I(L)"
    )
    print(
        "THEOREM CLASS                            : "
        "FIXED_TUBE_SINE_PRIMITIVE_POLYNOMIAL_GROWTH_IS_RH_EQUIVALENT"
    )

    finite = finite_v439_diagnostics(
        args.v439_primitive,
        args.v439_points,
    )

    print("\n[4] Finite arithmetic evidence only")
    if finite.get("primitive_available"):
        print(
            "maximum |primitive|/shell                :",
            f"{finite['maximum_abs_primitive_per_shell']:.12e}",
        )
        print(
            "maximum primitive/L^(2-eps) diagnostic  :",
            f"{finite['maximum_subquadratic_normalized']:.12e}",
        )
    if finite.get("points_available"):
        print(
            "minimum sampled F'/L                    :",
            f"{finite['minimum_sampled_Fp_over_L']:.12e}",
        )
        print(
            "maximum sampled |L DeltaF|              :",
            f"{finite['maximum_abs_LDeltaF_full']:.12e}",
        )

    exact_pass = bool(
        sym.get("pass")
        and v439_ok
    )

    verdict = (
        "EXACT_FIXED_TUBE_SINE_PRIMITIVE_RH_EQUIVALENCE_REDUCTION_PASS_MOVING_BRANCH_ROUTE_REQUIRED_FOR_INTERMEDIATE_CUTOFF_THEOREM"
        if exact_pass
        else
        "FIXED_TUBE_SINE_PRIMITIVE_RH_EQUIVALENCE_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "DERIVE_MOVING_BRANCH_PRIMITIVE_BETA_SUBQUADRATIC_FROM_CHARACTERISTIC_KREIN_DYNAMICS_WITHOUT_UNIFORM_FIXED_TUBE_GATE"
    )

    print("\n" + "="*238)
    print("VERDICT                                   :", verdict)
    print(
        "v439 GATE A                              : RH-EQUIVALENT CORE, NOT A WEAKER PRE-RH LEMMA"
    )
    print(
        "ORDINARY PNT MAGNITUDE ROUTE             : CANNOT CLOSE WITHOUT RH-STRENGTH INPUT"
    )
    print(
        "MINIMAL INTERMEDIATE FIXED-MODE ROUTE    : MOVING-BRANCH PRIMITIVE BETA (v419/v424)"
    )
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*238)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix)+"_SUMMARY.json")
    theorem_path = Path(str(prefix)+"_THEOREM.md")
    cert_path = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_roots": False,
            "larger_cutoff": False,
        },
        "upstream": {
            "v439_ok": v439_ok,
            "v424_finite_evidence_ok": v424_ok,
        },
        "symbolic": sym,
        "theorem_class": (
            "FIXED_TUBE_SINE_PRIMITIVE_POLYNOMIAL_GROWTH_IS_RH_EQUIVALENT"
        ),
        "analytic_statement": {
            "forward": (
                "Any finite polynomial bound for H_L(E), uniformly on a nonempty "
                "open E interval, excludes every beta>1/2 zero via a generic-E "
                "Laplace pole; zeta symmetry then yields RH."
            ),
            "reverse": (
                "Under RH, zero exponents are purely imaginary; finitely many "
                "near-resonant terms are O_I(L), while the far tail is absolutely "
                "summable from O_I(gamma^-2) coefficients and N(T)=O(T log T)."
            ),
            "normal_convergence_requirement": (
                "As in v432, the explicit-formula zero series / Laplace continuation "
                "must be written with a fully rigorous grouping and normal-convergence "
                "certificate before calling this a publication-level equivalence theorem."
            ),
        },
        "finite_v439": finite,
        "redirect": {
            "uniform_fixed_tube_gate_as_intermediate": False,
            "moving_branch_route": True,
            "moving_branch_target": (
                "|Pi_k(L)|=|int B_k(s) ds|<=C_k L^(2-epsilon), epsilon>0, "
                "plus eventual no-fold and branch persistence"
            ),
            "reason": (
                "moving-branch primitive beta is exactly sufficient for fixed-mode "
                "cutoff independence and does not assume a uniform polynomial bound "
                "on an entire fixed energy interval"
            ),
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v440 — fixed-tube primitive is the RH core

For fixed real `E`,

`H_L(E)=int_(log2)^L A(u)g'_E(u)du`.

The dyadic forcing telescopes:

`sum_(j<n)J_(L_j)(E)=H_(L_n)(E)-H_(L_0)(E)`.

Write

`g_E(u)=[e^(-s_+u)-e^(-s_-u)]/(2i)`,

with

`s_+=1/2-iE`, `s_-=1/2+iE`.

A nontrivial zero `rho` contributes

`H_rho
 =[s_+/(2i rho)]K_L(rho-s_+)
 -[s_-/(2i rho)]K_L(rho-s_-)`.

If `Re rho>1/2`, the two associated exponential rates lie in `Re lambda>0`
and have nonzero coefficients.  Cross-channel pole collisions occur only for
a countable set of real E.  Therefore any nonempty E interval contains a
generic E at which an off-critical zero produces an isolated right-half-plane
Laplace pole.

Consequently a polynomial bound for `H_L(E)` throughout a nonempty fixed-E
interval excludes all zeros with `beta>1/2`.  Functional-equation symmetry
then yields RH.

Conversely, under RH all zero rates are purely imaginary.  Near resonances
produce at most linear growth and the far zero tail has absolutely summable
`O(gamma^-2)` coefficients.  Hence `H_L=O_I(L)` on compact E intervals.

Thus the v439 uniform fixed-tube primitive Gate A is itself an RH-equivalent
core statement, subject to the same publication-level grouping / normal-
convergence completion required in v432.

For an intermediate fixed-mode cutoff theorem, return to the moving
characteristic:

`E_k'(L)=B_k(L)/L^2`.

It suffices to prove along the actual ordered branch

`Pi_k(L)=int B_k(s)ds=O_k(L^(2-epsilon))`

plus eventual no-fold and branch persistence.  This avoids assuming uniform
polynomial control over an entire fixed energy interval.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_MOVING_BRANCH_PRIMITIVE_BETA_REDIRECT_V1",
        "fixed_tube_gate_classification": {
            "proved_reduction": exact_pass,
            "class": "RH_EQUIVALENT_CORE",
            "do_not_use_as_weaker_intermediate_assumption": True,
        },
        "required_next_claims": {
            "moving_branch_primitive_beta": {
                "proved": False,
                "statement": (
                    "For each fixed ordered branch, "
                    "|Pi_k(L)|=|int B_k(s)ds|<=C_k L^(2-epsilon), epsilon>0."
                ),
                "preferred": "Pi_k(L)=O_k(L)",
            },
            "eventual_nofold": {
                "proved": False,
                "statement": "F'_L(E_k(L)) remains nonzero, preferably >=c_k L.",
            },
            "branch_persistence": {
                "proved": False,
                "statement": (
                    "The ordered k-th branch exists eventually and does not switch."
                ),
            },
        },
        "allowed_structure": [
            "v420 characteristic conservation",
            "v425 renormalized stiffness identity",
            "v436/v437 Krein representation",
            "exact moving-root flow",
        ],
        "forbidden_shortcuts": [
            "assume uniform fixed-tube Gate A",
            "assume RH",
            "known zero ordinates",
            "Xi fitting",
            "RH-equivalent square-root PNT error",
        ],
        "consequence": (
            "moving-branch primitive beta + nofold + persistence => "
            "fixed-mode cutoff independence without taking the uniform fixed-tube "
            "RH-equivalent statement as an assumption"
        ),
    }
    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
