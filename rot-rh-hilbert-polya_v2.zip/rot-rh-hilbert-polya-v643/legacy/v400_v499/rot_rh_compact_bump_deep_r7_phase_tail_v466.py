#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v466 — COMPACT-BUMP FINITE-PROPAGATION / DEEP R7 PHASE-TAIL THEOREM
============================================================================

PURPOSE
-------
Exploit together:

  1. compact bump support n < exp(L);
  2. the exact R^7 support jump by a factor 128;
  3. v402's exact beta=2 factorial four-jet contraction

       Qjet = 657981440000000/1853020188851841 < 1;

  4. v465's exact beta=2 dual formula for a decreasing bump profile.

This proves a new all-L statement: sufficiently deep recursive R^7 packets
make an exponentially vanishing contribution to the compact bump phase and its
first four factorially normalized E-jets.

No Xi, zeta values, zeta derivatives, or known zero ordinates are used.

---------------------------------------------------------------------------
A. Arithmetic fixed point and uniform input four-jet norm
---------------------------------------------------------------------------

Let

    x_n = (Lambda(n)-1)/(sqrt(n) log n),  n>=2,

and let T=R^7.  The exact recursive identity is

    x = G7 + T x.

For n>=2,

    Lambda(n) <= log n,

hence

    |x_n|
      <= (1 + 1/log 2)/sqrt(n)
      = C0/sqrt(n).

For every finite D and every E, define prefix E-jets

    A_r(m)
      = sum_(2<=n<=m)
          x_n (i log n)^r exp(i E log n),

r=0,1,2,3.

Use the beta=2 factorial four-jet norm

    ||x||_J
      = max_(0<=r<=3)
        sup_(2<=m<=D)
          (2/m)^2
          |A_r(m)|/[r! (log D)^r].

Since log n <= log D and

    sum_(n=2)^m n^(-1/2) <= 2 sqrt(m),

we have uniformly in D,E

    ||x||_J <= Cx,

where

    Cx = 2 sqrt(2) (1 + 1/log 2).

This is deliberately crude but unconditional.

---------------------------------------------------------------------------
B. v402 transfer
---------------------------------------------------------------------------

v402 proves, for every finite support and phase E,

    ||T u||_J <= Qjet ||u||_J,

with output support floor multiplied by 128.

Therefore after J packets,

    support(T^J x) >= s_J := 2*128^J,

and

    ||T^J x||_J <= Qjet^J Cx.

---------------------------------------------------------------------------
C. Exact beta=2 bump dual upper bound
---------------------------------------------------------------------------

Let

    b_L(n)=p(log n/L),
    p(t)=exp(-(t/(1-t))^2), 0<=t<1,

and b_L(n)=0 for n>=exp(L).

For a sequence supported on s<=n<=D, v465's exact Abel dual weight is

    W_2
      = (D/s)^2 b_D
        + sum_(m=s)^(D-1)
            (m/s)^2 (b_m-b_(m+1)).

Because b is nonnegative decreasing,

    W_2
      <= (D/s)^2
          [b_D + sum(b_m-b_(m+1))]
      = (D/s)^2 b_s
      <= (exp(L)/s)^2.

Hence for u=T^J x,

    W_2 <= exp(2L)/(4*128^(2J)).

Combining with v402 gives, for the normalized phase jet

    B_r(L,E;u)
      = 1/[r! L^r]
        partial_E^r
        sum_n b_L(n) u_n exp(iE log n),

r=0,1,2,3,

the common bound

    |B_r(L,E;T^J x)|
      <= (Cx/4) exp(2L)
         [Qjet/128^2]^J.

Define

    rhojet := Qjet/128^2
            = 40160000000/1853020188851841
            ~= 2.167272663385483e-5.

Thus

    max_(r<=3)|B_r|
      <= (Cx/4) exp(2L) rhojet^J.

This is an exact all-L consequence of the v402 theorem plus elementary Abel
summation.

---------------------------------------------------------------------------
D. Linear-depth exponential closure
---------------------------------------------------------------------------

Choose

    J(L)=ceil(kappa L).

If

    kappa > kappa_min
          := 2/|log rhojet|,

then

    delta(kappa)
      := kappa |log rhojet| - 2
      > 0

and

    max_(r<=3)|B_r(L,E;T^J x)|
      <= (Cx/4) exp[-delta(kappa)L].

Numerically

    kappa_min ~= 0.1862291734.

The compact bump itself becomes identically blind to the remainder once

    2*128^J >= exp(L).

The asymptotic support threshold is

    kappa_support = 1/log 128
                  ~= 0.2060992916.

Since

    kappa_min < kappa_support,

there is a nonempty interval in which the deep packet is still potentially
inside the bump support yet its complete phase four-jet is already
exponentially small.

The supremal four-jet decay rate as kappa approaches 1/log128 from below is

    delta_* =
      |log rhojet|/log128 - 2
      ~= 0.2133942578.

For the phase zero-jet alone, v402's sharper Q2 constant may be used:

    Q2 = 82247680000000/617673396283947,

    rho2=Q2/128^2,

giving

    kappa_min,0 = 2/|log rho2|
                 ~= 0.1706443119,

and a supremal zero-jet rate

    delta_0,* ~= 0.4155424720.

---------------------------------------------------------------------------
E. Exact finite propagation identity
---------------------------------------------------------------------------

Iterating x=G7+Tx gives

    x
      = sum_(j=0)^(J-1) T^j G7
        + T^J x.

For every finite L, if

    J >= ceil(log(exp(L)/2)/log128),

then the last term has support entirely beyond exp(L) and its compact bump
phase is EXACTLY ZERO.

Therefore the bump phase is always an exactly finite packet sum at finite L.

v466 additionally proves that one does not have to iterate all the way to exact
support extinction: choosing J approximately kappa L with
kappa>0.186229... already makes the full normalized four-jet remainder
exponentially small.

---------------------------------------------------------------------------
F. What remains
---------------------------------------------------------------------------

The unresolved object is now the packet head

    sum_(0<=j<J(L)) T^j G7,

with J(L)=O(L).

v466 does NOT prove cancellation of this growing packet head.
It does NOT prove the half-plane condition from v465.
It does NOT prove fixed-mode cutoff independence, RH, or the Fredholm-Xi
identity.

The next theorem should exploit packet-to-packet phase structure, real
arithmetic restrictions, or an independent operator/index property to control
the fractional phase of this O(L) packet head.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from fractions import Fraction
from pathlib import Path
from typing import Dict, Any, List

from tqdm import tqdm

VERSION = "2026-08-28-v466-compact-bump-deep-r7-phase-tail"

Q2 = Fraction(82247680000000, 617673396283947)
QJET = Fraction(657981440000000, 1853020188851841)
RHO2 = Q2 / (128**2)
RHOJET = QJET / (128**2)

C0 = 1.0 + 1.0 / math.log(2.0)
CX = 2.0 * math.sqrt(2.0) * C0


def constants() -> Dict[str, Any]:
    q2 = float(Q2)
    qj = float(QJET)
    rho2 = float(RHO2)
    rhoj = float(RHOJET)
    k0 = 2.0 / (-math.log(rho2))
    kj = 2.0 / (-math.log(rhoj))
    ks = 1.0 / math.log(128.0)
    delta0star = -(
        2.0 + ks * math.log(rho2)
    )
    deltajstar = -(
        2.0 + ks * math.log(rhoj)
    )
    return {
        "C0": C0,
        "Cx": CX,
        "Q2_fraction": f"{Q2.numerator}/{Q2.denominator}",
        "Q2": q2,
        "Qjet_fraction": f"{QJET.numerator}/{QJET.denominator}",
        "Qjet": qj,
        "rho2_fraction": f"{RHO2.numerator}/{RHO2.denominator}",
        "rho2": rho2,
        "rhojet_fraction": f"{RHOJET.numerator}/{RHOJET.denominator}",
        "rhojet": rhoj,
        "kappa_min_zerojet": k0,
        "kappa_min_fourjet": kj,
        "kappa_support": ks,
        "zerojet_nonempty_interval": k0 < ks,
        "fourjet_nonempty_interval": kj < ks,
        "delta_zerojet_support_supremum": delta0star,
        "delta_fourjet_support_supremum": deltajstar,
    }


def arithmetic_input_bound_check(D_values: List[int]) -> Dict[str, Any]:
    """
    Verify only the elementary analytic majorant:
        sum_{n=2}^m n^-1/2 <= 2 sqrt(m)
    and the resulting beta=2 bound.  Lambda values are not needed.
    """
    rows = []
    max_ratio = 0.0
    for D in tqdm(D_values, desc="v466 input majorant", unit="D", leave=False):
        s = 0.0
        local_max = 0.0
        for n in range(2, D + 1):
            s += n ** -0.5
            m = n
            ratio = ((2.0 / m) ** 2) * C0 * s
            local_max = max(local_max, ratio)
        max_ratio = max(max_ratio, local_max)
        rows.append({
            "D": D,
            "max_beta2_absolute_majorant": local_max,
            "Cx_bound": CX,
            "pass": local_max <= CX + 1e-12,
        })
    return {
        "rows": rows,
        "maximum_observed_majorant": max_ratio,
        "analytic_Cx": CX,
        "pass": all(r["pass"] for r in rows),
    }


def bump_p(x: float) -> float:
    if x < 0.0:
        return float("nan")
    if x >= 1.0:
        return 0.0
    z = x / (1.0 - x)
    expo = -(z*z)
    if expo < -745.0:
        return 0.0
    return math.exp(expo)


def exact_W2(L: float, s: int, D: int) -> float:
    if D < s:
        return 0.0
    bD = bump_p(math.log(D)/L)
    total = (D/s)**2 * bD
    for m in range(s, D):
        bm = bump_p(math.log(m)/L)
        bn = bump_p(math.log(m+1)/L)
        total += (m/s)**2 * max(0.0, bm-bn)
    return total


def dual_upper_diagnostics() -> Dict[str, Any]:
    cases = [
        (8.0, 2, 500),
        (10.0, 128, 4000),
        (12.0, 2048, 20000),
    ]
    rows = []
    for L, s, Draw in tqdm(cases, desc="v466 dual bounds", unit="case", leave=False):
        D = min(Draw, max(s, int(math.floor(math.exp(L))) - 1))
        if D < s:
            rows.append({
                "L": L, "s": s, "D": D, "W2": 0.0,
                "upper": 0.0, "pass": True,
            })
            continue
        W = exact_W2(L, s, D)
        upper = (math.exp(L)/s)**2
        rows.append({
            "L": L,
            "s": s,
            "D": D,
            "W2": W,
            "upper": upper,
            "ratio": W/upper if upper else 0.0,
            "pass": W <= upper * (1.0 + 2e-12),
        })
    return {
        "rows": rows,
        "pass": all(r["pass"] for r in rows),
    }


def depth_bound(L: float, kappa: float, fourjet: bool = True) -> Dict[str, Any]:
    rho = float(RHOJET if fourjet else RHO2)
    J = int(math.ceil(kappa * L))
    prefactor = CX / 4.0
    log_bound = math.log(prefactor) + 2.0*L + J*math.log(rho)
    bound = 0.0 if log_bound < -745.0 else math.exp(log_bound)
    sJ_log = math.log(2.0) + J*math.log(128.0)
    support_extinct = sJ_log >= L
    delta = kappa * (-math.log(rho)) - 2.0
    return {
        "L": L,
        "kappa": kappa,
        "J": J,
        "fourjet": fourjet,
        "rho": rho,
        "delta_continuous": delta,
        "log_bound": log_bound,
        "bound": bound,
        "log_support_floor": sJ_log,
        "bump_log_cutoff": L,
        "support_extinct": support_extinct,
    }


def panel(kappa: float) -> List[Dict[str, Any]]:
    rows = []
    for L in (10.0, 20.0, 40.0, 80.0, 160.0):
        rows.append(depth_bound(L, kappa, True))
    return rows


def symbolic_logic() -> Dict[str, Any]:
    rho = float(RHOJET)
    kmin = 2.0/(-math.log(rho))
    ksupport = 1.0/math.log(128.0)
    # Exact-rational identity for the fixed-prefix factor.
    rho_identity = (
        RHOJET
        == Fraction(40160000000, 1853020188851841)
    )
    return {
        "rhojet_identity_exact": rho_identity,
        "kappa_interval_nonempty": kmin < ksupport,
        "tail_exponent_formula": "delta=kappa*abs(log(rhojet))-2",
        "support_formula": "s_J=2*128^J",
        "finite_propagation":
            "if 2*128^J>=exp(L), compact bump pairing with T^J x is exactly zero",
        "pass": bool(rho_identity and kmin < ksupport),
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    cert = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    c = payload["constants"]
    theorem.write_text(
f"""# ROT-RH v466 — compact-bump finite-propagation / deep R7 phase-tail theorem

## 1. Inputs

Use the exact recursive fixed point

`x=G7+R^7 x`

with

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`.

The elementary bound `Lambda(n)<=log n` gives a cutoff- and phase-independent
beta-2 factorial four-jet bound

`||x||_J <= Cx`

with

`Cx=2 sqrt(2)(1+1/log2)={c['Cx']:.16e}`.

v402 proves the exact all-support four-jet transfer

`||R^7 u||_J <= Qjet ||u||_J`

with

`Qjet={c['Qjet_fraction']} ~= {c['Qjet']:.16e}`

and support floor multiplied by `128`.

## 2. Compact bump dual estimate

For `b_L(n)=p(log n/L)` and beta=2, v465's exact Abel formula implies

`W2(b_L;s,D) <= (exp(L)/s)^2`.

After `J` R7 packets,

`s_J=2*128^J`

and therefore

`max_(r=0..3) |B_r(L,E;R^(7J)x)|
 <= (Cx/4) exp(2L) rhojet^J`,

where `B_r` denotes the factorially `L^-r` normalized E-jet and

`rhojet=Qjet/128^2
       ={c['rhojet_fraction']}
       ~={c['rhojet']:.16e}`.

## 3. Exponential deep-tail closure

Let

`J(L)=ceil(kappa L)`.

If

`kappa > 2/|log rhojet|
       = {c['kappa_min_fourjet']:.16e}`,

then

`max_(r<=3)|B_r|
 <= (Cx/4) exp[-delta(kappa)L]`

with

`delta(kappa)=kappa|log rhojet|-2>0`.

The support-extinction threshold is

`1/log128={c['kappa_support']:.16e}`.

Since

`{c['kappa_min_fourjet']:.16e}
 <
 {c['kappa_support']:.16e}`,

the exponential four-jet closure begins before the compact bump becomes
identically blind to the remainder.

The limiting best four-jet exponent at the support edge is

`delta_*={c['delta_fourjet_support_supremum']:.16e}`.

For the phase zero-jet alone one may use `Q2` rather than `Qjet`, giving

`kappa_min,0={c['kappa_min_zerojet']:.16e}`

and support-edge exponent

`delta_0,*={c['delta_zerojet_support_supremum']:.16e}`.

## 4. Exact finite propagation

Iterating the recursion,

`x=sum_(j=0)^(J-1)(R^7)^j G7 + (R^7)^J x`.

If

`2*128^J>=exp(L)`,

the last term contributes exactly zero to the compact bump phase because its
coefficient support begins beyond the bump support.

Thus at each finite `L` the bump observable is exactly a finite recursive packet
sum.

## 5. What v466 changes

The deep recursive tail is no longer part of the bump cutoff-independence
bottleneck.  The unresolved object is the growing packet head

`sum_(j<J(L))(R^7)^j G7`.

The all-L half-plane theorem from v465 must therefore be proved from the
fractional phase of this packet head, using packet-to-packet phase cancellation,
the real arithmetic subspace, or an independent operator/index principle.

v466 does **not** prove that packet-head theorem, fixed-mode cutoff independence,
RH, or the Fredholm-Xi identity.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_COMPACT_BUMP_DEEP_R7_PHASE_TAIL_V1",
        "closed": {
            "arithmetic_input_fourjet_bound":
                "||x||_J <= 2 sqrt(2)(1+1/log2)",
            "R7_fourjet_contraction":
                f"Qjet={c['Qjet_fraction']}<1",
            "support_jump": "s_J=2*128^J",
            "bump_beta2_dual":
                "W2<=exp(2L)/s_J^2",
            "deep_fourjet":
                "max_r<=3 |B_r| <= (Cx/4) exp(2L) rhojet^J",
            "linear_depth_closure":
                "J=ceil(kappa L), kappa>2/|log rhojet| => exponential decay",
            "finite_propagation":
                "2*128^J>=exp(L) => compact bump remainder exactly zero",
        },
        "remaining": {
            "packet_head":
                "control fractional phase of sum_{j<J(L)}(R^7)^j G7",
            "halfplane":
                "prove L*dist(epsilon_L,Z+1/2)->infinity or an equivalent half-plane gap",
            "operator_promotion":
                "after fixed-mode closure, retain T_TAIL for trace-norm operator limit",
        },
        "next_attack": (
            "Exploit the multiplicative packet phase across j.  Test whether the "
            "R7 packet head admits a scale-index Dirichlet/cyclic-BV theorem after "
            "demodulation by the natural phase increment E*log(128), while keeping "
            "the real arithmetic restrictions."
        ),
    }
    cert.write_text(json.dumps(certificate, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--kappa", type=float, default=0.195)
    ap.add_argument(
        "--prefix",
        default="rot_rh_compact_bump_deep_r7_phase_tail_v466",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    c = constants()
    if args.kappa <= c["kappa_min_fourjet"]:
        raise ValueError(
            f"--kappa must exceed {c['kappa_min_fourjet']:.12g} "
            "for the four-jet exponential theorem."
        )

    print("="*196)
    print("ROT-RH v466 — COMPACT-BUMP FINITE-PROPAGATION / DEEP R7 PHASE-TAIL THEOREM")
    print("="*196)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("v402 Qjet                                  :", f"{c['Qjet']:.16e}")
    print("rhojet=Qjet/128^2                          :", f"{c['rhojet']:.16e}")
    print("selected kappa                             :", args.kappa)
    print("="*196)

    with tqdm(total=4, desc="v466 exact reduction", unit="step") as bar:
        sym = symbolic_logic()
        bar.update(1)
        inp = arithmetic_input_bound_check([32, 128, 512, 2048])
        bar.update(1)
        dual = dual_upper_diagnostics()
        bar.update(1)
        p = panel(args.kappa)
        bar.update(1)

    delta = args.kappa * (-math.log(c["rhojet"])) - 2.0
    theorem_pass = bool(
        sym["pass"]
        and inp["pass"]
        and dual["pass"]
        and delta > 0.0
    )

    verdict = (
        "EXACT_COMPACT_BUMP_DEEP_R7_PHASE_FOURJET_TAIL_CLOSURE_PASS"
        if theorem_pass else
        "COMPACT_BUMP_DEEP_R7_PHASE_TAIL_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "finite_scan_accepted_as_proof": False,
        },
        "constants": c,
        "selected": {
            "kappa": args.kappa,
            "delta_fourjet": delta,
        },
        "symbolic_logic": sym,
        "input_majorant": inp,
        "dual_diagnostics": dual,
        "depth_panel": p,
        "proof_status": (
            "Exact all-L deep-tail theorem conditional only on the already-proved "
            "v402 weighted four-jet contraction.  The O(L) recursive packet head "
            "remains open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*196)
    print("verdict                                  :", verdict)
    print("Cx                                       :", f"{c['Cx']:.16e}")
    print("kappa_min zero-jet                       :", f"{c['kappa_min_zerojet']:.16e}")
    print("kappa_min four-jet                       :", f"{c['kappa_min_fourjet']:.16e}")
    print("support threshold 1/log128               :", f"{c['kappa_support']:.16e}")
    print("selected four-jet decay exponent         :", f"{delta:.16e}")
    print("support-edge four-jet exponent supremum  :", f"{c['delta_fourjet_support_supremum']:.16e}")
    print("support-edge zero-jet exponent supremum  :", f"{c['delta_zerojet_support_supremum']:.16e}")
    print("summary                                  :", str(prefix)+"_SUMMARY.json")
    print("theorem                                  :", str(prefix)+"_THEOREM.md")
    print("next certificate                         :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*196)

    if args.strict and not theorem_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
