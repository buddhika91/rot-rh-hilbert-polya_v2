#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v412 — PROSPECTIVE ARITHMETIC DYADIC LOCK-TRANSFER / TRANSVERSALITY HOLDOUT
==================================================================================

Purpose
-------
Directly test the two FINAL fixed-mode cutoff-independence hypotheses isolated
by v411 + v392, using only the frozen arithmetic Riesz phase.

For each source cutoff X and its frozen arithmetic root E_{k,X}, evaluate
WITHOUT solving a root at Y:

    transfer:
      T_{k,X}(Y)
        = (log X) |F_Y(E_{k,X}) - F_X(E_{k,X})|,

    transversality:
      c_{k,X}(Y)
        = min_{E in transfer tube} F'_Y(E) / log X,

for Y in [X,2X].

The first quantity is exactly the scaled short-window collective lock-transfer
required by v392/v411:

    |F_Y(E_{k,X})-F_X(E_{k,X})| <= C_k/log X.

The second is exactly the transfer-tube slope condition:

    F'_Y(E) >= c_k log X.

Scientific design
-----------------
* Uses NO Xi.
* Uses NO zeta evaluations.
* Uses NO zeta-zero ordinates.
* Uses NO root at Y.
* Uses the source X-root only.
* Canonical phase gauge is inherited from v77/v71: F_X(0)=0.
* Development anchors freeze per-k and global caps.
* The largest requested/source anchor is held out prospectively.
* Finite PASS is evidence only, not an all-X theorem.

Recommended use
---------------
If your v78 forward audit produced roots at 8M and 16M:

    python rot_rh_arithmetic_dyadic_lock_holdout_v412.py ^
      --roots-csv rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv ^
      --anchors 8000000,16000000 ^
      --y-fractions 1.125,1.25,1.5,1.75,2.0 ^
      ...

This requires prime arithmetic only up to max(2X), so the above reaches 32M
rather than continuing roots to 32M.

Version: 412
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 412


def csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def native(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    raise TypeError(type(x).__name__)


def choose_energy_column(df: pd.DataFrame) -> str:
    for c in ["energy", "E", "root", "root_energy"]:
        if c in df.columns:
            return c
    raise KeyError(
        "roots CSV needs an energy column; tried energy,E,root,root_energy"
    )


def choose_root_index_column(df: pd.DataFrame) -> str:
    for c in ["root_index", "mode_index", "k", "index"]:
        if c in df.columns:
            return c
    raise KeyError(
        "roots CSV needs a root-index column; tried root_index,mode_index,k,index"
    )


def build_anchor_roots(
    df: pd.DataFrame,
    anchors: List[int],
    max_modes: int,
) -> Dict[int, np.ndarray]:
    e_col = choose_energy_column(df)
    k_col = choose_root_index_column(df)

    out: Dict[int, np.ndarray] = {}
    for X in anchors:
        g = df[df["cutoff"].astype(int) == int(X)].copy()
        if g.empty:
            raise ValueError(
                f"Requested anchor X={X:,} not present in roots CSV. "
                f"Available cutoffs: {sorted(df['cutoff'].astype(int).unique())}"
            )
        g = g.sort_values(k_col)
        e = g[e_col].to_numpy(float)
        if max_modes > 0:
            e = e[:max_modes]
        out[X] = e

    common = min(len(v) for v in out.values())
    if common < 1:
        raise ValueError("No common modes across anchors.")
    for X in out:
        out[X] = out[X][:common]
    return out


def tube_radius(
    X: int,
    eta: float,
    c_coordinate: float,
    sep_fraction: float,
) -> float:
    # Same geometry used by v78:
    # Y_height = X^(1/2+eta)
    # radius = (1-sep_fraction)c_coordinate/log(Y_height).
    L = math.log(float(X))
    return (
        (1.0 - sep_fraction)
        * c_coordinate
        / ((0.5 + eta) * L)
    )


def phase_and_slope(
    base,
    energies: np.ndarray,
    X: int,
    primes: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    logs, weights, _ = base.prime_power_riesz_terms(primes, int(X))
    F = np.asarray(base.phase_grid(energies, X, logs, weights), float)
    Fp = np.asarray(base.phase_prime_grid(energies, X, logs, weights), float)
    return F, Fp, logs, weights


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--roots-csv",
        default="rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv",
        help=(
            "Arithmetic root table containing cutoff, root index, energy. "
            "Only roots at the requested X anchors are used."
        ),
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument(
        "--anchors",
        default="8000000,16000000",
        help=(
            "X anchors already present in roots CSV. "
            "All except the last are development; last is prospective holdout."
        ),
    )
    ap.add_argument(
        "--y-fractions",
        default="1.125,1.25,1.5,1.75,2.0",
        help="Y/X values in (1,2].",
    )
    ap.add_argument(
        "--max-modes",
        type=int,
        default=32,
        help="0 means every common source mode.",
    )
    ap.add_argument(
        "--tube-samples",
        type=int,
        default=9,
    )
    ap.add_argument("--eta", type=float, default=0.10)
    ap.add_argument("--c-coordinate", type=float, default=1.0)
    ap.add_argument("--sep-fraction", type=float, default=0.60)

    ap.add_argument(
        "--transfer-safety",
        type=float,
        default=1.50,
        help="Development per-k/global scaled-transfer max multiplier.",
    )
    ap.add_argument(
        "--slope-safety",
        type=float,
        default=0.85,
        help=(
            "Development minimum slope coefficient multiplier; "
            "<1 makes the frozen lower bound conservative."
        ),
    )
    ap.add_argument(
        "--minimum-holdout-slope-coefficient",
        type=float,
        default=0.20,
        help="Independent sanity floor on F'_Y/logX.",
    )

    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_arithmetic_dyadic_lock_holdout_v412",
    )

    args = ap.parse_args()

    started = time.time()

    if args.tube_samples < 3:
        raise ValueError("--tube-samples must be >=3")
    if args.transfer_safety <= 1:
        raise ValueError("--transfer-safety must be >1")
    if not (0 < args.slope_safety < 1):
        raise ValueError("--slope-safety must lie in (0,1)")
    if not (0 < args.sep_fraction < 1):
        raise ValueError("--sep-fraction must lie in (0,1)")

    roots_path = Path(args.roots_csv)
    if not roots_path.exists():
        raise FileNotFoundError(roots_path)

    anchors = sorted(set(csv_ints(args.anchors)))
    if len(anchors) < 2:
        raise ValueError("Need at least two anchors for development + holdout.")

    y_fracs = sorted(set(csv_floats(args.y_fractions)))
    if not y_fracs:
        raise ValueError("Need at least one Y fraction.")
    if any(not (1.0 < q <= 2.0) for q in y_fracs):
        raise ValueError("Every --y-fractions value must lie in (1,2].")

    roots_df = pd.read_csv(roots_path)
    if "cutoff" not in roots_df.columns:
        raise KeyError("roots CSV missing cutoff column")

    roots = build_anchor_roots(
        roots_df,
        anchors,
        args.max_modes,
    )
    common = min(len(x) for x in roots.values())

    development_anchors = anchors[:-1]
    holdout_anchor = anchors[-1]

    maxY = int(
        math.ceil(
            max(anchors)
            * max(y_fracs)
        )
    )

    base = importlib.import_module(args.v71_module)

    print("=" * 238)
    print("ROT-RH v412 — PROSPECTIVE ARITHMETIC DYADIC LOCK-TRANSFER / TRANSVERSALITY HOLDOUT")
    print("=" * 238)
    print("Xi / zeta / known-zero data             : NONE")
    print("roots solved at transfer Y              : NO")
    print("source roots used only at X anchors      : YES")
    print("canonical phase gauge                    : v71/v77 F_X(0)=0")
    print("anchors                                  :", anchors)
    print("development anchors                      :", development_anchors)
    print("prospective holdout anchor               :", holdout_anchor)
    print("Y/X fractions                            :", y_fracs)
    print("common modes                             :", common)
    print("maximum arithmetic cutoff Y              :", f"{maxY:,}")
    print("=" * 238)

    print("[1] Building one prime table")
    t0 = time.time()
    primes = base.sieve_primes(maxY)
    print("primes <= maxY                           :", f"{len(primes):,}")
    print("sieve seconds                            :", f"{time.time()-t0:.2f}")

    rows = []

    total_jobs = len(anchors) * len(y_fracs)
    pbar = tqdm(
        total=total_jobs,
        desc="dyadic arithmetic transfer",
        unit="X,Y",
    )

    for X in anchors:
        Eroots = roots[X]
        tX = math.log(float(X))
        radius = tube_radius(
            X,
            args.eta,
            args.c_coordinate,
            args.sep_fraction,
        )
        offsets = np.linspace(
            -radius,
            radius,
            args.tube_samples,
        )

        # Source phase at the frozen X roots.
        FX, FpX, logsX, weightsX = phase_and_slope(
            base,
            Eroots,
            X,
            primes,
        )

        # Quantization diagnostic only: cos(F)=0 at source root.
        root_cos_resid = np.abs(np.cos(FX))

        for q in y_fracs:
            Y = int(round(X * q))
            tY = math.log(float(Y))
            Delta = tY - tX

            logsY, weightsY, _ = base.prime_power_riesz_terms(
                primes,
                Y,
            )

            FY = np.asarray(
                base.phase_grid(
                    Eroots,
                    Y,
                    logsY,
                    weightsY,
                ),
                float,
            )

            transfer = FY - FX
            abs_transfer = np.abs(transfer)
            scaled_transfer = tX * abs_transfer

            # Transfer-tube transversality at Y around the frozen X root.
            # Evaluate per mode in modest batches to keep memory bounded.
            for ki, E0 in enumerate(Eroots, start=1):
                Egrid = E0 + offsets
                slopes = np.asarray(
                    base.phase_prime_grid(
                        Egrid,
                        Y,
                        logsY,
                        weightsY,
                    ),
                    float,
                )
                min_slope = float(np.min(slopes))
                rootY_slope_at_frozenE = float(
                    base.phase_prime_grid(
                        np.asarray([E0]),
                        Y,
                        logsY,
                        weightsY,
                    )[0]
                )

                rows.append({
                    "set": (
                        "holdout"
                        if X == holdout_anchor
                        else "development"
                    ),
                    "X": int(X),
                    "Y": int(Y),
                    "Y_over_X": float(q),
                    "Delta_log_cutoff": float(Delta),
                    "root_index": int(ki),
                    "E_k_X": float(E0),
                    "logX": float(tX),
                    "logY": float(tY),
                    "tube_radius": float(radius),
                    "source_root_cos_residual": float(
                        root_cos_resid[ki - 1]
                    ),
                    "F_X_at_source_root": float(FX[ki - 1]),
                    "F_Y_at_frozen_X_root": float(FY[ki - 1]),
                    "signed_phase_transfer": float(
                        transfer[ki - 1]
                    ),
                    "abs_phase_transfer": float(
                        abs_transfer[ki - 1]
                    ),
                    "scaled_lock_transfer_logX_times_abs": float(
                        scaled_transfer[ki - 1]
                    ),
                    "Y_slope_at_frozen_X_root": (
                        rootY_slope_at_frozenE
                    ),
                    "Y_slope_at_frozen_X_root_over_logX": float(
                        rootY_slope_at_frozenE / tX
                    ),
                    "transfer_tube_min_slope": min_slope,
                    "transfer_tube_min_slope_over_logX": float(
                        min_slope / tX
                    ),
                    "term_count_Y": int(len(logsY)),
                })

            pbar.update(1)

    pbar.close()

    df = pd.DataFrame(rows)

    print("\n[2] Freezing development theorem quantities")

    dev = df[df["set"] == "development"].copy()
    hold = df[df["set"] == "holdout"].copy()

    if dev.empty or hold.empty:
        raise RuntimeError("Need nonempty development and holdout rows.")

    transfer_col = "scaled_lock_transfer_logX_times_abs"
    slope_col = "transfer_tube_min_slope_over_logX"

    global_dev_transfer_max = float(dev[transfer_col].max())
    global_transfer_cap = (
        args.transfer_safety
        * global_dev_transfer_max
    )

    global_dev_slope_min = float(dev[slope_col].min())
    global_slope_floor = (
        args.slope_safety
        * global_dev_slope_min
    )

    print(
        "development max logX*|phase transfer|    :",
        f"{global_dev_transfer_max:.12e}",
    )
    print(
        "frozen global transfer cap               :",
        f"{global_transfer_cap:.12e}",
    )
    print(
        "development min tube slope/logX          :",
        f"{global_dev_slope_min:.12e}",
    )
    print(
        "frozen global slope floor                :",
        f"{global_slope_floor:.12e}",
    )

    per_k = []
    for k, gdev in dev.groupby("root_index"):
        gh = hold[hold["root_index"] == k]
        if gh.empty:
            continue

        dT = float(gdev[transfer_col].max())
        Tcap = args.transfer_safety * dT

        dc = float(gdev[slope_col].min())
        cfloor = args.slope_safety * dc

        hT = float(gh[transfer_col].max())
        hc = float(gh[slope_col].min())

        per_k.append({
            "root_index": int(k),
            "development_transfer_max": dT,
            "frozen_transfer_cap": Tcap,
            "holdout_transfer_max": hT,
            "holdout_transfer_ratio_to_cap": (
                hT / Tcap if Tcap > 0 else math.inf
            ),
            "transfer_holdout_pass": bool(hT <= Tcap),
            "development_slope_min": dc,
            "frozen_slope_floor": cfloor,
            "holdout_slope_min": hc,
            "slope_holdout_pass": bool(
                hc >= cfloor
                and hc >= args.minimum_holdout_slope_coefficient
            ),
        })

    pk = pd.DataFrame(per_k)

    global_hold_transfer_max = float(
        hold[transfer_col].max()
    )
    global_hold_slope_min = float(
        hold[slope_col].min()
    )

    global_transfer_pass = bool(
        global_hold_transfer_max
        <= global_transfer_cap
    )
    global_slope_pass = bool(
        global_hold_slope_min
        >= global_slope_floor
        and global_hold_slope_min
        >= args.minimum_holdout_slope_coefficient
    )

    per_k_transfer_pass = bool(
        pk["transfer_holdout_pass"].all()
    )
    per_k_slope_pass = bool(
        pk["slope_holdout_pass"].all()
    )

    print("\n[3] Prospective holdout")
    print(
        "holdout max logX*|phase transfer|        :",
        f"{global_hold_transfer_max:.12e}",
    )
    print(
        "holdout / global frozen cap              :",
        f"{global_hold_transfer_max/global_transfer_cap:.9f}",
    )
    print(
        "holdout min transfer-tube slope/logX     :",
        f"{global_hold_slope_min:.12e}",
    )
    print("global transfer holdout pass             :", global_transfer_pass)
    print("global slope holdout pass                :", global_slope_pass)
    print("every fixed-k transfer cap pass          :", per_k_transfer_pass)
    print("every fixed-k slope floor pass           :", per_k_slope_pass)

    print("\nWorst transfer holdout rows:")
    worst_transfer = (
        hold
        .sort_values(transfer_col, ascending=False)
        .head(12)
    )
    print(
        worst_transfer[
            [
                "X", "Y", "Y_over_X",
                "root_index", "E_k_X",
                transfer_col,
                slope_col,
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nWorst slope holdout rows:")
    worst_slope = (
        hold
        .sort_values(slope_col, ascending=True)
        .head(12)
    )
    print(
        worst_slope[
            [
                "X", "Y", "Y_over_X",
                "root_index", "E_k_X",
                transfer_col,
                slope_col,
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    # Anchor summaries.
    anchor_rows = []
    for (set_name, X), g in df.groupby(["set", "X"]):
        anchor_rows.append({
            "set": set_name,
            "X": int(X),
            "logX": float(math.log(X)),
            "modes": int(g["root_index"].nunique()),
            "Y_count": int(g["Y"].nunique()),
            "maximum_scaled_lock_transfer": float(
                g[transfer_col].max()
            ),
            "minimum_transfer_tube_slope_over_logX": float(
                g[slope_col].min()
            ),
            "maximum_source_root_cos_residual": float(
                g["source_root_cos_residual"].max()
            ),
        })
    anchor_df = pd.DataFrame(anchor_rows).sort_values("X")

    print("\n[4] Anchor summary")
    print(
        anchor_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.12e}",
        )
    )

    gates = {
        "source_root_quantization_residual_small": bool(
            df["source_root_cos_residual"].max() <= 1e-6
        ),
        "global_transfer_holdout_pass": global_transfer_pass,
        "global_slope_holdout_pass": global_slope_pass,
        "every_fixed_k_transfer_holdout_pass": per_k_transfer_pass,
        "every_fixed_k_slope_holdout_pass": per_k_slope_pass,
        "all_holdout_slopes_positive": bool(
            (hold["transfer_tube_min_slope"] > 0).all()
        ),
    }

    failed = [
        k for k, v in gates.items()
        if not v
    ]

    if not failed:
        verdict = (
            "PROSPECTIVE_ARITHMETIC_DYADIC_LOCK_AND_TRANSVERSALITY_HOLDOUT_PASS"
        )
        next_theorem = (
            "PROVE_ALL_X_ARITHMETIC_LOCK_TRANSFER_BOUND_AND_SLOPE_FLOOR_USING_THE_EXACT_RIESZ_CROSS_CUTOFF_IDENTITY"
        )
    elif (
        global_slope_pass
        and per_k_slope_pass
        and not global_transfer_pass
    ):
        verdict = (
            "TRANSVERSALITY_SURVIVES_BUT_DYADIC_LOCK_TRANSFER_FREEZE_BREAKS"
        )
        next_theorem = (
            "LOCALIZE_PHASE_TRANSFER_GROWTH_BY_MODE_AND_Y_FRACTION_BEFORE_ANALYTIC_CLOSURE"
        )
    elif (
        global_transfer_pass
        and per_k_transfer_pass
        and not global_slope_pass
    ):
        verdict = (
            "DYADIC_LOCK_TRANSFER_SURVIVES_BUT_TRANSVERSALITY_FREEZE_BREAKS"
        )
        next_theorem = (
            "RETURN_TO_COLLISION_NORMALIZED_STIFFNESS_DEFECT_AND_TUBE_OSCILLATION"
        )
    else:
        verdict = (
            "FINAL_CUTOFF_HYPOTHESES_FAIL_PROSPECTIVE_ARITHMETIC_HOLDOUT"
        )
        next_theorem = (
            "DO_NOT_EXTRAPOLATE_V411_V392_CONSTANTS; LOCALIZE_FIRST_FAILURE"
        )

    print("\n" + "=" * 238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print("FAILED GATES                             :", failed if failed else "NONE")
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT PROVED — THIS IS A PROSPECTIVE FINITE ZERO-FREE TEST OF THE FINAL THEOREM HYPOTHESES",
    )
    print("=" * 238)

    prefix = Path(args.prefix)
    detail_path = Path(str(prefix) + "_DETAIL.csv")
    perk_path = Path(str(prefix) + "_PER_K_FREEZE_HOLDOUT.csv")
    anchor_path = Path(str(prefix) + "_ANCHOR_SUMMARY.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_NEXT_THEOREM.md")

    df.to_csv(detail_path, index=False)
    pk.to_csv(perk_path, index=False)
    anchor_df.to_csv(anchor_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "roots_solved_at_transfer_Y": False,
            "finite_scan_accepted_as_proof": False,
        },
        "inputs": {
            "roots_csv": str(roots_path),
            "v71_module": args.v71_module,
            "anchors": anchors,
            "development_anchors": development_anchors,
            "holdout_anchor": holdout_anchor,
            "y_fractions": y_fracs,
            "common_modes": common,
            "max_arithmetic_Y": maxY,
        },
        "freeze": {
            "transfer_safety": args.transfer_safety,
            "slope_safety": args.slope_safety,
            "global_development_transfer_max": global_dev_transfer_max,
            "global_frozen_transfer_cap": global_transfer_cap,
            "global_development_slope_min": global_dev_slope_min,
            "global_frozen_slope_floor": global_slope_floor,
        },
        "holdout": {
            "maximum_scaled_lock_transfer": global_hold_transfer_max,
            "minimum_transfer_tube_slope_over_logX": global_hold_slope_min,
            "global_transfer_pass": global_transfer_pass,
            "global_slope_pass": global_slope_pass,
            "every_fixed_k_transfer_pass": per_k_transfer_pass,
            "every_fixed_k_slope_pass": per_k_slope_pass,
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time() - started,
        "proof_status": (
            "Prospective finite arithmetic holdout of the exact v411/v392 "
            "hypotheses. No zero data or transfer-Y roots are used. A PASS "
            "supports the scale and mechanism but does not establish the "
            "all-X theorem."
        ),
    }

    summary_path.write_text(
        json.dumps(summary, indent=2, default=native),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v412 — direct final-hypothesis holdout

The exact quantities tested are

`C_(k,X)(Y) = log(X) |F_Y(E_(k,X))-F_X(E_(k,X))|`

and

`c_(k,X)(Y) = min_(transfer tube) F'_Y(E)/log(X)`.

No root at `Y` is used.

Development anchors: `{development_anchors}`

Prospective holdout anchor: `{holdout_anchor}`

Frozen global transfer cap:
`{global_transfer_cap:.16e}`

Prospective holdout maximum:
`{global_hold_transfer_max:.16e}`

Frozen global slope floor:
`{global_slope_floor:.16e}`

Prospective holdout minimum:
`{global_hold_slope_min:.16e}`

Verdict:
`{verdict}`

A PASS is finite zero-free evidence that the exact v411/v392 theorem
hypotheses have the correct scale.  It is not an all-X proof.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", detail_path)
    print(" ", perk_path)
    print(" ", anchor_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
