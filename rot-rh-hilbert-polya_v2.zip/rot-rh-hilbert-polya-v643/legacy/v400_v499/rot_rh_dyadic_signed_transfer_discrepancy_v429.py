#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v429 — DYADIC SIGNED TRANSFER / CENTERED CHEBYSHEV DISCREPANCY REDUCTION
===============================================================================

Goal
----
Attack the exact fixed-energy short-window transfer theorem

    Delta_h F_L(E) := F_(L+h)(E) - F_L(E),
    h = log 2,

for the zero-free v71 Riesz/PNT-centered phase.

The exact cutoff generator from v414 is

    partial_L F_L(E) = -C0(L,E)/L^2,

where

    C0(L,E)
      = sum_(n<e^L) Lambda(n)/sqrt(n) sin(E log n)
        - integral_2^(e^L) t^(-1/2) sin(E log t) dt.

Hence

    Delta_h F_L(E)
      = - integral_L^(L+h) C0(s,E)/s^2 ds.

Swap the s integral with the centered Chebyshev/Stieltjes measure

    dDelta_psi(u)
      = sum_n Lambda(n) delta_(log n)(du) - e^u du.

This gives EXACTLY

    Delta_h F_L(E)
      = - integral_(log2)^(L+h)
          K_(L,h)(u) e^(-u/2) sin(Eu) dDelta_psi(u),

with

    K_(L,h)(u) =
      1/L - 1/(L+h),            log2 <= u <= L,
      1/u - 1/(L+h),            L < u <= L+h.

K is continuous at u=L and K(L+h)=0.

Now remove the fixed n=2 atom.  Define

    A(u)
      = psi(e^u) - log(2) - (e^u - 2),

with the right-continuous convention and A(log2)=0.  Put

    q(u) = K_(L,h)(u) e^(-u/2) sin(Eu).

Stieltjes integration by parts gives

    Delta_h F_L(E)
      = -log(2) q(log2)
        + integral_(log2)^(L+h) A(u) q'(u) du.

The upper endpoint is ZERO because q(L+h)=0.
The lower endpoint is explicit:

    |log(2) q(log2)|
      <= log(2) * h / [sqrt(2) L(L+h)]
      = O(L^-2).

Therefore the missing O(1/L) short-window transfer theorem is reduced to
ONE centered prime-discrepancy functional:

    D_(L,h)(E)
      := integral_(log2)^(L+h) A(u) q'(u) du.

It is sufficient to prove, uniformly on the eventual fixed-k tube,

    sup | L * D_(L,log2)(E) | < infinity.

Then

    Delta_h F_L(E) = O_k(1/L),

which is exactly the signed short-window transfer required by v411.  Combined
with linear transversality/no-fold, fixed-mode cutoff removal follows.

What this script does
---------------------
1. Proves/checks the exact kernel algebra symbolically.
2. Reuses v424 fixed-mode shell/tube locations; NO new roots are solved.
3. Evaluates Delta_h F by the one-pass centered kernel formula.
4. On a small preregistered subset, independently checks against literal
   endpoint phases F_(2X)(E)-F_X(E).
5. Isolates:
      lower_endpoint = -log(2) q(log2),
      discrepancy_functional = Delta_h F - lower_endpoint,
      scaled_discrepancy = L * discrepancy_functional.
6. Performs a development/holdout finite diagnostic on the scaled functional.
   This is evidence only, never proof.
7. Writes the exact theorem target/certificate for the remaining all-L bound.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO new root solves.
NO cutoff larger than the supplied v424 shell data.
NO finite PASS is accepted as proof.

Version: 429
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import inspect
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 429
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def json_safe(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, Path):
        return str(x)
    raise TypeError(type(x).__name__)


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def sha256_file(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists():
        return None
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def phase_energy_col(df: pd.DataFrame) -> str:
    for c in ("E_start", "energy", "E", "root", "root_energy"):
        if c in df.columns:
            return c
    raise KeyError("No shell start energy column found.")


# -----------------------------------------------------------------------------
# Exact symbolic reductions
# -----------------------------------------------------------------------------

def symbolic_reductions() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": f"sympy unavailable: {exc}",
        }

    L, h, u, E = sp.symbols(
        "L h u E",
        positive=True,
        real=True,
    )

    b = L + h
    Kold = 1/L - 1/b
    Knew = 1/u - 1/b

    # Kernel continuity at u=L.
    continuity = sp.simplify(Knew.subs(u, L) - Kold)

    # Kernel zero at the upper endpoint.
    upper_zero = sp.simplify(Knew.subs(u, b))

    # Swapped-integral kernel identities.
    s = sp.symbols("s", positive=True, real=True)
    old_integral = sp.simplify(sp.integrate(s**-2, (s, L, b)) - Kold)
    new_integral = sp.simplify(sp.integrate(s**-2, (s, u, b)) - Knew)

    # q' on the two pieces.
    g = sp.exp(-u/2) * sp.sin(E*u)
    gp = sp.diff(g, u)
    qold = sp.simplify(Kold*g)
    qnew = sp.simplify(Knew*g)
    qoldp = sp.simplify(sp.diff(qold, u))
    qnewp = sp.simplify(sp.diff(qnew, u))

    expected_gp = sp.exp(-u/2) * (
        E*sp.cos(E*u) - sp.Rational(1, 2)*sp.sin(E*u)
    )
    gp_resid = sp.simplify(gp - expected_gp)

    expected_qnewp = sp.exp(-u/2) * (
        Knew * (
            E*sp.cos(E*u)
            - sp.Rational(1, 2)*sp.sin(E*u)
        )
        - sp.sin(E*u)/u**2
    )
    qnew_resid = sp.simplify(qnewp - expected_qnewp)

    # Fixed lower endpoint scale for h=log 2:
    # |log2*q(log2)| <= log2*h/(sqrt2*L*(L+h)).
    # We record the algebraic L^2-scaled limit.
    a, ell = sp.symbols("a ell", positive=True, real=True)
    lower_majorant = ell*h/(sp.sqrt(2)*L*(L+h))
    scaled_limit = sp.simplify(
        sp.limit(L**2 * lower_majorant, L, sp.oo)
    )

    return {
        "kernel_continuity_residual": str(continuity),
        "upper_endpoint_kernel": str(upper_zero),
        "old_support_swap_residual": str(old_integral),
        "new_shell_swap_residual": str(new_integral),
        "gprime_residual": str(gp_resid),
        "qold_prime": str(qoldp),
        "qnew_prime": str(qnewp),
        "qnew_prime_residual": str(qnew_resid),
        "lower_endpoint_L2_scaled_limit_general": str(scaled_limit),
        "pass": bool(
            continuity == 0
            and upper_zero == 0
            and old_integral == 0
            and new_integral == 0
            and gp_resid == 0
            and qnew_resid == 0
        ),
    }


def call_trig_sum(
    base,
    energies: np.ndarray,
    logs: np.ndarray,
    weights: np.ndarray,
    trig: str,
    *,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    """
    Compatibility wrapper across ROT-RH trig_sum revisions.

    The current v71 accepts e_chunk and term_chunk.  Older helper copies may
    expose only the four positional arguments.  Inspect the signature and pass
    only supported tuning keywords.
    """
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}

    try:
        return np.asarray(
            fn(energies, logs, weights, trig, **kwargs),
            float,
        )
    except TypeError:
        # Last-resort compatibility for legacy local copies.
        return np.asarray(
            fn(energies, logs, weights, trig),
            float,
        )


# -----------------------------------------------------------------------------
# Cached arithmetic
# -----------------------------------------------------------------------------

@dataclass
class PrimePowerCache:
    logs: np.ndarray
    exponents: np.ndarray
    base_weight: np.ndarray
    generator_weight: np.ndarray
    lambda_weight: np.ndarray
    lambda_cumsum: np.ndarray
    max_cutoff: int


def build_cache(base, primes: np.ndarray, max_cutoff: int) -> PrimePowerCache:
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)

    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    base_weight = np.exp(-0.5*logs) / exponents
    generator_weight = base_weight * logs
    lambda_weight = logs / exponents
    lambda_cumsum = np.cumsum(lambda_weight, dtype=np.float64)

    return PrimePowerCache(
        logs=logs,
        exponents=exponents,
        base_weight=base_weight,
        generator_weight=generator_weight,
        lambda_weight=lambda_weight,
        lambda_cumsum=lambda_cumsum,
        max_cutoff=int(max_cutoff),
    )


def support_count(cache: PrimePowerCache, L: float) -> int:
    # v71/v424 convention: log n < log X - 1e-14.
    return int(
        np.searchsorted(
            cache.logs,
            float(L) - 1.0e-14,
            side="left",
        )
    )


def kernel_weights(
    logs: np.ndarray,
    L0: float,
    L1: float,
) -> np.ndarray:
    c = 1.0/L0 - 1.0/L1
    out = np.where(
        logs <= L0,
        c,
        1.0/logs - 1.0/L1,
    )
    # Any atom exactly at the upper endpoint has zero kernel and is harmless.
    return out


def centered_kernel_transfer(
    *,
    base,
    cache: PrimePowerCache,
    X0: int,
    X1: int,
    energies: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> Dict[str, np.ndarray]:
    """
    Exact one-pass fixed-energy dyadic transfer.

    Delta F = - prime_kernel + smooth_kernel,

    where prime_kernel is the swapped integral of the prime-power generator
    and smooth_kernel = M_X1^R - M_X0^R.
    """
    L0 = math.log(float(X0))
    L1 = math.log(float(X1))
    k1 = support_count(cache, L1)

    logs = cache.logs[:k1]
    genw = cache.generator_weight[:k1]
    K = kernel_weights(logs, L0, L1)

    prime_kernel = call_trig_sum(
        base,
        np.asarray(energies, float),
        logs,
        genw*K,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )

    smooth_kernel = np.asarray(
        base.riesz_pnt_main(energies, int(X1))
        - base.riesz_pnt_main(energies, int(X0)),
        float,
    )

    centered_generator_integral = prime_kernel - smooth_kernel
    deltaF = -centered_generator_integral

    return {
        "deltaF": deltaF,
        "prime_kernel": prime_kernel,
        "smooth_kernel": smooth_kernel,
        "centered_generator_integral": centered_generator_integral,
    }


def literal_phase(
    *,
    base,
    cache: PrimePowerCache,
    X: int,
    energies: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L = math.log(float(X))
    k = support_count(cache, L)
    logs = cache.logs[:k]
    weights = cache.base_weight[:k] * (1.0 - logs/L)

    return (
        np.asarray(base.theta(energies), float)
        - call_trig_sum(
            base,
            np.asarray(energies, float),
            logs,
            weights,
            "sin",
            energy_chunk=energy_chunk,
            term_chunk=term_chunk,
        )
        + np.asarray(base.riesz_pnt_main(energies, int(X)), float)
    )


def discrepancy_at_L(
    cache: PrimePowerCache,
    X: int,
) -> float:
    """
    A(L) = psi(X-) - log 2 - (X-2),
    matching the strict n<X support convention.

    This is diagnostic only; the theorem object is the integral functional,
    not the pointwise discrepancy.
    """
    L = math.log(float(X))
    k = support_count(cache, L)
    psi_minus = (
        float(cache.lambda_cumsum[k-1])
        if k > 0
        else 0.0
    )
    return psi_minus - LOG2 - (float(X) - 2.0)


# -----------------------------------------------------------------------------
# v424 shell/tube locations
# -----------------------------------------------------------------------------

def load_shell_groups(
    path: str,
    max_modes: int,
) -> List[Dict[str, Any]]:
    df = pd.read_csv(path)
    required = {
        "root_index",
        "L_start",
        "L_end",
        "E_start",
    }
    missing = sorted(required - set(df.columns))
    if missing:
        raise KeyError(
            f"v424 shells missing columns: {missing}"
        )

    if "anchor" not in df.columns:
        df["anchor"] = np.rint(np.exp(df["L_start"])).astype(np.int64)
    if "endpoint_cutoff" not in df.columns:
        df["endpoint_cutoff"] = np.rint(np.exp(df["L_end"])).astype(np.int64)
    if "set" not in df.columns:
        df["set"] = "unknown"
    if "shell_index" not in df.columns:
        # Stable deterministic ordering by L_start.
        starts = {
            x: i
            for i, x in enumerate(
                sorted(df["L_start"].astype(float).unique())
            )
        }
        df["shell_index"] = df["L_start"].astype(float).map(starts)

    if max_modes > 0:
        df = df[df["root_index"].astype(int) <= int(max_modes)].copy()

    groups = []
    keycols = [
        "set",
        "shell_index",
        "anchor",
        "endpoint_cutoff",
        "L_start",
        "L_end",
    ]
    for key, g in df.groupby(keycols, sort=True, dropna=False):
        g = g.sort_values("root_index")
        groups.append({
            "set": str(key[0]),
            "shell_index": int(key[1]),
            "X0": int(key[2]),
            "X1": int(key[3]),
            "L0": float(key[4]),
            "L1": float(key[5]),
            "rows": g,
        })
    return groups


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v424-shells",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SHELLS.csv",
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )
    ap.add_argument(
        "--v411-summary",
        default="rot_rh_collective_phase_lock_v411_SUMMARY.json",
    )
    ap.add_argument(
        "--v414-summary",
        default="rot_rh_riesz_cutoff_generator_v414_SUMMARY.json",
    )
    ap.add_argument(
        "--v428-summary",
        default="rot_rh_fixed_mode_cutoff_removal_v428_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )

    ap.add_argument(
        "--tube-coordinates",
        default="-0.20,0,0.20",
        help="Fixed-energy offsets c/L0 about each v424 shell-start root.",
    )
    ap.add_argument("--max-modes", type=int, default=12)
    ap.add_argument(
        "--energy-chunk",
        type=int,
        default=6,
        help="Small trig_sum energy chunk to limit RAM.",
    )
    ap.add_argument(
        "--term-chunk",
        type=int,
        default=200000,
        help="Prime-power term chunk for trig_sum; tuned for speed without large RAM spikes.",
    )
    ap.add_argument(
        "--direct-check-modes",
        type=int,
        default=3,
        help="Literal endpoint-phase check for first N modes at tube coordinate 0.",
    )
    ap.add_argument(
        "--maximum-direct-check-absolute",
        type=float,
        default=2.0e-9,
    )
    ap.add_argument(
        "--maximum-direct-check-relative",
        type=float,
        default=2.0e-7,
    )
    ap.add_argument(
        "--development-cap-safety",
        type=float,
        default=1.25,
        help="Finite diagnostic only; never treated as proof.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_dyadic_signed_transfer_discrepancy_v429",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.time()

    if args.energy_chunk < 1:
        raise ValueError("--energy-chunk must be >=1")
    if args.term_chunk < 1:
        raise ValueError("--term-chunk must be >=1")
    if args.max_modes < 1:
        raise ValueError("--max-modes must be >=1")
    if args.development_cap_safety <= 1:
        raise ValueError("--development-cap-safety must be >1")

    coords = sorted(set(parse_floats(args.tube_coordinates)))
    if not coords:
        raise ValueError("--tube-coordinates is empty")
    if 0.0 not in coords:
        coords.append(0.0)
        coords = sorted(coords)

    v424 = load_json(args.v424_summary)
    v411 = load_json(args.v411_summary)
    v414 = load_json(args.v414_summary)
    v428 = load_json(args.v428_summary)

    upstream = {
        "v424": {
            "available": v424 is not None,
            "verdict": None if v424 is None else v424.get("verdict"),
            "pass": bool(
                v424 is not None
                and v424.get("verdict")
                == "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS"
            ),
        },
        "v411": {
            "available": v411 is not None,
            "verdict": None if v411 is None else v411.get("verdict"),
            "pass": bool(
                v411 is not None
                and v411.get("verdict")
                == "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS"
            ),
        },
        "v414": {
            "available": v414 is not None,
            "verdict": None if v414 is None else v414.get("verdict"),
            # v414 verdict names varied across branches; availability is lineage
            # context only. Its exact generator algebra is rederived below.
            "pass": None,
        },
        "v428": {
            "available": v428 is not None,
            "verdict": None if v428 is None else v428.get("verdict"),
            "fixed_mode_proved": bool(
                v428 is not None
                and v428.get("fixed_mode_cutoff_removal_proved") is True
            ),
        },
    }

    print("=" * 230)
    print("ROT-RH v429 — DYADIC SIGNED TRANSFER / CENTERED CHEBYSHEV DISCREPANCY REDUCTION")
    print("=" * 230)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff than v424                   : NONE")
    print("finite pass accepted as proof             : NO")
    print("shell width target                        : h=log(2)")
    print("tube coordinates c/L                      :", coords)
    print("=" * 230)

    print("[1] Upstream")
    for name, rec in upstream.items():
        print(
            f"{name:8s} available={str(rec['available']):5s} "
            f"verdict={rec['verdict']}"
        )

    print("\n[2] Exact symbolic dyadic-transfer reduction")
    symbolic = symbolic_reductions()
    print("kernel / summation-by-parts identities pass :", symbolic.get("pass"))
    if not symbolic.get("pass"):
        print("symbolic details                            :", symbolic)
        if args.strict:
            return 2

    groups = load_shell_groups(
        args.v424_shells,
        args.max_modes,
    )
    if not groups:
        raise RuntimeError("No v424 shell groups found.")

    max_cutoff = max(g["X1"] for g in groups)
    base = importlib.import_module(args.v71_module)

    print("\n[3] Cached zero-free arithmetic")
    print("shell groups                              :", len(groups))
    print("maximum reused cutoff                    :", f"{max_cutoff:,}")

    t0 = time.time()
    primes = base.sieve_primes(int(max_cutoff))
    cache = build_cache(base, primes, int(max_cutoff))
    print("primes <= max cutoff                     :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(cache.logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    point_rows: List[dict] = []
    direct_rows: List[dict] = []
    shell_rows: List[dict] = []

    direct_abs_residuals: List[float] = []
    direct_rel_residuals: List[float] = []

    bar = tqdm(
        total=len(groups),
        desc="dyadic discrepancy shells",
        unit="shell",
    )

    for shell in groups:
        X0 = int(shell["X0"])
        X1 = int(shell["X1"])
        L0 = math.log(float(X0))
        L1 = math.log(float(X1))
        h = L1 - L0

        # The proof target is specifically dyadic h=log2.  The kernel remains
        # exact for any supplied h; report the deviation rather than silently
        # modifying the data.
        dyadic_h_error = abs(h - LOG2)

        sdf = shell["rows"].sort_values("root_index")
        root_index = sdf["root_index"].to_numpy(int)
        E0 = sdf["E_start"].to_numpy(float)

        energies = []
        metadata = []
        for k, e in zip(root_index, E0):
            for c in coords:
                energies.append(float(e + c/L0))
                metadata.append((int(k), float(e), float(c)))
        energies = np.asarray(energies, float)

        trans = centered_kernel_transfer(
            base=base,
            cache=cache,
            X0=X0,
            X1=X1,
            energies=energies,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        deltaF = np.asarray(trans["deltaF"], float)

        # Exact Stieltjes integration-by-parts endpoint.
        ckernel = 1.0/L0 - 1.0/L1
        q_a = (
            ckernel
            * math.exp(-0.5*LOG2)
            * np.sin(energies*LOG2)
        )
        lower_endpoint = -LOG2*q_a
        upper_endpoint = np.zeros_like(lower_endpoint)

        # Exact isolated discrepancy functional from
        # DeltaF = lower_endpoint + D.
        discrepancy_functional = deltaF - lower_endpoint
        scaled_discrepancy = L0*discrepancy_functional
        scaled_transfer = L0*deltaF

        A_L = discrepancy_at_L(cache, X0)

        for i, (k, ecenter, coord) in enumerate(metadata):
            point_rows.append({
                "set": shell["set"],
                "shell_index": shell["shell_index"],
                "X0": X0,
                "X1": X1,
                "L0": L0,
                "L1": L1,
                "h": h,
                "dyadic_h_error": dyadic_h_error,
                "root_index": k,
                "E_center": ecenter,
                "tube_coordinate": coord,
                "E_fixed": float(energies[i]),
                "deltaF_kernel": float(deltaF[i]),
                "prime_kernel": float(trans["prime_kernel"][i]),
                "smooth_kernel": float(trans["smooth_kernel"][i]),
                "lower_endpoint": float(lower_endpoint[i]),
                "upper_endpoint": float(upper_endpoint[i]),
                "discrepancy_functional": float(discrepancy_functional[i]),
                "scaled_discrepancy_LD": float(scaled_discrepancy[i]),
                "scaled_transfer_LDeltaF": float(scaled_transfer[i]),
                "A_at_L": float(A_L),
                "A_at_L_over_sqrtX": float(A_L/math.sqrt(float(X0))),
            })

        # Independent literal phase check on a small preregistered central set.
        ncheck = min(
            int(args.direct_check_modes),
            len(E0),
        )
        if ncheck > 0:
            Echeck = E0[:ncheck]
            p0 = literal_phase(
                base=base,
                cache=cache,
                X=X0,
                energies=Echeck,
                energy_chunk=args.energy_chunk,
                term_chunk=args.term_chunk,
            )
            p1 = literal_phase(
                base=base,
                cache=cache,
                X=X1,
                energies=Echeck,
                energy_chunk=args.energy_chunk,
                term_chunk=args.term_chunk,
            )
            literal_delta = p1-p0

            # Locate tube-coordinate 0 kernel values for the checked modes.
            kernel_central = []
            for j in range(ncheck):
                # metadata ordering is mode-major, coordinate-minor.
                idx = next(
                    ii for ii, (kk, _, cc) in enumerate(metadata)
                    if kk == int(root_index[j]) and abs(cc) <= 1e-15
                )
                kernel_central.append(deltaF[idx])
            kernel_central = np.asarray(kernel_central, float)

            absr = np.abs(literal_delta-kernel_central)
            relr = absr/np.maximum(
                np.abs(literal_delta),
                1.0e-12,
            )
            direct_abs_residuals.extend(absr.tolist())
            direct_rel_residuals.extend(relr.tolist())

            for j in range(ncheck):
                direct_rows.append({
                    "set": shell["set"],
                    "shell_index": shell["shell_index"],
                    "X0": X0,
                    "X1": X1,
                    "root_index": int(root_index[j]),
                    "E_fixed": float(Echeck[j]),
                    "literal_endpoint_deltaF": float(literal_delta[j]),
                    "kernel_deltaF": float(kernel_central[j]),
                    "absolute_residual": float(absr[j]),
                    "relative_residual": float(relr[j]),
                })

        mask_shell = np.asarray([
            row["shell_index"] == shell["shell_index"]
            and row["X0"] == X0
            for row in point_rows
        ], dtype=bool)
        # Simpler summary from current arrays, not dataframe reconstruction.
        shell_rows.append({
            "set": shell["set"],
            "shell_index": shell["shell_index"],
            "X0": X0,
            "X1": X1,
            "L0": L0,
            "L1": L1,
            "h": h,
            "dyadic_h_error": dyadic_h_error,
            "modes": int(len(E0)),
            "tube_points": int(len(energies)),
            "max_abs_deltaF": float(np.max(np.abs(deltaF))),
            "max_abs_scaled_transfer": float(np.max(np.abs(scaled_transfer))),
            "max_abs_lower_endpoint": float(np.max(np.abs(lower_endpoint))),
            "max_abs_L2_lower_endpoint": float(
                np.max(np.abs((L0*L0)*lower_endpoint))
            ),
            "max_abs_discrepancy_functional": float(
                np.max(np.abs(discrepancy_functional))
            ),
            "max_abs_scaled_discrepancy": float(
                np.max(np.abs(scaled_discrepancy))
            ),
            "median_abs_scaled_discrepancy": float(
                np.median(np.abs(scaled_discrepancy))
            ),
            "A_at_L": float(A_L),
            "A_at_L_over_sqrtX": float(A_L/math.sqrt(float(X0))),
        })

        bar.update(1)

    bar.close()

    point_df = pd.DataFrame(point_rows)
    direct_df = pd.DataFrame(direct_rows)
    shell_df = pd.DataFrame(shell_rows).sort_values(
        ["L0", "shell_index"]
    )

    max_direct_abs = (
        float(np.max(direct_abs_residuals))
        if direct_abs_residuals
        else float("nan")
    )
    max_direct_rel = (
        float(np.max(direct_rel_residuals))
        if direct_rel_residuals
        else float("nan")
    )
    direct_pass = bool(
        direct_abs_residuals
        and max_direct_abs <= args.maximum_direct_check_absolute
        and max_direct_rel <= args.maximum_direct_check_relative
    )

    # Finite development/holdout diagnostic only.
    if "set" in shell_df.columns:
        dev = shell_df[shell_df["set"].str.lower() == "development"].copy()
        hold = shell_df[shell_df["set"].str.lower() != "development"].copy()
    else:
        dev = shell_df.iloc[:1].copy()
        hold = shell_df.iloc[1:].copy()

    if dev.empty:
        # Deterministic fallback: first shell is development only for the
        # finite diagnostic.  This does not affect the theorem reduction.
        dev = shell_df.iloc[:1].copy()
        hold = shell_df.iloc[1:].copy()

    dev_max = float(dev["max_abs_scaled_discrepancy"].max())
    frozen_cap = args.development_cap_safety * dev_max
    hold_max = (
        float(hold["max_abs_scaled_discrepancy"].max())
        if not hold.empty
        else float("nan")
    )
    holdout_finite_pass = bool(
        not hold.empty
        and math.isfinite(hold_max)
        and hold_max <= frozen_cap
    )

    max_h_error = float(shell_df["dyadic_h_error"].max())
    dyadic_data_pass = bool(max_h_error <= 5.0e-12)

    exact_reduction_pass = bool(
        symbolic.get("pass")
        and dyadic_data_pass
        and direct_pass
    )

    print("\n[4] Independent endpoint-phase check")
    print(
        "maximum absolute kernel/direct residual :",
        f"{max_direct_abs:.12e}",
    )
    print(
        "maximum relative kernel/direct residual :",
        f"{max_direct_rel:.12e}",
    )
    print("direct endpoint reconstruction pass      :", direct_pass)

    print("\n[5] Isolated centered Chebyshev functional")
    print(
        "maximum |h-log2|                        :",
        f"{max_h_error:.12e}",
    )
    print(
        "development max |L*D|                   :",
        f"{dev_max:.12e}",
    )
    print(
        "frozen finite diagnostic cap            :",
        f"{frozen_cap:.12e}",
    )
    print(
        "holdout max |L*D|                       :",
        f"{hold_max:.12e}",
    )
    print(
        "finite holdout diagnostic pass          :",
        holdout_finite_pass,
    )
    print(
        "IMPORTANT                               : finite |L*D| stability is NOT proof"
    )

    print("\nShell summary:")
    show_cols = [
        "set",
        "shell_index",
        "X0",
        "X1",
        "max_abs_scaled_transfer",
        "max_abs_L2_lower_endpoint",
        "max_abs_scaled_discrepancy",
        "A_at_L_over_sqrtX",
    ]
    print(
        shell_df[show_cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    verdict = (
        "EXACT_DYADIC_SIGNED_TRANSFER_CHEBYSHEV_DISCREPANCY_REDUCTION_PASS"
        if exact_reduction_pass
        else
        "DYADIC_SIGNED_TRANSFER_DISCREPANCY_REDUCTION_INCOMPLETE"
    )
    next_theorem = (
        "PROVE_UNIFORM_BOUNDED_SCALED_CENTERED_CHEBYSHEV_DYADIC_FUNCTIONAL_AND_TRANSVERSALITY"
    )

    print("\n" + "=" * 230)
    print("VERDICT                                   :", verdict)
    print(
        "EXACT TRANSFER REDUCTION                  :",
        "PROVED" if exact_reduction_pass else "INCOMPLETE",
    )
    print(
        "SINGLE REMAINING TRANSFER FUNCTIONAL      :",
        "sup_(E in fixed-k tube) |L * integral A(u) q'(u) du|",
    )
    print(
        "LOWER ENDPOINT                            :",
        "EXPLICIT O(L^-2)",
    )
    print(
        "UPPER ENDPOINT                            :",
        "EXACTLY ZERO",
    )
    print(
        "FIXED-MODE CUTOFF REMOVAL                 :",
        "NOT PROVED BY v429",
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 230)

    prefix = Path(args.prefix)
    points_path = Path(str(prefix) + "_POINTS.csv.gz")
    direct_path = Path(str(prefix) + "_DIRECT_CHECK.csv")
    shell_path = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    point_df.to_csv(
        points_path,
        index=False,
        compression="gzip",
    )
    direct_df.to_csv(
        direct_path,
        index=False,
    )
    shell_df.to_csv(
        shell_path,
        index=False,
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v424": False,
            "finite_pass_accepted_as_proof": False,
        },
        "upstream": upstream,
        "inputs": {
            "v424_shells": args.v424_shells,
            "v424_shells_sha256": sha256_file(args.v424_shells),
            "v71_module": args.v71_module,
            "tube_coordinates": coords,
            "max_modes": args.max_modes,
            "energy_chunk": args.energy_chunk,
            "term_chunk": args.term_chunk,
        },
        "exact_symbolic_reduction": symbolic,
        "direct_check": {
            "modes_per_shell": args.direct_check_modes,
            "maximum_absolute_residual": max_direct_abs,
            "maximum_relative_residual": max_direct_rel,
            "absolute_tolerance": args.maximum_direct_check_absolute,
            "relative_tolerance": args.maximum_direct_check_relative,
            "pass": direct_pass,
        },
        "dyadic_data": {
            "maximum_abs_h_minus_log2": max_h_error,
            "pass": dyadic_data_pass,
        },
        "finite_diagnostic": {
            "development_max_abs_scaled_discrepancy": dev_max,
            "safety": args.development_cap_safety,
            "frozen_cap": frozen_cap,
            "holdout_max_abs_scaled_discrepancy": hold_max,
            "holdout_pass": holdout_finite_pass,
            "proof_status": "EVIDENCE_ONLY",
        },
        "exact_theorem_reduction": {
            "A_definition": (
                "A(u)=psi(e^u)-log(2)-(e^u-2), with A(log2)=0"
            ),
            "K_definition": (
                "K=1/L-1/(L+h) for u<=L; "
                "K=1/u-1/(L+h) for L<u<=L+h"
            ),
            "q_definition": "q=K*exp(-u/2)*sin(Eu)",
            "identity": (
                "Delta_h F_L(E) = -log(2)*q(log2) "
                "+ integral_(log2)^(L+h) A(u) q'(u) du"
            ),
            "lower_endpoint": "O(L^-2) explicitly",
            "upper_endpoint": "0 exactly",
            "single_transfer_target": (
                "sup_(E in I_k) |L * integral A(u)q'(u)du| <= C_k"
            ),
            "consequence": (
                "Delta_h F_L(E)=O_k(1/L); with linear transversality, "
                "v411 gives summable fixed-mode root motion"
            ),
        },
        "exact_reduction_pass": exact_reduction_pass,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
        "outputs": {
            "points": str(points_path),
            "direct_check": str(direct_path),
            "shell_summary": str(shell_path),
            "summary": str(summary_path),
            "theorem": str(theorem_path),
            "certificate": str(cert_path),
        },
    }

    summary_path.write_text(
        json.dumps(payload, indent=2, default=json_safe),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v429 — exact dyadic signed-transfer discrepancy theorem

Let

`h=log 2`, `b=L+h`,

and let the centered logarithmic Chebyshev measure be

`dDelta_psi(u)=sum_n Lambda(n) delta_(log n)(du)-e^u du`.

The exact v414 generator is

`partial_L F_L(E)=-C0(L,E)/L^2`

with

`C0(L,E)=int_(log2)^L e^(-u/2)sin(Eu)dDelta_psi(u)`.

Therefore

`Delta_h F_L(E)=F_(L+h)(E)-F_L(E)
               =-int_L^(L+h) C0(s,E)/s^2 ds`.

By Fubini/Stieltjes exchange,

`Delta_h F_L(E)
 =-int_(log2)^(L+h)
    K_(L,h)(u)e^(-u/2)sin(Eu)dDelta_psi(u)`,

where

`K_(L,h)(u)=1/L-1/(L+h)` for `u<=L`,

and

`K_(L,h)(u)=1/u-1/(L+h)` for `L<u<=L+h`.

The kernel is continuous at `u=L` and satisfies

`K_(L,h)(L+h)=0`.

Remove the fixed atom at `n=2` and define

`A(u)=psi(e^u)-log(2)-(e^u-2)`,

so `A(log2)=0`.

Put

`q(u)=K_(L,h)(u)e^(-u/2)sin(Eu)`.

Then Stieltjes integration by parts gives exactly

`Delta_h F_L(E)
 =-log(2) q(log2)
  +int_(log2)^(L+h) A(u)q'(u)du`.

There is no upper endpoint term because `q(L+h)=0`.

The lower endpoint satisfies

`|log(2)q(log2)|
 <= log(2)h/[sqrt(2)L(L+h)]
 =O(L^-2)`.

The derivative kernel is explicit:

For `u<L`,

`q'(u)
 =(1/L-1/(L+h)) e^(-u/2)
   [E cos(Eu)-(1/2)sin(Eu)]`.

For `L<u<L+h`,

`q'(u)
 =e^(-u/2){
   (1/u-1/(L+h))[E cos(Eu)-(1/2)sin(Eu)]
   -sin(Eu)/u^2
 }`.

Hence the fixed-energy signed-transfer theorem is reduced to the SINGLE
centered prime-discrepancy functional

`D_(L,h)(E)
 =int_(log2)^(L+h) A(u)q'(u)du`.

A sufficient all-L theorem is

`sup_(E in I_k) |L D_(L,log2)(E)| <= C_k`

on each eventual fixed-k tube.

Then

`Delta_(log2) F_L(E)=O_k(1/L)`.

The exact v411 collective-lock theorem shows that this short-window transfer,
together with linear transversality `F'_L>=c_k L`, gives summable fixed-mode
root motion and cutoff independence.

The numerical development/holdout values written by v429 are evidence only.
They do not prove the uniform all-L bound.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_DYADIC_CHEBYSHEV_TRANSFER_CERTIFICATE_V1",
        "firewall": {
            "finite_numerics_may_not_set_proved": True,
            "known_zero_ordinates_forbidden": True,
            "Xi_fitting_forbidden": True,
            "RH_assumption_forbidden": True,
        },
        "required_claims": {
            "fixed_mode_tube": {
                "proved": False,
                "statement": (
                    "For each fixed k there is an eventual compact tube I_k "
                    "on which the fixed-energy transfer theorem is uniform."
                ),
            },
            "scaled_centered_chebyshev_functional": {
                "proved": False,
                "statement": (
                    "There exists C_k<infinity such that for all sufficiently "
                    "large L and E in I_k, "
                    "|L*int_(log2)^(L+log2) A(u)q'_(L,E)(u)du|<=C_k."
                ),
                "constant_C_k": None,
            },
            "transversality": {
                "proved": False,
                "statement": (
                    "There exists c_k>0 such that "
                    "F'_L(E)>=c_k L uniformly on the eventual tube."
                ),
                "constant_c_k": None,
            },
        },
        "exact_consequence_when_claims_proved": (
            "Delta_log2 F_L(E)=O_k(1/L); v411 then gives summable "
            "fixed-mode root motion and fixed-mode cutoff removal."
        ),
        "forbidden_shortcuts": [
            "finite cutoff regression",
            "absolute PNT majorant substituted for signed functional",
            "fill certificate from v429 holdout values",
            "known zero ordinates",
            "Xi fitting",
        ],
    }
    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_path)
    print(" ", direct_path)
    print(" ", shell_path)
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not exact_reduction_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
