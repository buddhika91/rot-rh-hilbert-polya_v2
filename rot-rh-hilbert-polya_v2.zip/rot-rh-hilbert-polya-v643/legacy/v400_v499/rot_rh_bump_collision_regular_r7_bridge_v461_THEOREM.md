# ROT-RH v461 — bump-collision / regular-R7 cutoff-independence bridge

## Exact bump identities

For

`p(x)=exp(-(x/(1-x))^2)`, `q(x)=-p'(x)`,

the exact cutoff identity is

`partial_L p(y/L) = y q(y/L)/L^2`.

Moreover `q>=0` and

`int_0^1 q(x) dx = 1`.

## Collision kernel

Let `u=(gamma-E)L` and define

`P_c(u)=int_0^1 p(x) cos(u x) dx`.

For `|u|<=pi/2`, restrict the integral to `0<=x<=1/2`.  There,

`p(x)>=e^-1` and `cos(ux)>=1/sqrt(2)`.

Hence

`P_c(u) >= c_bump = 1/(2 sqrt(2)e) ~= 1.3006502375572221e-01`.

The corresponding wavelet kernel satisfies

`|int_0^1 q(x) sin(ux) dx| <= int_0^1 q(x)dx = 1`.

For a multiplicity-`m` recombined critical collision this gives the local scales

`F_E,coll >= (m c_bump/pi)L`

and

`|F_L,coll| <= m/(pi L)`,

with every high-frequency conjugate term and nonlocal channel assigned to the
regular recombined remainder.

## Regular-remainder theorem

If eventually on the fixed branch tube

`|C_q,reg(L,E)| <= K_q L`

and

`|F_E,reg(L,E)| <= eta (m c_bump/pi)L`, `eta<1`,

then

`|E'(L)| <= [(m+K_q)/((1-eta)m c_bump)] L^-2`.

Therefore `E(L)` converges and the tail is `O(1/L)`.

This is a stronger route than requiring the total bump-wavelet generator to be
`O(L^0.90)` under a merely constant transversality floor.

## G7 head bridge

For

`A_u(M;E)=sum_(n<=M) u_n exp(iElog n)`

and `||u||_pref,E=sup_M |A_u(M;E)|`, discrete Abel summation with

`b_L(n)=log(n)q(log(n)/L)=L f(log(n)/L)`, `f(x)=xq(x)`,

gives

`|<b_L e^(iElog n),u>| <= ||u||_pref,E * L * TV(f)`.

Thus an all-`N` bounded phase-prefix theorem for `G7` gives

`C_q,G7=O(L)`,

which is sufficient in the collision-ratio theorem.

## R7 regular tail

v402 gives the exact beta-2 factorial four-jet contraction

`Qjet = 657981440000000/1853020188851841 ~= 3.5508595316907754e-01 < 1`

and the fixed-prefix packet factor

`rhojet = Qjet/128^2 ~= 2.1672726633854830e-05`.

The remaining bridge is to embed the bump-wavelet test family into this weighted
four-jet geometry.  Its normalized `E`-jets have only overall `O(L)` size, so
the expected regular R7 contribution is also `O(L)` after geometric contraction.

## Multiplicity safety

Do **not** analytically continue singular `G7` and `R^7X` separately.  The
v405/v417 residue bookkeeping is safe only after recombination in the full
fixed point.  v402 is used only for the regular coefficient-space R7 transfer.

## Still open

1. Prove eventual collision capture, or an alternative transversality theorem,
   for each fixed branch.
2. Prove the all-`N` G7 phase-prefix bound needed by the Abel bridge.
3. Prove the beta-2 bump-wavelet embedding / regular R7 remainder bound.
4. Control the regular `F_E` remainder by a strict fraction of the collision
   stiffness.
5. Promote fixed-mode convergence to the infinite operator using the existing
   uniform high-mode tail theorem.

This v461 packet is an analytic reduction.  It is not an RH proof and does not
claim the Fredholm identity.
