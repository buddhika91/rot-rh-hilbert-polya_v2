#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v453 — BUMP-2 FINITE-PART SIGNED DUHAMEL / CANCELLATION AUDIT
=====================================================================

PURPOSE
-------
v452 verified the exact finite-part source-flow identity

    dE_k/dL = -F_L/F_E,   L = log X,

but the training max-envelope did not support absolute integrability.  v453
resolves the flow INSIDE each dyadic interval and asks which mechanism is
actually present:

  (A) absolute source-flow convergence,

        T_{k,j} = int_{L_j}^{L_{j+1}} |dE_k/dL| dL,

      with sum_j T_{k,j} finite; or

  (B) signed / resonance cancellation,

        S_{k,j} = int_{L_j}^{L_{j+1}} dE_k/dL dL
                = E_k(L_{j+1}) - E_k(L_j),

      where |S_{k,j}| is summable even if T_{k,j} is not, while T_{k,j}->0
      controls within-interval excursions.

The script samples an odd number of equally spaced L=log X nodes in each
specified doubling interval and uses composite Simpson integration.  Every
node solves the finite-part roots independently by local continuation and
then evaluates the exact analytic velocity -F_L/F_E.

PROSPECTIVE FIREWALL
--------------------
All intervals ending at the penultimate cutoff are TRAINING.  For each mode,
v453 fits

    |Delta E_{k,j}|   and   T_{k,j}

against the right endpoint cutoff using the two frozen model classes

    C X^-p,    C (log X)^-p.

It then writes and SHA256-freezes all modewise predictions for the final
interval BEFORE evaluating any interior point of that held-out interval.

SCIENTIFIC BOUNDARY
-------------------
No known Riemann zero ordinates, zeta(), Xi(), or xi() are used.  A PASS is
finite prospective evidence for a convergence mechanism.  It is not an
all-L theorem and not an RH proof.

Required local module:
    rot_rh_bump2_finite_part_source_flow_v452.py
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.integrate import simpson
from tqdm import tqdm

VERSION = "2026-08-26-v453-bump2-signed-duhamel-flow"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


def safe_rel(a: float, b: float, floor: float = 1e-12) -> float:
    return abs(float(a)-float(b)) / max(abs(float(a)), abs(float(b)), float(floor))


def sign_changes(values: Sequence[float], zero_tol: float = 1e-14) -> int:
    a = np.asarray(values, float)
    s = np.sign(a[np.abs(a) > zero_tol])
    if len(s) < 2:
        return 0
    return int(np.sum(s[1:] * s[:-1] < 0))


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py in the same directory as v453, "
            "or pass --v452-module."
        )


def json_safe(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return [json_safe(x) for x in obj.tolist()]
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(x) for x in obj]
    return obj


# =============================================================================
# Root continuation at one L-node
# =============================================================================

def make_phase(v452, n_all: np.ndarray, lam_all: np.ndarray, X: float,
               pnt_q: int, prime_chunk: int):
    # Exact support restriction: bump2 is identically zero for n >= X.
    idx = int(np.searchsorted(n_all, float(X), side="left"))
    return v452.FinitePartBump2(
        n_all[:idx], lam_all[:idx], float(X), int(pnt_q), int(prime_chunk)
    )


def quantize_silent(v452, phase, modes: Sequence[int], free: np.ndarray,
                    previous: Dict[int, float] | None,
                    root_tol: float, max_newton: int,
                    scan_points: int) -> Dict[int, object]:
    out: Dict[int, object] = {}
    previous_ordered: float | None = None
    for k in modes:
        if previous and int(k) in previous:
            seed = float(previous[int(k)])
        else:
            seed = float(free[int(k)-1])
        if int(k) == 1:
            spacing = float(free[1]-free[0]) if len(free) > 1 else 2.0
        elif int(k) < len(free):
            spacing = 0.5*float(free[int(k)]-free[int(k)-2])
        else:
            spacing = float(free[-1]-free[-2])
        rr = v452.locate_root(
            phase, int(k), seed, spacing, previous_ordered,
            float(root_tol), int(max_newton), int(scan_points)
        )
        out[int(k)] = rr
        if rr.ok:
            previous_ordered = float(rr.root)
    return out


def evaluate_node(v452, n_all: np.ndarray, lam_all: np.ndarray,
                  X: float, modes: Sequence[int], free: np.ndarray,
                  previous: Dict[int, float] | None,
                  pnt_q: int, prime_chunk: int,
                  root_tol: float, max_newton: int,
                  scan_points: int) -> Tuple[object, Dict[int, dict], Dict[int, float]]:
    ph = make_phase(v452, n_all, lam_all, X, pnt_q, prime_chunk)
    roots = quantize_silent(
        v452, ph, modes, free, previous, root_tol, max_newton, scan_points
    )
    bad = [k for k, r in roots.items() if not r.ok]
    if bad:
        raise RuntimeError(f"root certification failed at X={X:.12g}, modes={bad}")

    rows: Dict[int, dict] = {}
    root_map: Dict[int, float] = {}
    for k in modes:
        rr = roots[int(k)]
        E = float(rr.root)
        sv = ph.sources(E)
        fL = -float(sv.finitepart_L)/math.pi
        fE = v452.smooth_count_prime(E) - float(sv.finitepart_E)/math.pi
        flow = -fL/fE
        denom = max(abs(float(sv.prime_L))+abs(float(sv.pnt_L)), 1e-300)
        rows[int(k)] = {
            "E": E,
            "root_residual": float(rr.residual),
            "root_method": rr.reason,
            "F_E": float(fE),
            "F_logX": float(fL),
            "flow": float(flow),
            "prime_logX_source": float(sv.prime_L),
            "pnt_logX_source": float(sv.pnt_L),
            "prime_minus_pnt_source": float(sv.finitepart_L),
            "source_cancellation_ratio": abs(float(sv.finitepart_L))/denom,
        }
        root_map[int(k)] = E
    return ph, rows, root_map


# =============================================================================
# Interval construction and integration
# =============================================================================

def interval_L_nodes(Xa: float, Xb: float, n: int) -> np.ndarray:
    if n < 5 or n % 2 == 0:
        raise ValueError("--nodes-per-doubling must be an odd integer >=5 for Simpson integration")
    return np.linspace(math.log(float(Xa)), math.log(float(Xb)), int(n))


def integrate_interval(node_data: List[Tuple[float, float, Dict[int, dict]]],
                       modes: Sequence[int], Xa: int, Xb: int,
                       stage: str) -> List[dict]:
    L = np.asarray([x[0] for x in node_data], float)
    out: List[dict] = []
    for k in modes:
        E = np.asarray([x[2][int(k)]["E"] for x in node_data], float)
        v = np.asarray([x[2][int(k)]["flow"] for x in node_data], float)
        fL = np.asarray([x[2][int(k)]["F_logX"] for x in node_data], float)
        fE = np.asarray([x[2][int(k)]["F_E"] for x in node_data], float)
        cancel = np.asarray([x[2][int(k)]["source_cancellation_ratio"] for x in node_data], float)

        signed = float(simpson(v, x=L))
        tv = float(simpson(np.abs(v), x=L))
        actual = float(E[-1]-E[0])
        abs_gap = abs(signed-actual)
        rel_gap = safe_rel(signed, actual, 1e-10)
        ratio = tv/max(abs(signed), 1e-15)
        endpoint_ratio = tv/max(abs(actual), 1e-15)
        out.append({
            "stage": stage,
            "Xa": int(Xa), "Xb": int(Xb), "k": int(k),
            "La": fmt(L[0]), "Lb": fmt(L[-1]), "delta_L": fmt(L[-1]-L[0]),
            "E_left": fmt(E[0]), "E_right": fmt(E[-1]),
            "actual_delta_E": fmt(actual),
            "simpson_signed_flow": fmt(signed),
            "duhamel_abs_gap": fmt(abs_gap),
            "duhamel_relative_gap": fmt(rel_gap),
            "total_variation": fmt(tv),
            "variation_to_signed_ratio": fmt(ratio),
            "variation_to_endpoint_ratio": fmt(endpoint_ratio),
            "flow_sign_changes": sign_changes(v),
            "source_sign_changes": sign_changes(fL),
            "max_abs_flow": fmt(float(np.max(np.abs(v)))),
            "max_abs_F_logX": fmt(float(np.max(np.abs(fL)))),
            "min_abs_F_E": fmt(float(np.min(np.abs(fE)))),
            "mean_source_cancellation_ratio": fmt(float(np.mean(cancel))),
            "max_source_cancellation_ratio": fmt(float(np.max(cancel))),
        })
    return out


# =============================================================================
# Decay fits / prospective predictions
# =============================================================================

def mode_fit(v452, train_interval_rows: Sequence[dict], mode: int,
             quantity: str) -> dict:
    rows = [r for r in train_interval_rows if int(r["k"]) == int(mode)]
    X = [float(r["Xb"]) for r in rows]
    if quantity == "increment":
        y = [abs(float(r["actual_delta_E"])) for r in rows]
    elif quantity == "variation":
        y = [float(r["total_variation"]) for r in rows]
    else:
        raise ValueError(quantity)
    fit = v452.choose_decay(X, y)
    fit = dict(fit)
    fit["training_Xb"] = X
    fit["training_values"] = y
    return fit


def monotone_tail(values: Sequence[float], n: int = 2) -> bool:
    a = list(map(float, values))
    if len(a) < 2:
        return True
    m = min(len(a)-1, max(1, int(n)))
    return all(a[-j] <= a[-j-1] for j in range(1, m+1))


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--v452-module", default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--cutoffs", default="583200,1166400,2332800,4665600,9331200,18662400")
    ap.add_argument("--modes", default="1,2,4,8,12,16,24,32")
    ap.add_argument("--nodes-per-doubling", type=int, default=17)
    ap.add_argument("--pnt-q", type=int, default=3072)
    ap.add_argument("--pnt-qcheck", type=int, default=4608)
    ap.add_argument("--prime-chunk", type=int, default=100000)
    ap.add_argument("--root-tol", type=float, default=2e-9)
    ap.add_argument("--scan-points", type=int, default=65)
    ap.add_argument("--max-newton", type=int, default=12)
    ap.add_argument("--prediction-safety", type=float, default=2.0)
    ap.add_argument("--minimum-transversality", type=float, default=1e-3)
    ap.add_argument("--maximum-duhamel-relative-gap", type=float, default=5e-3)
    ap.add_argument("--maximum-duhamel-absolute-gap", type=float, default=5e-7)
    ap.add_argument("--maximum-pnt-refinement-relative", type=float, default=5e-6)
    ap.add_argument("--maximum-holdout-prediction-ratio", type=float, default=1.0)
    ap.add_argument("--tail-monotone-steps", type=int, default=2)
    ap.add_argument("--refinement-modes", default="1,8,16,32")
    ap.add_argument("--prefix", default="rot_rh_bump2_signed_duhamel_flow_v453")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    v452 = import_v452(args.v452_module)
    cutoffs = parse_ints(args.cutoffs)
    modes = sorted(set(parse_ints(args.modes)))
    refine_modes = sorted(set(parse_ints(args.refinement_modes)))
    if len(cutoffs) < 5 or cutoffs != sorted(cutoffs):
        raise ValueError("--cutoffs must contain >=5 strictly increasing cutoffs")
    ratios = [cutoffs[i+1]/cutoffs[i] for i in range(len(cutoffs)-1)]
    if max(abs(r-2.0) for r in ratios) > 0.02:
        print("WARNING: cutoff ladder is not exactly dyadic; analysis still uses supplied intervals.")
    if args.nodes_per_doubling < 5 or args.nodes_per_doubling % 2 == 0:
        raise ValueError("--nodes-per-doubling must be odd and >=5")
    if args.pnt_qcheck <= args.pnt_q:
        raise ValueError("--pnt-qcheck must exceed --pnt-q")

    # Final interval [train_endpoint, holdout] is prospectively held out.
    train_cutoffs = cutoffs[:-1]
    holdout_X = cutoffs[-1]
    train_endpoint = train_cutoffs[-1]
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*176)
    print("ROT-RH v453 — BUMP-2 FINITE-PART SIGNED DUHAMEL / CANCELLATION AUDIT")
    print("="*176)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("finite-part source                 : bump2 prime - bump2 PNT + E1 analytic continuation")
    print("training cutoff ladder             :", train_cutoffs)
    print("HELD-OUT interval                  :", f"[{train_endpoint}, {holdout_X}]")
    print("modes                              :", modes)
    print("nodes per interval                 :", args.nodes_per_doubling)
    print("integrated identity                : Delta E = integral[-F_logX/F_E] dlogX")
    print("mechanism split                    : total variation vs signed displacement")
    print("prospective firewall               : holdout interval untouched until SHA freeze")
    print("="*176)

    print("\n[A] Building one shared prime-power table and free levels ...")
    n_all, lam_all = v452.mangoldt_terms(int(holdout_X))
    print("Mangoldt/prime-power terms         :", len(n_all))
    free = v452.free_archimedean_levels(max(modes))

    node_rows: List[dict] = []
    interval_rows: List[dict] = []
    endpoint_roots: Dict[int, Dict[int, float]] = {}
    endpoint_node_data: Dict[int, Dict[int, dict]] = {}

    # -------------------------------------------------------------------------
    # TRAINING interval construction
    # -------------------------------------------------------------------------
    print("\n[B] Resolving TRAINING dyadic flow interiors ...")
    previous: Dict[int, float] | None = None
    cached_left: Tuple[float, float, Dict[int, dict], Dict[int, float]] | None = None

    for interval_index, (Xa, Xb) in enumerate(zip(train_cutoffs[:-1], train_cutoffs[1:])):
        Lnodes = interval_L_nodes(Xa, Xb, args.nodes_per_doubling)
        interval_data: List[Tuple[float, float, Dict[int, dict]]] = []
        bar = tqdm(range(len(Lnodes)), desc=f"TRAIN flow {Xa}->{Xb}", unit="node")
        for j in bar:
            L = float(Lnodes[j]); X = float(math.exp(L))
            if j == 0 and cached_left is not None and abs(cached_left[0]-L) < 1e-12:
                _, Xc, data, roots = cached_left
                X = Xc
            else:
                ph, data, roots = evaluate_node(
                    v452, n_all, lam_all, X, modes, free, previous,
                    args.pnt_q, args.prime_chunk, args.root_tol,
                    args.max_newton, args.scan_points
                )
            previous = dict(roots)
            interval_data.append((L, X, data))
            for k in modes:
                d = data[int(k)]
                node_rows.append({
                    "stage": "TRAIN", "interval_index": interval_index,
                    "Xa": Xa, "Xb": Xb, "node_index": j,
                    "L": fmt(L), "X": fmt(X), "k": int(k),
                    "root": fmt(d["E"]), "root_residual": fmt(d["root_residual"]),
                    "root_method": d["root_method"],
                    "F_E": fmt(d["F_E"]), "F_logX": fmt(d["F_logX"]),
                    "dE_dlogX": fmt(d["flow"]),
                    "prime_logX_source": fmt(d["prime_logX_source"]),
                    "pnt_logX_source": fmt(d["pnt_logX_source"]),
                    "prime_minus_pnt_source": fmt(d["prime_minus_pnt_source"]),
                    "source_cancellation_ratio": fmt(d["source_cancellation_ratio"]),
                })
        interval_rows.extend(integrate_interval(interval_data, modes, Xa, Xb, "TRAIN"))
        Llast, Xlast, dlast = interval_data[-1]
        cached_left = (Llast, Xlast, dlast, dict(previous))
        endpoint_roots[Xb] = dict(previous)
        endpoint_node_data[Xb] = dlast
        if interval_index == 0:
            endpoint_roots[Xa] = {k: interval_data[0][2][k]["E"] for k in modes}
            endpoint_node_data[Xa] = interval_data[0][2]

        subset = [r for r in interval_rows if r["stage"] == "TRAIN" and int(r["Xa"]) == Xa and int(r["Xb"]) == Xb]
        print(
            f"  {Xa}->{Xb}: max Duhamel rel={max(float(r['duhamel_relative_gap']) for r in subset):.3e} "
            f"max T={max(float(r['total_variation']) for r in subset):.3e} "
            f"max |dE|={max(abs(float(r['actual_delta_E'])) for r in subset):.3e}"
        )

    # -------------------------------------------------------------------------
    # Modewise training fits; freeze final interval before reveal.
    # -------------------------------------------------------------------------
    print("\n[C] Fitting and FREEZING modewise signed/variation predictions ...")
    fit_rows: List[dict] = []
    mode_predictions: Dict[str, dict] = {}
    all_increment_integrable = True
    all_variation_integrable = True

    for k in modes:
        inc_fit = mode_fit(v452, interval_rows, k, "increment")
        tv_fit = mode_fit(v452, interval_rows, k, "variation")
        pred_inc = v452.predict_fit(inc_fit, holdout_X)
        pred_tv = v452.predict_fit(tv_fit, holdout_X)
        upper_inc = v452.upper_envelope(pred_inc, inc_fit, args.prediction_safety)
        upper_tv = v452.upper_envelope(pred_tv, tv_fit, args.prediction_safety)
        inc_vals = list(map(float, inc_fit["training_values"]))
        tv_vals = list(map(float, tv_fit["training_values"]))
        inc_tail = monotone_tail(inc_vals, args.tail_monotone_steps)
        tv_tail = monotone_tail(tv_vals, args.tail_monotone_steps)
        all_increment_integrable &= bool(inc_fit["integrable_in_dlogX"])
        all_variation_integrable &= bool(tv_fit["integrable_in_dlogX"])
        mode_predictions[str(k)] = {
            "increment_fit": inc_fit,
            "variation_fit": tv_fit,
            "predicted_holdout_abs_delta_E": pred_inc,
            "holdout_abs_delta_E_upper": upper_inc,
            "predicted_holdout_total_variation": pred_tv,
            "holdout_total_variation_upper": upper_tv,
            "training_increment_tail_monotone": inc_tail,
            "training_variation_tail_monotone": tv_tail,
        }
        for q, fit, pred, upper in (
            ("abs_delta_E", inc_fit, pred_inc, upper_inc),
            ("total_variation", tv_fit, pred_tv, upper_tv),
        ):
            fit_rows.append({
                "k": int(k), "quantity": q,
                "selected_family": fit["family"], "selected_label": fit["label"],
                "C": fmt(fit["C"]), "p": fmt(fit["p"]),
                "log_rms": fmt(fit["log_rms"]),
                "integrable_in_dlogX": bool(fit["integrable_in_dlogX"]),
                "predicted_holdout": fmt(pred), "upper_envelope": fmt(upper),
            })

    freeze = {
        "version": VERSION,
        "frozen_before_holdout_interval": True,
        "v452_module": args.v452_module,
        "v452_module_sha256": sha256_file(Path(v452.__file__).resolve()),
        "regulator": "bump_2 finite part: prime - PNT + E1 analytic continuation",
        "training_cutoffs": train_cutoffs,
        "held_out_interval": [train_endpoint, holdout_X],
        "modes": modes,
        "nodes_per_doubling": args.nodes_per_doubling,
        "mode_predictions": mode_predictions,
        "all_increment_fits_integrable": all_increment_integrable,
        "all_variation_fits_integrable": all_variation_integrable,
        "gates": vars(args),
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_used": False,
            "holdout_interval_interior_constructed": False,
            "holdout_endpoint_constructed": False,
        },
    }
    freeze_path = Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json")
    freeze_path.write_text(json.dumps(json_safe(freeze), indent=2), encoding="utf-8")
    freeze_sha = sha256_file(freeze_path)
    print("  PRE-HOLDOUT FREEZE SHA256:", freeze_sha)
    print("  all |Delta E| fits integrable          :", all_increment_integrable)
    print("  all total-variation fits integrable    :", all_variation_integrable)
    for k in modes:
        p = mode_predictions[str(k)]
        print(
            f"  k={k:<3d} |dE| {p['increment_fit']['family']} p={p['increment_fit']['p']:+.4f} "
            f"T {p['variation_fit']['family']} p={p['variation_fit']['p']:+.4f}"
        )

    # -------------------------------------------------------------------------
    # HOLDOUT interval reveal.
    # -------------------------------------------------------------------------
    print("\n[D] Revealing HELD-OUT dyadic flow interior ...")
    Xa, Xb = train_endpoint, holdout_X
    Lnodes = interval_L_nodes(Xa, Xb, args.nodes_per_doubling)
    hold_data: List[Tuple[float, float, Dict[int, dict]]] = []
    previous = dict(endpoint_roots[Xa])

    for j in tqdm(range(len(Lnodes)), desc=f"HOLDOUT flow {Xa}->{Xb}", unit="node"):
        L = float(Lnodes[j]); X = float(math.exp(L))
        if j == 0:
            data = endpoint_node_data[Xa]
            roots = dict(previous)
        else:
            ph, data, roots = evaluate_node(
                v452, n_all, lam_all, X, modes, free, previous,
                args.pnt_q, args.prime_chunk, args.root_tol,
                args.max_newton, args.scan_points
            )
        previous = dict(roots)
        hold_data.append((L, X, data))
        for k in modes:
            d = data[int(k)]
            node_rows.append({
                "stage": "HOLDOUT", "interval_index": len(train_cutoffs)-1,
                "Xa": Xa, "Xb": Xb, "node_index": j,
                "L": fmt(L), "X": fmt(X), "k": int(k),
                "root": fmt(d["E"]), "root_residual": fmt(d["root_residual"]),
                "root_method": d["root_method"],
                "F_E": fmt(d["F_E"]), "F_logX": fmt(d["F_logX"]),
                "dE_dlogX": fmt(d["flow"]),
                "prime_logX_source": fmt(d["prime_logX_source"]),
                "pnt_logX_source": fmt(d["pnt_logX_source"]),
                "prime_minus_pnt_source": fmt(d["prime_minus_pnt_source"]),
                "source_cancellation_ratio": fmt(d["source_cancellation_ratio"]),
            })
    hold_rows = integrate_interval(hold_data, modes, Xa, Xb, "HOLDOUT")
    interval_rows.extend(hold_rows)

    # -------------------------------------------------------------------------
    # Holdout PNT refinement at midpoint and endpoint for selected modes.
    # -------------------------------------------------------------------------
    print("\n[E] Checking PNT carrier refinement on held-out midpoint/endpoint ...")
    refinement_rows: List[dict] = []
    refinement_max = 0.0
    for node_index in sorted(set([len(hold_data)//2, len(hold_data)-1])):
        L, X, data = hold_data[node_index]
        phq = make_phase(v452, n_all, lam_all, X, args.pnt_qcheck, args.prime_chunk)
        for k in tqdm([m for m in refine_modes if m in modes], desc=f"PNT refine node {node_index}", unit="mode", leave=False):
            E = float(data[k]["E"])
            # Same E; compare carrier/residual evaluation only.
            base_ph = make_phase(v452, n_all, lam_all, X, args.pnt_q, args.prime_chunk)
            a = base_ph.sources(E); b = phq.sources(E)
            gaps = {
                "pnt_phase_rel": safe_rel(a.pnt_phase, b.pnt_phase, 1e-12),
                "pnt_E_rel": safe_rel(a.pnt_E, b.pnt_E, 1e-12),
                "pnt_L_rel": safe_rel(a.pnt_L, b.pnt_L, 1e-12),
                "finitepart_L_rel": safe_rel(a.finitepart_L, b.finitepart_L, 1e-12),
            }
            refinement_max = max(refinement_max, *gaps.values())
            refinement_rows.append({
                "node_index": node_index, "X": fmt(X), "k": int(k), "E": fmt(E),
                **{name: fmt(value) for name, value in gaps.items()},
            })

    # -------------------------------------------------------------------------
    # Prospective scoring and mechanism classification.
    # -------------------------------------------------------------------------
    print("\n[F] Scoring held-out interval against ORIGINAL frozen predictions ...")
    score_rows: List[dict] = []
    holdout_prediction_pass = True
    duhamel_pass = True
    trans_pass = True
    tv_tail_contract_all = True
    increment_tail_contract_all = True
    holdout_all_sign_cancellation = True

    train_by_mode = {k: [r for r in interval_rows if r["stage"] == "TRAIN" and int(r["k"]) == k] for k in modes}
    hold_by_mode = {int(r["k"]): r for r in hold_rows}

    for k in modes:
        r = hold_by_mode[k]
        p = mode_predictions[str(k)]
        actual_inc = abs(float(r["actual_delta_E"]))
        actual_tv = float(r["total_variation"])
        inc_upper = float(p["holdout_abs_delta_E_upper"])*args.maximum_holdout_prediction_ratio
        tv_upper = float(p["holdout_total_variation_upper"])*args.maximum_holdout_prediction_ratio
        inc_pass = actual_inc <= inc_upper
        tv_pass = actual_tv <= tv_upper
        holdout_prediction_pass &= bool(inc_pass and tv_pass)

        rel_gap = float(r["duhamel_relative_gap"])
        abs_gap = float(r["duhamel_abs_gap"])
        dpass = bool(rel_gap <= args.maximum_duhamel_relative_gap or abs_gap <= args.maximum_duhamel_absolute_gap)
        duhamel_pass &= dpass
        tpass = float(r["min_abs_F_E"]) >= args.minimum_transversality
        trans_pass &= tpass

        prev = train_by_mode[k][-1]
        tv_contract = actual_tv <= float(prev["total_variation"])
        inc_contract = actual_inc <= abs(float(prev["actual_delta_E"]))
        tv_tail_contract_all &= tv_contract
        increment_tail_contract_all &= inc_contract
        signed_cancel = float(r["variation_to_signed_ratio"]) > 1.000001 or int(r["flow_sign_changes"]) > 0
        holdout_all_sign_cancellation &= signed_cancel

        score_rows.append({
            "k": k,
            "actual_abs_delta_E": fmt(actual_inc),
            "predicted_abs_delta_E": fmt(p["predicted_holdout_abs_delta_E"]),
            "abs_delta_E_upper": fmt(inc_upper), "increment_prediction_pass": inc_pass,
            "actual_total_variation": fmt(actual_tv),
            "predicted_total_variation": fmt(p["predicted_holdout_total_variation"]),
            "total_variation_upper": fmt(tv_upper), "variation_prediction_pass": tv_pass,
            "duhamel_relative_gap": r["duhamel_relative_gap"],
            "duhamel_absolute_gap": r["duhamel_abs_gap"], "duhamel_pass": dpass,
            "variation_to_signed_ratio": r["variation_to_signed_ratio"],
            "flow_sign_changes": r["flow_sign_changes"],
            "increment_fit_integrable": bool(p["increment_fit"]["integrable_in_dlogX"]),
            "variation_fit_integrable": bool(p["variation_fit"]["integrable_in_dlogX"]),
            "increment_tail_contract": inc_contract,
            "variation_tail_contract": tv_contract,
            "minimum_abs_F_E": r["min_abs_F_E"], "transversality_pass": tpass,
        })

    refinement_pass = refinement_max <= args.maximum_pnt_refinement_relative

    # Global training Duhamel check also matters.
    train_duhamel_rel = [float(r["duhamel_relative_gap"]) for r in interval_rows if r["stage"] == "TRAIN"]
    train_duhamel_abs = [float(r["duhamel_abs_gap"]) for r in interval_rows if r["stage"] == "TRAIN"]
    training_duhamel_pass = all(
        rel <= args.maximum_duhamel_relative_gap or ab <= args.maximum_duhamel_absolute_gap
        for rel, ab in zip(train_duhamel_rel, train_duhamel_abs)
    )
    duhamel_pass &= training_duhamel_pass

    # Route classification.
    if not refinement_pass:
        verdict = "PNT_QUADRATURE_REFINEMENT_FAILED"
    elif not trans_pass:
        verdict = "FINITE_PART_TRANSVERSALITY_FAILED"
    elif not duhamel_pass:
        verdict = "DUHAMEL_FLOW_IDENTITY_NOT_RESOLVED_AT_CURRENT_NODE_DENSITY"
    elif not holdout_prediction_pass:
        verdict = "SIGNED_FLOW_HOLDOUT_NOT_SUPPORTED"
    elif all_variation_integrable and tv_tail_contract_all:
        verdict = "ABSOLUTE_FLOW_ROUTE_SUPPORTED_PROSPECTIVELY"
    elif all_increment_integrable and tv_tail_contract_all:
        verdict = "DYADIC_CANCELLATION_ROUTE_SUPPORTED_PROSPECTIVELY"
    elif tv_tail_contract_all and increment_tail_contract_all:
        verdict = "SIGNED_FLOW_CONTRACTS__SUMMABILITY_NOT_YET_SUPPORTED"
    else:
        verdict = "SIGNED_FLOW_CANCELLATION_NOT_YET_CLOSED"

    # Output files.
    node_path = Path(str(prefix)+"_FLOW_NODES.csv"); write_csv(node_path, node_rows)
    interval_path = Path(str(prefix)+"_INTERVALS.csv"); write_csv(interval_path, interval_rows)
    fit_path = Path(str(prefix)+"_MODE_FITS.csv"); write_csv(fit_path, fit_rows)
    score_path = Path(str(prefix)+"_HOLDOUT_SCORE.csv"); write_csv(score_path, score_rows)
    refine_path = Path(str(prefix)+"_PNT_REFINEMENT.csv"); write_csv(refine_path, refinement_rows)

    theorem_text = r"""# ROT-RH v453 — signed Duhamel convergence theorem target

Let L=log X and let E_k(L) be a simple ordered branch of the bump-2 finite-part
secular equation.  Define

    v_k(L) = dE_k/dL = -F_L(E_k(L),L)/F_E(E_k(L),L).

On a dyadic L-grid L_j=L_0+j log 2 define

    S_{k,j} = int_{L_j}^{L_{j+1}} v_k(L) dL
            = E_k(L_{j+1})-E_k(L_j),

and

    T_{k,j} = int_{L_j}^{L_{j+1}} |v_k(L)| dL.

Two sufficient routes to continuous cutoff convergence are:

1. Absolute route:
       sum_j T_{k,j} < infinity.

2. Dyadic cancellation route:
       sum_j |S_{k,j}| < infinity
   and T_{k,j} -> 0.

The first gives absolute integrability of the root velocity.  The second allows
large but shrinking within-shell oscillation: the dyadic endpoints are Cauchy,
and T_{k,j}->0 forces the entire continuous branch between endpoints into the
same limit.

A still weaker Dirichlet route could replace absolute summability of |S_{k,j}|
by a proved signed oscillation theorem, but finite alternating signs alone are
not a proof of such a theorem.

Once every fixed branch converges, a uniform Weyl lower bound upgrades the
ordered diagonal realization to strong-resolvent convergence; H_L^{-2} then
converges in trace norm under the corresponding summable inverse-square
envelope.
"""
    theorem_path = Path(str(prefix)+"_THEOREM.md")
    theorem_path.write_text(theorem_text, encoding="utf-8")

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time()-started,
        "verdict": verdict,
        "zero_ordinate_firewall": True,
        "cutoffs": cutoffs,
        "training_cutoffs": train_cutoffs,
        "held_out_interval": [train_endpoint, holdout_X],
        "modes": modes,
        "nodes_per_doubling": args.nodes_per_doubling,
        "pre_holdout_freeze_sha256": freeze_sha,
        "all_increment_fits_integrable": all_increment_integrable,
        "all_variation_fits_integrable": all_variation_integrable,
        "holdout_prediction_pass": holdout_prediction_pass,
        "duhamel_pass": duhamel_pass,
        "training_duhamel_pass": training_duhamel_pass,
        "transversality_pass": trans_pass,
        "PNT_refinement_max_relative": refinement_max,
        "PNT_refinement_pass": refinement_pass,
        "holdout_variation_tail_contract_all_modes": tv_tail_contract_all,
        "holdout_increment_tail_contract_all_modes": increment_tail_contract_all,
        "holdout_all_modes_show_signed_cancellation": holdout_all_sign_cancellation,
        "holdout_scores": score_rows,
        "scientific_boundary": (
            "Finite prospective evidence only. A theorem still requires an all-dyadic "
            "bound or signed oscillation law, not merely fitted finite decay."
        ),
        "outputs": [
            str(node_path), str(interval_path), str(fit_path), str(score_path),
            str(refine_path), str(freeze_path), str(theorem_path)
        ],
    }
    summary_path = Path(str(prefix)+"_SUMMARY.json")
    summary_path.write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    # Key results.
    hold_max_rel = max(float(r["duhamel_relative_gap"]) for r in hold_rows)
    hold_max_abs = max(float(r["duhamel_abs_gap"]) for r in hold_rows)
    hold_max_ratio = max(float(r["variation_to_signed_ratio"]) for r in hold_rows)
    hold_min_trans = min(float(r["min_abs_F_E"]) for r in hold_rows)

    print("\n"+"="*176)
    print("KEY RESULTS")
    print("="*176)
    print("verdict                                  :", verdict)
    print("pre-holdout freeze SHA256                :", freeze_sha)
    print("all mode |Delta E| fits integrable       :", all_increment_integrable)
    print("all mode total-variation fits integrable :", all_variation_integrable)
    print(f"holdout Duhamel max rel / abs gap        : {hold_max_rel:.6e} / {hold_max_abs:.6e} pass={duhamel_pass}")
    print(f"holdout minimum |F_E|                    : {hold_min_trans:.6e} pass={trans_pass}")
    print(f"PNT q refinement max relative            : {refinement_max:.6e} pass={refinement_pass}")
    print("holdout prediction pass all modes        :", holdout_prediction_pass)
    print("holdout variation tail contracts all     :", tv_tail_contract_all)
    print("holdout increment tail contracts all     :", increment_tail_contract_all)
    print(f"largest holdout T/|S| cancellation ratio : {hold_max_ratio:.6e}")
    print("holdout mode diagnostics                 :")
    for r in score_rows:
        print(
            f"  k={int(r['k']):<3d} |dE|={float(r['actual_abs_delta_E']):.6e} "
            f"T={float(r['actual_total_variation']):.6e} "
            f"T/|S|={float(r['variation_to_signed_ratio']):.3f} "
            f"signchg={int(r['flow_sign_changes'])} "
            f"inc_int={r['increment_fit_integrable']} T_int={r['variation_fit_integrable']} "
            f"pred_pass={bool(r['increment_prediction_pass'] and r['variation_prediction_pass'])}"
        )
    print("summary                                  :", summary_path)
    print("="*176)

    good = verdict in {
        "ABSOLUTE_FLOW_ROUTE_SUPPORTED_PROSPECTIVELY",
        "DYADIC_CANCELLATION_ROUTE_SUPPORTED_PROSPECTIVELY",
        "SIGNED_FLOW_CONTRACTS__SUMMABILITY_NOT_YET_SUPPORTED",
    }
    if args.strict and not good:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
