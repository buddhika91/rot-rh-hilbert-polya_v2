#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v457 — PACKET-FOURIER CUTOFF-INDEPENDENCE EXPONENT / CAUCHY AUDIT
============================================================================

PURPOSE
-------
v456 identified a concrete candidate mechanism for the bump-2 finite-part
source along a continued root branch:

    finitepart_L(E_k(L),L)
      = M_k(L) * normalized_signed_source_k(L)

with a standardized packet and prescribed arithmetic frequency

    Omega_k(L) = E_k(L) L sigma_k(L),       L = log X,

so that the carrier is controlled by the characteristic function of the
packet.  v457 tests the exact sufficient exponent inequality needed to turn
that mechanism into cutoff independence.

For each fixed mode k we seek training-side envelopes

    M_k(L)                  <= C_M L^(a_M)
    R_k(L)                  <= C_R L^(a_R)
    1/|F_E(E_k(L),L)|       <= C_D L^(a_D)
    Omega_k(L)              >= c_O L^(b_O)
    |H_k(Omega)|            <= C_H Omega^(-p_H)
    carrier residual eps_k  <= C_e L^(-p_e)

where H_k is the standardized packet characteristic function.  The packet
carrier then gives

    |E'_k(L)| = |finitepart_L|/(pi |F_E|)

with the candidate decay exponents

    p_carrier = p_H*b_O - a_M - a_R - a_D,
    p_residual = p_e       - a_M       - a_D,
    p_star     = min(p_carrier, p_residual).

If

    p_star > 1,

then the resulting target bound C L^(-p_star) is integrable in dL and yields

    integral_{L0}^infinity |E'_k(L)| dL < infinity,

hence E_k(L) is Cauchy and converges.  This is the exact analytic inequality
we ultimately need to PROVE for all sufficiently large L.

v457 does NOT infer this from one regression alone.  It performs:

  1. blocked TRAIN validation of every component envelope;
  2. a SHA256 freeze before reading v456's held-out trajectory;
  3. held-out checks of packet mass, amplitude, Omega, Fourier amplitude,
     carrier residual, root increments, and sampled within-dyadic excursion;
  4. an independent direct Cauchy diagnostic on |Delta E_k|;
  5. endpoint transversality checks using the exact v452 bump-2 F_E.

SCIENTIFIC BOUNDARY
-------------------
A numerical PASS is a prospective theorem-mechanism certificate, NOT an
all-L proof of cutoff independence.  To promote PASS to a proof one must prove
the frozen component inequalities for all sufficiently large L (or replace
them with stronger analytic bounds).  No known zero ordinates, zeta(), Xi(),
or xi() are used.

Required local files:
    rot_rh_bump2_finite_part_source_flow_v452.py
    <v456-prefix>_PRE_HOLDOUT_FREEZE.json
    <v456-prefix>_PACKET_PHASE_NODES.csv
    <v456-prefix>_HOLDOUT_TRAJECTORY.csv
    <v456-prefix>_SUMMARY.json

Recommended workflow:
    run v456 first, then run v457 from the same directory.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from tqdm import tqdm

VERSION = "2026-08-26-v457-packet-fourier-cutoff-independence"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def read_v456_train_nodes_only(path: Path) -> List[dict]:
    """Stream v456 nodes and retain TRAIN rows only.

    HOLDOUT rows are deliberately discarded without entering the theorem-fit
    data structures.  The complete file is not parsed into memory until after
    the v457 pre-holdout freeze.
    """
    out: List[dict] = []
    with path.open("r", newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if str(row.get("phase", "")).upper() == "TRAIN":
                out.append(row)
    return out


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def json_safe(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return [json_safe(x) for x in obj.tolist()]
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(x) for x in obj]
    return obj


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py beside v457, "
            "or pass --v452-module."
        )


def positive(x: float, floor: float = 1e-300) -> float:
    return max(float(x), float(floor))


def safe_ratio(a: float, b: float, floor: float = 1e-300) -> float:
    return float(a) / max(abs(float(b)), float(floor))


def geometric_mean(values: Sequence[float]) -> float:
    a = np.asarray(values, float)
    a = a[np.isfinite(a) & (a > 0)]
    if not len(a):
        return float("nan")
    return float(np.exp(np.mean(np.log(a))))


# =============================================================================
# Fixed log-power envelope families
# =============================================================================
# We deliberately do NOT select among many model families in v457.  Every
# theorem component uses one fixed asymptotic coordinate L=log X.
#
# upper growth: y <= C L^a
# upper decay : y <= C L^-p
# lower growth: y >= c L^b
#
# The multiplicative envelope is obtained from the largest one-sided training
# log residual and an explicit safety factor.
# =============================================================================

def _log_fit(x: Sequence[float], y: Sequence[float]) -> Tuple[float, float, np.ndarray]:
    xx = np.log(np.asarray(x, float))
    yy = np.log(np.maximum(np.asarray(y, float), 1e-300))
    A = np.column_stack([np.ones(len(xx)), xx])
    beta, *_ = np.linalg.lstsq(A, yy, rcond=None)
    pred = A @ beta
    return float(beta[0]), float(beta[1]), yy - pred


def fit_upper_growth(L: Sequence[float], y: Sequence[float], safety: float) -> dict:
    logC, a, resid = _log_fit(L, y)
    upper_shift = float(max(0.0, np.max(resid))) + math.log(float(safety))
    return {
        "kind": "upper_growth",
        "C": float(math.exp(logC + upper_shift)),
        "a": float(a),
        "raw_C": float(math.exp(logC)),
        "max_positive_log_residual": float(max(0.0, np.max(resid))),
        "safety": float(safety),
    }


def predict_upper_growth(fit: dict, L: float) -> float:
    return float(fit["C"] * float(L) ** float(fit["a"]))


def fit_upper_decay(L: Sequence[float], y: Sequence[float], safety: float) -> dict:
    logC, slope, resid = _log_fit(L, y)
    # log y = log C + slope log L = log C - p log L
    p = -float(slope)
    upper_shift = float(max(0.0, np.max(resid))) + math.log(float(safety))
    return {
        "kind": "upper_decay",
        "C": float(math.exp(logC + upper_shift)),
        "p": p,
        "raw_C": float(math.exp(logC)),
        "max_positive_log_residual": float(max(0.0, np.max(resid))),
        "safety": float(safety),
    }


def predict_upper_decay(fit: dict, L: float) -> float:
    return float(fit["C"] * float(L) ** (-float(fit["p"])))


def fit_lower_growth(L: Sequence[float], y: Sequence[float], safety: float) -> dict:
    logc, b, resid = _log_fit(L, y)
    # lower envelope must sit below all training values.
    lower_shift = float(min(0.0, np.min(resid))) - math.log(float(safety))
    return {
        "kind": "lower_growth",
        "c": float(math.exp(logc + lower_shift)),
        "b": float(b),
        "raw_c": float(math.exp(logc)),
        "min_negative_log_residual": float(min(0.0, np.min(resid))),
        "safety": float(safety),
    }


def predict_lower_growth(fit: dict, L: float) -> float:
    return float(fit["c"] * float(L) ** float(fit["b"]))


def fit_fourier_upper(omega: Sequence[float], H: Sequence[float], safety: float) -> dict:
    logC, slope, resid = _log_fit(omega, H)
    p = -float(slope)
    upper_shift = float(max(0.0, np.max(resid))) + math.log(float(safety))
    return {
        "kind": "fourier_upper",
        "C": float(math.exp(logC + upper_shift)),
        "p": p,
        "raw_C": float(math.exp(logC)),
        "max_positive_log_residual": float(max(0.0, np.max(resid))),
        "safety": float(safety),
    }


def predict_fourier_upper(fit: dict, omega: float) -> float:
    return float(fit["C"] * positive(omega) ** (-float(fit["p"])))


def envelope_pass(actual: Sequence[float], upper: Sequence[float], rel_slack: float = 1e-12) -> bool:
    return all(float(a) <= float(u) * (1.0 + rel_slack) for a, u in zip(actual, upper))


def lower_envelope_pass(actual: Sequence[float], lower: Sequence[float], rel_slack: float = 1e-12) -> bool:
    return all(float(a) + abs(float(a))*rel_slack >= float(lo) for a, lo in zip(actual, lower))


# =============================================================================
# v456 parsing
# =============================================================================

def resolve_v456_paths(prefix: Path) -> dict:
    s = str(prefix)
    return {
        "freeze": Path(s + "_PRE_HOLDOUT_FREEZE.json"),
        "nodes": Path(s + "_PACKET_PHASE_NODES.csv"),
        "holdout": Path(s + "_HOLDOUT_TRAJECTORY.csv"),
        "summary": Path(s + "_SUMMARY.json"),
    }


def require_paths(paths: Dict[str, Path]) -> None:
    missing = [str(p) for p in paths.values() if not p.exists()]
    if missing:
        joined = "\n  ".join(missing)
        raise SystemExit(
            "ERROR: required v456 outputs are missing. Run v456 first. Missing:\n  " + joined
        )


def mode_rows(rows: Iterable[dict], mode: int, phase: str | None = None) -> List[dict]:
    out = []
    for r in rows:
        if int(r["mode"]) != int(mode):
            continue
        if phase is not None and str(r.get("phase", "")).upper() != phase.upper():
            continue
        out.append(r)
    return sorted(out, key=lambda r: float(r["logX"]))


def group_train_intervals(rows: Sequence[dict], mode: int) -> List[dict]:
    rr = mode_rows(rows, mode, "TRAIN")
    by: Dict[int, List[dict]] = {}
    for r in rr:
        by.setdefault(int(r["interval"]), []).append(r)
    out = []
    for j in sorted(by):
        z = sorted(by[j], key=lambda r: float(r["logX"]))
        L = np.asarray([float(r["logX"]) for r in z], float)
        mass = np.asarray([positive(float(r["packet_mass"])) for r in z], float)
        R = np.asarray([positive(float(r["fit_R"])) for r in z], float)
        omega = np.asarray([positive(float(r["omega"])) for r in z], float)
        H = np.asarray([positive(float(r["fourier_abs"])) for r in z], float)
        src = np.asarray([float(r["source_norm"]) for r in z], float)
        srcfit = np.asarray([float(r["source_norm_nodefit"]) for r in z], float)
        eps = np.maximum(np.abs(src-srcfit), 1e-300)
        E = np.asarray([float(r["E"]) for r in z], float)
        out.append({
            "interval": j,
            "L_left": float(L[0]),
            "L_right": float(L[-1]),
            "L_rep": float(np.median(L)),
            "mass_max": float(np.max(mass)),
            "R_max": float(np.max(R)),
            "omega_min": float(np.min(omega)),
            "omega_med": float(np.median(omega)),
            "H_max": float(np.max(H)),
            "eps_max": float(np.max(eps)),
            "E_left": float(E[0]),
            "E_right": float(E[-1]),
            "abs_delta_E": float(abs(E[-1]-E[0])),
            "sampled_variation": float(np.sum(np.abs(np.diff(E)))),
            "sampled_excursion": float(np.max(E)-np.min(E)),
            "nodes": len(z),
        })
    return out


def holdout_mode_arrays(nodes: Sequence[dict], detail: Sequence[dict], mode: int) -> dict:
    nr = mode_rows(nodes, mode, "HOLDOUT")
    dr = sorted(
        [r for r in detail if int(r["mode"]) == int(mode)],
        key=lambda r: int(r["node_index"]),
    )
    if len(nr) != len(dr):
        raise RuntimeError(
            f"v456 holdout row mismatch for mode {mode}: nodes={len(nr)} detail={len(dr)}"
        )
    L = np.asarray([float(r["logX"]) for r in nr], float)
    E = np.asarray([float(r["E"]) for r in nr], float)
    mass = np.asarray([positive(float(r["packet_mass"])) for r in nr], float)
    omega = np.asarray([positive(float(r["omega"])) for r in nr], float)
    H = np.asarray([positive(float(r["actual_fourier_abs"])) for r in nr], float)
    Rpred = np.asarray([positive(float(r["pred_R"])) for r in dr], float)
    src = np.asarray([float(r["actual_source_norm"]) for r in dr], float)
    srcpred = np.asarray([float(r["conditional_source_norm_pred"]) for r in dr], float)
    eps = np.maximum(np.abs(src-srcpred), 1e-300)
    return {
        "L": L,
        "E": E,
        "mass": mass,
        "omega": omega,
        "H": H,
        "R": Rpred,
        "eps": eps,
        "abs_delta_E": float(abs(E[-1]-E[0])),
        "sampled_variation": float(np.sum(np.abs(np.diff(E)))),
        "sampled_excursion": float(np.max(E)-np.min(E)),
    }


# =============================================================================
# Exact endpoint transversality using v452
# =============================================================================

def cutoff_endpoint_roots(nodes: Sequence[dict], cutoffs: Sequence[int], modes: Sequence[int]) -> Dict[int, Dict[int, float]]:
    # Match by nearest logX because X was reconstructed from exp(L).
    allrows = list(nodes)
    out: Dict[int, Dict[int, float]] = {}
    for X in cutoffs:
        L0 = math.log(float(X))
        out[X] = {}
        for k in modes:
            rr = [r for r in allrows if int(r["mode"]) == int(k)]
            r = min(rr, key=lambda z: abs(float(z["logX"])-L0))
            gap = abs(float(r["logX"])-L0)
            if gap > 5e-8:
                raise RuntimeError(f"cannot match v456 node to cutoff X={X}, mode={k}, dlogX={gap}")
            out[X][k] = float(r["E"])
    return out


def exact_endpoint_transversality(v452, nodes: Sequence[dict], cutoffs: Sequence[int],
                                   modes: Sequence[int], pnt_q: int,
                                   prime_chunk: int) -> Tuple[List[dict], Dict[int, Dict[int, float]]]:
    maxX = int(max(cutoffs))
    n_all, lam_all = v452.mangoldt_terms(maxX)
    roots = cutoff_endpoint_roots(nodes, cutoffs, modes)
    rows: List[dict] = []
    by_mode: Dict[int, Dict[int, float]] = {int(k): {} for k in modes}

    for X in tqdm(cutoffs, desc="v457 endpoint transversality", unit="cutoff"):
        idx = int(np.searchsorted(n_all, float(X), side="left"))
        ph = v452.FinitePartBump2(
            n_all[:idx], lam_all[:idx], float(X), int(pnt_q), int(prime_chunk)
        )
        for k in modes:
            E = roots[int(X)][int(k)]
            f_resid = float(ph.f(E, int(k)))
            fE = float(v452.smooth_count_prime(E) - ph.E_component(E)/math.pi)
            inv = 1.0 / max(abs(fE), 1e-300)
            by_mode[int(k)][int(X)] = inv
            rows.append({
                "X": int(X), "logX": fmt(math.log(float(X))), "mode": int(k),
                "E": fmt(E), "secular_residual": fmt(f_resid),
                "F_E": fmt(fE), "abs_F_E": fmt(abs(fE)), "inv_abs_F_E": fmt(inv),
            })
    return rows, by_mode


# =============================================================================
# Validation / fitting helpers
# =============================================================================

def fit_component_packet(intervals: Sequence[dict], safety: float) -> dict:
    L = [r["L_rep"] for r in intervals]
    return {
        "mass": fit_upper_growth(L, [r["mass_max"] for r in intervals], safety),
        "R": fit_upper_growth(L, [r["R_max"] for r in intervals], safety),
        "omega": fit_lower_growth(L, [r["omega_min"] for r in intervals], safety),
        "fourier": fit_fourier_upper([r["omega_min"] for r in intervals], [r["H_max"] for r in intervals], safety),
        "residual": fit_upper_decay(L, [r["eps_max"] for r in intervals], safety),
        "increment": fit_upper_decay(L, [positive(r["abs_delta_E"]) for r in intervals], safety),
        "excursion": fit_upper_decay(L, [positive(r["sampled_excursion"]) for r in intervals], safety),
    }


def fit_invfe_growth(intervals: Sequence[dict], cutoffs: Sequence[int], mode: int,
                     inv_by_mode: Dict[int, Dict[int, float]], safety: float) -> dict:
    vals = []
    L = []
    # interval j corresponds cutoff[j] -> cutoff[j+1]
    for r in intervals:
        j = int(r["interval"])
        xa, xb = int(cutoffs[j]), int(cutoffs[j+1])
        vals.append(max(inv_by_mode[int(mode)][xa], inv_by_mode[int(mode)][xb]))
        L.append(float(r["L_rep"]))
    return fit_upper_growth(L, vals, safety)


def component_exponents(packet_fit: dict, invfe_fit: dict) -> dict:
    aM = float(packet_fit["mass"]["a"])
    aR = float(packet_fit["R"]["a"])
    aD = float(invfe_fit["a"])
    bO = float(packet_fit["omega"]["b"])
    pH = float(packet_fit["fourier"]["p"])
    pe = float(packet_fit["residual"]["p"])
    p_carrier = pH*bO - aM - aR - aD
    p_residual = pe - aM - aD
    return {
        "a_mass": aM,
        "a_R": aR,
        "a_invFE": aD,
        "b_omega": bO,
        "p_fourier": pH,
        "p_residual_norm": pe,
        "p_carrier": float(p_carrier),
        "p_residual": float(p_residual),
        "p_star": float(min(p_carrier, p_residual)),
    }


def validate_interval(model: dict, invfe: dict, row: dict,
                      invFE_actual: float) -> dict:
    L = float(row["L_rep"])
    vals = {
        "mass": (float(row["mass_max"]), predict_upper_growth(model["mass"], L)),
        "R": (float(row["R_max"]), predict_upper_growth(model["R"], L)),
        "omega": (float(row["omega_min"]), predict_lower_growth(model["omega"], L)),
        "fourier": (float(row["H_max"]), predict_fourier_upper(model["fourier"], float(row["omega_min"]))),
        "residual": (float(row["eps_max"]), predict_upper_decay(model["residual"], L)),
        "increment": (float(row["abs_delta_E"]), predict_upper_decay(model["increment"], L)),
        "excursion": (float(row["sampled_excursion"]), predict_upper_decay(model["excursion"], L)),
        "invFE": (float(invFE_actual), predict_upper_growth(invfe, L)),
    }
    passes = {
        "mass": vals["mass"][0] <= vals["mass"][1],
        "R": vals["R"][0] <= vals["R"][1],
        "omega": vals["omega"][0] >= vals["omega"][1],
        "fourier": vals["fourier"][0] <= vals["fourier"][1],
        "residual": vals["residual"][0] <= vals["residual"][1],
        "increment": vals["increment"][0] <= vals["increment"][1],
        "excursion": vals["excursion"][0] <= vals["excursion"][1],
        "invFE": vals["invFE"][0] <= vals["invFE"][1],
    }
    return {"values": vals, "passes": passes, "all": bool(all(passes.values()))}


def holdout_summary_row(h: dict) -> dict:
    return {
        "L_left": float(h["L"][0]),
        "L_right": float(h["L"][-1]),
        "L_rep": float(np.median(h["L"])),
        "mass_max": float(np.max(h["mass"])),
        "R_max": float(np.max(h["R"])),
        "omega_min": float(np.min(h["omega"])),
        "H_max": float(np.max(h["H"])),
        "eps_max": float(np.max(h["eps"])),
        "abs_delta_E": float(h["abs_delta_E"]),
        "sampled_variation": float(h["sampled_variation"]),
        "sampled_excursion": float(h["sampled_excursion"]),
    }


def bound_ratio(actual: float, bound: float) -> float:
    return float(actual) / max(float(bound), 1e-300)


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--v452-module", default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--v456-prefix", default="rot_rh_bump2_packet_fourier_cancellation_v456")
    ap.add_argument("--cutoffs", default="2332800,4665600,9331200,18662400,37324800,74649600")
    ap.add_argument("--modes", default="1,2,4,8,12,16,24,32")
    ap.add_argument("--pnt-q", type=int, default=3072)
    ap.add_argument("--prime-chunk", type=int, default=100000)
    ap.add_argument("--component-safety", type=float, default=1.75,
                    help="One-sided multiplicative envelope safety used for each theorem component.")
    ap.add_argument("--integrability-margin", type=float, default=0.10,
                    help="Require p_star >= 1 + this margin.")
    ap.add_argument("--minimum-fourier-decay-p", type=float, default=0.25,
                    help="Reject a formally positive combined exponent if packet Fourier decay itself is essentially flat.")
    ap.add_argument("--minimum-omega-growth-b", type=float, default=0.50,
                    help="Require Omega to grow at least as a positive power of L in the finite theorem model.")
    ap.add_argument("--minimum-transversality", type=float, default=1e-3)
    ap.add_argument("--maximum-secular-residual", type=float, default=2e-7)
    ap.add_argument("--maximum-holdout-envelope-ratio", type=float, default=1.0)
    ap.add_argument("--priority-modes", default="12,32")
    ap.add_argument("--prefix", default="rot_rh_packet_fourier_cutoff_independence_v457")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    v452 = import_v452(args.v452_module)
    modes = sorted(set(parse_ints(args.modes)))
    priority = sorted(set(parse_ints(args.priority_modes)))
    cutoffs = parse_ints(args.cutoffs)
    if len(cutoffs) < 6 or cutoffs != sorted(cutoffs):
        raise ValueError("--cutoffs must contain >=6 increasing values matching the v456 ladder")
    if max(abs(cutoffs[i+1]/cutoffs[i]-2.0) for i in range(len(cutoffs)-1)) > 0.03:
        print("WARNING: supplied cutoff ladder is not close to dyadic.")
    if args.component_safety <= 1.0:
        raise ValueError("--component-safety should be > 1")

    v456_prefix = Path(args.v456_prefix).expanduser().resolve()
    paths456 = resolve_v456_paths(v456_prefix)
    require_paths(paths456)
    freeze456 = json.loads(paths456["freeze"].read_text(encoding="utf-8"))
    train_nodes = read_v456_train_nodes_only(paths456["nodes"])

    # Do NOT read v456 SUMMARY, HOLDOUT trajectory, or HOLDOUT node rows until
    # the v457 final theorem model has been frozen.
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*188)
    print("ROT-RH v457 — PACKET-FOURIER CUTOFF-INDEPENDENCE EXPONENT / CAUCHY AUDIT")
    print("="*188)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("v456 verdict                       : SEALED until v457 freeze")
    print("cutoff ladder                      :", cutoffs)
    print("modes                              :", modes)
    print("theorem target                     : |E'_k(L)| <= C_k L^(-1-epsilon)")
    print("mechanism exponent                 : p*=min(pH*bOmega-aM-aR-aD, pe-aM-aD)")
    print("required p*                        :", 1.0 + args.integrability_margin)
    print("holdout policy                     : SUMMARY / HOLDOUT rows sealed until v457 SHA freeze")
    print("="*188)

    # Check ladder against v456 freeze.
    ftrain = [int(x) for x in freeze456.get("training_cutoffs", [])]
    fhold = [int(x) for x in freeze456.get("held_out_interval", [])]
    expected_train = cutoffs[:-1]
    expected_hold = [cutoffs[-2], cutoffs[-1]]
    if ftrain and ftrain != expected_train:
        raise RuntimeError(f"v456 training ladder mismatch: freeze={ftrain}, requested={expected_train}")
    if fhold and fhold != expected_hold:
        raise RuntimeError(f"v456 holdout mismatch: freeze={fhold}, requested={expected_hold}")

    # -------------------------------------------------------------------------
    # A. Exact endpoint transversality.  This uses only v456 root locations;
    #    no heldout packet trajectory is read.
    # -------------------------------------------------------------------------
    print("\n[A] Rechecking TRAIN-only exact v452 endpoint transversality ...")
    train_trans_rows, inv_by_mode = exact_endpoint_transversality(
        v452, train_nodes, cutoffs[:-1], modes, args.pnt_q, args.prime_chunk
    )
    train_max_root_resid = max(abs(float(r["secular_residual"])) for r in train_trans_rows)
    train_min_abs_FE = min(float(r["abs_F_E"]) for r in train_trans_rows)
    print(f"  TRAIN max endpoint secular residual : {train_max_root_resid:.6e}")
    print(f"  TRAIN min endpoint |F_E|            : {train_min_abs_FE:.6e}")

    # -------------------------------------------------------------------------
    # B. Build TRAIN interval summaries from v456 TRAIN rows only.
    #    The final TRAIN interval is blocked validation; earlier intervals fit.
    # -------------------------------------------------------------------------
    print("\n[B] Building TRAIN packet/Fourier theorem components ...")
    train_intervals_by_mode: Dict[int, List[dict]] = {}
    blocked_results: Dict[int, dict] = {}
    final_packet_models: Dict[int, dict] = {}
    final_invfe_models: Dict[int, dict] = {}
    exponent_rows: List[dict] = []

    for k in modes:
        ints = group_train_intervals(train_nodes, k)
        if len(ints) < 4:
            raise RuntimeError(f"mode {k}: need >=4 v456 TRAIN intervals, found {len(ints)}")
        train_intervals_by_mode[k] = ints

        # Blocked validation: fit all but final TRAIN interval.
        fit_ints = ints[:-1]
        val = ints[-1]
        pm_block = fit_component_packet(fit_ints, args.component_safety)
        inv_block = fit_invfe_growth(fit_ints, cutoffs, k, inv_by_mode, args.component_safety)
        jv = int(val["interval"])
        inv_actual = max(inv_by_mode[k][cutoffs[jv]], inv_by_mode[k][cutoffs[jv+1]])
        blocked = validate_interval(pm_block, inv_block, val, inv_actual)
        blocked_results[k] = blocked

        # Final freeze model uses every TRAIN interval after the fixed-family
        # blocked check.  No holdout trajectory has been read.
        pm = fit_component_packet(ints, args.component_safety)
        invm = fit_invfe_growth(ints, cutoffs, k, inv_by_mode, args.component_safety)
        ex = component_exponents(pm, invm)
        final_packet_models[k] = pm
        final_invfe_models[k] = invm

        exponent_rows.append({
            "mode": k,
            **{name: fmt(value) for name, value in ex.items()},
            "blocked_validation_pass": bool(blocked["all"]),
            "direct_increment_p": fmt(pm["increment"]["p"]),
            "direct_excursion_p": fmt(pm["excursion"]["p"]),
        })
        print(
            f"  k={k:<3d} pH={ex['p_fourier']:+.3f} bO={ex['b_omega']:+.3f} "
            f"aM={ex['a_mass']:+.3f} aR={ex['a_R']:+.3f} aD={ex['a_invFE']:+.3f} "
            f"pe={ex['p_residual_norm']:+.3f} => p*={ex['p_star']:+.3f} "
            f"blocked={blocked['all']}"
        )

    # Freeze BEFORE reading v456 holdout trajectory.
    freeze457 = {
        "version": VERSION,
        "frozen_before_v456_holdout_trajectory_read": True,
        "v452_module": args.v452_module,
        "v452_sha256": sha256_file(Path(v452.__file__).resolve()),
        "v456_prefix": str(v456_prefix),
        "v456_freeze_sha256": sha256_file(paths456["freeze"]),
        "v456_nodes_sha256": sha256_file(paths456["nodes"]),
        "v456_summary_sha256": sha256_file(paths456["summary"]),
        "cutoffs": cutoffs,
        "modes": modes,
        "priority_modes": priority,
        "component_safety": args.component_safety,
        "integrability_margin": args.integrability_margin,
        "packet_models": {str(k): final_packet_models[k] for k in modes},
        "invFE_models": {str(k): final_invfe_models[k] for k in modes},
        "blocked_validation": {str(k): blocked_results[k] for k in modes},
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_used": False,
            "v456_holdout_trajectory_read": False,
        },
    }
    freeze_path = Path(str(prefix) + "_PRE_HOLDOUT_FREEZE.json")
    freeze_path.write_text(json.dumps(json_safe(freeze457), indent=2), encoding="utf-8")
    freeze_sha = sha256_file(freeze_path)
    print("\n[C] PRE-HOLDOUT theorem model frozen")
    print("  SHA256                              :", freeze_sha)

    # -------------------------------------------------------------------------
    # D. Reveal v456 holdout trajectory only now.
    # -------------------------------------------------------------------------
    print("\n[D] Revealing v456 SUMMARY + held-out nodes/trajectory ...")
    summary456 = json.loads(paths456["summary"].read_text(encoding="utf-8"))
    nodes = read_csv(paths456["nodes"])
    detail = read_csv(paths456["holdout"])

    # Now certify the previously sealed final endpoint and merge it into the
    # training-side transversality table/model map.
    hold_trans_rows, hold_inv = exact_endpoint_transversality(
        v452, nodes, cutoffs[-1:], modes, args.pnt_q, args.prime_chunk
    )
    for k in modes:
        inv_by_mode[k].update(hold_inv[k])
    trans_rows = list(train_trans_rows) + list(hold_trans_rows)
    max_root_resid = max(abs(float(r["secular_residual"])) for r in trans_rows)
    min_abs_FE = min(float(r["abs_F_E"]) for r in trans_rows)
    print("  revealed v456 verdict                :", summary456.get("verdict"))
    print(f"  GLOBAL max endpoint secular residual : {max_root_resid:.6e}")
    print(f"  GLOBAL min endpoint |F_E|            : {min_abs_FE:.6e}")

    holdout_scores: List[dict] = []

    all_blocked = True
    all_component_holdout = True
    all_integrable_exponent = True
    all_fourier_positive = True
    all_omega_growth = True
    all_direct_increment = True
    all_excursion_contract = True
    priority_pass = True

    for k in modes:
        h = holdout_mode_arrays(nodes, detail, k)
        hr = holdout_summary_row(h)
        pm = final_packet_models[k]
        invm = final_invfe_models[k]
        ex = component_exponents(pm, invm)

        # Heldout inverse denominator max at the two endpoints.
        inv_actual = max(inv_by_mode[k][cutoffs[-2]], inv_by_mode[k][cutoffs[-1]])
        val = validate_interval(pm, invm, hr, inv_actual)

        # Allow explicit ratio knob without changing frozen predictions.
        ratios = {}
        for name, (actual, bound) in val["values"].items():
            if name == "omega":
                ratios[name] = bound_ratio(bound, actual)  # lower/actual <= 1
            else:
                ratios[name] = bound_ratio(actual, bound)
        component_holdout = all(
            ratio <= args.maximum_holdout_envelope_ratio for ratio in ratios.values()
        )

        pstar_pass = ex["p_star"] >= 1.0 + args.integrability_margin
        pH_pass = ex["p_fourier"] >= args.minimum_fourier_decay_p
        omega_pass = ex["b_omega"] >= args.minimum_omega_growth_b
        blocked_pass = bool(blocked_results[k]["all"])

        # Direct dyadic endpoint route: p_delta>1 would itself be a sufficient
        # asymptotic target for summable dyadic endpoint increments.  Sampled
        # excursion only needs to shrink (p_excursion>0) to squeeze interiors.
        pdelta = float(pm["increment"]["p"])
        pexc = float(pm["excursion"]["p"])
        direct_inc_pass = pdelta >= 1.0 + args.integrability_margin
        excursion_pass = pexc > 0.0

        all_blocked &= blocked_pass
        all_component_holdout &= component_holdout
        all_integrable_exponent &= pstar_pass
        all_fourier_positive &= pH_pass
        all_omega_growth &= omega_pass
        all_direct_increment &= direct_inc_pass
        all_excursion_contract &= excursion_pass

        mode_pass = bool(
            blocked_pass and component_holdout and pstar_pass and pH_pass and omega_pass
        )
        if k in priority:
            priority_pass &= mode_pass

        holdout_scores.append({
            "mode": k,
            "p_star": fmt(ex["p_star"]),
            "p_carrier": fmt(ex["p_carrier"]),
            "p_residual": fmt(ex["p_residual"]),
            "p_fourier": fmt(ex["p_fourier"]),
            "b_omega": fmt(ex["b_omega"]),
            "a_mass": fmt(ex["a_mass"]),
            "a_R": fmt(ex["a_R"]),
            "a_invFE": fmt(ex["a_invFE"]),
            "p_residual_norm": fmt(ex["p_residual_norm"]),
            "blocked_validation_pass": blocked_pass,
            "holdout_component_pass": component_holdout,
            **{f"ratio_{name}": fmt(ratio) for name, ratio in ratios.items()},
            "actual_abs_delta_E": fmt(hr["abs_delta_E"]),
            "direct_increment_p": fmt(pdelta),
            "direct_increment_integrable_target": direct_inc_pass,
            "actual_sampled_excursion": fmt(hr["sampled_excursion"]),
            "direct_excursion_p": fmt(pexc),
            "sampled_excursion_contract_target": excursion_pass,
            "mechanism_integrability_pass": pstar_pass,
            "fourier_decay_pass": pH_pass,
            "omega_growth_pass": omega_pass,
            "mode_pass": mode_pass,
        })
        print(
            f"  k={k:<3d} p*={ex['p_star']:+.3f} hold={component_holdout} "
            f"pDelta={pdelta:+.3f} pExc={pexc:+.3f} mode_pass={mode_pass}"
        )

    # -------------------------------------------------------------------------
    # E. Global numerical gates / diagnosis.
    # -------------------------------------------------------------------------
    trans_pass = min_abs_FE >= args.minimum_transversality
    root_pass = max_root_resid <= args.maximum_secular_residual
    v456_verdict = str(summary456.get("verdict", ""))
    v456_full = v456_verdict == "STANDARDIZED_PACKET_FOURIER_CANCELLATION_SUPPORTED_PROSPECTIVELY"
    v456_phase = v456_verdict in {
        "STANDARDIZED_PACKET_FOURIER_CANCELLATION_SUPPORTED_PROSPECTIVELY",
        "PACKET_PHASE_LOCK_SUPPORTED__FOURIER_DECAY_NOT_YET_CLOSED",
    }

    if not root_pass:
        verdict = "ROOT_ENDPOINT_CERTIFICATION_FAILED"
    elif not trans_pass:
        verdict = "TRANSVERSALITY_GATE_FAILED"
    elif not all_blocked:
        verdict = "THEOREM_COMPONENT_BLOCKED_VALIDATION_FAILED"
    elif not all_component_holdout:
        verdict = "THEOREM_COMPONENT_HOLDOUT_ENVELOPE_FAILED"
    elif not all_fourier_positive:
        verdict = "PACKET_FOURIER_DECAY_TOO_WEAK"
    elif not all_omega_growth:
        verdict = "ARITHMETIC_FREQUENCY_GROWTH_TOO_WEAK"
    elif not all_integrable_exponent:
        verdict = "PACKET_FOURIER_EXPONENT_NOT_YET_INTEGRABLE"
    elif not v456_phase:
        verdict = "INTEGRABLE_EXPONENT_FOUND__PHASE_LOCK_NOT_SUPPORTED_BY_V456"
    elif v456_full:
        verdict = "CUTOFF_INDEPENDENCE_MECHANISM_SUPPORTED_PROSPECTIVELY"
    else:
        verdict = "INTEGRABLE_EXPONENT_FOUND__FOURIER_HOLDOUT_NEEDS_CLOSURE"

    # A stronger but independent empirical route if both endpoint increments and
    # within-dyadic sampled excursions have favorable training exponents.
    direct_cauchy_route = bool(all_direct_increment and all_excursion_contract)

    score_path = Path(str(prefix) + "_MODE_SCORE.csv")
    exponents_path = Path(str(prefix) + "_EXPONENTS.csv")
    trans_path = Path(str(prefix) + "_ENDPOINT_TRANSVERSALITY.csv")
    write_csv(score_path, holdout_scores)
    write_csv(exponents_path, exponent_rows)
    write_csv(trans_path, trans_rows)

    theorem_text = f"""# ROT-RH v457 — packet-Fourier cutoff-independence theorem target

Numerical verdict: **{verdict}**

Let `L=log X` and let `E_k(L)` be a simple continued bump-2 root branch.
The exact implicit identity is

`E'_k(L) = finitepart_L(E_k(L),L) / (pi F_E(E_k(L),L))`.

Assume that for every fixed mode `k`, for all `L >= L0`, there are positive
constants with

`M_k(L) <= C_M L^(a_M)`,

`R_k(L) <= C_R L^(a_R)`,

`1/|F_E| <= C_D L^(a_D)`,

`Omega_k(L) >= c_O L^(b_O)`,

`|H_k(Omega)| <= C_H Omega^(-p_H)`,

and the normalized phase-lock residual obeys

`eps_k(L) <= C_e L^(-p_e)`.

Then

`|E'_k(L)| <= C1 L^(-p_carrier) + C2 L^(-p_residual)`,

where

`p_carrier = p_H b_O - a_M - a_R - a_D`,

`p_residual = p_e - a_M - a_D`.

Therefore, if

`min(p_carrier,p_residual) > 1`,

then `E'_k` is absolutely integrable on `[L0,infinity)` and `E_k(L)` converges.
This proves cutoff independence for each fixed branch once the six displayed
component inequalities are established analytically for all sufficiently large
`L`.

For operator convergence one then combines branch convergence with the existing
uniform Weyl lower bound / inverse-square envelope to upgrade to the desired
strong-resolvent and trace-class statements.

This v457 run is a finite prospective audit of the theorem hypotheses.  It is
not itself an all-L proof, exact Fredholm identity proof, or RH proof.
"""
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    theorem_path.write_text(theorem_text, encoding="utf-8")

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "v456_verdict": v456_verdict,
        "pre_holdout_freeze_sha256": freeze_sha,
        "cutoffs": cutoffs,
        "modes": modes,
        "priority_modes": priority,
        "training_root_endpoint_max_secular_residual": train_max_root_resid,
        "training_minimum_endpoint_abs_F_E": train_min_abs_FE,
        "root_endpoint_max_secular_residual": max_root_resid,
        "root_endpoint_pass": root_pass,
        "minimum_endpoint_abs_F_E": min_abs_FE,
        "transversality_pass": trans_pass,
        "all_blocked_component_validation_pass": all_blocked,
        "all_holdout_component_envelopes_pass": all_component_holdout,
        "all_fourier_decay_gates_pass": all_fourier_positive,
        "all_omega_growth_gates_pass": all_omega_growth,
        "all_mechanism_integrability_exponents_pass": all_integrable_exponent,
        "priority_modes_pass": priority_pass,
        "direct_dyadic_cauchy_route_supported_prospectively": direct_cauchy_route,
        "all_direct_increment_exponents_integrable": all_direct_increment,
        "all_sampled_excursion_exponents_contract": all_excursion_contract,
        "mode_scores": holdout_scores,
        "scientific_boundary": (
            "Finite prospective theorem-mechanism evidence only. A cutoff-independence proof "
            "requires all-L analytic bounds for packet mass, phase amplitude, transversality, "
            "Omega growth, Fourier decay, and phase-lock residual."
        ),
        "outputs": {
            "freeze": str(freeze_path),
            "mode_score": str(score_path),
            "exponents": str(exponents_path),
            "transversality": str(trans_path),
            "theorem": str(theorem_path),
        },
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    print("\n" + "="*188)
    print("KEY RESULTS")
    print("="*188)
    print("verdict                                  :", verdict)
    print("v456 verdict                             :", v456_verdict)
    print("v457 pre-holdout freeze SHA256           :", freeze_sha)
    print(f"max endpoint secular residual            : {max_root_resid:.6e} pass={root_pass}")
    print(f"minimum endpoint |F_E|                   : {min_abs_FE:.6e} pass={trans_pass}")
    print("blocked component validation all modes   :", all_blocked)
    print("holdout component envelopes all modes    :", all_component_holdout)
    print("Fourier decay gate all modes             :", all_fourier_positive)
    print("Omega growth gate all modes              :", all_omega_growth)
    print("mechanism p*>1+margin all modes          :", all_integrable_exponent)
    print("priority modes pass                      :", priority_pass, priority)
    print("direct dyadic Cauchy route prospective   :", direct_cauchy_route)
    print("mode exponents:")
    for r in holdout_scores:
        print(
            f"  k={int(r['mode']):<3d} p*={float(r['p_star']):+.4f} "
            f"pC={float(r['p_carrier']):+.4f} pR={float(r['p_residual']):+.4f} "
            f"pH={float(r['p_fourier']):+.4f} bO={float(r['b_omega']):+.4f} "
            f"pDelta={float(r['direct_increment_p']):+.4f} pass={r['mode_pass']}"
        )
    print("summary                                  :", summary_path)
    print("theorem target                           :", theorem_path)
    print("="*188)

    good = verdict in {
        "CUTOFF_INDEPENDENCE_MECHANISM_SUPPORTED_PROSPECTIVELY",
        "INTEGRABLE_EXPONENT_FOUND__FOURIER_HOLDOUT_NEEDS_CLOSURE",
        "INTEGRABLE_EXPONENT_FOUND__PHASE_LOCK_NOT_SUPPORTED_BY_V456",
    }
    if args.strict and not good:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
