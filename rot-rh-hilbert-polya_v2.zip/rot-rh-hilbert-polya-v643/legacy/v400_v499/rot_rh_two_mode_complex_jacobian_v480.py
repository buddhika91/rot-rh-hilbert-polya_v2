#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v480 — TWO-MODE COMPLEX CANCELLATION JACOBIAN TRANSVERSALITY
==================================================================

PURPOSE
-------
Strengthen v479 from relative-phase velocity to the full complex two-mode
cancellation geometry.

Let
    R(L,E)=log[K_1(L,E)/K_2(L,E)]
          =U(L,E)+iV(L,E).

A two-mode exact cancellation
    A_1 K_1 + A_2 K_2 = 0
with fixed nonzero prefactors A_j requires TWO real equations:

    U = log|A_2/A_1|,
    V = arg(-A_2/A_1) mod 2pi.

The local geometry is controlled by

    J = det d(U,V)/d(L,E)
      = U_L V_E - U_E V_L.

For a comparable high-ordinate pair with common
    lambda ~ i Gamma,
    DeltaGamma !=0,
    Delta a=o(DeltaGamma),

v473/v479 give

    R_L = i DeltaGamma [1+o(1)],

and

    R_E
      = (2^(1/3)/3)
          L^(2/3)
          lambda^(-4/3)
          DeltaGamma
          [1+o(1)].

Since
    (i Gamma)^(-4/3)
      = (-1/2-i sqrt(3)/2) Gamma^(-4/3),

we get

    U_E
      = -[2^(1/3)/6]
          L^(2/3) DeltaGamma Gamma^(-4/3)
          [1+o(1)],

    V_E
      = -[2^(1/3)sqrt(3)/6]
          L^(2/3) DeltaGamma Gamma^(-4/3)
          [1+o(1)],

    U_L=o(DeltaGamma),
    V_L=DeltaGamma[1+o(1)].

Therefore

    J
      = [2^(1/3)/6]
          L^(2/3)
          (DeltaGamma)^2
          Gamma^(-4/3)
          [1+o(1)]
      >0.

CONSEQUENCES
------------
1. The amplitude-equality and phase-cancellation contours cross transversely.

2. Exact two-mode cancellation points are locally ISOLATED in (L,E).

3. The inverse conditioning scale is

       J^(-1)
         asymp
       Gamma^(4/3) /
       [L^(2/3)(DeltaGamma)^2].

4. Pairwise cancellation cannot itself form the persistent exceptional
   diagonal needed by v411.

5. A sequence of isolated pair crossings can still occur, but between crossings
   the branch must be supported by some other modes. Combined with v479, no
   single pair can transport an O(L^-2) convergent branch over a late interval.

Thus the surviving nonattained mechanism requires simultaneous participation
of at least three modes and, in view of v476-v478/v477, ultimately a genuinely
many-mode superoscillatory family.

This theorem is asymptotic/conditional on the v473 sectorial saddle expansion
and the comparable-pair regime. It does not exclude degenerate multi-mode
Jacobians.

No Xi, zeta numerical values, known zero ordinates, RH, or simple zeros are
used.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v480-two-mode-complex-jacobian"

A = 2.0**(1.0/3.0)
JCONST = A/6.0


def symbolic_check() -> Dict[str, Any]:
    import sympy as sp
    A0, L, dg, G = sp.symbols(
        "A L dg G", positive=True, real=True
    )
    UE = -A0/6 * L**sp.Rational(2,3)*dg*G**(-sp.Rational(4,3))
    VE = -A0*sp.sqrt(3)/6 * L**sp.Rational(2,3)*dg*G**(-sp.Rational(4,3))
    UL = sp.Integer(0)
    VL = dg
    J = sp.simplify(UL*VE-UE*VL)
    expected = A0/6*L**sp.Rational(2,3)*dg**2*G**(-sp.Rational(4,3))
    return {
        "Jacobian": str(J),
        "expected": str(expected),
        "residual": str(sp.simplify(J-expected)),
        "pass": bool(sp.simplify(J-expected) == 0),
    }


def psi_prime(z: complex) -> complex:
    c1 = 2.0**(2.0/3.0)
    return (
        1.0
        - A*z**(-1.0/3.0)
        + (c1/3.0)*z**(-2.0/3.0)
        - (2.0/3.0)/z
    )


def numerical_jacobian(L: float, G: float, dG: float, E: float = 20.0, a: float = 0.20):
    l1 = complex(a, G+0.5*dG-E)
    l2 = complex(a, G-0.5*dG-E)
    z1 = L*l1
    z2 = L*l2

    RL = l1*psi_prime(z1)-l2*psi_prime(z2)
    RE = -1j*L*(psi_prime(z1)-psi_prime(z2))

    UL, VL = RL.real, RL.imag
    UE, VE = RE.real, RE.imag
    J = UL*VE-UE*VL
    pred = JCONST*L**(2.0/3.0)*dG*dG*G**(-4.0/3.0)

    return {
        "L": L,
        "Gamma": G,
        "DeltaGamma": dG,
        "U_L": UL,
        "V_L": VL,
        "U_E": UE,
        "V_E": VE,
        "Jacobian": J,
        "prediction": pred,
        "ratio": J/pred,
        "inverse_conditioning": 1.0/abs(J),
    }


def panel():
    return [
        numerical_jacobian(1e3, 50.0, 1.0),
        numerical_jacobian(1e4, 100.0, 1.0),
        numerical_jacobian(1e5, 250.0, 1.0),
        numerical_jacobian(1e6, 500.0, 1.0),
    ]


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v480 — two-mode complex cancellation Jacobian transversality

For

`R=log(K_1/K_2)=U+iV`,

a two-mode exact cancellation imposes one amplitude equation and one phase
equation. Their `(L,E)` Jacobian is

`J=U_L V_E-U_E V_L`.

In the comparable high-ordinate regime,

`R_L=i DeltaGamma[1+o(1)]`

and

`R_E
 =(2^(1/3)/3)L^(2/3)
  (iGamma)^(-4/3)DeltaGamma[1+o(1)]`.

Thus

`J
 =[2^(1/3)/6]
  L^(2/3)(DeltaGamma)^2 Gamma^(-4/3)
  [1+o(1)] >0`.

Therefore the two cancellation equations meet transversely and exact pair
cancellations are locally isolated.

**Verdict:** {payload['verdict']}

Together with v479, an isolated pair cannot provide the persistent late
transport channel needed by v411. The unresolved mechanism must be degenerate
many-mode collective cancellation.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_TWO_MODE_COMPLEX_JACOBIAN_V1",
        "closed": {
            "Jacobian":
                "2^(1/3)/6 L^(2/3)(DeltaGamma)^2 Gamma^(-4/3)[1+o(1)]",
            "transverse": "pair amplitude and phase contours cross transversely",
            "isolated": "exact two-mode cancellations are locally isolated",
            "pair_transport": "cannot supply a persistent v411 phase-lock channel",
        },
        "remaining":
            "degenerate three-or-more-mode / genuinely many-mode arithmetic superoscillation",
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="rot_rh_two_mode_complex_jacobian_v480")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*196)
    print("ROT-RH v480 — TWO-MODE COMPLEX CANCELLATION JACOBIAN TRANSVERSALITY")
    print("="*196)
    with tqdm(total=2, desc="v480 theorem", unit="step") as bar:
        sym = symbolic_check()
        bar.update(1)
        rows = panel()
        bar.update(1)

    diag = abs(rows[-1]["ratio"]-1.0) < 0.20 and rows[-1]["Jacobian"] > 0
    passed = bool(sym["pass"] and diag)
    verdict = (
        "TWO_MODE_COMPLEX_CANCELLATION_JACOBIAN_TRANSVERSALITY_PASS"
        if passed else
        "TWO_MODE_COMPLEX_JACOBIAN_ASYMPTOTIC_CHECK_INCOMPLETE"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic_panel": rows,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "diagnostic_used_as_proof": False,
        },
        "proof_status":
            "Comparable-pair asymptotic theorem derived from v473 saddle. It excludes persistent pair-controlled cancellation, not many-mode degeneracy.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("symbolic                        :", sym["pass"])
    print("last Jacobian ratio             :", f"{rows[-1]['ratio']:.8f}")
    print("last Jacobian                   :", f"{rows[-1]['Jacobian']:.8e}")
    print("last inverse conditioning       :", f"{rows[-1]['inverse_conditioning']:.8e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
