#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v443 — UNIFORM ALL-MODE DYADIC DISPLACEMENT / TRACE-TAIL BRIDGE
=====================================================================

PURPOSE
-------
Audit the exact theorem-shaped condition that promotes the fixed-mode v438
cutoff-removal mechanism to a UNIFORM-IN-MODE displacement theorem.

Let L = log X, h = log 2, and let E_{k,L} denote the zero-blind arithmetic
level on a dyadic cutoff ladder L_n = L_0 + n h.

The direct sufficient theorem is

    U_STEP:
        |E_{k,L+h} - E_{k,L}| <= C_E / [L(L+h)]

uniformly in k and all sufficiently large dyadic L.

Then exactly,

    sum_{n=0}^{N-1} 1/[L_n L_{n+1}]
      = (1/h)(1/L_0 - 1/L_N)
      <= 1/(h L_0),

so

    sup_{k,N} |E_{k,L_N} - E_{k,L_0}|
      <= C_E/(h L_0).

This is the moving-cutoff term required by v236/v238.

Connection to v438
-------------------
v438 gives the exact mean-value identity

    E_{k,L+h} - E_{k,L}
      = - Delta_h F_L(E_{k,L}) / F'_{L+h}(xi_{k,L}).

Therefore the two UNIFORM all-mode statements

    |L Delta_h F_L(E_{k,L})| <= C_F,
    F'_{L+h}(xi_{k,L})/(L+h) >= c > 0

imply U_STEP with

    C_E = C_F/c.

The present script audits U_STEP DIRECTLY from a zero-blind root table.
If phase_derivative is present it also audits endpoint stiffness ratios, but
endpoint stiffness is only a diagnostic: it is NOT a proof of the required
whole-segment secant/tube transversality.

Fixed-reference term
--------------------
Let A_k be the free Archimedean level. v238 analytically proves, for every
fixed finite reference cutoff L_0,

    D_0 := sup_k |E_{k,L_0} - A_k| < infinity.

Hence U_STEP implies

    sup_{k,L_n} |E_{k,L_n} - A_k|
      <= D_0 + C_E/(h L_0) < infinity.

Then v232/v235 transfer the free Weyl bound to an eventual arithmetic bound

    E_{k,L} >= k/log(k+e),

which yields

    sup_L sum_{k>N} E_{k,L}^{-2}
      <= sum_{k>N} [log(k+e)/k]^2 -> 0.

Combined with fixed-mode convergence, dominated convergence gives

    ||H_L^{-2} - H_infinity^{-2}||_1 -> 0.

SCIENTIFIC BOUNDARY
-------------------
This script is a finite zero-blind theorem-premise audit. It does NOT prove
the all-L/all-k U_STEP bound, the all-mode v438 transfer theorem, RH, or the
Xi Fredholm identity.

No Xi evaluations.
No zeta evaluations.
No known zero ordinates.
No root solves.
No prime rebuild.

The intended input is a zero-blind root table containing at least
    cutoff, index, energy
and optionally
    phase_derivative, free_level, free_displacement, quantization_residual.

Includes tqdm progress bars and only O(number_of_rows) dataframe work.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v443 requires tqdm: pip install tqdm") from exc

VERSION = 443
H = math.log(2.0)
EE = math.e
EPS = 1.0e-300


def csv_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def canonicalize(df: pd.DataFrame) -> pd.DataFrame:
    aliases = {
        "cutoff": ["cutoff", "X", "xcut", "regulator", "Lcut"],
        "mode": ["index", "k", "mode", "root_index", "level"],
        "energy": ["energy", "E", "root", "eigenvalue", "eig", "lambda"],
    }

    out = df.copy()
    rename = {}
    for target, names in aliases.items():
        if target in out.columns:
            continue
        hit = next((x for x in names if x in out.columns), None)
        if hit is None:
            raise KeyError(f"Could not locate required column {target!r}; columns={list(out.columns)}")
        rename[hit] = target

    out = out.rename(columns=rename)

    # If both a pandas-export index and a scientific "index" existed, pandas may
    # already have disambiguated them. Keep only the canonical scientific mode.
    need = ["cutoff", "mode", "energy"]
    for c in need:
        out[c] = pd.to_numeric(out[c], errors="coerce")

    out = out[
        np.isfinite(out["cutoff"])
        & np.isfinite(out["mode"])
        & np.isfinite(out["energy"])
        & (out["cutoff"] > 1)
        & (out["energy"] > 0)
    ].copy()

    out["cutoff"] = out["cutoff"].astype(np.int64)
    out["mode"] = out["mode"].astype(np.int64)

    # Conservative deduplication: first deterministic row after sorting.
    out = (
        out.sort_values(["cutoff", "mode", "energy"])
        .drop_duplicates(["cutoff", "mode"], keep="first")
        .reset_index(drop=True)
    )
    return out


def tail_majorant(N: int, c: float = 1.0) -> float:
    """
    For N>=3:
      sum_{k>N} [log(k+e)/k]^2
        <= [(log N+d)^2 + 2(log N+d)+2]/N,
      d=log(1+e/N).
    Multiply by c^-2.
    """
    N = int(N)
    if N < 3 or c <= 0:
        return float("inf")
    d = math.log1p(EE / float(N))
    u = math.log(float(N)) + d
    return (u*u + 2.0*u + 2.0) / (float(N) * c*c)


def minimum_k_for_displacement(D: float) -> int:
    """
    v232 gives A_k >= 2 k/log(k+e), k>=6.
    If |E-A|<=D and k/log(k+e)>=D, then E>=k/log(k+e).
    """
    if not np.isfinite(D) or D < 0:
        return -1
    k = 6
    while k / math.log(k + EE) < D:
        k += 1
        if k > 10**9:
            return -1
    return k


def native(x):
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, list):
        return [native(v) for v in x]
    if isinstance(x, tuple):
        return [native(v) for v in x]
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, float) and not math.isfinite(x):
        return None
    return x


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots",
        default="rot_rh_direct_riesz1_depth320_roots.csv",
        help="Zero-blind root table.",
    )
    ap.add_argument(
        "--development-pairs",
        type=int,
        default=3,
        help="Earliest dyadic pairs used to freeze the finite C_E diagnostic.",
    )
    ap.add_argument(
        "--step-safety",
        type=float,
        default=1.25,
        help="C_E_safe = safety * max development L(L+h)|Delta E|.",
    )
    ap.add_argument(
        "--endpoint-slope-safety",
        type=float,
        default=0.90,
        help="Diagnostic endpoint c_safe = safety * min development F'/log X.",
    )
    ap.add_argument(
        "--dyadic-log-tol",
        type=float,
        default=5e-12,
        help="Maximum |log(Xb/Xa)-log2| for a pair.",
    )
    ap.add_argument(
        "--tail-N-values",
        default="32,64,128,256,512,1024,4096,16384,65536",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_uniform_allmode_dyadic_displacement_v443",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    roots_path = Path(args.roots)
    if not roots_path.exists():
        raise FileNotFoundError(roots_path)

    print("=" * 196)
    print("ROT-RH v443 — UNIFORM ALL-MODE DYADIC DISPLACEMENT / TRACE-TAIL BRIDGE")
    print("=" * 196)
    print("Xi / zeta / known zeros              : NONE")
    print("root solves / prime rebuild           : NONE / NONE")
    print("input                                 :", roots_path)
    print("=" * 196)

    raw = pd.read_csv(roots_path)
    df = canonicalize(raw)
    cutoffs = np.asarray(sorted(df["cutoff"].unique()), dtype=np.int64)
    if len(cutoffs) < 3:
        raise RuntimeError("Need at least three distinct cutoffs.")

    pair_rows: List[Dict] = []
    mode_rows: List[Dict] = []

    pairs = list(zip(cutoffs[:-1], cutoffs[1:]))
    for pair_index, (Xa, Xb) in enumerate(
        tqdm(pairs, desc="Auditing dyadic all-mode pairs", unit="pair")
    ):
        a = df[df["cutoff"] == Xa].set_index("mode", drop=False)
        b = df[df["cutoff"] == Xb].set_index("mode", drop=False)
        common = np.asarray(sorted(set(a.index).intersection(b.index)), dtype=np.int64)
        if len(common) == 0:
            continue

        L0 = math.log(float(Xa))
        L1 = math.log(float(Xb))
        h = L1 - L0

        Ea = a.loc[common, "energy"].to_numpy(float)
        Eb = b.loc[common, "energy"].to_numpy(float)
        dE = Eb - Ea
        scaled = np.abs(dE) * L0 * L1

        has_slope = "phase_derivative" in a.columns and "phase_derivative" in b.columns
        if has_slope:
            slope_a = pd.to_numeric(a.loc[common, "phase_derivative"], errors="coerce").to_numpy(float)
            slope_b = pd.to_numeric(b.loc[common, "phase_derivative"], errors="coerce").to_numpy(float)
            slope_ratio_a = slope_a / L0
            slope_ratio_b = slope_b / L1
            finite_slope = np.isfinite(slope_ratio_a) & np.isfinite(slope_ratio_b)
            min_endpoint_slope_ratio = (
                float(np.min(np.minimum(slope_ratio_a[finite_slope], slope_ratio_b[finite_slope])))
                if np.any(finite_slope) else float("nan")
            )
        else:
            slope_ratio_a = np.full(len(common), np.nan)
            slope_ratio_b = np.full(len(common), np.nan)
            min_endpoint_slope_ratio = float("nan")

        for j, k in enumerate(common):
            mode_rows.append(
                {
                    "pair_index": pair_index,
                    "Xa": int(Xa),
                    "Xb": int(Xb),
                    "L0": L0,
                    "L1": L1,
                    "h": h,
                    "mode": int(k),
                    "Ea": float(Ea[j]),
                    "Eb": float(Eb[j]),
                    "delta_E": float(dE[j]),
                    "abs_delta_E": float(abs(dE[j])),
                    "scaled_step_L0L1_abs_delta_E": float(scaled[j]),
                    "endpoint_slope_over_L0": float(slope_ratio_a[j]),
                    "endpoint_slope_over_L1": float(slope_ratio_b[j]),
                }
            )

        pair_rows.append(
            {
                "pair_index": pair_index,
                "Xa": int(Xa),
                "Xb": int(Xb),
                "L0": L0,
                "L1": L1,
                "h": h,
                "dyadic_log_error": abs(h - H),
                "common_modes": int(len(common)),
                "max_abs_delta_E": float(np.max(np.abs(dE))),
                "rms_delta_E": float(np.sqrt(np.mean(dE*dE))),
                "median_scaled_step": float(np.median(scaled)),
                "q95_scaled_step": float(np.quantile(scaled, 0.95)),
                "q99_scaled_step": float(np.quantile(scaled, 0.99)),
                "max_scaled_step": float(np.max(scaled)),
                "min_endpoint_slope_ratio": min_endpoint_slope_ratio,
            }
        )

    pair_df = pd.DataFrame(pair_rows)
    mode_df = pd.DataFrame(mode_rows)
    if pair_df.empty:
        raise RuntimeError("No adjacent cutoff pairs had common modes.")

    dyadic_pairs = pair_df[pair_df["dyadic_log_error"] <= args.dyadic_log_tol].copy()
    if len(dyadic_pairs) < 2:
        raise RuntimeError("Too few genuinely dyadic adjacent pairs.")

    ndev = min(max(1, int(args.development_pairs)), len(dyadic_pairs)-1)
    dev = dyadic_pairs.iloc[:ndev].copy()
    hold = dyadic_pairs.iloc[ndev:].copy()

    C_E_train = float(dev["max_scaled_step"].max())
    C_E_safe = float(args.step_safety) * C_E_train
    hold_max_scaled = float(hold["max_scaled_step"].max()) if not hold.empty else float("nan")
    step_holdout_pass = bool(
        not hold.empty and np.isfinite(hold_max_scaled) and hold_max_scaled <= C_E_safe
    )

    slope_available = bool(np.isfinite(dev["min_endpoint_slope_ratio"]).any())
    if slope_available:
        c_dev = float(dev["min_endpoint_slope_ratio"].min())
        c_endpoint_safe = float(args.endpoint_slope_safety) * c_dev
        c_hold = (
            float(hold["min_endpoint_slope_ratio"].min())
            if not hold.empty else float("nan")
        )
        endpoint_holdout_pass = bool(
            not hold.empty and np.isfinite(c_hold) and c_hold >= c_endpoint_safe
        )
    else:
        c_dev = c_endpoint_safe = c_hold = float("nan")
        endpoint_holdout_pass = False

    # Direct telescoping theorem candidate.
    X0 = int(cutoffs[0])
    Lref = math.log(float(X0))
    B_moving_bound = C_E_safe / (H * Lref)

    ref = df[df["cutoff"] == X0].set_index("mode")
    ref_energy = ref["energy"]
    observed_max_ref_shift = 0.0
    observed_worst = None

    ref_rows = []
    for X in tqdm(cutoffs, desc="Checking reference displacement", unit="cutoff"):
        g = df[df["cutoff"] == X].set_index("mode")
        common = ref_energy.index.intersection(g.index)
        if len(common) == 0:
            continue
        shifts = (g.loc[common, "energy"] - ref_energy.loc[common]).abs()
        imax = shifts.idxmax()
        m = float(shifts.loc[imax])
        ref_rows.append({
            "cutoff": int(X),
            "L": math.log(float(X)),
            "common_modes": int(len(common)),
            "max_abs_shift_from_reference": m,
            "worst_mode": int(imax),
            "theorem_candidate_bound": B_moving_bound,
            "margin": B_moving_bound / max(m, EPS),
        })
        if m > observed_max_ref_shift:
            observed_max_ref_shift = m
            observed_worst = (int(X), int(imax), m)

    ref_df = pd.DataFrame(ref_rows)
    moving_bound_finite_data_pass = bool(
        observed_max_ref_shift <= B_moving_bound
    )

    # Fixed-reference numerical displacement is only a diagnostic. v238 gives
    # the qualitative analytic finiteness theorem.
    if "free_displacement" in ref.columns:
        ref_free_disp = pd.to_numeric(ref["free_displacement"], errors="coerce").to_numpy(float)
        D0_observed = float(np.nanmax(np.abs(ref_free_disp)))
    elif "free_level" in ref.columns:
        free_level = pd.to_numeric(ref["free_level"], errors="coerce").to_numpy(float)
        D0_observed = float(np.nanmax(np.abs(ref["energy"].to_numpy(float) - free_level)))
    else:
        D0_observed = float("nan")

    D_global_candidate = (
        D0_observed + B_moving_bound
        if np.isfinite(D0_observed) else float("nan")
    )
    candidate_k0 = (
        minimum_k_for_displacement(D_global_candidate)
        if np.isfinite(D_global_candidate) else -1
    )

    tail_rows = []
    for N in csv_ints(args.tail_N_values):
        tail_rows.append(
            {
                "N": int(N),
                "single_operator_tail_majorant_c1": tail_majorant(N, 1.0),
                "pairwise_two_operator_tail_majorant_c1": 2.0 * tail_majorant(N, 1.0),
            }
        )
    tail_df = pd.DataFrame(tail_rows)

    max_dyadic_error = float(dyadic_pairs["dyadic_log_error"].max())
    all_pairs_same_mode_count = bool(dyadic_pairs["common_modes"].min() > 0)
    all_quantization_residuals_ok = None
    max_quant_resid = None
    if "quantization_residual" in df.columns:
        q = pd.to_numeric(df["quantization_residual"], errors="coerce").to_numpy(float)
        q = np.abs(q[np.isfinite(q)])
        if len(q):
            max_quant_resid = float(np.max(q))
            all_quantization_residuals_ok = bool(max_quant_resid <= 1e-9)

    gates = {
        "dyadic_ladder_exact_within_tolerance": bool(max_dyadic_error <= args.dyadic_log_tol),
        "common_modes_exist_on_all_pairs": all_pairs_same_mode_count,
        "development_C_E_finite_positive": bool(np.isfinite(C_E_safe) and C_E_safe > 0),
        "prospective_scaled_step_holdout_pass": step_holdout_pass,
        "finite_observed_reference_shift_below_telescoping_bound": moving_bound_finite_data_pass,
    }
    if all_quantization_residuals_ok is not None:
        gates["quantization_residuals_small"] = all_quantization_residuals_ok

    failed = [k for k, v in gates.items() if not v]
    verdict = (
        "UNIFORM_ALLMODE_DYADIC_DISPLACEMENT_STRONGLY_SUPPORTED_THEOREM_PREMISE_OPEN"
        if not failed
        else
        "UNIFORM_ALLMODE_DYADIC_DISPLACEMENT_TARGET_UNRESOLVED"
    )

    prefix = Path(args.prefix)
    pair_path = Path(str(prefix) + "_PAIRS.csv")
    mode_path = Path(str(prefix) + "_MODES.csv.gz")
    ref_path = Path(str(prefix) + "_REFERENCE.csv")
    tail_path = Path(str(prefix) + "_TAIL_MAJORANTS.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    pair_df.to_csv(pair_path, index=False)
    mode_df.to_csv(mode_path, index=False, compression="gzip")
    ref_df.to_csv(ref_path, index=False)
    tail_df.to_csv(tail_path, index=False)

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "root_solves": False,
            "prime_rebuild": False,
        },
        "input": str(roots_path),
        "rows": int(len(df)),
        "cutoffs": cutoffs.tolist(),
        "mode_min": int(df["mode"].min()),
        "mode_max": int(df["mode"].max()),
        "distinct_modes": int(df["mode"].nunique()),
        "dyadic": {
            "h_log2": H,
            "maximum_log_ratio_error": max_dyadic_error,
            "pairs": int(len(dyadic_pairs)),
        },
        "finite_uniform_step_audit": {
            "development_pairs": int(ndev),
            "development_max_scaled_step": C_E_train,
            "step_safety": float(args.step_safety),
            "frozen_C_E_safe": C_E_safe,
            "holdout_max_scaled_step": hold_max_scaled,
            "holdout_margin_C_over_max": C_E_safe / max(hold_max_scaled, EPS),
            "holdout_pass": step_holdout_pass,
            "meaning": "finite evidence for |Delta E| <= C_E/[L(L+h)] uniformly over audited modes",
        },
        "endpoint_transversality_diagnostic": {
            "available": slope_available,
            "development_min_endpoint_Fprime_over_L": c_dev,
            "safety_fraction": float(args.endpoint_slope_safety),
            "frozen_endpoint_c_safe": c_endpoint_safe,
            "holdout_min_endpoint_Fprime_over_L": c_hold,
            "holdout_pass": endpoint_holdout_pass,
            "warning": (
                "Endpoint slopes do not prove the v438 whole-segment MVT/secant floor. "
                "They are a diagnostic only."
            ),
        },
        "telescoping_promotion": {
            "reference_cutoff_X0": X0,
            "reference_L0_logX": Lref,
            "identity": (
                "sum_n 1/[L_n L_(n+1)] = (1/log2)(1/L0-1/LN)"
            ),
            "conditional_uniform_moving_bound": B_moving_bound,
            "maximum_observed_shift_from_reference": observed_max_ref_shift,
            "worst_observed": observed_worst,
            "finite_data_pass": moving_bound_finite_data_pass,
        },
        "free_displacement_transfer": {
            "v238_analytic_input": "For fixed finite L0, D0=sup_k|E_k(L0)-A_k|<infinity.",
            "observed_D0_at_reference_not_proof": D0_observed,
            "numerical_global_D_candidate": D_global_candidate,
            "candidate_k0_using_v232_Ak_ge_2k_log_inverse": candidate_k0,
            "consequence_if_all_scale_U_STEP_proved": (
                "sup_{k,L}|E_k(L)-A_k|<infinity, hence eventual "
                "E_k(L)>=k/log(k+e) and uniform inverse-square tail tightness."
            ),
        },
        "trace_tail": {
            "consequence": (
                "With fixed-mode convergence, the uniform Weyl lower bound gives "
                "||H_L^-2-H_inf^-2||_1 -> 0 by dominated convergence."
            ),
            "tail_majorants": tail_rows,
        },
        "quantization": {
            "maximum_abs_residual": max_quant_resid,
        },
        "gates": gates,
        "failed_gates": failed,
        "proof_status": (
            "FINITE ZERO-BLIND EVIDENCE ONLY. The exact promotion theorem is proved "
            "algebraically, but its all-L/all-k U_STEP premise remains open. "
            "A non-circular proof should establish U_STEP along moving arithmetic "
            "characteristics, e.g. from uniform v438 signed transfer plus uniform "
            "whole-segment transversality, without replacing the moving characteristic "
            "by a stronger fixed-energy prefix theorem."
        ),
        "runtime_seconds": time.time() - started,
    }
    summary_path.write_text(json.dumps(native(summary), indent=2), encoding="utf-8")

    theorem = f"""# ROT-RH v443 — uniform all-mode dyadic displacement theorem

## Setup

Let

`L_n = L_0 + n h`, with `h = log 2`,

and let `E_(k,n)` be the same arithmetic mode at cutoff `X_n=exp(L_n)`.

The finite audit used `{len(dyadic_pairs)}` dyadic pairs and
`{int(df["mode"].nunique())}` modes, with no Xi, zeta, or known-zero input.

## Theorem U_STEP -> uniform moving displacement

Assume there is one constant `C_E < infinity`, independent of both `k` and `n`,
such that eventually

`|E_(k,n+1)-E_(k,n)| <= C_E/[L_n L_(n+1)]`.

Then

`1/[L_n L_(n+1)]
   = (1/h)[1/L_n - 1/L_(n+1)]`.

Therefore, for every `N`,

`|E_(k,N)-E_(k,0)|
 <= C_E sum_(n<N) 1/[L_n L_(n+1)]
 = (C_E/h)[1/L_0 - 1/L_N]
 <= C_E/(h L_0)`.

The bound is independent of `k`. Hence

`sup_(k,N)|E_(k,N)-E_(k,0)| <= C_E/(h L_0) < infinity`.

This is exactly the moving-cutoff theorem left open by v236/v238.

## v438 reduction to U_STEP

The exact v438 mean-value identity is

`E_(k,L+h)-E_(k,L)
 = -Delta_h F_L(E_(k,L))/F'_(L+h)(xi_(k,L))`.

Thus the two all-mode hypotheses

`sup_(k,L)|L Delta_h F_L(E_(k,L))| <= C_F < infinity`

and

`inf_(k,L) F'_(L+h)(xi_(k,L))/(L+h) >= c > 0`

imply

`|Delta E_(k,L)| <= (C_F/c)/[L(L+h)]`.

So U_STEP holds with

`C_E = C_F/c`.

This is a moving-characteristic theorem. It does not require a uniform
fixed-energy prime-prefix bound.

## Fixed-reference Archimedean term

v238 analytically establishes, at any one fixed finite reference cutoff `L_0`,

`D_0 := sup_k |E_(k,L_0)-A_k| < infinity`,

where `A_k` is the free Gamma/Archimedean level.

Combining with U_STEP,

`sup_(k,N)|E_(k,L_N)-A_k|
 <= D_0 + C_E/(h L_0) < infinity`.

This is the v235 uniform free-level displacement theorem.

## Trace-tail consequence

v232 gives eventually

`A_k >= 2k/log(k+e)`.

Let

`D = D_0 + C_E/(hL_0)`.

For sufficiently large `k`, `k/log(k+e) >= D`, so

`E_(k,L) >= k/log(k+e)` uniformly in cutoff.

Therefore

`E_(k,L)^(-2) <= [log(k+e)/k]^2`,

and the right side is summable. Hence

`sup_L sum_(k>N) E_(k,L)^(-2) -> 0`.

If, in addition, v438 is promoted to fixed-mode convergence for every fixed `k`,
then dominated convergence gives

`||K_L-K_infinity||_1 -> 0`,

for `K_L=H_L^(-2)`.

## Finite v443 audit

Development-only frozen constant:

`C_E_safe = {C_E_safe:.15g}`.

Holdout maximum of `L(L+h)|Delta E|`:

`{hold_max_scaled:.15g}`.

Holdout pass:

`{step_holdout_pass}`.

Conditional telescoping moving bound from the frozen finite constant:

`C_E_safe/(log(2)L_0) = {B_moving_bound:.15g}`.

Maximum observed displacement from the reference cutoff:

`{observed_max_ref_shift:.15g}`.

Observed reference free displacement maximum (diagnostic only):

`{D0_observed:.15g}`.

Numerical global displacement candidate:

`{D_global_candidate:.15g}`.

## Logical status

The algebraic implication

`U_STEP => uniform moving displacement => uniform free displacement => T_TAIL`

is proved.

What is **not** proved is the all-scale premise U_STEP itself.

The clean non-circular next theorem is therefore either:

1. prove U_STEP directly on the moving arithmetic root characteristics; or
2. prove the uniform all-mode v438 pair:
   `|L Delta_h F| <= C_F` and whole-segment `F'/L >= c>0`.

Endpoint `F'/L` values in the finite table are supporting diagnostics only and
must not be promoted to the whole-segment transversality theorem.

This is not an RH proof and does not establish the Xi Fredholm identity.
"""
    theorem_path.write_text(theorem, encoding="utf-8")

    print()
    print("DYADIC PAIR SUMMARY")
    print("-" * 196)
    show = [
        "Xa", "Xb", "common_modes", "max_abs_delta_E",
        "q99_scaled_step", "max_scaled_step", "min_endpoint_slope_ratio"
    ]
    print(pair_df[show].to_string(index=False))
    print()
    print("FINITE UNIFORM STEP")
    print("-" * 196)
    print(f"development max L(L+h)|dE|        : {C_E_train:.12e}")
    print(f"frozen C_E safe                    : {C_E_safe:.12e}")
    print(f"holdout max L(L+h)|dE|             : {hold_max_scaled:.12e}")
    print(f"holdout C/max margin                : {C_E_safe/max(hold_max_scaled,EPS):.9f}")
    print(f"holdout pass                        : {step_holdout_pass}")
    print()
    print("TELESCOPING PROMOTION")
    print("-" * 196)
    print(f"reference X0                       : {X0}")
    print(f"conditional moving bound           : {B_moving_bound:.12e}")
    print(f"observed max reference shift        : {observed_max_ref_shift:.12e}")
    print(f"observed bound/shift margin         : {B_moving_bound/max(observed_max_ref_shift,EPS):.9f}")
    print(f"observed reference free D0          : {D0_observed:.12e}")
    print(f"numerical global D candidate        : {D_global_candidate:.12e}")
    print(f"candidate eventual k0               : {candidate_k0}")
    print()
    print("ENDPOINT TRANSVERSALITY DIAGNOSTIC")
    print("-" * 196)
    print(f"development min F'/logX             : {c_dev:.12e}")
    print(f"frozen endpoint c safe              : {c_endpoint_safe:.12e}")
    print(f"holdout min F'/logX                 : {c_hold:.12e}")
    print(f"holdout pass                        : {endpoint_holdout_pass}")
    print("WARNING: endpoint slope != whole-segment MVT/secant proof.")
    print()
    print("=" * 196)
    print("FAILED FINITE GATES                 :", failed if failed else "none")
    print("NUMERICAL VERDICT                   :", verdict)
    print("PROOF VERDICT                       : U_STEP PROMOTION PROVED; ALL-L/ALL-k U_STEP PREMISE OPEN")
    print("=" * 196)
    print("Files written:")
    for q in [pair_path, mode_path, ref_path, tail_path, summary_path, theorem_path]:
        print(" ", q)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
