#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v464 — LOCAL ARGUMENT-PRINCIPLE MIDPOINT / ROUCHE DISK BRIDGE
=====================================================================

PURPOSE
-------
Sharpen the v463 midpoint-background target.

v463 showed that for a multiplicity-m bump collision, fixed-mode capture follows
once the regular normalized counting background has error < 1/2 from the
canonical midpoint N_- + m/2.

The present theorem separates two logically different facts:

  A. TOPOLOGICAL MIDPOINT — exact.
  B. FINITE-L REGULAR-FACTOR ERROR — analytic and still open globally.

A. LOCAL ARGUMENT-PRINCIPLE MIDPOINT
------------------------------------
After the v405 multiplicity-safe recombination, the local logarithmic derivative
has an integer residue m at an isolated zero/collision rho. Integrating locally
gives a characteristic factorization

    J_ref(z) = (z-rho)^m G_ref(z),

where G_ref is holomorphic and nonzero on a sufficiently small disk.

Indent the real/physical contour around rho by a small upper semicircle

    z = rho + r exp(i theta),  theta: pi -> 0.

The singular factor contributes an unwrapped argument change

    Delta arg (z-rho)^m = -m pi.

The regular factor contributes o(1) on the shrinking indentation because
G_ref(rho) != 0.

Thus the one-sided counting values differ by exactly m. With the canonical
symmetric/half-weight convention at the collision,

    N_sym(rho) = (N_- + N_+)/2 = N_- + m/2.

This is the exact midpoint. It does NOT require simple zeros.

B. FINITE-L ROUCHE / HALF-PLANE CRITERION
------------------------------------------
Let G_L denote the FINITE-L recombined regular factor after the principal
bump-collision channel has been removed, and compare it with the canonical
local reference G_ref by

    R_L = G_L / G_ref.

If on the relevant shrinking branch tube

    |R_L - 1| <= eta < 1,

then R_L lies in the open disk centered at 1 of radius eta. That disk excludes
zero and lies inside an angular sector with

    |arg R_L| <= arcsin(eta) < pi/2.

Therefore the normalized counting-background error obeys

    |epsilon_L| <= arcsin(eta)/pi < 1/2.

Combining with v463 gives

    |u_j(L)|
      <= 2 m (1+sqrt(pi))
         / [pi/2 - arcsin(eta)]

and since

    pi/2 - arcsin(eta) = arccos(eta),

the clean capture bound is

    |u_j(L)|
      <= 2 m (1+sqrt(pi)) / arccos(eta),

    |E_j(L)-gamma|
      <= 2 m (1+sqrt(pi))
         / [arccos(eta) L].

This criterion is strictly relative: no absolute phase limit is required.

WHY THIS IS THE RIGHT FRONTIER
------------------------------
v384/v416/v432 show that a blanket all-L boundedness theorem for the complete
fixed-E arithmetic forcing is RH-strength: an off-critical zero beta>1/2
produces exp[(beta-1/2)L]-type growth.

Therefore one must NOT claim that the regular-background midpoint error is
automatically o(1) from the argument principle alone.

The new target is instead a BRANCH-LOCAL RELATIVE FACTOR theorem:

    sup_{tube_k(L)} |G_L/G_ref - 1| <= eta_k < 1.

This is weaker and geometrically exact for the v463 half-index margin.

R7 LOCALIZATION
---------------
v402 gives the exact beta=2 factorial four-jet regular R^7 contraction

    Qjet ~= 0.3550859531691 < 1,

and fixed-prefix packet factor

    rhojet ~= 2.167272663e-5.

These constants do NOT by themselves prove the determinant-factor ratio above.
An embedding from the v402 coefficient-space norm into the local regular
factor ratio is still required.

If such an embedding gave eta <= Qjet, then the midpoint error would satisfy

    |epsilon| <= arcsin(Qjet)/pi ~= 0.11555,

leaving a margin ~= 0.38445 and

    |u| <= 4.59095 m.

If the much stronger fixed-prefix rhojet transferred directly, the capture
constant would be essentially the exact-midpoint value 3.53005 m.

These are CONDITIONAL illustrations only.

SCIENTIFIC BOUNDARY
-------------------
v464 proves:
  * the exact local half-multiplicity midpoint from argument principle;
  * the exact disk-to-phase-error inequality;
  * the exact v463 capture bound in terms of eta.

v464 does NOT prove:
  * the all-L relative-factor disk estimate;
  * the v402-to-factor embedding;
  * RH or the Fredholm-Xi identity.

No Xi values, numerical zeta values, zeta derivatives, or known zero ordinates
are used.

Version: 2026-08-28-v464-argument-principle-rouche-midpoint
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any, List

from tqdm import tqdm

VERSION = "2026-08-28-v464-argument-principle-rouche-midpoint"

QJET = 657981440000000 / 1853020188851841
RHOJET = 40160000000 / 1853020188851841


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available": False, "pass": False, "error": str(exc)}

    m = sp.symbols("m", integer=True, positive=True)
    theta = sp.symbols("theta", real=True)
    eta = sp.symbols("eta", positive=True)

    # Upper indentation theta: pi -> 0.
    singular_arg = m * theta
    delta_arg = sp.simplify(singular_arg.subs(theta, 0) - singular_arg.subs(theta, sp.pi))

    # v463 algebra:
    eps = sp.asin(eta) / sp.pi
    denom1 = sp.simplify(sp.pi * (sp.Rational(1, 2) - eps))
    denom2 = sp.acos(eta)
    # SymPy may leave acos(eta)+asin(eta)-pi/2 unevaluated for a generic
    # positive symbol because the branch condition eta<1 is an inequality
    # assumption.  Verify the identity by differentiating on (0,1) and checking
    # one interior anchor eta=1/2.
    trig_expr = sp.simplify(denom1 - denom2)
    trig_derivative = sp.simplify(sp.diff(trig_expr, eta))
    trig_anchor = sp.simplify(trig_expr.subs(eta, sp.Rational(1,2)))
    trig_pass = bool(trig_derivative == 0 and trig_anchor == 0)

    return {
        "available": True,
        "upper_indentation_singular_argument_change": str(delta_arg),
        "absolute_jump": "m*pi",
        "symmetric_counting_midpoint": "N_- + m/2",
        "epsilon_eta": "asin(eta)/pi",
        "pi_margin_identity": "pi*(1/2-asin(eta)/pi)=acos(eta)",
        "pi_margin_residual": str(trig_expr),
        "pi_margin_derivative_residual": str(trig_derivative),
        "pi_margin_anchor_residual_eta_half": str(trig_anchor),
        "pass": bool(delta_arg == -sp.pi*m and trig_pass),
    }


def geometry_for_eta(eta: float, m: int, L: float) -> Dict[str, Any]:
    if not (0.0 <= eta < 1.0):
        raise ValueError("eta must satisfy 0<=eta<1")
    if m < 1:
        raise ValueError("m must be >=1")
    if L <= 0.0:
        raise ValueError("L must be positive")

    angle = math.asin(eta)
    epsilon = angle / math.pi
    index_margin = 0.5 - epsilon
    angular_margin = math.acos(eta)
    U = 2.0*m*(1.0+math.sqrt(math.pi))/angular_margin

    return {
        "eta": eta,
        "multiplicity": m,
        "L": L,
        "maximum_regular_argument_error_radians": angle,
        "maximum_normalized_midpoint_error": epsilon,
        "remaining_index_margin": index_margin,
        "remaining_angular_margin": angular_margin,
        "capture_U": U,
        "capture_E_error": U/L,
        "capture_formula":
            "2*m*(1+sqrt(pi))/(acos(eta)*L)",
        "disk_excludes_zero": eta < 1.0,
        "midpoint_gate": epsilon < 0.5,
    }


def disk_angle_numeric(eta: float) -> Dict[str, Any]:
    """
    Numerically verify the sharp maximum argument over |z-1|<=eta.
    """
    if eta == 0.0:
        return {
            "eta": eta,
            "sampled_max_abs_arg": 0.0,
            "analytic_max_abs_arg": 0.0,
            "gap": 0.0,
        }

    n = 200000
    maxarg = 0.0
    for j in tqdm(range(n), desc=f"disk angle eta={eta:.3g}", unit="pt", leave=False):
        th = 2.0*math.pi*j/n
        z = 1.0 + eta*complex(math.cos(th), math.sin(th))
        maxarg = max(maxarg, abs(math.atan2(z.imag, z.real)))

    exact = math.asin(eta)
    return {
        "eta": eta,
        "sampled_max_abs_arg": maxarg,
        "analytic_max_abs_arg": exact,
        "absolute_gap": abs(maxarg-exact),
    }


def panel(m: int, L: float) -> List[Dict[str, Any]]:
    etas = [0.0, RHOJET, 0.10, QJET, 0.50, 0.75, 0.90, 0.99]
    rows = []
    for eta in etas:
        g = geometry_for_eta(eta, m, L)
        rows.append({
            "eta": eta,
            "epsilon": g["maximum_normalized_midpoint_error"],
            "index_margin": g["remaining_index_margin"],
            "capture_U_per_m": g["capture_U"]/m,
            "capture_E_error": g["capture_E_error"],
            "label": (
                "rhojet_conditional" if abs(eta-RHOJET) < 1e-14 else
                "Qjet_conditional" if abs(eta-QJET) < 1e-14 else
                "diagnostic"
            ),
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    qeps = math.asin(QJET)/math.pi
    qU = 2.0*(1.0+math.sqrt(math.pi))/math.acos(QJET)
    reps = math.asin(RHOJET)/math.pi
    rU = 2.0*(1.0+math.sqrt(math.pi))/math.acos(RHOJET)

    theorem.write_text(
f"""# ROT-RH v464 — local argument-principle midpoint / Rouché disk bridge

## 1. Exact topological midpoint

After multiplicity-safe recombination, an isolated multiplicity-`m` local
characteristic has the form

`J_ref(z)=(z-rho)^m G_ref(z)`,

with `G_ref` holomorphic and nonzero near `rho`.

Across an upper semicircular indentation around `rho`, the unwrapped argument
of `(z-rho)^m` changes by `-m*pi`, while the regular factor contributes `o(1)`.

Hence the one-sided counting values differ by exactly `m`.

With the standard symmetric/half-weight convention,

`N_sym(rho)=N_-+m/2`.

This is topological and multiplicity-safe.

## 2. Finite-L regular-factor disk theorem

Let

`R_L = G_L/G_ref`.

If on the eventual shrinking branch tube

`|R_L-1|<=eta<1`,

then the disk `|z-1|<=eta` excludes zero and

`|arg R_L|<=asin(eta)<pi/2`.

Therefore the v463 normalized midpoint error satisfies

`|epsilon_L|<=asin(eta)/pi<1/2`.

So the exact half-index margin survives.

## 3. Capture bound

v463 then gives

`|u_j(L)| <= 2m(1+sqrt(pi))/acos(eta)`,

where

`u_j(L)=(gamma-E_j(L))L`.

Thus

`|E_j(L)-gamma|
 <= 2m(1+sqrt(pi))/[acos(eta)L]`.

No root derivative or no-fold estimate is needed for this implication.

## 4. Conditional v402 numerics

v402 proves the coefficient-space contraction constant

`Qjet={QJET:.16e}`.

If — and only if — a separate embedding theorem transferred this directly to

`|G_L/G_ref-1|<=Qjet`,

then

`|epsilon|<={qeps:.16e}`

and

`|u|<={qU:.16e} m`.

The fixed-prefix packet factor is

`rhojet={RHOJET:.16e}`.

If it transferred directly to the factor ratio, then

`|epsilon|<={reps:.16e}`

and

`|u|<={rU:.16e} m`.

These are illustrations, NOT proven consequences of v402.

## 5. Why argument principle alone does not close the finite-L theorem

The topological midpoint is exact, but the finite-L relative factor is an
arithmetic object.

The earlier explicit-formula line shows that off-critical poles create
`exp[(beta-1/2)L]` forcing.  In particular, a blanket fixed-E bounded-forcing
theorem is RH-equivalent in the classical explicit-formula framework.

So the honest remaining theorem is not

`G_L/G_ref -> 1 automatically`.

It is the branch-local relative estimate

`sup_tube |G_L/G_ref-1| <= eta_k < 1`.

## 6. Recursive localization

The regular R7 packet transfer is already contractive in v402's beta-2
factorial four-jet geometry.  The missing steps are:

1. build an exact local determinant/regular-factor observable from that
   coefficient geometry;
2. prove its R7 contribution remains inside a strict relative disk;
3. prove the finite G7 regular head stays in the same disk after the principal
   collision has been recombined and removed.

The third item is the genuinely RH-strength signed-head frontier identified
by the earlier v384/v416 line unless an independent operator principle supplies
the relative disk estimate.

v464 is an exact reduction, not an RH proof.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_LOCAL_ROUCHE_MIDPOINT_CERTIFICATE_V1",
        "already_closed": {
            "local_factorization":
                "J_ref=(z-rho)^m G_ref with G_ref nonzero after recombination",
            "argument_jump": "Delta arg singular factor = +/-m*pi",
            "topological_midpoint": "N_sym=N_-+m/2",
            "disk_phase_bound":
                "|R-1|<=eta<1 => |arg R|<=asin(eta)",
            "normalized_midpoint_error":
                "|epsilon|<=asin(eta)/pi<1/2",
            "capture":
                "|(gamma-E)L|<=2m(1+sqrt(pi))/acos(eta)",
        },
        "required_claims": {
            "regular_factor_definition":
                "construct finite-L G_L and canonical G_ref from the recombined bump characteristic",
            "relative_disk":
                "sup on eventual branch tube |G_L/G_ref-1|<=eta_k<1",
            "v402_factor_embedding":
                "optional route: transfer beta-2 four-jet R7 control into the local determinant-factor ratio",
            "G7_relative_head":
                "control the collision-subtracted finite G7 regular factor relatively, not by a magnitude-only PNT bound",
            "branch_label_persistence":
                "retain the fixed half-integer labels in the local packet",
        },
        "important_boundary": (
            "Argument principle proves the exact midpoint of the canonical local "
            "factor, but not small finite-L arithmetic factor error. A blanket "
            "fixed-E forcing bound would be RH-strength."
        ),
        "next_attack": (
            "Construct the exact regular-factor ratio as an exponential of a "
            "collision-subtracted phase integral, then test whether v402 gives a "
            "strict disk bound for the R7 piece; whatever remains is the G7 head."
        ),
    }
    cert.write_text(json.dumps(certificate, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--eta", type=float, default=QJET)
    ap.add_argument("--multiplicity", type=int, default=1)
    ap.add_argument("--L", type=float, default=20.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_local_rouche_midpoint_v464",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if not (0.0 <= args.eta < 1.0):
        raise ValueError("--eta must satisfy 0<=eta<1")
    if args.multiplicity < 1:
        raise ValueError("--multiplicity must be >=1")
    if args.L <= 0:
        raise ValueError("--L must be positive")

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*188)
    print("ROT-RH v464 — LOCAL ARGUMENT-PRINCIPLE MIDPOINT / ROUCHE DISK BRIDGE")
    print("="*188)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("simple-zero assumption                     : NONE")
    print("argument-principle midpoint                : EXACT")
    print("finite-L relative disk                     : THEOREM TARGET")
    print("="*188)

    with tqdm(total=4, desc="v464 midpoint bridge", unit="step") as bar:
        sym = symbolic_checks()
        bar.update(1)
        geom = geometry_for_eta(args.eta, args.multiplicity, args.L)
        bar.update(1)
        # Keep the expensive disk diagnostic to one representative eta.
        diag = disk_angle_numeric(args.eta)
        bar.update(1)
        rows = panel(args.multiplicity, args.L)
        bar.update(1)

    passed = bool(
        sym.get("pass", False)
        and geom["disk_excludes_zero"]
        and geom["midpoint_gate"]
        and diag["absolute_gap"] <= 2e-5
    )

    verdict = (
        "EXACT_ARGUMENT_PRINCIPLE_MIDPOINT_AND_ROUCHE_DISK_BRIDGE_PASS"
        if passed else
        "LOCAL_ROUCHE_MIDPOINT_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "symbolic_checks": sym,
        "selected_geometry": geom,
        "disk_diagnostic": diag,
        "v402_constants": {
            "Qjet": QJET,
            "rhojet": RHOJET,
            "direct_factor_transfer_proved": False,
        },
        "eta_panel": rows,
        "proof_status": (
            "Topological midpoint and relative-disk-to-index-margin theorem are exact. "
            "The all-L local regular-factor disk estimate remains open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*188)
    print("verdict                                  :", verdict)
    print("selected eta                             :", f"{args.eta:.16e}")
    print("max normalized midpoint error            :", f"{geom['maximum_normalized_midpoint_error']:.16e}")
    print("remaining exact half-index margin        :", f"{geom['remaining_index_margin']:.16e}")
    print("capture |u| upper                        :", f"{geom['capture_U']:.16e}")
    print("capture |E-gamma| upper at L             :", f"{geom['capture_E_error']:.16e}")
    print("sampled/exact disk max angle             :", f"{diag['sampled_max_abs_arg']:.16e}", "/", f"{diag['analytic_max_abs_arg']:.16e}")
    print("Qjet (conditional factor illustration)   :", f"{QJET:.16e}")
    print("rhojet (conditional factor illustration) :", f"{RHOJET:.16e}")
    print("summary                                  :", str(prefix)+"_SUMMARY.json")
    print("theorem                                  :", str(prefix)+"_THEOREM.md")
    print("next certificate                         :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*188)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
