# ROT-RH v475 — nonattained parabolic height / adiabatic window theorem

Using the v473 sectorial saddle envelope, compare an instantaneous winner with
one fixed off-critical baseline `a0>0`.

After absorbing the `L^(1/3)|Gamma|^(1/3)` term by Young's inequality,

`winner >= baseline`

implies

`L^(2/3)|Gamma_w|^(2/3) <= C L + O(L^(2/3))`.

Therefore

`|Gamma_w(L)| <= C_* sqrt(L)`.

v473's nonattained overtaking simultaneously gives

`|Gamma_w(L)|->infinity`

and

`delta_w(L)=a_*-a_w(L)->0`.

Hence the active bump support satisfies

`1 << |Gamma_w(L)| <= C_* sqrt(L)`.

On any fixed cutoff window `|Delta|<=h`:

`exp(-delta_w Delta)=1+o(1)`

uniformly, while

`|Gamma_w|h/(2pi)->infinity`.

And v473 gives the common energy-carrier law

`partial_E phase / L = 1+o(1)`.

So every late fixed window is adiabatic in amplitude and infinitely oscillatory
in phase.

**Verdict:** NONATTAINED_PARABOLIC_HEIGHT_ADIABATIC_WINDOW_REDUCTION_PASS

The remaining nonattained theorem is therefore stronger than v410's
single-point exceptional-sampling question: a bounded fixed branch must remain
on an exceptional broad-band/amplitude-collapse set throughout every fixed
window containing infinitely many active oscillations.
