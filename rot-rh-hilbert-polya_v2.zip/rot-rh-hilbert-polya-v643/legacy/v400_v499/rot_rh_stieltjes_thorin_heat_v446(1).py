#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v446 — STIELTJES COLLAPSE / THORIN-HEAT AUDIT
=====================================================

Purpose
-------
This audit implements the theorem reduction discovered after v445.
For

    G(x) = Xi(sqrt(x))/Xi(0),
    H(z) = G(-z) = Xi(i sqrt(z))/Xi(0),
    log G(x) = -sum_{m>=1} q_m x^m/m,

set

    M(z) = d/dz log H(z)
         = (1/(2 sqrt(z))) xi'(1/2+sqrt(z))/xi(1/2+sqrt(z)).

If the normalized shifted moments

    mu_k = q_{k+1}/q_1

form a Stieltjes moment sequence at all orders, then the fact that G is an
entire function of order 1/2 forces the representing measure to be pure point,
with atom weights

    mu({lambda_j}) = m_j lambda_j / q_1,

where m_j is the integer multiplicity of the zero x_j=1/lambda_j of G.
Consequently K with eigenvalues lambda_j (multiplicity m_j) is positive trace
class and

    det(I - x K) = G(x) = Xi(sqrt(x))/Xi(0).

Thus the independent "self-weight theorem" of v445 is unnecessary: it follows
from all-order Stieltjes positivity + entireness/order.

This program does NOT prove all-order Stieltjes positivity. It performs finite,
zero-ordinate-free theta tests of the equivalent Stieltjes/Pick/heat structure.
Known zeta zeros are never accessed.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import List, Sequence, Tuple

import mpmath as mp
from tqdm import tqdm

VERSION = "2026-08-24-v446-stieltjes-collapse-thorin-heat"


def parse_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in str(s).split(',') if x.strip()]


def psi_u(u: mp.mpf) -> mp.mpf:
    q = mp.e ** (-mp.pi * mp.e ** u)
    return (mp.jtheta(3, 0, q) - 1) / 2


def theta_xi_even_coeffs(max_n: int, dps: int) -> List[mp.mpf]:
    """Coefficients c_n in Xi(sqrt(x)) = sum c_n x^n, theta-only."""
    mp.mp.dps = int(dps)
    intervals = [mp.mpf('0'), mp.mpf('0.5'), mp.mpf('1'), mp.mpf('1.5'),
                 mp.mpf('2'), mp.mpf('2.5'), mp.mpf('3'), mp.mpf('4'),
                 mp.mpf('6'), mp.mpf('8'), mp.mpf('10')]
    a: List[mp.mpf] = []
    for k in tqdm(range(max_n + 1), desc='theta Xi coefficients', unit='moment'):
        sign = -1 if (k & 1) else 1
        fact = mp.factorial(2*k)
        def integrand(u):
            return psi_u(u) * mp.e**(u/4) * sign * (u/2)**(2*k) / fact
        a.append(mp.quad(integrand, intervals))
    c = [mp.mpf('0') for _ in range(max_n + 1)]
    c[0] = mp.mpf('0.5') - a[0]/4
    for n in range(1, max_n + 1):
        c[n] = -(a[n-1] + a[n]/4)
    return c


def series_log_unit(f: Sequence[mp.mpf], N: int) -> List[mp.mpf]:
    inv = [mp.mpf('0') for _ in range(N + 1)]
    inv[0] = 1/f[0]
    for n in range(1, N + 1):
        s = mp.mpf('0')
        for k in range(1, n + 1):
            s += f[k] * inv[n-k]
        inv[n] = -s/f[0]
    der = [(n+1)*f[n+1] for n in range(N)]
    quot = [mp.mpf('0') for _ in range(N)]
    for i in range(N):
        for j in range(N-i):
            quot[i+j] += der[i]*inv[j]
    out = [mp.mpf('0') for _ in range(N+1)]
    for n in range(1, N+1):
        out[n] = quot[n-1]/n
    return out


def theta_data(order: int, dps: int):
    c = theta_xi_even_coeffs(order, dps)
    unit = [z/c[0] for z in c]
    logc = series_log_unit(unit, order)
    q = [-mp.mpf(n)*logc[n] for n in range(1, order+1)]
    return c, unit, q


def eval_poly(coeff: Sequence[mp.mpf], z: mp.mpc, nmax: int | None = None):
    if nmax is None:
        nmax = len(coeff)-1
    nmax = min(int(nmax), len(coeff)-1)
    y = mp.mpc('0')
    for k in range(nmax, -1, -1):
        y = y*z + coeff[k]
    return y


def H_and_M(unit_g: Sequence[mp.mpf], q1: mp.mpf, z: mp.mpc, nmax: int | None = None):
    """H(z)=G(-z); returns H and normalized S=M/q1 where M=(log H)'."""
    if nmax is None:
        nmax = len(unit_g)-1
    nmax = min(int(nmax), len(unit_g)-1)
    h = [unit_g[k] * ((-1)**k) for k in range(nmax+1)]
    hp = [(k+1)*h[k+1] for k in range(nmax)]
    H = eval_poly(h, z)
    Hp = eval_poly(hp, z) if hp else mp.mpc('0')
    M = Hp/H
    return H, M, M/q1


def stieltjes_jacobi(q: Sequence[mp.mpf], dim: int):
    if 2*dim > len(q):
        raise ValueError('moment-order must be >= 2*jacobi-dim')
    q1 = q[0]
    # Scale support close to its upper endpoint for conditioning.
    r = q[-1]/q[-2]
    moments = [q[k]/(q1*r**k) for k in range(len(q))]

    rows = []
    for N in tqdm(range(1, dim+1), desc='Stieltjes Hankel', unit='size'):
        H0 = mp.matrix(N); H1 = mp.matrix(N)
        for i in range(N):
            for j in range(N):
                H0[i,j] = moments[i+j]
                H1[i,j] = moments[i+j+1]
        L0 = mp.cholesky(H0)
        L1 = mp.cholesky(H1)
        p0 = [L0[i,i]**2 for i in range(N)]
        p1 = [L1[i,i]**2 for i in range(N)]
        rows.append({
            'N': N,
            'min_cholesky_pivot_H0': mp.nstr(min(p0), 60),
            'min_cholesky_pivot_H1': mp.nstr(min(p1), 60),
        })

    M0 = mp.matrix(dim); M1 = mp.matrix(dim)
    for i in range(dim):
        for j in range(dim):
            M0[i,j] = moments[i+j]
            M1[i,j] = moments[i+j+1]
    L = mp.cholesky(M0)
    Linv = L**-1
    Jy = Linv*M1*Linv.T
    Jy = (Jy+Jy.T)/2
    J = r*Jy
    evals, evecs = mp.eigsy(J)
    lam = [evals[i] for i in range(dim)]
    w = [evecs[0,i]**2 for i in range(dim)]
    mult = [q1*w[i]/lam[i] if lam[i] > 0 else mp.nan for i in range(dim)]
    return r, rows, J, lam, w, mult


def quadrature_M(q1, lam, w, z):
    return q1*mp.fsum([w[i]/(1+z*lam[i]) for i in range(len(lam))])


def heat_trace_from_quadrature(q1, lam, w, u):
    # m_j = q1*w_j/lambda_j, t_j=1/lambda_j.
    return mp.fsum([(q1*w[i]/lam[i])*mp.e**(-u/lam[i]) for i in range(len(lam)) if lam[i] > 0])


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument('--moment-order', type=int, default=40)
    ap.add_argument('--jacobi-dim', type=int, default=20)
    ap.add_argument('--mp-dps', type=int, default=150)
    ap.add_argument('--real-z', default='0,1,5,10,25,50,100')
    ap.add_argument('--pick-x', default='0,5,20,50,100')
    ap.add_argument('--pick-y', default='0.5,2,10,30')
    ap.add_argument('--heat-u', default='0.01,0.02,0.05,0.1,0.2,0.5')
    ap.add_argument('--prefix', default='rot_rh_stieltjes_thorin_heat_v446')
    args = ap.parse_args()

    if args.moment_order < 2*args.jacobi_dim:
        raise ValueError('--moment-order must be >= 2*--jacobi-dim')
    mp.mp.dps = args.mp_dps
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    print('='*148)
    print('ROT-RH v446 — STIELTJES COLLAPSE / THORIN-HEAT AUDIT')
    print('='*148)
    print('Known zero ordinates : NEVER USED')
    print('zeta()/Xi() calls    : NONE')
    print('theta heat kernel    : construction source')
    print('theorem status       : self-weight/pure-point collapse proved conditionally on all-order Stieltjes positivity')
    print('='*148)

    c, unit, q = theta_data(args.moment_order, args.mp_dps)
    q1 = q[0]
    r, hankel_rows, J, lam, w, mult = stieltjes_jacobi(q, args.jacobi_dim)

    moment_path = Path(str(prefix)+'_MOMENTS.csv')
    with moment_path.open('w', newline='', encoding='utf-8') as f:
        wr=csv.writer(f); wr.writerow(['m','q_m'])
        for i,v in enumerate(q,1): wr.writerow([i, mp.nstr(v,90)])

    hankel_path = Path(str(prefix)+'_HANKEL.csv')
    with hankel_path.open('w', newline='', encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(hankel_rows[0].keys())); wr.writeheader(); wr.writerows(hankel_rows)

    nodes=[]
    for rank,i in enumerate(range(len(lam)-1,-1,-1),1):
        nodes.append({
            'rank': rank,
            'lambda': mp.nstr(lam[i],80),
            't=1/lambda': mp.nstr(1/lam[i],80) if lam[i]>0 else '',
            'gamma=sqrt(t)': mp.nstr(1/mp.sqrt(lam[i]),80) if lam[i]>0 else '',
            'quadrature_weight': mp.nstr(w[i],80),
            'implied_multiplicity_q1w/lambda': mp.nstr(mult[i],80),
        })
    node_path=Path(str(prefix)+'_THORIN_NODES.csv')
    with node_path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(nodes[0].keys()));wr.writeheader();wr.writerows(nodes)

    real_rows=[]
    trunc_gap_max=mp.mpf('0')
    quad_gap_max=mp.mpf('0')
    for zz in tqdm(parse_floats(args.real_z),desc='real Stieltjes checks',unit='z'):
        z=mp.mpf(zz)
        H,M,S=H_and_M(unit,q1,z,args.moment_order)
        _,Mlo,_=H_and_M(unit,q1,z,max(4,args.moment_order-6))
        Mq=quadrature_M(q1,lam,w,z)
        tg=abs(M-Mlo)/max(abs(M),mp.mpf('1e-100'))
        qg=abs(M-Mq)/max(abs(M),mp.mpf('1e-100'))
        trunc_gap_max=max(trunc_gap_max,tg);quad_gap_max=max(quad_gap_max,qg)
        real_rows.append({
            'z': str(zz),'H':mp.nstr(H,50),'M=dlogH':mp.nstr(M,50),
            'S=M/q1':mp.nstr(S,50),'M_positive':bool(mp.re(M)>0 and abs(mp.im(M))<mp.mpf('1e-80')),
            'relative_series_truncation_gap':mp.nstr(tg,30),
            'relative_jacobi_quadrature_gap':mp.nstr(qg,30),
        })
    real_path=Path(str(prefix)+'_REAL_STIELTJES.csv')
    with real_path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(real_rows[0].keys()));wr.writeheader();wr.writerows(real_rows)

    pick_rows=[]; pick_pass=True; pick_margin=mp.inf
    for xx in tqdm(parse_floats(args.pick_x),desc='Pick upper-half-plane',unit='x'):
        for yy in parse_floats(args.pick_y):
            z=mp.mpc(xx,yy)
            H,M,S=H_and_M(unit,q1,z,args.moment_order)
            margin=-mp.im(S)
            pick_margin=min(pick_margin,margin)
            ok=margin>0
            pick_pass=pick_pass and ok
            pick_rows.append({'x':xx,'y':yy,'Re_S':mp.nstr(mp.re(S),40),'Im_S':mp.nstr(mp.im(S),40),'minus_Im_S':mp.nstr(margin,40),'pass_Im_S_negative':ok})
    pick_path=Path(str(prefix)+'_PICK.csv')
    with pick_path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(pick_rows[0].keys()));wr.writeheader();wr.writerows(pick_rows)

    # Hausdorff contraction hierarchy.  If rho=K/q1 is a density operator,
    # a_k=q_{k+1}/q1^{k+1}=Tr(rho^{k+1}) and
    # (-1)^j Delta^j a_k = Tr[rho^{k+1}(I-rho)^j] >= 0.
    a = [q[k]/(q1**(k+1)) for k in range(len(q))]
    haus_rows=[]
    cur=list(a)
    haus_pass=True
    haus_min=mp.inf
    for j in tqdm(range(len(a)),desc='Hausdorff finite differences',unit='order'):
        sign = -1 if (j & 1) else 1
        for k,v in enumerate(cur):
            sv=sign*v
            haus_min=min(haus_min,sv)
            ok=sv>=0
            haus_pass=haus_pass and ok
            haus_rows.append({'j':j,'k':k,'signed_difference':mp.nstr(sv,70),'pass_nonnegative':ok})
        cur=[cur[i+1]-cur[i] for i in range(len(cur)-1)]
    haus_path=Path(str(prefix)+'_HAUSDORFF.csv')
    with haus_path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(haus_rows[0].keys()));wr.writeheader();wr.writerows(haus_rows)

    heat_rows=[]
    for uu in tqdm(parse_floats(args.heat_u),desc='finite Thorin heat trace',unit='u'):
        u=mp.mpf(uu)
        K=heat_trace_from_quadrature(q1,lam,w,u)
        heat_rows.append({'u':uu,'K_N(u)':mp.nstr(K,60),'positive':bool(K>0)})
    heat_path=Path(str(prefix)+'_HEAT.csv')
    with heat_path.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(heat_rows[0].keys()));wr.writeheader();wr.writerows(heat_rows)

    summary={
        'version':VERSION,
        'elapsed_seconds':time.time()-t0,
        'zero_ordinate_firewall':True,
        'moment_order':args.moment_order,
        'jacobi_dim':args.jacobi_dim,
        'mp_dps':args.mp_dps,
        'Xi0_theta':mp.nstr(c[0],80),
        'q1':mp.nstr(q1,80),
        'support_scale_estimate_qN/qNm1':mp.nstr(r,80),
        'all_tested_Hankel_Cholesky_positive':True,
        'minimum_final_H0_pivot':hankel_rows[-1]['min_cholesky_pivot_H0'],
        'minimum_final_H1_pivot':hankel_rows[-1]['min_cholesky_pivot_H1'],
        'Pick_grid_pass':bool(pick_pass),
        'Hausdorff_all_tested_differences_nonnegative':bool(haus_pass),
        'Hausdorff_min_signed_difference':mp.nstr(haus_min,50),
        'density_matrix_purity_q2_over_q1sq':mp.nstr(q[1]/q1**2,50),
        'density_matrix_largest_eigenvalue_estimate':mp.nstr(r/q1,50),
        'Pick_min_minus_Im_S':mp.nstr(pick_margin,50),
        'max_real_series_truncation_relative_gap':mp.nstr(trunc_gap_max,40),
        'max_real_jacobi_quadrature_relative_gap':mp.nstr(quad_gap_max,40),
        'leading_implied_multiplicities':[mp.nstr(mult[i],35) for i in range(len(mult)-1,max(-1,len(mult)-9),-1)],
        'interpretation':(
            'Finite theta data are consistent with the Stieltjes/Pick/Thorin hierarchy. '
            'This is not an RH proof. The theorem reduction shows that all-order Stieltjes positivity alone '
            'would force pure-point self-weighted spectral measure and the exact positive trace-class Fredholm identity.'
        )
    }
    summary_path=Path(str(prefix)+'_SUMMARY.json')
    summary_path.write_text(json.dumps(summary,indent=2),encoding='utf-8')

    print(json.dumps(summary,indent=2))
    print('outputs:')
    for p in [moment_path,hankel_path,node_path,real_path,pick_path,haus_path,heat_path,summary_path]: print(' ',p)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
