#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v451 — FROZEN v450 ROOT-CELL CERTIFICATION / BRANCH CONTINUATION AUDIT
================================================================================

Purpose
-------
v450 produced prospective uniform heat-tube evidence for the frozen bump-2
prime regulator, but its strongest verdict was blocked because one held-out
Gamma-centered root cell had no sign-changing bracket on the original 64-point
grid.  v451 does NOT refit the v450 convergence law, change the regulator, use
known Riemann zero ordinates, or modify the frozen holdout prediction.

It performs a surgical audit of every held-out cell that failed the frozen v450
root-cleanliness gate:

  Route A — local analytic-Newton + certified bracketing
      Start from the exact fallback point saved by v450, use the exact secular
      F_k(E;X) and analytic derivative F'_k(E;X), then certify any recovered
      simple root with a sign-changing Brent bracket.

  Route B — cutoff continuation
      Start from the same ordered branch at the final TRAINING cutoff and
      continue it through a geometric X ladder to the HELD-OUT cutoff.  Every
      continuation step is independently bracket-certified.

A recovered root is accepted only when the two routes agree, its residual and
transversality gates pass, and it does not duplicate a neighboring level.
Nominal/expanded cell scans are written for diagnosis but are not allowed to
replace the two-route certificate.

After certification, v451 replaces ONLY the failed v450 branch value(s) and
recomputes the held-out heat vector.  It then scores that corrected vector
against the ORIGINAL frozen v450:

  * pre-holdout SHA256 manifest,
  * anchor-target envelope,
  * every uniform heat-tube envelope,
  * dense target-free predicted holdout vector,
  * depth-stability gate,
  * tail-improvement condition.

Nothing is refit after root recovery.

Scientific boundary
-------------------
A PASS means the v450 failure was a root-certification issue rather than a
failure of its already-frozen prospective heat tests.  It is finite numerical
evidence only.  It does not prove all-mode branch persistence, uniform heat
convergence for all u>0, operator/strong-resolvent convergence, an exact
Hilbert-Pólya operator, or RH.

Typical PowerShell run for the reported v450 experiment
--------------------------------------------------------
python .\\rot_rh_root_cell_continuation_v451.py `
  --v450-prefix rot_rh_uniform_heat_tube_v450 `
  --expected-v450-prefreeze-sha 0ee4ca414a119d35225c44cd8af2d8b29a33c37b9d13953604e7979c8e8f18ff `
  --continuation-steps 17 `
  --neighbor-cells 2 `
  --diagnostic-scan-points 513 `
  --root-tol 2e-10 `
  --route-agreement-tol 5e-8 `
  --prefix rot_rh_root_cell_continuation_v451
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import brentq
from scipy.special import digamma
from tqdm import tqdm

VERSION = "2026-08-25-v451-frozen-v450-root-cell-continuation"
DEFAULT_EXPECTED_PREFREEZE_SHA = "0ee4ca414a119d35225c44cd8af2d8b29a33c37b9d13953604e7979c8e8f18ff"


# =============================================================================
# Utilities
# =============================================================================

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def import_required(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_clock_theta_jacobi_v445.py and "
            "rot_rh_regulator_universality_heat_v448.py in the same directory as v451, "
            "or pass --v445-module/--v448-module."
        )


def spectral_heat_vector(levels: np.ndarray, u_grid: np.ndarray) -> np.ndarray:
    e2 = np.asarray(levels, dtype=float) ** 2
    return np.exp(-np.outer(np.asarray(u_grid, dtype=float), e2)).sum(axis=1)


def symmetric_components(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> np.ndarray:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum.reduce([np.abs(aa), np.abs(bb), np.full_like(aa, floor)])
    return np.abs(aa - bb) / scale


def relative_components(model: Sequence[float], target: Sequence[float], floor: float = 1e-300) -> np.ndarray:
    m = np.asarray(model, dtype=float)
    t = np.asarray(target, dtype=float)
    return np.abs(m - t) / np.maximum(np.abs(t), floor)


def rms(a: Sequence[float]) -> float:
    x = np.asarray(a, dtype=float)
    return float(np.sqrt(np.mean(x * x))) if x.size else float("nan")


def tube_mask(u_grid: np.ndarray, u0: float, u_max: float) -> np.ndarray:
    tol = 1e-14 * max(1.0, abs(u0), abs(u_max))
    return (u_grid >= u0 - tol) & (u_grid <= u_max + tol)


def tube_metrics(a: Sequence[float], b: Sequence[float], u_grid: np.ndarray, u0: float, u_max: float) -> Tuple[float, float, int]:
    c = symmetric_components(a, b)
    vals = c[tube_mask(u_grid, u0, u_max)]
    if vals.size == 0:
        raise ValueError(f"empty heat tube u0={u0}")
    return float(np.max(vals)), float(np.sqrt(np.mean(vals * vals))), int(vals.size)


def module_sha(module) -> dict:
    p = Path(module.__file__).resolve()
    return {"path": str(p), "sha256": sha256_file(p)}


# =============================================================================
# Exact frozen bump-2 secular function
# =============================================================================

class FrozenSecular:
    """Evaluate the frozen bump-2 F_k(E;X) and analytic E derivative."""

    def __init__(self, v445, v448, n: np.ndarray, mang: np.ndarray, holdout_X: int, prime_chunk: int):
        self.v445 = v445
        self.v448 = v448
        self.n = np.asarray(n, dtype=np.int64)
        self.mang = np.asarray(mang, dtype=float)
        self.nf = self.n.astype(float)
        self.logs = np.log(self.nf)
        self.base = self.mang / (self.logs * np.sqrt(self.nf))
        self.reg = v448.Regulator("bump", 2.0, "bump_2")
        self.holdout_X = int(holdout_X)
        self.prime_chunk = int(prime_chunk)
        self._cache: Dict[int, Tuple[np.ndarray, np.ndarray]] = {}

    def weights(self, X: int) -> Tuple[np.ndarray, np.ndarray]:
        X = int(X)
        if X not in self._cache:
            win = self.v448.regulator_window(self.logs, X, self.reg)
            w = self.base * win
            self._cache[X] = (w, w * self.logs)
        return self._cache[X]

    def _phase_scalar(self, E: float, w: np.ndarray, derivative: bool = False) -> float:
        total = 0.0
        for j in range(0, len(self.logs), self.prime_chunk):
            lg = self.logs[j:j+self.prime_chunk]
            ww = w[j:j+self.prime_chunk]
            if derivative:
                total += float(np.dot(np.cos(float(E) * lg), ww))
            else:
                total += float(np.dot(np.sin(float(E) * lg), ww))
        return total

    def f(self, E: float, k: int, X: int) -> float:
        w, _ = self.weights(X)
        target = float(k) - 0.5
        return float(self.v445.smooth_count(float(E)) - self._phase_scalar(E, w, False) / math.pi - target)

    def fp(self, E: float, k: int, X: int) -> float:
        _, wlog = self.weights(X)
        z = 0.25 + 0.5j * float(E)
        theta_prime = 0.5 * float(np.real(digamma(z))) - 0.5 * math.log(math.pi)
        smooth_prime = theta_prime / math.pi
        arithmetic_prime = self._phase_scalar(E, wlog, True) / math.pi
        return float(smooth_prime - arithmetic_prime)

    def fgrid(self, E: np.ndarray, k: int, X: int, energy_batch: int = 64) -> np.ndarray:
        eall = np.asarray(E, dtype=float)
        w, _ = self.weights(X)
        out = np.empty(len(eall), dtype=float)
        target = float(k) - 0.5
        for a in range(0, len(eall), int(energy_batch)):
            e = eall[a:a+int(energy_batch)]
            sm = np.asarray([self.v445.smooth_count(float(x)) for x in e], dtype=float)
            ph = np.zeros(len(e), dtype=float)
            for j in range(0, len(self.logs), self.prime_chunk):
                lg = self.logs[j:j+self.prime_chunk]
                ww = w[j:j+self.prime_chunk]
                ph += np.sin(np.outer(e, lg)) @ ww
            out[a:a+len(e)] = sm - ph / math.pi - target
        return out


# =============================================================================
# Root certification helpers
# =============================================================================

@dataclass
class RootCert:
    ok: bool
    root: float
    residual: float
    derivative: float
    bracket_lo: float
    bracket_hi: float
    iterations: int
    reason: str


def original_cell_bounds(k: int, depth: int, free_ext: np.ndarray) -> Tuple[float, float]:
    idx = int(k) - 1
    free = np.asarray(free_ext[:depth], dtype=float)
    if idx < 0 or idx >= depth:
        raise ValueError(f"k={k} outside depth={depth}")
    lo = 7.0 if idx == 0 else 0.5 * (free[idx-1] + free[idx])
    if idx + 1 < depth:
        hi = 0.5 * (free[idx] + free[idx+1])
    else:
        hi = free[idx] + 0.5 * (free[idx] - free[idx-1])
    return float(lo), float(hi)


def expanded_bounds(k: int, depth: int, free_ext: np.ndarray, neighbor_cells: int) -> Tuple[float, float]:
    klo = max(1, int(k) - int(neighbor_cells))
    khi = min(int(depth), int(k) + int(neighbor_cells))
    lo, _ = original_cell_bounds(klo, depth, free_ext)
    _, hi = original_cell_bounds(khi, depth, free_ext)
    return lo, hi


def safeguarded_newton(
    sec: FrozenSecular,
    k: int,
    X: int,
    seed: float,
    lo: float,
    hi: float,
    residual_tol: float,
    max_iter: int,
    max_step_fraction: float,
) -> Tuple[bool, float, float, float, int, str]:
    x = float(min(max(seed, lo), hi))
    width = max(hi - lo, 1e-12)
    max_step = max_step_fraction * width
    fcur = sec.f(x, k, X)
    for it in range(1, int(max_iter) + 1):
        fp = sec.fp(x, k, X)
        if abs(fcur) <= residual_tol:
            return True, x, abs(fcur), fp, it, "newton_residual"
        if not math.isfinite(fp) or abs(fp) < 1e-14:
            return False, x, abs(fcur), fp, it, "derivative_too_small"
        step = -fcur / fp
        if abs(step) > max_step:
            step = math.copysign(max_step, step)
        trial = min(max(x + step, lo), hi)
        ftrial = sec.f(trial, k, X)
        # Backtrack if Newton increased the residual strongly.
        bt = 0
        while abs(ftrial) > abs(fcur) and bt < 8 and abs(trial - x) > 1e-15:
            trial = 0.5 * (trial + x)
            ftrial = sec.f(trial, k, X)
            bt += 1
        if abs(trial - x) <= 1e-14 * max(1.0, abs(x)):
            x, fcur = trial, ftrial
            break
        x, fcur = trial, ftrial
    fp = sec.fp(x, k, X)
    return abs(fcur) <= residual_tol, x, abs(fcur), fp, int(max_iter), "newton_max_iter"


def certify_bracket_near(
    sec: FrozenSecular,
    k: int,
    X: int,
    center: float,
    lo: float,
    hi: float,
    root_tol: float,
    residual_tol: float,
    initial_radius_fraction: float,
    expansions: int,
) -> RootCert:
    width = max(hi - lo, 1e-12)
    radius = max(width * initial_radius_fraction, 1e-9)
    fc = sec.f(center, k, X)
    if abs(fc) <= residual_tol:
        # We still insist on a sign-changing bracket around it.
        pass
    for it in range(int(expansions)):
        a = max(lo, center - radius)
        b = min(hi, center + radius)
        fa = sec.f(a, k, X)
        fb = sec.f(b, k, X)
        candidates = []
        if fa == 0.0:
            candidates.append((a, a))
        if fb == 0.0:
            candidates.append((b, b))
        if a < center and fa * fc <= 0.0:
            candidates.append((a, center))
        if center < b and fc * fb <= 0.0:
            candidates.append((center, b))
        if fa * fb <= 0.0:
            candidates.append((a, b))
        if candidates:
            # Use the narrowest bracket first.
            aa, bb = min(candidates, key=lambda q: abs(q[1]-q[0]))
            if aa == bb:
                r = aa
            else:
                r = brentq(lambda z: sec.f(float(z), k, X), aa, bb, xtol=root_tol, rtol=1e-14, maxiter=500)
            res = abs(sec.f(r, k, X))
            der = sec.fp(r, k, X)
            return RootCert(res <= residual_tol, float(r), float(res), float(der), float(aa), float(bb), it+1,
                            "brent_certified" if res <= residual_tol else "brent_residual_failed")
        if a <= lo and b >= hi:
            break
        radius *= 1.8
    return RootCert(False, float(center), abs(float(fc)), float(sec.fp(center, k, X)), float("nan"), float("nan"), int(expansions), "no_sign_bracket")


def route_a_local(
    sec: FrozenSecular,
    k: int,
    X: int,
    fallback: float,
    lo: float,
    hi: float,
    args,
) -> RootCert:
    ok, x, res, der, nit, why = safeguarded_newton(
        sec, k, X, fallback, lo, hi,
        args.newton_residual_tol, args.newton_iters, args.newton_max_step_fraction,
    )
    # Bracket certification is mandatory whether Newton declared convergence or not.
    cert = certify_bracket_near(
        sec, k, X, x, lo, hi, args.root_tol, args.root_residual_tol,
        args.initial_bracket_radius_fraction, args.bracket_expansions,
    )
    cert.reason = f"routeA:{why}->{cert.reason}"
    cert.iterations += nit
    return cert


def continuation_route(
    sec: FrozenSecular,
    k: int,
    X0: int,
    X1: int,
    root0: float,
    lo: float,
    hi: float,
    args,
) -> Tuple[RootCert, List[dict]]:
    xs = np.unique(np.rint(np.geomspace(int(X0), int(X1), int(args.continuation_steps))).astype(np.int64))
    if xs[0] != X0:
        xs = np.insert(xs, 0, X0)
    if xs[-1] != X1:
        xs = np.append(xs, X1)
    root = float(root0)
    rows: List[dict] = []
    final = RootCert(False, root, float("inf"), float("nan"), float("nan"), float("nan"), 0, "not_started")
    for idx, X in enumerate(tqdm(xs, desc=f"continue k={k}", unit="X")):
        if idx == 0:
            res = abs(sec.f(root, k, int(X)))
            der = sec.fp(root, k, int(X))
            cert = certify_bracket_near(
                sec, k, int(X), root, lo, hi, args.root_tol, args.root_residual_tol,
                args.initial_bracket_radius_fraction, args.bracket_expansions,
            )
            if cert.ok:
                root = cert.root
            final = cert
            rows.append({
                "k": k, "step": idx, "cutoff": int(X), "seed": f"{root0:.17g}",
                "root": f"{root:.17g}", "residual": f"{res:.17g}", "derivative": f"{der:.17g}",
                "bracket_ok": cert.ok, "step_size": "0", "reason": cert.reason,
            })
            if not cert.ok:
                return cert, rows
            continue

        seed = root
        ok, xn, resn, dern, nit, why = safeguarded_newton(
            sec, k, int(X), seed, lo, hi,
            args.newton_residual_tol, args.newton_iters, args.newton_max_step_fraction,
        )
        cert = certify_bracket_near(
            sec, k, int(X), xn, lo, hi, args.root_tol, args.root_residual_tol,
            args.initial_bracket_radius_fraction, args.bracket_expansions,
        )
        step_size = float(cert.root - root) if cert.ok else float(xn - root)
        rows.append({
            "k": k, "step": idx, "cutoff": int(X), "seed": f"{seed:.17g}",
            "root": f"{(cert.root if cert.ok else xn):.17g}",
            "residual": f"{(cert.residual if cert.ok else resn):.17g}",
            "derivative": f"{(cert.derivative if cert.ok else dern):.17g}",
            "bracket_ok": cert.ok, "step_size": f"{step_size:.17g}",
            "reason": f"{why}->{cert.reason}",
        })
        final = cert
        if not cert.ok:
            return cert, rows
        root = cert.root
    return final, rows


def diagnostic_scan(
    sec: FrozenSecular,
    k: int,
    X: int,
    lo: float,
    hi: float,
    points: int,
    root_tol: float,
    residual_tol: float,
    energy_batch: int,
    label: str,
) -> Tuple[List[dict], List[float]]:
    grid = np.linspace(lo, hi, int(points))
    vals = sec.fgrid(grid, k, X, energy_batch=energy_batch)
    crossings = np.flatnonzero(vals[:-1] * vals[1:] <= 0.0)
    roots: List[float] = []
    for j in crossings:
        a, b = float(grid[j]), float(grid[j+1])
        try:
            r = brentq(lambda z: sec.f(float(z), k, X), a, b, xtol=root_tol, rtol=1e-14, maxiter=500)
            if not roots or min(abs(r-q) for q in roots) > 10 * root_tol:
                roots.append(float(r))
        except Exception:
            pass
    # Save a compressed diagnostic representation: every point plus metadata is
    # still modest for one/few failed cells.
    rows = [{
        "k": k, "scan": label, "i": i, "E": f"{float(e):.17g}",
        "F": f"{float(v):.17g}", "absF": f"{abs(float(v)):.17g}",
    } for i, (e, v) in enumerate(zip(grid, vals))]
    return rows, roots


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v451 frozen v450 root-cell certification and branch-continuation audit",
    )
    ap.add_argument("--v445-module", default="rot_rh_clock_theta_jacobi_v445")
    ap.add_argument("--v448-module", default="rot_rh_regulator_universality_heat_v448")
    ap.add_argument("--v450-prefix", default="rot_rh_uniform_heat_tube_v450")
    ap.add_argument("--expected-v450-prefreeze-sha", default=DEFAULT_EXPECTED_PREFREEZE_SHA)
    ap.add_argument("--modes", default="", help="Optional explicit 1-based modes; default = failed v450 holdout cells.")

    ap.add_argument("--continuation-steps", type=int, default=17)
    ap.add_argument("--neighbor-cells", type=int, default=2)
    ap.add_argument("--diagnostic-scan-points", type=int, default=513)
    ap.add_argument("--energy-batch", type=int, default=32)
    ap.add_argument("--prime-chunk", type=int, default=20000)

    ap.add_argument("--newton-iters", type=int, default=16)
    ap.add_argument("--newton-residual-tol", type=float, default=2e-9)
    ap.add_argument("--newton-max-step-fraction", type=float, default=0.20)
    ap.add_argument("--root-tol", type=float, default=2e-10)
    ap.add_argument("--root-residual-tol", type=float, default=2e-8)
    ap.add_argument("--route-agreement-tol", type=float, default=5e-8)
    ap.add_argument("--minimum-absolute-derivative", type=float, default=1e-6)
    ap.add_argument("--minimum-neighbor-separation", type=float, default=1e-6)
    ap.add_argument("--initial-bracket-radius-fraction", type=float, default=2e-5)
    ap.add_argument("--bracket-expansions", type=int, default=24)

    # Development-only smoke path.  Never needed for the reported v450 failure.
    ap.add_argument("--development-force-worst-cell", action="store_true")
    ap.add_argument("--prefix", default="rot_rh_root_cell_continuation_v451")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.continuation_steps < 3:
        raise ValueError("--continuation-steps must be >=3")
    if args.neighbor_cells < 1:
        raise ValueError("--neighbor-cells must be >=1")
    if args.diagnostic_scan_points < 65:
        raise ValueError("--diagnostic-scan-points must be >=65")
    if args.root_tol <= 0 or args.root_residual_tol <= 0 or args.route_agreement_tol <= 0:
        raise ValueError("root tolerances must be positive")

    t0 = time.time()
    v445 = import_required(args.v445_module)
    v448 = import_required(args.v448_module)

    v450p = Path(args.v450_prefix).expanduser().resolve()
    def vp(suffix: str) -> Path:
        return Path(str(v450p) + suffix)

    required = {
        "summary": vp("_SUMMARY.json"),
        "prefreeze": vp("_PRE_HOLDOUT_FREEZE.json"),
        "roots": vp("_ROOT_DIAGNOSTICS.csv"),
        "heat": vp("_HEAT_GRID.csv"),
        "predvec": vp("_PREDICTED_HOLDOUT_VECTOR.csv"),
        "theta": vp("_THETA_ANCHORS.csv"),
        "cutoff_drift": vp("_TUBE_CUTOFF_DRIFT.csv"),
    }
    missing = [str(p) for p in required.values() if not p.exists()]
    if missing:
        raise SystemExit("ERROR: missing v450 output files:\n  " + "\n  ".join(missing))

    summary450 = read_json(required["summary"])
    freeze = read_json(required["prefreeze"])
    actual_prefreeze_sha = sha256_file(required["prefreeze"])
    summary_sha = str(summary450.get("prospective_freeze", {}).get("sha256", ""))
    expected_sha = str(args.expected_v450_prefreeze_sha).strip()
    sha_pass = bool(actual_prefreeze_sha == summary_sha and (not expected_sha or actual_prefreeze_sha == expected_sha))
    if not sha_pass:
        raise SystemExit(
            "ERROR: v450 pre-holdout freeze SHA mismatch.\n"
            f"  actual   : {actual_prefreeze_sha}\n"
            f"  summary  : {summary_sha}\n"
            f"  expected : {expected_sha or '(not supplied)'}\n"
            "Refusing to rescore a non-identical frozen prediction."
        )

    holdout_X = int(freeze["held_out_cutoff"])
    train_cutoffs = [int(x) for x in freeze["training_cutoffs"]]
    prev_X = train_cutoffs[-1]
    depths = [int(x) for x in freeze["depths"]]
    max_depth = max(depths)
    u_grid = np.asarray(freeze["dense_u_grid"], dtype=float)
    tube_u0 = [float(x) for x in freeze["tube_u0"]]
    hard_u0 = float(freeze["hardest_tube_u0"])
    direct_u = [float(x) for x in freeze["direct_target_u"]]
    u_max = float(max(u_grid))
    root_gate = float(freeze["gates"]["maximum_quantization_residual"])

    root_rows = read_csv(required["roots"])
    hold_rows = [r for r in root_rows if r["stage"] == "HOLDOUT" and int(r["cutoff"]) == holdout_X]
    prev_rows = [r for r in root_rows if r["stage"] == "TRAIN" and int(r["cutoff"]) == prev_X]
    if len(hold_rows) != max_depth or len(prev_rows) != max_depth:
        raise RuntimeError("v450 root diagnostics do not contain the expected max-depth rows")
    hold_by_k = {int(r["k"]): r for r in hold_rows}
    prev_by_k = {int(r["k"]): r for r in prev_rows}

    if args.modes.strip():
        modes = sorted(set(parse_ints(args.modes)))
    else:
        modes = sorted({
            int(r["k"]) for r in hold_rows
            if int(r["crossings"]) != 1 or float(r["residual"]) > root_gate
        })
    development_forced = False
    if not modes and args.development_force_worst_cell:
        modes = [max(hold_rows, key=lambda r: float(r["residual"]))["k"]]
        modes = [int(modes[0])]
        development_forced = True
    if not modes:
        print("No failed held-out v450 root cells were found. Nothing to repair.")
        return 0
    if any(k < 1 or k > max_depth for k in modes):
        raise ValueError(f"requested modes must lie in 1..{max_depth}")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 176)
    print("ROT-RH v451 — FROZEN v450 ROOT-CELL CERTIFICATION / BRANCH CONTINUATION AUDIT")
    print("=" * 176)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("frozen regulator                   : bump_2 ONLY")
    print("v450 pre-holdout SHA256            :", actual_prefreeze_sha)
    print("final training cutoff              :", prev_X)
    print("held-out cutoff                    :", holdout_X)
    print("max depth                          :", max_depth)
    print("failed/audited modes               :", modes)
    print("root acceptance                    : Route A + Route B agreement + bracket + residual + transversality")
    print("post-recovery scoring              : ORIGINAL v450 frozen envelopes; NO REFIT")
    print("=" * 176)

    print("\n[A] Building free Gamma cells and one reusable held-out Mangoldt table ...")
    free_ext = v445.free_archimedean_levels(max_depth)
    n, mang = v445.mangoldt_terms(holdout_X)
    sec = FrozenSecular(v445, v448, n, mang, holdout_X, args.prime_chunk)
    print("Mangoldt/prime-power terms         :", len(n))

    corrected_roots = np.asarray([float(hold_by_k[k]["root"]) for k in range(1, max_depth+1)], dtype=float)
    original_roots = corrected_roots.copy()

    scan_rows: List[dict] = []
    continuation_rows: List[dict] = []
    cert_rows: List[dict] = []
    all_certified = True
    any_cell_crossing = False
    any_coarse_miss = False

    print("\n[B] Auditing failed root cell(s) by two independent numerical routes ...")
    for k in modes:
        hrow = hold_by_k[k]
        prow = prev_by_k[k]
        fallback = float(hrow["root"])
        prev_root = float(prow["root"])
        nom_lo, nom_hi = original_cell_bounds(k, max_depth, free_ext)
        exp_lo, exp_hi = expanded_bounds(k, max_depth, free_ext, args.neighbor_cells)

        print(f"\n  mode k={k}: original fallback={fallback:.12f}, residual={float(hrow['residual']):.6e}, crossings={hrow['crossings']}")
        print(f"             nominal=[{nom_lo:.12f}, {nom_hi:.12f}] expanded=[{exp_lo:.12f}, {exp_hi:.12f}]")

        # Diagnostic scans are independent of branch continuation and expose
        # whether the original 64-point cell simply undersampled a sign change.
        nom_scan, nom_roots = diagnostic_scan(
            sec, k, holdout_X, nom_lo, nom_hi, args.diagnostic_scan_points,
            args.root_tol, args.root_residual_tol, args.energy_batch, "nominal",
        )
        exp_points = 2 * args.diagnostic_scan_points - 1
        exp_scan, exp_roots = diagnostic_scan(
            sec, k, holdout_X, exp_lo, exp_hi, exp_points,
            args.root_tol, args.root_residual_tol, args.energy_batch, "expanded",
        )
        scan_rows.extend(nom_scan)
        scan_rows.extend(exp_scan)

        routeA = route_a_local(sec, k, holdout_X, fallback, exp_lo, exp_hi, args)
        routeB, cont = continuation_route(sec, k, prev_X, holdout_X, prev_root, exp_lo, exp_hi, args)
        continuation_rows.extend(cont)

        agree = bool(routeA.ok and routeB.ok and abs(routeA.root - routeB.root) <= args.route_agreement_tol)
        recovered = 0.5 * (routeA.root + routeB.root) if agree else (routeB.root if routeB.ok else routeA.root)
        rec_res = abs(sec.f(recovered, k, holdout_X)) if math.isfinite(recovered) else float("inf")
        rec_der = sec.fp(recovered, k, holdout_X) if math.isfinite(recovered) else float("nan")
        trans_pass = bool(math.isfinite(rec_der) and abs(rec_der) >= args.minimum_absolute_derivative)
        inside_nominal = bool(nom_lo <= recovered <= nom_hi) if math.isfinite(recovered) else False

        # Local nonduplication/order diagnostic after replacement.
        neighbor_vals = []
        if k > 1:
            neighbor_vals.append(float(corrected_roots[k-2]))
        if k < max_depth:
            neighbor_vals.append(float(corrected_roots[k]))
        min_sep = min((abs(recovered-q) for q in neighbor_vals), default=float("inf")) if math.isfinite(recovered) else 0.0
        separation_pass = bool(min_sep >= args.minimum_neighbor_separation)

        cert_ok = bool(
            routeA.ok and routeB.ok and agree
            and rec_res <= args.root_residual_tol
            and trans_pass and separation_pass
        )
        all_certified = all_certified and cert_ok
        if cert_ok:
            corrected_roots[k-1] = recovered

        classification = "unresolved"
        if cert_ok and inside_nominal and int(hrow["crossings"]) == 0:
            classification = "coarse_grid_miss_inside_nominal_cell"
            any_coarse_miss = True
        elif cert_ok and not inside_nominal:
            classification = "continued_branch_crossed_nominal_cell_boundary"
            any_cell_crossing = True
        elif cert_ok:
            classification = "root_recertified"
        elif routeA.ok or routeB.ok:
            classification = "one_route_only_or_route_disagreement"
        else:
            classification = "branch_unresolved"

        cert_rows.append({
            "k": k,
            "original_fallback": f"{fallback:.17g}",
            "original_residual": hrow["residual"],
            "original_crossings": hrow["crossings"],
            "previous_cutoff_root": f"{prev_root:.17g}",
            "nominal_lo": f"{nom_lo:.17g}", "nominal_hi": f"{nom_hi:.17g}",
            "expanded_lo": f"{exp_lo:.17g}", "expanded_hi": f"{exp_hi:.17g}",
            "diagnostic_nominal_crossings": len(nom_roots),
            "diagnostic_expanded_crossings": len(exp_roots),
            "diagnostic_nominal_roots": ";".join(f"{x:.15g}" for x in nom_roots),
            "diagnostic_expanded_roots": ";".join(f"{x:.15g}" for x in exp_roots),
            "routeA_ok": routeA.ok, "routeA_root": f"{routeA.root:.17g}",
            "routeA_residual": f"{routeA.residual:.17g}", "routeA_derivative": f"{routeA.derivative:.17g}",
            "routeA_reason": routeA.reason,
            "routeB_ok": routeB.ok, "routeB_root": f"{routeB.root:.17g}",
            "routeB_residual": f"{routeB.residual:.17g}", "routeB_derivative": f"{routeB.derivative:.17g}",
            "routeB_reason": routeB.reason,
            "route_agreement": agree,
            "route_difference": f"{abs(routeA.root-routeB.root):.17g}" if routeA.ok and routeB.ok else "",
            "recovered_root": f"{recovered:.17g}" if math.isfinite(recovered) else "",
            "recovered_residual": f"{rec_res:.17g}",
            "recovered_derivative": f"{rec_der:.17g}",
            "transversality_pass": trans_pass,
            "inside_nominal_cell": inside_nominal,
            "minimum_neighbor_separation": f"{min_sep:.17g}",
            "neighbor_separation_pass": separation_pass,
            "certified": cert_ok,
            "classification": classification,
        })
        print(f"    Route A: ok={routeA.ok} root={routeA.root:.12f} residual={routeA.residual:.3e} F'={routeA.derivative:.6e}")
        print(f"    Route B: ok={routeB.ok} root={routeB.root:.12f} residual={routeB.residual:.3e} F'={routeB.derivative:.6e}")
        print(f"    agreement={agree} recovered={recovered:.12f} residual={rec_res:.3e} class={classification}")

    scan_path = Path(str(prefix) + "_FAILED_CELL_SCAN.csv")
    write_csv(scan_path, list(scan_rows[0].keys()), scan_rows)
    cont_path = Path(str(prefix) + "_CONTINUATION.csv")
    write_csv(cont_path, list(continuation_rows[0].keys()), continuation_rows)
    cert_path = Path(str(prefix) + "_CERTIFICATION.csv")
    write_csv(cert_path, list(cert_rows[0].keys()), cert_rows)

    print("\n[C] Re-scoring corrected held-out spectrum against ORIGINAL frozen v450 predictions ...")

    # Corrected roots file, preserving untouched v450 branches verbatim.
    corrected_rows: List[dict] = []
    audited_set = set(modes)
    for k in range(1, max_depth+1):
        old = original_roots[k-1]
        new = corrected_roots[k-1]
        corrected_rows.append({
            "k": k, "original_root": f"{old:.17g}", "corrected_root": f"{new:.17g}",
            "changed": bool(k in audited_set and abs(new-old) > 0),
            "delta": f"{(new-old):.17g}",
            "original_residual": hold_by_k[k]["residual"],
            "original_crossings": hold_by_k[k]["crossings"],
        })
    corrected_path = Path(str(prefix) + "_CORRECTED_ROOTS.csv")
    write_csv(corrected_path, list(corrected_rows[0].keys()), corrected_rows)

    # Load exact frozen dense prediction vector.
    pred_rows = read_csv(required["predvec"])
    pred_u = np.asarray([float(r["u"]) for r in pred_rows], dtype=float)
    pred_vec = np.asarray([float(r["predicted_holdout_heat"]) for r in pred_rows], dtype=float)
    if len(pred_u) != len(u_grid) or np.max(np.abs(pred_u-u_grid)) > 1e-13:
        raise RuntimeError("frozen predicted vector u-grid does not match pre-holdout manifest")

    # Load previous max-depth vector from v450, untouched by recovery.
    heat_rows450 = read_csv(required["heat"])
    prev_heat_rows = [r for r in heat_rows450 if int(r["cutoff"]) == prev_X and int(r["depth"]) == max_depth]
    prev_heat_rows.sort(key=lambda r: float(r["u"]))
    prev_u = np.asarray([float(r["u"]) for r in prev_heat_rows], dtype=float)
    prev_vec = np.asarray([float(r["heat"]) for r in prev_heat_rows], dtype=float)
    if len(prev_u) != len(u_grid) or np.max(np.abs(prev_u-u_grid)) > 1e-13:
        raise RuntimeError("previous-cutoff heat vector does not match frozen u-grid")

    corrected_vec = spectral_heat_vector(corrected_roots, u_grid)

    # Frozen target anchors from pre-holdout theta computation.
    theta_rows = read_csv(required["theta"])
    theta_by_u = {float(r["u"]): float(r["K_dehoog"]) for r in theta_rows}
    anchor_target = np.asarray([theta_by_u[min(theta_by_u, key=lambda x: abs(x-u))] for u in direct_u], dtype=float)
    anchor_idx = [int(np.argmin(np.abs(u_grid-u))) for u in direct_u]
    corrected_anchor = corrected_vec[anchor_idx]
    corrected_anchor_rms = rms(relative_components(corrected_anchor, anchor_target))
    frozen_anchor_upper = float(freeze["anchor_target_upper_envelope"])
    frozen_anchor_abs_gate = float(freeze["gates"]["maximum_holdout_anchor_target_rms"])
    anchor_pass = bool(corrected_anchor_rms <= frozen_anchor_upper and corrected_anchor_rms <= frozen_anchor_abs_gate)

    # Frozen tube envelopes.
    tube_predictions_raw = freeze["tube_predictions"]
    tube_predictions = {float(k): v for k, v in tube_predictions_raw.items()}
    corrected_tube_rows: List[dict] = []
    tube_envelope_pass = True
    hard_cutoff_sup = 0.0
    for u0 in tube_u0:
        supv, rmsv, count = tube_metrics(prev_vec, corrected_vec, u_grid, u0, u_max)
        key = min(tube_predictions, key=lambda x: abs(x-u0))
        pred = float(tube_predictions[key]["predicted_sup_drift"])
        upper = float(tube_predictions[key]["upper_envelope"])
        ok = bool(supv <= upper)
        tube_envelope_pass = tube_envelope_pass and ok
        if abs(u0-hard_u0) < 1e-14:
            hard_cutoff_sup = supv
        corrected_tube_rows.append({
            "u0": f"{u0:.17g}", "sup_drift": f"{supv:.17g}", "rms_drift": f"{rmsv:.17g}",
            "grid_points": count, "frozen_prediction": f"{pred:.17g}",
            "frozen_upper_envelope": f"{upper:.17g}", "pass": ok,
        })
    hard_cutoff_abs_gate = float(freeze["gates"]["maximum_hard_tube_cutoff_sup"])
    hard_cutoff_pass = bool(hard_cutoff_sup <= hard_cutoff_abs_gate)

    # Dense target-free frozen holdout vector.
    pred_comp = symmetric_components(pred_vec, corrected_vec)
    vector_sup = float(np.max(pred_comp))
    vector_rms = float(np.sqrt(np.mean(pred_comp*pred_comp)))
    vector_abs_gate = float(freeze["gates"]["maximum_holdout_vector_prediction_sup"])
    hard_key = min(tube_predictions, key=lambda x: abs(x-hard_u0))
    vector_training_upper = float(tube_predictions[hard_key]["upper_envelope"])
    vector_pass = bool(vector_sup <= vector_abs_gate and vector_sup <= vector_training_upper)

    # Recompute depth stability from corrected roots.
    corrected_depth_vectors = {D: spectral_heat_vector(corrected_roots[:D], u_grid) for D in depths}
    depth_rows: List[dict] = []
    hard_depth_sup = 0.0
    for da, db in zip(depths[:-1], depths[1:]):
        for u0 in tube_u0:
            supv, rmsv, count = tube_metrics(corrected_depth_vectors[da], corrected_depth_vectors[db], u_grid, u0, u_max)
            depth_rows.append({
                "depth_from": da, "depth_to": db, "u0": f"{u0:.17g}",
                "sup_drift": f"{supv:.17g}", "rms_drift": f"{rmsv:.17g}", "grid_points": count,
            })
            if db == max_depth and abs(u0-hard_u0) < 1e-14:
                hard_depth_sup = max(hard_depth_sup, supv)
    depth_gate = float(freeze["gates"]["maximum_hard_tube_depth_sup"])
    depth_pass = bool(hard_depth_sup <= depth_gate)

    # Tail-improvement is rechecked against the last TRAINING drift from v450.
    cutoff_drift450 = read_csv(required["cutoff_drift"])
    final_train_by_u0: Dict[float, float] = {}
    for u0 in tube_u0:
        candidates = [
            r for r in cutoff_drift450
            if r["stage"] == "TRAIN" and int(r["to_cutoff"]) == prev_X and abs(float(r["u0"])-u0) < 1e-13
        ]
        if len(candidates) != 1:
            raise RuntimeError(f"could not identify final v450 training tube drift for u0={u0}")
        final_train_by_u0[u0] = float(candidates[0]["sup_drift"])
    tail_improved = all(
        float(r["sup_drift"]) <= final_train_by_u0[float(r["u0"])]
        for r in corrected_tube_rows
    )

    # Root cleanliness after surgical correction.  Untouched branches must keep
    # the original v450 cleanliness; audited branches must have two-route certs.
    untouched_clean = True
    for k in range(1, max_depth+1):
        if k in audited_set:
            continue
        rr = hold_by_k[k]
        untouched_clean = untouched_clean and int(rr["crossings"]) == 1 and float(rr["residual"]) <= root_gate
    root_recovery_pass = bool(all_certified and untouched_clean)

    rescore_rows: List[dict] = []
    for u, pred, corr, old in zip(u_grid, pred_vec, corrected_vec, spectral_heat_vector(original_roots, u_grid)):
        rescore_rows.append({
            "u": f"{u:.17g}", "frozen_predicted_heat": f"{pred:.17g}",
            "original_v450_holdout_heat": f"{old:.17g}", "corrected_holdout_heat": f"{corr:.17g}",
            "correction_delta": f"{(corr-old):.17g}",
            "prediction_symmetric_error": f"{abs(corr-pred)/max(abs(corr),abs(pred),1e-300):.17g}",
        })
    rescore_path = Path(str(prefix) + "_RESCORE.csv")
    write_csv(rescore_path, list(rescore_rows[0].keys()), rescore_rows)
    tube_path = Path(str(prefix) + "_TUBE_RESCORE.csv")
    write_csv(tube_path, list(corrected_tube_rows[0].keys()), corrected_tube_rows)
    depth_path = Path(str(prefix) + "_DEPTH_RESCORE.csv")
    write_csv(depth_path, list(depth_rows[0].keys()), depth_rows)

    # Determine whether the local spectrum stayed strictly ordered after the
    # branch replacement.  This is diagnostic but required for strongest PASS.
    diffs = np.diff(corrected_roots)
    ordering_pass = bool(np.all(diffs > args.minimum_neighbor_separation))
    minimum_level_gap = float(np.min(diffs)) if diffs.size else float("inf")

    frozen_heat_pass = all([
        anchor_pass,
        tube_envelope_pass,
        hard_cutoff_pass,
        vector_pass,
        depth_pass,
        tail_improved,
    ])

    if not root_recovery_pass:
        verdict = "FAILED_BRANCH_CERTIFICATION_NOT_RECOVERED"
    elif not ordering_pass:
        verdict = "ROOT_RECOVERED_BUT_LOCAL_SPECTRAL_ORDERING_NOT_CLEAN"
    elif not frozen_heat_pass:
        verdict = "ROOT_RECOVERED_BUT_ORIGINAL_V450_FROZEN_HEAT_HOLDOUT_FAILED"
    elif any_cell_crossing:
        verdict = "V450_UNIFORM_HEAT_HOLDOUT_RECOVERED__CERTIFIED_CELL_BOUNDARY_CONTINUATION"
    elif any_coarse_miss:
        verdict = "V450_UNIFORM_HEAT_HOLDOUT_RECOVERED__CERTIFIED_COARSE_GRID_MISS"
    else:
        verdict = "V450_UNIFORM_HEAT_HOLDOUT_RECOVERED__CERTIFIED_ROOT_RECOVERY"

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time()-t0,
        "verdict": verdict,
        "scientific_boundary": (
            "Finite numerical root certification and re-score of an already-frozen v450 prospective holdout. "
            "No convergence law is refit. This does not prove all-mode branch persistence, operator convergence, "
            "an exact Hilbert-Pólya operator, or RH."
        ),
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_used": False,
            "regulator_changed": False,
            "v450_predictions_refit": False,
            "v450_prefreeze_sha256": actual_prefreeze_sha,
            "expected_prefreeze_sha256": expected_sha,
            "prefreeze_sha_verified": sha_pass,
        },
        "v450": {
            "prefix": str(v450p),
            "original_verdict": summary450.get("verdict"),
            "training_cutoff": prev_X,
            "holdout_cutoff": holdout_X,
            "depths": depths,
            "audited_modes": modes,
            "development_forced_worst_cell": development_forced,
        },
        "root_certification": {
            "all_audited_modes_certified": bool(all_certified),
            "untouched_modes_clean": bool(untouched_clean),
            "root_recovery_pass": bool(root_recovery_pass),
            "any_coarse_grid_miss": bool(any_coarse_miss),
            "any_cell_boundary_crossing": bool(any_cell_crossing),
            "ordering_pass": bool(ordering_pass),
            "minimum_corrected_level_gap": minimum_level_gap,
            "certificates": cert_rows,
        },
        "frozen_v450_rescore": {
            "corrected_anchor_target_rms": corrected_anchor_rms,
            "frozen_anchor_upper_envelope": frozen_anchor_upper,
            "anchor_pass": bool(anchor_pass),
            "tube_scores": corrected_tube_rows,
            "hardest_tube_cutoff_sup": hard_cutoff_sup,
            "hardest_tube_absolute_gate": hard_cutoff_abs_gate,
            "hardest_tube_pass": bool(hard_cutoff_pass),
            "dense_target_free_prediction_sup": vector_sup,
            "dense_target_free_prediction_rms": vector_rms,
            "dense_prediction_pass": bool(vector_pass),
            "hardest_tube_depth_sup": hard_depth_sup,
            "depth_pass": bool(depth_pass),
            "tail_improved_all_tubes": bool(tail_improved),
            "all_original_frozen_heat_tests_pass": bool(frozen_heat_pass),
        },
        "modules": {"v445": module_sha(v445), "v448": module_sha(v448)},
        "parameters": vars(args),
        "outputs": {
            "failed_cell_scan": scan_path.name,
            "continuation": cont_path.name,
            "certification": cert_path.name,
            "corrected_roots": corrected_path.name,
            "rescore": rescore_path.name,
            "tube_rescore": tube_path.name,
            "depth_rescore": depth_path.name,
        },
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n" + "=" * 176)
    print("KEY RESULTS")
    print("=" * 176)
    print("verdict                                  :", verdict)
    print("v450 pre-holdout SHA verified           :", sha_pass)
    print("audited modes                           :", modes)
    print("all audited branches certified          :", all_certified)
    for r in cert_rows:
        print(
            f"  k={int(r['k']):<4d} class={r['classification']} "
            f"root={float(r['recovered_root'] or 'nan'):.12f} residual={float(r['recovered_residual']):.3e} "
            f"F'={float(r['recovered_derivative']):.6e} agree={r['route_agreement']}"
        )
    print("corrected spectrum strictly ordered     :", ordering_pass, " min_gap=", f"{minimum_level_gap:.6e}")
    print("\nORIGINAL frozen v450 re-score           :")
    print("  corrected anchor target RMS           :", f"{corrected_anchor_rms:.6e}", " pass=", anchor_pass)
    print("  uniform cutoff-drift tubes            :")
    for r in sorted(corrected_tube_rows, key=lambda z: float(z["u0"]), reverse=True):
        print(
            f"    u0={float(r['u0']):<9.6g} sup={float(r['sup_drift']):.6e} "
            f"pred={float(r['frozen_prediction']):.6e} upper={float(r['frozen_upper_envelope']):.6e} pass={r['pass']}"
        )
    print("  dense target-free prediction sup      :", f"{vector_sup:.6e}", " pass=", vector_pass)
    print("  dense target-free prediction RMS      :", f"{vector_rms:.6e}")
    print("  hardest-tube depth sup                :", f"{hard_depth_sup:.6e}", " pass=", depth_pass)
    print("  tail improved on every tube           :", tail_improved)
    print("  all original frozen heat tests pass   :", frozen_heat_pass)
    print("summary                                  :", summary_path)
    print("=" * 176)

    if args.strict and not (root_recovery_pass and ordering_pass and frozen_heat_pass):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
