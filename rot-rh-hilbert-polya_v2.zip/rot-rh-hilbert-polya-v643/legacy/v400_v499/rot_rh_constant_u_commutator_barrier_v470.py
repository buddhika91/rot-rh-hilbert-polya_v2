#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v470 — CONSTANT-u MOVING-CELL COMMUTATOR / BARRIER THEOREM
=================================================================

Exact reduction for the current bump-2 phase.

For E_u(L)=gamma-u/L and B_L(E)=P_L(E)-M_L(E),

    d/dL B_L(E_u(L)) = [C_q(L,E_u)+u B_E(L,E_u)]/L^2.

Define H_u=C_q+u B_E. For a multiplicity-m principal collision
B_coll=sigma*m*S_p((gamma-E)L), S_p'=P_c, one has on E=E_u

    C_coll=sigma*m*u*L*P_c(u),
    B_E,coll=-sigma*m*L*P_c(u),
    H_u,coll=0.

Thus constant-u geometry removes the principal collision exactly.

For another critical-line ordinate gamma', Delta=gamma'-gamma,
its boundary phase derivative is sigma'*m'*Delta*P_c(Delta L+u).
The compact bump satisfies p'(0)=0, p'''(0)=-12 and is flat at x=1.
Four integrations by parts give

    P_c(v)=[p'''(0)+int_0^1 p''''(x)cos(vx)dx]/v^4,

hence |P_c(v)|<=C4/|v|^4, C4=12+||p''''||_1. For
L>=2|u|/|Delta|,

    |phase_gamma'(infinity)-phase_gamma'(L)|
      <=16*m'*C4/(3|Delta|^3 L^3).

Since N(T)=O(T log T), the sum over remote critical-line ordinates converges.

Barrier: if a continuous local branch starts inside |(gamma-E)L|<U and on
both boundaries u=+/-U the midpoint error obeys |epsilon_L|<=eta with

    eta + 2m(1+sqrt(pi))/(pi U) < 1/2,

then no local half-integer label can occur on either boundary, so the branch
cannot exit and |E(L)-gamma|<U/L.

No RH or simple-zero assumption is made. Off-critical/collective control remains
open.
"""

from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
from typing import Dict, Any, List
from tqdm import tqdm

VERSION = "2026-08-28-v470-constant-u-moving-cell-commutator"


def p_bump(x: float) -> float:
    if x < 0.0:
        return math.nan
    if x >= 1.0:
        return 0.0
    r=x/(1.0-x); z=-(r*r)
    return 0.0 if z < -745.0 else math.exp(z)


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available":False,"pass":False,"error":str(exc)}
    L,u,m,sigma=sp.symbols("L u m sigma", real=True, nonzero=True)
    Pc=sp.Function("Pc")
    C=sigma*m*u*L*Pc(u)
    BE=-sigma*m*L*Pc(u)
    cancel=sp.simplify(C+u*BE)
    Delta=sp.symbols("Delta", real=True, nonzero=True)
    remote=sigma*m*Delta*Pc(Delta*L+u)
    x=sp.symbols("x", real=True)
    pb=sp.exp(-(x/(1-x))**2)
    p1=sp.simplify(sp.diff(pb,x,1).subs(x,0))
    p3=sp.simplify(sp.diff(pb,x,3).subs(x,0))
    return {
        "available":True,
        "principal_C_coll":str(C),
        "principal_BE_coll":str(BE),
        "principal_commutator":str(cancel),
        "principal_cancellation_pass":bool(cancel==0),
        "remote_boundary_derivative":str(remote),
        "p_prime_0":str(p1),
        "p_triple_prime_0":str(p3),
        "endpoint_derivative_pass":bool(p1==0 and p3==-12),
        "pass":bool(cancel==0 and p1==0 and p3==-12),
    }


def pc_numeric(u: float, n: int=6000) -> float:
    h=1.0/n; total=0.0
    for j in range(n):
        x=(j+0.5)*h
        total += p_bump(x)*math.cos(u*x)
    return total*h


def remote_scaling_demo(Delta: float, u: float) -> List[Dict[str,Any]]:
    rows=[]
    for L in (20.0,40.0,80.0,160.0):
        v=Delta*L+u; pc=pc_numeric(v); der=Delta*pc
        rows.append({"L":L,"v":v,"Pc":pc,"boundary_phase_derivative":der,
                     "L4_scaled_abs_derivative":abs(der)*L**4})
    return rows


def barrier(U: float, eta: float, m: int) -> Dict[str,Any]:
    if U<=0 or not (0<=eta<0.5) or m<1:
        raise ValueError("need U>0, 0<=eta<1/2, m>=1")
    sat=2.0*m*(1.0+math.sqrt(math.pi))/(math.pi*U)
    margin=0.5-eta-sat
    return {
        "U":U,"eta":eta,"multiplicity":m,
        "saturation_error_upper":sat,
        "boundary_label_margin":margin,
        "barrier_closes":margin>0,
        "energy_bound":"|E(L)-gamma|<U/L",
        "midpoint_threshold":4.0*m*(1.0+math.sqrt(math.pi))/math.pi,
    }


def primitive_tail(eps: float,C: float,L: float)->Dict[str,Any]:
    return {"eps":eps,"C":C,"L":L,
            "tail_bound":C*(1.0+2.0/eps)*L**(-eps)}


def write_outputs(prefix: Path, payload: Dict[str,Any]) -> None:
    summary=Path(str(prefix)+"_SUMMARY.json")
    theorem=Path(str(prefix)+"_THEOREM.md")
    cert=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    b=payload["barrier"]
    theorem_text = f"""# ROT-RH v470 — constant-u moving-cell commutator / barrier theorem

## 1. Exact moving-cell generator

For `E_u(L)=gamma-u/L` and `B_L=P_L-M_L`,

`d/dL B_L(E_u)=[C_q(L,E_u)+u B_E(L,E_u)]/L^2`.

Define `H_u=C_q+u B_E`. By v469,

`d/dL log r_L(E_u)=-i H_u/L^2`.

## 2. Principal collision cancellation

For `B_coll=sigma m S_p((gamma-E)L)`, on `E=E_u`,

`C_coll=sigma m u L P_c(u)`,

`B_E,coll=-sigma m L P_c(u)`,

therefore `C_coll+u B_E,coll=0` exactly.

The constant-u observable is collision-subtracted by geometry, without splitting
singular G7 and R7X continuations.

## 3. Remote critical-line sector

For `Delta=gamma'-gamma`,

`d phase_gamma'/dL=sigma' m' Delta P_c(Delta L+u)`.

Four integrations by parts give

`P_c(v)=[p'''(0)+int_0^1 p''''(x)cos(vx)dx]/v^4`,

with `p'''(0)=-12`. Hence `|P_c(v)|<=C4/|v|^4`, where
`C4=12+||p''''||_1`.

For `L>=2|u|/|Delta|`,

`|phase_gamma'(infinity)-phase_gamma'(L)|
 <=16m'C4/(3|Delta|^3L^3)`.

Since `N(T)=O(T log T)`, the sum `sum m'/|gamma'-gamma|^3` converges. Thus the
complete remote critical-line sector has an absolutely summable `O(L^-3)`
boundary-phase tail.

## 4. Two-boundary barrier

If a continuous local branch starts inside `|u|<U` and both boundaries satisfy

`|epsilon_L(+/-U)|<=eta`

with

`eta+2m(1+sqrt(pi))/(pi U)<1/2`,

then no local half-integer label occurs on either boundary. The branch cannot
leave the moving cell, hence

`|E(L)-gamma|<U/L`.

For selected multiplicity the exact midpoint threshold as `eta->0` is

`U>{b['midpoint_threshold']:.16e}`.

Selected test: `U={b['U']}`, `eta={b['eta']}`, margin
`{b['boundary_label_margin']:.16e}`, barrier closes `{b['barrier_closes']}`.

## 5. Remaining target

Only two explicit signed primitives are needed:

`Pi_(+U)(L)=int H_(+U)(s)ds`,

`Pi_(-U)(L)=int H_(-U)(s)ds`.

The principal collision is absent exactly and every other critical-line collision
is already summable. The remaining dangerous zero-side sector is the
off-critical/collective sector.

If `Pi_(+/-U)=O(L^(2-eps))` and the limiting phase class is the completed midpoint
class, the barrier gives fixed-mode `O(1/L)` capture.

## 6. Scope

Verdict: **{payload['verdict']}**.

This is an exact reduction theorem, not RH and not the Fredholm-Xi identity.
"""
    theorem.write_text(theorem_text,encoding="utf-8")
    cert.write_text(json.dumps({
        "schema":"ROT_RH_CONSTANT_U_COMMUTATOR_BARRIER_V1",
        "closed":{
            "moving_boundary":"E_u=gamma-u/L",
            "commutator_generator":"H_u=C_q+u B_E",
            "half_phase_ode":"d_L log r_L(E_u)=-i H_u/L^2",
            "principal_collision":"H_u,coll=0 exactly",
            "remote_critical_single":"phase tail O(1/(|Delta|^3 L^3))",
            "remote_critical_sum":"absolutely summable using N(T)=O(T log T)",
            "barrier":"two explicit boundary phase margins imply |E-gamma|<U/L"
        },
        "required_next":{
            "offcritical_sector":"analyze the functional-equation-recombined off-critical contribution to H_u",
            "signed_primitive":"prove Pi_U=O(L^(2-eps)) or stronger for u=+/-U",
            "midpoint_class":"identify limiting boundary multiplier with completed midpoint class"
        },
        "key_observable":"H_u=C_q+u B_E is collision-subtracted by scale geometry"
    },indent=2),encoding="utf-8")


def main()->int:
    ap=argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--multiplicity",type=int,default=1)
    ap.add_argument("--U",type=float,default=5.0)
    ap.add_argument("--eta",type=float,default=0.05)
    ap.add_argument("--demo-Delta",type=float,default=1.0)
    ap.add_argument("--demo-u",type=float,default=5.0)
    ap.add_argument("--eps",type=float,default=1.0)
    ap.add_argument("--prefix",default="rot_rh_constant_u_commutator_barrier_v470")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter(); prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    print("="*198)
    print("ROT-RH v470 — CONSTANT-u MOVING-CELL COMMUTATOR / BARRIER THEOREM")
    print("="*198)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("RH assumed                                  : NO")
    print("="*198)
    with tqdm(total=4,desc="v470 reduction",unit="step") as bar:
        sym=symbolic_checks(); bar.update(1)
        b=barrier(args.U,args.eta,args.multiplicity); bar.update(1)
        remote=remote_scaling_demo(args.demo_Delta,args.demo_u); bar.update(1)
        prim=primitive_tail(args.eps,1.0,100.0); bar.update(1)
    passed=bool(sym.get("pass") and b["barrier_closes"])
    verdict="EXACT_CONSTANT_U_COLLISION_COMMUTATOR_AND_BARRIER_PASS" if passed else "CONSTANT_U_BARRIER_SELF_CHECK_INCOMPLETE"
    payload={
        "version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-t0,
        "firewall":{"Xi_used":False,"zeta_numerical_values_used":False,"known_zero_ordinates_used":False,"RH_assumed":False,"simple_zeros_assumed":False},
        "symbolic":sym,"barrier":b,"remote_critical_diagnostic":remote,"primitive_example":prim,
        "exact_status":{"principal_collision_commutator":"C_coll+u B_E_coll=0","remote_critical_tail":"16 m C4/(3 |Delta|^3 L^3)","remote_sum":"finite by N(T)=O(T log T)"},
        "proof_status":"Principal and remote critical-line sectors closed for constant-u boundary observable; off-critical/collective signed primitive remains open."
    }
    write_outputs(prefix,payload)
    print("\nKEY RESULTS")
    print("-"*198)
    print("verdict                                  :",verdict)
    print("principal commutator cancellation        :",sym.get("principal_cancellation_pass"))
    print("p'(0)=0, p'''(0)=-12                     :",sym.get("endpoint_derivative_pass"))
    print("barrier closes for selected U,eta        :",b["barrier_closes"])
    print("selected boundary margin                 :",f"{b['boundary_label_margin']:.16e}")
    print("midpoint U threshold                     :",f"{b['midpoint_threshold']:.16e}")
    print("summary                                  :",str(prefix)+"_SUMMARY.json")
    print("theorem                                  :",str(prefix)+"_THEOREM.md")
    print("next certificate                         :",str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*198)
    return 2 if args.strict and not passed else 0

if __name__=="__main__":
    raise SystemExit(main())
