#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v491 — HALF-PLANE GAP / FIXED-WINDING-CLASS THEOREM
==========================================================

Purpose
-------
Sharpen the exact meaning of the v465/v470 boundary target.

Let a nonzero regular multiplier along one moving boundary be

    U(L) = R(L)/|R(L)| = exp(i*pi*epsilon(L)),

with epsilon a continuous unwrapped phase in normalized units.

If

    |Re U(L)| >= h > 0

for all L>=L0, then the bad half-integer set is avoided by

    d = asin(h)/pi > 0.

The safe set is a disjoint union

    union_n (n-1/2+d, n+1/2-d).

By continuity, epsilon(L) must remain in ONE fixed connected component.
Therefore there is one integer n_* such that

    |epsilon(L)-n_*| <= 1/2-d

for every L>=L0.

So a strict half-plane barrier is much stronger than a modulo-phase statement:
it forbids all future integer winding of the unwrapped regular phase.

For the two v470 boundaries u=+U and u=-U, a simultaneous strict gap fixes two
integer classes n_+, n_-.  The v470 collision saturation margin then traps the
branch in |E-gamma|<U/L.

Conversely, any proposed nonattained off-critical mechanism that keeps producing
unbounded unwrapped boundary winding MUST cross the bad half-integer set and
therefore cannot satisfy the v470 barrier.
"""
from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
from tqdm import tqdm

VERSION = "2026-08-29-v491-halfplane-fixed-winding-class"

def geometry(h: float):
    if not (0.0 < h <= 1.0):
        raise ValueError("need 0<h<=1")
    d=math.asin(h)/math.pi
    radius=0.5-d
    return {
        "h":h,
        "half_integer_gap":d,
        "safe_component_radius":radius,
        "safe_component_width":1.0-2.0*d,
        "pass":0.0 < d <= 0.5 and radius >= 0.0,
    }

def barrier_margin(h: float, U: float, m: int):
    d=math.asin(h)/math.pi
    sat=2.0*m*(1.0+math.sqrt(math.pi))/(math.pi*U)
    # In normalized phase units, v470 needs regular error + saturation < 1/2.
    # A half-plane gap gives distance d from bad half-integers; sufficient is
    # saturation < d.
    return {
        "U":U,
        "multiplicity":m,
        "half_integer_gap":d,
        "collision_saturation_normalized_upper":sat,
        "positive_boundary_margin":d-sat,
        "traps_if_positive":d>sat,
        "energy_capture":"|E(L)-gamma|<U/L",
    }

def write(prefix: Path,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v491 — half-plane gap / fixed winding class

Write the normalized collision-subtracted regular multiplier on one moving
boundary as

`U(L)=R(L)/|R(L)|=exp(i*pi*epsilon(L))`

with `epsilon(L)` chosen as a continuous **unwrapped** normalized phase.

Assume a strict half-plane gap

`|Re U(L)| >= h > 0`

for all sufficiently large `L`.

By v465,

`dist(epsilon(L), Z+1/2) >= d`,
`d=asin(h)/pi > 0`.

The complement of the `d`-neighborhood of the bad half-integers is the disjoint
union

`union_(n in Z) [n-1/2+d, n+1/2-d]`.

Because `epsilon(L)` is continuous on a connected tail interval, it cannot move
from one component to another without crossing a bad half-integer neighborhood.
Hence there exists **one fixed integer** `n_*` such that

`|epsilon(L)-n_*| <= 1/2-d`

for every sufficiently large `L`.

So eventual half-plane avoidance is not merely a statement modulo `pi`: it
forbids all future integer winding of the unwrapped boundary phase.

For the two v470 boundaries `u=+U` and `u=-U`, simultaneous half-plane gaps fix
two winding classes `n_+` and `n_-`.  The finite collision saturation error is

`2m(1+sqrt(pi))/(pi U)`

in normalized units.  Therefore the clean sufficient condition is

`2m(1+sqrt(pi))/(pi U) < asin(h)/pi`.

Equivalently,

`U > 2m(1+sqrt(pi))/asin(h)`.

Under that condition, the v470 two-boundary barrier traps the associated fixed
label:

`|E(L)-gamma| < U/L`.

### Consequence for the remaining nonattained sector

Any off-critical mechanism whose **unwrapped** boundary phase has arbitrarily
large winding cannot coexist with a strict v470 half-plane gap.  It must hit the
bad half-integer set infinitely often.

Thus the final boundary problem may be stated without asking for convergence to
the completed sign:

> prove either bounded fixed winding class on both moving boundaries, or prove
> that every nonattained off-critical collective mechanism necessarily develops
> unbounded boundary winding / bad half-integer crossings.

The second alternative is now the natural contradiction target after v490,
because beta-reflection does not cancel the additive bump phase.

**Verdict:** `EXACT_HALFPLANE_FIXED_WINDING_CLASS_PASS`.

This theorem is topological/elementary.  It does not itself prove the required
half-plane gap or exclude the nonattained many-mode cancellation.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_HALFPLANE_FIXED_WINDING_CLASS_V1",
        "closed":{
            "gap":"|Re U|>=h => dist(epsilon,Z+1/2)>=asin(h)/pi",
            "connected_component":
                "continuous epsilon on a tail with fixed gap lies in one fixed safe interval around one integer",
            "no_future_winding":True,
            "two_boundary_capture":
                "if saturation error < asin(h)/pi on both boundaries, v470 gives |E-gamma|<U/L"
        },
        "required_next":{
            "nonattained_winding":
                "show the v490 off-critical additive quartet system forces unbounded unwrapped boundary winding unless its signed generator lies in the v419 subquadratic primitive class",
            "or_gap":
                "prove a direct fixed half-plane gap for both u=+U and u=-U"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--h",type=float,default=0.5)
    ap.add_argument("--U",type=float,default=8.0)
    ap.add_argument("--multiplicity",type=int,default=1)
    ap.add_argument("--prefix",default="rot_rh_halfplane_fixed_winding_v491")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v491 topology",unit="step") as bar:
        g=geometry(args.h);bar.update(1)
        b=barrier_margin(args.h,args.U,args.multiplicity);bar.update(1)
    ok=bool(g["pass"])
    verdict="EXACT_HALFPLANE_FIXED_WINDING_CLASS_PASS" if ok else "FAILED"
    payload={
        "version":VERSION,
        "verdict":verdict,
        "runtime_seconds":time.perf_counter()-t0,
        "geometry":g,
        "barrier":b,
        "firewall":{
            "RH_assumed":False,
            "known_zero_ordinates_used":False,
            "numerical_zeta_used":False
        },
        "proof_status":
            "Exact connected-component consequence of the v465 half-plane gap. "
            "The existence of that gap remains the arithmetic theorem."
    }
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s)
    print("theorem:",t)
    print("certificate:",c)
    if args.strict and not ok:
        raise SystemExit(2)

if __name__=="__main__":
    main()
