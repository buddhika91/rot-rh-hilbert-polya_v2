#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v460 — BUMP-WAVELET G7 / R7 DUAL LOCALIZATION AUDIT
===========================================================

PURPOSE
-------
v459 prospectively supported the bump-wavelet / relative-commutator mechanism

    C_q(L,E)
      = sum Lambda(n)/sqrt(n) q(log n/L) sin(E log n)
        - int_(log 2)^L e^(y/2) q(y/L) sin(Ey) dy,

with the frozen conservative theorem exponents

    a = 0, p = 1.10, b = 0.90,

so that

    |C_q| = O(L^b),  |D*| >= d > 0
        => |Delta E| = O(L^(-p)).

The next analytic question is NOT another larger cutoff.  It is:

    Which recursive arithmetic sector carries C_q?

Use the exact recursive fixed-point decomposition

    x = G7 + R^7 x,

where

    x_n = (Lambda(n)-1)/(sqrt(n) log n).

For the bump-wavelet dual weight

    w_n(L,E) = log(n) q(log n/L) exp(i E log n),

we have exactly

    <w,x> = <w,G7> + <(R^T)^7 w, x>.

Therefore the discrete centered bump generator splits into

    Im<w,x> = Im<w,G7> + Im<(R^T)^7w,x>.

The literal v459 C_q differs only by the smooth Euler channel

    Euler_q
      = sum n^(-1/2) q(log n/L) sin(E log n)
        - int e^(y/2) q(y/L) sin(Ey)dy.

Hence

    C_q = Cq_G7 + Cq_R7tail + Cq_Euler

with every term evaluated without Xi, zeta values, zeta derivatives, or known
zero ordinates.

This script uses v337's exact transpose recursion:
    solve_I_minus_Kb_transpose_inplace
    apply_Klambda_transpose_shrink
    x_dot_sparse

and NEVER materializes a forward G7 coefficient array.

SCIENTIFIC STATUS
-----------------
This is a finite mechanism-localization audit.  It does not prove an all-L G7
wavelet bound.  A successful localization says the theorem attack may be
focused on the finite G7 head, while the already-contracted R7 sector is small
for the tested bump-wavelet functional.

Version: 2026-08-26-v460-bump-wavelet-g7-r7-dual
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.special import roots_legendre
from tqdm import tqdm


VERSION = "2026-08-26-v460-bump-wavelet-g7-r7-dual"
LOG2 = math.log(2.0)
LAYERS = 7


# =============================================================================
# Helpers
# =============================================================================

def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


def safe_rel(a: complex | float, b: complex | float, floor: float = 1e-14) -> float:
    aa = abs(a)
    bb = abs(b)
    return abs(a - b) / max(aa, bb, float(floor))


def read_csv(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def json_safe(x):
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    if isinstance(x, np.ndarray):
        return [json_safe(v) for v in x.tolist()]
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    return x


def load_v459_left_endpoint_rows(
    path: Path, cutoffs: Sequence[int], modes: Sequence[int]
) -> Dict[Tuple[int, int], dict]:
    rows = read_csv(path)
    out: Dict[Tuple[int, int], dict] = {}
    wantedX = set(int(x) for x in cutoffs)
    wantedK = set(int(k) for k in modes)
    for r in rows:
        if "Xa" not in r or "mode" not in r:
            continue
        X = int(float(r["Xa"]))
        k = int(float(r["mode"]))
        if X in wantedX and k in wantedK:
            out[(X, k)] = r

    missing = [
        (X, k)
        for X in cutoffs
        for k in modes
        if (int(X), int(k)) not in out
    ]
    if missing:
        raise RuntimeError(
            "v459 training interval file is missing requested left endpoints: "
            + ", ".join(f"X={X},k={k}" for X, k in missing[:12])
        )
    return out


# =============================================================================
# Bump q
# =============================================================================

def bump_q_x(x: np.ndarray) -> np.ndarray:
    xx = np.asarray(x, float)
    out = np.zeros_like(xx)
    mask = (xx > 0.0) & (xx < 1.0)
    if not np.any(mask):
        return out
    a = xx[mask]
    gap = 1.0 - a
    r = a / gap
    expo = -(r * r)
    live = expo > -745.0
    vals = np.zeros_like(a)
    if np.any(live):
        al = a[live]
        gl = gap[live]
        p = np.exp(expo[live])
        vals[live] = 2.0 * al * p / (gl ** 3)
    out[mask] = vals
    return out


# =============================================================================
# Dense log table + dual weight
# =============================================================================

def dense_logs(N: int) -> np.ndarray:
    logs = np.zeros(int(N) + 1, dtype=np.float64)
    chunk = 1_000_000
    for start in tqdm(range(2, int(N) + 1, chunk), desc=f"dense logs N={N:,}", unit="chunk"):
        stop = min(int(N) + 1, start + chunk)
        logs[start:stop] = np.log(np.arange(start, stop, dtype=np.float64))
    return logs


def build_bump_wavelet_weight(
    N: int,
    L: float,
    E: float,
    logs: np.ndarray,
    chunk: int,
) -> np.ndarray:
    """
    w_n = log(n) q(log n/L) exp(i E log n).
    Pairing with x_n=(Lambda(n)-1)/(sqrt(n)log n) gives the centered
    DISCRETE q generator.
    """
    w = np.zeros(int(N) + 1, dtype=np.complex128)
    for start in range(2, int(N) + 1, int(chunk)):
        stop = min(int(N) + 1, start + int(chunk))
        lg = logs[start:stop]
        qv = bump_q_x(lg / float(L))
        amp = lg * qv
        ang = float(E) * lg
        w[start:stop] = amp * (np.cos(ang) + 1j * np.sin(ang))
    return w


# =============================================================================
# Smooth Euler channel
# =============================================================================

def smooth_euler_q(
    N: int,
    L: float,
    E: float,
    logs: np.ndarray,
    pnt_q: int,
    chunk: int,
) -> Tuple[float, float, float]:
    """
    Euler_q = sum_{n=2}^N n^-1/2 q(log n/L) sin(E log n)
              - int_(log2)^L e^(y/2)q(y/L)sin(Ey)dy.
    """
    discrete = 0.0
    for start in range(2, int(N) + 1, int(chunk)):
        stop = min(int(N) + 1, start + int(chunk))
        n = np.arange(start, stop, dtype=np.float64)
        lg = logs[start:stop]
        qv = bump_q_x(lg / float(L))
        discrete += float(
            np.dot(
                np.sin(float(E) * lg),
                qv / np.sqrt(n),
            )
        )

    z, wg = roots_legendre(int(pnt_q))
    jac = 0.5 * (float(L) - LOG2)
    y = jac * z + 0.5 * (float(L) + LOG2)
    qy = bump_q_x(y / float(L))
    integral = float(
        np.dot(
            jac * wg * np.exp(0.5 * y) * qy,
            np.sin(float(E) * y),
        )
    )
    return discrete - integral, discrete, integral


# =============================================================================
# Exact dual G7/R7 decomposition
# =============================================================================

def dual_g7_r7(
    v337,
    w: np.ndarray,
    pp_k: np.ndarray,
    pp_lam: np.ndarray,
    logs: np.ndarray,
    chunk: int,
) -> dict:
    """
    Exact:
      x0 = <w,x>
      x7 = <(R^T)^7 w,x>
      g7 = x0-x7 = <w,G7>.
    """
    x0 = v337.x_dot_sparse(
        w,
        pp_k,
        pp_lam,
        logs,
        int(chunk),
    )

    v = w
    layer_norms = []
    for j in tqdm(range(LAYERS), desc="R^T layers", unit="layer", leave=False):
        sv = v.copy()
        v337.solve_I_minus_Kb_transpose_inplace(
            sv,
            logs[: len(sv)],
        )
        v = v337.apply_Klambda_transpose_shrink(
            sv,
            pp_k,
            pp_lam,
            logs,
        )
        del sv
        if len(v) > 2:
            layer_norms.append(
                {
                    "layer": j + 1,
                    "support_N": len(v) - 1,
                    "max_abs_weight": float(np.max(np.abs(v[2:]))),
                    "l2_weight": float(np.linalg.norm(v[2:])),
                }
            )
        else:
            layer_norms.append(
                {
                    "layer": j + 1,
                    "support_N": len(v) - 1,
                    "max_abs_weight": 0.0,
                    "l2_weight": 0.0,
                }
            )

    if len(v) > 2:
        x7 = v337.x_dot_sparse(
            v,
            pp_k,
            pp_lam,
            logs,
            int(chunk),
        )
    else:
        x7 = 0.0 + 0.0j

    g7 = x0 - x7
    return {
        "x0": complex(x0),
        "x7": complex(x7),
        "g7": complex(g7),
        "identity_relative": safe_rel(x0, g7 + x7),
        "layer_norms": layer_norms,
    }


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v337-module",
        default="rot_rh_G7_21state_dyadic_closure_v337",
    )
    ap.add_argument(
        "--v459-training-intervals",
        default="rot_rh_bump_wavelet_relative_commutator_v459_TRAINING_INTERVALS.csv",
    )
    ap.add_argument(
        "--mangoldt-cache",
        default="rot_rh_mangoldt_segmented_cache_149299200.npz",
        help="v459 cache; only terms <= each analyzed X are used.",
    )
    ap.add_argument(
        "--cutoffs",
        default="2332800,4665600,9331200",
        help=(
            "Mechanism-localization scales. Dense dual vectors scale like X; "
            "keep this modest initially. Add 18662400 only if desired."
        ),
    )
    ap.add_argument(
        "--modes",
        default="1,8,16,32",
        help="Mechanism probe modes; all v459 modes can be requested.",
    )
    ap.add_argument("--wavelet-exponent", type=float, default=0.90)
    ap.add_argument("--chunk", type=int, default=250000)
    ap.add_argument("--pnt-q", type=int, default=2048)

    # Identity gates are theorem-independent.
    ap.add_argument("--maximum-dual-identity-relative", type=float, default=5e-11)
    ap.add_argument("--maximum-Cq-reconstruction-relative", type=float, default=5e-6)

    # Mechanism classification thresholds: diagnostic, not proof.
    ap.add_argument("--maximum-median-tail-l1-share", type=float, default=0.35)
    ap.add_argument("--minimum-median-head-l1-share", type=float, default=0.50)

    ap.add_argument(
        "--prefix",
        default="rot_rh_bump_wavelet_g7_r7_dual_v460",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    cutoffs = parse_ints(args.cutoffs)
    modes = sorted(set(parse_ints(args.modes)))
    if not cutoffs or cutoffs != sorted(cutoffs):
        raise ValueError("--cutoffs must be increasing")
    if max(cutoffs) > 25_000_000:
        print(
            "WARNING: max cutoff exceeds 25M. The v337 transpose uses dense complex "
            "vectors; memory/runtime may be substantial."
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    v337 = importlib.import_module(args.v337_module)

    print("=" * 168)
    print("ROT-RH v460 — BUMP-WAVELET G7 / R7 DUAL LOCALIZATION AUDIT")
    print("=" * 168)
    print("Xi / zeta / zeta' / known zero ordinates : NONE")
    print("new root solves                            : NONE")
    print("new larger cutoff                         : NONE")
    print("cutoffs                                   :", cutoffs)
    print("modes                                     :", modes)
    print("wavelet theorem exponent b                :", args.wavelet_exponent)
    print("v337 module                               :", Path(v337.__file__).name)
    print("=" * 168)

    # -------------------------------------------------------------------------
    # A. Load v459 roots / literal Cq values.
    # -------------------------------------------------------------------------
    print("\n[A] Loading v459 root-conditioned bump-wavelet values")
    v459_path = Path(args.v459_training_intervals)
    roots = load_v459_left_endpoint_rows(v459_path, cutoffs, modes)
    print("  resolved root-conditioned points        :", len(roots))

    # -------------------------------------------------------------------------
    # B. Load sparse Mangoldt cache.
    # -------------------------------------------------------------------------
    print("\n[B] Loading v459 Mangoldt cache")
    cache_path = Path(args.mangoldt_cache)
    if not cache_path.exists():
        raise FileNotFoundError(cache_path)
    with np.load(cache_path, allow_pickle=False) as z:
        pp_k_all = np.asarray(z["n"], np.int64)
        pp_lam_all = np.asarray(z["lam"], float)
        cache_limit = int(z["limit"])
    if max(cutoffs) > cache_limit:
        raise RuntimeError(
            f"requested cutoff {max(cutoffs):,} exceeds cache limit {cache_limit:,}"
        )
    print("  cache limit                               :", f"{cache_limit:,}")
    print("  cached Mangoldt terms                    :", f"{len(pp_k_all):,}")

    # Numba warmup on a tiny synthetic problem to avoid contaminating first timing.
    print("\n[C] Numba warmup")
    warmN = 4096
    warm_logs = dense_logs(warmN)
    right = int(np.searchsorted(pp_k_all, warmN, side="right"))
    warm_ppk = pp_k_all[:right]
    warm_ppl = pp_lam_all[:right]
    vw = np.zeros(warmN + 1, dtype=np.complex128)
    vw[2:] = 1.0 + 0.0j
    sw = vw.copy()
    v337.solve_I_minus_Kb_transpose_inplace(sw, warm_logs)
    _ = v337.apply_Klambda_transpose_shrink(sw, warm_ppk, warm_ppl, warm_logs)
    _ = v337.x_dot_sparse(vw, warm_ppk, warm_ppl, warm_logs, 1024)
    del warm_logs, vw, sw
    print("  warmup complete")

    # -------------------------------------------------------------------------
    # D. Exact dual decomposition.
    # -------------------------------------------------------------------------
    rows: List[dict] = []
    layer_rows: List[dict] = []
    max_dual_identity = 0.0
    max_cq_recon = 0.0

    for X in tqdm(cutoffs, desc="G7/R7 scales", unit="scale"):
        N = int(X)
        L = math.log(float(X))
        print(f"\n  [scale X={X:,}] allocating dense log table")
        logs = dense_logs(N)

        right = int(np.searchsorted(pp_k_all, N, side="right"))
        pp_k = pp_k_all[:right]
        pp_lam = pp_lam_all[:right]

        for k in tqdm(modes, desc=f"modes X={X:,}", unit="mode", leave=False):
            r459 = roots[(X, k)]
            E = float(r459["E_left"])
            literal_Cq = float(r459["Cq_left_direct"])

            w = build_bump_wavelet_weight(
                N, L, E, logs, args.chunk
            )

            dual = dual_g7_r7(
                v337,
                w,
                pp_k,
                pp_lam,
                logs,
                args.chunk,
            )
            del w

            euler, euler_discrete, euler_integral = smooth_euler_q(
                N, L, E, logs, args.pnt_q, args.chunk
            )

            Cq_x = float(np.imag(dual["x0"]))
            Cq_g7 = float(np.imag(dual["g7"]))
            Cq_r7 = float(np.imag(dual["x7"]))
            Cq_reconstructed = Cq_g7 + Cq_r7 + euler

            recon_rel = safe_rel(Cq_reconstructed, literal_Cq, 1e-10)
            max_cq_recon = max(max_cq_recon, recon_rel)
            max_dual_identity = max(
                max_dual_identity,
                float(dual["identity_relative"]),
            )

            l1 = abs(Cq_g7) + abs(Cq_r7) + abs(euler)
            if l1 <= 1e-300:
                head_share = tail_share = euler_share = 0.0
            else:
                head_share = abs(Cq_g7) / l1
                tail_share = abs(Cq_r7) / l1
                euler_share = abs(euler) / l1

            cancel = l1 / max(abs(literal_Cq), 1e-15)
            Lb = L ** float(args.wavelet_exponent)

            rows.append(
                {
                    "X": X,
                    "L": fmt(L),
                    "mode": k,
                    "E": fmt(E),
                    "literal_Cq_v459": fmt(literal_Cq),
                    "Cq_x_centered_discrete": fmt(Cq_x),
                    "Cq_G7": fmt(Cq_g7),
                    "Cq_R7tail": fmt(Cq_r7),
                    "Cq_Euler": fmt(euler),
                    "Cq_reconstructed": fmt(Cq_reconstructed),
                    "Cq_reconstruction_relative": fmt(recon_rel),
                    "dual_identity_relative": fmt(dual["identity_relative"]),
                    "head_l1_share": fmt(head_share),
                    "tail_l1_share": fmt(tail_share),
                    "euler_l1_share": fmt(euler_share),
                    "signed_cancellation_factor": fmt(cancel),
                    "abs_literal_Cq_over_Lb": fmt(abs(literal_Cq) / Lb),
                    "abs_G7_over_Lb": fmt(abs(Cq_g7) / Lb),
                    "abs_R7tail_over_Lb": fmt(abs(Cq_r7) / Lb),
                    "abs_Euler_over_Lb": fmt(abs(euler) / Lb),
                    "Euler_discrete_baseline": fmt(euler_discrete),
                    "Euler_continuum": fmt(euler_integral),
                }
            )

            for lr in dual["layer_norms"]:
                layer_rows.append(
                    {
                        "X": X,
                        "L": fmt(L),
                        "mode": k,
                        "E": fmt(E),
                        **lr,
                    }
                )

            print(
                f"    k={k:<3d} Cq={literal_Cq:+.3e} "
                f"G7={Cq_g7:+.3e} R7={Cq_r7:+.3e} Euler={euler:+.3e} "
                f"shares H/T/E={head_share:.3f}/{tail_share:.3f}/{euler_share:.3f} "
                f"recon={recon_rel:.2e}"
            )

        del logs

    # -------------------------------------------------------------------------
    # E. Mechanism summary.
    # -------------------------------------------------------------------------
    head_shares = np.asarray([float(r["head_l1_share"]) for r in rows], float)
    tail_shares = np.asarray([float(r["tail_l1_share"]) for r in rows], float)
    euler_shares = np.asarray([float(r["euler_l1_share"]) for r in rows], float)

    median_head = float(np.median(head_shares))
    median_tail = float(np.median(tail_shares))
    median_euler = float(np.median(euler_shares))

    dual_identity_pass = bool(
        max_dual_identity <= args.maximum_dual_identity_relative
    )
    reconstruction_pass = bool(
        max_cq_recon <= args.maximum_Cq_reconstruction_relative
    )
    head_localization_diag = bool(
        median_head >= args.minimum_median_head_l1_share
        and median_tail <= args.maximum_median_tail_l1_share
    )

    if not dual_identity_pass:
        verdict = "DUAL_G7_R7_IDENTITY_FAILED"
    elif not reconstruction_pass:
        verdict = "BUMP_WAVELET_Cq_RECONSTRUCTION_FAILED"
    elif head_localization_diag:
        verdict = "BUMP_WAVELET_G7_HEAD_LOCALIZATION_SUPPORTED"
    else:
        verdict = "BUMP_WAVELET_EXACT_DECOMPOSITION_PASS__HEAD_NOT_YET_DOMINANT"

    # Scale summary per mode (descriptive only).
    mode_summary = []
    for k in modes:
        rr = [r for r in rows if int(r["mode"]) == int(k)]
        mode_summary.append(
            {
                "mode": k,
                "max_abs_literal_Cq_over_Lb": max(
                    float(r["abs_literal_Cq_over_Lb"]) for r in rr
                ),
                "max_abs_G7_over_Lb": max(
                    float(r["abs_G7_over_Lb"]) for r in rr
                ),
                "max_abs_R7tail_over_Lb": max(
                    float(r["abs_R7tail_over_Lb"]) for r in rr
                ),
                "median_head_l1_share": float(
                    np.median([float(r["head_l1_share"]) for r in rr])
                ),
                "median_tail_l1_share": float(
                    np.median([float(r["tail_l1_share"]) for r in rr])
                ),
            }
        )

    out_detail = Path(str(prefix) + "_DETAIL.csv")
    out_layers = Path(str(prefix) + "_DUAL_LAYER_NORMS.csv")
    out_summary = Path(str(prefix) + "_SUMMARY.json")
    out_theorem = Path(str(prefix) + "_THEOREM.md")

    write_csv(out_detail, rows)
    write_csv(out_layers, layer_rows)

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.time() - started,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "zeta_derivatives_used": False,
            "known_zero_ordinates_used": False,
            "new_root_solves": False,
            "new_larger_cutoff": False,
        },
        "exact_decomposition": {
            "x": "G7 + R^7 x",
            "weight": "w_n=log(n) q(log n/L) exp(i E log n)",
            "Cq": "Im<w,G7> + Im<(R^T)^7w,x> + Euler_q",
        },
        "cutoffs": cutoffs,
        "modes": modes,
        "wavelet_exponent_b": args.wavelet_exponent,
        "identity_metrics": {
            "maximum_dual_identity_relative": max_dual_identity,
            "maximum_Cq_reconstruction_relative": max_cq_recon,
            "dual_identity_pass": dual_identity_pass,
            "Cq_reconstruction_pass": reconstruction_pass,
        },
        "mechanism_diagnostic": {
            "median_head_l1_share": median_head,
            "median_tail_l1_share": median_tail,
            "median_euler_l1_share": median_euler,
            "minimum_median_head_l1_share_gate": args.minimum_median_head_l1_share,
            "maximum_median_tail_l1_share_gate": args.maximum_median_tail_l1_share,
            "head_localization_supported": head_localization_diag,
            "note": (
                "Share thresholds are mechanism diagnostics, not theorem conditions. "
                "Exact decomposition/reconstruction identities are the rigorous algebraic gates."
            ),
        },
        "mode_summary": mode_summary,
        "outputs": [
            str(out_detail),
            str(out_layers),
            str(out_summary),
            str(out_theorem),
        ],
        "proof_status": (
            "Finite exact dual decomposition of the root-conditioned bump-wavelet "
            "generator into G7, R7 tail, and smooth Euler channels. No all-L bound proved."
        ),
    }
    out_summary.write_text(
        json.dumps(json_safe(summary), indent=2),
        encoding="utf-8",
    )

    theorem = f"""# ROT-RH v460 — bump-wavelet G7/R7 localization

Verdict: **{verdict}**

## Exact identity

Let

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`

and use the exact recursive fixed point

`x=G7+R^7x`.

For

`w_n(L,E)=log(n) q(log n/L) exp(iElog n)`,

duality gives

`<w,x>=<w,G7>+<(R^T)^7w,x>`.

Taking imaginary parts and restoring the smooth discrete-minus-continuum Euler
channel gives exactly

`C_q = Cq_G7 + Cq_R7tail + Cq_Euler`.

The maximum observed dual identity relative error was

`{max_dual_identity:.6e}`

and the maximum reconstruction relative error against v459's literal prime-PNT
`C_q` was

`{max_cq_recon:.6e}`.

## Mechanism diagnostic

Median L1 shares across the requested root-conditioned probes:

- G7 head: `{median_head:.6f}`
- R7 tail: `{median_tail:.6f}`
- Euler: `{median_euler:.6f}`

These shares are diagnostics only; they are not an analytic proof.

## Analytic consequence if G7 localization persists

v402 already supplies a strict contraction theorem for the regular R7
four-jet sector in its theorem-native weighted geometry.  If the bump-wavelet
dual functional is shown to be bounded in that geometry, the R7 contribution
can be handled recursively.

The remaining new theorem would then be the finite-head inequality

`|Im <w(L,E_k(L)), G7>| <= C_k L^b`

with the v459 conservative target

`b={args.wavelet_exponent}`.

Together with the smooth Euler bound and a positive secant slope floor, v459's
exact relation gives a summable root increment.

## Scientific boundary

This audit uses no Xi, zeta numerical values, zeta derivatives, or known zero
ordinates. It does not prove the all-L G7 head inequality, cutoff independence,
RH, or a complete Hilbert-Polya theorem.
"""
    out_theorem.write_text(theorem, encoding="utf-8")

    print("\n" + "=" * 168)
    print("KEY RESULTS")
    print("=" * 168)
    print("verdict                                    :", verdict)
    print("maximum dual identity relative            :", f"{max_dual_identity:.3e}")
    print("maximum Cq reconstruction relative        :", f"{max_cq_recon:.3e}")
    print("median G7 head L1 share                   :", f"{median_head:.6f}")
    print("median R7 tail L1 share                   :", f"{median_tail:.6f}")
    print("median Euler L1 share                     :", f"{median_euler:.6f}")
    print("head-localization diagnostic              :", head_localization_diag)
    print("summary                                    :", out_summary)
    print("theorem                                    :", out_theorem)
    print("=" * 168)

    if args.strict and verdict not in {
        "BUMP_WAVELET_G7_HEAD_LOCALIZATION_SUPPORTED",
        "BUMP_WAVELET_EXACT_DECOMPOSITION_PASS__HEAD_NOT_YET_DOMINANT",
    }:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
