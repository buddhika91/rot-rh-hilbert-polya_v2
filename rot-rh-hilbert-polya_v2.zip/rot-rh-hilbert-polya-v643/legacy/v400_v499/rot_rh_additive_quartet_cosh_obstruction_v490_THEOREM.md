# ROT-RH v490 — additive quartet pairing / cosh obstruction

For the exact v481 zero expansion

`Q_L^zero(E)=-sum_rho m_rho K_L(rho-1/2+iE)`,

take one off-critical functional-equation/conjugation quartet

`rho_(sigma,tau)=1/2+sigma*a+i*tau*gamma`,
`(sigma,tau) in {+1,-1}^2`.

At the integrand level,

`sum_(sigma,tau) exp[(sigma*a+i(tau*gamma+E))y]
 =4 cosh(a y) cos(gamma y) exp(iEy)`.

Therefore the complete quartet contributes

`Q_quart(L,E)
 =-4m int p(y/L) cosh(a y) cos(gamma y) exp(iEy) dy/y`

and hence

`Im Q_quart
 =-4m int p(y/L) cosh(a y) cos(gamma y) sin(Ey) dy/y`.

So **functional-equation reflection in beta does not cancel the additive bump
phase**.  It produces the positive envelope factor `cosh(a y)`.

For the moving boundary

`E_u(L)=gamma0-u/L`

the exact chain rule gives

`d_L Im Q_quart(L,E_u)=H_(u,quart)(L)/L^2`

with

`H_(u,quart)=C_quart+u B_(E,quart)`,

where

`C_quart
 =-4m int q(y/L) cosh(a y) cos(gamma y) sin(E_u y) dy`

and

`B_(E,quart)
 =-4m int p(y/L) cosh(a y) cos(gamma y) cos(E_u y) dy`.

Thus the constant-`u` cancellation that removes the **principal critical
collision** in v470 does not remove an off-critical quartet.

This must be distinguished from v468's completed canonical-product identity:
the completed quartet factor is positive on the real axis and has zero
fractional completed phase.  That is a multiplicative canonical-product fact;
it is **not** a termwise identity for the additive finite-bump primitive.

Consequently v488's useful canonical-multiplier reduction remains valid as an
exact scalar reformulation, but completed-quartet positivity by itself does not
prove the missing finite-`L` boundary-phase control.

The remaining off-critical theorem must use one of:

1. cross-ordinate many-mode signed cancellation;
2. a subquadratic moving-boundary signed primitive;
3. a genuine multiplicative/operator/index bridge from the bump characteristic
   to the completed factor.

**Verdict:** `EXACT_ADDITIVE_QUARTET_COSH_OBSTRUCTION_PASS`.

No RH, simple-zero assumption, numerical zeta values, Xi values, or known zero
ordinates are used.
