# ROT–RH v446: Stieltjes collapse theorem

## Setup

Let

\[
G(x)=\frac{\Xi(\sqrt{x})}{\Xi(0)},\qquad G(0)=1,
\]

where evenness of \(\Xi\) makes \(G\) entire. Since \(\Xi\) has order one in \(t\), \(G\) has order \(1/2\) in \(x\).
Define \(q_m\) near the origin by

\[
\log G(x)=-\sum_{m\ge1}\frac{q_m}{m}x^m,
\]

so

\[
-\frac{G'(x)}{G(x)}=\sum_{k\ge0}q_{k+1}x^k.
\]

Assume \(q_1>0\) and set

\[
\mu_k=\frac{q_{k+1}}{q_1},\qquad k\ge0.
\]

## Theorem — all-order Stieltjes positivity collapses the remaining operator problem

Assume that \((\mu_k)_{k\ge0}\) is a Stieltjes moment sequence; equivalently, every finite Hankel and shifted-Hankel matrix

\[
[\mu_{i+j}]_{i,j=0}^{N},\qquad [\mu_{i+j+1}]_{i,j=0}^{N}
\]

is positive semidefinite.

Then there exists a positive trace-class operator \(K\) such that

\[
\boxed{G(x)=\det(I-xK)}.
\]

More precisely, the representing Stieltjes measure is forced to be

\[
\boxed{d\mu(\lambda)=\frac1{q_1}\sum_j m_j\lambda_j\,\delta_{\lambda_j}},
\]

where \(x_j=1/\lambda_j>0\) are the zeros of \(G\) and \(m_j\in\mathbb N\) are their multiplicities. Thus

\[
q_m=\sum_jm_j\lambda_j^m=\operatorname{Tr}K^m.
\]

For the Riemann \(\Xi\)-function this condition is therefore equivalent to RH and to the exact positive Fredholm identity.

## Proof

### 1. Stieltjes representation

All-order Hankel and shifted-Hankel positivity gives a positive measure \(\mu\) on \([0,\infty)\) with

\[
\mu_k=\int_0^\infty\lambda^k\,d\mu(\lambda).
\]

Because \(G(0)=1\), its logarithmic derivative is analytic in some disk around zero. Cauchy estimates therefore give an exponential bound \(q_{k+1}=O(R^k)\). Since the moments are nonnegative, any representing measure must consequently have compact support, say \([0,R]\). The compact moment problem is determinate.

### 2. The logarithmic derivative is the Cauchy/Stieltjes transform of that measure

For \(|x|<1/R\),

\[
-\frac{G'(x)}{q_1G(x)}
=\sum_{k\ge0}\mu_kx^k
=\int_0^R\frac{d\mu(\lambda)}{1-x\lambda}.
\tag{1}
\]

The right-hand side is analytic away from the positive reciprocal support \(\{1/\lambda:\lambda\in\operatorname{supp}\mu,\lambda>0\}\).

### 3. Non-real zeros are impossible

The left-hand side of (1) extends meromorphically to the whole plane because \(G\) is entire. If \(G\) had a non-real zero, \(-G'/G\) would have a pole there. But the Stieltjes transform on the right of (1) is analytic off the positive real reciprocal support. By uniqueness of analytic continuation this is impossible. Hence every zero of \(G\) is positive real.

For \(G(x)=\Xi(\sqrt x)/\Xi(0)\), this is exactly the assertion that every zero of \(\Xi(t)\) is real, i.e. RH.

### 4. Meromorphicity forces the Stieltjes measure to be pure point

A continuous component of \(\mu\) on any interval would create a non-isolated singular set / jump of the Cauchy transform across the corresponding reciprocal interval. Equation (1), however, continues as the meromorphic function \(-G'/(q_1G)\), whose singularities are isolated poles. Stieltjes inversion therefore forces \(\mu\) on \((0,R]\) to be purely atomic.

Write an atom as \(w_j\delta_{\lambda_j}\). Then

\[
\frac{w_j}{1-x\lambda_j}
\]

has residue \(-w_j/\lambda_j\) at \(x_j=1/\lambda_j\).

### 5. Residues force the self-weight law and integer multiplicity

If \(x_j\) is a zero of \(G\) of multiplicity \(m_j\), then

\[
-\frac{G'(x)}{q_1G(x)}
\sim -\frac{m_j/q_1}{x-x_j}.
\]

Comparing residues with the atomic Stieltjes transform gives

\[
\boxed{w_j=\frac{m_j\lambda_j}{q_1}}.
\]

Thus the v445 self-weight law is not an additional hypothesis; it is forced by Stieltjes positivity plus the entire-function continuation. For simple zeros \(m_j=1\).

### 6. There is no hidden atom at zero

An atom \(w_0\delta_0\) would add a positive constant \(w_0\) to (1). Integrating would produce an exponential factor \(\exp(-q_1w_0x)\) in \(G\). Such a nontrivial factor has order one, whereas \(G\) has order \(1/2\). Hence \(w_0=0\).

### 7. Trace class and the exact Fredholm determinant follow

Using the self-weight law,

\[
q_m=q_1\int\lambda^{m-1}d\mu(\lambda)
=\sum_jm_j\lambda_j^m.
\]

In particular,

\[
\sum_jm_j\lambda_j=q_1<\infty,
\]

so the positive diagonal operator with eigenvalues \(\lambda_j\), repeated \(m_j\) times, is trace class.

Its Fredholm logarithm is

\[
\log\det(I-xK)
=-\sum_{m\ge1}\frac{x^m}{m}\operatorname{Tr}K^m
=-\sum_{m\ge1}\frac{q_m}{m}x^m
=\log G(x)
\]

near the origin. Both sides are entire, so

\[
\boxed{\det(I-xK)=G(x)}
\]

globally.

Setting \(x=t^2\) gives

\[
\boxed{\det(I-t^2K)=\frac{\Xi(t)}{\Xi(0)}}.
\]

---

## Equivalent single target

Define the Euclidean recursive-clock function

\[
H(z)=G(-z)=\frac{\Xi(i\sqrt z)}{\Xi(0)}
=\frac{\xi(1/2+\sqrt z)}{\xi(1/2)}
\]

and

\[
\mathcal M(z)=\frac{d}{dz}\log H(z)
=\frac{1}{2\sqrt z}\frac{\xi'(1/2+\sqrt z)}{\xi(1/2+\sqrt z)}.
\]

The theorem says that the remaining target can be expressed as any one of the equivalent conditions

\[
\boxed{\mathcal M\text{ is Stieltjes}}
\]

\[
\Longleftrightarrow\quad
\boxed{\log H\text{ is a Thorin/complete-Bernstein exponent}}
\]

\[
\Longleftrightarrow\quad
\boxed{H^{-1}\text{ is the Laplace transform of a GGC with discrete unit Thorin masses}}
\]

\[
\Longleftrightarrow\quad
\boxed{\text{all normalized shifted }q_m\text{ Hankel tests are positive}}
\]

\[
\Longleftrightarrow\quad RH.
\]

A heat-semigroup form is obtained from the Stieltjes representation

\[
\mathcal M(z)=\int_0^\infty\frac{dU(t)}{z+t}
=\int_0^\infty e^{-zu}K(u)\,du,
\]

where

\[
K(u)=\int_0^\infty e^{-tu}\,dU(t).
\]

Thus \(\mathcal M\) is Stieltjes iff the inverse-Laplace heat kernel \(K(u)\) is completely monotone. Under the Hilbert–Pólya operator,

\[
K(u)=\operatorname{Tr}e^{-uH_{\rm HP}^2}.
\]

This is the most natural place for an additional ROT ingredient: a positive recursive-clock heat semigroup whose trace equals the theta/prime explicit-formula kernel.

## What this proves and what it does not

This theorem genuinely removes three separate open-looking tasks from v445: determinacy, pure-point support, and self-weight/multiplicity. They follow automatically once all-order Stieltjes positivity is proved.

It does **not** prove that positivity. That remaining statement is RH-strength; presenting finite Hankel positivity as if it settled the infinite hierarchy would be circular.

---

## Stronger ROT formulation: the Hilbert–Pólya kernel is a density operator up to one scalar

Since

\[
q_1=\operatorname{Tr}K,
\]

define

\[
\boxed{\rho_{\rm ROT}=K/q_1}.
\]

Then \(\rho_{\rm ROT}\ge0\) and \(\operatorname{Tr}\rho_{\rm ROT}=1\). Hence it is a genuine density operator, and

\[
\boxed{\frac{q_m}{q_1^m}=\operatorname{Tr}\rho_{\rm ROT}^m.}
\]

The normalized \(\Xi\)-logarithmic coefficients are therefore exactly the Rényi power traces/purities of one observer state.

Set

\[
a_k=\frac{q_{k+1}}{q_1^{k+1}}=\operatorname{Tr}\rho_{\rm ROT}^{k+1}.
\]

Because a density matrix obeys \(0\le\rho\le I\),

\[
\boxed{
(-1)^j\Delta^j a_k
=\operatorname{Tr}\!\left[\rho^{k+1}(I-\rho)^j\right]\ge0
}
\tag{H}
\]

for every \(j,k\ge0\).

Conversely, the Hausdorff moment theorem says that the full scalar hierarchy (H) gives a positive measure on \([0,1]\). Combined with the Stieltjes-collapse argument above and the entireness/order of \(G\), this again forces the discrete self-weighted spectrum and the Fredholm determinant. Thus RH can be reduced to the single scalar hierarchy (H).

This is more ROT-native than the raw Hankel statement: the two operators inside every inequality are simply the recursive observation state \(\rho\) and its complement \(I-\rho\).

For the theta-only v446 data,

\[
\operatorname{Tr}\rho^2=\frac{q_2}{q_1^2}
=0.06963238060969086949\ldots,
\]

and the estimated largest eigenvalue is

\[
\|\rho\|\approx\frac{0.0050052441235\ldots}{q_1}
=0.2166304096493\ldots<1.
\]

All Hausdorff differences accessible from the first 32 theta moments were positive in the v446 audit. This is finite evidence only.

## Heat representation of the density operator

If \(H_{\rm ROT}=K^{-1/2}\) (up to the chosen spectral scale), then

\[
K^m=H_{\rm ROT}^{-2m}
=\frac1{\Gamma(m)}\int_0^\infty u^{m-1}e^{-uH_{\rm ROT}^2}\,du,
\]

so

\[
\boxed{
q_m=\frac1{\Gamma(m)}\int_0^\infty u^{m-1}
\operatorname{Tr}e^{-uH_{\rm ROT}^2}\,du.
}
\]

Therefore the entire \(q_m\) hierarchy is the Mellin hierarchy of one positive heat trace. A constructive ROT proof could proceed by deriving a positive recursive-clock generator \(H_{\rm ROT}^2\) whose heat trace is equal to the theta/prime explicit-formula heat kernel. Positivity and all Hausdorff inequalities would then be automatic rather than separately proved.
