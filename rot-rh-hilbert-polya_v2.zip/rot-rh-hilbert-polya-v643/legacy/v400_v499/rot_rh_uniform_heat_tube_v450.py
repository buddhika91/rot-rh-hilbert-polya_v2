#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v450 — FROZEN BUMP-2 UNIFORM HEAT-TUBE / SPECTRAL-TAIL HOLDOUT AUDIT
================================================================================

Purpose
-------
v449 established a successful prospective holdout at six fixed heat times for
one frozen arithmetic regulator,

    W_X(n) = exp(-(x/(1-x))^2) 1_{x<1},   x = log(n)/log(X).

v450 does NOT search regulator shape, tune its parameter, or use known Riemann
zero ordinates.  It asks the harder next question:

    Does the heat-semigroup Cauchy behavior persist UNIFORMLY on intervals

        u in [u0, u_max]

    while u0 is pushed toward zero and more of the high spectrum is exposed?

The primary small-u tests are TARGET FREE:

    B_X(u0) = sup_{u in [u0,u_max]}
              |h_X(u)-h_prev(u)| / max(|h_X(u)|,|h_prev(u)|)

    D_X(u0; d1,d2) = sup_{u in [u0,u_max]}
              |h_{X,d2}(u)-h_{X,d1}(u)| / max(...)

with

    h_{X,d}(u) = sum_{k<=d} exp(-u E_k(X)^2).

A dense logarithmic u-grid is used.  Training cutoffs are constructed first.
For every heat tube, the cutoff-drift decay law is fitted using TRAINING DATA
ONLY to the two predeclared classes

    C X^{-p},            C (log X)^{-p}.

The largest cutoff is then held out.  Before it is constructed, v450 writes and
SHA256-hashes a prediction manifest containing:

  * all tube-drift fits and frozen holdout envelopes;
  * a dense target-free predicted holdout heat vector;
  * the frozen bump-2 law and numerical gates.

Only after the freeze is the held-out cutoff constructed and scored.

Theta target
------------
Direct inverse-Laplace theta evaluation is retained only at safe anchor points
(default u >= 0.002), where Stehfest and de Hoog agree.  It is NOT used as the
dense small-u target, because direct numerical inverse Laplace becomes unstable
when u is pushed too close to zero.  This separation is intentional:

  * u >= direct-target floor: target agreement + uniform Cauchy tests;
  * smaller u: target-free cutoff/depth/holdout closure only.

Scientific boundary
-------------------
A PASS is finite prospective evidence for uniform heat-trace convergence on the
sampled compact heat tubes.  It is NOT a proof of uniform convergence for all
u>0, strong-resolvent convergence, all-order Stieltjes positivity, an exact
Hilbert-Pólya operator, or RH.

Typical run (PowerShell)
------------------------
python .\\rot_rh_uniform_heat_tube_v450.py `
  --depths 64,96,128 `
  --cutoffs 583200,1166400,2332800,4665600,9331200 `
  --u-min 0.0005 --u-max 0.05 --u-points 97 `
  --tube-u0 0.008,0.004,0.002,0.001,0.0005 `
  --direct-target-u 0.002,0.004,0.008,0.015,0.03,0.05 `
  --grid-points 64 `
  --mp-dps 130 `
  --stehfest-degree 22 --dehoog-degree 34 `
  --prediction-safety 2.0 `
  --prefix rot_rh_uniform_heat_tube_v450
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import numpy as np
from tqdm import tqdm

VERSION = "2026-08-25-v450-frozen-bump2-uniform-heat-tube"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_required(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_clock_theta_jacobi_v445.py and "
            "rot_rh_regulator_universality_heat_v448.py in the same directory "
            "as v450, or pass --v445-module/--v448-module."
        )


def module_sha(module) -> Dict[str, str]:
    p = Path(module.__file__).resolve()
    return {"path": str(p), "sha256": sha256_file(p)}


def spectral_heat_vector(levels: np.ndarray, u_grid: np.ndarray) -> np.ndarray:
    e2 = np.asarray(levels, dtype=float) ** 2
    u = np.asarray(u_grid, dtype=float)
    # Shape (len(u), len(levels)); small enough for the intended depths.
    return np.exp(-np.outer(u, e2)).sum(axis=1)


def symmetric_components(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> np.ndarray:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum.reduce([np.abs(aa), np.abs(bb), np.full_like(aa, floor)])
    return np.abs(aa - bb) / scale


def relative_components(model: Sequence[float], target: Sequence[float], floor: float = 1e-300) -> np.ndarray:
    m = np.asarray(model, dtype=float)
    t = np.asarray(target, dtype=float)
    return np.abs(m - t) / np.maximum(np.abs(t), floor)


def rms(values: Iterable[float]) -> float:
    a = np.asarray(list(values), dtype=float)
    return float(np.sqrt(np.mean(a * a))) if a.size else float("nan")


def make_u_grid(u_min: float, u_max: float, points: int, must_include: Sequence[float]) -> np.ndarray:
    if not (0 < u_min < u_max):
        raise ValueError("Require 0 < --u-min < --u-max")
    if points < 16:
        raise ValueError("--u-points must be >=16")
    base = np.geomspace(float(u_min), float(u_max), int(points))
    extra = [float(u) for u in must_include if u_min <= float(u) <= u_max]
    vals = np.asarray(sorted(set([float(x) for x in base] + extra + [u_min, u_max])), dtype=float)
    return vals


def tube_mask(u_grid: np.ndarray, u0: float, u_max: float) -> np.ndarray:
    tol = 1e-14 * max(1.0, abs(u0), abs(u_max))
    return (u_grid >= u0 - tol) & (u_grid <= u_max + tol)


def tube_metrics(a: Sequence[float], b: Sequence[float], u_grid: np.ndarray, u0: float, u_max: float) -> Tuple[float, float, int]:
    comp = symmetric_components(a, b)
    mask = tube_mask(u_grid, u0, u_max)
    vals = comp[mask]
    if vals.size == 0:
        raise ValueError(f"Empty tube for u0={u0}")
    return float(np.max(vals)), float(np.sqrt(np.mean(vals * vals))), int(vals.size)


# =============================================================================
# Frozen convergence model classes (same declared classes as v449)
# =============================================================================

def _basis_value(x: np.ndarray, model: str) -> np.ndarray:
    if model == "power_X":
        return np.log(x)
    if model == "power_logX":
        return np.log(np.log(x))
    raise ValueError(model)


def fit_decay_model(x: Sequence[float], y: Sequence[float], model: str, safety: float) -> dict:
    xx = np.asarray(x, dtype=float)
    yy = np.asarray(y, dtype=float)
    if len(xx) < 3 or len(xx) != len(yy):
        raise ValueError("Need >=3 matched points for a decay fit")
    if np.any(xx <= math.e) or np.any(yy <= 0) or not np.all(np.isfinite(yy)):
        return {
            "model": model, "valid": False, "reason": "nonpositive/nonfinite data",
            "C": float("nan"), "p": float("nan"), "log_rms": float("inf"),
            "envelope_factor": float("inf"), "residuals_log": [],
        }
    t = _basis_value(xx, model)
    ly = np.log(yy)
    A = np.column_stack([np.ones_like(t), -t])
    beta, *_ = np.linalg.lstsq(A, ly, rcond=None)
    logC, p = float(beta[0]), float(beta[1])
    fitted = A @ beta
    resid = ly - fitted
    lrms = float(np.sqrt(np.mean(resid * resid)))
    env = float(max(1.0, safety * math.exp(float(np.max(np.abs(resid))))))
    return {
        "model": model,
        "valid": bool(math.isfinite(p) and math.isfinite(logC)),
        "C": float(math.exp(logC)),
        "p": p,
        "log_rms": lrms,
        "envelope_factor": env,
        "residuals_log": [float(v) for v in resid],
    }


def choose_decay_model(fits: Sequence[dict]) -> dict:
    positive = [f for f in fits if f.get("valid") and float(f.get("p", -1)) > 0]
    pool = positive if positive else [f for f in fits if f.get("valid")]
    if not pool:
        return {"valid": False, "model": "none", "p": float("nan"), "log_rms": float("inf")}
    return min(pool, key=lambda f: float(f["log_rms"]))


def decay_predict(fit: dict, x: float) -> float:
    if not fit.get("valid", False):
        return float("nan")
    C, p = float(fit["C"]), float(fit["p"])
    if fit["model"] == "power_X":
        return C * float(x) ** (-p)
    if fit["model"] == "power_logX":
        return C * math.log(float(x)) ** (-p)
    raise ValueError(fit["model"])


def phi(x: float, fit: dict) -> float:
    p = float(fit["p"])
    if fit["model"] == "power_X":
        return float(x) ** (-p)
    if fit["model"] == "power_logX":
        return math.log(float(x)) ** (-p)
    raise ValueError(fit["model"])


def extrapolate_limit_and_holdout(
    x1: int,
    x2: int,
    xh: int,
    h1: Sequence[float],
    h2: Sequence[float],
    decay_fit: dict,
) -> Tuple[List[float], List[float]]:
    """Two-point h_X = h_inf + c phi(X), using TRAINING-only exponent."""
    if not decay_fit.get("valid", False) or float(decay_fit.get("p", -1)) <= 0:
        return [float("nan")] * len(h1), [float("nan")] * len(h1)
    f1, f2, fh = phi(x1, decay_fit), phi(x2, decay_fit), phi(xh, decay_fit)
    den = f1 - f2
    if abs(den) < 1e-300:
        return [float("nan")] * len(h1), [float("nan")] * len(h1)
    lim, pred = [], []
    for a, b in zip(h1, h2):
        hinf = (b * f1 - a * f2) / den
        c = (a - b) / den
        lim.append(float(hinf))
        pred.append(float(hinf + c * fh))
    return lim, pred


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v450 frozen bump-2 uniform heat-tube prospective holdout audit",
    )
    ap.add_argument("--v445-module", default="rot_rh_clock_theta_jacobi_v445")
    ap.add_argument("--v448-module", default="rot_rh_regulator_universality_heat_v448")

    ap.add_argument("--depths", default="64,96,128")
    ap.add_argument("--cutoffs", default="583200,1166400,2332800,4665600,9331200")
    ap.add_argument("--grid-points", type=int, default=64)
    ap.add_argument("--prime-chunk", type=int, default=20000)

    ap.add_argument("--u-min", type=float, default=0.0005)
    ap.add_argument("--u-max", type=float, default=0.05)
    ap.add_argument("--u-points", type=int, default=97)
    ap.add_argument("--tube-u0", default="0.008,0.004,0.002,0.001,0.0005")

    # Direct inverse Laplace is deliberately restricted to safe anchors.
    ap.add_argument("--direct-target-u", default="0.002,0.004,0.008,0.015,0.03,0.05")
    ap.add_argument("--direct-target-floor", type=float, default=0.002)
    ap.add_argument("--mp-dps", type=int, default=130)
    ap.add_argument("--theta-quad-order", type=int, default=22)
    ap.add_argument("--theta-breakpoints", default="0,0.5,1,1.5,2,2.5,3,3.5,4,5,6")
    ap.add_argument("--stehfest-degree", type=int, default=22)
    ap.add_argument("--dehoog-degree", type=int, default=34)

    # Prospective gates.  These are frozen before holdout construction.
    ap.add_argument("--prediction-safety", type=float, default=2.0)
    ap.add_argument("--maximum-target-method-relative-gap", type=float, default=5e-4)
    ap.add_argument("--maximum-holdout-anchor-target-rms", type=float, default=5e-3)
    ap.add_argument("--maximum-hard-tube-cutoff-sup", type=float, default=5e-3)
    ap.add_argument("--maximum-hard-tube-depth-sup", type=float, default=1e-3)
    ap.add_argument("--maximum-holdout-vector-prediction-sup", type=float, default=5e-3)
    ap.add_argument("--maximum-missing-cells", type=int, default=0)
    ap.add_argument("--maximum-quantization-residual", type=float, default=2e-8)
    ap.add_argument("--tail-single-term-tol", type=float, default=1e-12)

    ap.add_argument("--prefix", default="rot_rh_uniform_heat_tube_v450")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    depths = parse_ints(args.depths)
    if len(depths) < 2 or depths != sorted(set(depths)) or min(depths) < 8:
        raise ValueError("--depths must contain >=2 unique increasing integers >=8")
    max_depth = depths[-1]

    cutoffs = parse_ints(args.cutoffs)
    if len(cutoffs) < 5 or cutoffs != sorted(set(cutoffs)):
        raise ValueError("--cutoffs must contain >=5 unique increasing values")
    if min(cutoffs[i+1] / cutoffs[i] for i in range(len(cutoffs)-1)) <= 1:
        raise ValueError("cutoffs must be strictly increasing")
    train_cutoffs = cutoffs[:-1]
    holdout_X = cutoffs[-1]

    tube_u0 = sorted(set(parse_floats(args.tube_u0)), reverse=True)
    if not tube_u0 or min(tube_u0) < args.u_min or max(tube_u0) > args.u_max:
        raise ValueError("--tube-u0 values must lie inside [u-min,u-max]")
    hard_u0 = min(tube_u0)

    direct_u = sorted(set(parse_floats(args.direct_target_u)))
    if not direct_u:
        raise ValueError("--direct-target-u must be nonempty")
    if min(direct_u) < args.direct_target_floor - 1e-15:
        raise ValueError(
            "Direct theta inverse-Laplace anchors below --direct-target-floor are forbidden; "
            "use the target-free heat-tube tests there instead."
        )
    if min(direct_u) < args.u_min or max(direct_u) > args.u_max:
        raise ValueError("--direct-target-u must lie inside [u-min,u-max]")
    if args.prediction_safety <= 1.0:
        raise ValueError("--prediction-safety must exceed 1")

    u_grid = make_u_grid(args.u_min, args.u_max, args.u_points, tube_u0 + direct_u)
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    v445 = import_required(args.v445_module)
    v448 = import_required(args.v448_module)
    mp.mp.dps = int(args.mp_dps)
    reg = v448.Regulator("bump", 2.0, "bump_2")

    print("=" * 166)
    print("ROT-RH v450 — FROZEN BUMP-2 UNIFORM HEAT-TUBE / SPECTRAL-TAIL HOLDOUT AUDIT")
    print("=" * 166)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("frozen regulator                   : bump_2 ONLY")
    print("window                             : exp(-(x/(1-x))^2) 1_{x<1}")
    print("depths                             :", depths)
    print("training cutoffs                   :", train_cutoffs)
    print("HELD-OUT cutoff                    :", holdout_X)
    print("dense heat grid                    :", len(u_grid), "points", f"[{u_grid[0]:.6g}, {u_grid[-1]:.6g}]")
    print("heat tubes u0                      :", tube_u0)
    print("direct theta anchors               :", direct_u)
    print("small-u policy                     : target-free below", args.direct_target_floor)
    print("prospective model classes          : C X^-p ; C (log X)^-p")
    print("=" * 166)

    # ------------------------------------------------------------------
    # A. Safe direct theta anchors only.
    # ------------------------------------------------------------------
    print("\n[A] Building direct theta anchor target (safe inversion region only) ...")
    target = v448.DirectThetaTarget(
        dps=args.mp_dps,
        quad_order=args.theta_quad_order,
        breakpoints=parse_floats(args.theta_breakpoints),
    )
    anchor_rows: List[dict] = []
    anchor_target: List[float] = []
    anchor_gaps: List[float] = []
    anchor_positive = True
    for uu in tqdm(direct_u, desc="theta anchor inverse Laplace", unit="u"):
        u = mp.mpf(str(uu))
        ks = target.heat(u, "stehfest", args.stehfest_degree)
        kd = target.heat(u, "dehoog", args.dehoog_degree)
        gap = float(abs(ks-kd) / max(abs(kd), mp.mpf("1e-100")))
        positive = bool(mp.re(kd) > 0 and abs(mp.im(kd)) < mp.mpf("1e-40"))
        anchor_positive = anchor_positive and positive
        anchor_target.append(float(mp.re(kd)))
        anchor_gaps.append(gap)
        anchor_rows.append({
            "u": f"{uu:.17g}",
            "K_stehfest": mp.nstr(ks, 70),
            "K_dehoog": mp.nstr(kd, 70),
            "relative_method_gap": f"{gap:.17g}",
            "positive": positive,
        })
    anchor_path = Path(str(prefix) + "_THETA_ANCHORS.csv")
    write_csv(anchor_path, list(anchor_rows[0].keys()), anchor_rows)
    max_anchor_gap = max(anchor_gaps)
    anchor_numerics_pass = anchor_positive and max_anchor_gap <= args.maximum_target_method_relative_gap

    # Map exact requested anchor u to dense grid indices (they were forced into grid).
    anchor_idx = [int(np.argmin(np.abs(u_grid - u))) for u in direct_u]
    if any(abs(float(u_grid[i]) - float(u)) > 1e-13 for i, u in zip(anchor_idx, direct_u)):
        raise RuntimeError("internal error: direct anchor missing from dense u-grid")

    # ------------------------------------------------------------------
    # B. Free Gamma cells once at maximum depth.
    # ------------------------------------------------------------------
    print("\n[B] Building free Gamma cells at maximum depth ...")
    free_ext = v445.free_archimedean_levels(max_depth)

    vectors: Dict[Tuple[int, int], np.ndarray] = {}
    records: Dict[int, Dict[str, object]] = {}
    heat_rows: List[dict] = []
    root_rows: List[dict] = []

    def construct_cutoff(X: int, stage: str) -> None:
        print(f"\n  [Mangoldt cache/{stage}] X={X}")
        n, mang = v445.mangoldt_terms(int(X))
        rec = v448.quantize_regulator(
            v445=v445,
            depth=max_depth,
            X=int(X),
            reg=reg,
            free_ext=free_ext,
            n=n,
            lam=mang,
            grid_points=args.grid_points,
            prime_chunk=args.prime_chunk,
        )
        records[X] = rec
        roots = np.asarray(rec["roots"], dtype=float)
        for k, (rr, res, cnt) in enumerate(zip(roots, rec["residuals"], rec["counts"]), 1):
            root_rows.append({
                "stage": stage, "cutoff": X, "k": k,
                "root": f"{float(rr):.17g}",
                "residual": f"{float(res):.17g}",
                "crossings": int(cnt),
            })
        for D in depths:
            vec = spectral_heat_vector(roots[:D], u_grid)
            vectors[(X, D)] = vec
            for uu, hv in zip(u_grid, vec):
                heat_rows.append({
                    "stage": stage, "cutoff": X, "depth": D,
                    "u": f"{float(uu):.17g}", "heat": f"{float(hv):.17g}",
                })

    # ------------------------------------------------------------------
    # C. TRAINING cutoffs only.
    # ------------------------------------------------------------------
    print("\n[C] Constructing TRAINING cutoffs only ...")
    for X in train_cutoffs:
        construct_cutoff(X, "TRAIN")

    # Training anchor target errors at maximum depth.
    train_anchor_rms: List[float] = []
    for X in train_cutoffs:
        v = vectors[(X, max_depth)][anchor_idx]
        train_anchor_rms.append(rms(relative_components(v, anchor_target)))

    # Training cutoff drift metrics for every tube.
    tube_training: Dict[float, List[dict]] = {u0: [] for u0 in tube_u0}
    for Xa, Xb in zip(train_cutoffs[:-1], train_cutoffs[1:]):
        va, vb = vectors[(Xa, max_depth)], vectors[(Xb, max_depth)]
        for u0 in tube_u0:
            supv, rmsv, count = tube_metrics(va, vb, u_grid, u0, args.u_max)
            tube_training[u0].append({
                "from_cutoff": Xa, "to_cutoff": Xb,
                "sup_drift": supv, "rms_drift": rmsv, "grid_points": count,
            })

    # Training depth stability.
    depth_training_rows: List[dict] = []
    for X in train_cutoffs:
        for da, db in zip(depths[:-1], depths[1:]):
            for u0 in tube_u0:
                supv, rmsv, count = tube_metrics(vectors[(X, da)], vectors[(X, db)], u_grid, u0, args.u_max)
                depth_training_rows.append({
                    "stage": "TRAIN", "cutoff": X, "depth_from": da, "depth_to": db,
                    "u0": f"{u0:.17g}", "sup_drift": f"{supv:.17g}",
                    "rms_drift": f"{rmsv:.17g}", "grid_points": count,
                })

    # ------------------------------------------------------------------
    # D. Fit TRAINING-only convergence laws and freeze holdout predictions.
    # ------------------------------------------------------------------
    print("\n[D] Fitting and FREEZING prospective uniform-tube predictions ...")

    # Target-anchor convergence model.
    target_fits = [
        fit_decay_model(train_cutoffs, train_anchor_rms, "power_X", args.prediction_safety),
        fit_decay_model(train_cutoffs, train_anchor_rms, "power_logX", args.prediction_safety),
    ]
    target_fit = choose_decay_model(target_fits)
    pred_anchor_rms = decay_predict(target_fit, holdout_X)
    anchor_upper = pred_anchor_rms * float(target_fit.get("envelope_factor", float("inf")))

    tube_fits: Dict[float, dict] = {}
    tube_predictions: Dict[float, dict] = {}
    fit_rows: List[dict] = []
    for u0 in tube_u0:
        tx = [int(r["to_cutoff"]) for r in tube_training[u0]]
        ty = [float(r["sup_drift"]) for r in tube_training[u0]]
        fits = [
            fit_decay_model(tx, ty, "power_X", args.prediction_safety),
            fit_decay_model(tx, ty, "power_logX", args.prediction_safety),
        ]
        selected = choose_decay_model(fits)
        tube_fits[u0] = selected
        pred = decay_predict(selected, holdout_X)
        upper = pred * float(selected.get("envelope_factor", float("inf")))
        tube_predictions[u0] = {"predicted_sup_drift": pred, "upper_envelope": upper}
        for f in fits:
            fit_rows.append({
                "quantity": f"tube_sup_u0={u0:.17g}",
                "model": f.get("model"), "selected": bool(f is selected),
                "valid": bool(f.get("valid", False)),
                "C": f.get("C"), "p": f.get("p"),
                "log_rms": f.get("log_rms"), "envelope_factor": f.get("envelope_factor"),
            })
    for f in target_fits:
        fit_rows.append({
            "quantity": "direct_anchor_target_rms", "model": f.get("model"),
            "selected": bool(f is target_fit), "valid": bool(f.get("valid", False)),
            "C": f.get("C"), "p": f.get("p"),
            "log_rms": f.get("log_rms"), "envelope_factor": f.get("envelope_factor"),
        })
    fits_path = Path(str(prefix) + "_TRAIN_FITS.csv")
    write_csv(fits_path, list(fit_rows[0].keys()), fit_rows)

    # Hardest tube determines the target-free pointwise holdout extrapolation.
    hard_fit = tube_fits[hard_u0]
    x1, x2 = train_cutoffs[-2], train_cutoffs[-1]
    lim_vec, pred_holdout_vec = extrapolate_limit_and_holdout(
        x1, x2, holdout_X,
        vectors[(x1, max_depth)], vectors[(x2, max_depth)], hard_fit,
    )
    pred_holdout_vec = np.asarray(pred_holdout_vec, dtype=float)
    lim_vec = np.asarray(lim_vec, dtype=float)

    pred_vec_rows = [{
        "u": f"{float(u):.17g}",
        "training_extrapolated_limit": f"{float(lim):.17g}",
        "predicted_holdout_heat": f"{float(pred):.17g}",
    } for u, lim, pred in zip(u_grid, lim_vec, pred_holdout_vec)]
    pred_vec_path = Path(str(prefix) + "_PREDICTED_HOLDOUT_VECTOR.csv")
    write_csv(pred_vec_path, list(pred_vec_rows[0].keys()), pred_vec_rows)

    # Training tail-monotonicity flags are frozen before holdout.
    training_tail_flags: Dict[str, bool] = {}
    for u0 in tube_u0:
        vals = [float(r["sup_drift"]) for r in tube_training[u0]]
        training_tail_flags[f"{u0:.17g}"] = bool(len(vals) < 2 or vals[-1] <= vals[-2])

    prediction_manifest = {
        "version": VERSION,
        "frozen_before_holdout": True,
        "frozen_regulator": {
            "name": "bump_2",
            "window": "exp(-(x/(1-x))^2) for x<1 else 0; x=log(n)/log(X)",
        },
        "training_cutoffs": train_cutoffs,
        "held_out_cutoff": holdout_X,
        "depths": depths,
        "dense_u_grid": [float(x) for x in u_grid],
        "tube_u0": tube_u0,
        "direct_target_u": direct_u,
        "small_u_target_policy": f"target-free below {args.direct_target_floor}",
        "prediction_safety": args.prediction_safety,
        "direct_anchor_target_fit": target_fit,
        "predicted_holdout_anchor_target_rms": pred_anchor_rms,
        "anchor_target_upper_envelope": anchor_upper,
        "tube_fits": {f"{u0:.17g}": tube_fits[u0] for u0 in tube_u0},
        "tube_predictions": {f"{u0:.17g}": tube_predictions[u0] for u0 in tube_u0},
        "hardest_tube_u0": hard_u0,
        "hardest_tube_fit": hard_fit,
        "predicted_holdout_vector_file": pred_vec_path.name,
        "predicted_holdout_vector_sha256": sha256_file(pred_vec_path),
        "training_tail_flags": training_tail_flags,
        "gates": {
            "maximum_target_method_relative_gap": args.maximum_target_method_relative_gap,
            "maximum_holdout_anchor_target_rms": args.maximum_holdout_anchor_target_rms,
            "maximum_hard_tube_cutoff_sup": args.maximum_hard_tube_cutoff_sup,
            "maximum_hard_tube_depth_sup": args.maximum_hard_tube_depth_sup,
            "maximum_holdout_vector_prediction_sup": args.maximum_holdout_vector_prediction_sup,
            "maximum_missing_cells": args.maximum_missing_cells,
            "maximum_quantization_residual": args.maximum_quantization_residual,
        },
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_function_called": False,
            "holdout_spectrum_constructed": False,
        },
    }
    prefreeze_path = Path(str(prefix) + "_PRE_HOLDOUT_FREEZE.json")
    prefreeze_path.write_text(json.dumps(prediction_manifest, indent=2), encoding="utf-8")
    prefreeze_sha = sha256_file(prefreeze_path)
    print("  PRE-HOLDOUT FREEZE SHA256:", prefreeze_sha)
    print("  anchor target model       :", target_fit.get("model"), "p=", f"{float(target_fit.get('p',float('nan'))):.6g}")
    print("  hardest tube model        :", hard_fit.get("model"), "p=", f"{float(hard_fit.get('p',float('nan'))):.6g}")
    print("  hardest tube predicted sup:", f"{tube_predictions[hard_u0]['predicted_sup_drift']:.6e}",
          "upper=", f"{tube_predictions[hard_u0]['upper_envelope']:.6e}")

    # ------------------------------------------------------------------
    # E. Reveal held-out cutoff only after freeze.
    # ------------------------------------------------------------------
    print("\n[E] Revealing and constructing HELD-OUT cutoff ...")
    construct_cutoff(holdout_X, "HOLDOUT")

    hold_vec = vectors[(holdout_X, max_depth)]
    prev_vec = vectors[(train_cutoffs[-1], max_depth)]

    # Direct-anchor target score.
    hold_anchor = hold_vec[anchor_idx]
    hold_anchor_rms = rms(relative_components(hold_anchor, anchor_target))
    anchor_prediction_pass = bool(hold_anchor_rms <= anchor_upper)
    anchor_absolute_pass = bool(hold_anchor_rms <= args.maximum_holdout_anchor_target_rms)

    # Holdout uniform tube cutoff scores.
    tube_holdout_rows: List[dict] = []
    all_tube_prediction_pass = True
    all_tube_positive_decay = True
    for u0 in tube_u0:
        supv, rmsv, count = tube_metrics(prev_vec, hold_vec, u_grid, u0, args.u_max)
        pred = tube_predictions[u0]["predicted_sup_drift"]
        upper = tube_predictions[u0]["upper_envelope"]
        pass_env = bool(supv <= upper)
        fit_ok = bool(tube_fits[u0].get("valid", False) and float(tube_fits[u0].get("p", -1)) > 0)
        all_tube_prediction_pass = all_tube_prediction_pass and pass_env
        all_tube_positive_decay = all_tube_positive_decay and fit_ok
        tube_holdout_rows.append({
            "stage": "HOLDOUT", "from_cutoff": train_cutoffs[-1], "to_cutoff": holdout_X,
            "u0": f"{u0:.17g}", "sup_drift": f"{supv:.17g}", "rms_drift": f"{rmsv:.17g}",
            "grid_points": count, "predicted_sup_drift": f"{pred:.17g}",
            "upper_envelope": f"{upper:.17g}", "prediction_pass": pass_env,
            "selected_model": tube_fits[u0].get("model"), "p": tube_fits[u0].get("p"),
        })

    hard_holdout_sup = float(next(float(r["sup_drift"]) for r in tube_holdout_rows if abs(float(r["u0"])-hard_u0) < 1e-15))
    hard_cutoff_absolute_pass = bool(hard_holdout_sup <= args.maximum_hard_tube_cutoff_sup)

    # Holdout depth stability on all tubes.
    holdout_depth_rows: List[dict] = []
    hard_depth_sup = 0.0
    for da, db in zip(depths[:-1], depths[1:]):
        for u0 in tube_u0:
            supv, rmsv, count = tube_metrics(vectors[(holdout_X, da)], vectors[(holdout_X, db)], u_grid, u0, args.u_max)
            holdout_depth_rows.append({
                "stage": "HOLDOUT", "cutoff": holdout_X, "depth_from": da, "depth_to": db,
                "u0": f"{u0:.17g}", "sup_drift": f"{supv:.17g}",
                "rms_drift": f"{rmsv:.17g}", "grid_points": count,
            })
            if abs(u0-hard_u0) < 1e-15 and db == max_depth:
                hard_depth_sup = max(hard_depth_sup, supv)
    hard_depth_pass = bool(hard_depth_sup <= args.maximum_hard_tube_depth_sup)

    # Target-free dense holdout-vector prediction.
    pred_comp = symmetric_components(pred_holdout_vec, hold_vec)
    holdout_vector_sup = float(np.max(pred_comp))
    holdout_vector_rms = float(np.sqrt(np.mean(pred_comp * pred_comp)))
    # Frozen absolute gate AND a training-derived envelope tied to hardest tube.
    vector_training_upper = float(tube_predictions[hard_u0]["upper_envelope"])
    vector_prediction_pass = bool(
        holdout_vector_sup <= args.maximum_holdout_vector_prediction_sup
        and holdout_vector_sup <= vector_training_upper
    )

    # Root cleanliness.
    hrec = records[holdout_X]
    counts = np.asarray(hrec["counts"], dtype=int)
    residuals = np.asarray(hrec["residuals"], dtype=float)
    hold_missing = int(np.sum(counts == 0))
    hold_ambiguous = int(np.sum(counts > 1))
    hold_max_residual = float(np.max(residuals))
    root_pass = bool(
        hold_missing <= args.maximum_missing_cells
        and hold_ambiguous == 0
        and hold_max_residual <= args.maximum_quantization_residual
    )

    # Resolution diagnostics: not a proof of the infinite tail, but ties depth
    # explicitly to the heat scale.  E_resolution makes one exponential term
    # smaller than tail-single-term-tol.
    terminal_E = float(np.asarray(hrec["roots"], dtype=float)[max_depth-1])
    resolution_rows = []
    resolution_pass_flags = []
    for u0 in tube_u0:
        E_resolution = math.sqrt(-math.log(args.tail_single_term_tol) / u0)
        ok = terminal_E >= E_resolution
        resolution_pass_flags.append(ok)
        resolution_rows.append({
            "u0": f"{u0:.17g}", "terminal_energy": f"{terminal_E:.17g}",
            "single_term_resolution_energy": f"{E_resolution:.17g}",
            "terminal_energy_exceeds_resolution": ok,
            "tail_single_term_tol": f"{args.tail_single_term_tol:.17g}",
        })
    resolution_path = Path(str(prefix) + "_HEAT_RESOLUTION.csv")
    write_csv(resolution_path, list(resolution_rows[0].keys()), resolution_rows)

    # Tail improvement including holdout: every tube holdout drift should be no
    # worse than its final training drift.  This is stricter than merely landing
    # inside a broad prediction envelope.
    holdout_tail_improved = True
    for r in tube_holdout_rows:
        u0 = float(r["u0"])
        final_train = float(tube_training[u0][-1]["sup_drift"])
        holdout_tail_improved = holdout_tail_improved and float(r["sup_drift"]) <= final_train

    # ------------------------------------------------------------------
    # F. Write complete diagnostics.
    # ------------------------------------------------------------------
    heat_path = Path(str(prefix) + "_HEAT_GRID.csv")
    write_csv(heat_path, list(heat_rows[0].keys()), heat_rows)

    roots_path = Path(str(prefix) + "_ROOT_DIAGNOSTICS.csv")
    write_csv(roots_path, list(root_rows[0].keys()), root_rows)

    cutoff_drift_rows: List[dict] = []
    for u0 in tube_u0:
        for r in tube_training[u0]:
            cutoff_drift_rows.append({
                "stage": "TRAIN", "from_cutoff": r["from_cutoff"], "to_cutoff": r["to_cutoff"],
                "u0": f"{u0:.17g}", "sup_drift": f"{float(r['sup_drift']):.17g}",
                "rms_drift": f"{float(r['rms_drift']):.17g}", "grid_points": r["grid_points"],
                "predicted_sup_drift": "", "upper_envelope": "", "prediction_pass": "",
                "selected_model": "", "p": "",
            })
    cutoff_drift_rows.extend(tube_holdout_rows)
    cutoff_path = Path(str(prefix) + "_TUBE_CUTOFF_DRIFT.csv")
    write_csv(cutoff_path, list(cutoff_drift_rows[0].keys()), cutoff_drift_rows)

    depth_all_rows = depth_training_rows + holdout_depth_rows
    depth_path = Path(str(prefix) + "_TUBE_DEPTH_DRIFT.csv")
    write_csv(depth_path, list(depth_all_rows[0].keys()), depth_all_rows)

    holdout_score_rows = []
    for u, pred, actual in zip(u_grid, pred_holdout_vec, hold_vec):
        holdout_score_rows.append({
            "u": f"{float(u):.17g}",
            "predicted_heat": f"{float(pred):.17g}",
            "actual_heat": f"{float(actual):.17g}",
            "symmetric_prediction_drift": f"{float(abs(pred-actual)/max(abs(pred),abs(actual),1e-300)):.17g}",
        })
    holdout_score_path = Path(str(prefix) + "_HOLDOUT_VECTOR_SCORE.csv")
    write_csv(holdout_score_path, list(holdout_score_rows[0].keys()), holdout_score_rows)

    anchor_score_rows = []
    for u, targetv, modelv in zip(direct_u, anchor_target, hold_anchor):
        anchor_score_rows.append({
            "u": f"{u:.17g}", "theta_dehoog": f"{targetv:.17g}",
            "holdout_heat": f"{float(modelv):.17g}",
            "relative_error": f"{abs(float(modelv)-targetv)/max(abs(targetv),1e-300):.17g}",
        })
    anchor_score_path = Path(str(prefix) + "_HOLDOUT_TARGET_ANCHORS.csv")
    write_csv(anchor_score_path, list(anchor_score_rows[0].keys()), anchor_score_rows)

    # ------------------------------------------------------------------
    # G. Verdict.
    # ------------------------------------------------------------------
    all_training_tail_ok = all(training_tail_flags.values())
    resolution_diagnostic_pass = all(resolution_pass_flags)

    core_pass = all([
        anchor_numerics_pass,
        anchor_prediction_pass,
        anchor_absolute_pass,
        all_tube_prediction_pass,
        all_tube_positive_decay,
        hard_cutoff_absolute_pass,
        hard_depth_pass,
        vector_prediction_pass,
        root_pass,
        holdout_tail_improved,
    ])

    if not anchor_numerics_pass:
        verdict = "DIRECT_THETA_ANCHOR_NUMERICS_NOT_STABLE"
    elif not anchor_prediction_pass:
        verdict = "UNIFORM_CAUCHY_PROMISING_BUT_TARGET_ANCHOR_HOLDOUT_MISSED"
    elif not all_tube_prediction_pass:
        verdict = "UNIFORM_HEAT_TUBE_HOLDOUT_MISSED_FROZEN_ENVELOPE"
    elif not all_tube_positive_decay:
        verdict = "TUBE_DRIFT_DOES_NOT_SUPPORT_POSITIVE_DECAY_EXPONENTS"
    elif not root_pass:
        verdict = "HOLDOUT_ROOT_QUANTIZATION_NOT_CLEAN"
    elif not hard_depth_pass:
        verdict = "CUTOFF_TUBE_CONVERGES_BUT_SMALL_U_DEPTH_CLOSURE_FAILED"
    elif not vector_prediction_pass:
        verdict = "TUBE_DRIFT_OK_BUT_DENSE_TARGET_FREE_VECTOR_PREDICTION_FAILED"
    elif not hard_cutoff_absolute_pass or not anchor_absolute_pass:
        verdict = "PROSPECTIVE_HOLDOUT_PASSED_BUT_ABSOLUTE_UNIFORM_GATES_NOT_MET"
    elif not holdout_tail_improved:
        verdict = "HOLDOUT_INSIDE_ENVELOPE_BUT_UNIFORM_TUBE_TAIL_NOT_IMPROVING"
    else:
        verdict = "FROZEN_BUMP2_UNIFORM_HEAT_TUBE_HOLDOUT_SUPPORTED"

    manifest = {
        "version": VERSION,
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "modules": {"v445": module_sha(v445), "v448": module_sha(v448)},
        "parameters": vars(args),
        "pre_holdout_prediction_manifest": prefreeze_path.name,
        "pre_holdout_prediction_sha256": prefreeze_sha,
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_function_called": False,
            "frozen_regulator": "bump_2",
            "holdout_constructed_only_after_prediction_freeze": True,
        },
    }
    manifest_path = Path(str(prefix) + "_FREEZE.json")
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time() - t0,
        "verdict": verdict,
        "scientific_boundary": (
            "Finite prospective zero-ordinate-free evidence on sampled compact heat tubes only. "
            "This does not prove uniform convergence for all u>0, semigroup/operator convergence, "
            "all-order Stieltjes positivity, an exact Hilbert-Pólya operator, or RH."
        ),
        "frozen_law": {
            "regulator": "bump_2",
            "window": "exp(-(x/(1-x))^2) for x<1 else 0; x=log(n)/log(X)",
        },
        "dense_heat_grid": {
            "u_min": args.u_min, "u_max": args.u_max,
            "points": int(len(u_grid)), "tube_u0": tube_u0,
            "small_u_target_policy": f"target-free below {args.direct_target_floor}",
        },
        "direct_theta_anchors": {
            "u": direct_u,
            "maximum_stehfest_dehoog_relative_gap": max_anchor_gap,
            "numerics_pass": bool(anchor_numerics_pass),
            "training_target_rms": {str(X): train_anchor_rms[i] for i, X in enumerate(train_cutoffs)},
            "selected_fit": target_fit,
            "predicted_holdout_rms": pred_anchor_rms,
            "upper_envelope": anchor_upper,
            "actual_holdout_rms": hold_anchor_rms,
            "prediction_pass": bool(anchor_prediction_pass),
            "absolute_gate_pass": bool(anchor_absolute_pass),
        },
        "prospective_freeze": {
            "manifest": prefreeze_path.name,
            "sha256": prefreeze_sha,
            "hardest_tube_u0": hard_u0,
            "hardest_tube_fit": hard_fit,
            "tube_fits": {str(u0): tube_fits[u0] for u0 in tube_u0},
            "tube_predictions": {str(u0): tube_predictions[u0] for u0 in tube_u0},
        },
        "holdout": {
            "cutoff": holdout_X,
            "tube_scores": tube_holdout_rows,
            "hardest_tube_cutoff_sup": hard_holdout_sup,
            "hardest_tube_depth_sup": hard_depth_sup,
            "target_free_vector_prediction_sup": holdout_vector_sup,
            "target_free_vector_prediction_rms": holdout_vector_rms,
            "missing_cells": hold_missing,
            "ambiguous_cells": hold_ambiguous,
            "maximum_quantization_residual": hold_max_residual,
            "tail_improved_all_tubes": bool(holdout_tail_improved),
            "terminal_energy": terminal_E,
            "heat_resolution_diagnostic_pass": bool(resolution_diagnostic_pass),
        },
        "training_diagnostics": {
            "training_tail_flags": training_tail_flags,
            "all_training_tail_flags_true": bool(all_training_tail_ok),
        },
        "gates": {
            "maximum_target_method_relative_gap": args.maximum_target_method_relative_gap,
            "maximum_holdout_anchor_target_rms": args.maximum_holdout_anchor_target_rms,
            "maximum_hard_tube_cutoff_sup": args.maximum_hard_tube_cutoff_sup,
            "maximum_hard_tube_depth_sup": args.maximum_hard_tube_depth_sup,
            "maximum_holdout_vector_prediction_sup": args.maximum_holdout_vector_prediction_sup,
            "maximum_missing_cells": args.maximum_missing_cells,
            "maximum_quantization_residual": args.maximum_quantization_residual,
        },
        "outputs": {
            "theta_anchors": anchor_path.name,
            "train_fits": fits_path.name,
            "predicted_holdout_vector": pred_vec_path.name,
            "pre_holdout_freeze": prefreeze_path.name,
            "heat_grid": heat_path.name,
            "tube_cutoff_drift": cutoff_path.name,
            "tube_depth_drift": depth_path.name,
            "root_diagnostics": roots_path.name,
            "holdout_vector_score": holdout_score_path.name,
            "holdout_target_anchors": anchor_score_path.name,
            "heat_resolution": resolution_path.name,
            "freeze_manifest": manifest_path.name,
        },
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n" + "=" * 166)
    print("KEY RESULTS")
    print("=" * 166)
    print("verdict                                  :", verdict)
    print("direct theta anchors stable              :", anchor_numerics_pass)
    print("max Stehfest/de Hoog anchor gap          :", f"{max_anchor_gap:.6e}")
    print("pre-holdout freeze SHA256                :", prefreeze_sha)
    print("anchor target convergence model          :", target_fit.get("model"), "p=", f"{float(target_fit.get('p',float('nan'))):.6g}")
    print("hardest tube convergence model           :", hard_fit.get("model"), "p=", f"{float(hard_fit.get('p',float('nan'))):.6g}")
    print("\ntraining direct-anchor target RMS        :")
    for X, e in zip(train_cutoffs, train_anchor_rms):
        print(f"  X={X:<10d} {e:.6e}")
    print("\nHELD-OUT cutoff                          :", holdout_X)
    print("predicted anchor RMS / upper             :", f"{pred_anchor_rms:.6e} / {anchor_upper:.6e}")
    print("actual anchor RMS                        :", f"{hold_anchor_rms:.6e}", " pass=", anchor_prediction_pass)
    print("\nuniform cutoff-drift tube scores         :")
    for r in sorted(tube_holdout_rows, key=lambda z: float(z["u0"]), reverse=True):
        print(
            f"  u0={float(r['u0']):<9.6g} sup={float(r['sup_drift']):.6e} "
            f"pred={float(r['predicted_sup_drift']):.6e} upper={float(r['upper_envelope']):.6e} "
            f"pass={r['prediction_pass']}"
        )
    print("hardest-tube depth sup drift             :", f"{hard_depth_sup:.6e}", " pass=", hard_depth_pass)
    print("dense target-free holdout prediction sup :", f"{holdout_vector_sup:.6e}", " pass=", vector_prediction_pass)
    print("dense target-free holdout prediction RMS :", f"{holdout_vector_rms:.6e}")
    print("holdout missing / ambiguous cells        :", hold_missing, "/", hold_ambiguous)
    print("holdout max quantization residual        :", f"{hold_max_residual:.6e}")
    print("holdout tail improved on every tube      :", holdout_tail_improved)
    print("terminal energy                          :", f"{terminal_E:.9f}")
    print("heat-resolution diagnostic pass          :", resolution_diagnostic_pass)
    print("summary                                  :", summary_path)
    print("=" * 166)

    if args.strict and not core_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
