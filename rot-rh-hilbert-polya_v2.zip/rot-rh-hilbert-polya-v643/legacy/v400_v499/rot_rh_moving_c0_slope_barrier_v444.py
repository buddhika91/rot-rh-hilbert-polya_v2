#!/usr/bin/env python3
"""
ROT-RH v444 — MOVING C0/L + RENORMALIZED SLOPE BARRIER CLOSURE

Key exact collapse
------------------
v424 defines, on the moving characteristic,

    beta_k(L) = C0_k(L) / Fp_k(L),

and let

    g_k(L) = Fp_k(L) / L.

v425 gives the exact signed-RG identity

    Q_k(L) = -log(g_k(L)/g_k(L0)),

so

    exp(-Q_k(L)) = g_k(L)/g_k(L0).

The v442 Duhamel variable is

    Y_k(L) = L exp(-Q_k(L)) beta_k(L).

Therefore, identically,

    Y_k(L)
      = L [g_k(L)/g_k(L0)] [C0_k(L)/(L g_k(L))]
      = C0_k(L)/g_k(L0).

Thus the v443 weighted Duhamel-prefix theorem is equivalent to direct
control of the moving arithmetic numerator.

A sufficient cutoff-independence theorem is therefore:

    |C0_k(L)| <= A_k L
    g_k(L) >= c_k > 0

for every sufficiently large L along each eventual ordered branch.

Then

    |beta_k(L)| = |C0_k(L)| / [L g_k(L)] <= A_k/c_k,

and since the exact root flow is

    E'_k(L) = beta_k(L)/L^2,

we obtain

    |E_k(infinity)-E_k(L)| <= (A_k/c_k)/L.

This script:
  * verifies the Q <-> slope identity;
  * verifies the exact Duhamel collapse Y=C0/g0;
  * freezes prospective development envelopes for |C0|/L;
  * freezes a prospective development lower barrier for g=F'/L;
  * tests untouched holdout shells;
  * emits the conditional O(1/L) tail constant.

It does NOT claim the all-L theorem from a finite holdout.

Firewall:
  - no Xi values
  - no zeta values
  - no known zero ordinates
  - no new root solves
  - no larger cutoffs
  - no finite fit/regression accepted as proof

Notation warning:
The beta/B in the v424-v444 characteristic flow is a scalar arithmetic
root-flow forcing.  It is not the bounded Jacobi operator B_L.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(it=None, *args, **kwargs):
        return it


VERSION = "444"
EXPECTED_V442 = "EXACT_LOG_BETA_DUHAMEL_REDUCTION_PASS_SOURCE_BOUND_OPEN"
EPS = 1.0e-300


def load_json(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return json.loads(p.read_text(encoding="utf-8"))


def require_columns(df: pd.DataFrame, cols: set[str], label: str) -> None:
    missing = sorted(cols - set(df.columns))
    if missing:
        raise KeyError(f"{label} missing columns: {missing}")


def shell_order(steps: pd.DataFrame) -> List[int]:
    x = (
        steps[["shell_index", "shell_anchor", "shell_endpoint"]]
        .drop_duplicates()
        .sort_values(["shell_anchor", "shell_endpoint", "shell_index"])
    )
    return x["shell_index"].astype(int).tolist()


def relerr(a: np.ndarray, b: np.ndarray, floor: float = 1.0e-14) -> np.ndarray:
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    scale = np.maximum.reduce(
        [np.abs(a), np.abs(b), np.full_like(a, floor, dtype=float)]
    )
    return np.abs(a - b) / scale


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "ROT-RH v444 moving C0/L and renormalized-slope "
            "barrier cutoff-closure audit"
        ),
    )

    ap.add_argument(
        "--v442-nodes",
        default="rot_rh_logbeta_source_stiffness_damping_v442_NODES.csv",
    )
    ap.add_argument(
        "--v442-steps",
        default="rot_rh_logbeta_source_stiffness_damping_v442_STEPS.csv.gz",
    )
    ap.add_argument(
        "--v442-summary",
        default="rot_rh_logbeta_source_stiffness_damping_v442_SUMMARY.json",
    )
    ap.add_argument(
        "--v443-summary",
        default="rot_rh_renormalized_duhamel_prefix_bound_v443_SUMMARY.json",
    )

    ap.add_argument("--development-shells", type=int, default=1)

    # Prospective envelope for |C0|/L.
    ap.add_argument("--c0-cap-safety", type=float, default=2.25)
    ap.add_argument("--minimum-c0-cap", type=float, default=1.0e-12)

    # Prospective lower barrier for g=F'/L.
    # A value 0.98 freezes 98% of the development minimum as the future floor.
    ap.add_argument("--slope-floor-fraction", type=float, default=0.98)
    ap.add_argument("--absolute-slope-floor", type=float, default=1.0e-12)

    # Exact algebra gates.
    ap.add_argument("--maximum-q-slope-identity-relative", type=float, default=5.0e-10)
    ap.add_argument("--maximum-duhamel-collapse-relative", type=float, default=5.0e-10)
    ap.add_argument("--maximum-c0-two-route-relative", type=float, default=5.0e-10)

    ap.add_argument(
        "--prefix",
        default="rot_rh_moving_c0_slope_barrier_v444",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.development_shells < 1:
        raise ValueError("--development-shells must be >= 1")
    if args.c0_cap_safety <= 1.0:
        raise ValueError("--c0-cap-safety must exceed 1")
    if not (0.0 < args.slope_floor_fraction <= 1.0):
        raise ValueError("--slope-floor-fraction must lie in (0,1]")
    if args.absolute_slope_floor <= 0:
        raise ValueError("--absolute-slope-floor must be positive")

    started = time.perf_counter()

    s442 = load_json(args.v442_summary)
    v443_path = Path(args.v443_summary)
    s443 = load_json(v443_path) if v443_path.exists() else None

    upstream_v442 = bool(
        s442.get("verdict") == EXPECTED_V442
        or s442.get("exact_beta_split", {}).get("pass", False)
    )

    nodes = pd.read_csv(args.v442_nodes)
    steps = pd.read_csv(args.v442_steps)

    require_columns(
        nodes,
        {
            "cutoff", "L", "root_index", "E", "Fp", "beta",
            "Q", "Y", "slope_over_L",
        },
        "v442 nodes",
    )
    require_columns(
        steps,
        {
            "set", "shell_index", "shell_anchor", "shell_endpoint",
            "root_index", "cutoff_start", "cutoff_end",
            "L_start", "L_end", "E_start", "E_end",
            "B_start", "B_moving_end",
            "Q_start", "Q_end", "Y_start", "Y_end",
            "slope_over_L_start", "slope_over_L_end",
        },
        "v442 steps",
    )

    nodes["root_index"] = nodes["root_index"].astype(int)
    nodes["cutoff"] = nodes["cutoff"].astype(int)
    steps["root_index"] = steps["root_index"].astype(int)
    steps["shell_index"] = steps["shell_index"].astype(int)
    steps["cutoff_start"] = steps["cutoff_start"].astype(int)
    steps["cutoff_end"] = steps["cutoff_end"].astype(int)

    nodes = nodes.sort_values(["root_index", "L", "cutoff"]).reset_index(drop=True)
    steps = steps.sort_values(
        ["root_index", "L_start", "cutoff_start"]
    ).reset_index(drop=True)

    roots = sorted(nodes["root_index"].unique().tolist())
    shell_ids = shell_order(steps)
    if len(shell_ids) <= args.development_shells:
        raise RuntimeError(
            "Need at least one untouched holdout shell. "
            f"shells={shell_ids}, development={args.development_shells}"
        )

    dev_shells = set(shell_ids[: args.development_shells])
    hold_shells = set(shell_ids[args.development_shells :])

    print("=" * 238)
    print("ROT-RH v444 — MOVING C0/L + RENORMALIZED SLOPE BARRIER CLOSURE")
    print("=" * 238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff                             : NONE")
    print("finite holdout accepted as proof          : NO")
    print("v442 exact Duhamel reduction              :", upstream_v442, s442.get("verdict"))
    if s443 is not None:
        print("v443 diagnostic verdict                   :", s443.get("verdict"))
    print("modes                                     :", len(roots))
    print("development shells                        :", sorted(dev_shells))
    print("holdout shells                            :", sorted(hold_shells))
    print("=" * 238)

    # ------------------------------------------------------------------
    # Exact algebra on nodes.
    # ------------------------------------------------------------------
    exact_rows: List[Dict[str, Any]] = []

    for rk in tqdm(roots, desc="v444 exact collapse", unit="branch"):
        g = (
            nodes[nodes["root_index"] == rk]
            .sort_values(["L", "cutoff"])
            .reset_index(drop=True)
        )
        if len(g) < 2:
            continue

        L = g["L"].to_numpy(float)
        Fp = g["Fp"].to_numpy(float)
        beta = g["beta"].to_numpy(float)
        Q = g["Q"].to_numpy(float)
        Y = g["Y"].to_numpy(float)
        slope = g["slope_over_L"].to_numpy(float)

        g_from_Fp = Fp / L
        c0_from_Fp_beta = Fp * beta
        c0_from_Lg_beta = L * slope * beta

        # Exact v425 identity:
        # Q(L)-Q(L0) = -log(g(L)/g(L0)).
        slope0 = float(slope[0])
        Q0 = float(Q[0])

        q_pred = np.full_like(Q, np.nan)
        good = (slope > 0) & np.isfinite(slope)
        q_pred[good] = Q0 - np.log(slope[good] / slope0)

        # Avoid a relative-error pathology when both sides are ~0 by using
        # 1+|Q| in the scale.  This remains a stringent absolute/relative gate.
        q_resid = np.abs(Q - q_pred) / np.maximum(
            1.0, np.maximum(np.abs(Q), np.abs(q_pred))
        )

        # Exact collapse:
        # Y = C0/g0 when Q is anchored consistently.
        # If Q0 is not exactly zero, the generalized identity is
        # Y = exp(-Q0) * C0 / g0.
        Y_from_c0 = math.exp(-Q0) * c0_from_Fp_beta / slope0

        c0_route_rel = relerr(c0_from_Fp_beta, c0_from_Lg_beta)
        Y_rel = relerr(Y, Y_from_c0)

        for i in range(len(g)):
            exact_rows.append(
                {
                    "root_index": rk,
                    "cutoff": int(g.iloc[i]["cutoff"]),
                    "L": float(L[i]),
                    "E": float(g.iloc[i]["E"]),
                    "Q": float(Q[i]),
                    "Q_from_slope": float(q_pred[i]),
                    "Q_slope_identity_scaled_residual": float(q_resid[i]),
                    "slope_over_L": float(slope[i]),
                    "slope_from_Fp_over_L": float(g_from_Fp[i]),
                    "C0_from_Fp_beta": float(c0_from_Fp_beta[i]),
                    "C0_from_Lg_beta": float(c0_from_Lg_beta[i]),
                    "C0_two_route_relative_residual": float(c0_route_rel[i]),
                    "Y": float(Y[i]),
                    "Y_from_C0_over_g0": float(Y_from_c0[i]),
                    "duhamel_collapse_relative_residual": float(Y_rel[i]),
                }
            )

    exact = pd.DataFrame(exact_rows)
    if exact.empty:
        raise RuntimeError("No exact-collapse rows produced")

    max_q_identity = float(
        exact["Q_slope_identity_scaled_residual"].max()
    )
    max_c0_route = float(
        exact["C0_two_route_relative_residual"].max()
    )
    max_duhamel_collapse = float(
        exact["duhamel_collapse_relative_residual"].max()
    )

    q_identity_pass = bool(
        max_q_identity <= args.maximum_q_slope_identity_relative
    )
    c0_route_pass = bool(
        max_c0_route <= args.maximum_c0_two_route_relative
    )
    duhamel_collapse_pass = bool(
        max_duhamel_collapse <= args.maximum_duhamel_collapse_relative
    )

    # ------------------------------------------------------------------
    # Prospective endpoint diagnostic, using only already-generated moving
    # branch data.  At each step endpoint:
    #
    #   C0 = Fp beta = L g beta.
    #
    # The correct O(L) observable is |C0|/L = |g beta|.
    # Unlike v443's increment variable, this does not initialize at zero.
    # ------------------------------------------------------------------
    p_rows: List[Dict[str, Any]] = []
    b_rows: List[Dict[str, Any]] = []

    for rk in tqdm(roots, desc="v444 prospective branches", unit="branch"):
        gs = (
            steps[steps["root_index"] == rk]
            .sort_values(["L_end", "cutoff_end"])
            .reset_index(drop=True)
        )
        if gs.empty:
            continue

        # Initial node for a conditional tail constant.
        gn = (
            nodes[nodes["root_index"] == rk]
            .sort_values(["L", "cutoff"])
            .reset_index(drop=True)
        )
        if gn.empty:
            continue

        local_rows: List[Dict[str, Any]] = []
        for _, r in gs.iterrows():
            L = float(r["L_end"])
            slope = float(r["slope_over_L_end"])
            beta = float(r["B_moving_end"])
            Fp = L * slope
            C0 = Fp * beta
            c0_over_L = abs(C0) / max(L, EPS)

            local_rows.append(
                {
                    "set": str(r["set"]),
                    "shell_index": int(r["shell_index"]),
                    "root_index": rk,
                    "cutoff_end": int(r["cutoff_end"]),
                    "L_end": L,
                    "E_end": float(r["E_end"]),
                    "beta_end": beta,
                    "Fp_end": Fp,
                    "slope_over_L": slope,
                    "C0": C0,
                    "abs_C0_over_L": c0_over_L,
                    "Q_end": float(r["Q_end"]),
                }
            )

        gp = pd.DataFrame(local_rows)
        dev = gp[gp["shell_index"].isin(dev_shells)].copy()
        hold = gp[gp["shell_index"].isin(hold_shells)].copy()
        if dev.empty or hold.empty:
            continue

        dev_c0 = float(dev["abs_C0_over_L"].max())
        c0_cap = max(
            args.minimum_c0_cap,
            args.c0_cap_safety * dev_c0,
        )
        hold_c0 = float(hold["abs_C0_over_L"].max())
        hold_c0_ratio = hold_c0 / max(c0_cap, EPS)
        c0_hold_pass = bool(hold_c0 <= c0_cap)

        dev_slope_min = float(dev["slope_over_L"].min())
        slope_floor = max(
            args.absolute_slope_floor,
            args.slope_floor_fraction * dev_slope_min,
        )
        hold_slope_min = float(hold["slope_over_L"].min())
        slope_margin_ratio = hold_slope_min / max(slope_floor, EPS)
        slope_hold_pass = bool(hold_slope_min >= slope_floor)

        # Direct conditional beta/tail constant if the two frozen bounds
        # held for every later L:
        #
        # |C0|/L <= A, g >= c  =>  |beta| <= A/c.
        beta_star = c0_cap / max(slope_floor, EPS)

        Lmax = float(gp["L_end"].max())
        conditional_tail = beta_star / max(Lmax, EPS)

        # Finite observations, diagnostic only.
        actual_beta_max = float(np.max(np.abs(gp["beta_end"].to_numpy(float))))
        actual_c0_scaled_max = float(gp["abs_C0_over_L"].max())
        actual_slope_min = float(gp["slope_over_L"].min())

        branch_pass = bool(c0_hold_pass and slope_hold_pass)

        gp["frozen_C0_over_L_cap"] = c0_cap
        gp["C0_cap_ratio"] = gp["abs_C0_over_L"] / max(c0_cap, EPS)
        gp["frozen_slope_floor"] = slope_floor
        gp["slope_floor_ratio"] = gp["slope_over_L"] / max(slope_floor, EPS)
        gp["branch_holdout_pass"] = branch_pass
        p_rows.extend(gp.to_dict("records"))

        b_rows.append(
            {
                "root_index": rk,
                "development_max_abs_C0_over_L": dev_c0,
                "frozen_C0_over_L_cap": c0_cap,
                "holdout_max_abs_C0_over_L": hold_c0,
                "holdout_C0_cap_ratio": hold_c0_ratio,
                "C0_holdout_pass": c0_hold_pass,
                "development_min_slope_over_L": dev_slope_min,
                "frozen_slope_floor": slope_floor,
                "holdout_min_slope_over_L": hold_slope_min,
                "holdout_slope_floor_ratio": slope_margin_ratio,
                "slope_holdout_pass": slope_hold_pass,
                "actual_max_abs_beta": actual_beta_max,
                "actual_max_abs_C0_over_L": actual_c0_scaled_max,
                "actual_min_slope_over_L": actual_slope_min,
                "conditional_beta_star": beta_star,
                "current_Lmax": Lmax,
                "conditional_root_tail_at_Lmax": conditional_tail,
                "branch_holdout_pass": branch_pass,
            }
        )

    points = pd.DataFrame(p_rows)
    branches = pd.DataFrame(b_rows)
    if points.empty or branches.empty:
        raise RuntimeError("No prospective branch rows produced")

    shell_rows: List[Dict[str, Any]] = []
    for (setname, sh), g in points.groupby(["set", "shell_index"], sort=True):
        shell_rows.append(
            {
                "set": str(setname),
                "shell_index": int(sh),
                "roots": int(g["root_index"].nunique()),
                "max_abs_C0_over_L": float(g["abs_C0_over_L"].max()),
                "max_C0_cap_ratio": float(g["C0_cap_ratio"].max()),
                "min_slope_over_L": float(g["slope_over_L"].min()),
                "min_slope_floor_ratio": float(g["slope_floor_ratio"].min()),
                "max_abs_beta": float(
                    np.max(np.abs(g["beta_end"].to_numpy(float)))
                ),
                "max_abs_Q": float(
                    np.max(np.abs(g["Q_end"].to_numpy(float)))
                ),
            }
        )
    shells = pd.DataFrame(shell_rows).sort_values("shell_index")

    exact_pass = bool(
        upstream_v442
        and q_identity_pass
        and c0_route_pass
        and duhamel_collapse_pass
    )
    finite_holdout_pass = bool(
        exact_pass and branches["branch_holdout_pass"].all()
    )

    holdp = points[points["shell_index"].isin(hold_shells)]
    max_hold_c0_ratio = float(holdp["C0_cap_ratio"].max())
    min_hold_slope_ratio = float(holdp["slope_floor_ratio"].min())

    verdict = (
        "EXACT_DUHAMEL_C0_COLLAPSE_AND_FINITE_MOVING_C0_SLOPE_BARRIER_PASS_ALL_L_THEOREM_OPEN"
        if finite_holdout_pass
        else
        "DUHAMEL_C0_COLLAPSE_OR_MOVING_C0_SLOPE_BARRIER_INCOMPLETE"
    )

    print("\n[1] Exact algebraic collapse")
    print("max Q <-> slope scaled residual           :", f"{max_q_identity:.12e}")
    print("Q <-> slope identity pass                 :", q_identity_pass)
    print("max C0 two-route relative residual        :", f"{max_c0_route:.12e}")
    print("C0=Fp*beta=L*g*beta pass                  :", c0_route_pass)
    print("max Y=C0/g0 relative residual             :", f"{max_duhamel_collapse:.12e}")
    print("Duhamel -> C0 collapse pass               :", duhamel_collapse_pass)

    print("\n[2] Prospective moving C0/L + slope barrier")
    print("all branch holdouts pass                  :", bool(branches["branch_holdout_pass"].all()))
    print("maximum holdout C0-cap ratio              :", f"{max_hold_c0_ratio:.12e}")
    print("minimum holdout slope-floor ratio         :", f"{min_hold_slope_ratio:.12e}")
    print("global minimum observed F'/L              :", f"{points['slope_over_L'].min():.12e}")
    print("global maximum observed |Q|               :", f"{np.max(np.abs(points['Q_end'].to_numpy(float))):.12e}")

    cols = [
        "root_index",
        "development_max_abs_C0_over_L",
        "frozen_C0_over_L_cap",
        "holdout_max_abs_C0_over_L",
        "holdout_C0_cap_ratio",
        "development_min_slope_over_L",
        "frozen_slope_floor",
        "holdout_min_slope_over_L",
        "holdout_slope_floor_ratio",
        "conditional_beta_star",
        "conditional_root_tail_at_Lmax",
        "branch_holdout_pass",
    ]
    print("\nBranch summary:")
    print(
        branches[cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nShell summary:")
    print(
        shells.to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    next_theorem = (
        "PROVE_MOVING_BRANCH_C0_EQUALS_O_L_AND_UNIFORM_RENORMALIZED_SLOPE_FLOOR"
    )

    print("\n" + "=" * 238)
    print("VERDICT                                   :", verdict)
    print("EXACT Q ELIMINATION                       :", q_identity_pass)
    print("EXACT DUHAMEL -> C0 COLLAPSE              :", duhamel_collapse_pass)
    print("FINITE |C0|/L HOLDOUT                     :", bool(branches["C0_holdout_pass"].all()))
    print("FINITE F'/L LOWER BARRIER                 :", bool(branches["slope_holdout_pass"].all()))
    print("ALL-L |C0_k(L)| <= A_k L                 : NOT PROVED")
    print("ALL-L F'_L(E_k(L))/L >= c_k > 0          : NOT PROVED")
    print("FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED")
    print("JACOBI STRONG-RESOLVENT LIMIT             : NOT YET PROVED")
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 238)

    prefix = Path(args.prefix)
    exact_out = Path(str(prefix) + "_EXACT.csv.gz")
    points_out = Path(str(prefix) + "_POINTS.csv.gz")
    branches_out = Path(str(prefix) + "_BRANCH_SUMMARY.csv")
    shells_out = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix) + "_SUMMARY.json")
    theorem_out = Path(str(prefix) + "_THEOREM.md")
    cert_out = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    exact.to_csv(exact_out, index=False, compression="gzip")
    points.to_csv(points_out, index=False, compression="gzip")
    branches.to_csv(branches_out, index=False)
    shells.to_csv(shells_out, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_numeric_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff": False,
            "finite_holdout_accepted_as_proof": False,
        },
        "upstream": {
            "v442_verdict": s442.get("verdict"),
            "v442_exact_reduction": upstream_v442,
            "v443_verdict": None if s443 is None else s443.get("verdict"),
        },
        "exact_collapse": {
            "maximum_Q_slope_scaled_residual": max_q_identity,
            "Q_slope_identity_pass": q_identity_pass,
            "maximum_C0_two_route_relative_residual": max_c0_route,
            "C0_two_route_pass": c0_route_pass,
            "maximum_duhamel_C0_relative_residual": max_duhamel_collapse,
            "duhamel_C0_collapse_pass": duhamel_collapse_pass,
            "combined_pass": exact_pass,
        },
        "prospective_design": {
            "development_shells": sorted(dev_shells),
            "holdout_shells": sorted(hold_shells),
            "C0_cap_safety": args.c0_cap_safety,
            "slope_floor_fraction": args.slope_floor_fraction,
        },
        "finite_diagnostics": {
            "all_branch_holdout_pass": bool(
                branches["branch_holdout_pass"].all()
            ),
            "all_C0_holdout_pass": bool(
                branches["C0_holdout_pass"].all()
            ),
            "all_slope_holdout_pass": bool(
                branches["slope_holdout_pass"].all()
            ),
            "maximum_holdout_C0_cap_ratio": max_hold_c0_ratio,
            "minimum_holdout_slope_floor_ratio": min_hold_slope_ratio,
            "global_minimum_slope_over_L": float(
                points["slope_over_L"].min()
            ),
            "global_maximum_abs_Q": float(
                np.max(np.abs(points["Q_end"].to_numpy(float)))
            ),
            "maximum_conditional_beta_star": float(
                branches["conditional_beta_star"].max()
            ),
            "maximum_conditional_root_tail_at_current_Lmax": float(
                branches["conditional_root_tail_at_Lmax"].max()
            ),
            "proof_status": "FINITE_PROSPECTIVE_EVIDENCE_ONLY",
        },
        "verdict": verdict,
        "moving_C0_O_L_proved": False,
        "uniform_slope_floor_proved": False,
        "fixed_mode_cutoff_independence_proved": False,
        "jacobi_strong_resolvent_limit_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.perf_counter() - started,
    }
    summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    theorem_out.write_text(
        r"""# ROT-RH v444 — moving `C0/L` and renormalized slope barrier

The v424 characteristic generator satisfies

`beta_k(L)=C0_k(L)/F'_L(E_k(L))`.

Define

`g_k(L)=F'_L(E_k(L))/L`.

The exact v425 RG identity is

`Q_k(L)-Q_k(L0)=-log(g_k(L)/g_k(L0))`.

Hence, with the v442 Duhamel variable

`Y_k(L)=L exp(-Q_k(L)) beta_k(L)`,

we obtain identically

`Y_k(L)=exp(-Q_k(L0)) C0_k(L)/g_k(L0)`.

With the standard anchor `Q_k(L0)=0` this is simply

`Y_k(L)=C0_k(L)/g_k(L0)`.

Therefore the separate bounded-`Q` and weighted-source formulation can
be replaced by the direct sufficient conditions

`|C0_k(L)| <= A_k L`

and

`g_k(L) >= c_k > 0`

for all sufficiently large `L` on each eventual ordered branch.

Indeed,

`|beta_k(L)| <= A_k/c_k`.

Since

`E'_k(L)=beta_k(L)/L^2`,

we get

`|E_k(infinity)-E_k(L)| <= (A_k/c_k)/L`.

Thus the fixed spectral mode is cutoff-independent with an `O_k(1/L)`
tail.

For the arithmetic used in v424,

`C0(E,L) = sum_{p^m<exp(L)} Lambda(p^m)/sqrt(p^m) sin(E log p^m)
           - integral_2^{exp(L)} t^(-1/2) sin(E log t) dt`.

The remaining analytic problem is branch-specific:

1. prove the moving-characteristic bound `C0(E_k(L),L)=O_k(L)`;
2. prove the renormalized slope barrier
   `F'_L(E_k(L))/L >= c_k > 0`;
3. prove eventual ordered-branch persistence.

This does not use or require a uniform fixed-`E` bound.  A finite v444
pass is evidence for this route, not the all-`L` theorem.

Once these claims are proved, the next stage is operator-level:
construct cutoff-independent moments/Jacobi coefficients and establish
strong-resolvent convergence of the self-adjoint Jacobi operators.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_MOVING_C0_SLOPE_BARRIER_CERTIFICATE_V1",
        "exact_Q_elimination_proved": q_identity_pass,
        "exact_duhamel_C0_collapse_proved": duhamel_collapse_pass,
        "finite_prospective_holdout_pass": finite_holdout_pass,
        "required_all_L_claims": {
            "moving_C0_linear_bound": {
                "proved": False,
                "statement": (
                    "For every fixed eventual ordered branch k, "
                    "|C0(E_k(L),L)| <= A_k L for all sufficiently large L."
                ),
            },
            "renormalized_slope_barrier": {
                "proved": False,
                "statement": (
                    "For every fixed eventual ordered branch k, "
                    "F'_L(E_k(L))/L >= c_k > 0 for all sufficiently large L."
                ),
            },
            "branch_persistence": {
                "proved": False,
                "statement": (
                    "Each ordered branch persists eventually without switching."
                ),
            },
        },
        "consequence_if_proved": (
            "|beta_k|<=A_k/c_k => "
            "|E_k(infinity)-E_k(L)|<=(A_k/c_k)/L => "
            "fixed-mode cutoff independence"
        ),
        "operator_upgrade_after_fixed_modes": (
            "derive cutoff-independent moment/Jacobi coefficients, prove "
            "coefficient convergence on a common dense core, then prove "
            "strong-resolvent convergence"
        ),
        "forbidden_shortcuts": [
            "uniform fixed-E Gate A",
            "RH",
            "known zero ordinates",
            "Xi fitting",
            "square-root PNT error",
            "finite holdout as proof",
            "loosening a failed gate solely to obtain PASS",
        ],
    }
    cert_out.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("Files written:")
    for p in [
        exact_out,
        points_out,
        branches_out,
        shells_out,
        summary_out,
        theorem_out,
        cert_out,
    ]:
        print(" ", p)

    if args.strict and not finite_holdout_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
