#!/usr/bin/env python3
"""ROT-RH v447 — density-matrix / positive-tail completion audit.

Input:
  --roots-csv : v445 ROOTS.csv (columns mode,cutoff,k,root,crossings)
  --moments-csv : v446/v445 theta MOMENTS.csv (columns m,q_m or n,q_n)

For each mode/cutoff this checks whether the finite inverse-square spectrum can
be a literal prefix of a positive trace-class completion matching the theta
moments. No known zero ordinates are used.
"""
import argparse,csv,json,math
from collections import defaultdict
from pathlib import Path
import mpmath as mp
from tqdm import tqdm


def load_q(path):
    q=[]
    with open(path,newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            v=row.get('q_m',row.get('q_n'))
            q.append(mp.mpf(v))
    return q


def load_groups(path):
    g=defaultdict(list)
    with open(path,newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            key=(row.get('mode','unknown'),int(float(row.get('cutoff',0))))
            g[key].append(row)
    return g


def cholesky_tail(res,dim):
    if res[0] <= 0: return False, mp.nan, mp.nan
    mu=[x/res[0] for x in res]
    H0=mp.matrix(dim);H1=mp.matrix(dim)
    for i in range(dim):
        for j in range(dim):
            H0[i,j]=mu[i+j];H1[i,j]=mu[i+j+1]
    try:
        L0=mp.cholesky(H0);L1=mp.cholesky(H1)
        return True,min(L0[i,i]**2 for i in range(dim)),min(L1[i,i]**2 for i in range(dim))
    except Exception:
        e0=mp.eigsy(H0,eigvals_only=True);e1=mp.eigsy(H1,eigvals_only=True)
        return False,min(e0),min(e1)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--roots-csv',required=True)
    ap.add_argument('--moments-csv',required=True)
    ap.add_argument('--moment-count',type=int,default=12)
    ap.add_argument('--tail-hankel-dim',type=int,default=3)
    ap.add_argument('--mp-dps',type=int,default=100)
    ap.add_argument('--prefix',default='rot_rh_density_completion_v447')
    a=ap.parse_args();mp.mp.dps=a.mp_dps
    q=load_q(a.moments_csv)[:a.moment_count]
    groups=load_groups(a.roots_csv)
    rows=[]
    for (mode,X),rr in tqdm(sorted(groups.items()),desc='density completion',unit='operator'):
        rr=sorted(rr,key=lambda r:int(r.get('k',0)))
        unique=[r for r in rr if int(float(r.get('crossings',1)))==1]
        if len(unique)!=len(rr):
            structural=False
        else: structural=True
        lam=[mp.mpf(r['root'])**-2 for r in unique]
        partial=[];res=[]
        for m in range(1,len(q)+1):
            p=mp.fsum([x**m for x in lam])
            partial.append(p);res.append(q[m-1]-p)
        firstneg=next((i+1 for i,x in enumerate(res) if x<0),None)
        td=min(a.tail_hankel_dim,(len(res)-1)//2)
        tail_ok,p0,p1=cholesky_tail(res,td) if td>=1 and res[0]>0 else (False,mp.nan,mp.nan)
        q1=q[0]
        row={
            'mode':mode,'cutoff':X,'levels':len(rr),'unique_levels':len(unique),
            'structurally_unique':structural,
            'trace_capture_fraction':mp.nstr(partial[0]/q1,30),
            'trace_missing_fraction':mp.nstr(res[0]/q1,30),
            'first_negative_residual_moment':firstneg if firstneg else '',
            'positive_tail_Hankel_dim':td,
            'positive_tail_Hankel_pass':tail_ok,
            'tail_min_H0':mp.nstr(p0,30),'tail_min_H1':mp.nstr(p1,30),
        }
        for m in range(2,min(len(q),8)+1):
            row[f'q{m}_partial_relative_error']=mp.nstr((partial[m-1]-q[m-1])/q[m-1],25)
        rows.append(row)
    out=Path(a.prefix+'_SUMMARY.csv')
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    print('wrote',out)
    for r in rows:
        print(r)
if __name__=='__main__':main()
