#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v482 — ZERO-DENSITY SPARSITY / SUPERO-SCILLATION COMPLEXITY BRIDGE
=========================================================================

PURPOSE
-------
Combine v481 coefficient rigidity with a classical zeta zero-density theorem.

Classical Ingham zero density:
for every fixed sigma in (1/2,1),

    N(sigma,T)
      << T^theta(sigma) log^5 T,

where

    theta(sigma)
      = 3(1-sigma)/(2-sigma)
      < 1.

Here N(sigma,T) counts zeros WITH MULTIPLICITY satisfying
    beta>=sigma, 0<gamma<=T.

Suppose
    beta_* = sup beta > 1/2
is not attained.

Choose once and for all
    sigma_0 in (1/2,beta_*).

Every sufficiently right-edge active zero has beta>=sigma_0.

Therefore the total number of available near-edge modes up to height T is

    n_edge(T)
      = O(T^theta0 log^5 T)
      = o(T).

v475 additionally places every instantaneous bump winner below

    T_active(L)=O(sqrt L).

Thus the total near-edge arithmetic degrees of freedom available in the entire
active parabolic strip satisfy

    n_active(L)
      = O(
          L^(theta0/2)
          log^5 L
        )
      = o(sqrt L).

Because v481 shows that the raw zero coefficients are only integer
multiplicities, this is a genuine mode-count restriction; there is no hidden
independent residue parameter for each mode.

WHAT THIS DOES NOT YET PROVE
----------------------------
v477 shows that a sufficiently high-dimensional arbitrary exponential family
can superoscillate.  Zero density says the actual near-edge zeta family is
sublinear in carrier height.

To turn this into exclusion one needs the following purely harmonic theorem:

HIGH-PASS SECTOR-LOCK COMPLEXITY (OPEN)
---------------------------------------
For each fixed physical window length h>0 and bounded carrier |nu|<=Nu, prove
that an n-term exponential polynomial whose relevant frequencies escape to
height M, and which stays in a shrinking half-plane/phase sector throughout
the window after the carrier removal, must satisfy

    n >= c_h M

(or any lower bound M^alpha with alpha strictly larger than the available
zero-density exponent in the relevant edge range),

unless its contribution is negligible in the v419 secular characteristic.

If a linear lower bound holds, Ingham immediately contradicts it because

    n_edge(M)=o(M).

Thus the final nonattained problem has now been reduced to:
  * an arithmetic sparse high-pass exponential family,
  * common-sign multiplicity residues,
  * parabolic active height,
  * isolated one/two-mode transfers,
  * and one precise superoscillation-complexity lemma.

This file proves only the ZERO-DENSITY SPARSITY reduction, not the open harmonic
complexity lemma.

No numerical zeros or RH assumption are used.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v482-zero-density-sparsity-bridge"


def theta(sigma: float) -> float:
    return 3.0*(1.0-sigma)/(2.0-sigma)


def symbolic_check() -> Dict[str, Any]:
    import sympy as sp
    s = sp.symbols("s", real=True)
    th = 3*(1-s)/(2-s)
    diff = sp.simplify(1-th)
    # 1-theta=(2s-1)/(2-s)>0 for 1/2<s<1.
    expected = (2*s-1)/(2-s)
    return {
        "theta": str(th),
        "one_minus_theta": str(diff),
        "expected": str(expected),
        "residual": str(sp.simplify(diff-expected)),
        "pass": bool(sp.simplify(diff-expected) == 0),
    }


def panel():
    rows = []
    for sigma in (0.51, 0.55, 0.60, 0.70, 0.80, 0.90):
        th = theta(sigma)
        rows.append({
            "sigma": sigma,
            "theta": th,
            "sublinear_margin": 1.0-th,
            "active_L_exponent": th/2.0,
            "sqrtL_margin": 0.5-th/2.0,
        })
    return rows


def edge_choice(beta_star: float):
    if not (0.5 < beta_star <= 1.0):
        raise ValueError("beta_star must be in (1/2,1]")
    sigma0 = 0.5*(beta_star+0.5)
    th = theta(sigma0)
    return {
        "beta_star": beta_star,
        "sigma0": sigma0,
        "theta0": th,
        "n_edge_T": "O(T^theta0 log^5 T)=o(T)",
        "n_active_L":
            "O(L^(theta0/2) log^5 L)=o(sqrt L)",
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v482 — zero-density sparsity / superoscillation complexity bridge

Ingham's classical estimate is

`N(sigma,T)
 << T^[3(1-sigma)/(2-sigma)] log^5 T`.

For every fixed `sigma>1/2`,

`theta(sigma)=3(1-sigma)/(2-sigma)<1`

because

`1-theta=(2sigma-1)/(2-sigma)>0`.

If `beta_*>1/2` is a nonattained supremum, choose fixed

`sigma_0 in (1/2,beta_*)`.

All sufficiently right-edge modes satisfy `beta>=sigma_0`, so

`n_edge(T)=O(T^theta0 log^5T)=o(T)`.

Using v475's `T_active=O(sqrt L)`,

`n_active(L)
 =O(L^(theta0/2)log^5L)
 =o(sqrt L)`.

Together with v481, these are genuinely the available arithmetic mode degrees
of freedom because raw zero coefficients are only multiplicities.

**Verdict:** {payload['verdict']}

The remaining bridge is a harmonic complexity theorem showing that persistent
high-pass fixed-window phase locking requires at least linear-in-carrier mode
complexity (or another exponent beating `theta0`).  v482 does not prove that
harmonic lemma.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_ZERO_DENSITY_SUPEROSCILLATION_BRIDGE_V1",
        "closed": {
            "Ingham_exponent":
                "theta(sigma)=3(1-sigma)/(2-sigma)<1 for sigma>1/2",
            "near_edge_count":
                "N(sigma0,T)=o(T)",
            "active_parabolic_count":
                "using v475, n_active(L)=o(sqrt L)",
            "coefficient_freedom":
                "removed by v481; multiplicities are counted in N(sigma,T)",
        },
        "open_harmonic_lemma": {
            "name": "HIGH_PASS_SECTOR_LOCK_COMPLEXITY",
            "target":
                "persistent shrinking-sector lock at carrier M requires n>=c M, or another lower exponent exceeding theta(sigma0)",
            "consequence":
                "combined with Ingham would exclude genuinely nonattained off-critical lock",
        },
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta-star", type=float, default=0.75)
    ap.add_argument("--prefix", default="rot_rh_zero_density_sparsity_v482")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*194)
    print("ROT-RH v482 — ZERO-DENSITY SPARSITY / SUPERO-SCILLATION COMPLEXITY BRIDGE")
    print("="*194)

    with tqdm(total=3, desc="v482 reduction", unit="step") as bar:
        sym = symbolic_check()
        bar.update(1)
        rows = panel()
        bar.update(1)
        edge = edge_choice(args.beta_star)
        bar.update(1)

    passed = bool(sym["pass"] and edge["theta0"] < 1.0)
    verdict = (
        "ZERO_DENSITY_SPARSE_NONATTAINED_MODE_REDUCTION_PASS"
        if passed else
        "ZERO_DENSITY_SPARSITY_REDUCTION_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "panel": rows,
        "example_edge_choice": edge,
        "external_theorem":
            "Ingham: N(sigma,T)<<T^[3(1-sigma)/(2-sigma)] log^5T",
        "firewall": {
            "numerical_zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
        },
        "proof_status":
            "Classical zero-density sparsity reduction only. The high-pass superoscillation complexity lemma remains open.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("symbolic exponent algebra       :", sym["pass"])
    print("example sigma0                  :", f"{edge['sigma0']:.6f}")
    print("example theta0                  :", f"{edge['theta0']:.6f}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
