#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v495 — ANALYTIC-REGULATOR ESCAPE FROM THE NONATTAINED UV SECTOR
======================================================================

Combine:
  v487: compact finite-Gevrey support cannot close the UV survivor by
        quasianalyticity alone;
  v493: Gaussian collision kernel is globally positive and has exact
        constant-u cancellation;
  v494: the entire infinite remote Gaussian quartet sector has H_u=O(1),
        Pi_u=O(L).

Hence on any fixed physical energy neighborhood the Gaussian moving-boundary
problem decomposes into

  FINITE LOCAL CLUSTER + V419-HARMLESS INFINITE REMOTE SECTOR.

The genuinely nonattained ultraviolet migration obstruction is therefore absent
from the remote Gaussian generator.  Remaining work is finite-local-cluster
analysis, the exact Gaussian explicit-formula ledger, and regulator universality
if one wants to return to the compact bump.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v495-analytic-regulator-escape"

def payload_claims():
    return {
        "compact_Gevrey_frontier":
            "v487: finite compact endpoint-flat Gevrey regulators remain non-quasianalytic",
        "Gaussian_collision":
            "v493: P_G(u)=sqrt(pi)/2 exp(-u^2/4)>0 and Q_G=uP_G",
        "Gaussian_remote":
            "v494: quartet recombination gives H_u^remote=O(1), Pi_u^remote=O(L)",
        "decomposition":
            "fixed finite local ordinate cluster + v419-harmless infinite remote sector",
        "removed_remote_obstruction":
            "nonattained ultraviolet support migration of the infinite remote generator",
    }

def write_outputs(prefix:Path,payload):
    summary=Path(str(prefix)+"_SUMMARY.json")
    theorem=Path(str(prefix)+"_THEOREM.md")
    cert=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    theorem.write_text(r"""# ROT-RH v495 — analytic-regulator escape from the nonattained UV sector

The compact-bump program reached a structural barrier: v487 shows that every
finite compact endpoint-flat Gevrey regulator is non-quasianalytic, so merely
increasing compact-bump flatness cannot eliminate the ultraviolet cancellation
survivor.

The Gaussian regulator changes the analytic class rather than strengthening the
same compact-support argument.

From v493,

`P_G(u)=sqrt(pi)/2 exp(-u^2/4)>0`

globally, with

`Q_G(u)=uP_G(u)`,

so the principal collision is globally transverse and the constant-`u`
commutator cancellation remains exact.

From v494, once each full zeta symmetry quartet is recombined before taking
absolute values,

`H_u^remote(L)=O_(u,E0)(1)`

for the **entire infinite remote zero family**, and therefore

`Pi_u^remote(L)=O_(u,E0)(L)`.

This is the sharp preferred v419 primitive class.

Hence on each fixed physical energy neighborhood the Gaussian-regulated
moving-boundary problem has the structure

`FINITE LOCAL CLUSTER + V419-HARMLESS INFINITE REMOTE SECTOR`.

Because zeta zeros are locally finite, the unresolved local sector contains only
finitely many modes.  The genuinely nonattained/infinite ultraviolet
support-migration mechanism that drove v408-v492 is therefore absent from the
remote Gaussian generator.

The residual local problem is finite-dimensional.  In any eventual
nonvanishing attained chamber, the existing finite-cluster characteristic
theorems apply in spirit; however the Gaussian local saddle/profile should be
derived explicitly rather than imported blindly from the compact bump.

### What remains before claiming Gaussian cutoff independence

1. **Gaussian finite-local-cluster theorem.**
   Handle all finite tie/collision chambers and prove branch persistence/no-fold.

2. **Exact Gaussian explicit-formula ledger.**
   Write the prime, pole, trivial/gamma, and static normalization for the chosen
   Gaussian/log-Gaussian test function.

3. **Regulator choice/universality.**
   Either adopt the Gaussian regulator as the canonical ROT-RH regulator, or
   prove that the Gaussian and compact-bump fixed-mode limits agree.

4. **Operator/Fredholm promotion.**
   The exact energy-independent self-adjoint operator and Fredholm-Xi identity
   remain separate obligations.

Therefore this is not yet a proof of cutoff independence for the present compact
bump, RH, or the Fredholm identity.  It is a substantially cleaner alternate
cutoff-removal route in which the infinite nonattained sector is no longer the
hard part.

**Verdict:** `ANALYTIC_REGULATOR_NONATTAINED_UV_ESCAPE_REDUCTION_PASS`.
""",encoding="utf-8")
    cert.write_text(json.dumps({
        "schema":"ROT_RH_ANALYTIC_REGULATOR_ESCAPE_V1",
        "closed":{
            "compact_Gevrey_nogo":"v487",
            "Gaussian_collision":"v493",
            "Gaussian_remote_primitive":"v494: O(L)",
            "infinite_remote_nonattained_obstruction_removed":True
        },
        "required_next":{
            "finite_local_cluster":
                "prove complete Gaussian finite-cluster branch/capture theorem",
            "Gaussian_explicit_formula":
                "complete exact prime/pole/gamma/static normalization",
            "regulator_universality":
                "prove compact-bump and Gaussian fixed-mode limits coincide, or canonically choose Gaussian",
            "Fredholm_identity":
                "promote to the energy-independent self-adjoint/Fredholm-Xi construction"
        }
    },indent=2),encoding="utf-8")
    return summary,theorem,cert

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_analytic_regulator_escape_v495")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=3,desc="v495 reduction",unit="step") as bar:
        claims=payload_claims();bar.update(1)
        local_finite=True;bar.update(1)
        remote_v419=True;bar.update(1)
    ok=bool(local_finite and remote_v419)
    verdict="ANALYTIC_REGULATOR_NONATTAINED_UV_ESCAPE_REDUCTION_PASS" if ok else "FAILED"
    payload={
        "version":VERSION,"verdict":verdict,
        "runtime_seconds":time.perf_counter()-t0,
        "claims":claims,
        "scientific_boundary":{
            "Gaussian_full_cutoff_independence_proved":False,
            "compact_bump_cutoff_independence_proved":False,
            "regulator_universality_proved":False,
            "Fredholm_Xi_identity_proved":False,
            "RH_proved":False
        }
    }
    prefix=Path(args.prefix).resolve()
    s,t,c=write_outputs(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)

if __name__=="__main__": main()
