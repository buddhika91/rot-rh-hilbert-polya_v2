#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v415 — MULTIPLICITY-ROBUST RIESZ GENERATOR / DIRECT ROOT-FLOW CLOSURE
============================================================================

Purpose
-------
Correct and sharpen v414.

v414 proved the exact cutoff-generator identities

    d_L F_L(E) = -C0(L,E)/L^2,

    d_L(F'_L(E)-L/2) = -D1(L,E)/L^2,

where L=log X and D1=C1+L^2/2.

Two improvements are essential.

1. MULTIPLICITY-ROBUST TRANSVERSALITY

The two-sided condition

    |D1| <= K1 L

is stronger than needed and is simple-zero flavored.

If a limiting collision has multiplicity m>1, the leading slope is mL/2,
so D1 may be NEGATIVE of order L^2.  That strengthens transversality and must
not be treated as a failure.

The correct sufficient theorem is ONE-SIDED:

    D1(L,E) <= K1 L

uniformly on the eventual fixed-k tube.

Then, for A(L,E)=F'_L(E)-L/2,

    d_L A >= -K1/L,

so

    A(L,E) >= A(L0,E) - K1 log(L/L0),

and therefore

    F'_L(E) >= L/2 - O_k(log L).

Hence for every c_k<1/2,

    F'_L(E) >= c_k L

eventually.

This is valid whether the eventual collision multiplicity is 1 or larger.

2. DIRECT ROOT-FLOW CLOSURE

Along a continuous fixed quantized branch

    F_L(E_k(L)) = C_k,

differentiate:

    0 = d_L F_L + F'_L E_k'
      = -C0/L^2 + F'_L E_k'.

Therefore exactly

    E_k'(L)
      = C0(L,E_k(L)) / [L^2 F'_L(E_k(L))].

If

    |C0(L,E)| <= K0_k L

and

    F'_L(E) >= c_k L

on the branch tube, then

    |E_k'(L)| <= K0_k/(c_k L^2).

This is integrable:

    |E_k(infinity)-E_k(L)|
      <= K0_k/(c_k L).

Thus fixed-mode cutoff independence follows DIRECTLY from the two generator
bounds, without needing a separate dyadic summation step.

v415 also prospectively tests the corrected one-sided D1 positive-part scale
on the same 8M development / 16M holdout arithmetic panel used by v414.

Scientific firewall
-------------------
NO Xi.
NO zeta evaluations.
NO known zero ordinates.
NO simple-zero assumption.
NO root solves at transfer Y.
NO finite scan accepted as proof.

Version: 415
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 415


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def energy_col(df):
    for c in ("energy", "E", "root", "root_energy"):
        if c in df.columns:
            return c
    raise KeyError("No energy column found.")


def index_col(df):
    for c in ("root_index", "mode_index", "k", "index"):
        if c in df.columns:
            return c
    raise KeyError("No root-index column found.")


def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    lo = math.log(2.0)
    return np.imag(
        (np.exp(a*L)-np.exp(a*lo))/a
    )


def smooth1(E: np.ndarray, L: float) -> np.ndarray:
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    lo = math.log(2.0)

    def primitive(u):
        return np.exp(a*u)*(u/a - 1.0/(a*a))

    return np.real(
        primitive(L)-primitive(lo)
    )


def generator_arrays(base, primes, Y: int, energies: np.ndarray):
    logs, _, exponents = base.prime_power_riesz_terms(
        primes, int(Y)
    )
    m = exponents.astype(float)
    lam = logs/m
    decay = np.exp(-0.5*logs)

    w0 = lam*decay
    w1 = lam*logs*decay

    prime0 = base.trig_sum(
        energies, logs, w0, "sin"
    )
    prime1 = base.trig_sum(
        energies, logs, w1, "cos"
    )

    L = math.log(float(Y))
    C0 = (
        np.asarray(prime0, float)
        - smooth0(energies, L)
    )
    C1 = (
        np.asarray(prime1, float)
        - smooth1(energies, L)
    )
    D1 = C1 + 0.5*L*L
    return C0, C1, D1, logs, len(logs)


def symbolic_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, K0, K1, c = sp.symbols(
        "L K0 K1 c",
        positive=True,
        real=True,
    )
    C0, D1, Fp = sp.symbols(
        "C0 D1 Fp",
        real=True,
    )

    # Root flow.
    Eprime = C0/(L**2*Fp)
    root_identity = sp.simplify(
        -C0/L**2 + Fp*Eprime
    )

    # Collision defect generator.
    Ader = -D1/L**2
    danger = K1*L
    lower_Ader = sp.simplify(
        -danger/L**2
    )

    # Integrable velocity upper envelope.
    vel = K0/(c*L**2)
    tail = sp.integrate(
        vel,
        (L, L, sp.oo),
    )
    expected_tail = K0/(c*L)
    tail_resid = sp.simplify(
        tail-expected_tail
    )

    # C1 = partial_E C0 is exact from definitions; record symbolically.
    return {
        "root_flow_residual": str(root_identity),
        "one_sided_A_derivative_floor": str(lower_Ader),
        "integrated_root_tail": str(tail),
        "root_tail_residual": str(tail_resid),
        "C1_is_E_derivative_of_C0": True,
        "pass": bool(
            root_identity == 0
            and tail_resid == 0
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--roots-csv",
        default="rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv",
    )
    ap.add_argument(
        "--v414-summary",
        default="rot_rh_riesz_cutoff_generator_v414_SUMMARY.json",
    )
    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--anchors", default="8000000,16000000")
    ap.add_argument(
        "--y-fractions",
        default="1.125,1.25,1.5,1.75,2.0",
    )
    ap.add_argument("--max-modes", type=int, default=32)
    ap.add_argument("--tube-samples", type=int, default=7)
    ap.add_argument("--eta", type=float, default=0.10)
    ap.add_argument("--c-coordinate", type=float, default=1.0)
    ap.add_argument("--sep-fraction", type=float, default=0.60)
    ap.add_argument(
        "--generator-safety",
        type=float,
        default=1.50,
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_multiplicity_robust_generator_v415",
    )

    args = ap.parse_args()
    started = time.time()

    if args.generator_safety <= 1:
        raise ValueError("--generator-safety must be >1")
    if args.tube_samples < 3:
        raise ValueError("--tube-samples must be >=3")

    anchors = sorted(set(parse_ints(args.anchors)))
    qvals = sorted(set(parse_floats(args.y_fractions)))
    if len(anchors) < 2:
        raise ValueError("Need at least two anchors.")
    if any(q <= 1 or q > 2 for q in qvals):
        raise ValueError("Y/X fractions must lie in (1,2].")

    roots_path = Path(args.roots_csv)
    if not roots_path.exists():
        raise FileNotFoundError(roots_path)

    rdf = pd.read_csv(roots_path)
    if "cutoff" not in rdf.columns:
        raise KeyError("roots CSV needs cutoff.")

    ec = energy_col(rdf)
    kc = index_col(rdf)

    roots: Dict[int, np.ndarray] = {}
    for X in anchors:
        g = rdf[
            rdf["cutoff"].astype(int) == X
        ].sort_values(kc)
        if g.empty:
            raise ValueError(f"Anchor {X} not found.")
        e = g[ec].to_numpy(float)
        if args.max_modes > 0:
            e = e[:args.max_modes]
        roots[X] = e

    common = min(len(v) for v in roots.values())
    roots = {
        X: v[:common]
        for X, v in roots.items()
    }

    dev_anchors = anchors[:-1]
    hold_anchor = anchors[-1]
    maxY = int(
        math.ceil(max(anchors)*max(qvals))
    )

    v414 = None
    p414 = Path(args.v414_summary)
    if p414.exists():
        v414 = json.loads(
            p414.read_text(encoding="utf-8")
        )

    v405 = None
    p405 = Path(args.v405_summary)
    if p405.exists():
        v405 = json.loads(
            p405.read_text(encoding="utf-8")
        )

    v414_ok = bool(
        v414 is not None
        and v414.get("verdict")
        == "PROSPECTIVE_POINTWISE_RIESZ_GENERATOR_HOLDOUT_PASS"
    )
    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )

    base = importlib.import_module(
        args.v71_module
    )

    print("="*238)
    print("ROT-RH v415 — MULTIPLICITY-ROBUST RIESZ GENERATOR / DIRECT ROOT-FLOW CLOSURE")
    print("="*238)
    print("Xi / zeta / known-zero data             : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("root solves at transfer Y                : NONE")
    print("v414 pointwise-generator holdout         :", v414_ok)
    print("v405 multiplicity architecture           :", v405_ok)
    print("anchors                                  :", anchors)
    print("development anchors                      :", dev_anchors)
    print("holdout anchor                           :", hold_anchor)
    print("maximum arithmetic Y                     :", f"{maxY:,}")
    print("="*238)

    print("[1] Exact closure algebra")
    sym = symbolic_checks()
    print("symbolic closure pass                    :", sym.get("pass"))
    print(
        "root flow                               :",
        "E_k'(L)=C0/[L^2 F'_L]",
    )
    print(
        "multiplicity-robust slope target        :",
        "D1<=K1*L (ONE-SIDED)",
    )
    print(
        "root tail if generator bounds hold      :",
        "|E_k(inf)-E_k(L)|<=K0/(c_k L)",
    )

    if args.strict and not sym.get("pass"):
        raise RuntimeError(
            f"Symbolic closure failure: {sym}"
        )

    print("\n[2] Prime table")
    t0 = time.time()
    primes = base.sieve_primes(maxY)
    print(
        "primes <= maxY                           :",
        f"{len(primes):,}",
    )
    print(
        "sieve seconds                            :",
        f"{time.time()-t0:.3f}",
    )

    rows = []
    total = len(anchors)*len(qvals)
    bar = tqdm(
        total=total,
        desc="multiplicity-robust generators",
        unit="X,Y",
    )

    for X in anchors:
        E0 = roots[X]
        LX = math.log(float(X))
        radius = (
            (1.0-args.sep_fraction)
            * args.c_coordinate
            / ((0.5+args.eta)*LX)
        )
        offsets = np.linspace(
            -radius,
            radius,
            args.tube_samples,
        )

        for q in qvals:
            Y = int(round(q*X))
            LY = math.log(float(Y))

            C0root, _, D1root, logsY, terms = generator_arrays(
                base, primes, Y, E0
            )

            Etube = (
                E0[:, None]
                + offsets[None, :]
            ).reshape(-1)

            _, _, D1flat, _, _ = generator_arrays(
                base, primes, Y, Etube
            )
            D1tube = D1flat.reshape(
                len(E0),
                len(offsets),
            )

            # Actual phase slope for diagnostic and direct root-flow denominator.
            _, weightsY, _ = base.prime_power_riesz_terms(
                primes, Y
            )
            slopeflat = base.phase_prime_grid(
                Etube,
                Y,
                logsY,
                weightsY,
            )
            slopes = np.asarray(
                slopeflat,
                float,
            ).reshape(
                len(E0),
                len(offsets),
            )

            for j, E in enumerate(E0, start=1):
                drow = D1tube[j-1]
                srow = slopes[j-1]

                max_D1 = float(np.max(drow))
                min_D1 = float(np.min(drow))
                max_positive_D1 = max(
                    max_D1,
                    0.0,
                )
                min_slope = float(np.min(srow))

                rows.append({
                    "set": (
                        "holdout"
                        if X == hold_anchor
                        else "development"
                    ),
                    "X": int(X),
                    "Y": int(Y),
                    "Y_over_X": float(q),
                    "root_index": int(j),
                    "E_k_X": float(E),
                    "logX": LX,
                    "logY": LY,
                    "C0_root": float(C0root[j-1]),
                    "abs_C0_root_over_logY": (
                        abs(float(C0root[j-1]))/LY
                    ),
                    "D1_root": float(D1root[j-1]),
                    "max_D1_tube": max_D1,
                    "min_D1_tube": min_D1,
                    "positive_D1_tube_over_logY": (
                        max_positive_D1/LY
                    ),
                    "negative_D1_magnitude_over_logY": (
                        max(-min_D1, 0.0)/LY
                    ),
                    "tube_min_slope": min_slope,
                    "tube_min_slope_over_logX": (
                        min_slope/LX
                    ),
                    "term_count_Y": int(terms),
                })

            bar.update(1)

    bar.close()
    df = pd.DataFrame(rows)

    dev = df[
        df["set"] == "development"
    ].copy()
    hold = df[
        df["set"] == "holdout"
    ].copy()

    c0col = "abs_C0_root_over_logY"
    dposcol = "positive_D1_tube_over_logY"

    dev_c0 = float(dev[c0col].max())
    hold_c0 = float(hold[c0col].max())
    cap_c0 = args.generator_safety*dev_c0

    dev_dpos = float(dev[dposcol].max())
    hold_dpos = float(hold[dposcol].max())

    # If dev_dpos is exactly zero, don't create a zero cap; the theorem target
    # is already satisfied on development and we use a tiny numerical cushion.
    cap_dpos = (
        args.generator_safety*dev_dpos
        if dev_dpos > 1e-15
        else 1e-12
    )

    c0_pass = bool(
        hold_c0 <= cap_c0
    )
    dpos_pass = bool(
        hold_dpos <= cap_dpos
    )

    min_hold_slope = float(
        hold["tube_min_slope_over_logX"].min()
    )

    print("\n[3] Corrected prospective generator holdout")
    print(
        "development max |C0|/logY               :",
        f"{dev_c0:.12e}",
    )
    print(
        "frozen C0 cap                            :",
        f"{cap_c0:.12e}",
    )
    print(
        "holdout max |C0|/logY                   :",
        f"{hold_c0:.12e}",
    )
    print(
        "C0 holdout pass                          :",
        c0_pass,
    )
    print()
    print(
        "development max positive(D1)_tube/logY  :",
        f"{dev_dpos:.12e}",
    )
    print(
        "frozen one-sided D1 danger cap           :",
        f"{cap_dpos:.12e}",
    )
    print(
        "holdout max positive(D1)_tube/logY      :",
        f"{hold_dpos:.12e}",
    )
    print(
        "one-sided D1 holdout pass                :",
        dpos_pass,
    )
    print(
        "holdout min slope/logX                   :",
        f"{min_hold_slope:.12e}",
    )

    print("\nWorst one-sided D1 danger rows:")
    print(
        hold.nlargest(
            12,
            dposcol,
        )[
            [
                "X","Y","Y_over_X",
                "root_index","E_k_X",
                c0col,
                dposcol,
                "negative_D1_magnitude_over_logY",
                "tube_min_slope_over_logX",
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nMost negative D1 rows (beneficial for slope):")
    print(
        hold.nlargest(
            12,
            "negative_D1_magnitude_over_logY",
        )[
            [
                "X","Y","Y_over_X",
                "root_index","E_k_X",
                dposcol,
                "negative_D1_magnitude_over_logY",
                "tube_min_slope_over_logX",
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    theorem = [
        (
            "GENERATOR",
            "d_L F_L=-C0/L^2.",
        ),
        (
            "ROOT_FLOW",
            "E_k'=C0/[L^2 F'_L] on a continuous quantized branch.",
        ),
        (
            "TRANSFER_BOUND",
            "|C0|<=K0 L and F'>=cL imply |E_k'|<=K0/(cL^2).",
        ),
        (
            "TAIL_BOUND",
            "|E_k(infinity)-E_k(L)|<=K0/(cL).",
        ),
        (
            "MULTIPLICITY_ROBUST_STIFFNESS",
            "D1<=K1 L implies F'_L>=L/2-O(log L), with no simple-zero assumption.",
        ),
        (
            "NEGATIVE_D1",
            "D1<0 only increases the collision-normalized slope and is not a theorem failure.",
        ),
    ]

    print("\n[4] Direct fixed-mode closure theorem")
    for key, txt in theorem:
        print(f"{key:46s}: {txt}")

    upstream_ok = bool(
        sym.get("pass")
        and v414_ok
        and v405_ok
    )

    gates = {
        "upstream_exact_architecture": upstream_ok,
        "C0_prospective_holdout": c0_pass,
        "one_sided_D1_prospective_holdout": dpos_pass,
        "holdout_slope_positive": bool(
            min_hold_slope > 0
        ),
    }
    failed = [
        k for k,v in gates.items()
        if not v
    ]

    if not failed:
        verdict = (
            "PROSPECTIVE_MULTIPLICITY_ROBUST_GENERATOR_CLOSURE_HOLDOUT_PASS"
        )
        next_theorem = (
            "PROVE_ALL_X_FIXED_TUBE_ABS_C0_O_L_AND_POSITIVE_PART_D1_O_L"
        )
    else:
        verdict = (
            "MULTIPLICITY_ROBUST_GENERATOR_HOLDOUT_INCOMPLETE"
        )
        next_theorem = (
            "LOCALIZE_C0_OR_ONE_SIDED_D1_FAILURE_WITHOUT_REINTRODUCING_SIMPLE_ZERO_NORMALIZATION"
        )

    print("\n" + "="*238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print("FAILED GATES                             :", failed if failed else "NONE")
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           :",
        "FOLLOWS DIRECTLY IF THE TWO ALL-X GENERATOR BOUNDS ARE PROVED",
    )
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT YET PROVED",
    )
    print("="*238)

    prefix = Path(args.prefix)
    detail_path = Path(
        str(prefix) + "_DETAIL.csv"
    )
    summary_path = Path(
        str(prefix) + "_SUMMARY.json"
    )
    theorem_path = Path(
        str(prefix) + "_THEOREM.md"
    )

    df.to_csv(
        detail_path,
        index=False,
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "roots_solved_at_transfer_Y": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v414_ok": v414_ok,
            "v405_ok": v405_ok,
        },
        "exact_closure": sym,
        "development": {
            "max_abs_C0_over_logY": dev_c0,
            "max_positive_D1_tube_over_logY": dev_dpos,
        },
        "freeze": {
            "generator_safety": args.generator_safety,
            "C0_cap": cap_c0,
            "one_sided_D1_danger_cap": cap_dpos,
        },
        "holdout": {
            "max_abs_C0_over_logY": hold_c0,
            "max_positive_D1_tube_over_logY": hold_dpos,
            "minimum_slope_over_logX": min_hold_slope,
            "C0_pass": c0_pass,
            "one_sided_D1_pass": dpos_pass,
        },
        "theorem": {
            key: txt
            for key, txt in theorem
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact multiplicity-robust generator/root-flow implication plus "
            "finite prospective arithmetic holdout. The remaining proof is the "
            "all-X fixed-tube bound |C0|=O_k(L) and positive-part(D1)=O_k(L)."
        ),
        "runtime_seconds": time.time()-started,
    }

    summary_path.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v415 — multiplicity-robust direct cutoff closure

Let `L=log X`.

The exact generator is

`partial_L F_L(E)=-C0(L,E)/L^2`.

Along a continuous fixed quantized branch

`F_L(E_k(L))=C_k`,

the exact root velocity is

`E_k'(L)=C0(L,E_k(L))/[L^2 F'_L(E_k(L))]`.

Thus

`|C0|<=K0_k L`

and

`F'_L>=c_k L`

give

`|E_k'|<=K0_k/(c_k L^2)`

and therefore

`|E_k(infinity)-E_k(L)|<=K0_k/(c_k L)`.

For transversality define

`D1=C1+L^2/2`

with

`partial_L(F'_L-L/2)=-D1/L^2`.

The correct multiplicity-robust hypothesis is ONE-SIDED:

`D1<=K1_k L`.

Indeed, if multiplicity `m>1`, the collision slope is stronger than `L/2`,
and `D1` may be negative of order `L^2`; that must not count as a failure.

The one-sided bound gives

`F'_L>=L/2-O_k(log L)`

and hence eventual `F'_L>=c_k L` for every `c_k<1/2`.

Therefore fixed-mode cutoff independence follows directly from

`|C0|=O_k(L)`

and

`positive_part(D1)=O_k(L)`

uniformly on the eventual fixed-k tube.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", detail_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
