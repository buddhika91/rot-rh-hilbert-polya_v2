#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v477 — SUPEROSCILLATORY COUNTERMODEL / ARITHMETIC-STRUCTURE BARRIER
=========================================================================

PURPOSE
-------
Test whether the final v476 window-coherence-collapse mechanism can be excluded
by abstract positive-frequency harmonic analysis alone.

It cannot.

We construct an explicit family whose entire Fourier support escapes to
+infinity, whose phase is asymptotically constant on every fixed physical
window, but whose normalized coherence collapses exponentially because the
coefficient l1 mass is enormous.

This shows that v476 is essentially the endpoint of structure-free
frequency-escape arguments.  Any further exclusion must use arithmetic
constraints on the actual zeta-residue coefficients, or the Hilbert-space /
Fredholm realization.

---------------------------------------------------------------------------
A. Superoscillatory family
---------------------------------------------------------------------------

Let M_N>1 and define

    F_N(t)
      = exp(i M_N t)
        [ cos(t/N) - i M_N sin(t/N) ]^N.

Expand

    cos y - i M sin y
      = [(1-M)/2] exp(i y)
        +[(1+M)/2] exp(-i y).

Therefore F_N is an exponential polynomial with frequencies

    gamma_(N,k)
      = M_N + (2k-N)/N,
      k=0,...,N.

Hence

    min_k gamma_(N,k) = M_N-1.

If M_N->infinity, ALL spectral support escapes to +infinity.

The coefficient l1 mass is exactly

    W0_N
      = [ |1-M_N|/2 + |1+M_N|/2 ]^N
      = M_N^N.

---------------------------------------------------------------------------
B. Constant-phase window limit
---------------------------------------------------------------------------

For fixed |t|<=h, put y=t/N.  Taylor expansion gives

    log[cos y - i M_N sin y]
      = -i M_N y
        +(M_N^2-1)y^2/2
        +O(M_N^3 |y|^3)

uniformly provided M_N |y| is small.

Thus

    log F_N(t)
      = iM_N t
        -iM_N t
        +(M_N^2-1)t^2/(2N)
        +O(M_N^3 h^3/N^2).

Choose for example

    M_N=N^alpha,
    0<alpha<1/2.

Then

    M_N^2/N ->0,
    M_N^3/N^2 ->0,

so uniformly on every fixed window,

    F_N(t) -> 1.

Therefore

    arg F_N(t) -> 0

uniformly and

    |F_N(t)| ->1.

Yet

    |F_N(t)|/W0_N
      ~ M_N^(-N)
      ->0

super-exponentially.

So this family satisfies exactly the qualitative exceptional mechanism isolated
by v476:
  * all positive frequencies escape;
  * physical phase locks to a bounded carrier (indeed zero);
  * absolute function amplitude remains O(1);
  * normalized coherence relative to coefficient mass collapses.

---------------------------------------------------------------------------
C. Consequence for ROT-RH
---------------------------------------------------------------------------

Therefore the following data are NOT sufficient to exclude the nonattained
collective branch:

  * positive frequencies;
  * support migration gamma->infinity;
  * zero-count / local finiteness;
  * Bohr frequency escape;
  * fixed-window amplitude freezing;
  * bounded total phase velocity;
  * even uniform fixed-window phase lock.

A superoscillatory coefficient arrangement can defeat all of them by using
exponentially large internal coefficient mass and exponentially precise signed
cancellation.

What distinguishes the actual ROT-RH problem is that its coefficients are NOT
free. They are fixed by:
  * zeta-zero multiplicities/residues;
  * functional-equation pairing;
  * the compact-bump saddle factor;
  * the recursive arithmetic characteristic;
  * ultimately the proposed Hilbert-space/Fredholm realization.

Thus the final nonattained theorem must exploit one of those structures.

This is a NO-GO theorem for another generic harmonic-analysis attack, not a
counterexample to the actual zeta/ROT-RH characteristic.

No zeta values or known zeros are used.
"""

from __future__ import annotations

import argparse
import cmath
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v477-superoscillatory-structure-barrier"


def exact_spectrum_check(N: int, M: float) -> Dict[str, Any]:
    min_gamma = M - 1.0
    max_gamma = M + 1.0
    return {
        "N": N,
        "M": M,
        "minimum_frequency": min_gamma,
        "maximum_frequency": max_gamma,
        "coefficient_l1_mass_log": N*math.log(M),
        "coefficient_l1_mass_formula": "M^N",
        "positive_support": min_gamma > 0.0,
    }


def F(N: int, M: float, t: float) -> complex:
    return cmath.exp(1j*M*t) * (
        cmath.cos(t/N) - 1j*M*cmath.sin(t/N)
    )**N


def window_panel(alpha: float, h: float):
    rows = []
    for N in (100, 1000, 10000, 100000):
        M = N**alpha
        max_err = 0.0
        max_phase = 0.0
        min_amp = float("inf")
        max_log_coh = -float("inf")

        for j in range(81):
            t = -h + 2*h*j/80
            z = F(N, M, t)
            max_err = max(max_err, abs(z-1.0))
            max_phase = max(max_phase, abs(cmath.phase(z)))
            min_amp = min(min_amp, abs(z))
            log_coh = math.log(max(abs(z), 1e-300))-N*math.log(M)
            max_log_coh = max(max_log_coh, log_coh)

        rows.append({
            "N": N,
            "M": M,
            "minimum_frequency": M-1.0,
            "M2_over_N": M*M/N,
            "M3_over_N2": M**3/N**2,
            "max_abs_F_minus_1": max_err,
            "max_abs_phase": max_phase,
            "minimum_amplitude": min_amp,
            "max_log_normalized_coherence": max_log_coh,
        })
    return rows


def symbolic_coefficients() -> Dict[str, Any]:
    import sympy as sp
    M = sp.symbols("M", positive=True)
    A = (1-M)/2
    B = (1+M)/2
    # for M>1, |A|=(M-1)/2, |B|=(M+1)/2
    l1_base = sp.simplify((M-1)/2 + (M+1)/2)
    return {
        "positive_M_gt_1_l1_base": str(l1_base),
        "equals_M": bool(sp.simplify(l1_base-M) == 0),
        "pass": bool(sp.simplify(l1_base-M) == 0),
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v477 — superoscillatory countermodel / arithmetic-structure barrier

Define

`F_N(t)
 =e^(iM_N t)[cos(t/N)-iM_N sin(t/N)]^N`.

Its frequencies are exactly

`gamma_(N,k)=M_N+(2k-N)/N`,

so the full support lies in

`[M_N-1,M_N+1]`.

If `M_N->infinity`, every frequency escapes to `+infinity`.

For `M_N>1`, the coefficient `l1` mass is exactly

`W0_N=M_N^N`.

Choose

`M_N=N^alpha`, `0<alpha<1/2`.

Uniformly on each fixed `|t|<=h`,

`F_N(t)->1`.

Thus the phase tends uniformly to zero while the actual amplitude tends to one.

But

`|F_N|/W0_N ~ M_N^(-N)->0`.

Hence an escaping positive-frequency family can exhibit perfect-looking
fixed-window phase lock by superoscillatory cancellation, provided its
normalized coefficient coherence collapses.

**Verdict:** {payload['verdict']}

Therefore v476's final coherence-collapse sector cannot be eliminated using
only generic spectral escape, positivity of ordinates, window freezing, or
Bohr typicality.  The next proof must use actual arithmetic residue constraints
or the operator/Fredholm structure.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_SUPEROSCILLATORY_STRUCTURE_BARRIER_V1",
        "countermodel": {
            "support": "[M_N-1,M_N+1] -> +infinity",
            "phase": "uniformly ->0 on fixed windows",
            "amplitude": "|F_N|->1",
            "coefficient_mass": "W0=M_N^N",
            "normalized_coherence": "|F_N|/W0->0",
        },
        "generic_routes_ruled_out": [
            "frequency escape alone",
            "positive-frequency support alone",
            "fixed-window phase lock alone",
            "Bohr mean-square typicality alone",
            "amplitude freezing alone",
        ],
        "required_new_structure": [
            "actual zeta residue coefficient constraints",
            "functional equation quartet coefficient relations",
            "compact-bump saddle coefficient geometry",
            "recursive arithmetic characteristic",
            "Hilbert-space/Fredholm realization",
        ],
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alpha", type=float, default=0.25)
    ap.add_argument("--window", type=float, default=1.0)
    ap.add_argument("--prefix", default="rot_rh_superoscillatory_structure_barrier_v477")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if not (0.0 < args.alpha < 0.5):
        raise ValueError("need 0<alpha<1/2")

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*194)
    print("ROT-RH v477 — SUPEROSCILLATORY COUNTERMODEL / ARITHMETIC-STRUCTURE BARRIER")
    print("="*194)

    with tqdm(total=3, desc="v477 countermodel", unit="step") as bar:
        sym = symbolic_coefficients()
        bar.update(1)
        panel = window_panel(args.alpha, args.window)
        bar.update(1)
        spec = exact_spectrum_check(
            panel[-1]["N"],
            panel[-1]["M"],
        )
        bar.update(1)

    # Diagnostic convergence only. The theorem is the Taylor expansion.
    diag = (
        panel[-1]["max_abs_F_minus_1"] < panel[0]["max_abs_F_minus_1"]
        and panel[-1]["max_abs_phase"] < panel[0]["max_abs_phase"]
        and spec["positive_support"]
    )
    passed = bool(sym["pass"] and diag)
    verdict = (
        "EXACT_SUPEROSCILLATORY_GENERIC_HARMONIC_NO_GO_PASS"
        if passed else
        "SUPEROSCILLATORY_COUNTERMODEL_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic_panel": panel,
        "last_spectrum": spec,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "countermodel_claimed_as_zeta_model": False,
        },
        "proof_status":
            "Explicit abstract countermodel. It proves a limitation of generic harmonic-analysis strategies, not a property of the actual zeta residue family.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("coefficient algebra             :", sym["pass"])
    print("max |F-1| first/last            :",
          f"{panel[0]['max_abs_F_minus_1']:.6e}",
          "/",
          f"{panel[-1]['max_abs_F_minus_1']:.6e}")
    print("minimum frequency last          :", f"{panel[-1]['minimum_frequency']:.6e}")
    print("log normalized coherence last   :", f"{panel[-1]['max_log_normalized_coherence']:.6e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
