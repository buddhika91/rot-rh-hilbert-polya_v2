#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v417 — MULTIPLICITY-SAFE CRITICAL COLLISION WINDOW / SUPERLOCK THEOREM
=============================================================================

Purpose
-------
Advance the v415-v416 fixed-mode cutoff-independence problem by solving the
LOCAL critical-line collision contribution exactly.

This script also enforces the v405 architectural correction:

  * coefficient-space identities such as x=G7+R^7 x remain exact;
  * the regular R^7 packet transfer is controlled by v402;
  * BUT singular analytic continuations of G7 and R^7 X must not be treated
    as independent final objects when multiplicity is unknown;
  * the physical collision channel is read from the RECOMBINED fixed point.

No zeta values or zero ordinates are evaluated.

----------------------------------------------------------------------
A. Recombined local collision
----------------------------------------------------------------------

Landau's explicit formula for the centered truncated Mangoldt Dirichlet sum
contains, near a zero rho of multiplicity m,

    -zeta'/zeta(s)  ->  m/(rho-s)

together with the zero residue

    -m exp[(rho-s)L]/(rho-s).

Thus the exact local pair is

    Q_m(a,L)
      = m [1-exp(aL)] / a,
      a=rho-s.

On the critical line take

    s=1/2+iE,
    rho=1/2+i gamma,
    u=(gamma-E)L,

so a=i u/L.

Then

    Q_m
      = -m L sin(u)/u
        - i m L [1-cos(u)]/u.

The v415 generator C0 is minus the imaginary part of this centered complex
sum, hence

    C0_coll
      = m L f(u),

    f(u)
      = [1-cos(u)]/u,
      f(0)=0.

Since C1=partial_E C0 and du/dE=-L,

    C1_coll
      = -m L^2 g(u),

where

    g(u)
      = f'(u)
      = [u sin(u)-(1-cos(u))]/u^2,
      g(0)=1/2.

The multiplicity-robust stiffness generator is

    D1_coll
      = C1_coll + L^2/2
      = L^2 [1/2-m g(u)].

----------------------------------------------------------------------
B. Exact first-generator collision bound
----------------------------------------------------------------------

For every real u,

    |f(u)| <= 1.

Proof:
  * if |u|<=2, 1-cos(u)<=u^2/2, so |f(u)|<=|u|/2<=1;
  * if |u|>=2, 1-cos(u)<=2, so |f(u)|<=2/|u|<=1.

Therefore

    |C0_coll| <= m L

for EVERY critical collision detuning.

So the local critical-line collision channel itself can never violate the
v415 first-generator O(L) scale.

----------------------------------------------------------------------
C. One-sided D1 collision theorem
----------------------------------------------------------------------

For |u|<=1, the elementary alternating-Taylor inequalities give

    u sin(u) >= u^2-u^4/6,

    1-cos(u) <= u^2/2.

Hence

    g(u) >= 1/2-u^2/6.

Therefore

    D1_coll/L^2
      <= -(m-1)/2 + m u^2/6.

Consequences:

MULTIPLE ZERO, m>=2:
For |u|<=1,

    D1_coll/L^2
      <= -(m-1)/2 + m/6
      = (3-2m)/6
      <= -1/6.

Thus

    D1_coll <= -L^2/6 < 0.

The entire local multiple-zero collision is BENEFICIAL for the one-sided v415
transversality theorem.

SIMPLE ZERO, m=1:
For |u|<=1,

    (D1_coll)_+
      <= L^2 u^2/6.

Hence if

    |u| <= A/sqrt(L),

then

    (D1_coll)_+ <= A^2 L/6.

Equivalently,

    |E-gamma|
      <= A/L^(3/2)

is a sufficient local SIMPLE-COLLISION SUPERLOCK condition for the desired
O(L) positive stiffness defect.

This is much sharper than a generic E-gamma=O(1/L) phase lock.

----------------------------------------------------------------------
D. What this means for the remaining theorem
----------------------------------------------------------------------

The local critical collision itself is now analytically understood.

The remaining global theorem must prove one of the following:

1. SIMPLE-COLLISION SUPERLOCK:
   the fixed quantized branch approaches its associated simple critical
   collision with |E-gamma|=O(L^(-3/2)), uniformly enough for the fixed-k tube;

OR

2. COLLECTIVE COMPENSATION:
   other signed recombined resonance channels cancel the O(L^2) positive
   part of the simple-collision D1 channel while preserving the C0=O(L) scale;

AND in either case

3. OFF-CRITICAL / NONATTAINED CONTROL:
   the full signed off-critical resonance system must not create positive
   generator growth exceeding O(L).

v408-v411 explain why this last part cannot be replaced by magnitude-only
PNT estimates or fixed-epsilon mean-motion continuity.

----------------------------------------------------------------------
E. v405 architectural correction
----------------------------------------------------------------------

v404 found at a multiplicity-m zero the split principal residues

    Res X       = -m,
    Res R^7 X   = -m^8,
    Res G7      = m^8-m.

They recombine exactly:

    (m^8-m) + (-m^8) = -m.

For m=1 the split G7 pole happens to vanish.
For m>1 it does NOT.

Therefore an unconditional proof may use G7+R7 in finite coefficient space,
but it must not require the singular G7 analytic continuation by itself to be
bounded.  Singular residue accounting is multiplicity-safe only after the
v405 recombination.

The safe final statement is therefore a RECOMBINED generator theorem with
v402 delegated only the regular R7 packet transfer.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO numerical zeta derivatives.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 417
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 417


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_collision_algebra():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    u, L, m = sp.symbols(
        "u L m",
        real=True,
        positive=True,
    )
    # u may actually have either sign; use a separate real symbol for algebra.
    ur = sp.symbols("u", real=True)
    I = sp.I

    # a = i u/L
    a = I * ur / L
    Q = sp.simplify(
        m * (1-sp.exp(a*L)) / a
    )

    # Candidate real/imaginary decomposition.
    q_re = -m*L*sp.sin(ur)/ur
    q_im = -m*L*(1-sp.cos(ur))/ur

    # Verify algebra away from u=0 by expand_complex.
    Qexp = sp.expand_complex(Q)
    re_resid = sp.simplify(
        sp.re(Qexp) - q_re
    )
    im_resid = sp.simplify(
        sp.im(Qexp) - q_im
    )

    f = (1-sp.cos(ur))/ur
    g = sp.simplify(sp.diff(f, ur))
    g_expected = (
        ur*sp.sin(ur)
        - (1-sp.cos(ur))
    )/ur**2

    g_resid = sp.simplify(
        g-g_expected
    )

    f_series = sp.series(f, ur, 0, 6)
    g_series = sp.series(g, ur, 0, 6)

    return {
        "Q": str(Q),
        "real_part_formula": str(q_re),
        "imag_part_formula": str(q_im),
        "real_residual": str(re_resid),
        "imag_residual": str(im_resid),
        "f_series": str(f_series),
        "g_formula": str(g),
        "g_series": str(g_series),
        "g_residual": str(g_resid),
        "f_at_zero_limit": str(
            sp.limit(f, ur, 0)
        ),
        "g_at_zero_limit": str(
            sp.limit(g, ur, 0)
        ),
        "pass": bool(
            re_resid == 0
            and im_resid == 0
            and g_resid == 0
            and sp.limit(f, ur, 0) == 0
            and sp.limit(g, ur, 0) == sp.Rational(1,2)
        ),
    }


def symbolic_residue_recombination():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    m = sp.symbols(
        "m",
        positive=True,
        integer=True,
    )

    res_X = -m
    res_R7 = -m**8
    res_G7 = sp.simplify(
        res_X-res_R7
    )
    recombined = sp.simplify(
        res_G7+res_R7
    )

    simple = sp.simplify(
        res_G7.subs(m, 1)
    )
    double = sp.simplify(
        res_G7.subs(m, 2)
    )

    return {
        "Res_X": str(res_X),
        "Res_R7X": str(res_R7),
        "Res_G7": str(res_G7),
        "recombined": str(recombined),
        "simple_G7_residue": str(simple),
        "double_G7_residue": str(double),
        "pass": bool(
            recombined == res_X
            and simple == 0
            and double == 254
        ),
    }


def exact_elementary_inequality_certificate():
    """
    Record the exact elementary inequalities used.  This is a theorem
    certificate, not a floating scan.

    For |u|<=1:
       sin |u| >= |u|-|u|^3/6
       1-cos u <= u^2/2.
    Thus
       g(u)>=1/2-u^2/6.
    """
    return {
        "global_f_bound": {
            "claim": "|(1-cos u)/u|<=1 for all real u, with value 0 at u=0",
            "proof_split": [
                "|u|<=2: 1-cos u<=u^2/2 => |f|<=|u|/2<=1",
                "|u|>=2: 1-cos u<=2 => |f|<=2/|u|<=1",
            ],
        },
        "local_g_lower": {
            "domain": "|u|<=1",
            "inputs": [
                "u sin u >= u^2-u^4/6",
                "1-cos u <= u^2/2",
            ],
            "claim": "g(u)>=1/2-u^2/6",
        },
        "multiple_zero": {
            "m": "integer m>=2",
            "domain": "|u|<=1",
            "bound": (
                "D1/L^2 <= -(m-1)/2+m/6=(3-2m)/6<=-1/6"
            ),
        },
        "simple_zero": {
            "m": 1,
            "domain": "|u|<=1",
            "bound": "(D1)_+ <= L^2 u^2/6",
            "superlock": (
                "|u|<=A/sqrt(L) => (D1)_+<=A^2 L/6"
            ),
            "energy_form": "|E-gamma|<=A/L^(3/2)",
        },
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v416-summary",
        default="rot_rh_generator_G7_head_bridge_v416_SUMMARY.json",
    )
    ap.add_argument(
        "--v415-summary",
        default="rot_rh_multiplicity_robust_generator_v415_SUMMARY.json",
    )
    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument(
        "--v404-summary",
        default="rot_rh_G7_local_singularity_v404_SUMMARY.json",
    )
    ap.add_argument(
        "--v402-summary",
        default="rot_rh_weighted_factorial_four_jet_v402_SUMMARY.json",
    )
    ap.add_argument(
        "--v408-summary",
        default="rot_rh_nonattained_support_migration_v408_SUMMARY.json",
    )
    ap.add_argument(
        "--v411-summary",
        default="rot_rh_collective_phase_lock_v411_SUMMARY.json",
    )

    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_collision_window_superlock_v417",
    )

    args = ap.parse_args()

    v416 = load_json(args.v416_summary)
    v415 = load_json(args.v415_summary)
    v405 = load_json(args.v405_summary)
    v404 = load_json(args.v404_summary)
    v402 = load_json(args.v402_summary)
    v408 = load_json(args.v408_summary)
    v411 = load_json(args.v411_summary)

    v416_ok = bool(
        v416 is not None
        and v416.get("verdict")
        == "EXACT_GENERATOR_TO_G7_HEAD_EXPLICIT_FORMULA_BRIDGE_PASS"
    )
    v415_ok = bool(
        v415 is not None
        and v415.get("verdict")
        == "PROSPECTIVE_MULTIPLICITY_ROBUST_GENERATOR_CLOSURE_HOLDOUT_PASS"
    )
    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )
    v402_ok = bool(
        v402 is not None
        and v402.get("verdict")
        == "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
    )
    v408_ok = bool(
        v408 is not None
        and v408.get("verdict")
        == "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS"
    )
    v411_ok = bool(
        v411 is not None
        and v411.get("verdict")
        == "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS"
    )

    v404_text = (
        str(v404.get("verdict", ""))
        if v404 is not None
        else ""
    )
    v404_ok = bool(
        v404 is not None
        and "G7_LOCAL_SINGULARITY" in v404_text
        and "PASS" in v404_text
    )

    print("="*238)
    print("ROT-RH v417 — MULTIPLICITY-SAFE CRITICAL COLLISION WINDOW / SUPERLOCK THEOREM")
    print("="*238)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scan accepted as proof            : NO")
    print("="*238)

    print("[1] Upstream")
    print("v416 generator/head bridge               :", v416_ok)
    print("v415 generator/root-flow closure         :", v415_ok)
    print("v405 recombined multiplicity             :", v405_ok)
    print("v404 split local singularity             :", v404_ok)
    if v404 is not None:
        print("v404 verdict                             :", v404_text)
    print("v402 regular R7 four-jet                 :", v402_ok)
    print("v408 nonattained migration               :", v408_ok)
    print("v411 collective phase-lock               :", v411_ok)

    print("\n[2] Exact collision algebra")

    with tqdm(
        total=3,
        desc="critical collision theorem",
        unit="identity",
    ) as bar:
        collision = symbolic_collision_algebra()
        bar.update(1)

        residues = symbolic_residue_recombination()
        bar.update(1)

        inequalities = exact_elementary_inequality_certificate()
        bar.update(1)

    print("critical collision formulas              :", collision.get("pass"))
    print("v405 residue recombination algebra       :", residues.get("pass"))
    print("elementary inequality certificate        :", inequalities.get("pass"))

    algebra_ok = bool(
        collision.get("pass")
        and residues.get("pass")
        and inequalities.get("pass")
    )

    print("\n[3] Exact critical-line collision theorem")

    statements = [
        (
            "COLLISION_COORDINATE",
            "u=(gamma-E)L.",
        ),
        (
            "FIRST_GENERATOR",
            "C0_coll=mL(1-cos u)/u.",
        ),
        (
            "FIRST_BOUND",
            "|C0_coll|<=mL for every real u.",
        ),
        (
            "SECOND_GENERATOR",
            "D1_coll=L^2[1/2-m g(u)], g=(u sin u-(1-cos u))/u^2.",
        ),
        (
            "G_LOWER",
            "|u|<=1 => g(u)>=1/2-u^2/6.",
        ),
        (
            "MULTIPLE_ZERO",
            "m>=2 and |u|<=1 => D1_coll<=-L^2/6; multiplicity helps transversality.",
        ),
        (
            "SIMPLE_ZERO",
            "m=1 and |u|<=1 => (D1_coll)_+<=L^2 u^2/6.",
        ),
        (
            "SIMPLE_SUPERLOCK",
            "|u|<=A/sqrt(L), i.e. |E-gamma|<=A/L^(3/2), gives (D1_coll)_+<=A^2 L/6.",
        ),
    ]

    for key, txt in statements:
        print(f"{key:46s}: {txt}")

    print("\n[4] v405 architectural correction")

    architecture = [
        (
            "SPLIT_RESIDUES",
            "Res X=-m, Res R7X=-m^8, Res G7=m^8-m.",
        ),
        (
            "RECOMBINATION",
            "(m^8-m)-m^8=-m exactly.",
        ),
        (
            "SIMPLE_ACCIDENT",
            "For m=1 the split G7 principal pole vanishes.",
        ),
        (
            "MULTIPLE_WARNING",
            "For m>1 the split G7 pole is nonzero; separate singular G7 boundedness is not a multiplicity-safe final theorem.",
        ),
        (
            "SAFE_USE_OF_V402",
            "v402 controls the regular recursive packet transfer; singular residue accounting remains recombined as in v405.",
        ),
        (
            "SAFE_FINAL_OBJECT",
            "The final all-L theorem is the recombined v415 generator, with the regular R7 packet contribution controlled separately.",
        ),
    ]

    for key, txt in architecture:
        print(f"{key:46s}: {txt}")

    print("\n[5] What is genuinely left")

    remaining = [
        (
            "LOCAL_CRITICAL_C0",
            "CLOSED: a critical collision contributes only O(mL) to C0 for every detuning.",
        ),
        (
            "MULTIPLE_CRITICAL_D1",
            "CLOSED locally on |u|<=1: multiplicity m>=2 gives negative D1 and cannot damage the one-sided slope theorem.",
        ),
        (
            "SIMPLE_CRITICAL_D1",
            "Need simple-collision superlock |E-gamma|=O(L^-3/2), OR signed compensation from the remaining resonance system.",
        ),
        (
            "OFFCRITICAL_CLUSTER",
            "Still open: control the full recombined off-critical/attained/nonattained signed resonance contribution.",
        ),
        (
            "NONATTAINED_ROUTE",
            "v408-v411 show this cannot be replaced by magnitude-only PNT bounds or regular epsilon->0 mean-motion continuity.",
        ),
        (
            "FINAL_GENERATOR_TARGET",
            "Prove |C0|=O_k(L) and positive_part(D1)=O_k(L) for the full recombined generator on the fixed-k tube.",
        ),
    ]

    for key, txt in remaining:
        print(f"{key:46s}: {txt}")

    upstream_ok = bool(
        v416_ok
        and v415_ok
        and v405_ok
        and v404_ok
        and v402_ok
        and v408_ok
        and v411_ok
    )

    theorem_pass = bool(
        upstream_ok
        and algebra_ok
    )

    verdict = (
        "EXACT_MULTIPLICITY_SAFE_COLLISION_WINDOW_SUPERLOCK_REDUCTION_PASS"
        if theorem_pass
        else
        "COLLISION_WINDOW_SUPERLOCK_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_RECOMBINED_SIMPLE_COLLISION_SUPERLOCK_OR_SIGNED_COMPENSATION_AND_OFFCRITICAL_GENERATOR_CONTROL"
    )

    print("\n" + "="*238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "CRITICAL COLLISION C0                    :",
        "ANALYTICALLY CLOSED AT O(L)",
    )
    print(
        "MULTIPLE-ZERO D1 LOCAL CHANNEL           :",
        "ANALYTICALLY SAFE / BENEFICIAL",
    )
    print(
        "SIMPLE-ZERO D1 LOCAL CHANNEL             :",
        "REQUIRES O(L^-3/2) SUPERLOCK OR COLLECTIVE COMPENSATION",
    )
    print(
        "FINAL GLOBAL BOTTLENECK                  :",
        "RECOMBINED SIGNED OFF-CRITICAL + SIMPLE-COLLISION COMPENSATION",
    )
    print("FIXED-MODE CUTOFF INDEPENDENCE           : NOT YET PROVED")
    print("="*238)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v416_ok": v416_ok,
            "v415_ok": v415_ok,
            "v405_ok": v405_ok,
            "v404_ok": v404_ok,
            "v404_verdict": v404_text,
            "v402_ok": v402_ok,
            "v408_ok": v408_ok,
            "v411_ok": v411_ok,
        },
        "collision_algebra": collision,
        "residue_recombination": residues,
        "elementary_inequalities": inequalities,
        "critical_collision_theorem": {
            key: txt for key, txt in statements
        },
        "architecture": {
            key: txt for key, txt in architecture
        },
        "remaining": {
            key: txt for key, txt in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact local critical-collision theorem plus multiplicity-safe "
            "architectural correction. The critical collision contribution to "
            "C0 is automatically O(L). Multiple critical zeros are locally "
            "beneficial for the one-sided D1 theorem. For a simple collision, "
            "D1=O(L) follows from |E-gamma|=O(L^-3/2), unless the remaining "
            "signed resonance system supplies compensation. Global off-critical "
            "signed control remains open."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v417 — critical collision window / superlock theorem

For a critical-line zero `rho=1/2+i gamma` of multiplicity `m`, set

`u=(gamma-E)L`.

The exact recombined Landau collision pair gives

`C0_coll = m L (1-cos u)/u`

and

`D1_coll = L^2 [1/2-m g(u)]`,

where

`g(u)=[u sin u-(1-cos u)]/u^2`,
`g(0)=1/2`.

For every real `u`,

`|(1-cos u)/u|<=1`,

so

`|C0_coll|<=mL`.

Thus a critical collision cannot violate the v415 first-generator scale.

For `|u|<=1`,

`g(u)>=1/2-u^2/6`.

Hence:

* if `m>=2`, `D1_coll<=-L^2/6`, so the multiple-zero local channel is
  beneficial for the one-sided transversality theorem;

* if `m=1`,
  `positive_part(D1_coll)<=L^2u^2/6`.

Therefore the local simple-collision contribution satisfies the desired
`O(L)` bound whenever

`|u|=O(L^-1/2)`,

equivalently

`|E-gamma|=O(L^-3/2)`.

The v405 recombination remains essential.  The split residues are

`Res X=-m`,
`Res R7X=-m^8`,
`Res G7=m^8-m`.

Only their recombination is multiplicity-safe.  v402 may be used for the
regular R7 packet transfer, but not to discard the singular recombination
channel.

The remaining theorem is global: prove the simple-collision superlock or its
signed collective compensation, while also controlling the recombined
off-critical resonance system.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_RECOMBINED_COLLISION_SUPERLOCK_CERTIFICATE_V1",
        "already_closed": {
            "critical_collision_C0": "|C0_coll|<=mL",
            "multiple_zero_local_D1": "D1_coll<0 for m>=2, |u|<=1",
            "simple_zero_sufficient_window": (
                "|E-gamma|<=A/L^(3/2) => positive_part(D1_coll)<=A^2 L/6"
            ),
            "regular_R7_packet_transfer": "v402",
            "multiplicity_recombination": "v405",
        },
        "required_claims": {
            "simple_collision": (
                "prove O(L^-3/2) superlock OR quantify signed compensation"
            ),
            "offcritical_cluster": (
                "prove full recombined signed generator contribution is O_k(L)"
            ),
            "fixed_k_tube": "uniform",
            "transversality": (
                "deduce from one-sided D1 after all channels are recombined"
            ),
        },
        "forbidden_as_proof": [
            "separate singular G7 boundedness without multiplicity bookkeeping",
            "simple-zero assumption",
            "magnitude-only PNT bound",
            "finite cutoff extrapolation",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
