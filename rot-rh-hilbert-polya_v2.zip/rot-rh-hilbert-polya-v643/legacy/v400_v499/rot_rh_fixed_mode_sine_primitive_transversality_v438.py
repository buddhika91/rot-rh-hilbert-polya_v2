#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v438 — FIXED-MODE SINE-PRIMITIVE + TRANSVERSALITY CUTOFF THEOREM
=======================================================================

Purpose
-------
This script isolates the minimal DYADIC FIXED-MODE cutoff-removal theorem after
v430-v437.

It does NOT attempt to prove the stronger v432 complex bounded-forcing theorem.
Instead it attacks the real/sine fixed-mode route.

Exact ingredients already available
-----------------------------------
v430:
    exact old-history / fresh-shell decomposition

        L D_total = S_L + R_L,

    where

        S_L = L D_old,
        R_L = L D_fresh.

v431/v437:
    exact local sine forcing J_L^sin on one dyadic shell, with the renewal

        S_(L+h)
          = alpha_L S_L + beta_L J_L,

        alpha_L=(L+h)/(L+2h),
        beta_L=h/(L+2h),
        h=log 2.

Multiplying by L+2h gives the telescoping form

        (L+2h)S_(L+h)
          = (L+h)S_L + h J_L.

For L_n=L_0+n h and S_n=S_(L_n),

        L_(n+1) S_n
          = L_1 S_0
            + h sum_(j=0)^(n-1) J_j.

Therefore if the signed primitive satisfies

        |sum_(j<n) J_j|
          <= C L_n^(2-epsilon),

with epsilon>0, then

        S_n = O(L_n^(1-epsilon)),

and hence

        D_old = S_n/L_n = O(L_n^(-epsilon)).

Fresh remainder gate
--------------------
If additionally

        |R_n|=|L_n D_fresh|
          <= C_f L_n^(1-epsilon),

then

        Delta_h F_L(E)
          = D_old + D_fresh
          = O(L^(-epsilon)).

The natural strong form epsilon=1 is

        signed primitive = O(L),
        L D_fresh = O(1),

which gives

        Delta_h F_L(E)=O(1/L).

Transversality gate
-------------------
Let E_(k,L) and E_(k,L+h) be corresponding roots of the same quantization
level.  The exact mean-value identity is

    E_(k,L+h)-E_(k,L)
      = - Delta_h F_L(E_(k,L))
        / F'_(L+h)(xi_k,L)

for some xi between the two roots.

If on an eventual fixed-k tube

        F'_L(E) >= c_k L,

then

    |Delta E_k|
      = O(L^(-1-epsilon)).

Because L_n=L_0+n log 2,

    sum_n L_n^(-1-epsilon) < infinity

for every epsilon>0.  Therefore

    E_(k,L_n) -> E_k^(infinity).

For epsilon=1,

    |Delta E_k|=O(L^-2),
    |E_k^(infinity)-E_(k,L)|=O(1/L).

What v438 audits
----------------
1. Loads the exact v430 old/fresh decomposition.
2. Loads the exact v437 complex forcing and takes

       J_sin = -Im J_complex.

3. Verifies the v431 renewal directly against the stored v430 S=L D_old.
4. Accumulates the signed primitive mode-by-mode and tube-coordinate-by-tube.
5. Audits the strong finite O(L) primitive diagnostic using the Cesaro mean.
6. Audits the strong finite fresh-remainder diagnostic |L D_fresh|=O(1).
7. Cross-checks the total phase transfer against v435:

       L * Im(Q_(2X)-Q_X) = L D_total.

8. Independently evaluates F'_X/L from the zero-free v71 phase_prime_grid on
   the same fixed-mode tube points.
9. Freezes development caps and checks holdout without using Xi or zero data.
10. Writes an analytic certificate specifying the three all-L statements that
    would close fixed-mode cutoff independence.

IMPORTANT
---------
A finite PASS is NOT the proof.  The proof still requires ALL-L bounds:

    (A) signed primitive subquadratic,
    (B) fresh scaled remainder of compatible order,
    (C) eventual uniform transversality/no-fold.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO new root solves.
NO larger cutoff.
Finite regression is not accepted as theorem.

Version: 438
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 438
LOG2 = math.log(2.0)
EPS = 1e-300


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def support_count(logs: np.ndarray, L: float) -> int:
    return int(
        np.searchsorted(
            logs,
            float(L) - 1e-14,
            side="left",
        )
    )


def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)
    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    base_weight = (
        np.exp(-0.5 * logs)
        / exponents
    )
    return primes, logs, exponents, base_weight


def phase_prime(
    *,
    base,
    logs: np.ndarray,
    base_weight: np.ndarray,
    X: int,
    E: np.ndarray,
) -> np.ndarray:
    L = math.log(float(X))
    k = support_count(logs, L)
    l = logs[:k]
    w = (
        base_weight[:k]
        * (1.0 - l / L)
    )
    return np.asarray(
        base.phase_prime_grid(
            np.asarray(E, float),
            int(X),
            l,
            w,
        ),
        float,
    )


def expected_upstream(summary: Optional[dict], verdict: str) -> bool:
    return bool(
        summary is not None
        and summary.get("verdict") == verdict
    )


def symbolic_theorem(epsilon: float) -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, h, S, J = sp.symbols(
        "L h S J",
        positive=True,
        real=True,
    )
    alpha = (L+h)/(L+2*h)
    beta = h/(L+2*h)
    recurrence = sp.simplify(
        (L+2*h)*(alpha*S+beta*J)
        - ((L+h)*S+h*J)
    )

    # Power bookkeeping:
    # primitive O(L^(2-eps)) -> S O(L^(1-eps))
    # R=L D_fresh O(L^(1-eps))
    # total DeltaF O(L^-eps)
    # F' >= cL -> DeltaE O(L^(-1-eps)).
    return {
        "alpha_plus_beta": str(sp.simplify(alpha+beta)),
        "telescoping_recurrence_residual": str(recurrence),
        "primitive_hypothesis": (
            "|sum_{j<n} J_j| <= C L_n^(2-epsilon)"
        ),
        "old_scaled_consequence": (
            "S_n=L_n D_old=O(L_n^(1-epsilon))"
        ),
        "fresh_hypothesis": (
            "|R_n|=|L_n D_fresh|<=C_f L_n^(1-epsilon)"
        ),
        "phase_transfer_consequence": (
            "Delta_h F=O(L^-epsilon)"
        ),
        "transversality_hypothesis": (
            "F'_L(E)>=c_k L on eventual fixed-k tube"
        ),
        "root_increment_consequence": (
            "Delta E_k=O(L^(-1-epsilon))"
        ),
        "root_tail_consequence": (
            "E_k(infinity)-E_k(L)=O(L^-epsilon)"
        ),
        "strong_epsilon_1": (
            "primitive O(L), L D_fresh=O(1), "
            "DeltaF=O(1/L), DeltaE=O(1/L^2), root tail O(1/L)"
        ),
        "epsilon": float(epsilon),
        "pass": bool(recurrence == 0 and 0 < epsilon <= 1.0),
    }


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v430-points",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v430-summary",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_SUMMARY.json",
    )
    ap.add_argument(
        "--v435-points",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v435-summary",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_SUMMARY.json",
    )
    ap.add_argument(
        "--v437-points",
        default="rot_rh_signed_dyadic_krein_forcing_bridge_v437_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v437-summary",
        default="rot_rh_signed_dyadic_krein_forcing_bridge_v437_SUMMARY.json",
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )

    ap.add_argument(
        "--epsilon",
        type=float,
        default=1.0,
        help=(
            "The theorem permits 0<epsilon<=1. "
            "epsilon=1 is the strong O(L) primitive / O(1) fresh class."
        ),
    )
    ap.add_argument(
        "--development-shells",
        type=int,
        default=1,
    )
    ap.add_argument(
        "--primitive-cap-safety",
        type=float,
        default=1.5,
    )
    ap.add_argument(
        "--fresh-cap-safety",
        type=float,
        default=1.5,
    )
    ap.add_argument(
        "--transfer-cap-safety",
        type=float,
        default=1.25,
    )
    ap.add_argument(
        "--minimum-slope-ratio",
        type=float,
        default=0.45,
    )
    ap.add_argument(
        "--maximum-renewal-relative",
        type=float,
        default=5e-10,
    )
    ap.add_argument(
        "--maximum-total-transfer-absolute",
        type=float,
        default=2e-9,
    )
    ap.add_argument(
        "--maximum-energy-alignment",
        type=float,
        default=5e-12,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_fixed_mode_sine_primitive_transversality_v438",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()

    if not (0 < args.epsilon <= 1):
        raise ValueError("--epsilon must satisfy 0 < epsilon <= 1")
    for name in (
        "primitive_cap_safety",
        "fresh_cap_safety",
        "transfer_cap_safety",
    ):
        if getattr(args, name) <= 1.0:
            raise ValueError(f"--{name.replace('_','-')} must be >1")

    started = time.time()

    v430s = load_json(args.v430_summary)
    v435s = load_json(args.v435_summary)
    v437s = load_json(args.v437_summary)
    v424s = load_json(args.v424_summary)

    v430_ok = expected_upstream(
        v430s,
        "EXACT_DYADIC_OLD_FRESH_TRANSFER_DECOMPOSITION_PASS_OLD_HISTORY_CARRIER",
    )
    v435_ok = expected_upstream(
        v435s,
        "EXACT_CANONICAL_COMPLEX_RIESZ_SCALAR_CHARACTERISTIC_NORMALIZATION_PASS",
    )
    v437_ok = expected_upstream(
        v437s,
        "EXACT_V432_COMPLEX_FORCING_AS_SIGNED_DYADIC_KREIN_TRANSFER_PASS",
    )
    v424_ok = expected_upstream(
        v424s,
        "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS",
    )

    print("=" * 238)
    print("ROT-RH v438 — FIXED-MODE SINE-PRIMITIVE + TRANSVERSALITY CUTOFF THEOREM")
    print("=" * 238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff                             : NONE")
    print("finite audit accepted as proof            : NO")
    print("=" * 238)

    print("[1] Upstream")
    print("v430 old/fresh exact decomposition       :", v430_ok, None if v430s is None else v430s.get("verdict"))
    print("v435 canonical phase characteristic       :", v435_ok, None if v435s is None else v435s.get("verdict"))
    print("v437 exact signed Krein forcing bridge    :", v437_ok, None if v437s is None else v437s.get("verdict"))
    print("v424 primitive-beta finite evidence       :", v424_ok, None if v424s is None else v424s.get("verdict"))

    print("\n[2] Exact theorem algebra")
    theorem = symbolic_theorem(args.epsilon)
    print("symbolic theorem pass                     :", theorem.get("pass"))
    print("primitive hypothesis                      :", theorem.get("primitive_hypothesis"))
    print("fresh hypothesis                          :", theorem.get("fresh_hypothesis"))
    print("transversality hypothesis                 :", theorem.get("transversality_hypothesis"))
    print("root increment consequence                :", theorem.get("root_increment_consequence"))
    print("root tail consequence                     :", theorem.get("root_tail_consequence"))

    # ------------------------------------------------------------------
    # Load and align exact point tables.
    # ------------------------------------------------------------------
    p430 = Path(args.v430_points)
    p435 = Path(args.v435_points)
    p437 = Path(args.v437_points)
    for p in (p430, p435, p437):
        if not p.exists():
            raise FileNotFoundError(p)

    d430 = pd.read_csv(p430)
    d435 = pd.read_csv(p435)
    d437 = pd.read_csv(p437)

    req430 = {
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate", "E_fixed",
        "LD_old", "LD_fresh", "LD_total",
    }
    req435 = {
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate", "E_fixed",
        "dQ_imag",
    }
    req437 = {
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate", "E_fixed",
        "forcing_imag",
    }

    for label, df, req in (
        ("v430", d430, req430),
        ("v435", d435, req435),
        ("v437", d437, req437),
    ):
        missing = sorted(req - set(df.columns))
        if missing:
            raise KeyError(f"{label} missing columns: {missing}")

    keys = [
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate",
    ]

    a = d430[
        keys + [
            "E_fixed",
            "LD_old",
            "LD_fresh",
            "LD_total",
        ]
    ].rename(columns={"E_fixed": "E430"})

    b = d435[
        keys + [
            "E_fixed",
            "dQ_imag",
        ]
    ].rename(columns={"E_fixed": "E435"})

    c = d437[
        keys + [
            "E_fixed",
            "forcing_imag",
        ]
    ].rename(columns={"E_fixed": "E437"})

    merged = (
        a.merge(b, on=keys, how="inner", validate="one_to_one")
         .merge(c, on=keys, how="inner", validate="one_to_one")
    )

    if len(merged) != len(a) or len(merged) != len(b) or len(merged) != len(c):
        raise RuntimeError(
            "Point-table alignment is not one-to-one across v430/v435/v437."
        )

    max_E_alignment = float(
        np.max(
            np.maximum(
                np.abs(merged["E430"] - merged["E435"]),
                np.abs(merged["E430"] - merged["E437"]),
            )
        )
    )
    if max_E_alignment > args.maximum_energy_alignment:
        raise RuntimeError(
            f"Energy alignment failed: {max_E_alignment:.3e}"
        )

    merged["E_fixed"] = merged["E430"].astype(float)
    merged["L0"] = np.log(merged["X0"].astype(float))
    merged["L1"] = np.log(merged["X1"].astype(float))

    # v437 J_complex has J_sin = -Im J_complex.
    merged["J_sin"] = -merged["forcing_imag"].astype(float)

    # v435 dQ_imag is the real secular phase transfer because theta is
    # cutoff-independent.
    merged["LD_total_from_v435"] = (
        merged["L0"] * merged["dQ_imag"].astype(float)
    )
    merged["LD_total_cross_abs"] = np.abs(
        merged["LD_total_from_v435"]
        - merged["LD_total"].astype(float)
    )
    max_transfer_cross = float(
        merged["LD_total_cross_abs"].max()
    )

    print("\n[3] Exact table alignment / total transfer cross-check")
    print("aligned point rows                        :", len(merged))
    print("maximum energy alignment                  :", f"{max_E_alignment:.12e}")
    print("max |L*dQ_imag - LD_total(v430)|         :", f"{max_transfer_cross:.12e}")

    # ------------------------------------------------------------------
    # Exact renewal check.
    #
    # For a fixed (root_index,tube_coordinate) track:
    # S_n = v430 LD_old on shell n.
    # J_n = v437 sine forcing on shell n.
    # S_(n+1)=alpha_n S_n+beta_n J_n.
    # ------------------------------------------------------------------
    merged = merged.sort_values(
        ["root_index", "tube_coordinate", "shell_index"]
    ).reset_index(drop=True)

    renewal_rows = []
    max_renewal_rel = 0.0

    track_keys = ["root_index", "tube_coordinate"]
    for tkey, g in merged.groupby(track_keys, sort=True):
        g = g.sort_values("shell_index").reset_index(drop=True)
        for i in range(len(g)-1):
            r0 = g.iloc[i]
            r1 = g.iloc[i+1]

            # Require adjacent dyadic shell continuity.
            if int(r0["X1"]) != int(r1["X0"]):
                continue

            L = float(r0["L0"])
            h = float(r0["L1"] - r0["L0"])
            S0 = float(r0["LD_old"])
            J0 = float(r0["J_sin"])
            S1 = float(r1["LD_old"])

            alpha = (L+h)/(L+2*h)
            beta = h/(L+2*h)
            pred = alpha*S0 + beta*J0

            abs_resid = abs(pred-S1)
            rel_resid = abs_resid / max(
                abs(S1), abs(pred), 1e-12
            )
            max_renewal_rel = max(
                max_renewal_rel,
                rel_resid,
            )

            renewal_rows.append({
                "root_index": int(r0["root_index"]),
                "tube_coordinate": float(r0["tube_coordinate"]),
                "shell_index": int(r0["shell_index"]),
                "X0": int(r0["X0"]),
                "X1": int(r0["X1"]),
                "S0_LD_old": S0,
                "J_sin": J0,
                "S1_actual": S1,
                "S1_predicted": pred,
                "absolute_residual": abs_resid,
                "relative_residual": rel_resid,
            })

    renewal_df = pd.DataFrame(renewal_rows)

    print("\n[4] Exact renewal reconstruction")
    print("renewal comparisons                       :", len(renewal_df))
    print("maximum renewal relative residual         :", f"{max_renewal_rel:.12e}")
    renewal_pass = bool(
        len(renewal_df) > 0
        and max_renewal_rel <= args.maximum_renewal_relative
    )
    print("renewal reconstruction pass               :", renewal_pass)

    # ------------------------------------------------------------------
    # Signed primitive diagnostics.
    # Use shell index count as the discrete dyadic variable. Since
    # L_n=L0+n log2, O(n^p) and O(L_n^p) are equivalent asymptotically.
    # ------------------------------------------------------------------
    primitive_rows = []
    for tkey, g in merged.groupby(track_keys, sort=True):
        g = g.sort_values("shell_index").reset_index(drop=True)
        cumulative = 0.0
        for i, row in g.iterrows():
            cumulative += float(row["J_sin"])
            count = i+1
            L = float(row["L0"])
            primitive_rows.append({
                "set": str(row["set"]),
                "root_index": int(row["root_index"]),
                "tube_coordinate": float(row["tube_coordinate"]),
                "shell_index": int(row["shell_index"]),
                "X0": int(row["X0"]),
                "X1": int(row["X1"]),
                "L0": L,
                "J_sin": float(row["J_sin"]),
                "signed_primitive": cumulative,
                "abs_primitive": abs(cumulative),
                "abs_primitive_per_shell": abs(cumulative)/count,
                "abs_primitive_over_L": abs(cumulative)/L,
                "abs_primitive_subquadratic_normalized": (
                    abs(cumulative)
                    / max(L**(2.0-args.epsilon), EPS)
                ),
            })

    primitive_df = pd.DataFrame(primitive_rows)

    # ------------------------------------------------------------------
    # Independent transversality F'/L on same tube points.
    # Evaluate at endpoint cutoff X1, which is the derivative entering the
    # exact mean-value root-shift identity.
    # ------------------------------------------------------------------
    base = importlib.import_module(args.v71_module)
    max_X = int(merged["X1"].max())

    print("\n[5] Independent zero-free transversality")
    t0 = time.time()
    primes, logs, exponents, base_weight = build_cache(
        base, max_X
    )
    print("maximum reused cutoff                    :", f"{max_X:,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    merged["Fp_endpoint"] = np.nan
    merged["Fp_over_L_endpoint"] = np.nan

    groups = list(merged.groupby(["X1"], sort=True))
    bar = tqdm(
        total=len(groups),
        desc="fixed-mode transversality",
        unit="cutoff",
    )
    for (X1,), g in groups:
        idx = g.index.to_numpy()
        E = g["E_fixed"].to_numpy(float)
        Fp = phase_prime(
            base=base,
            logs=logs,
            base_weight=base_weight,
            X=int(X1),
            E=E,
        )
        L1 = math.log(float(X1))
        merged.loc[idx, "Fp_endpoint"] = Fp
        merged.loc[idx, "Fp_over_L_endpoint"] = Fp/L1
        bar.update(1)
    bar.close()

    min_slope_ratio = float(
        merged["Fp_over_L_endpoint"].min()
    )
    nofold_all = bool(
        np.all(
            np.isfinite(merged["Fp_endpoint"])
            & (merged["Fp_endpoint"] > 0)
        )
    )

    print("minimum endpoint F'/L on all tube points :", f"{min_slope_ratio:.12e}")
    print("all endpoint tube points no-fold          :", nofold_all)
    print("pre-registered transversality floor       :", f"{args.minimum_slope_ratio:.12e}")
    transversality_pass = bool(
        nofold_all
        and min_slope_ratio >= args.minimum_slope_ratio
    )
    print("finite transversality pass                :", transversality_pass)

    # ------------------------------------------------------------------
    # Development / holdout finite diagnostics.
    # ------------------------------------------------------------------
    dev_shell_indices = sorted(
        merged["shell_index"].unique().tolist()
    )[:args.development_shells]
    dev_mask = merged["shell_index"].isin(dev_shell_indices)
    hold_mask = ~dev_mask

    # Primitive table labels by shell index rather than inherited set, to make
    # the split controlled by --development-shells.
    pdev = primitive_df[
        primitive_df["shell_index"].isin(dev_shell_indices)
    ]
    phold = primitive_df[
        ~primitive_df["shell_index"].isin(dev_shell_indices)
    ]

    dev_primitive_mean = float(
        pdev["abs_primitive_per_shell"].max()
    )
    primitive_cap = (
        args.primitive_cap_safety
        * dev_primitive_mean
    )
    hold_primitive_mean = (
        float(
            phold["abs_primitive_per_shell"].max()
        )
        if len(phold) else float("nan")
    )
    primitive_hold_pass = bool(
        len(phold)
        and hold_primitive_mean <= primitive_cap
    )

    dev_fresh = float(
        np.max(
            np.abs(
                merged.loc[dev_mask, "LD_fresh"]
                .to_numpy(float)
            )
        )
    )
    fresh_cap = args.fresh_cap_safety*dev_fresh
    hold_fresh = (
        float(
            np.max(
                np.abs(
                    merged.loc[hold_mask, "LD_fresh"]
                    .to_numpy(float)
                )
            )
        )
        if np.any(hold_mask) else float("nan")
    )
    fresh_hold_pass = bool(
        np.any(hold_mask)
        and hold_fresh <= fresh_cap
    )

    dev_total = float(
        np.max(
            np.abs(
                merged.loc[dev_mask, "LD_total"]
                .to_numpy(float)
            )
        )
    )
    total_cap = args.transfer_cap_safety*dev_total
    hold_total = (
        float(
            np.max(
                np.abs(
                    merged.loc[hold_mask, "LD_total"]
                    .to_numpy(float)
                )
            )
        )
        if np.any(hold_mask) else float("nan")
    )
    total_hold_pass = bool(
        np.any(hold_mask)
        and hold_total <= total_cap
    )

    print("\n[6] Strong epsilon=1 finite diagnostics")
    print("development max |primitive|/shell         :", f"{dev_primitive_mean:.12e}")
    print("frozen primitive Cesaro cap              :", f"{primitive_cap:.12e}")
    print("holdout max |primitive|/shell             :", f"{hold_primitive_mean:.12e}")
    print("primitive holdout pass                    :", primitive_hold_pass)
    print()
    print("development max |L D_fresh|              :", f"{dev_fresh:.12e}")
    print("frozen fresh cap                         :", f"{fresh_cap:.12e}")
    print("holdout max |L D_fresh|                  :", f"{hold_fresh:.12e}")
    print("fresh remainder holdout pass              :", fresh_hold_pass)
    print()
    print("development max |L DeltaF_total|         :", f"{dev_total:.12e}")
    print("frozen total-transfer cap                :", f"{total_cap:.12e}")
    print("holdout max |L DeltaF_total|             :", f"{hold_total:.12e}")
    print("total transfer holdout pass               :", total_hold_pass)

    cross_pass = bool(
        max_transfer_cross
        <= args.maximum_total_transfer_absolute
    )

    finite_pass = bool(
        renewal_pass
        and cross_pass
        and primitive_hold_pass
        and fresh_hold_pass
        and total_hold_pass
        and transversality_pass
    )

    # ------------------------------------------------------------------
    # Per-shell summary.
    # ------------------------------------------------------------------
    shell_rows = []
    for shell_index, g in merged.groupby(
        "shell_index",
        sort=True,
    ):
        pg = primitive_df[
            primitive_df["shell_index"] == shell_index
        ]
        shell_rows.append({
            "set": str(g.iloc[0]["set"]),
            "shell_index": int(shell_index),
            "X0": int(g.iloc[0]["X0"]),
            "X1": int(g.iloc[0]["X1"]),
            "max_abs_J_sin": float(
                np.max(np.abs(g["J_sin"]))
            ),
            "max_abs_signed_primitive": float(
                pg["abs_primitive"].max()
            ),
            "max_abs_primitive_per_shell": float(
                pg["abs_primitive_per_shell"].max()
            ),
            "max_abs_LD_old": float(
                np.max(np.abs(g["LD_old"]))
            ),
            "max_abs_LD_fresh": float(
                np.max(np.abs(g["LD_fresh"]))
            ),
            "max_abs_LD_total": float(
                np.max(np.abs(g["LD_total"]))
            ),
            "minimum_Fp_over_L_endpoint": float(
                g["Fp_over_L_endpoint"].min()
            ),
            "maximum_transfer_cross_abs": float(
                g["LD_total_cross_abs"].max()
            ),
        })

    shell_df = pd.DataFrame(shell_rows)

    exact_lineage_pass = bool(
        theorem.get("pass")
        and v430_ok
        and v435_ok
        and v437_ok
        and renewal_pass
        and cross_pass
    )

    verdict = (
        "EXACT_FIXED_MODE_SINE_PRIMITIVE_TRANSVERSALITY_CUTOFF_THEOREM_PASS_ANALYTIC_BOUNDS_OPEN"
        if exact_lineage_pass
        else
        "FIXED_MODE_SINE_PRIMITIVE_TRANSVERSALITY_THEOREM_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_ALL_L_SIGNED_SINE_PRIMITIVE_SUBQUADRATIC_FRESH_REMAINDER_AND_EVENTUAL_TRANSVERSALITY"
    )

    print("\n" + "=" * 238)
    print("VERDICT                                   :", verdict)
    print("EXACT RENEWAL / OLD-HISTORY REDUCTION    :", "PASS" if renewal_pass else "FAIL")
    print("TOTAL PHASE TRANSFER CROSS-CHECK          :", "PASS" if cross_pass else "FAIL")
    print("FINITE STRONG PRIMITIVE HOLDOUT           :", primitive_hold_pass)
    print("FINITE STRONG FRESH HOLDOUT               :", fresh_hold_pass)
    print("FINITE TRANSVERSALITY                     :", transversality_pass)
    print("FINITE COMBINED DIAGNOSTIC                :", finite_pass)
    print("FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED")
    print("MISSING ANALYTIC GATES                    :")
    print("  A) all-L signed sine primitive subquadratic")
    print("  B) all-L fresh scaled remainder of compatible order")
    print("  C) eventual fixed-k tube transversality F'/L >= c_k > 0")
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 238)

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)
    points_out = Path(str(prefix) + "_POINTS.csv.gz")
    primitive_out = Path(str(prefix) + "_PRIMITIVE.csv")
    renewal_out = Path(str(prefix) + "_RENEWAL.csv")
    shell_out = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix) + "_SUMMARY.json")
    theorem_out = Path(str(prefix) + "_THEOREM.md")
    cert_out = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    merged.to_csv(
        points_out,
        index=False,
        compression="gzip",
    )
    primitive_df.to_csv(primitive_out, index=False)
    renewal_df.to_csv(renewal_out, index=False)
    shell_df.to_csv(shell_out, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff": False,
        },
        "upstream": {
            "v430_ok": v430_ok,
            "v435_ok": v435_ok,
            "v437_ok": v437_ok,
            "v424_finite_evidence_ok": v424_ok,
        },
        "exact_theorem": theorem,
        "reconstruction": {
            "maximum_energy_alignment": max_E_alignment,
            "maximum_renewal_relative_residual": max_renewal_rel,
            "maximum_total_transfer_cross_absolute": max_transfer_cross,
            "renewal_pass": renewal_pass,
            "total_transfer_cross_pass": cross_pass,
        },
        "finite_strong_epsilon_1": {
            "development_max_abs_primitive_per_shell": dev_primitive_mean,
            "primitive_cap": primitive_cap,
            "holdout_max_abs_primitive_per_shell": hold_primitive_mean,
            "primitive_holdout_pass": primitive_hold_pass,
            "development_max_abs_LD_fresh": dev_fresh,
            "fresh_cap": fresh_cap,
            "holdout_max_abs_LD_fresh": hold_fresh,
            "fresh_holdout_pass": fresh_hold_pass,
            "development_max_abs_LD_total": dev_total,
            "total_transfer_cap": total_cap,
            "holdout_max_abs_LD_total": hold_total,
            "total_transfer_holdout_pass": total_hold_pass,
            "minimum_Fp_over_L_endpoint": min_slope_ratio,
            "minimum_required_slope_ratio": args.minimum_slope_ratio,
            "nofold_all": nofold_all,
            "transversality_pass": transversality_pass,
            "combined_pass": finite_pass,
            "proof_status": "FINITE_EVIDENCE_ONLY",
        },
        "verdict": verdict,
        "fixed_mode_cutoff_independence_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time() - started,
    }
    summary_out.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        f"""# ROT-RH v438 — fixed-mode sine primitive + transversality theorem

Let `h=log 2`, `L_n=L_0+n h`, and write the exact v430 decomposition

`L_n Delta_h F_(L_n)(E) = S_n(E)+R_n(E)`,

where

`S_n=L_n D_old`, `R_n=L_n D_fresh`.

The exact v431/v437 renewal is

`(L_n+2h)S_(n+1)=(L_n+h)S_n+h J_n`.

Equivalently,

`L_(n+1) S_n
 = L_1 S_0 + h sum_(j<n) J_j`.

Hence, if for some `epsilon>0`

`|sum_(j<n) J_j| <= C_k L_n^(2-epsilon)`,

then

`S_n=O_k(L_n^(1-epsilon))`.

If also

`|R_n|<=C'_k L_n^(1-epsilon)`,

then

`Delta_h F_(L_n)=O_k(L_n^(-epsilon))`.

For corresponding roots, the exact mean-value theorem gives

`E_(k,L_n+h)-E_(k,L_n)
 =-Delta_h F_(L_n)(E_(k,L_n))
  /F'_(L_n+h)(xi_n)`.

If on the eventual fixed-k tube

`F'_L(E)>=c_k L`,

then

`Delta E_k=O_k(L_n^(-1-epsilon))`.

Since `L_n=L_0+n log2`, the series is absolutely summable for every
`epsilon>0`, so the fixed mode converges:

`E_(k,L_n) -> E_k^(infinity)`.

For the strong class `epsilon=1`:

`sum J=O(L)`,
`L D_fresh=O(1)`,
`Delta F=O(1/L)`,
`Delta E=O(1/L^2)`,
`E_k(infinity)-E_(k,L)=O(1/L)`.

The present run tests these statements only on finite development/holdout
cutoffs.  It does NOT prove the required all-L arithmetic bounds.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_FIXED_MODE_SINE_PRIMITIVE_TRANSVERSALITY_CERTIFICATE_V1",
        "exact_implication_proved": exact_lineage_pass,
        "epsilon": args.epsilon,
        "required_all_L_claims": {
            "signed_sine_primitive": {
                "proved": False,
                "statement": (
                    "|sum_{j<n} J_{k,j}^{sin}| "
                    "<= C_k L_n^(2-epsilon), epsilon>0"
                ),
                "strong_preferred": (
                    "|sum J|<=C_k L_n"
                ),
            },
            "fresh_scaled_remainder": {
                "proved": False,
                "statement": (
                    "|L_n D_fresh| "
                    "<= C'_k L_n^(1-epsilon)"
                ),
                "strong_preferred": (
                    "|L_n D_fresh|<=C'_k"
                ),
            },
            "transversality": {
                "proved": False,
                "statement": (
                    "F'_L(E)>=c_k L uniformly on an eventual "
                    "fixed-k tube, c_k>0"
                ),
            },
            "branch_persistence": {
                "proved": False,
                "statement": (
                    "the ordered fixed-k branch remains in the tube "
                    "and does not switch/fold"
                ),
            },
        },
        "consequence": (
            "the four all-L claims imply "
            "E_k(L_n)->E_k(infinity); in the strong epsilon=1 class "
            "the cutoff tail is O_k(1/L)"
        ),
        "finite_evidence": {
            "combined_pass": finite_pass,
            "minimum_Fp_over_L_endpoint": min_slope_ratio,
            "primitive_holdout_pass": primitive_hold_pass,
            "fresh_holdout_pass": fresh_hold_pass,
            "total_transfer_holdout_pass": total_hold_pass,
        },
        "forbidden_as_proof": [
            "finite cutoff holdout",
            "finite regression",
            "known zero ordinates",
            "Xi fitting",
            "absolute PNT magnitude bound that destroys signed cancellation",
            "full complex bounded-forcing assumption",
        ],
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_out)
    print(" ", primitive_out)
    print(" ", renewal_out)
    print(" ", shell_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_lineage_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
