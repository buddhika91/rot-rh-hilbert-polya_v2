#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v440 — ACTION-ANGLE OPERATOR-LIMIT / TRACE-CLASS PROMOTION AUDIT
=======================================================================

Promote the scalar fixed-mode cutoff theorem targeted by v438 to an actual
self-adjoint operator-limit theorem for the closed-form action-angle
Hamiltonians introduced in v439.

The key correction is that G_X = F'_X(D), D=(xp+px)/2, is a stiffness
generator. v438 targets F'_X ~ (1/2) log X on fixed-mode tubes, so the natural
cutoff-limit object is instead H_X e_j = E_{j,X} e_j with
F_X(E_{j,X}) = pi(j+1/2).

Analytic promotion theorems encoded here:
  A) fixed-label convergence E_{j,X}->E_j for every j implies
     H_X -> H_inf in the strong resolvent sense;
  B) adding uniform inverse-square tail tightness implies
     K_X=H_X^-2 -> K_inf in trace norm;
  C) trace-norm convergence gives local-uniform Fredholm determinant convergence.

No Xi, zeta values, known zero ordinates, or RH assumptions are used.
Version: 440
"""
from __future__ import annotations

import argparse, csv, json, math
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 440
EPS = 1e-300


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8'); return
    fields=[]; seen=set()
    for row in rows:
        for k in row:
            if k not in seen:
                seen.add(k); fields.append(k)
    with path.open('w', newline='', encoding='utf-8') as fh:
        w=csv.DictWriter(fh, fieldnames=fields); w.writeheader(); w.writerows(rows)


def parse_complex_list(text: str) -> List[complex]:
    out=[]
    for s in str(text).split(','):
        s=s.strip().replace('i','j')
        if s: out.append(complex(s))
    return out


def load_levels(path: str) -> Tuple[List[int], Dict[int, Dict[int, float]], pd.DataFrame]:
    df=pd.read_csv(path)
    req={'cutoff_X','action_label_j','energy'}
    miss=req-set(df.columns)
    if miss: raise ValueError(f'levels CSV missing columns: {sorted(miss)}')
    df=df.copy()
    df['cutoff_X']=df['cutoff_X'].astype(int)
    df['action_label_j']=df['action_label_j'].astype(int)
    df['energy']=df['energy'].astype(float)
    cutoffs=sorted(df['cutoff_X'].unique().tolist())
    by={}
    for X in cutoffs:
        q=df[df.cutoff_X==X]
        by[X]={int(r.action_label_j):float(r.energy) for r in q.itertuples()}
    return cutoffs,by,df


def common_labels(A: Dict[int,float], B: Dict[int,float], positive_only: bool) -> List[int]:
    js=sorted(set(A).intersection(B))
    if positive_only: js=[j for j in js if A[j]>0 and B[j]>0]
    return js


def resolvent_metrics(A, B, labels, z: complex):
    if not labels: return {'opnorm':float('nan'),'hs':float('nan')}
    da=np.array([1/(A[j]-z) for j in labels],complex)
    db=np.array([1/(B[j]-z) for j in labels],complex)
    d=np.abs(db-da)
    return {'opnorm':float(np.max(d)), 'hs':float(np.sqrt(np.sum(d*d)))}


def inverse_square_metrics(A, B, labels):
    labels=[j for j in labels if A[j]>0 and B[j]>0]
    if not labels: return {'trace_norm':float('nan'),'hs':float('nan')}
    a=np.array([A[j]**-2 for j in labels]); b=np.array([B[j]**-2 for j in labels])
    d=np.abs(b-a)
    return {'trace_norm':float(np.sum(d)), 'hs':float(np.sqrt(np.sum(d*d)))}


def weyl_tail_majorant(M: int, c: float, N: int=200000) -> float:
    """Diagnostic majorant assuming E_j >= c*j/log(j+1). Not a proof of that bound."""
    if c<=0: return float('nan')
    lo=max(M+1,2); N=max(N,lo+10)
    j=np.arange(lo,N+1,dtype=float)
    s=float(np.sum((np.log(j+1)/(c*j))**2))
    tail=4*(math.log(N)**2+2*math.log(N)+2)/(c*c*N)
    return s+tail


def theorem_text() -> str:
    return r'''# ROT-RH v440 — operator-limit promotion theorem

## A. Strong-resolvent promotion

On the fixed action Hilbert space \(\ell^2(J)\), define

\[
H_X e_j=E_{j,X}e_j,\qquad F_X(E_{j,X})=\pi(j+\tfrac12).
\]

Assume that for every fixed action label \(j\),

\[
E_{j,X}\to E_j.
\]

Define \(H_\infty e_j=E_j e_j\). For \(z\notin\mathbb R\),

\[
(H_X-z)^{-1}e_j=(E_{j,X}-z)^{-1}e_j.
\]

Hence for every \(f=(f_j)\in\ell^2\),

\[
\|(H_X-z)^{-1}f-(H_\infty-z)^{-1}f\|^2
=\sum_j |f_j|^2
\left|(E_{j,X}-z)^{-1}-(E_j-z)^{-1}\right|^2.
\]

Each summand tends to zero and is bounded by
\(4|f_j|^2/|\operatorname{Im}z|^2\). Dominated convergence gives

\[
\boxed{H_X\xrightarrow{\rm strong\ resolvent}H_\infty.}
\]

No convergence rate uniform in \(j\) is required. Therefore a proof of the
v438 fixed-mode theorem for every fixed mode already promotes to an infinite
self-adjoint operator limit.

## B. Trace-class promotion

Assume additionally positivity and uniform inverse-square tail tightness:

\[
\lim_{M\to\infty}\sup_{X\ge X_0}\sum_{j>M}E_{j,X}^{-2}=0.
\]

Set \(K_X=H_X^{-2}\), \(K_\infty=H_\infty^{-2}\). Then

\[
\|K_X-K_\infty\|_1
\le \sum_{j\le M}|E_{j,X}^{-2}-E_j^{-2}|
+\sum_{j>M}E_{j,X}^{-2}+\sum_{j>M}E_j^{-2}.
\]

First send \(X\to\infty\) at fixed \(M\), then \(M\to\infty\). Thus

\[
\boxed{K_X\to K_\infty\ \text{in trace norm}.}
\]

A sufficient stronger hypothesis is a cutoff-uniform Weyl lower bound

\[
E_{j,X}\ge c\,j/\log(j+1),
\]

because \(\sum_j(\log(j+1)/j)^2<\infty\).

## C. Fredholm consequence

Trace-norm convergence gives, locally uniformly in \(t\),

\[
\boxed{\det(I-t^2K_X)\to\det(I-t^2K_\infty).}
\]

So cutoff independence of the operator reduces to two scalar obligations:

1. **T_MODE:** prove the v438 fixed-mode convergence for every fixed action label.
2. **T_TAIL:** prove uniform inverse-square tail tightness (or a cutoff-uniform
   Weyl lower bound).

Only after those remain the separate entire-function identity
\(\det(I-t^2K_\infty)=\Xi(t)/\Xi(0)\).

## D. Why not take \(G_X=F'_X(D)\) as the limit?

v438 uses the stiffness growth \(F'_X\gtrsim c_k\log X\) near locked modes to
make root motion summable. Thus \(G_X\) is a transversality generator, not the
quantity expected to approach the final Hilbert-Pólya Hamiltonian. The correct
limit object is the spectral/action-angle family \(H_X\).
'''


def main() -> int:
    ap=argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument('--levels-csv', required=True)
    ap.add_argument('--z-values', default='1j,10+1j,40+2j')
    ap.add_argument('--weyl-c', type=float, default=0.0,
                    help='Only use if independently justified; 0 disables the tail majorant.')
    ap.add_argument('--tail-after-j', type=int, default=100)
    ap.add_argument('--prefix', default='rot_rh_action_angle_operator_limit_v440')
    ap.add_argument('--strict', action='store_true')
    args=ap.parse_args()

    cutoffs,by,_=load_levels(args.levels_csv); zs=parse_complex_list(args.z_values)
    print('='*180)
    print('ROT-RH v440 — ACTION-ANGLE OPERATOR-LIMIT / TRACE-CLASS PROMOTION AUDIT')
    print('='*180)
    print('Xi / zeta / known zero ordinates : NONE')
    print('cutoffs                           :',cutoffs)
    print('theorem A                         : fixed-mode convergence => strong resolvent')
    print('theorem B                         : + inverse-square tail => trace norm')
    print('='*180)

    pair_rows=[]; mode_rows=[]
    for Xa,Xb in tqdm(list(zip(cutoffs[:-1],cutoffs[1:])),desc='cutoff pairs',unit='pair'):
        labels=common_labels(by[Xa],by[Xb],True)
        if not labels: continue
        dE=np.array([by[Xb][j]-by[Xa][j] for j in labels])
        km=inverse_square_metrics(by[Xa],by[Xb],labels)
        row={'lower_cutoff':Xa,'upper_cutoff':Xb,'common_labels':len(labels),
             'first_j':labels[0],'last_j':labels[-1],
             'energy_rms_drift':float(np.sqrt(np.mean(dE*dE))),
             'energy_max_abs_drift':float(np.max(np.abs(dE))),
             'K_head_trace_norm':km['trace_norm'],'K_head_hs':km['hs']}
        for z in zs:
            rm=resolvent_metrics(by[Xa],by[Xb],labels,z)
            tag=f'z{z.real:g}_{z.imag:+g}i'.replace('+','p').replace('-','m').replace('.','d')
            row[tag+'_resolvent_opnorm']=rm['opnorm']; row[tag+'_resolvent_hs']=rm['hs']
        pair_rows.append(row)
        for j in labels:
            mode_rows.append({'lower_cutoff':Xa,'upper_cutoff':Xb,'action_label_j':j,
                              'E_lower':by[Xa][j],'E_upper':by[Xb][j],
                              'delta_E':by[Xb][j]-by[Xa][j],
                              'abs_delta_E':abs(by[Xb][j]-by[Xa][j]),
                              'delta_inv_square':by[Xb][j]**-2-by[Xa][j]**-2})

    persistent=sorted(set.intersection(*[set(by[X]) for X in cutoffs])) if cutoffs else []
    persistent=[j for j in persistent if all(by[X][j]>0 for X in cutoffs)]
    persistent_rows=[]
    for j in persistent:
        vals=np.array([by[X][j] for X in cutoffs])
        dif=np.abs(np.diff(vals))
        persistent_rows.append({'action_label_j':j,'E_first':float(vals[0]),'E_last':float(vals[-1]),
                                'net_drift':float(vals[-1]-vals[0]),
                                'max_successive_abs_drift':float(np.max(dif)) if len(dif) else 0.0,
                                'successive_abs_drift_nonincreasing':bool(np.all(np.diff(dif)<=1e-15)) if len(dif)>1 else True})

    tail=weyl_tail_majorant(args.tail_after_j,args.weyl_c) if args.weyl_c>0 else float('nan')
    prefix=Path(args.prefix)
    write_csv(Path(str(prefix)+'_PAIRWISE.csv'),pair_rows)
    write_csv(Path(str(prefix)+'_MODE_DRIFT.csv'),mode_rows)
    write_csv(Path(str(prefix)+'_PERSISTENT_MODES.csv'),persistent_rows)
    Path(str(prefix)+'_THEOREM.md').write_text(theorem_text(),encoding='utf-8')
    payload={'version':VERSION,'Xi_used':False,'zeta_used':False,'known_zero_ordinates_used':False,
             'analytic_results':{
                 'strong_resolvent_promotion':'PROVED_CONDITIONALLY_ON_FIXED_MODE_CONVERGENCE',
                 'uniform_mode_rate_required':False,
                 'trace_norm_promotion':'PROVED_CONDITIONALLY_ON_UNIFORM_INVERSE_SQUARE_TAIL_TIGHTNESS',
                 'fredholm_promotion':'FOLLOWS_FROM_TRACE_NORM_CONTINUITY'},
             'remaining':{
                 'T_MODE':'prove v438 all-L fixed-mode convergence for every fixed action label',
                 'T_TAIL':'prove uniform inverse-square tail tightness or cutoff-uniform Weyl lower bound',
                 'T_IDENTITY':'prove det(I-t^2 K_inf)=Xi(t)/Xi(0) as entire functions'},
             'raw_GX_limit_note':'G_X is the stiffness/transversality generator; H_X is the correct cutoff-limit object.',
             'cutoffs':cutoffs,'persistent_positive_labels':len(persistent),
             'weyl_c_input':args.weyl_c,'tail_after_j':args.tail_after_j,
             'weyl_tail_majorant':tail,'weyl_majorant_is_conditional_on_proved_bound':True,
             'pairwise':pair_rows}
    Path(str(prefix)+'_VERDICT.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')

    print('\nFinite-head diagnostics:')
    for r in pair_rows:
        print(f"  {r['lower_cutoff']:>9d}->{r['upper_cutoff']:<9d} labels={r['common_labels']:<4d} "
              f"dE_rms={r['energy_rms_drift']:.3e}  ||dK||_1(head)={r['K_head_trace_norm']:.3e}")
    print('\nANALYTIC RESULT A : fixed-mode convergence => strong-resolvent H_inf [PROVED]')
    print('ANALYTIC RESULT B : + uniform inverse-square tail => trace-norm K_inf [PROVED]')
    print('T_MODE             : still requires the all-L v438 scalar theorem')
    print('T_TAIL             : still requires a uniform tail theorem')
    if args.weyl_c>0: print(f'conditional Weyl tail majorant after j={args.tail_after_j}: {tail:.6e}')
    print('='*180)
    if args.strict and not pair_rows: return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
