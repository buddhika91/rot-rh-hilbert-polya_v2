# ROT-RH v473 — flat-bump complex endpoint saddle / nonattained migration

For

`K_L(lambda)=int p(x)e^(lambda Lx)dx/x`, `Re lambda>0`,

put `z=lambda L`, `t=1-x`.  The exact saddle equation is

`z t^3+2t-2=0`.

Its asymptotic solution is

`t
 =2^(1/3)z^(-1/3)
 -2^(2/3)z^(-2/3)/3
 +2*2^(1/3)z^(-4/3)/81
 +O(z^(-5/3))`.

The saddle exponent is

`Psi(z)
 =z
 -3*2^(-2/3)z^(2/3)
 +2^(2/3)z^(1/3)
 -2/3
 +O(z^(-1/3))`.

Hence the standard steepest-descent form is

`K_L(lambda)
 ~ const * z^(-2/3) exp(Psi(z))`.

For `lambda=a+i omega` this gives

`log|K|
 =aL
 -3*2^(-2/3)L^(2/3)Re(lambda^(2/3))
 +O(L^(1/3)|lambda|^(1/3)+log|lambda L|)`.

For `|omega|>>a` the leading frequency penalty is proportional to

`-|omega|^(2/3)L^(2/3)`.

At the same time

`partial_E log K
 =-iL[1-2^(1/3)(lambda L)^(-1/3)+O((lambda L)^(-2/3))]`

for `omega=Gamma-E`, so the real-energy carrier slope is `L(1+o(1))`.

And

`partial_L Im log K
 =omega+O(L^(-1/3)|lambda|^(2/3))`.

Thus an isolated active high-ordinate resonance still carries its own escaping
ordinate frequency.

Finally, if two fixed zeros satisfy `a_j>a_k`, their logarithmic magnitude
difference is

`(a_j-a_k)L+O(L^(2/3))`,

so the larger real part eventually wins.  Compact smoothness gives
super-polynomial Fourier decay at fixed L, hence a finite instantaneous winner.
If `sup a_j` is not attained, all instantaneous winners escape every finite
ordinate set.

**Verdict:** EXACT_FLAT_BUMP_SADDLE_AND_NONATTAINED_MIGRATION_REDUCTION_PASS

The bump therefore changes the vertical penalty from the old Gamma/Stirling
geometry to a `2/3` endpoint-saddle geometry, but the nonattained support
migration itself survives.

The remaining case is still genuinely collective.
