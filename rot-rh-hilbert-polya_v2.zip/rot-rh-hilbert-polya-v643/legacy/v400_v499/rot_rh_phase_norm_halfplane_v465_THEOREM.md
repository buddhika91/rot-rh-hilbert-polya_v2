# ROT-RH v465 — phase-functional norm mismatch / half-plane capture theorem

## A. Exact bump-phase dual norm

For

`||u||_beta=sup_(s<=m<=D)(s/m)^beta |A_u(m)|`

and any decreasing nonnegative `b_m`,

`||L_b||_dual
 = (D/s)^beta b_D
   + sum_(m=s)^(D-1)(m/s)^beta(b_m-b_(m+1))`.

The equality is exact, not only an upper bound.

For the bump phase `b_L(n)=p(log n/L)`:

* `beta=0`: `||L_b||=b_L(s)<=1`;
* every `beta>0`: taking `D=floor(exp(alpha L))`, `0<alpha<1`, gives

  `||L_b|| >= p(alpha) exp(alpha beta L)/s^beta`

  asymptotically.

Therefore the full bump phase functional is not uniformly continuous on
v402's `beta=2` weighted-prefix geometry.

So `Qjet=3.5508595316907754e-01<1` does **not** by itself imply a bounded local phase-factor
perturbation.

## B. Correct half-integer target

Let `epsilon_L` be the normalized regular phase shift modulo integer winding.

The collision plateaus are `Z+epsilon_L`; secular labels are `Z+1/2`.

Define

`d_L=dist(epsilon_L,Z+1/2)`.

Then v462 gives

`|u_L| <= m*2(1+sqrt(pi))/(pi d_L)`,

and hence

`|E(L)-gamma|
 <= m*2(1+sqrt(pi))/(pi L d_L)`.

A constant positive `d_L` gives the usual `O(1/L)` capture, but the weaker
condition

`L d_L -> infinity`

already suffices.

If `d_L>=c L^-alpha` with `alpha<1`, then

`|E(L)-gamma|=O(L^(alpha-1))`.

## C. Half-plane form

Write the regular factor phase as

`R_L/|R_L|=exp(i pi epsilon_L)`.

The bad half-integer set is exactly

`Re R_L=0`.

If

`|Re R_L|/|R_L| >= h_L>0`,

then

`d_L >= asin(h_L)/pi`

and

`|u_L| <= 2m(1+sqrt(pi))/asin(h_L)`.

Thus the true relative target is **avoid the imaginary axis**, not remain in a
disk around `+1`.

v464's disk condition is recovered from

`|R_L-1|<=eta<1`

because then `asin(h)>=acos(eta)`.

## D. Norm-design consequence

The desired Banach geometry must simultaneously make

1. the bump phase observable continuous, and
2. the regular `R^7` transfer contractive.

The v402 `beta=2` geometry has property 2 but not property 1.

The ordinary unweighted phase-prefix geometry has property 1, but the full
complex-prefix contraction route was already rejected and motivated the
scale-covariant v323 program.

Therefore the next serious theorem should target one of:

* the real/arithmetic prefix subspace;
* a bounded cancellation-preserving norm;
* a collision-subtracted **relative** phase functional with a bounded beta=2
  dual norm;
* an independent operator/index theorem forcing half-plane avoidance.

This is an exact obstruction/reduction, not an RH proof.
