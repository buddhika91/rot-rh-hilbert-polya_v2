# ROT-RH v464 — local argument-principle midpoint / Rouché disk bridge

## 1. Exact topological midpoint

After multiplicity-safe recombination, an isolated multiplicity-`m` local
characteristic has the form

`J_ref(z)=(z-rho)^m G_ref(z)`,

with `G_ref` holomorphic and nonzero near `rho`.

Across an upper semicircular indentation around `rho`, the unwrapped argument
of `(z-rho)^m` changes by `-m*pi`, while the regular factor contributes `o(1)`.

Hence the one-sided counting values differ by exactly `m`.

With the standard symmetric/half-weight convention,

`N_sym(rho)=N_-+m/2`.

This is topological and multiplicity-safe.

## 2. Finite-L regular-factor disk theorem

Let

`R_L = G_L/G_ref`.

If on the eventual shrinking branch tube

`|R_L-1|<=eta<1`,

then the disk `|z-1|<=eta` excludes zero and

`|arg R_L|<=asin(eta)<pi/2`.

Therefore the v463 normalized midpoint error satisfies

`|epsilon_L|<=asin(eta)/pi<1/2`.

So the exact half-index margin survives.

## 3. Capture bound

v463 then gives

`|u_j(L)| <= 2m(1+sqrt(pi))/acos(eta)`,

where

`u_j(L)=(gamma-E_j(L))L`.

Thus

`|E_j(L)-gamma|
 <= 2m(1+sqrt(pi))/[acos(eta)L]`.

No root derivative or no-fold estimate is needed for this implication.

## 4. Conditional v402 numerics

v402 proves the coefficient-space contraction constant

`Qjet=3.5508595316907754e-01`.

If — and only if — a separate embedding theorem transferred this directly to

`|G_L/G_ref-1|<=Qjet`,

then

`|epsilon|<=1.1554840190101018e-01`

and

`|u|<=4.5909522764127937e+00 m`.

The fixed-prefix packet factor is

`rhojet=2.1672726633854830e-05`.

If it transferred directly to the factor ratio, then

`|epsilon|<=6.8986431486547968e-06`

and

`|u|<=3.5300465839895501e+00 m`.

These are illustrations, NOT proven consequences of v402.

## 5. Why argument principle alone does not close the finite-L theorem

The topological midpoint is exact, but the finite-L relative factor is an
arithmetic object.

The earlier explicit-formula line shows that off-critical poles create
`exp[(beta-1/2)L]` forcing.  In particular, a blanket fixed-E bounded-forcing
theorem is RH-equivalent in the classical explicit-formula framework.

So the honest remaining theorem is not

`G_L/G_ref -> 1 automatically`.

It is the branch-local relative estimate

`sup_tube |G_L/G_ref-1| <= eta_k < 1`.

## 6. Recursive localization

The regular R7 packet transfer is already contractive in v402's beta-2
factorial four-jet geometry.  The missing steps are:

1. build an exact local determinant/regular-factor observable from that
   coefficient geometry;
2. prove its R7 contribution remains inside a strict relative disk;
3. prove the finite G7 regular head stays in the same disk after the principal
   collision has been recombined and removed.

The third item is the genuinely RH-strength signed-head frontier identified
by the earlier v384/v416 line unless an independent operator principle supplies
the relative disk estimate.

v464 is an exact reduction, not an RH proof.
