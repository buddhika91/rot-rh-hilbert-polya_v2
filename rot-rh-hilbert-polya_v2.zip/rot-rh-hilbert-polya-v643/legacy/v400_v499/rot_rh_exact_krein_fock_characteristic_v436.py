#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v436 — EXACT KREIN / FOCK REALIZATION OF THE CANONICAL RIESZ CHARACTERISTIC
==================================================================================

Purpose
-------
v435 canonically fixed the scalar off-shell arithmetic function

    Q_L(z)
      = int_a^L k_L(u) e^(-u/2) e^(-izu) dDelta_psi(u),

    k_L(u)=(1-u/L)/u,
    a=log 2,

and

    chi_L(z)=exp(Q_L(z)-Q_L(-z)).

v434 showed that roots and root-slopes alone cannot determine this function.
v435 removed that ambiguity directly from the prime/PNT arithmetic.

v436 now gives an EXACT energy-independent operator realization of Q_L and chi_L.

Common one-particle Hilbert/Krein space
---------------------------------------
Use the fixed, cutoff-independent space

    K
      = l2(prime powers)
        direct_sum
        L2([log2,infinity), du).

Let U be multiplication by logarithmic coordinate:

    U e_n = log(n) e_n

on the discrete prime-power channel and

    (Uf)(u)=u f(u)

on the continuum channel.

Let the fundamental symmetry be

    J = +I_discrete direct_sum -I_continuum.

Thus (K,J) is a Krein space while K retains its ordinary positive Hilbert norm.

For each cutoff L define the cutoff vector psi_L by

discrete:
    |psi_L(n)|^2
      = 1_(log n<L)
        k_L(log n)
        Lambda(n) n^(-1/2),

continuum:
    |psi_L(u)|^2
      = 1_(a<=u<L)
        k_L(u) e^(u/2).

All these weights are nonnegative because k_L>=0 on [a,L].

Then EXACTLY

    Q_L(z)
      = <psi_L, J exp(-izU) psi_L>_K.

No roots, zero ordinates, Xi values, or spectral fitting enter this identity.

Doubled realization of chi
---------------------------
On

    K2 = K direct_sum K

define

    A = U direct_sum (-U),
    J2 = J direct_sum (-J),
    Psi_L = psi_L direct_sum psi_L.

Then

    <Psi_L, J2 exp(-izA) Psi_L>
       = Q_L(z)-Q_L(-z),

and therefore

    chi_L(z)
      = exp(
          <Psi_L, J2 exp(-izA) Psi_L>
        ).

Bosonic-Fock matrix element
---------------------------
Let epsilon(f) be the unnormalised exponential vector and Gamma(T) the bosonic
second quantization.  Since

    <epsilon(f), Gamma(T) epsilon(g)>
      = exp(<f,Tg>),

we have the exact Hilbert-Fock realization

    chi_L(z)
      = <epsilon(Psi_L),
          Gamma(exp(-izA))
          epsilon(J2 Psi_L)>.

The generator A is energy-independent.  Cutoff dependence occurs only in the
canonical arithmetic coupling vector Psi_L.

Why positive Hilbert norm estimates are insufficient
-----------------------------------------------------
The ordinary Hilbert norm is

    ||psi_L||^2 = |mu_L|([a,L]),

the total variation of the centered signed Riesz measure.

Because the discrete Mangoldt channel and negative PNT continuum are mutually
singular,

    TV_L
      = sum_(n<e^L)
          Lambda(n)/log(n) n^(-1/2)(1-log n/L)
        + int_a^L
          [(1-u/L)/u] e^(u/2) du.

The smooth term has exact form

    M_L
      = Ei(L/2)-Ei(a/2)
        -(2/L)[e^(L/2)-e^(a/2)]

and asymptotic

    M_L ~ 4 e^(L/2)/L^2.

By the PNT the discrete positive mass has the same leading size, so

    TV_L ~ 8 sqrt(X)/(log X)^2.

Hence the positive Hilbert norm diverges:

    ||psi_L|| ~ sqrt(8) X^(1/4)/log X.

For the doubled Fock vectors the generic Cauchy-Schwarz envelope is

    ||epsilon(Psi_L)|| ||epsilon(J2Psi_L)||
      = exp(2 TV_L),

while for real E the exact arithmetic characteristic has

    |chi_L(E)|=1.

Thus a positive-Hilbert norm estimate loses precisely the centered arithmetic
cancellation and cannot yield the desired uniform cutoff bound.

Interpretation
--------------
This is consistent with the earlier v273 failure of simple global
Schur/Herglotz positivity: the canonical arithmetic realization is naturally
INDEFINITE.  The next theorem must control the DYADIC CHANGE of the Krein
matrix element / coupling vector while preserving J-cancellation, rather than
take absolute Hilbert norms.

What v436 does
--------------
1. Symbolically proves the Krein and doubled characteristic identities.
2. Rebuilds the common-space prime/PNT coupling vector from zero-free arithmetic.
3. Reconstructs v435 Q_L(E) independently as a J-matrix element.
4. Reconstructs chi_L(E) from the doubled Krein exponent.
5. Computes exact total-variation/Hilbert norms for all reused cutoffs.
6. Compares TV_L with 8 sqrt(X)/(log X)^2.
7. Quantifies the positive-Hilbert/Fock envelope blow-up.
8. Writes the next certificate for a signed dyadic Krein-transfer theorem.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO new root solves.
NO larger cutoff than v435.
Finite reconstruction is identity validation, not a proof of RH.

Version: 436
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 436
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def call_trig_sum(
    base,
    energies: np.ndarray,
    logs: np.ndarray,
    weights: np.ndarray,
    trig: str,
    *,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}

    try:
        return np.asarray(
            fn(energies, logs, weights, trig, **kwargs),
            float,
        )
    except TypeError:
        return np.asarray(
            fn(energies, logs, weights, trig),
            float,
        )


def support_count(logs: np.ndarray, L: float) -> int:
    return int(
        np.searchsorted(
            logs,
            float(L)-1.0e-14,
            side="left",
        )
    )


# -----------------------------------------------------------------------------
# Symbolic theorem
# -----------------------------------------------------------------------------

def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    Qp, Qm = sp.symbols("Qp Qm")
    krein_doubled = sp.simplify(Qp-Qm)
    chi = sp.exp(krein_doubled)

    TV = sp.symbols("TV", positive=True, real=True)
    psi2 = TV
    Psi2 = 2*TV

    # ||epsilon(Psi)|| = exp(||Psi||^2/2), same for J2 Psi.
    fock_product = sp.simplify(
        sp.exp(Psi2/2)*sp.exp(Psi2/2)
    )

    return {
        "one_particle_identity": (
            "Q_L(z)=<psi_L,J exp(-izU) psi_L>"
        ),
        "doubled_identity": (
            "<Psi_L,J2 exp(-izA)Psi_L>=Q_L(z)-Q_L(-z)"
        ),
        "chi_identity": (
            "chi_L(z)=exp(<Psi_L,J2 exp(-izA)Psi_L>)"
        ),
        "fock_identity": (
            "chi_L(z)=<epsilon(Psi_L),Gamma(exp(-izA))"
            "epsilon(J2Psi_L)>"
        ),
        "psi_norm_squared": str(psi2),
        "doubled_norm_squared": str(Psi2),
        "fock_CS_envelope": str(fock_product),
        "pass": bool(
            krein_doubled == Qp-Qm
            and chi == sp.exp(Qp-Qm)
            and fock_product == sp.exp(2*TV)
        ),
    }


# -----------------------------------------------------------------------------
# Arithmetic
# -----------------------------------------------------------------------------

def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)
    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    # Lambda/log n = 1/m.
    coeff = 1.0/exponents
    return primes, logs, exponents, coeff


def smooth_Q_integral(E: np.ndarray, L: float) -> np.ndarray:
    """
    int_a^L k_L(u)e^(u/2)e^(-iEu) du
    = int [(1-u/L)/u] exp[(1/2-iE)u] du.
    """
    from scipy.special import expi

    E = np.atleast_1d(np.asarray(E, float))
    alpha = 0.5-1j*E

    return (
        expi(alpha*L)
        - expi(alpha*LOG2)
        - (
            np.exp(alpha*L)
            - np.exp(alpha*LOG2)
        )/(L*alpha)
    )


def krein_Q(
    *,
    base,
    logs: np.ndarray,
    coeff: np.ndarray,
    X: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L = math.log(float(X))
    E = np.atleast_1d(np.asarray(E, float))

    if L <= LOG2 + 5e-15:
        return np.zeros(len(E), dtype=complex)

    k = support_count(logs, L)
    l = logs[:k]

    # |psi_atom|^2 = Lambda/log n * n^-1/2 (1-log n/L)
    atom_mass = (
        coeff[:k]
        * np.exp(-0.5*l)
        * (1.0-l/L)
    )

    real = call_trig_sum(
        base,
        E,
        l,
        atom_mass,
        "cos",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    sinv = call_trig_sum(
        base,
        E,
        l,
        atom_mass,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    discrete = real-1j*sinv

    continuum = smooth_Q_integral(E, L)

    # J=+ on discrete, - on continuum.
    return discrete-continuum


def total_variation(
    *,
    logs: np.ndarray,
    coeff: np.ndarray,
    X: int,
) -> Dict[str, float]:
    from scipy.special import expi

    L = math.log(float(X))
    if L <= LOG2 + 5e-15:
        return {
            "X": int(X),
            "L": L,
            "atom_mass": 0.0,
            "continuum_mass": 0.0,
            "TV": 0.0,
            "psi_norm": 0.0,
            "asymptotic_8sqrtX_L2": 0.0,
            "TV_over_asymptotic": float("nan"),
            "log_fock_CS_envelope": 0.0,
        }

    k = support_count(logs, L)
    l = logs[:k]
    atom_mass = float(
        np.sum(
            coeff[:k]
            * np.exp(-0.5*l)
            * (1.0-l/L)
        )
    )

    continuum_mass = float(
        np.real(
            expi(L/2.0)
            - expi(LOG2/2.0)
            - (2.0/L)
            * (
                math.exp(L/2.0)
                - math.exp(LOG2/2.0)
            )
        )
    )

    TV = atom_mass+continuum_mass
    asym = 8.0*math.sqrt(float(X))/(L*L)

    return {
        "X": int(X),
        "L": L,
        "atom_mass": atom_mass,
        "continuum_mass": continuum_mass,
        "TV": TV,
        "psi_norm": math.sqrt(max(TV, 0.0)),
        "asymptotic_8sqrtX_L2": asym,
        "TV_over_asymptotic": TV/asym if asym > 0 else float("nan"),
        # doubled Fock C-S product = exp(2 TV);
        # store the logarithm to avoid overflow.
        "log_fock_CS_envelope": 2.0*TV,
    }


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v435-points",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v435-summary",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_SUMMARY.json",
    )
    ap.add_argument(
        "--v273-summary",
        default="rot_rh_full_centered_schur_herglotz_v273_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--energy-chunk", type=int, default=6)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument(
        "--maximum-Q-absolute",
        type=float,
        default=2e-9,
    )
    ap.add_argument(
        "--maximum-chi-absolute",
        type=float,
        default=2e-9,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_krein_fock_characteristic_v436",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    v435 = load_json(args.v435_summary)
    v273 = load_json(args.v273_summary)

    v435_ok = bool(
        v435 is not None
        and v435.get("verdict")
        == "EXACT_CANONICAL_COMPLEX_RIESZ_SCALAR_CHARACTERISTIC_NORMALIZATION_PASS"
    )
    v273_failed = bool(
        v273 is not None
        and v273.get("mechanism")
        == "FULL_CENTERED_REGULARIZED_SCHUR_HERGLOTZ_FAILS_FINITE_AUDIT"
    )

    print("="*232)
    print("ROT-RH v436 — EXACT KREIN / FOCK REALIZATION OF CANONICAL RIESZ CHARACTERISTIC")
    print("="*232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new roots / larger cutoff                 : NONE")
    print("positive Hilbert envelope accepted proof  : NO")
    print("="*232)

    print("[1] Upstream")
    print(
        "v435 canonical scalar characteristic     :",
        v435_ok,
        None if v435 is None else v435.get("verdict"),
    )
    print(
        "v273 simple Herglotz finite audit failed :",
        v273_failed,
        None if v273 is None else v273.get("mechanism"),
    )

    print("\n[2] Exact Krein/Fock algebra")
    sym = symbolic_checks()
    print("symbolic realization pass                 :", sym.get("pass"))
    print("one-particle realization                 :", sym.get("one_particle_identity"))
    print("doubled realization                      :", sym.get("doubled_identity"))
    print("Fock realization                         :", sym.get("fock_identity"))
    if not sym.get("pass") and args.strict:
        return 2

    p = Path(args.v435_points)
    if not p.exists():
        raise FileNotFoundError(p)

    df = pd.read_csv(p)
    required = {
        "X0", "X1", "E_fixed",
        "Q_X0_real", "Q_X0_imag",
        "Q_X1_real", "Q_X1_imag",
        "chi_X0_real", "chi_X0_imag",
        "chi_X1_real", "chi_X1_imag",
    }
    missing = sorted(required-set(df.columns))
    if missing:
        raise KeyError(
            f"v435 points missing columns: {missing}"
        )

    cutoffs = sorted(
        set(df["X0"].astype(int).tolist())
        | set(df["X1"].astype(int).tolist())
    )
    max_X = max(cutoffs)
    base = importlib.import_module(args.v71_module)

    print("\n[3] Common-space arithmetic cache")
    t0 = time.time()
    primes, logs, exponents, coeff = build_cache(
        base,
        max_X,
    )
    print("maximum reused cutoff                    :", f"{max_X:,}")
    print("primes                                   :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    rows = []
    max_Q_abs = 0.0
    max_chi_abs = 0.0

    groups = list(
        df.groupby(["X0","X1"], sort=True)
    )
    bar = tqdm(
        total=len(groups),
        desc="Krein characteristic shells",
        unit="shell",
    )

    for (X0, X1), g in groups:
        X0 = int(X0)
        X1 = int(X1)
        gg = g.reset_index(drop=True)
        E = gg["E_fixed"].to_numpy(float)

        Q0 = krein_Q(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X0,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        Q1 = krein_Q(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X1,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )

        Q0_ref = (
            gg["Q_X0_real"].to_numpy(float)
            + 1j*gg["Q_X0_imag"].to_numpy(float)
        )
        Q1_ref = (
            gg["Q_X1_real"].to_numpy(float)
            + 1j*gg["Q_X1_imag"].to_numpy(float)
        )
        Qres = np.maximum(
            np.abs(Q0-Q0_ref),
            np.abs(Q1-Q1_ref),
        )
        max_Q_abs = max(
            max_Q_abs,
            float(np.max(Qres)),
        )

        # Doubled Krein exponent on the real axis.
        chi0 = np.exp(Q0-np.conjugate(Q0))
        chi1 = np.exp(Q1-np.conjugate(Q1))
        chi0_ref = (
            gg["chi_X0_real"].to_numpy(float)
            + 1j*gg["chi_X0_imag"].to_numpy(float)
        )
        chi1_ref = (
            gg["chi_X1_real"].to_numpy(float)
            + 1j*gg["chi_X1_imag"].to_numpy(float)
        )
        cres = np.maximum(
            np.abs(chi0-chi0_ref),
            np.abs(chi1-chi1_ref),
        )
        max_chi_abs = max(
            max_chi_abs,
            float(np.max(cres)),
        )

        for i in range(len(gg)):
            rows.append({
                "X0": X0,
                "X1": X1,
                "E_fixed": float(E[i]),
                "krein_Q_X0_real": float(np.real(Q0[i])),
                "krein_Q_X0_imag": float(np.imag(Q0[i])),
                "krein_Q_X1_real": float(np.real(Q1[i])),
                "krein_Q_X1_imag": float(np.imag(Q1[i])),
                "Q_absolute_residual": float(Qres[i]),
                "krein_chi_X0_real": float(np.real(chi0[i])),
                "krein_chi_X0_imag": float(np.imag(chi0[i])),
                "krein_chi_X1_real": float(np.real(chi1[i])),
                "krein_chi_X1_imag": float(np.imag(chi1[i])),
                "chi_absolute_residual": float(cres[i]),
                "chi_modulus_X0": float(np.abs(chi0[i])),
                "chi_modulus_X1": float(np.abs(chi1[i])),
            })
        bar.update(1)

    bar.close()
    out = pd.DataFrame(rows)

    norm_rows = [
        total_variation(
            logs=logs,
            coeff=coeff,
            X=X,
        )
        for X in cutoffs
    ]
    norm_df = pd.DataFrame(norm_rows)

    reconstruction_pass = bool(
        max_Q_abs <= args.maximum_Q_absolute
        and max_chi_abs <= args.maximum_chi_absolute
    )

    # Trend diagnostics only.
    if len(norm_df) >= 2:
        tv_growth_ratio = float(
            norm_df.iloc[-1]["TV"]
            / max(norm_df.iloc[0]["TV"], EPS)
        )
        norm_growth_ratio = float(
            norm_df.iloc[-1]["psi_norm"]
            / max(norm_df.iloc[0]["psi_norm"], EPS)
        )
    else:
        tv_growth_ratio = 1.0
        norm_growth_ratio = 1.0

    print("\n[4] Exact Krein reconstruction")
    print(
        "maximum |Q_Krein-Q_v435|                :",
        f"{max_Q_abs:.12e}",
    )
    print(
        "maximum |chi_Krein-chi_v435|            :",
        f"{max_chi_abs:.12e}",
    )
    print(
        "exact Krein reconstruction pass          :",
        reconstruction_pass,
    )

    print("\n[5] Positive-Hilbert norm growth")
    display_cols = [
        "X", "TV", "psi_norm",
        "asymptotic_8sqrtX_L2",
        "TV_over_asymptotic",
        "log_fock_CS_envelope",
    ]
    print(
        norm_df[display_cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )
    print(
        "TV growth first->last                    :",
        f"{tv_growth_ratio:.6f}x",
    )
    print(
        "||psi|| growth first->last               :",
        f"{norm_growth_ratio:.6f}x",
    )
    print(
        "real-axis exact |chi|                    : 1 by J-cancellation"
    )
    print(
        "generic positive-Hilbert/Fock envelope    : diverges with TV"
    )

    exact_pass = bool(
        sym.get("pass")
        and v435_ok
        and reconstruction_pass
    )

    verdict = (
        "EXACT_CANONICAL_KREIN_FOCK_CHARACTERISTIC_REALIZATION_PASS_POSITIVE_NORM_BOUND_NO_GO"
        if exact_pass
        else
        "CANONICAL_KREIN_FOCK_CHARACTERISTIC_REALIZATION_INCOMPLETE"
    )
    next_theorem = (
        "PROVE_SIGNED_DYADIC_KREIN_TRANSFER_BOUND_FOR_CANONICAL_COUPLING_UPDATE_WITHOUT_TOTAL_VARIATION_MAJORANT"
    )

    print("\n" + "="*232)
    print("VERDICT                                   :", verdict)
    print(
        "ENERGY-INDEPENDENT GENERATOR U/A          : CONSTRUCTED EXACTLY"
        if exact_pass else
        "ENERGY-INDEPENDENT GENERATOR U/A          : INCOMPLETE"
    )
    print(
        "CANONICAL chi OPERATOR MATRIX ELEMENT     : EXACT"
        if exact_pass else
        "CANONICAL chi OPERATOR MATRIX ELEMENT     : INCOMPLETE"
    )
    print(
        "POSITIVE HILBERT NORM ROUTE               : NO-GO / LOSES CENTERED CANCELLATION"
    )
    print(
        "INDEFINITE KREIN CANCELLATION             : REQUIRED"
    )
    print(
        "BOUND |J_complex|                         : NOT PROVED"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*232)

    prefix = Path(args.prefix)
    points_out = Path(str(prefix)+"_POINTS.csv.gz")
    norms_out = Path(str(prefix)+"_NORMS.csv")
    summary_out = Path(str(prefix)+"_SUMMARY.json")
    theorem_out = Path(str(prefix)+"_THEOREM.md")
    cert_out = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    out.to_csv(
        points_out,
        index=False,
        compression="gzip",
    )
    norm_df.to_csv(norms_out, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v435": False,
        },
        "upstream": {
            "v435_ok": v435_ok,
            "v273_simple_Herglotz_failed": v273_failed,
        },
        "symbolic": sym,
        "operator_realization": {
            "common_Hilbert_space": (
                "l2(prime powers) direct_sum L2([log2,infinity),du)"
            ),
            "U": "multiplication by log-coordinate",
            "J": "+I_discrete direct_sum -I_continuum",
            "psi_L": (
                "sqrt of positive discrete/continuum Riesz masses"
            ),
            "Q_identity": (
                "Q_L(z)=<psi_L,J exp(-izU)psi_L>"
            ),
            "doubled_generator": "A=U direct_sum (-U)",
            "doubled_symmetry": "J2=J direct_sum (-J)",
            "chi_identity": (
                "chi_L(z)=exp(<Psi_L,J2 exp(-izA)Psi_L>)"
            ),
            "fock_identity": sym.get("fock_identity"),
        },
        "reconstruction": {
            "maximum_Q_absolute_residual": max_Q_abs,
            "maximum_chi_absolute_residual": max_chi_abs,
            "pass": reconstruction_pass,
        },
        "positive_norm_no_go": {
            "TV_first_to_last_growth": tv_growth_ratio,
            "psi_norm_first_to_last_growth": norm_growth_ratio,
            "asymptotic": (
                "TV_L ~ 8 sqrt(X)/(log X)^2 under PNT"
            ),
            "fock_CS_log_envelope": "2 TV_L",
            "real_axis_exact_characteristic_modulus": 1.0,
            "interpretation": (
                "absolute positive Hilbert norms erase the discrete-minus-continuum "
                "centered cancellation and cannot provide the desired uniform bound"
            ),
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_out.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        r"""# ROT-RH v436 — exact canonical Krein/Fock realization

On the fixed common space

`K=l2(prime powers) direct_sum L2([log2,infinity),du)`

let `U` multiply by logarithmic coordinate and let

`J=+I_discrete direct_sum -I_continuum`.

For each cutoff `L`, define `psi_L` by the square roots of the positive Riesz
masses on the discrete Mangoldt channel and on the PNT continuum channel.

Then exactly

`Q_L(z)=<psi_L,J exp(-izU)psi_L>`.

On the doubled space, with

`A=U direct_sum (-U)`,
`J2=J direct_sum (-J)`,
`Psi_L=psi_L direct_sum psi_L`,

we obtain

`Q_L(z)-Q_L(-z)=<Psi_L,J2 exp(-izA)Psi_L>`

and hence

`chi_L(z)=exp(<Psi_L,J2 exp(-izA)Psi_L>)`.

Equivalently this is a bosonic exponential-vector matrix element.

The ordinary Hilbert norm is the total variation of the centered Riesz
measure:

`||psi_L||^2=TV_L`.

The smooth positive mass is asymptotic to

`4 sqrt(X)/(log X)^2`,

and the discrete Mangoldt mass has the same leading size by PNT, so

`TV_L ~ 8 sqrt(X)/(log X)^2`.

Therefore positive Hilbert norms diverge even though on the real axis the exact
Krein cancellation gives `|chi_L(E)|=1`.

The remaining bound must therefore preserve the indefinite discrete-minus-
continuum cancellation.  The next theorem is a signed dyadic Krein-transfer
estimate for the canonical cutoff coupling update, not an absolute total-
variation estimate.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_SIGNED_DYADIC_KREIN_TRANSFER_CERTIFICATE_V1",
        "exact_realization": {
            "proved": exact_pass,
            "Q": "Q_L(z)=<psi_L,J exp(-izU)psi_L>",
            "chi": (
                "chi_L(z)=exp(<Psi_L,J2 exp(-izA)Psi_L>)"
            ),
        },
        "required_next_claims": {
            "dyadic_signed_transfer": {
                "proved": False,
                "statement": (
                    "Bound the dyadic change of the canonical Krein matrix element "
                    "or its cutoff derivative uniformly in X while retaining J "
                    "cancellation; do not replace it by ||psi_L||^2."
                ),
            },
            "forcing_bridge": {
                "proved": False,
                "statement": (
                    "Express the v432 complex forcing J_X^C(E) exactly in terms of "
                    "the dyadic change/cutoff derivative of the Krein realization."
                ),
            },
            "uniform_bound": {
                "proved": False,
                "statement": (
                    "Derive sup_X |J_X^C(E)|<infinity from the signed Krein transfer "
                    "theorem without RH-equivalent prime-error input."
                ),
            },
        },
        "forbidden_shortcuts": [
            "total variation majorant",
            "ordinary Hilbert norm bound on psi_L",
            "generic Fock Cauchy-Schwarz bound",
            "simple full-centered Schur/Herglotz positivity",
            "assume bounded J_complex",
            "assume RH",
            "known zero ordinates",
            "Xi fitting",
        ],
        "consequence": (
            "signed Krein forcing bound + completed v432 analytic certificate "
            "would imply RH"
        ),
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_out)
    print(" ", norms_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
