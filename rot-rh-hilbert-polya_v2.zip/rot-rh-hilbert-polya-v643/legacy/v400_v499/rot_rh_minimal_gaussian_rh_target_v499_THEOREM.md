# ROT-RH v499 — minimal Gaussian RH target: uniform inverse-square trace

v498 reduces the Gaussian RH problem to one positive operator estimate:

`sup_(L>=L0) Tr(H_L^-2)<infinity`.

This is weaker than proving trace-norm cutoff convergence and does not require
first proving convergence of every fixed eigenvalue.

There are three clean sufficient routes.

## Route A — uniform Weyl lower bound

If

`E_k(L)>=c k/log(k+e)`

for all sufficiently large `k,L`, then

`E_k(L)^-2`
` <=c^-2 [log(k+e)/k]^2`

and the right side is summable.  Together with the finitely many low modes this
gives the required uniform trace bound.  This is exactly the theorem shape
already isolated in v223/v230.

## Route B — uniform displacement from the free Archimedean levels

v232 gives

`A_k>=2k/log(k+e)`

eventually.  If one proves the v235 target

`sup_(L,k)|E_k(L)-A_k|<=D<infinity`,

then eventually

`E_k(L)>=k/log(k+e)`,

which again gives a uniform inverse-square trace bound.

Thus, **for the Gaussian regulator**, the old v235 uniform displacement target
would not merely prove the high-mode trace tail: combined with v497-v498, it
would force RH.

## Route C — trace-norm Cauchy directly

If the Gaussian

`K_L=H_L^-2`

form a trace-norm Cauchy family, norm boundedness is automatic and v498 forces
RH.  Fixed-mode convergence and the Fredholm-Xi identity may then be proved
afterward for the stronger Hilbert-Pólya conclusion.

### New strategic ordering

The most economical Gaussian attack is now:

1. prove `sup_L Tr(H_L^-2)<infinity` zero-blind;
2. v497-v498 then force RH;
3. with the off-critical sector eliminated, prove fixed-mode Gaussian cutoff
   convergence using only critical-line collision geometry plus the v494 remote
   primitive;
4. prove the uniform Weyl/trace-tail theorem and trace-norm convergence;
5. establish regulator universality / Fredholm-Xi identity.

This avoids spending the hardest analysis on an off-critical sector that a
positive trace estimate would already rule out.

**Verdict:** `UNIFORM_GAUSSIAN_INVERSE_SQUARE_TRACE_IS_MINIMAL_RH_TARGET_PASS`.

What remains open is the actual zero-blind proof of the uniform trace bound.
Existing v223/v230/v235/v443 results provide exact conditional transfer
theorems and strong numerical evidence, but their all-scale premises have not
been proved analytically.
