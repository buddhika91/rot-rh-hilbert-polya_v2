#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v442 — LOG-BETA SOURCE / RG-STIFFNESS DUHAMEL REDUCTION
==============================================================

Purpose
-------
v441 showed that moving-energy compensation is weak in the H-coordinate.
That does not settle the moving-branch primitive-beta problem, because the
quantity needed for cutoff removal is

    B(L,E)=C0(L,E)/F'_L(E),

not H.

v425 supplies

    kappa(L,E)=1+partial_E B(L,E)/L

and on a quantized characteristic E_k(L),

    E_k'(L)=B_k(L)/L^2.

Exact log-beta transport
------------------------
Along the moving characteristic,

    dB_k/dL
      = partial_L B
        + E_k' partial_E B

      = partial_L B
        + B_k (kappa_k-1)/L.

Define logarithmic scale tau=log L and the FIXED-CUTOFF beta source

    S_k(L)
      := L partial_L B(L,E)|_(E=E_k(L)).

Then EXACTLY

    dB_k/dtau
      + (1-kappa_k) B_k
      = S_k.

Let

    Q_k(L)
      = int_(L0)^L kappa_k(s)/s ds.

The integrating factor is

    L exp(-Q_k(L)),

so

    d/dL [ L exp(-Q_k(L)) B_k(L) ]
      = exp(-Q_k(L)) S_k(L).

Therefore

    B_k(L)
      = exp(Q_k(L))/L
        [ L0 B_k(L0)
          + int_(L0)^L exp(-Q_k(s)) S_k(s) ds ].

Sufficient fixed-mode theorem
-----------------------------
If eventually

    |Q_k(L)| <= Q_*,

and the fixed-cutoff beta source is bounded in the appropriate
piecewise/distributional sense,

    |S_k(L)| <= M_k,

then

    B_k(L)=O_k(1).

Consequently

    Pi_k(L)=int B_k(s) ds = O_k(L),

and by v419

    E_k(infinity)-E_k(L)=O_k(1/L),

provided the ordered branch persists and v425 no-fold remains valid.

Prime jumps
-----------
C0, hence B, has arithmetic jump structure.  Numerically v442 therefore does
NOT differentiate through prime jumps.  Instead on each small v424
characteristic step `(La,Ea)->(Lb,Eb)` it uses the exact decomposition

    Delta B_moving
      = Delta B_fixed + Delta B_energy,

where

    Delta B_fixed
      = B(Lb,Ea)-B(La,Ea),

    Delta B_energy
      = B(Lb,Eb)-B(Lb,Ea).

The secant source

    S_sec
      = Delta B_fixed / Delta(log L)

is the natural finite-resolution version of `S=L partial_L B`.

The exact energy secant also defines

    kappa_sec
      = 1 + Delta B_energy/[Lb(Eb-Ea)],

when Eb != Ea, and should agree with the local v425 kappa as the characteristic
step becomes small.

Renormalized source
-------------------
Define

    Y_k(L)=L exp(-Q_k(L)) B_k(L).

The theorem above is

    Y_k'(L)=exp(-Q_k(L)) S_k(L).

v442 therefore also measures the exact characteristic secant

    R_sec
      = [Y(Lb)-Y(La)]/(Lb-La).

If `Q` is bounded and this renormalized source remains O(1), then directly

    Y=O(L),
    B=O(1),
    Pi=O(L).

What v442 tests
---------------
1. Reuses the v424 zero-free moving characteristic.
2. Reuses v425 Q_k and kappa on that same characteristic.
3. Rebuilds only B(Lb,Ea), the fixed-E comparison needed to separate source
   from energy response.  No new root solves.
4. Verifies the exact beta split.
5. Measures S_sec and the exact renormalized source secant R_sec.
6. Compares the exact energy-response secant kappa to v425 kappa.
7. Checks whether source magnitudes remain stable on holdout microsteps/shells.
8. Places source bounds beside:
       * max |Q_k|,
       * F'/L,
       * B,
       * Pi_k/L.
9. Writes the all-L certificate which, together with v425, would close
   fixed-mode cutoff independence.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta.
NO known zero ordinates.
NO RH.
NO new roots.
NO larger cutoff.
Finite source stability is evidence only.

Version: 442
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 442
EPS = 1e-300


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def expected(summary: Optional[dict], verdict: str) -> bool:
    return bool(summary is not None and summary.get("verdict") == verdict)


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L = sp.symbols("L", positive=True)
    B, BL, BE, kap = sp.symbols(
        "B BL BE kap", real=True
    )

    # E'=B/L^2, kappa=1+BE/L.
    moving = sp.simplify(
        L*(BL + (B/L**2)*BE)
    )
    target = sp.simplify(
        L*BL + (kap-1)*B
    )
    sub = sp.simplify(
        moving.subs(BE, L*(kap-1))
        - target
    )

    return {
        "log_beta_transport": (
            "dB/d(log L)=S+(kappa-1)B, "
            "S=L partial_L B"
        ),
        "damped_form": (
            "dB/d(log L)+(1-kappa)B=S"
        ),
        "integrating_factor": (
            "L exp(-Q), Q'=kappa/L"
        ),
        "duhamel": (
            "B(L)=e^Q/L [L0 B0 + int e^-Q S dL]"
        ),
        "sufficient_theorem": (
            "|Q| bounded + |S| bounded => B=O(1) "
            "=> Pi=O(L) => fixed-mode tail O(1/L)"
        ),
        "algebra_residual": str(sub),
        "pass": bool(sub == 0),
    }


def first_shell_starts(shells: pd.DataFrame) -> pd.DataFrame:
    if "shell_index" in shells.columns:
        idx = int(shells["shell_index"].min())
        first = shells[
            shells["shell_index"].astype(int) == idx
        ].copy()
    else:
        anchor = int(shells["anchor"].min())
        first = shells[
            shells["anchor"].astype(int) == anchor
        ].copy()

    return first.sort_values("root_index")


def make_nodes(
    *,
    track: pd.DataFrame,
    shells: pd.DataFrame,
    evaluator,
) -> pd.DataFrame:
    first = first_shell_starts(shells)
    X0 = int(first["anchor"].iloc[0])
    E0 = first["E_start"].to_numpy(float)
    ev0 = evaluator.eval(X0, E0)

    start_rows = []
    for j, rk in enumerate(
        first["root_index"].astype(int).tolist()
    ):
        start_rows.append({
            "cutoff": X0,
            "L": float(ev0.L),
            "root_index": int(rk),
            "E": float(E0[j]),
            "Fp": float(ev0.Fp[j]),
            "beta": float(ev0.beta[j]),
            "node_source": "v424_shell_start",
        })

    required = {
        "cutoff","L","root_index","E","Fp","beta",
    }
    missing = sorted(required-set(track.columns))
    if missing:
        raise KeyError(
            f"v424 track missing columns: {missing}"
        )

    tr = track[
        ["cutoff","L","root_index","E","Fp","beta"]
    ].copy()
    tr["node_source"] = "v424_track"

    nodes = pd.concat(
        [pd.DataFrame(start_rows), tr],
        ignore_index=True,
    )
    nodes["cutoff"] = nodes["cutoff"].astype(int)
    nodes["root_index"] = nodes["root_index"].astype(int)
    nodes = (
        nodes.sort_values(
            ["root_index","L","cutoff"]
        )
        .drop_duplicates(
            subset=["root_index","cutoff"],
            keep="last",
        )
        .reset_index(drop=True)
    )
    return nodes


def attach_v425(
    nodes: pd.DataFrame,
    rgtraj: pd.DataFrame,
    kappapoints: Optional[pd.DataFrame],
) -> pd.DataFrame:
    required_rg = {
        "cutoff","root_index",
        "rg_drift_cumulative",
    }
    if not required_rg.issubset(rgtraj.columns):
        raise KeyError(
            "v425 RG trajectory missing "
            f"{sorted(required_rg-set(rgtraj.columns))}"
        )

    keep = [
        c for c in [
            "cutoff","root_index",
            "rg_drift_cumulative",
            "rg_abs_mass_cumulative",
            "renorm_slope_ratio_actual",
            "rg_identity_residual",
            "kappa",
        ]
        if c in rgtraj.columns
    ]
    rg = (
        rgtraj[keep]
        .copy()
        .sort_values(["root_index","cutoff"])
        .drop_duplicates(
            subset=["root_index","cutoff"],
            keep="last",
        )
    )

    out = nodes.merge(
        rg,
        on=["cutoff","root_index"],
        how="left",
        validate="one_to_one",
        suffixes=("","_rg"),
    )

    if kappapoints is not None:
        kpkeep = [
            c for c in [
                "cutoff","root_index",
                "kappa",
                "dB_dE",
                "kappa_refinement_spread",
            ]
            if c in kappapoints.columns
        ]
        if {"cutoff","root_index"}.issubset(kpkeep):
            kp = (
                kappapoints[kpkeep]
                .copy()
                .sort_values(
                    ["root_index","cutoff"]
                )
                .drop_duplicates(
                    subset=["root_index","cutoff"],
                    keep="last",
                )
            )
            out = out.merge(
                kp,
                on=["cutoff","root_index"],
                how="left",
                validate="one_to_one",
                suffixes=("","_kp"),
            )
            if "kappa_kp" in out.columns:
                if "kappa" not in out.columns:
                    out["kappa"] = out["kappa_kp"]
                else:
                    out["kappa"] = out["kappa"].fillna(
                        out["kappa_kp"]
                    )

    return out


def shell_index_for_L(
    shells: pd.DataFrame,
    Lmid: float,
    root_index: int,
):
    sh = shells[
        shells["root_index"].astype(int)
        == int(root_index)
    ].copy()
    for _, r in sh.iterrows():
        La = math.log(float(int(r["anchor"])))
        Lb = math.log(
            float(int(r["endpoint_cutoff"]))
        )
        if La-1e-12 <= Lmid <= Lb+1e-12:
            return (
                str(r.get("set","unknown")),
                int(r.get("shell_index",-1)),
                int(r["anchor"]),
                int(r["endpoint_cutoff"]),
            )
    return ("unknown",-1,-1,-1)


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v424-track",
        default="rot_rh_cesaro_mean_primitive_beta_v424_TRACK.csv",
    )
    ap.add_argument(
        "--v424-shells",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SHELLS.csv",
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )

    ap.add_argument(
        "--v425-kappa-points",
        default="rot_rh_renormalized_stiffness_rg_v425_KAPPA_POINTS.csv",
    )
    ap.add_argument(
        "--v425-rg-trajectory",
        default="rot_rh_renormalized_stiffness_rg_v425_RG_TRAJECTORY.csv",
    )
    ap.add_argument(
        "--v425-rg-shells",
        default="rot_rh_renormalized_stiffness_rg_v425_RG_SHELLS.csv",
    )
    ap.add_argument(
        "--v425-summary",
        default="rot_rh_renormalized_stiffness_rg_v425_SUMMARY.json",
    )

    ap.add_argument(
        "--v440-summary",
        default="rot_rh_fixed_tube_primitive_rh_equivalence_v440_SUMMARY.json",
    )
    ap.add_argument(
        "--v441-summary",
        default="rot_rh_moving_characteristic_compensation_v441_SUMMARY.json",
    )

    ap.add_argument(
        "--v424-module",
        default="rot_rh_cesaro_mean_primitive_beta_v424",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )

    ap.add_argument(
        "--development-shells",
        type=int,
        default=1,
    )
    ap.add_argument(
        "--source-cap-safety",
        type=float,
        default=1.75,
    )
    ap.add_argument(
        "--renorm-source-cap-safety",
        type=float,
        default=1.75,
    )
    ap.add_argument(
        "--maximum-beta-split-absolute",
        type=float,
        default=5e-11,
    )
    ap.add_argument(
        "--maximum-kappa-secant-absolute",
        type=float,
        default=0.20,
        help=(
            "Finite derivative diagnostic: max |kappa_secant-kappa_endpoint|. "
            "Not an analytic gate."
        ),
    )
    ap.add_argument(
        "--maximum-rg-Q-absolute",
        type=float,
        default=0.10,
        help="Finite diagnostic only.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_logbeta_source_stiffness_damping_v442",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()

    if args.development_shells < 1:
        raise ValueError(
            "--development-shells must be >=1"
        )
    if args.source_cap_safety <= 1:
        raise ValueError(
            "--source-cap-safety must be >1"
        )
    if args.renorm_source_cap_safety <= 1:
        raise ValueError(
            "--renorm-source-cap-safety must be >1"
        )

    started = time.time()

    s424 = load_json(args.v424_summary)
    s425 = load_json(args.v425_summary)
    s440 = load_json(args.v440_summary)
    s441 = load_json(args.v441_summary)

    ok424 = expected(
        s424,
        "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS",
    )
    ok425 = expected(
        s425,
        "RENORMALIZED_STIFFNESS_RG_PROSPECTIVE_NOFOLD_PASS",
    )
    ok440 = expected(
        s440,
        "EXACT_FIXED_TUBE_SINE_PRIMITIVE_RH_EQUIVALENCE_REDUCTION_PASS_MOVING_BRANCH_ROUTE_REQUIRED_FOR_INTERMEDIATE_CUTOFF_THEOREM",
    )
    ok441 = expected(
        s441,
        "EXACT_MOVING_CHARACTERISTIC_COMPENSATION_PRIMITIVE_BETA_BRIDGE_PASS",
    )

    print("="*238)
    print("ROT-RH v442 — LOG-BETA SOURCE / RG-STIFFNESS DUHAMEL REDUCTION")
    print("="*238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new roots                                 : NONE")
    print("larger cutoff                             : NONE")
    print("finite source stability accepted as proof : NO")
    print("="*238)

    print("[1] Upstream")
    print(
        "v424 moving primitive-beta               :",
        ok424,
        None if s424 is None else s424.get("verdict"),
    )
    print(
        "v425 signed RG/no-fold                   :",
        ok425,
        None if s425 is None else s425.get("verdict"),
    )
    print(
        "v440 fixed-E route classified RH-core    :",
        ok440,
        None if s440 is None else s440.get("verdict"),
    )
    print(
        "v441 H-coordinate compensation bridge    :",
        ok441,
        None if s441 is None else s441.get("verdict"),
    )

    sym = symbolic_checks()
    print("\n[2] Exact log-beta theorem")
    print(
        "symbolic transport pass                  :",
        sym.get("pass"),
    )
    print(
        "transport                                :",
        sym.get("damped_form"),
    )
    print(
        "integrating factor                       :",
        sym.get("integrating_factor"),
    )
    print(
        "Duhamel formula                          :",
        sym.get("duhamel"),
    )
    print(
        "sufficient theorem                       :",
        sym.get("sufficient_theorem"),
    )

    # ------------------------------------------------------------------
    # Load data/modules.
    # ------------------------------------------------------------------
    track = pd.read_csv(args.v424_track)
    shells = pd.read_csv(args.v424_shells)
    rgtraj = pd.read_csv(args.v425_rg_trajectory)

    kppath = Path(args.v425_kappa_points)
    kappapoints = (
        pd.read_csv(kppath)
        if kppath.exists()
        else None
    )

    v424 = importlib.import_module(
        args.v424_module
    )
    base = importlib.import_module(
        args.v71_module
    )

    max_X = int(
        max(
            track["cutoff"].astype(int).max(),
            shells["endpoint_cutoff"]
            .astype(int).max(),
        )
    )

    print("\n[3] Reused zero-free characteristic")
    print(
        "maximum reused cutoff                    :",
        f"{max_X:,}",
    )
    print(
        "modes                                    :",
        track["root_index"].nunique(),
    )

    t0 = time.time()
    primes = base.sieve_primes(max_X)
    table = v424.build_cached_prime_powers(
        base, primes, max_X
    )
    evaluator = v424.ArithmeticEvaluator(
        base, table
    )
    print(
        "prime-power terms                        :",
        f"{len(table.logs):,}",
    )
    print(
        "cache build seconds                      :",
        f"{time.time()-t0:.3f}",
    )

    nodes = make_nodes(
        track=track,
        shells=shells,
        evaluator=evaluator,
    )
    nodes = attach_v425(
        nodes,
        rgtraj,
        kappapoints,
    )

    if nodes["rg_drift_cumulative"].isna().any():
        missing = int(
            nodes["rg_drift_cumulative"]
            .isna().sum()
        )
        raise RuntimeError(
            f"{missing} characteristic nodes lack v425 cumulative Q"
        )

    nodes["Q"] = nodes[
        "rg_drift_cumulative"
    ].astype(float)
    nodes["Y"] = (
        nodes["L"].to_numpy(float)
        * np.exp(-nodes["Q"].to_numpy(float))
        * nodes["beta"].to_numpy(float)
    )
    nodes["slope_over_L"] = (
        nodes["Fp"].to_numpy(float)
        / nodes["L"].to_numpy(float)
    )

    # ------------------------------------------------------------------
    # Microstep exact beta split.
    # ------------------------------------------------------------------
    step_rows = []
    max_split_abs = 0.0
    kappa_diffs = []

    roots = sorted(
        nodes["root_index"].unique().tolist()
    )
    total_steps = sum(
        max(
            len(
                nodes[
                    nodes["root_index"] == rk
                ]
            )-1,
            0,
        )
        for rk in roots
    )

    bar = tqdm(
        total=total_steps,
        desc="log-beta source microsteps",
        unit="step",
    )

    for rk in roots:
        g = (
            nodes[
                nodes["root_index"] == rk
            ]
            .sort_values("L")
            .reset_index(drop=True)
        )

        for i in range(len(g)-1):
            a = g.iloc[i]
            b = g.iloc[i+1]

            Xa = int(a["cutoff"])
            Xb = int(b["cutoff"])
            La = float(a["L"])
            Lb = float(b["L"])
            Ea = float(a["E"])
            Eb = float(b["E"])
            Ba = float(a["beta"])
            Bb = float(b["beta"])
            Qa = float(a["Q"])
            Qb = float(b["Q"])

            if not (Lb > La > 0):
                bar.update(1)
                continue

            # Fixed-E comparison at the new cutoff.
            ev_fixed = evaluator.eval(
                Xb,
                np.array([Ea], float),
            )
            B_fixed_end = float(
                ev_fixed.beta[0]
            )

            dB_fixed = B_fixed_end-Ba
            dB_energy = Bb-B_fixed_end
            dB_moving = Bb-Ba
            split_abs = abs(
                dB_moving
                - dB_fixed
                - dB_energy
            )
            max_split_abs = max(
                max_split_abs,
                split_abs,
            )

            dtau = math.log(Lb/La)
            dL = Lb-La

            source_sec = (
                dB_fixed/dtau
                if dtau > 0
                else float("nan")
            )
            energy_rate = (
                dB_energy/dtau
                if dtau > 0
                else float("nan")
            )
            moving_rate = (
                dB_moving/dtau
                if dtau > 0
                else float("nan")
            )

            dE = Eb-Ea

            if abs(dE) > 1e-15:
                kappa_sec = (
                    1.0
                    + dB_energy/(Lb*dE)
                )
            else:
                kappa_sec = float("nan")

            kappa_end = (
                float(b["kappa"])
                if "kappa" in b.index
                and pd.notna(b["kappa"])
                else float("nan")
            )
            if (
                math.isfinite(kappa_sec)
                and math.isfinite(kappa_end)
            ):
                kappa_diffs.append(
                    abs(kappa_sec-kappa_end)
                )

            # Exact effective B average from the root-flow integral:
            # dE = int B/L^2 dL.
            denom_flow = (
                1.0/La - 1.0/Lb
            )
            beta_flow_effective = (
                dE/denom_flow
                if abs(denom_flow) > EPS
                else float("nan")
            )

            effective_energy_damping = (
                -energy_rate
                / beta_flow_effective
                if math.isfinite(
                    beta_flow_effective
                )
                and abs(beta_flow_effective) > 1e-12
                else float("nan")
            )

            # Exact B^2 work of the fixed/source and energy legs.
            source_work = 0.5*(
                B_fixed_end**2-Ba**2
            )
            energy_work = 0.5*(
                Bb**2-B_fixed_end**2
            )
            moving_work = 0.5*(
                Bb**2-Ba**2
            )

            Ya = float(a["Y"])
            Yb = float(b["Y"])
            renorm_source_sec = (
                (Yb-Ya)/dL
                if dL > 0
                else float("nan")
            )

            Lmid = 0.5*(La+Lb)
            (
                setname,
                shell_index,
                shell_anchor,
                shell_endpoint,
            ) = shell_index_for_L(
                shells,
                Lmid,
                int(rk),
            )

            step_rows.append({
                "set": setname,
                "shell_index": shell_index,
                "shell_anchor": shell_anchor,
                "shell_endpoint": shell_endpoint,
                "root_index": int(rk),
                "cutoff_start": Xa,
                "cutoff_end": Xb,
                "L_start": La,
                "L_end": Lb,
                "delta_log_L": dtau,
                "E_start": Ea,
                "E_end": Eb,
                "delta_E": dE,
                "B_start": Ba,
                "B_fixed_end_at_Estart": B_fixed_end,
                "B_moving_end": Bb,
                "delta_B_fixed": dB_fixed,
                "delta_B_energy": dB_energy,
                "delta_B_moving": dB_moving,
                "beta_split_absolute_residual": split_abs,
                "fixed_source_log_secant": source_sec,
                "energy_response_log_rate": energy_rate,
                "moving_beta_log_rate": moving_rate,
                "kappa_secant_energy": kappa_sec,
                "kappa_endpoint_v425": kappa_end,
                "kappa_secant_minus_endpoint": (
                    kappa_sec-kappa_end
                    if math.isfinite(kappa_sec)
                    and math.isfinite(kappa_end)
                    else float("nan")
                ),
                "beta_flow_effective": beta_flow_effective,
                "effective_energy_damping_coeff": (
                    effective_energy_damping
                ),
                "source_B2_work": source_work,
                "energy_B2_work": energy_work,
                "moving_B2_work": moving_work,
                "energy_is_damping": bool(
                    energy_work < 0
                ),
                "Q_start": Qa,
                "Q_end": Qb,
                "Y_start": Ya,
                "Y_end": Yb,
                "renormalized_source_L_secant": (
                    renorm_source_sec
                ),
                "slope_over_L_start": float(
                    a["slope_over_L"]
                ),
                "slope_over_L_end": float(
                    b["slope_over_L"]
                ),
            })

            bar.update(1)

    bar.close()
    steps = pd.DataFrame(step_rows)

    max_kappa_diff = (
        float(np.max(kappa_diffs))
        if kappa_diffs
        else float("nan")
    )

    exact_split_pass = bool(
        max_split_abs
        <= args.maximum_beta_split_absolute
    )

    print("\n[4] Exact beta-source decomposition")
    print(
        "maximum beta split absolute residual      :",
        f"{max_split_abs:.12e}",
    )
    print(
        "exact beta split pass                     :",
        exact_split_pass,
    )
    print(
        "maximum |kappa_secant-kappa_endpoint|     :",
        (
            f"{max_kappa_diff:.12e}"
            if math.isfinite(max_kappa_diff)
            else "N/A"
        ),
    )
    print(
        "kappa secant finite diagnostic pass       :",
        (
            bool(
                max_kappa_diff
                <= args.maximum_kappa_secant_absolute
            )
            if math.isfinite(max_kappa_diff)
            else False
        ),
    )

    # ------------------------------------------------------------------
    # Duhamel / source stability diagnostics.
    # ------------------------------------------------------------------
    shell_rows = []

    for key, g in steps.groupby(
        [
            "set","shell_index",
            "shell_anchor","shell_endpoint",
        ],
        sort=True,
    ):
        setname, si, X0, X1 = key

        shell_rows.append({
            "set": str(setname),
            "shell_index": int(si),
            "anchor": int(X0),
            "endpoint_cutoff": int(X1),
            "max_abs_fixed_source_log_secant": float(
                np.max(
                    np.abs(
                        g["fixed_source_log_secant"]
                        .to_numpy(float)
                    )
                )
            ),
            "median_abs_fixed_source_log_secant": float(
                np.median(
                    np.abs(
                        g["fixed_source_log_secant"]
                        .to_numpy(float)
                    )
                )
            ),
            "max_abs_renorm_source_L_secant": float(
                np.max(
                    np.abs(
                        g["renormalized_source_L_secant"]
                        .to_numpy(float)
                    )
                )
            ),
            "median_abs_renorm_source_L_secant": float(
                np.median(
                    np.abs(
                        g["renormalized_source_L_secant"]
                        .to_numpy(float)
                    )
                )
            ),
            "energy_damping_fraction": float(
                np.mean(
                    g["energy_is_damping"]
                    .to_numpy(bool)
                )
            ),
            "median_effective_energy_damping_coeff": float(
                np.nanmedian(
                    g["effective_energy_damping_coeff"]
                    .to_numpy(float)
                )
            ),
            "max_abs_B": float(
                np.max(
                    np.abs(
                        np.concatenate([
                            g["B_start"].to_numpy(float),
                            g["B_moving_end"].to_numpy(float),
                        ])
                    )
                )
            ),
            "min_slope_over_L": float(
                min(
                    g["slope_over_L_start"].min(),
                    g["slope_over_L_end"].min(),
                )
            ),
            "max_abs_Q": float(
                np.max(
                    np.abs(
                        np.concatenate([
                            g["Q_start"].to_numpy(float),
                            g["Q_end"].to_numpy(float),
                        ])
                    )
                )
            ),
        })

    shell_df = (
        pd.DataFrame(shell_rows)
        .sort_values("shell_index")
        .reset_index(drop=True)
    )

    shell_indices = sorted(
        shell_df["shell_index"].unique().tolist()
    )
    dev_idx = shell_indices[
        :args.development_shells
    ]
    hold_idx = shell_indices[
        args.development_shells:
    ]

    dev = shell_df[
        shell_df["shell_index"].isin(dev_idx)
    ]
    hold = shell_df[
        shell_df["shell_index"].isin(hold_idx)
    ]

    dev_source = float(
        dev[
            "max_abs_fixed_source_log_secant"
        ].max()
    )
    source_cap = (
        args.source_cap_safety*dev_source
    )
    hold_source = (
        float(
            hold[
                "max_abs_fixed_source_log_secant"
            ].max()
        )
        if len(hold)
        else float("nan")
    )
    source_hold_pass = bool(
        len(hold)
        and hold_source <= source_cap
    )

    dev_rsource = float(
        dev[
            "max_abs_renorm_source_L_secant"
        ].max()
    )
    rsource_cap = (
        args.renorm_source_cap_safety
        * dev_rsource
    )
    hold_rsource = (
        float(
            hold[
                "max_abs_renorm_source_L_secant"
            ].max()
        )
        if len(hold)
        else float("nan")
    )
    rsource_hold_pass = bool(
        len(hold)
        and hold_rsource <= rsource_cap
    )

    max_Q = float(
        np.max(
            np.abs(nodes["Q"].to_numpy(float))
        )
    )
    Q_finite_pass = bool(
        max_Q <= args.maximum_rg_Q_absolute
    )
    min_slope = float(
        nodes["slope_over_L"].min()
    )
    max_abs_B = float(
        np.max(
            np.abs(nodes["beta"].to_numpy(float))
        )
    )

    # v424 Pi/L diagnostic from shells.
    max_abs_Pi_over_L = 0.0
    if {
        "primitive_beta_cumulative",
        "L_end",
    }.issubset(shells.columns):
        max_abs_Pi_over_L = float(
            np.max(
                np.abs(
                    shells[
                        "primitive_beta_cumulative"
                    ].to_numpy(float)
                )
                / shells["L_end"].to_numpy(float)
            )
        )
    elif {
        "primitive_beta_cumulative",
        "endpoint_cutoff",
    }.issubset(shells.columns):
        max_abs_Pi_over_L = float(
            np.max(
                np.abs(
                    shells[
                        "primitive_beta_cumulative"
                    ].to_numpy(float)
                )
                / np.log(
                    shells[
                        "endpoint_cutoff"
                    ].to_numpy(float)
                )
            )
        )

    print("\n[5] Log-beta source / Duhamel diagnostics")
    display = [
        "set","shell_index","anchor","endpoint_cutoff",
        "max_abs_fixed_source_log_secant",
        "max_abs_renorm_source_L_secant",
        "energy_damping_fraction",
        "median_effective_energy_damping_coeff",
        "max_abs_B",
        "max_abs_Q",
        "min_slope_over_L",
    ]
    print(
        shell_df[display].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print(
        "development max |S_sec|                  :",
        f"{dev_source:.12e}",
    )
    print(
        "frozen source cap                        :",
        f"{source_cap:.12e}",
    )
    print(
        "holdout max |S_sec|                      :",
        f"{hold_source:.12e}",
    )
    print(
        "finite fixed-source holdout pass          :",
        source_hold_pass,
    )
    print()
    print(
        "development max |renorm source|          :",
        f"{dev_rsource:.12e}",
    )
    print(
        "frozen renorm-source cap                 :",
        f"{rsource_cap:.12e}",
    )
    print(
        "holdout max |renorm source|              :",
        f"{hold_rsource:.12e}",
    )
    print(
        "finite renorm-source holdout pass         :",
        rsource_hold_pass,
    )
    print()
    print(
        "maximum |Q_k| on reused branch           :",
        f"{max_Q:.12e}",
    )
    print(
        "finite bounded-Q diagnostic pass          :",
        Q_finite_pass,
    )
    print(
        "minimum F'/L                             :",
        f"{min_slope:.12e}",
    )
    print(
        "maximum |B|                              :",
        f"{max_abs_B:.12e}",
    )
    print(
        "maximum |Pi_k|/L                         :",
        f"{max_abs_Pi_over_L:.12e}",
    )

    finite_source_pass = bool(
        source_hold_pass
        and rsource_hold_pass
        and Q_finite_pass
    )

    exact_pass = bool(
        sym.get("pass")
        and ok424
        and ok425
        and exact_split_pass
    )

    verdict = (
        "EXACT_LOG_BETA_DUHAMEL_REDUCTION_PASS_SOURCE_BOUND_OPEN"
        if exact_pass
        else
        "LOG_BETA_DUHAMEL_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_UNIFORM_MOVING_BRANCH_RENORMALIZED_BETA_SOURCE_BOUND_WITH_BOUNDED_RG_PRIMITIVE"
    )

    print("\n" + "="*238)
    print("VERDICT                                   :", verdict)
    print(
        "LOG-BETA DUHAMEL IDENTITY                :",
        "EXACT" if exact_pass else "INCOMPLETE",
    )
    print(
        "FINITE SOURCE STABILITY                 :",
        finite_source_pass,
    )
    print(
        "v425 BOUNDED SIGNED RG PRIMITIVE         : FINITE EVIDENCE"
    )
    print(
        "ALL-L SOURCE BOUND                       : NOT PROVED"
    )
    print(
        "IF |Q|+|S| BOUNDED                       : B=O(1) => Pi=O(L) => ROOT TAIL O(1/L)"
    )
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           : NOT YET PROVED"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*238)

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)
    nodes_out = Path(
        str(prefix)+"_NODES.csv"
    )
    steps_out = Path(
        str(prefix)+"_STEPS.csv.gz"
    )
    shell_out = Path(
        str(prefix)+"_SHELL_SUMMARY.csv"
    )
    summary_out = Path(
        str(prefix)+"_SUMMARY.json"
    )
    theorem_out = Path(
        str(prefix)+"_THEOREM.md"
    )
    cert_out = Path(
        str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json"
    )

    nodes.to_csv(
        nodes_out,
        index=False,
    )
    steps.to_csv(
        steps_out,
        index=False,
        compression="gzip",
    )
    shell_df.to_csv(
        shell_out,
        index=False,
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_numeric_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff": False,
        },
        "upstream": {
            "v424_ok": ok424,
            "v425_ok": ok425,
            "v440_ok": ok440,
            "v441_ok": ok441,
        },
        "exact_theorem": sym,
        "exact_beta_split": {
            "maximum_absolute_residual": max_split_abs,
            "pass": exact_split_pass,
        },
        "finite_source": {
            "development_max_abs_fixed_source_log_secant": dev_source,
            "source_cap": source_cap,
            "holdout_max_abs_fixed_source_log_secant": hold_source,
            "source_holdout_pass": source_hold_pass,
            "development_max_abs_renorm_source_L_secant": dev_rsource,
            "renorm_source_cap": rsource_cap,
            "holdout_max_abs_renorm_source_L_secant": hold_rsource,
            "renorm_source_holdout_pass": rsource_hold_pass,
            "maximum_abs_Q": max_Q,
            "bounded_Q_diagnostic_pass": Q_finite_pass,
            "minimum_slope_over_L": min_slope,
            "maximum_abs_B": max_abs_B,
            "maximum_abs_Pi_over_L": max_abs_Pi_over_L,
            "maximum_kappa_secant_minus_endpoint": max_kappa_diff,
            "combined_pass": finite_source_pass,
            "proof_status": "FINITE_EVIDENCE_ONLY",
        },
        "verdict": verdict,
        "all_L_source_bound_proved": False,
        "fixed_mode_cutoff_independence_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_out.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        r"""# ROT-RH v442 — log-beta Duhamel reduction

Along a quantized characteristic,

`E_k'=B_k/L^2`

and v425 defines

`kappa=1+partial_E B/L`.

Therefore

`dB_k/d(log L)
 = L partial_L B +(kappa-1)B_k`.

With

`S_k=L partial_L B|_(E=E_k(L))`

this becomes

`dB_k/d(log L)+(1-kappa_k)B_k=S_k`.

Let

`Q_k(L)=int_(L0)^L kappa_k(s)/s ds`.

Then

`d/dL[L exp(-Q_k)B_k]=exp(-Q_k)S_k`

and hence

`B_k(L)=exp(Q_k(L))/L
 [L0 B_k(L0)+int_(L0)^L exp(-Q_k(s))S_k(s)ds]`.

Thus a bounded signed RG primitive `Q_k` together with a bounded
fixed-cutoff beta source `S_k` implies

`B_k=O_k(1)`.

Consequently

`Pi_k(L)=int B_k=O_k(L)`,

and the v419 primitive-beta theorem gives an `O_k(1/L)` fixed-mode cutoff
tail, provided the branch persists and the v425 no-fold condition holds.

Because the arithmetic generator has prime jumps, the finite script uses
small-step secants of the fixed-E beta injection instead of pretending a
classical derivative exists at every cutoff.

The remaining analytic problem is therefore sharply localized:

prove the renormalized moving-branch beta source is uniformly bounded (or
has O(L) cumulative weighted input) while the signed RG primitive remains
bounded.

This target is branch-specific and does not assume the RH-equivalent
uniform fixed-E H bound from v439/v440.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": (
            "ROT_RH_LOG_BETA_DUHAMEL_SOURCE_CERTIFICATE_V1"
        ),
        "exact_reduction_proved": exact_pass,
        "required_all_L_claims": {
            "bounded_signed_RG_primitive": {
                "proved": False,
                "statement": (
                    "|Q_k(L)|=|int kappa_k(s)/s ds|<=Q_k^* "
                    "along each eventual ordered branch."
                ),
                "upstream_finite_evidence": "v425",
            },
            "bounded_beta_source": {
                "proved": False,
                "statement": (
                    "The fixed-cutoff source S_k=L partial_L B "
                    "(interpreted with the arithmetic jump measure) is "
                    "uniformly bounded, or equivalently its exponentially "
                    "weighted Duhamel input is O(L)."
                ),
            },
            "branch_persistence": {
                "proved": False,
                "statement": (
                    "The ordered branch persists eventually without switching."
                ),
            },
        },
        "consequence": (
            "bounded Q + bounded source => B=O(1) => Pi=O(L) => "
            "fixed-mode cutoff independence with O(1/L) tail"
        ),
        "forbidden_shortcuts": [
            "uniform fixed-E Gate A",
            "RH",
            "known zero ordinates",
            "Xi fitting",
            "square-root PNT error",
            "finite source cap as proof",
        ],
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", nodes_out)
    print(" ", steps_out)
    print(" ", shell_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
