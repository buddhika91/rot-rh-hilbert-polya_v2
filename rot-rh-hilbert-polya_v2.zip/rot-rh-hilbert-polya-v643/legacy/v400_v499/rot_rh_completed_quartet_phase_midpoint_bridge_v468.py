#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v468 — COMPLETED QUARTET PHASE / LOCAL MIDPOINT TARGET BRIDGE
====================================================================

PURPOSE
-------
Replace the abstract v465 "half-plane avoidance" target by a sharper completed
target statement that respects the functional-equation recombination.

For

    Xi(t) = xi(1/2 + i t),

the standard symmetries are

    Xi(-t)=Xi(t),
    Xi(conj(t))=conj(Xi(t)).

An off-critical zeta zero

    rho = 1/2 + a + i gamma,  a != 0,

maps to a nonreal t-zero

    tau = gamma - i a.

The functional equation and conjugation give the quartet

    tau, conj(tau), -tau, -conj(tau).

The corresponding even canonical factor can be grouped as

    Q_(a,gamma)(t)
      = (1 - t^2/tau^2)(1 - t^2/conj(tau)^2)
      = |1 - t^2/tau^2|^2

for real t.

Therefore

    Q_(a,gamma)(t) > 0

for every real t.

So off-critical quartets contribute NO fractional real-axis phase to the
completed Xi target.  They affect magnitude, but not the sign/phase modulo pi.

By contrast, a critical-line zero rho=1/2+i gamma maps to the real t-zero
gamma and contributes

    C_gamma(t) = (1 - t^2/gamma^2)^m.

Thus the sign changes / real-axis phase jumps are carried only by critical-line
zeros.

This is unconditional: it uses only the standard functional equation,
conjugation symmetry, and the canonical zero symmetries.  It does NOT assume RH
or simple zeros.

---------------------------------------------------------------------------
LOCAL REGULAR FACTOR
---------------------------------------------------------------------------

Let gamma be an isolated real zero of Xi of multiplicity m and define

    G_gamma(t)
      = Xi(t) / (1 - t^2/gamma^2)^m.

On a sufficiently small real interval I around gamma containing no other real
Xi zero,

    G_gamma(t) is real, continuous, and nonzero.

Hence its sign is constant on I and

    G_gamma(t)/|G_gamma(t)| in {+1,-1},

so the exact completed regular factor has maximal half-plane margin

    |Re G_gamma|/|G_gamma| = 1.

Equivalently, its normalized regular phase is an integer modulo 1.  This is the
precise completed-target version of the midpoint-background law sought in
v463-v465.

---------------------------------------------------------------------------
RELATIVE-CONVERGENCE BRIDGE
---------------------------------------------------------------------------

Let R_L(t) be the collision-subtracted finite bump regular factor in the same
local chart, after removing the multiplicity-m local bump collision.

It is enough to control only the normalized phase.  Put

    U_L(t)=R_L(t)/|R_L(t)|

and let sigma_gamma=sign(G_gamma).

Assume

    sup_(t in I) |sigma_gamma U_L(t)-1| <= eta_L < 1.

Then every normalized R_L(t) lies in the disk centered at the target sign with
radius eta_L. Therefore

    |Re R_L|/|R_L| >= sqrt(1-eta_L^2),

and the angular distance from the imaginary axis is at least

    arccos(eta_L).

By v465's exact half-plane capture theorem,

    |E_L-gamma|
      <= 2m(1+sqrt(pi))
         / [L arccos(eta_L)].

Consequences:

  * any eventual eta_L <= eta < 1 gives O(1/L) cutoff capture;
  * eta_L -> 0 gives the asymptotic midpoint constant

        |E_L-gamma|
          <= [4m(1+sqrt(pi))/pi + o(1)] / L.

Thus the local half-plane theorem is reduced to phase convergence only:

    R_L/|R_L| -> sign(G_gamma)

uniformly on the local real tube.

No modulus convergence is required.

A still more local sufficient criterion is available.  Choose one anchor
t0 in I and write the angular anchor error as a_L.  If R_L has no zero on I and

    V_L = integral_I | Im(R_L'(t)/R_L(t)) | dt,

then the phase error everywhere on I is at most

    a_L + V_L.

If

    a_L+V_L < pi/2,

then

    |Re R_L|/|R_L| >= cos(a_L+V_L)

and the angular distance from the imaginary axis is at least

    pi/2-a_L-V_L.

Hence v465 gives

    |E_L-gamma|
      <= 2m(1+sqrt(pi))
         / [L (pi/2-a_L-V_L)].

Therefore an anchor error plus integrated regular logarithmic-phase derivative
tending to zero is enough to recover the exact midpoint O(1/L) constant.

---------------------------------------------------------------------------
IMPORTANT CONSEQUENCE
---------------------------------------------------------------------------

A phase-only secular construction cannot detect off-critical quartets on the
real t-axis: their completed factors are strictly positive there.  Therefore
cutoff independence of the phase roots alone is not RH.

RH can only enter later through a complete operator/Fredholm identity that also
captures the zero set/magnitude structure of Xi.

This distinction prevents the cutoff-independence proof from being forced to
prove a false intermediate statement such as "every individual off-critical
resonance is small."  Individual split resonances can grow; the completed
quartet has zero fractional phase after recombination.

No numerical Xi/zeta values and no known zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v468-completed-quartet-phase-midpoint-bridge"
CSAT = 2.0 * (1.0 + math.sqrt(math.pi))


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "sympy_available": False,
            "error": str(exc),
            "pass": False,
        }

    a, g, t, u = sp.symbols(
        "a g t u",
        real=True,
        nonzero=True,
    )
    I = sp.I

    # Critical-line s variable: s=1/2+iE and a paired off-line zero pair
    # at 1/2 +/- a + i gamma.
    pair_s = sp.expand(
        (-a + I*u) * (a + I*u)
    )
    expected_pair_s = -(a*a + u*u)

    pair_s_pass = bool(
        sp.simplify(pair_s - expected_pair_s) == 0
    )

    # t-plane quartet.  tau = gamma - i a.
    tau = g - I*a
    taut = g + I*a

    q = sp.simplify(
        (1 - t**2/tau**2)
        * (1 - t**2/taut**2)
    )

    # For real a,g,t this equals modulus-square.  Expand to a manifestly
    # positive rational expression by combining numerator/denominator.
    q_manifest = sp.factor(
        (
            ((g*g - a*a - t*t)**2 + 4*a*a*g*g)
            / ((g*g - a*a)**2 + 4*a*a*g*g)
        )
    )

    quartet_identity_pass = bool(
        sp.simplify(q - q_manifest) == 0
    )

    # Denominator simplifies to (g^2+a^2)^2.
    denom_identity = bool(
        sp.simplify(
            ((g*g-a*a)**2 + 4*a*a*g*g)
            - (g*g+a*a)**2
        ) == 0
    )

    # Numerator is sum of squares:
    # (g^2-a^2-t^2)^2 + (2ag)^2 > 0 for a,g nonzero real.
    # We record positivity symbolically as sum-of-squares structure.
    numerator = sp.expand(
        (g*g-a*a-t*t)**2 + (2*a*g)**2
    )

    # Critical factor mapping.
    critical = 1 - t*t/(g*g)

    return {
        "sympy_available": True,
        "s_pair_product": str(pair_s),
        "s_pair_expected": str(expected_pair_s),
        "s_pair_real_negative_identity": pair_s_pass,
        "quartet_factor": str(q),
        "quartet_manifest_positive": str(q_manifest),
        "quartet_identity_pass": quartet_identity_pass,
        "quartet_denominator_identity_pass": denom_identity,
        "quartet_numerator_sum_squares": str(numerator),
        "critical_factor": str(critical),
        "pass": bool(
            pair_s_pass
            and quartet_identity_pass
            and denom_identity
        ),
    }


def disk_halfplane(eta: float, m: int, L: float) -> Dict[str, Any]:
    if not (0.0 <= eta < 1.0):
        raise ValueError("eta must satisfy 0<=eta<1")
    h = math.sqrt(max(0.0, 1.0 - eta*eta))
    angle = math.acos(eta)
    bound = (
        2.0*m*(1.0+math.sqrt(math.pi))
        / (L*angle)
    )
    return {
        "eta": eta,
        "halfplane_h": h,
        "angular_gap": angle,
        "normalized_plateau_gap": angle/math.pi,
        "capture_E_error": bound,
    }


def asymptotic_midpoint_constant(m: int) -> float:
    return 4.0*m*(1.0+math.sqrt(math.pi))/math.pi


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v468 — completed quartet phase / local midpoint target bridge

## A. Off-critical quartet phase cancellation

Let

`Xi(t)=xi(1/2+i t)`.

An off-critical zero

`rho=1/2+a+i gamma`, `a!=0`,

maps to

`tau=gamma-i a`.

The standard symmetries give the quartet

`tau, conj(tau), -tau, -conj(tau)`.

Group its even canonical factor as

`Q_(a,gamma)(t)
 =(1-t^2/tau^2)(1-t^2/conj(tau)^2)`.

For real `t`,

`Q_(a,gamma)(t)
 = |1-t^2/tau^2|^2
 >0`.

Equivalently, the symbolic computation gives the manifest form

`Q
 = [ (gamma^2-a^2-t^2)^2 + 4a^2 gamma^2 ]
   / (gamma^2+a^2)^2`.

So an off-critical quartet changes the completed magnitude but contributes zero
fractional real-axis phase modulo `pi`.

No RH or simplicity assumption is used.

## B. Critical collision

A critical-line zero of multiplicity `m` at `gamma` contributes

`(1-t^2/gamma^2)^m`.

After removing that local factor,

`G_gamma(t)=Xi(t)/(1-t^2/gamma^2)^m`

is real and nonzero on a sufficiently small isolated real tube.

Therefore

`|Re G_gamma|/|G_gamma|=1`.

The exact completed target therefore satisfies the strongest possible v465
half-plane condition.

## C. Relative-convergence theorem

Let `R_L(t)` be the collision-subtracted finite bump regular factor and let
`sigma_gamma=sign G_gamma` on the tube.

If

`sup_I | sigma_gamma R_L/|R_L| - 1 | <= eta_L < 1`,

then

`|Re R_L|/|R_L| >= sqrt(1-eta_L^2)`

and the v465 angular half-plane gap is at least

`arccos(eta_L)`.

Consequently,

`|E_L-gamma|
 <= 2m(1+sqrt(pi))
    / [L arccos(eta_L)]`.

Any eventual uniform `eta_L<=eta<1` gives `O(1/L)` cutoff capture.

If `eta_L->0`,

`|E_L-gamma|
 <= [4m(1+sqrt(pi))/pi+o(1)]/L`.

For multiplicity one the midpoint constant is

`{asymptotic_midpoint_constant(1):.16e}`.

## D. New analytic target

The midpoint/half-plane problem is no longer an abstract phase-density theorem.

It is enough to prove the weaker phase statement

`R_L/|R_L| -> sign(G_gamma)`

uniformly on each eventual isolated critical collision tube.

A sufficient derivative form is

`anchor angular error + int_I |Im(R_L'/R_L)| -> 0`.

This target must preserve the functional-equation quartet recombination.
Bounding individual off-critical Mellin residues separately is structurally
wrong for fractional phase.

## E. Scope

This does not prove the relative-convergence theorem itself, global cutoff
independence, RH, or the Fredholm-Xi identity.

It also shows why phase-root cutoff independence alone cannot prove RH:
off-critical quartets are strictly positive on the real t-axis and are
therefore invisible to the completed fractional phase.
""",
        encoding="utf-8",
    )

    cert.write_text(
        json.dumps({
            "schema": "ROT_RH_COMPLETED_QUARTET_MIDPOINT_BRIDGE_V1",
            "closed": {
                "offcritical_quartet_real_axis_factor":
                    "strictly positive",
                "offcritical_fractional_phase":
                    "zero modulo pi",
                "critical_local_regular_factor":
                    "real nonzero after local multiplicity factor removal",
                "completed_halfplane_margin":
                    "h=1 on an isolated real tube",
                "relative_disk_to_capture":
                    "|E_L-gamma|<=2m(1+sqrt(pi))/(L arccos eta_L)",
            },
            "required_next": {
                "phase_convergence":
                    "prove R_L/|R_L| converges uniformly to sign(G_gamma) on the isolated collision tube",
                "log_phase_derivative":
                    "suffices to prove one-point angular anchoring plus integral_I |Im(R_L'/R_L)| -> 0",
                "recombination":
                    "pair functional-equation off-critical partners before estimating any phase contribution",
                "local_collision":
                    "keep multiplicity-m critical collision recombined; never split singular G7/R7 continuations",
            },
            "forbidden_shortcut": [
                "bounding one off-critical zero residue and treating its power growth as the completed fractional phase",
                "assuming RH",
                "assuming simple zeros",
                "using finite cutoff regression as uniform convergence proof",
            ],
        }, indent=2),
        encoding="utf-8",
    )


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--multiplicity", type=int, default=1)
    ap.add_argument("--L", type=float, default=100.0)
    ap.add_argument(
        "--eta-values",
        default="0.9,0.5,0.25,0.1,0.01,0",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_completed_quartet_phase_midpoint_bridge_v468",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.multiplicity < 1:
        raise ValueError("--multiplicity must be >=1")
    if args.L <= 0:
        raise ValueError("--L must be positive")

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*196)
    print("ROT-RH v468 — COMPLETED QUARTET PHASE / LOCAL MIDPOINT TARGET BRIDGE")
    print("="*196)
    print("Xi numerical values / zeta numerical values : NONE")
    print("known zero ordinates                         : NONE")
    print("RH assumption                                : NONE")
    print("="*196)

    with tqdm(total=2, desc="v468 exact reduction", unit="step") as bar:
        sym = symbolic_checks()
        bar.update(1)

        eta_values = [
            float(x.strip())
            for x in args.eta_values.split(",")
            if x.strip()
        ]
        panel = [
            disk_halfplane(eta, args.multiplicity, args.L)
            for eta in eta_values
        ]
        bar.update(1)

    passed = bool(sym.get("pass"))
    verdict = (
        "EXACT_COMPLETED_QUARTET_PHASE_MIDPOINT_BRIDGE_PASS"
        if passed else
        "COMPLETED_QUARTET_SYMBOLIC_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_numerical_values_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
        },
        "symbolic": sym,
        "relative_convergence_panel": panel,
        "asymptotic_midpoint_constant_m":
            asymptotic_midpoint_constant(args.multiplicity),
        "theorem_status": (
            "Exact completed-target quartet phase theorem and relative-convergence "
            "reduction. The arithmetic finite-bump relative-convergence theorem "
            "remains open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*196)
    print("verdict                                  :", verdict)
    print("off-critical pair product identity       :", sym.get("s_pair_real_negative_identity"))
    print("off-critical quartet positive identity   :", sym.get("quartet_identity_pass"))
    print("completed local half-plane margin        : 1")
    print("midpoint capture constant (selected m)   :", f"{asymptotic_midpoint_constant(args.multiplicity):.16e}")
    print("summary                                  :", str(prefix)+"_SUMMARY.json")
    print("theorem                                  :", str(prefix)+"_THEOREM.md")
    print("next certificate                         :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*196)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
