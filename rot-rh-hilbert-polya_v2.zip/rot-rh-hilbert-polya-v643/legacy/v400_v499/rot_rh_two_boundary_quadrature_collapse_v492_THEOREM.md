# ROT-RH v492 — two-boundary quadrature / coherence-collapse reduction

Let `S_0(L)` denote the escaping off-critical complex saddle packet at the
center of a local collision cell and

`W_0(L)=sum_j |b_j(L)|`.

After removing a low-frequency absolute-mass fraction `tau_L`, v473's universal
energy carrier gives on the high packet, for fixed scaled displacement `u`,

`S_(+u)=e^(+iu) S_0 + R_+`,
`S_(-u)=e^(-iu) S_0 + R_-`,

with

`|R_+|, |R_-| <= eps_L W_0`

and, on a uniformly escaping packet,

`eps_L=O(|u|(L Gamma_min)^(-1/3)) -> 0`.

Choose

`U=n*pi+pi/4`.

Then

`|sin U|=|cos U|=1/sqrt(2)`.

Write `S_0=x+iy`.  Ignoring the controlled remainders,

`Im S_(+U)= sin(U)x + cos(U)y`,
`Im S_(-U)=-sin(U)x + cos(U)y`.

These are two independent quadratures.  If both off-critical boundary phase
projections are bounded,

`|Im S_(+U)| <= C`,
`|Im S_(-U)| <= C`,

then including the remainders gives

`|x| <= sqrt(2)(C+eps_L W_0)`,
`|y| <= sqrt(2)(C+eps_L W_0)`,

and therefore

`|S_0|/W_0 <= 2 eps_L + 2C/W_0`.

After restoring the discarded low-frequency packet,

`coherence_total
 <= 2 eps_L + O(tau_L) + 2C/W_0,total`.

In the genuinely nonattained sector, absolute-frequency escape allows a
diagonal `Gamma_min(L)->infinity` with `tau_L->0`.  The off-critical absolute
mass also has a growing unfactored baseline, so `C/W_0,total->0`.  Hence
simultaneous bounded **unwrapped** phase on the two boundaries forces

`|S_0|/W_0 -> 0`.

### Meaning for v491

v491 showed that a strict half-plane gap fixes the unwrapped winding class on
each boundary.  Once the already-closed/static channels are removed, this makes
the off-critical boundary projections bounded.  Therefore a successful v470
two-boundary barrier in the nonattained sector can occur only together with
quantitative collective coherence collapse.

This does **not** exclude that collapse.  It sharpens the final dichotomy:

1. boundary winding escapes / hits the bad half-integer set, so the v470
   half-plane barrier fails; or
2. both boundaries stay in fixed winding classes, which forces the central
   nonattained packet into the coherence-collapse regime.

**Verdict:** `TWO_BOUNDARY_QUADRATURE_FORCES_COHERENCE_COLLAPSE_REDUCTION_PASS`.

The carrier estimate uses the v473/v475 sectorial saddle asymptotic; a
publication proof still needs its already-identified uniform remainder
inequalities.
