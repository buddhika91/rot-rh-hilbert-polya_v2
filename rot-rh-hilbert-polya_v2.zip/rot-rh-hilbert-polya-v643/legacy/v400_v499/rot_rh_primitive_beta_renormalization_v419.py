#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v419 — CESARO / PRIMITIVE-BETA NON-PERTURBATIVE CUTOFF THEOREM
=====================================================================

Purpose
-------
Correct one overstatement in v418 and sharpen the genuinely non-perturbative
cutoff-removal criterion.

v418 proved the exact identity

    E_k'(L) = B_k(L)/L^2,

where

    B_k(L) = C0(L,E_k(L))/F'_L(E_k(L)).

A bounded beta function is a strong sufficient condition, but it is NOT
necessary for cutoff independence.

A stable almost-periodic resonance cluster can have

    E_k(L) = E_* + q(L)/L,

with bounded oscillatory q.  Then

    B_k(L)
      = L^2 E_k'(L)
      = L q'(L) - q(L),

which can grow like O(L), even though E_k(L)->E_*.

Therefore the correct signed non-perturbative object is the PRIMITIVE of beta.

Define

    Pi_k(L)
      = integral_(L0)^L B_k(s) ds.

Integration by parts gives exactly

    integral_L^T B_k(s)/s^2 ds
      = Pi_k(T)/T^2
        - Pi_k(L)/L^2
        + 2 integral_L^T Pi_k(s)/s^3 ds.

Hence if, for some epsilon>0,

    |Pi_k(L)| <= C_k L^(2-epsilon)

eventually, then

    integral_L^infinity B_k(s)/s^2 ds

converges and

    |E_k(infinity)-E_k(L)|
      <= C_k (1+2/epsilon) L^(-epsilon).

In particular,

    Pi_k(L)=O_k(L)

gives the sharp tail

    |E_k(infinity)-E_k(L)|=O_k(1/L).

This criterion allows B_k itself to be unbounded and oscillatory.

----------------------------------------------------------------------
A. Why bounded beta is not necessary
----------------------------------------------------------------------

Take

    E(L)=E_* + sin(L)/L.

Then

    E'(L)=cos(L)/L - sin(L)/L^2,

so

    B(L)=L^2 E'(L)=L cos(L)-sin(L),

which is unbounded.

But

    Pi(L)
      = integral B
      = L sin(L)+2 cos(L)+constant
      = O(L),

and E(L)->E_*.

Thus a theorem requiring sup|B|<infinity would reject a perfectly convergent
oscillatory renormalization flow.

----------------------------------------------------------------------
B. General bounded-phase-remainder lemma
----------------------------------------------------------------------

Suppose

    E(L)=E_* + q(L)/L

with q bounded and locally absolutely continuous.

Then

    B=L^2 E'
     = L q' - q.

Integrating,

    Pi(L)
      = L q(L)
        - 2 integral_(L0)^L q(s) ds
        + constant.

Therefore

    |q|<=Q

implies

    Pi(L)=O(Q L).

So every branch with a bounded O(1/L) phase remainder automatically has the
primitive-beta property, regardless of whether q' oscillates strongly.

This places the already-closed attained resonance cases in the correct
renormalization class:

* v385: single dominant resonance, ordinary O(1/L) phase lock;
* v386: stable finite nonvanishing mean-motion cluster, bounded phase remainder;
* v387: attained rightmost infinite cluster, bounded/o(1) phase remainder,
  provided the eventual branch is differentiable/no-fold when expressed through
  the beta quotient.

----------------------------------------------------------------------
C. True hierarchy of cutoff criteria
----------------------------------------------------------------------

STRONG:
    |C0|<=K0 L and F'>=cL
        => |B|<=K0/c.

LESS STRONG:
    |B|<=B*
        => Pi=O(L).

SIGNED / CESARO:
    Pi=O(L)
        => E(infinity)-E(L)=O(1/L).

GENERAL SUBQUADRATIC:
    Pi=O(L^(2-epsilon))
        => E(infinity)-E(L)=O(L^(-epsilon)).

MINIMAL EXACT STATEMENT:
    fixed-mode convergence is equivalent, along a persistent differentiable
    branch, to convergence of

        integral^infinity B(L)/L^2 dL.

The primitive-beta theorem is a useful robust sufficient condition for that
signed convergence, not a claim of logical necessity.

----------------------------------------------------------------------
D. No-fold / branch persistence
----------------------------------------------------------------------

The quotient

    B=C0/F'

is only a regular local coordinate when F'!=0.

The raw determinant is not globally Herglotz-monotone (v82 has negative-delay
witnesses away from roots), so no-fold cannot be inferred from global scalar
inner structure.

Instead it must be proved on the eventual ordered root branch.

Known attained cases:

* v385:
      denominator L+delta'(E)>0 eventually.

* v386:
      partial_E Phi >= L-M-D>0 eventually
  under its bounded E-phase derivative hypothesis.

* v387:
  fixed-root convergence is proved under an attained rightmost nonvanishing
  stable mean-motion chamber, but a beta-quotient no-fold statement should
  retain/check the corresponding uniform E-derivative control explicitly.

----------------------------------------------------------------------
E. Remaining global theorem
----------------------------------------------------------------------

The honest remaining all-L target is now:

BRANCH:
    prove the fixed ordered root exists continuously for all sufficiently
    large L.

NO-FOLD:
    prove F'_L(E_k(L)) != 0 eventually
    (preferably a quantitative lower bound).

SIGNED RG:
    prove either

        Pi_k(L)
          = integral_(L0)^L
              C0(s,E_k(s))/F'_s(E_k(s)) ds
          = O_k(L^(2-epsilon))

    for some epsilon>0,

    OR directly prove convergence of

        integral^infinity
          [C0/F'] dL/L^2.

The O(L) primitive is the natural sharp target because it reproduces the
O(1/L) convergence already seen in all stable attained resonance chambers.

The genuinely unresolved sector is the nonattained / switching infinite
resonance system isolated by v388-v411.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO numerical zeta derivatives.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 419
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 419


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def integration_by_parts_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    s, L, T = sp.symbols(
        "s L T",
        positive=True,
        real=True,
    )
    Pi = sp.Function("Pi")

    # Formal integration-by-parts identity:
    # B=Pi', integral Pi'/s^2
    integrand = sp.diff(Pi(s), s)/s**2

    # SymPy keeps the integral formal; compare to derivative of boundary
    # expression to certify the antiderivative structure.
    candidate = (
        Pi(s)/s**2
        + 2*sp.Integral(Pi(s)/s**3, s)
    )

    derivative_residual = sp.simplify(
        sp.diff(candidate, s) - integrand
    )

    return {
        "identity": (
            "int_L^T B/s^2 "
            "=Pi(T)/T^2-Pi(L)/L^2+2 int_L^T Pi/s^3"
        ),
        "antiderivative_derivative_residual": str(
            derivative_residual
        ),
        "pass": bool(derivative_residual == 0),
    }


def subquadratic_tail_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, eps, C = sp.symbols(
        "L eps C",
        positive=True,
        real=True,
    )
    s = sp.symbols(
        "s",
        positive=True,
        real=True,
    )

    # If |Pi(s)|<=C s^(2-eps):
    # |Pi(L)|/L^2 <= C L^-eps
    # and 2 int_L^inf C s^(-1-eps) ds = 2C/eps L^-eps.
    integral = sp.integrate(
        2*C*s**(-1-eps),
        (s, L, sp.oo),
    )
    expected = 2*C/eps * L**(-eps)

    residual = sp.simplify(
        integral-expected
    )

    total = sp.simplify(
        C*L**(-eps) + expected
    )
    target = sp.simplify(
        C*(1+2/eps)*L**(-eps)
    )

    return {
        "integral_tail": str(integral),
        "integral_residual": str(residual),
        "total_tail": str(total),
        "target_tail": str(target),
        "total_residual": str(
            sp.simplify(total-target)
        ),
        "pass": bool(
            residual == 0
            and sp.simplify(total-target) == 0
        ),
    }


def oscillatory_counterexample_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L = sp.symbols(
        "L",
        positive=True,
        real=True,
    )
    Estar = sp.symbols(
        "E_star",
        real=True,
    )

    E = Estar + sp.sin(L)/L
    Eprime = sp.simplify(
        sp.diff(E, L)
    )
    B = sp.simplify(
        L**2 * Eprime
    )
    expected_B = L*sp.cos(L)-sp.sin(L)

    B_residual = sp.simplify(
        B-expected_B
    )

    Pi = sp.integrate(
        expected_B,
        L,
    )
    expected_Pi = (
        L*sp.sin(L)+2*sp.cos(L)
    )
    Pi_residual = sp.simplify(
        Pi-expected_Pi
    )

    return {
        "E": str(E),
        "Eprime": str(Eprime),
        "B": str(B),
        "B_expected": str(expected_B),
        "B_residual": str(B_residual),
        "Pi": str(Pi),
        "Pi_expected": str(expected_Pi),
        "Pi_residual": str(Pi_residual),
        "beta_unbounded": True,
        "primitive_order": "O(L)",
        "level_limit": "E(L)->E_star",
        "pass": bool(
            B_residual == 0
            and Pi_residual == 0
        ),
    }


def bounded_remainder_lemma_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L = sp.symbols(
        "L",
        positive=True,
        real=True,
    )
    q = sp.Function("q")

    e = q(L)/L
    B = sp.simplify(
        L**2 * sp.diff(e, L)
    )
    expected_B = (
        L*sp.diff(q(L), L)-q(L)
    )

    B_residual = sp.simplify(
        B-expected_B
    )

    # Antiderivative structure:
    candidate_Pi = (
        L*q(L)
        - 2*sp.Integral(q(L), L)
    )
    primitive_residual = sp.simplify(
        sp.diff(candidate_Pi, L)
        - expected_B
    )

    return {
        "level_remainder": "E-E*=q(L)/L",
        "beta": str(B),
        "beta_residual": str(B_residual),
        "primitive": (
            "Pi=L q(L)-2 int q(L)dL + constant"
        ),
        "primitive_derivative_residual": str(
            primitive_residual
        ),
        "bounded_q_implication": (
            "|q|<=Q => |Pi(L)|=O(Q L)"
        ),
        "pass": bool(
            B_residual == 0
            and primitive_residual == 0
        ),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v418-summary",
        default="rot_rh_nonperturbative_beta_closure_v418_SUMMARY.json",
    )
    ap.add_argument(
        "--v385-summary",
        default="rot_rh_moving_root_single_resonance_v385_SUMMARY.json",
    )
    ap.add_argument(
        "--v386-summary",
        default="rot_rh_resonance_cluster_mean_motion_v386_SUMMARY.json",
    )
    ap.add_argument(
        "--v387-summary",
        default="rot_rh_attained_rightmost_infinite_cluster_v387_SUMMARY.json",
    )
    ap.add_argument(
        "--v409-summary",
        default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json",
    )
    ap.add_argument(
        "--v410-summary",
        default="rot_rh_bohr_frequency_escape_v410_SUMMARY.json",
    )
    ap.add_argument(
        "--v411-summary",
        default="rot_rh_collective_phase_lock_v411_SUMMARY.json",
    )

    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_primitive_beta_renormalization_v419",
    )

    args = ap.parse_args()

    v418 = load_json(args.v418_summary)
    v385 = load_json(args.v385_summary)
    v386 = load_json(args.v386_summary)
    v387 = load_json(args.v387_summary)
    v409 = load_json(args.v409_summary)
    v410 = load_json(args.v410_summary)
    v411 = load_json(args.v411_summary)

    v418_ok = bool(
        v418 is not None
        and v418.get("verdict")
        == "EXACT_NONPERTURBATIVE_BETA_FUNCTION_CUTOFF_CLOSURE_REDUCTION_PASS"
    )
    v385_ok = bool(
        v385 is not None
        and v385.get("verdict")
        == "SINGLE_DOMINANT_RESONANCE_CUTOFF_INDEPENDENCE_THEOREM_PASS"
    )
    v386_ok = bool(
        v386 is not None
        and v386.get("verdict")
        == "STABLE_FINITE_RESONANCE_CLUSTER_CUTOFF_THEOREM_PASS"
    )
    v387_ok = bool(
        v387 is not None
        and v387.get("verdict")
        == "ATTAINED_RIGHTMOST_INFINITE_CLUSTER_CUTOFF_THEOREM_PASS"
    )
    v409_ok = bool(
        v409 is not None
        and v409.get("verdict")
        == "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS"
    )
    v410_ok = bool(
        v410 is not None
        and v410.get("verdict")
        == "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS"
    )
    v411_ok = bool(
        v411 is not None
        and v411.get("verdict")
        == "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS"
    )

    print("="*238)
    print("ROT-RH v419 — CESARO / PRIMITIVE-BETA NON-PERTURBATIVE CUTOFF THEOREM")
    print("="*238)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scan accepted as proof            : NO")
    print("="*238)

    print("[1] Upstream")
    print("v418 bounded-beta sufficient theorem     :", v418_ok)
    print("v385 single resonance                    :", v385_ok)
    print("v386 stable finite cluster               :", v386_ok)
    print("v387 attained infinite rightmost cluster :", v387_ok)
    print("v409 nonattained cancellation necessity  :", v409_ok)
    print("v410 Bohr frequency escape               :", v410_ok)
    print("v411 collective phase-lock               :", v411_ok)

    print("\n[2] Exact primitive-beta algebra")

    with tqdm(
        total=4,
        desc="primitive-beta theorem",
        unit="identity",
    ) as bar:
        ibp = integration_by_parts_check()
        bar.update(1)

        tail = subquadratic_tail_check()
        bar.update(1)

        counter = oscillatory_counterexample_check()
        bar.update(1)

        remainder = bounded_remainder_lemma_check()
        bar.update(1)

    print("integration-by-parts identity            :", ibp.get("pass"))
    print("subquadratic primitive tail              :", tail.get("pass"))
    print("unbounded-beta convergent example        :", counter.get("pass"))
    print("bounded phase-remainder lemma            :", remainder.get("pass"))

    algebra_ok = bool(
        ibp.get("pass")
        and tail.get("pass")
        and counter.get("pass")
        and remainder.get("pass")
    )

    print("\n[3] Correct theorem hierarchy")

    hierarchy = [
        (
            "EXACT_FLOW",
            "E_k'(L)=B_k(L)/L^2.",
        ),
        (
            "BOUNDED_BETA",
            "|B_k|<=B* is sufficient but not necessary.",
        ),
        (
            "PRIMITIVE",
            "Pi_k(L)=int_(L0)^L B_k(s)ds.",
        ),
        (
            "SUBQUADRATIC",
            "|Pi_k(L)|<=C L^(2-eps), eps>0 => E_k(L) converges.",
        ),
        (
            "TAIL",
            "|E_inf-E(L)|<=C(1+2/eps)L^(-eps).",
        ),
        (
            "SHARP_O1_OVER_L",
            "Pi_k=O(L) => E_inf-E(L)=O(1/L).",
        ),
        (
            "EXACT_MINIMAL",
            "Along a persistent differentiable branch, convergence is exactly convergence of int^infinity B(L)dL/L^2.",
        ),
    ]

    for key, txt in hierarchy:
        print(f"{key:46s}: {txt}")

    print("\n[4] Attained resonance sectors")

    attained = [
        (
            "SINGLE_RESONANCE",
            "v385 gives O(1/L) locking and eventual positive denominator; hence it lies in the primitive-beta O(L) class.",
        ),
        (
            "FINITE_CLUSTER",
            "v386 bounded phase remainder gives E-E*=q(L)/L with bounded q and eventual no-fold; therefore Pi=O(L), even if B=O(L) oscillatory.",
        ),
        (
            "ATTAINED_INFINITE_CLUSTER",
            "v387 gives E-E*=O(1/L)+o(1/L) under an attained nonvanishing stable chamber. Primitive-beta translation is valid once corresponding eventual no-fold/E-derivative control is retained.",
        ),
        (
            "CONCLUSION",
            "The ordinary attained stable chambers are not the remaining renormalization obstruction.",
        ),
    ]

    for key, txt in attained:
        print(f"{key:46s}: {txt}")

    print("\n[5] What remains")

    remaining = [
        (
            "NONATTAINED_SWITCHING",
            "The genuinely unresolved sector is the nonattained / dominance-switching infinite resonance family isolated by v388-v411.",
        ),
        (
            "BRANCH",
            "Prove the fixed ordered root persists continuously for all sufficiently large L.",
        ),
        (
            "NO_FOLD",
            "Prove F'_L(E_k(L)) != 0 eventually; global Herglotz monotonicity is unavailable.",
        ),
        (
            "SIGNED_PRIMITIVE",
            "Prove Pi_k(L)=int C0/F' = O_k(L^(2-eps)) for some eps>0; O_k(L) is the sharp natural target.",
        ),
        (
            "OR_DIRECT",
            "Alternatively prove conditional convergence of int^infinity [C0/F'] dL/L^2 directly.",
        ),
        (
            "NO_ABSOLUTE_MAJORANT",
            "Do not replace this by |B| or magnitude-only PNT bounds; oscillatory cancellation is part of the theorem.",
        ),
    ]

    for key, txt in remaining:
        print(f"{key:46s}: {txt}")

    upstream_core = bool(
        v418_ok
        and v385_ok
        and v386_ok
        and v387_ok
        and v409_ok
        and v410_ok
        and v411_ok
    )

    theorem_pass = bool(
        algebra_ok
        and upstream_core
    )

    verdict = (
        "EXACT_PRIMITIVE_BETA_NONPERTURBATIVE_CUTOFF_REDUCTION_PASS"
        if theorem_pass
        else
        "PRIMITIVE_BETA_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_NONATTAINED_FIXED_BRANCH_NO_FOLD_AND_SUBQUADRATIC_SIGNED_BETA_PRIMITIVE"
    )

    print("\n" + "="*238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "BOUNDED BETA                             :",
        "VALID SUFFICIENT CONDITION, NOT NECESSARY",
    )
    print(
        "ATTAINED STABLE RESONANCE SECTORS        :",
        "CLOSED / COMPATIBLE WITH PRIMITIVE-BETA RENORMALIZATION",
    )
    print(
        "FINAL FIXED-MODE BOTTLENECK              :",
        "NONATTAINED/SWITCHING SIGNED BETA PRIMITIVE + NO-FOLD",
    )
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           :",
        "NOT YET PROVED GLOBALLY",
    )
    print("="*238)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v418_ok": v418_ok,
            "v385_ok": v385_ok,
            "v386_ok": v386_ok,
            "v387_ok": v387_ok,
            "v409_ok": v409_ok,
            "v410_ok": v410_ok,
            "v411_ok": v411_ok,
        },
        "exact_algebra": {
            "integration_by_parts": ibp,
            "subquadratic_tail": tail,
            "oscillatory_counterexample": counter,
            "bounded_remainder": remainder,
        },
        "hierarchy": {
            key: txt for key, txt in hierarchy
        },
        "attained_sectors": {
            key: txt for key, txt in attained
        },
        "remaining": {
            key: txt for key, txt in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Corrects v418's claim of minimality. Bounded beta remains a valid "
            "strong sufficient condition. The signed primitive-beta theorem "
            "allows unbounded oscillatory beta functions. If Pi=O(L^(2-eps)), "
            "the root flow converges with O(L^-eps) tail. Stable attained "
            "resonance chambers fit the Pi=O(L) class. The unresolved sector is "
            "the nonattained/switching infinite resonance system plus eventual "
            "no-fold/branch persistence."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v419 — primitive-beta non-perturbative cutoff theorem

The exact root flow is

`E_k'(L)=B_k(L)/L^2`.

Define

`Pi_k(L)=int_(L0)^L B_k(s) ds`.

Integration by parts gives

`int_L^T B_k(s)/s^2 ds
 = Pi_k(T)/T^2
   - Pi_k(L)/L^2
   + 2 int_L^T Pi_k(s)/s^3 ds`.

Hence, if

`|Pi_k(L)|<=C_k L^(2-epsilon)`

for some `epsilon>0`, then

`E_k(L)` converges and

`|E_k(infinity)-E_k(L)|
 <= C_k(1+2/epsilon)L^(-epsilon)`.

In particular,

`Pi_k(L)=O_k(L)`

gives the natural `O_k(1/L)` cutoff tail.

Bounded beta is sufficient but not necessary.  For example,

`E(L)=E_*+sin(L)/L`

has

`B(L)=L cos(L)-sin(L)`,

which is unbounded, while

`Pi(L)=L sin(L)+2 cos(L)=O(L)`

and the level converges.

More generally, if

`E(L)=E_*+q(L)/L`

with bounded `q`, then

`B=L q'-q`

and

`Pi=Lq-2 int q + constant=O(L)`.

Thus stable attained mean-motion chambers naturally realize a signed
primitive-beta renormalization even when the instantaneous beta function is
large.

The remaining global theorem is to prove eventual branch persistence/no-fold
and a subquadratic signed beta primitive for the nonattained/switching
infinite resonance system.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_PRIMITIVE_BETA_RENORMALIZATION_CERTIFICATE_V1",
        "already_closed": {
            "exact_flow": "E'=B/L^2",
            "primitive_integration_by_parts": True,
            "subquadratic_primitive_implication": True,
            "unbounded_beta_can_converge": True,
            "single_resonance": "v385",
            "stable_finite_cluster": "v386",
            "attained_infinite_cluster": "v387 under its chamber hypotheses",
        },
        "required_claims": {
            "branch_persistence": "eventual fixed ordered branch",
            "no_fold": "F'_L(E_k(L)) != 0 eventually",
            "signed_beta_primitive": (
                "|int_(L0)^L C0/F' ds| <= C_k L^(2-epsilon)"
            ),
        },
        "preferred_sharp_target": (
            "|Pi_k(L)|<=C_k L"
        ),
        "alternative": (
            "direct convergence of int^infinity [C0/F'] dL/L^2"
        ),
        "forbidden_as_proof": [
            "claiming bounded beta is necessary",
            "absolute-value beta majorant that destroys oscillatory cancellation",
            "global scalar Herglotz monotonicity of raw D_X",
            "known zero ordinates",
            "Xi fitting",
            "finite cutoff extrapolation",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
