#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v418 — NON-PERTURBATIVE BETA-FUNCTION CUTOFF CLOSURE
============================================================

Purpose
-------
Replace the unnecessarily strong sufficient conditions

    |C0(L,E)| = O_k(L),
    positive_part(D1(L,E)) = O_k(L)

by the strictly weaker quantity that the exact root-flow equation actually
needs.

Let L=log X and let a continuous fixed quantized branch satisfy

    F_L(E_k(L)) = const.

The exact v414/v415 cutoff generator is

    partial_L F_L(E) = -C0(L,E)/L^2.

Differentiating the quantization condition gives

    E_k'(L)
      = C0(L,E_k(L))
        / [L^2 F'_L(E_k(L))].

Define the NON-PERTURBATIVE RENORMALIZATION BETA FUNCTION

    B_k(L)
      := C0(L,E_k(L))
         / F'_L(E_k(L)).

Then exactly

    E_k'(L)=B_k(L)/L^2.

Therefore the theorem

    |B_k(L)| <= B_k^*

for all sufficiently large L, together with nonvanishing branch
transversality F'_L != 0, implies

    |E_k(infinity)-E_k(L)|
      <= B_k^*/L.

This proves fixed-mode cutoff independence directly.

This theorem is strictly weaker than separately demanding

    C0=O(L)
    and
    F'_L >= cL.

It permits both numerator and denominator to grow non-perturbatively,
including exponentially, provided their signed ratio remains bounded.

That is precisely the architecture suggested by v385's single-resonance
phase lock and v411's collective phase-lock reduction.

----------------------------------------------------------------------
A. Exact critical-collision beta function
----------------------------------------------------------------------

For a critical-line zero rho=1/2+i gamma of multiplicity m, let

    u=(gamma-E)L.

The recombined Landau collision pair gives

    C0_coll
      = m L (1-cos u)/u.

The collision contribution to the phase stiffness is the real part of

    m R_L(iu/L),

where

    R_L(a)
      = [exp(La)-1-La]/(L a^2).

Exactly,

    Fp_coll
      = m L (1-cos u)/u^2.

Hence, whenever u is not a nonzero multiple of 2*pi,

    C0_coll/Fp_coll = u.

The removable u=0 limit is also 0.

Thus the local critical-collision beta function is EXACTLY

    B_coll = u = (gamma-E)L.

Multiplicity cancels completely.

Consequences:

1. No simple-zero assumption is needed.

2. A generic O(1/L) collision lock

       |E-gamma| <= U/L

   already gives

       |B_coll| <= U

   and therefore

       |E_k(infinity)-E_k(L)| = O(1/L)

   through the exact root-flow theorem.

3. The stronger O(L^-3/2) "superlock" from v417 was only needed to force the
   stronger separate estimate positive_part(D1)=O(L).  It is NOT necessary
   for cutoff independence itself.

4. On |u|<=1,

       (1-cos u)/u^2 >= 11/24,

   so

       Fp_coll >= (11/24)mL > 0.

Thus the local critical collision is both bounded-beta and transverse on the
ordinary O(1/L) locking window.

----------------------------------------------------------------------
B. Why this is the correct non-perturbative theorem
----------------------------------------------------------------------

If an off-critical resonance makes

    C0 ~ exp(delta L)

and simultaneously

    F'_L ~ exp(delta L),

the separate v415 sufficient bounds fail, but

    C0/F'_L = O(1)

may still hold.  Then the level flow remains integrable:

    E_k'(L)=O(L^-2).

So a proof based only on separate polynomial bounds can reject perfectly
renormalizable non-perturbative behavior.

The correct final fixed-mode theorem is therefore:

BETA-BOUND:
    sup_(L>=L0) |C0(L,E_k(L))/F'_L(E_k(L))| < infinity.

NO-FOLD:
    F'_L(E_k(L)) never vanishes on the eventual ordered branch.

Then fixed-mode cutoff independence follows.

----------------------------------------------------------------------
C. Relation to the earlier stronger theorem
----------------------------------------------------------------------

The v415 pair

    |C0|<=K0 L,
    F'_L>=cL

implies

    |B_k|<=K0/c,

so v415 remains a valid sufficient route.

But the converse is false in general.

Therefore v418 does not invalidate v415; it identifies the minimal
non-perturbative quantity needed for cutoff removal.

----------------------------------------------------------------------
D. Remaining global analytic theorem
----------------------------------------------------------------------

The local critical collision is analytically closed.

The still-open RH-strength/global statement is to prove, for the FULL
RECOMBINED signed arithmetic phase on each fixed ordered branch,

    |C0/F'_L| <= B_k^*

and

    F'_L != 0

eventually.

The proof must preserve signed resonance cancellation.  Landau's explicit
formula shows why magnitude-only PNT estimates are insufficient: at
s=1/2+iE, an off-critical zero beta>1/2 contributes a factor
exp[(beta-1/2)L].  But v418 shows such growth is not itself fatal if it occurs
coherently in numerator and stiffness.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO numerical zeta derivatives.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 418
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 418


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def exact_root_flow_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, C0, Fp = sp.symbols(
        "L C0 Fp",
        positive=True,
        real=True,
    )
    B = sp.symbols("B", real=True)

    # partial_L F = -C0/L^2.
    # 0 = partial_L F + Fp E'
    Eprime = C0/(L**2*Fp)
    residual = sp.simplify(
        -C0/L**2 + Fp*Eprime
    )

    beta_identity = sp.simplify(
        Eprime - (C0/Fp)/L**2
    )

    # Tail theorem if |B|<=Bstar.
    Bstar = sp.symbols(
        "Bstar",
        positive=True,
        real=True,
    )
    s = sp.symbols(
        "s",
        positive=True,
        real=True,
    )
    tail = sp.integrate(
        Bstar/s**2,
        (s, L, sp.oo),
    )
    tail_residual = sp.simplify(
        tail-Bstar/L
    )

    return {
        "root_flow": "E_k'=C0/(L^2 F'_L)",
        "beta_function": "B_k=C0/F'_L",
        "renormalized_flow": "E_k'=B_k/L^2",
        "root_flow_residual": str(residual),
        "beta_identity_residual": str(beta_identity),
        "integrated_tail": str(tail),
        "tail_residual": str(tail_residual),
        "pass": bool(
            residual == 0
            and beta_identity == 0
            and tail_residual == 0
        ),
    }


def critical_collision_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    u, L, m = sp.symbols(
        "u L m",
        real=True,
        nonzero=True,
    )

    # Critical recombined collision coordinate a=i u/L.
    a = sp.I*u/L

    R = sp.simplify(
        (sp.exp(L*a)-1-L*a)/(L*a**2)
    )
    Rexp = sp.expand_complex(R)

    Fp_expected = (
        L*(1-sp.cos(u))/u**2
    )
    Fp_resid = sp.simplify(
        sp.re(Rexp)-Fp_expected
    )

    C0 = (
        m*L*(1-sp.cos(u))/u
    )
    Fp = (
        m*L*(1-sp.cos(u))/u**2
    )

    beta = sp.simplify(C0/Fp)
    beta_resid = sp.simplify(beta-u)

    # Removable limits.
    C0_limit = sp.limit(
        m*L*(1-sp.cos(u))/u,
        u,
        0,
    )
    Fp_limit = sp.limit(
        m*L*(1-sp.cos(u))/u**2,
        u,
        0,
    )
    beta_limit = sp.limit(
        u,
        u,
        0,
    )

    return {
        "R_L_critical": str(R),
        "collision_stiffness": (
            "mL(1-cos u)/u^2"
        ),
        "collision_C0": (
            "mL(1-cos u)/u"
        ),
        "beta_collision": str(beta),
        "expected_beta": str(u),
        "Fp_residual": str(Fp_resid),
        "beta_residual": str(beta_resid),
        "C0_u0_limit": str(C0_limit),
        "Fp_u0_limit": str(Fp_limit),
        "beta_u0_limit": str(beta_limit),
        "pass": bool(
            Fp_resid == 0
            and beta_resid == 0
            and C0_limit == 0
            and Fp_limit == m*L/sp.Integer(2)
        ),
    }


def critical_window_inequality_certificate():
    """
    Exact elementary theorem.

    For |u|<=1:
       cos u <= 1-u^2/2+u^4/24
    hence
       1-cos u >= u^2/2-u^4/24
                  >= (11/24)u^2.
    Thus
       (1-cos u)/u^2 >= 11/24.
    """
    return {
        "domain": "|u|<=1",
        "input": (
            "cos u <= 1-u^2/2+u^4/24 "
            "(alternating Taylor bound)"
        ),
        "deduction": (
            "1-cos u >= u^2/2-u^4/24 "
            ">= 11u^2/24"
        ),
        "stiffness_floor": (
            "Fp_coll >= (11/24)mL"
        ),
        "ordinary_lock": (
            "|E-gamma|<=1/L => |u|<=1"
        ),
        "beta_bound": (
            "|B_coll|=|u|<=1"
        ),
        "pass": True,
    }


def logical_strength_check():
    """
    Record that the v415 theorem implies the v418 theorem, but not conversely.
    This is a logical/theorem statement, not a numeric test.
    """
    return {
        "v415_sufficient": (
            "|C0|<=K0 L and F'>=cL "
            "=> |C0/F'|<=K0/c"
        ),
        "converse": False,
        "counterexample_scaling": (
            "C0=e^L, F'=e^L gives beta=1 "
            "while neither separate O(L) bound holds"
        ),
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v415-summary",
        default="rot_rh_multiplicity_robust_generator_v415_SUMMARY.json",
    )
    ap.add_argument(
        "--v416-summary",
        default="rot_rh_generator_G7_head_bridge_v416_SUMMARY.json",
    )
    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument(
        "--v403-summary",
        default="rot_rh_G7_riesz_mellin_collision_v403_SUMMARY.json",
    )
    ap.add_argument(
        "--v411-summary",
        default="rot_rh_collective_phase_lock_v411_SUMMARY.json",
    )

    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_nonperturbative_beta_closure_v418",
    )

    args = ap.parse_args()

    v415 = load_json(args.v415_summary)
    v416 = load_json(args.v416_summary)
    v405 = load_json(args.v405_summary)
    v403 = load_json(args.v403_summary)
    v411 = load_json(args.v411_summary)

    v415_ok = bool(
        v415 is not None
        and v415.get("verdict")
        == "PROSPECTIVE_MULTIPLICITY_ROBUST_GENERATOR_CLOSURE_HOLDOUT_PASS"
    )
    v416_ok = bool(
        v416 is not None
        and v416.get("verdict")
        == "EXACT_GENERATOR_TO_G7_HEAD_EXPLICIT_FORMULA_BRIDGE_PASS"
    )
    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )
    v403_ok = bool(
        v403 is not None
        and v403.get("verdict")
        == "EXACT_G7_RIESZ_MELLIN_COLLISION_REDUCTION_PASS"
    )
    v411_ok = bool(
        v411 is not None
        and v411.get("verdict")
        == "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS"
    )

    print("="*238)
    print("ROT-RH v418 — NON-PERTURBATIVE BETA-FUNCTION CUTOFF CLOSURE")
    print("="*238)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scan accepted as proof            : NO")
    print("="*238)

    print("[1] Upstream")
    print("v415 stronger generator route            :", v415_ok)
    print("v416 generator/head bridge               :", v416_ok)
    print("v405 multiplicity recombination          :", v405_ok)
    print("v403 collision-safe Riesz architecture   :", v403_ok)
    print("v411 collective phase-lock reduction     :", v411_ok)

    print("\n[2] Exact non-perturbative root-flow theorem")

    with tqdm(
        total=4,
        desc="beta-function theorem",
        unit="identity",
    ) as bar:
        rootflow = exact_root_flow_check()
        bar.update(1)

        collision = critical_collision_check()
        bar.update(1)

        window = critical_window_inequality_certificate()
        bar.update(1)

        strength = logical_strength_check()
        bar.update(1)

    print("exact root-flow/beta identity            :", rootflow.get("pass"))
    print("critical collision beta identity         :", collision.get("pass"))
    print("critical locking-window theorem          :", window.get("pass"))
    print("strictly-weaker theorem logic            :", strength.get("pass"))

    algebra_ok = bool(
        rootflow.get("pass")
        and collision.get("pass")
        and window.get("pass")
        and strength.get("pass")
    )

    print("\n[3] Minimal cutoff-independence theorem")

    theorem = [
        (
            "BETA_FUNCTION",
            "B_k(L)=C0(L,E_k(L))/F'_L(E_k(L)).",
        ),
        (
            "EXACT_FLOW",
            "E_k'(L)=B_k(L)/L^2.",
        ),
        (
            "BETA_BOUND",
            "If |B_k(L)|<=B_k^* eventually, the level flow is absolutely integrable.",
        ),
        (
            "TAIL",
            "|E_k(infinity)-E_k(L)|<=B_k^*/L.",
        ),
        (
            "NO_FOLD",
            "F'_L(E_k(L)) must remain nonzero so the ordered branch remains locally unique.",
        ),
        (
            "NONPERTURBATIVE",
            "C0 and F' may both grow; only their signed ratio must remain bounded.",
        ),
    ]

    for key, txt in theorem:
        print(f"{key:46s}: {txt}")

    print("\n[4] Exact critical-collision closure")

    critical = [
        (
            "u",
            "u=(gamma-E)L.",
        ),
        (
            "C0_COLL",
            "C0_coll=mL(1-cos u)/u.",
        ),
        (
            "FP_COLL",
            "F'_coll=mL(1-cos u)/u^2.",
        ),
        (
            "BETA_COLL",
            "C0_coll/F'_coll=u exactly; multiplicity cancels.",
        ),
        (
            "ORDINARY_LOCK",
            "|E-gamma|<=1/L gives |B_coll|<=1.",
        ),
        (
            "SLOPE_FLOOR",
            "|u|<=1 gives F'_coll>=(11/24)mL.",
        ),
        (
            "SUPERLOCK_NOT_NEEDED",
            "O(L^-3/2) locking is only needed for the stronger separate D1=O(L) route, not for cutoff independence.",
        ),
    ]

    for key, txt in critical:
        print(f"{key:46s}: {txt}")

    print("\n[5] Remaining global analytic theorem")

    remaining = [
        (
            "FULL_RECOMBINED_BETA",
            "Prove sup_L |C0/F'_L|<infinity on each eventual fixed ordered root branch.",
        ),
        (
            "NO_SLOPE_ZERO",
            "Prove F'_L does not vanish on that eventual branch.",
        ),
        (
            "SIGNED_STRUCTURE",
            "The proof must use the full recombined signed arithmetic phase; magnitude-only PNT estimates are too weak.",
        ),
        (
            "OFFCRITICAL_ALLOWED",
            "Off-critical exponential growth is not automatically fatal if numerator and stiffness share it coherently.",
        ),
        (
            "RELATION_TO_V411",
            "Persistent collective phase lock is now interpreted as bounded renormalized beta function rather than separately bounded generators.",
        ),
    ]

    for key, txt in remaining:
        print(f"{key:46s}: {txt}")

    upstream_exact = bool(
        v405_ok
        and v403_ok
        and v411_ok
    )

    # v415/v416 are useful lineage, but the exact v418 theorem does not
    # logically require their finite holdout verdicts.
    theorem_pass = bool(
        algebra_ok
        and upstream_exact
    )

    verdict = (
        "EXACT_NONPERTURBATIVE_BETA_FUNCTION_CUTOFF_CLOSURE_REDUCTION_PASS"
        if theorem_pass
        else
        "NONPERTURBATIVE_BETA_FUNCTION_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_FULL_RECOMBINED_FIXED_BRANCH_BETA_BOUND_AND_NO_FOLD"
    )

    print("\n" + "="*238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "CRITICAL COLLISION                       :",
        "ANALYTICALLY BOUNDED-BETA UNDER ORDINARY O(1/L) LOCK",
    )
    print(
        "STRONG v415 SEPARATE BOUNDS              :",
        "SUFFICIENT BUT NO LONGER REQUIRED",
    )
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           :",
        "FOLLOWS ONCE GLOBAL BETA-BOUND + NO-FOLD ARE PROVED",
    )
    print(
        "GLOBAL ANALYTIC BETA BOUND               :",
        "NOT YET PROVED",
    )
    print("="*238)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v415_ok": v415_ok,
            "v416_ok": v416_ok,
            "v405_ok": v405_ok,
            "v403_ok": v403_ok,
            "v411_ok": v411_ok,
        },
        "exact_root_flow": rootflow,
        "critical_collision": collision,
        "critical_window": window,
        "logical_strength": strength,
        "minimal_theorem": {
            key: txt for key, txt in theorem
        },
        "critical_closure": {
            key: txt for key, txt in critical
        },
        "remaining": {
            key: txt for key, txt in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact non-perturbative cutoff-removal implication. The minimal "
            "quantity is the beta function B_k=C0/F'. A bounded beta function "
            "gives E_k'=O(L^-2) and hence fixed-mode cutoff independence. "
            "The critical collision has B_coll=(gamma-E)L exactly, so ordinary "
            "O(1/L) locking is sufficient locally. The still-open theorem is "
            "global boundedness of the full recombined beta function together "
            "with exclusion of slope folds."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v418 — non-perturbative beta-function cutoff theorem

Let `L=log X` and let the fixed ordered branch satisfy

`F_L(E_k(L))=constant`.

Since

`partial_L F_L(E)=-C0(L,E)/L^2`,

implicit differentiation gives

`E_k'(L)=C0(L,E_k(L))/[L^2 F'_L(E_k(L))]`.

Define

`B_k(L)=C0/F'_L`.

Then exactly

`E_k'(L)=B_k(L)/L^2`.

Therefore, if

`sup_(L>=L0)|B_k(L)|<=B_k^*`

and `F'_L` never vanishes on the eventual branch, then

`|E_k(infinity)-E_k(L)|<=B_k^*/L`.

This is strictly weaker than requiring separately

`|C0|=O(L)`

and

`F'_L>=cL`.

For a critical collision of multiplicity `m`, with

`u=(gamma-E)L`,

the exact recombined collision kernel gives

`C0_coll=mL(1-cos u)/u`

and

`F'_coll=mL(1-cos u)/u^2`.

Hence

`B_coll=u`

exactly, with removable limit zero at `u=0`.

Thus an ordinary collision lock

`|E-gamma|=O(1/L)`

already gives a bounded local beta function and the integrable root flow
needed for cutoff independence.  The stronger `O(L^-3/2)` superlock is only
needed for the stronger separate `positive_part(D1)=O(L)` route.

The remaining theorem is global: prove boundedness of the FULL recombined
signed beta function and exclude slope folds.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_NONPERTURBATIVE_BETA_FUNCTION_CERTIFICATE_V1",
        "already_closed": {
            "root_flow": "E_k'=B_k/L^2",
            "tail_integral": "|E_inf-E(L)|<=Bstar/L",
            "critical_collision_beta": "B_coll=(gamma-E)L",
            "critical_O1_over_L_lock": "sufficient locally",
            "multiplicity": "cancels from local beta ratio",
        },
        "required_claims": {
            "global_beta_bound": (
                "sup_L |C0(L,E_k(L))/F'_L(E_k(L))| < infinity"
            ),
            "no_fold": (
                "F'_L(E_k(L)) != 0 eventually"
            ),
            "branch_persistence": (
                "fixed ordered branch exists continuously for all sufficiently large L"
            ),
        },
        "allowed_inputs": [
            "exact Riesz generator identity",
            "v405 multiplicity-safe recombination",
            "v403 collision-safe Riesz kernel",
            "v411 collective phase-lock algebra",
            "Selberg/Volterra recursive structure",
        ],
        "forbidden_as_proof": [
            "separate generator bounds treated as necessary",
            "simple-zero assumption",
            "magnitude-only PNT majorant",
            "known zero ordinates",
            "Xi fitting",
            "finite cutoff extrapolation",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
