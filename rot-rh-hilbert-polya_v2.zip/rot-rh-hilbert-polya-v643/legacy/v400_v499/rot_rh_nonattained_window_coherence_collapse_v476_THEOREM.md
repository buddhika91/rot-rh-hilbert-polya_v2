# ROT-RH v476 — nonattained window-lock implies coherence collapse

At a large base cutoff `t`, write

`H_t(s)=sum a_j(t)e^(-delta_j s)e^(i gamma_j s)`,
`0<=s<=h`,

and

`W0=sum|a_j|`.

The nonattained sector has:

1. for every fixed `M`,
   `sum_(gamma_j<=M)|a_j|/W0 ->0`;

2. for every fixed `eps>0`,
   `sum_(delta_j>=eps)|a_j|/W0 ->0`,
   hence `sum delta_j|a_j|/W0->0`.

Therefore the amplitudes freeze on fixed windows:

`sup_(0<=s<=h)|H_t(s)-sum a_j e^(i gamma_j s)|/W0 ->0`.

For every `phi in C_c^infinity(0,h)`,

`int phi(s) sum a_j e^(i gamma_j s) ds
 =sum a_j phi_hat(-gamma_j)`.

Fourier decay plus absolute frequency escape gives

`(1/W0) int phi H_t ->0`.

Now assume a shrinking phase-sector lock: after multiplication by a bounded
carrier and one constant phase rotation,

`|arg Z_t(s)|<=eps_t`,
`eps_t->0`.

For every nonnegative interior test function,

`Re Z_t(s)>=cos(eps_t)|H_t(s)|`.

But the test integral of `Z_t/W0` tends to zero. Hence

`(1/W0) int phi(s)|H_t(s)| ds ->0`.

So a genuinely nonattained family satisfying the v411 short-window phase lock
must undergo **window-averaged normalized coherence collapse**.

This rules out the complete noncollapsed broad-band alternative left by v474.

**Verdict:** EXACT_NONATTAINED_WINDOW_LOCK_COHERENCE_COLLAPSE_PASS

Remaining theorem: show this persistent window coherence collapse contradicts
fixed-action-label transversality/no-fold, or derive its signed primitive-beta
law.
