#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v433 — OPERATOR-TO-COMPLEX-FORCING BRIDGE / SELF-ADJOINTNESS NO-GO
=========================================================================

Purpose
-------
v432 isolates the complex dyadic forcing

    J_X(E) = J_L^C(E),   L=log X,

and reduces RH to proving that J_X(E) is uniformly bounded in X for each
fixed real E, within the classical explicit-formula framework.

The next question is NOT whether H_X is self-adjoint at each fixed X.
That theorem is already known.

The actual missing bridge is:

    how does the scalar arithmetic forcing J_X(E)
    arise as a uniformly bounded observable of H_X and H_(2X)?

v433 separates three logical statements.

A. What fixed-cutoff self-adjointness really gives
--------------------------------------------------
For a self-adjoint H and z with Im z = eta != 0,

    ||(H-z)^(-1)|| <= 1/|eta|.

Therefore for any two self-adjoint operators H0,H1,

    ||R1(z)-R0(z)|| <= 2/|eta|.

But this does NOT bound an arbitrary trace observable.  If P_N is a rank-N
projection and H=0, then

    Tr[P_N(H-i)^(-1)] = i N,

which diverges although H is self-adjoint and its resolvent norm is 1.

Thus self-adjointness alone is insufficient.

B. A sufficient MATRIX-ELEMENT bridge
--------------------------------------
If one can prove EXACTLY that

    J_X(E)
      = <u_X(E),
          [R_(2X)(z_E)-R_X(z_E)]
          v_X(E)>,

where

    inf_X |Im z_E| >= eta_E > 0,
    sup_X ||u_X(E)|| <= U_E,
    sup_X ||v_X(E)|| <= V_E,

then immediately

    |J_X(E)|
      <= 2 U_E V_E / eta_E.

This would close the v432 bounded-forcing theorem.

C. A sufficient TRACE-CLASS bridge
-----------------------------------
More generally, if

    J_X(E)
      = Tr(
          B_X(E)
          [R_(2X)(z_E)-R_X(z_E)]
        )

with

    sup_X ||B_X(E)||_1 <= T_E,

then

    |J_X(E)|
      <= ||B_X||_1 ||Delta R_X||
      <= 2 T_E / eta_E.

An alternative is

    sup_X ||Delta R_X||_1 <= C_E,
    sup_X ||B_X(E)|| <= M_E,

which gives

    |J_X(E)| <= M_E C_E.

What v433 proves
----------------
1. The operator inequalities above.
2. A concrete counterexample showing fixed-X self-adjointness does NOT by
   itself control trace-type forcing.
3. The existing fixed-cutoff ROT-RH theorem is N->infinity at fixed X;
   it does not prove X->infinity resolvent convergence.
4. The simple full-centered Schur/Herglotz route is not allowed as a generic
   substitute if the v273 finite audit failed.
5. v432's observed finite forcing is checked only for compatibility with the
   generic self-adjoint matrix-element envelope 2/eta.  Compatibility is NOT
   evidence that the required representation exists.

The exact next theorem is therefore:

    CONSTRUCT AN EXACT OPERATOR OBSERVABLE REPRESENTATION OF J_X(E)

using only the zero-free arithmetic operator, and then prove uniform vector /
trace-class control.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO finite compatibility check accepted as proof.

Version: 433
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 433


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    eta, U, V, T, M, C = sp.symbols(
        "eta U V T M C",
        positive=True,
        real=True,
    )

    # These are norm inequalities, so the symbolic part records their scalar
    # envelope algebra rather than pretending SymPy proves the spectral theorem.
    single_resolvent = 1/eta
    resolvent_difference = sp.simplify(
        single_resolvent + single_resolvent
    )
    matrix_element = sp.simplify(
        U*V*resolvent_difference
    )
    trace_class_weight = sp.simplify(
        T*resolvent_difference
    )
    trace_class_resolvent = sp.simplify(
        M*C
    )

    return {
        "self_adjoint_resolvent": "||R_H(z)||<=1/|Im z|",
        "dyadic_resolvent_difference": "||R_1-R_0||<=2/|Im z|",
        "matrix_element_bound": str(matrix_element),
        "trace_class_weight_bound": str(trace_class_weight),
        "trace_class_resolvent_bound": str(trace_class_resolvent),
        "counterexample": (
            "H=0 on l2, P_N rank N: "
            "Tr[P_N(H-i)^(-1)]=iN -> infinity"
        ),
        "counterexample_meaning": (
            "self-adjointness + bounded resolvent norm does not control "
            "trace observables whose trace-class mass grows"
        ),
        "pass": bool(
            sp.simplify(resolvent_difference-2/eta) == 0
            and sp.simplify(matrix_element-2*U*V/eta) == 0
            and sp.simplify(trace_class_weight-2*T/eta) == 0
            and sp.simplify(trace_class_resolvent-M*C) == 0
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v432-summary",
        default="rot_rh_complex_dyadic_forcing_laplace_pole_v432_SUMMARY.json",
    )
    ap.add_argument(
        "--v432-shells",
        default="rot_rh_complex_dyadic_forcing_laplace_pole_v432_SHELL_SUMMARY.csv",
    )
    ap.add_argument(
        "--fixed-operator-summary",
        default="rot_rh_fixed_cutoff_infinite_operator_theorem_summary.json",
    )
    ap.add_argument(
        "--v273-summary",
        default="rot_rh_full_centered_schur_herglotz_v273_SUMMARY.json",
        help="Optional; if absent the Herglotz route is reported as unknown from this run.",
    )
    ap.add_argument(
        "--resolvent-imag",
        type=float,
        default=0.5,
        help="Generic nonreal spectral height eta used only for a compatibility envelope.",
    )
    ap.add_argument(
        "--unit-vector-norm-cap",
        type=float,
        default=1.0,
        help="Hypothetical matrix-element vector norm cap for compatibility only.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_operator_complex_forcing_bridge_v433",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.resolvent_imag <= 0:
        raise ValueError("--resolvent-imag must be positive")
    if args.unit_vector_norm_cap <= 0:
        raise ValueError("--unit-vector-norm-cap must be positive")

    started = time.time()

    v432 = load_json(args.v432_summary)
    fixed = load_json(args.fixed_operator_summary)
    v273 = load_json(args.v273_summary)

    v432_ok = bool(
        v432 is not None
        and v432.get("verdict")
        == "EXACT_COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_PASS"
    )
    fixed_ok = bool(
        fixed is not None
        and fixed.get("verdict")
        == "PASS_FIXED_CUTOFF_INFINITE_SELF_ADJOINT_AND_DEPTH_STRONG_RESOLVENT_GLOBAL_PRIME_LIMIT_OPEN"
    )

    v273_mechanism = (
        None if v273 is None
        else v273.get("mechanism")
    )
    simple_herglotz_failed = bool(
        v273 is not None
        and (
            v273.get("mechanism")
            == "FULL_CENTERED_REGULARIZED_SCHUR_HERGLOTZ_FAILS_FINITE_AUDIT"
            or "FAIL" in str(v273.get("verdict", "")).upper()
        )
    )

    print("=" * 230)
    print("ROT-RH v433 — OPERATOR-TO-COMPLEX-FORCING BRIDGE / SELF-ADJOINTNESS NO-GO")
    print("=" * 230)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("finite compatibility accepted as proof   : NO")
    print("=" * 230)

    print("[1] Upstream theorem state")
    print(
        "v432 Laplace-pole reduction             :",
        v432_ok,
        None if v432 is None else v432.get("verdict"),
    )
    print(
        "fixed-X infinite self-adjoint operator  :",
        fixed_ok,
        None if fixed is None else fixed.get("verdict"),
    )
    print(
        "fixed-X theorem prime-cutoff limit open :",
        None if fixed is None
        else not bool(
            fixed.get("gates", {}).get(
                "prime_cutoff_limit_strong_resolvent_proved",
                False,
            )
        ),
    )
    print(
        "simple centered Herglotz route failed   :",
        simple_herglotz_failed,
        v273_mechanism,
    )

    print("\n[2] Exact operator inequalities / no-go")
    sym = symbolic_checks()
    with tqdm(total=4, desc="operator bridge lemmas", unit="lemma") as bar:
        for _ in range(4):
            bar.update(1)
    print("symbolic envelope algebra pass           :", sym.get("pass"))
    print(
        "self-adjoint resolvent bound             :",
        sym.get("self_adjoint_resolvent"),
    )
    print(
        "dyadic resolvent difference              :",
        sym.get("dyadic_resolvent_difference"),
    )
    print(
        "counterexample                          :",
        sym.get("counterexample"),
    )
    print(
        "SELF-ADJOINTNESS ALONE                   : INSUFFICIENT"
    )

    # ------------------------------------------------------------------
    # Finite v432 compatibility only
    # ------------------------------------------------------------------
    shell_path = Path(args.v432_shells)
    finite = {}
    if shell_path.exists():
        sdf = pd.read_csv(shell_path)
        if "max_abs_J_complex" in sdf.columns and len(sdf):
            max_J = float(
                np.max(
                    np.abs(
                        sdf["max_abs_J_complex"].to_numpy(float)
                    )
                )
            )
            eta = float(args.resolvent_imag)
            U = float(args.unit_vector_norm_cap)
            matrix_envelope = 2.0*U*U/eta
            finite = {
                "maximum_observed_abs_J_complex": max_J,
                "hypothetical_unit_vector_matrix_element_envelope": matrix_envelope,
                "compatible": bool(max_J <= matrix_envelope),
                "proof_status": (
                    "COMPATIBILITY_ONLY_NO_OPERATOR_REPRESENTATION_ESTABLISHED"
                ),
            }
        else:
            finite = {"available": False}
    else:
        finite = {"available": False}

    print("\n[3] Finite compatibility only")
    if finite.get("available") is False:
        print("v432 shell table                         : unavailable")
    else:
        print(
            "maximum observed |J_complex|            :",
            f"{finite['maximum_observed_abs_J_complex']:.12e}",
        )
        print(
            "hypothetical matrix-element envelope    :",
            f"{finite['hypothetical_unit_vector_matrix_element_envelope']:.12e}",
        )
        print(
            "numerically compatible                  :",
            finite["compatible"],
        )
        print(
            "representation proved                   : False"
        )

    # ------------------------------------------------------------------
    # Bridge hierarchy
    # ------------------------------------------------------------------
    bridges = {
        "matrix_element_bridge": {
            "identity_needed": (
                "J_X(E)=<u_X(E), [R_(2X)(z_E)-R_X(z_E)] v_X(E)>"
            ),
            "uniform_control_needed": (
                "inf |Im z_E|>=eta_E>0, sup||u_X||<=U_E, sup||v_X||<=V_E"
            ),
            "consequence": "|J_X(E)|<=2 U_E V_E/eta_E",
            "status": "OPEN_EXACT_REPRESENTATION_NOT_YET_DERIVED",
        },
        "trace_class_weight_bridge": {
            "identity_needed": (
                "J_X(E)=Tr(B_X(E)[R_(2X)(z_E)-R_X(z_E)])"
            ),
            "uniform_control_needed": "sup_X ||B_X(E)||_1<=T_E",
            "consequence": "|J_X(E)|<=2 T_E/eta_E",
            "status": "OPEN_EXACT_REPRESENTATION_NOT_YET_DERIVED",
        },
        "trace_norm_resolvent_bridge": {
            "identity_needed": (
                "J_X(E)=Tr(B_X(E) Delta R_X(z_E))"
            ),
            "uniform_control_needed": (
                "sup||B_X||<=M_E and sup||Delta R_X||_1<=C_E"
            ),
            "consequence": "|J_X(E)|<=M_E C_E",
            "status": "OPEN_X_TO_INFINITY_TRACE_NORM_THEOREM_NOT_YET_DERIVED",
        },
    }

    exact_logic_pass = bool(
        sym.get("pass")
        and v432_ok
        and fixed_ok
    )

    verdict = (
        "EXACT_OPERATOR_COMPLEX_FORCING_BRIDGE_REQUIREMENTS_PASS_SELF_ADJOINTNESS_ALONE_NO_GO"
        if exact_logic_pass
        else
        "OPERATOR_COMPLEX_FORCING_BRIDGE_REQUIREMENTS_INCOMPLETE"
    )
    next_theorem = (
        "CONSTRUCT_EXACT_JCOMPLEX_AS_DYADIC_RESOLVENT_MATRIX_ELEMENT_OR_TRACE_CLASS_OBSERVABLE"
    )

    print("\n[4] Exact bridge target")
    print(
        "preferred minimal bridge                :",
        bridges["matrix_element_bridge"]["identity_needed"],
    )
    print(
        "if proved                               :",
        bridges["matrix_element_bridge"]["consequence"],
    )
    print(
        "current status                           :",
        bridges["matrix_element_bridge"]["status"],
    )

    print("\n" + "=" * 230)
    print("VERDICT                                   :", verdict)
    print(
        "FIXED-X SELF-ADJOINTNESS                  : PROVED UPSTREAM"
    )
    print(
        "X->INFINITY OPERATOR BRIDGE               : OPEN"
    )
    print(
        "SIMPLE SCHUR/HERGLOTZ SUBSTITUTE          :",
        (
            "RULED OUT BY v273 FINITE AUDIT"
            if simple_herglotz_failed
            else "NOT USED / NOT CERTIFIED HERE"
        ),
    )
    print(
        "BOUND |J_complex|                         : NOT PROVED"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 230)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_compatibility_accepted_as_proof": False,
        },
        "upstream": {
            "v432_ok": v432_ok,
            "v432_verdict": None if v432 is None else v432.get("verdict"),
            "fixed_operator_ok": fixed_ok,
            "fixed_operator_verdict": None if fixed is None else fixed.get("verdict"),
            "simple_centered_herglotz_failed": simple_herglotz_failed,
            "v273_mechanism": v273_mechanism,
        },
        "operator_lemmas": sym,
        "finite_compatibility": finite,
        "bridge_options": bridges,
        "logical_conclusion": {
            "self_adjointness_alone_sufficient": False,
            "reason": (
                "resolvent operator norm does not control arbitrary or growing-rank "
                "trace observables; an exact J_complex operator representation plus "
                "uniform vector/trace-class control is required"
            ),
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v433 — operator bridge theorem

For any self-adjoint operator `H` and `z` with `Im z != 0`,

`||(H-z)^(-1)|| <= 1/|Im z|`.

Hence for two self-adjoint cutoff operators,

`||R_(2X)(z)-R_X(z)|| <= 2/|Im z|`.

This by itself does **not** bound a trace observable.  On `l2`, take `H=0`
and let `P_N` be the rank-`N` projection.  Then

`Tr[P_N(H-i)^(-1)] = iN`,

which diverges while `H` is self-adjoint and `||(H-i)^(-1)||=1`.

Therefore the already-proved fixed-cutoff self-adjointness theorem is not
the missing RH step.

A sufficient minimal bridge would be an exact identity

`J_X(E)
 = <u_X(E), [R_(2X)(z_E)-R_X(z_E)] v_X(E)>`

with

`inf_X |Im z_E|>=eta_E>0`,
`sup_X ||u_X(E)||<=U_E`,
`sup_X ||v_X(E)||<=V_E`.

Then

`|J_X(E)| <= 2 U_E V_E / eta_E`.

A trace version is also sufficient:

`J_X(E)=Tr(B_X(E) Delta R_X(z_E))`

and either

`sup ||B_X||_1<=T_E`

or

`sup ||B_X||<=M_E`, `sup ||Delta R_X||_1<=C_E`.

The next mathematical task is therefore not more fixed-X self-adjointness
and not generic Herglotz positivity.  It is to derive the exact arithmetic
complex forcing as one of these controlled operator observables without using
RH, Xi fitting, known zero ordinates, or an RH-equivalent prime-error theorem.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_EXACT_JCOMPLEX_OPERATOR_OBSERVABLE_BRIDGE_V1",
        "required_claim": {
            "proved": False,
            "statement": (
                "Construct from the zero-free arithmetic operator an exact identity "
                "representing J_X^C(E) as a dyadic resolvent matrix element or "
                "trace-class observable."
            ),
        },
        "preferred_matrix_element_form": {
            "identity": (
                "J_X^C(E)=<u_X(E), [R_(2X)(z_E)-R_X(z_E)] v_X(E)>"
            ),
            "uniform_bounds": [
                "inf_X |Im z_E|>0",
                "sup_X ||u_X(E)||<infinity",
                "sup_X ||v_X(E)||<infinity",
            ],
        },
        "alternative_trace_form": {
            "identity": (
                "J_X^C(E)=Tr(B_X(E)[R_(2X)(z_E)-R_X(z_E)])"
            ),
            "uniform_bounds": [
                "sup_X ||B_X(E)||_1<infinity",
                "or sup_X ||B_X(E)||<infinity and sup_X ||Delta R_X||_1<infinity",
            ],
        },
        "forbidden_shortcuts": [
            "fixed-X self-adjointness alone",
            "fixed-X depth strong-resolvent convergence alone",
            "simple full-centered Schur/Herglotz positivity if v273 has failed",
            "assume bounded J_complex",
            "assume RH",
            "known zero ordinates",
            "Xi fitting",
        ],
        "consequence": (
            "exact controlled operator bridge => bounded J_complex; "
            "v432 Laplace-pole theorem then gives RH"
        ),
    }
    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not exact_logic_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
