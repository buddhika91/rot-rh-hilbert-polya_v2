# ROT-RH v469 — canonical complex bump-2 half-phase characteristic

## 1. Canonical complex primitive

Let `a=log2` and

`dmu(y)=dpsi(e^y)-e^y dy`.

Define

`Q_L(z)
 = int_[a,L) p(y/L)e^(-y/2+i z y)dmu(y)/y`.

For real `E`,

`Q_L(-E)=conj(Q_L(E))`

and

`Im Q_L(E)=P_L(E)-M_L(E)`.

The current bump finite-part law is

`P_L^FP=P_L-M_L+M_inf^AC`.

Therefore, with

`Phi_ref(E)=theta(E)+pi-M_inf^AC(E)`,

we have exactly

`pi F_L(E)=Phi_ref(E)-Im Q_L(E)`.

## 2. Multiplicative half-phase lift

Define

`r_L(z)=exp(-(Q_L(z)-Q_L(-z))/2)`.

For real `E`,

`r_L(E)=exp(-i Im Q_L(E))`

and hence

`V_L(E)=exp(i Phi_ref(E)) r_L(E)=exp(i pi F_L(E))`.

Therefore

`F_L(E)=k-1/2`

iff

`cos(pi F_L(E))=0`

iff

`V_L(E)^2=-1`.

This is the exact scalar multiplicative lift of the bump-2 secular phase.

## 3. Exact cutoff ODE

Because `q=-p'` and the bump is flat at its endpoint,

`partial_L Q_L(z)=C_q^C(L,z)/L^2`.

Consequently

`partial_L log r_L(z)
 =-[C_q^C(L,z)-C_q^C(L,-z)]/(2L^2)`.

On the real axis,

`partial_L log r_L(E)=-i C_q(L,E)/L^2`.

Thus the signed v459 wavelet generator is literally the logarithmic cutoff
generator of the canonical half-phase characteristic.

## 4. Collision/regular factorization

If

`Im Q_L=B_coll+B_reg`,

then exactly

`r_L=e^(-iB_coll)e^(-iB_reg)`.

So the v465 relative phase

`R_L/|R_L|=e^(i pi epsilon_L)`

has a canonical realization as the collision-subtracted bump half-phase
multiplier, up to the fixed secular sign convention.

No Fredholm/determinant assumption is needed for this scalar factorization.

## 5. Signed-primitive criterion

At fixed real `E`, write

`phi_reg'(L,E)=-C_reg(L,E)/L^2`

and

`Pi_reg(L,E)=int_(L0)^L C_reg(s,E) ds`.

Integration by parts gives

`int_L^T C_reg(s,E)/s^2 ds
 =Pi_reg(T,E)/T^2-Pi_reg(L,E)/L^2
  +2 int_L^T Pi_reg(s,E)/s^3 ds`.

Hence

* `Pi_reg=O(L^(2-eps))`, `eps>0`, gives a phase tail `O(L^-eps)`;
* `Pi_reg=O(L)` gives a phase tail `O(1/L)`.

This is the correct signed target. A pointwise `|C_reg|=O(L)` estimate alone
would give only a logarithmic absolute bound and is not the right theorem.

## 6. Status

The multiplicative lift and cutoff ODE are exact.

Still open:

1. a branch-local/tube-uniform signed primitive estimate for the recombined
   regular generator;
2. identification of its limiting phase class with the canonical midpoint;
3. fixed-mode cutoff independence;
4. operator promotion and the Fredholm-Xi identity.

No Xi values, numerical zeta values, known zero ordinates, or finite regression
enter this theorem.
