#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v416 — GENERATOR / HARD-PREFIX JET / G7-HEAD EXPLICIT-FORMULA BRIDGE
===========================================================================

Purpose
-------
Identify exactly where the two remaining v415 all-L bounds live in the
recursive construction and in the classical explicit formula.

This is NOT another finite extrapolation.

It proves/reduces:

1. The cutoff generator C0 differs by a uniformly bounded Euler-summation
   discrepancy from the FIRST hard-prefix E-jet of the centered recursive
   fixed point

       x_n=(Lambda(n)-1)/(sqrt(n) log n).

2. C1 differs by a uniformly bounded Euler discrepancy from the SECOND
   hard-prefix E-jet.

3. v402/v403 already close the differentiated regular R^7 cascade; therefore
   the unresolved all-L generator theorem is the same finite G7-head theorem
   previously isolated by the Mellin-Volterra/Riesz analysis.

4. Landau's explicit formula explains why ordinary PNT estimates cannot prove
   the desired bound and why the multiplicity-robust one-sided D1 condition is
   the correct collision normalization.

No zeta values or zero ordinates are numerically evaluated.

----------------------------------------------------------------------
A. Euler bridge
----------------------------------------------------------------------

Let N>=2 and E lie in a fixed compact interval |E|<=Emax.

Define

    f0_E(t)=t^(-1/2) sin(E log t).

Then

    C0(log N,E)
      = sum_(n<=N) [Lambda(n)-1]/sqrt(n) sin(E log n)
        + R0(N,E),

where

    R0
      = sum_(n<=N) f0_E(n) - int_2^N f0_E(t)dt

up to the harmless convention at the final endpoint.

A cellwise Euler estimate gives

    |R0|
      <= sup_(t>=2)|f0_E(t)|
         + int_2^infty |f0_E'(t)|dt

      <= 1/sqrt(2)
         + sqrt(2)*sqrt(Emax^2+1/4).

Hence R0=O_I(1) uniformly in N.

Likewise

    f1_E(t)=log(t)t^(-1/2) cos(E log t)

gives

    C1(log N,E)
      = sum_(n<=N)
          [Lambda(n)-1] log(n)/sqrt(n) cos(E log n)
        + R1(N,E),

with R1=O_I(1).

One explicit bound is

    |R1|
      <= 2/e
         + sqrt(2)
         + sqrt(2)*(Emax+1/2)*(log 2+2).

----------------------------------------------------------------------
B. Hard-prefix jets of x
----------------------------------------------------------------------

For

    x_n=(Lambda(n)-1)/(sqrt(n)log n),

define the real hard-prefix jets

    J1(N,E;x)
      = sum_(n<=N) log(n)x_n sin(E log n),

    J2(N,E;x)
      = sum_(n<=N) log(n)^2 x_n cos(E log n).

Then exactly

    C0(log N,E)=J1(N,E;x)+O_I(1),

    C1(log N,E)=J2(N,E;x)+O_I(1).

Thus v415 becomes

    |J1(N,E;x)| = O_k(log N),

and

    positive_part[
      J2(N,E;x) + (log N)^2/2
    ] = O_k(log N),

on the eventual fixed-k tube.

----------------------------------------------------------------------
C. Recursive decomposition
----------------------------------------------------------------------

The exact fixed point is

    x = G7 + R^7 x.

v402 closes the regular differentiated R^7 cascade in weighted factorial
four-jet geometry.

v403 explicitly records that, after that closure, the remaining head theorem
is the collision-subtracted G7 Mellin/Riesz contour estimate.

Therefore the v415 generator bounds are not new independent mysteries:
they are the hard-prefix first/second-jet formulation of the same G7-head
obstruction.

----------------------------------------------------------------------
D. Landau explicit-formula collision
----------------------------------------------------------------------

For s not at a singular point, Landau's formula has the structure

    sum_(n<=x)' Lambda(n)n^(-s)
      = x^(1-s)/(1-s)
        - zeta'(s)/zeta(s)
        - sum_rho m_rho x^(rho-s)/(rho-s)
        + trivial-zero terms.

Subtracting the smooth x^(1-s)/(1-s) term leaves the centered generator.

Near one zero rho of multiplicity m, put

    a=rho-s.

The local combination of the log-derivative pole and the zero residue is

    m/a - m exp(aL)/a
      = m(1-exp(aL))/a.

Taylor expansion:

    m(1-exp(aL))/a
      = -mL
        - (m/2)aL^2
        - (m/6)a^2L^3
        + ...

At a critical-line collision rho=1/2+i gamma and s=1/2+iE,

    a=i(gamma-E).

With the v414/v415 real convention this gives

    C1(L,gamma)
      = -m L^2/2 + lower-order terms,

and hence

    D1(L,gamma)
      = C1 + L^2/2
      = -(m-1)L^2/2 + lower-order terms.

Therefore:
  * m=1: the L^2/2 collision term cancels;
  * m>1: D1 has a large NEGATIVE leading term, strengthening the slope;
  * only the POSITIVE part of D1 is dangerous.

This exactly justifies the multiplicity-robust v415 theorem.

For beta>1/2, the factor

    exp[(beta-1/2)L]

appears.  Thus a magnitude-only classical PNT bound cannot prove the desired
critical-line generator theorem.  Signed/root-conditioned cancellation is
essential.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO numerical zeta derivatives.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 416
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from tqdm import tqdm

VERSION = 416


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_collision_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    a, L, m = sp.symbols(
        "a L m",
        nonzero=True,
    )

    expr = m*(1-sp.exp(a*L))/a
    series = sp.series(expr, a, 0, 4)

    expected = (
        -m*L
        - m*a*L**2/sp.Integer(2)
        - m*a**2*L**3/sp.Integer(6)
        - m*a**3*L**4/sp.Integer(24)
    )

    expanded = sp.expand(
        series.removeO()
    )
    residual = sp.simplify(
        expanded-expected
    )

    return {
        "collision_function": str(expr),
        "series": str(series),
        "residual_through_a3": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_multiplicity_D1_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    m, L = sp.symbols(
        "m L",
        positive=True,
        real=True,
    )

    C1_lead = -m*L**2/sp.Integer(2)
    D1_lead = sp.simplify(
        C1_lead + L**2/sp.Integer(2)
    )
    expected = -(m-1)*L**2/sp.Integer(2)
    residual = sp.simplify(
        D1_lead-expected
    )

    return {
        "C1_collision_leading": str(C1_lead),
        "D1_collision_leading": str(D1_lead),
        "simple_zero_m1": str(
            sp.simplify(D1_lead.subs(m, 1))
        ),
        "double_zero_m2": str(
            sp.simplify(D1_lead.subs(m, 2))
        ),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def euler_bounds(Emax):
    Emax = abs(float(Emax))

    B0 = (
        1.0/math.sqrt(2.0)
        + math.sqrt(2.0)
        * math.sqrt(Emax*Emax+0.25)
    )

    B1 = (
        2.0/math.e
        + math.sqrt(2.0)
        + math.sqrt(2.0)
        * (Emax+0.5)
        * (math.log(2.0)+2.0)
    )

    return {
        "Emax": Emax,
        "R0_uniform_bound": B0,
        "R1_uniform_bound": B1,
        "R0_formula": (
            "1/sqrt(2)+sqrt(2)*sqrt(Emax^2+1/4)"
        ),
        "R1_formula": (
            "2/e+sqrt(2)+sqrt(2)*(Emax+1/2)*(log(2)+2)"
        ),
        "pass": math.isfinite(B0) and math.isfinite(B1),
    }


def symbolic_jet_mapping():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    Lam, n, ell, theta = sp.symbols(
        "Lambda n ell theta",
        positive=True,
        real=True,
    )

    x = (Lam-1)/(sp.sqrt(n)*ell)

    J1_term = sp.simplify(
        ell*x*sp.sin(theta)
    )
    J2_term = sp.simplify(
        ell**2*x*sp.cos(theta)
    )

    e1 = (Lam-1)/sp.sqrt(n)*sp.sin(theta)
    e2 = (Lam-1)*ell/sp.sqrt(n)*sp.cos(theta)

    r1 = sp.simplify(J1_term-e1)
    r2 = sp.simplify(J2_term-e2)

    return {
        "J1_term": str(J1_term),
        "J2_term": str(J2_term),
        "J1_residual": str(r1),
        "J2_residual": str(r2),
        "pass": bool(r1 == 0 and r2 == 0),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v415-summary",
        default="rot_rh_multiplicity_robust_generator_v415_SUMMARY.json",
    )
    ap.add_argument(
        "--v403-summary",
        default="rot_rh_G7_riesz_mellin_collision_v403_SUMMARY.json",
    )
    ap.add_argument(
        "--v402-summary",
        default="rot_rh_weighted_factorial_four_jet_v402_SUMMARY.json",
    )
    ap.add_argument(
        "--v383-summary",
        default="rot_rh_G7_mellin_volterra_head_v383_SUMMARY.json",
    )
    ap.add_argument(
        "--v384-summary",
        default="rot_rh_G7_zero_resonance_obstruction_v384_SUMMARY.json",
    )

    ap.add_argument(
        "--Emax",
        type=float,
        default=120.0,
        help="Compact E-tube ceiling used only for explicit Euler discrepancy constants.",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_generator_G7_head_bridge_v416",
    )

    args = ap.parse_args()

    v415 = load_json(args.v415_summary)
    v403 = load_json(args.v403_summary)
    v402 = load_json(args.v402_summary)
    v383 = load_json(args.v383_summary)
    v384 = load_json(args.v384_summary)

    v415_ok = bool(
        v415 is not None
        and v415.get("verdict")
        == "PROSPECTIVE_MULTIPLICITY_ROBUST_GENERATOR_CLOSURE_HOLDOUT_PASS"
    )
    v403_ok = bool(
        v403 is not None
        and v403.get("verdict")
        == "EXACT_G7_RIESZ_MELLIN_COLLISION_REDUCTION_PASS"
    )
    v402_ok = bool(
        v402 is not None
        and v402.get("verdict")
        == "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
    )
    v383_ok = bool(
        v383 is not None
        and v383.get("verdict")
        == "EXACT_MELLIN_VOLTERRA_G7_REDUCTION_PASS"
    )

    # v384 historical naming was stable enough to accept any zero-resonance PASS.
    v384_text = (
        str(v384.get("verdict", ""))
        if v384 is not None
        else ""
    )
    v384_ok = bool(
        v384 is not None
        and "ZERO_RESONANCE" in v384_text
        and "PASS" in v384_text
    )

    print("="*238)
    print("ROT-RH v416 — GENERATOR / HARD-PREFIX JET / G7-HEAD EXPLICIT-FORMULA BRIDGE")
    print("="*238)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scan accepted as proof            : NO")
    print("="*238)

    print("[1] Upstream")
    print("v415 multiplicity-robust generator       :", v415_ok)
    print("v403 G7 Riesz/Mellin collision           :", v403_ok)
    print("v402 R7 factorial four-jet contraction   :", v402_ok)
    print("v383 exact G7 Mellin-Volterra            :", v383_ok)
    print("v384 zero-resonance obstruction          :", v384_ok)
    if v384 is not None:
        print("v384 verdict                             :", v384_text)

    print("\n[2] Exact/bounded bridge identities")

    with tqdm(
        total=4,
        desc="generator-head bridge",
        unit="identity",
    ) as bar:
        jets = symbolic_jet_mapping()
        bar.update(1)

        euler = euler_bounds(args.Emax)
        bar.update(1)

        collision = symbolic_collision_check()
        bar.update(1)

        mult = symbolic_multiplicity_D1_check()
        bar.update(1)

    print("hard-prefix jet mapping pass             :", jets.get("pass"))
    print("uniform Euler discrepancy bounds         :", euler.get("pass"))
    print("collision Taylor identity                :", collision.get("pass"))
    print("multiplicity D1 identity                 :", mult.get("pass"))

    print("\nEuler constants for |E|<=Emax")
    print("Emax                                     :", euler["Emax"])
    print("R0 uniform bound                         :", f"{euler['R0_uniform_bound']:.12e}")
    print("R1 uniform bound                         :", f"{euler['R1_uniform_bound']:.12e}")

    algebra_ok = bool(
        jets.get("pass")
        and euler.get("pass")
        and collision.get("pass")
        and mult.get("pass")
    )

    print("\n[3] Exact generator -> hard-prefix theorem")

    bridge = [
        (
            "C0_JET",
            "C0(log N,E)=J1(N,E;x)+O_I(1), x_n=(Lambda(n)-1)/(sqrt(n)log n).",
        ),
        (
            "C1_JET",
            "C1(log N,E)=J2(N,E;x)+O_I(1).",
        ),
        (
            "V415_TRANSFER_TARGET",
            "|C0|=O_k(log N) iff the centered first hard-prefix jet has O_k(log N) scale.",
        ),
        (
            "V415_SLOPE_TARGET",
            "positive_part(C1+(log N)^2/2)=O_k(log N) iff the collision-subtracted second hard-prefix jet has that scale.",
        ),
    ]

    for key, txt in bridge:
        print(f"{key:46s}: {txt}")

    print("\n[4] Recursive localization")

    recursive = [
        (
            "FIXED_POINT",
            "x=G7+R^7 x exactly.",
        ),
        (
            "R7_REGULAR_JETS",
            "v402 closes the differentiated regular R^7 cascade in beta=2 factorial four-jet geometry.",
        ),
        (
            "G7_MELLIN",
            "v383 reduces G7 exactly to one signed Mellin-Volterra head.",
        ),
        (
            "G7_RIESZ_COLLISION",
            "v403 identifies the remaining collision-subtracted G7 contour/transfer theorem after R7 closure.",
        ),
        (
            "CONCLUSION",
            "The v415 all-L generator theorem is the hard-prefix first/second-jet form of the same unresolved finite G7-head inequality.",
        ),
    ]

    for key, txt in recursive:
        print(f"{key:46s}: {txt}")

    print("\n[5] Explicit-formula meaning")

    explicit = [
        (
            "LANDAU_ZERO_TERM",
            "A zero rho contributes x^(rho-s)/(rho-s) to the centered truncated Mangoldt Dirichlet sum.",
        ),
        (
            "OFF_CRITICAL",
            "At Re(s)=1/2, beta>1/2 carries exp[(beta-1/2)L]; classical PNT remainder estimates cannot give the v415 critical-line bound.",
        ),
        (
            "COLLISION",
            "m(1-exp(aL))/a=-mL-(m/2)aL^2+O(a^2L^3).",
        ),
        (
            "SIMPLE_ZERO",
            "m=1 gives C1 leading -L^2/2, exactly canceled by the +L^2/2 normalization.",
        ),
        (
            "MULTIPLE_ZERO",
            "m>1 gives D1 leading -(m-1)L^2/2, which is beneficial for transversality.",
        ),
        (
            "SIGN_REQUIRED",
            "Any proof must preserve the signed/root-conditioned G7 cancellation; magnitude-only PNT majorants are structurally too weak.",
        ),
    ]

    for key, txt in explicit:
        print(f"{key:46s}: {txt}")

    theorem_pass = bool(
        v415_ok
        and v403_ok
        and v402_ok
        and v383_ok
        and v384_ok
        and algebra_ok
    )

    verdict = (
        "EXACT_GENERATOR_TO_G7_HEAD_EXPLICIT_FORMULA_BRIDGE_PASS"
        if theorem_pass
        else
        "GENERATOR_TO_G7_HEAD_BRIDGE_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_QUANTIZED_G7_FIRST_JET_O_LOGN_AND_ONE_SIDED_COLLISION_SUBTRACTED_SECOND_JET_O_LOGN"
    )

    print("\n" + "="*238)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "REMAINING FIXED-MODE BOTTLENECK          :",
        "ONE SIGNED FINITE G7-HEAD HARD-PREFIX JET THEOREM",
    )
    print(
        "CLASSICAL PNT ROUTE                      :",
        "INSUFFICIENT AT THE REQUIRED CRITICAL-LINE SCALE",
    )
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           :",
        "NOT YET PROVED",
    )
    print("="*238)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "zeta_derivatives_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v415_ok": v415_ok,
            "v403_ok": v403_ok,
            "v402_ok": v402_ok,
            "v383_ok": v383_ok,
            "v384_ok": v384_ok,
            "v384_verdict": v384_text,
        },
        "bridge_algebra": {
            "jets": jets,
            "euler": euler,
            "collision": collision,
            "multiplicity": mult,
        },
        "generator_to_prefix": {
            key: txt for key, txt in bridge
        },
        "recursive_localization": {
            key: txt for key, txt in recursive
        },
        "explicit_formula_meaning": {
            key: txt for key, txt in explicit
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact/bounded bridge. The v415 generator targets differ only by "
            "uniform O_I(1) Euler discrepancies from the first and second "
            "hard-prefix jets of the centered recursive fixed point. Upstream "
            "v402/v403 localize the unresolved theorem to the finite G7 head. "
            "Landau's explicit formula shows why this is genuinely critical-line "
            "strength and why magnitude-only PNT bounds are insufficient."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v416 — generator to G7-head theorem

Let

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`.

For `N>=2`, uniformly on every fixed compact E interval,

`C0(log N,E)
 = sum_(n<=N) log(n)x_n sin(E log n) + O_E(1)`,

and

`C1(log N,E)
 = sum_(n<=N) log(n)^2 x_n cos(E log n) + O_E(1)`.

Hence the v415 all-L theorem is equivalent, up to bounded smooth discrepancy,
to

`|J1_G7+J1_R7tail|=O_k(log N)`

and

`positive_part[J2_G7+J2_R7tail+(log N)^2/2]=O_k(log N)`.

v402 closes the differentiated regular R7 cascade, while v403 identifies the
remaining collision-subtracted G7 head theorem.

The classical explicit formula contains zero factors `N^(rho-s)`.  Therefore
the desired critical-line bound cannot be obtained from an ordinary
magnitude-only PNT error estimate.  The remaining proof must exploit the
signed quantized G7 head.

At a multiplicity-m critical collision,

`m(1-exp(aL))/a
 = -mL-(m/2)aL^2+...`

and consequently

`D1 ~ -(m-1)L^2/2`.

This proves again that the correct stiffness theorem is one-sided in D1.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_QUANTIZED_G7_HARD_PREFIX_JET_CERTIFICATE_V1",
        "required_claims": {
            "first_jet": (
                "|J1_G7(N,E)| plus the already-controlled R7 contribution "
                "is O_k(log N) on the eventual fixed-k tube"
            ),
            "second_jet": (
                "positive_part[J2_G7(N,E)+(log N)^2/2 plus regular R7 "
                "contribution] is O_k(log N)"
            ),
            "quantized_branch_use": (
                "must be explicit; a generic magnitude-only PNT estimate is insufficient"
            ),
            "uniform_tube": "required",
        },
        "allowed_inputs": [
            "Selberg forcing identity",
            "G7=sum_(j=0)^6 R^j S F",
            "v402 exact R7 four-jet contraction",
            "v383 Mellin-Volterra G7 representation",
            "v403 collision-safe Riesz-Mellin representation",
            "Euler summation for the smooth discrete-minus-integral channel",
        ],
        "forbidden_as_proof": [
            "ordinary PNT remainder majorant",
            "absolute value of all zero residues",
            "known zero ordinates",
            "Xi fitting",
            "finite cutoff extrapolation",
            "simple-zero assumption",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
