#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v487 — FLAT-BUMP GEVREY / REGULATOR BARRIER
====================================================

Generalize the current endpoint-flat bump to the model family

    p_r(1-t) ~ exp(-1/t^r),   r>0.

For z=lambda L the endpoint exponent is modeled by

    z - z t - 1/t^r.

The saddle equation gives

    t_* ~ (r/z)^(1/(r+1)),

and the frequency penalty is of order

    exp[-c_r |z|^(r/(r+1))].

Consequences:
  * active ordinate height from balancing with O(L) off-critical growth:
        Gamma_active = O(L^(1/r));
  * at the v486 diagonal UV truncation T=L/(log L)^(1+eta), the tail exponent is
        (L T)^(r/(r+1))
        = L^(2r/(r+1))/(log L)^((1+eta)r/(r+1)).

For r=2 this recovers the present 2/3 saddle, sqrt(L) active strip, and the
L^(4/3) UV-collapse exponent.

However exp(-1/t^r) is naturally Gevrey of order s=1+1/r.  Every finite r has
s>1, hence lies in the non-quasianalytic regime in which nontrivial compactly
supported functions exist.  Therefore increasing finite endpoint flatness can
strengthen the UV barrier arbitrarily close to an L^2 exponent, but it cannot by
itself justify a quasianalytic 'superflat implies zero' argument.

This is a structural no-go for a smoothness-only closure of v486/v485.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict

from tqdm import tqdm

VERSION = "2026-08-29-v487-flat-bump-gevrey-barrier"


def exponents(r: float, eta: float) -> Dict[str, Any]:
    if r <= 0 or eta <= 0:
        raise ValueError("need r>0 and eta>0")
    saddle = r / (r + 1.0)
    gevrey = 1.0 + 1.0 / r
    active = 1.0 / r
    uv_L = 2.0 * r / (r + 1.0)
    uv_log = (1.0 + eta) * r / (r + 1.0)
    return {
        "r": r,
        "eta": eta,
        "saddle_power": saddle,
        "gevrey_order": gevrey,
        "active_height_power": active,
        "uv_collapse_L_power": uv_L,
        "uv_collapse_log_power": uv_log,
        "nonquasianalytic_for_finite_r": gevrey > 1.0,
        "pass": True,
    }


def panel(eta: float):
    rows = []
    for r in (1.0, 2.0, 4.0, 8.0, 16.0):
        e = exponents(r, eta)
        rows.append(e)
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    cert = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    theorem.write_text(r'''# ROT-RH v487 — flat-bump Gevrey / regulator barrier

Consider the endpoint-flat model family

`p_r(1-t) ~ exp(-1/t^r)`, `r>0`.

For the large complex parameter `z=lambda L`, the endpoint phase is

`Psi_r(t;z)=z-z t-1/t^r`.

The stationary equation is

`-z+r/t^(r+1)=0`,

so

`t_*=(r/z)^(1/(r+1))`.

Substitution gives a leading loss proportional to

`|z|^(r/(r+1))`.

Thus the generalized bump has Fourier/saddle decay

`exp[-c_r |lambda L|^(r/(r+1))]`.

## Active-height law

Balancing the off-critical `O(L)` real-part advantage against the vertical loss

`L^(r/(r+1)) Gamma^(r/(r+1))`

gives

`Gamma_active=O(L^(1/r))`.

For the present bump `r=2`, this is exactly the v475 `O(sqrt L)` parabolic strip.

## UV-collapse law

Use the v486 truncation

`T_eta=L/(log L)^(1+eta)`.

Then the omitted-tail exponent becomes

`(L T_eta)^(r/(r+1))
 = L^(2r/(r+1))/(log L)^((1+eta)r/(r+1))`.

For `r=2` this recovers the v486 `L^(4/3)` scale.  As `r->infinity`, the
power `2r/(r+1)` tends to `2`, so higher endpoint flatness makes the surviving
UV cancellation requirement dramatically more severe.

## Why this still does not close the theorem

The prototype `exp(-1/t^r)` is Gevrey of order

`s=1+1/r`.

For every finite `r`, `s>1`.  Gevrey classes of order greater than one are
non-quasianalytic and admit nonzero compactly supported functions; their Fourier
transforms have stretched-exponential decay of the form `exp(-c |xi|^(1/s))`.
Thus the saddle exponent `r/(r+1)=1/s` is exactly the expected Gevrey dual
exponent.

Therefore **no finite compactly supported endpoint-flat regulator can close the
v485/v486 survivor merely by a quasianalytic argument**.  Increasing `r`
strengthens the numerical/analytic barrier but does not remove the structural
possibility of arbitrarily flat cancellation.

**Verdict:** `FINITE_FLAT_BUMP_GEVREY_QUASIANALYTIC_ROUTE_NOGO_PASS`.

The remaining closure must use genuine arithmetic/Fredholm structure, or move to
a noncompact analytic regulator and re-prove regulator universality.
''', encoding="utf-8")
    cert.write_text(json.dumps({
        "schema": "ROT_RH_FLAT_BUMP_GEVREY_BARRIER_V1",
        "closed": {
            "general_saddle_power": "r/(r+1)",
            "active_height": "Gamma_active=O(L^(1/r))",
            "v486_tail_power": "L^(2r/(r+1))/log(L)^((1+eta)r/(r+1))",
            "present_bump_r2": "saddle=2/3, active=sqrt(L), UV=L^(4/3) up to logs",
            "gevrey_order": "s=1+1/r",
            "quasianalyticity": "every finite r has s>1 and is non-quasianalytic"
        },
        "remaining": {
            "arithmetic": "exploit fixed zeta beta-gamma/multiplicity geometry",
            "fredholm": "use operator positivity/determinant structure to rule out the UV outer-factor mechanism",
            "analytic_regulator": "alternatively move to a noncompact analytic regulator and prove universality back to the compact bump"
        }
    }, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--r", type=float, default=2.0)
    ap.add_argument("--eta", type=float, default=0.25)
    ap.add_argument("--prefix", default="rot_rh_flat_bump_gevrey_barrier_v487")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    with tqdm(total=2, desc="v487 scaling", unit="step") as bar:
        chosen = exponents(args.r, args.eta)
        bar.update(1)
        rows = panel(args.eta)
        bar.update(1)
    passed = bool(chosen["pass"] and chosen["nonquasianalytic_for_finite_r"])
    verdict = (
        "FINITE_FLAT_BUMP_GEVREY_QUASIANALYTIC_ROUTE_NOGO_PASS"
        if passed else "FLAT_BUMP_GEVREY_CHECK_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter() - started,
        "selected": chosen,
        "panel": rows,
        "external_math_inputs": [
            "standard Gevrey model exp(-1/t^r) has order s=1+1/r",
            "compactly supported Gevrey-s functions for s>1 are non-quasianalytic",
            "compact Gevrey-s Fourier decay is stretched exponential exp(-c|xi|^(1/s))",
        ],
        "proof_status": (
            "Exact saddle-scaling algebra plus standard Gevrey-class facts. "
            "This is a no-go for a smoothness-only/quasianalytic closure, not a proof of RH."
        ),
    }
    write_outputs(prefix, payload)
    print("verdict                         :", verdict)
    print("selected r                      :", args.r)
    print("saddle power                    :", chosen["saddle_power"])
    print("active-height power             :", chosen["active_height_power"])
    print("Gevrey order                    :", chosen["gevrey_order"])
    print("UV L power                      :", chosen["uv_collapse_L_power"])
    print("summary                         :", str(prefix) + "_SUMMARY.json")
    print("theorem                         :", str(prefix) + "_THEOREM.md")
    print("certificate                     :", str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
