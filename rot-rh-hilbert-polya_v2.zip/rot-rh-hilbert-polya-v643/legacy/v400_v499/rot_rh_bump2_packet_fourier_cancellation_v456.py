#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v456 — STANDARDIZED PACKET PHASE-LOCK / FOURIER CANCELLATION AUDIT
============================================================================

PURPOSE
-------
v455 prospectively supported stability of the absolute finite-part source packet
in standardized coordinates y=(x-mu)/sigma.  v456 restores the SIGN of the
finite-part shell source and asks whether the signed field is controlled by the
arithmetic-prescribed frequency

    Omega_k(L) = E_k(L) * L * sigma_k(L),       L = log X,

rather than by a tuned frequency search.

For each mode/node, with shell source s_b and absolute packet

    p_b = |s_b| / sum_j |s_j|,
    q_b = s_b / sum_j |s_j|,
    y_b = (x_b-mu)/sigma,

we fit only the two coefficients in

    q_b ~= p_b [a cos(Omega y_b) + b sin(Omega y_b)].

Writing

    R = sqrt(a^2+b^2),
    psi = atan2(a,b),
    phi_geom = E L mu,
    delta = unwrap(psi - phi_geom),

the main prospective model freezes low-complexity laws for R(L) and delta(L)
on TRAINING data.  The final dyadic interval is untouched until the SHA256
freeze.  On the held-out interval the frozen laws are applied to the actual
packet geometry to test the signed phase-lock mechanism, and also to a frozen
training packet template to test the Fourier carrier.

The shell resolution is deliberately much finer than v455.  A phase-resolution
diagnostic checks

    max(E L / N_bins),

which is the largest arithmetic phase advance across one normalized x-bin.

SCIENTIFIC BOUNDARY
-------------------
This is a finite prospective mechanism audit.  A PASS is evidence that a stable
packet plus arithmetic phase can explain the signed finite-part source over the
tested unseen interval.  It is NOT an all-L Fourier-decay theorem, operator
cutoff-independence theorem, Fredholm identity proof, or RH proof.

Required local module:
    rot_rh_bump2_finite_part_source_flow_v452.py
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.special import roots_legendre
from tqdm import tqdm

VERSION = "2026-08-26-v456-standardized-packet-fourier-cancellation"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k); fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def json_safe(obj):
    if isinstance(obj, (np.integer,)): return int(obj)
    if isinstance(obj, (np.floating,)): return float(obj)
    if isinstance(obj, np.ndarray): return [json_safe(x) for x in obj.tolist()]
    if isinstance(obj, complex): return {"real": float(obj.real), "imag": float(obj.imag)}
    if isinstance(obj, dict): return {str(k): json_safe(v) for k,v in obj.items()}
    if isinstance(obj, (list,tuple)): return [json_safe(x) for x in obj]
    return obj


def rms(x: Sequence[float]) -> float:
    a=np.asarray(x,float)
    return float(np.sqrt(np.mean(a*a))) if a.size else float("nan")


def corr(a: Sequence[float], b: Sequence[float]) -> float:
    x=np.asarray(a,float); y=np.asarray(b,float)
    if len(x)<2 or np.std(x)<1e-30 or np.std(y)<1e-30: return 0.0
    return float(np.corrcoef(x,y)[0,1])


def safe_rel(a: float, b: float, floor: float=1e-14) -> float:
    return float(abs(a-b)/max(abs(b),floor))


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py beside v456, "
            "or pass --v452-module."
        )


# =============================================================================
# Phase/root helpers
# =============================================================================

def make_phase(v452, n_all: np.ndarray, lam_all: np.ndarray, X: float,
               pnt_q: int, prime_chunk: int):
    idx=int(np.searchsorted(n_all,float(X),side="left"))
    return v452.FinitePartBump2(
        n_all[:idx],lam_all[:idx],float(X),int(pnt_q),int(prime_chunk)
    )


def quantize_silent(v452, phase, modes: Sequence[int], free: np.ndarray,
                    previous: Dict[int,float] | None, root_tol: float,
                    max_newton: int, scan_points: int) -> Dict[int,object]:
    out={}; previous_ordered=None
    for k in modes:
        k=int(k)
        seed=float(previous[k]) if previous and k in previous else float(free[k-1])
        if k==1:
            spacing=float(free[1]-free[0]) if len(free)>1 else 2.0
        elif k<len(free):
            spacing=0.5*float(free[k]-free[k-2])
        else:
            spacing=float(free[-1]-free[-2])
        rr=v452.locate_root(
            phase,k,seed,spacing,previous_ordered,
            float(root_tol),int(max_newton),int(scan_points)
        )
        out[k]=rr
        if rr.ok: previous_ordered=float(rr.root)
    return out


# =============================================================================
# High-resolution shell decomposition
# =============================================================================

def shell_decompose_fast(v452, phase, E_values: np.ndarray, nbins: int,
                         shell_q: int, prime_chunk: int) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    """Exact bin decomposition of partial_L prime/PNT source.

    Returns arrays (nmodes, nbins): prime_L, pnt_L, prime_L-pnt_L.
    The prime work is chunked and accumulated with bincount, avoiding a Python
    trigonometric call per shell.  The PNT shell quadrature is vectorized over
    every bin.
    """
    E=np.asarray(E_values,float); nm=len(E); nb=int(nbins); L=float(phase.L)
    prime=np.zeros((nm,nb),float)

    logs=np.asarray(phase.logs,float); wL=np.asarray(phase.w_L,float)
    bid=np.floor((logs/L)*nb).astype(np.int64)
    bid=np.clip(bid,0,nb-1)
    pc=int(prime_chunk)
    for a in range(0,len(logs),pc):
        z=min(len(logs),a+pc)
        lg=logs[a:z]; ww=wL[a:z]; bb=bid[a:z]
        vals=np.sin(np.outer(E,lg))*ww[None,:]
        for mi in range(nm):
            prime[mi]+=np.bincount(bb,weights=vals[mi],minlength=nb)

    # Vectorized Gauss-Legendre quadrature in each normalized x-bin.
    q=int(shell_q); zg,wg=roots_legendre(q)
    edges=np.linspace(0.0,1.0,nb+1)
    lo=np.maximum(math.log(2.0),edges[:-1]*L)
    hi=np.minimum(L,edges[1:]*L)
    live=hi>lo
    live_bins=np.nonzero(live)[0]
    if len(live_bins)==0:
        return prime,np.zeros_like(prime),prime.copy()
    aa=lo[live]; cc=hi[live]
    y=(0.5*(cc-aa)[:,None]*zg[None,:] + 0.5*(cc+aa)[:,None]).reshape(-1)
    jac=(0.5*(cc-aa)[:,None]*np.ones((1,q))).reshape(-1)
    wgre=np.tile(wg,len(live_bins))
    _,dphi=v452.bump2_and_dL(y,L)
    ww=jac*wgre*np.exp(0.5*y)*dphi/y
    ybin=np.repeat(live_bins,q)
    pnt=np.zeros((nm,nb),float)
    vals=np.sin(np.outer(E,y))*ww[None,:]
    for mi in range(nm):
        pnt[mi]+=np.bincount(ybin,weights=vals[mi],minlength=nb)
    return prime,pnt,prime-pnt


def packet_stats(centers: np.ndarray, finite_shell: np.ndarray) -> dict:
    s=np.asarray(finite_shell,float)
    amp=np.abs(s); mass=float(np.sum(amp))
    if not np.isfinite(mass) or mass<=1e-300:
        raise RuntimeError("degenerate finite-part packet")
    p=amp/mass
    mu=float(np.sum(centers*p))
    var=float(np.sum((centers-mu)**2*p))
    sig=math.sqrt(max(var,1e-18))
    y=(centers-mu)/sig
    q=s/mass
    return {"mass":mass,"p":p,"mu":mu,"sigma":sig,"y":y,"q":q}


def fit_node_phase(p: np.ndarray, y: np.ndarray, q: np.ndarray,
                   omega: float, ridge: float) -> dict:
    """Weighted fit sign ~= a cos(omega y)+b sin(omega y)."""
    p=np.asarray(p,float); y=np.asarray(y,float); q=np.asarray(q,float)
    sign=np.sign(q)
    c=np.cos(float(omega)*y); s=np.sin(float(omega)*y)
    A=np.column_stack([c,s])
    W=p
    lhs=A.T@(W[:,None]*A) + float(ridge)*np.eye(2)
    rhs=A.T@(W*sign)
    try: beta=np.linalg.solve(lhs,rhs)
    except np.linalg.LinAlgError: beta=np.linalg.lstsq(lhs,rhs,rcond=None)[0]
    a=float(beta[0]); b=float(beta[1]); R=float(math.hypot(a,b))
    psi=float(math.atan2(a,b))  # R sin(omega*y + psi)
    qhat=p*(a*c+b*s)
    l1=float(np.sum(np.abs(q-qhat)))
    signacc=float(np.sum(p*(np.sign(qhat)==np.sign(q))))
    H=complex(np.sum(p*np.exp(1j*float(omega)*y)))
    return {
        "a":a,"b":b,"R":R,"psi":psi,"qhat":qhat,
        "profile_l1":l1,"sign_accuracy":signacc,
        "source_norm":float(np.sum(q)),"source_norm_pred":float(np.sum(qhat)),
        "fourier_real":float(H.real),"fourier_imag":float(H.imag),"fourier_abs":float(abs(H)),
    }


# =============================================================================
# Template measure in standardized y
# =============================================================================

def deposit_template(y: np.ndarray, p: np.ndarray, grid: np.ndarray) -> np.ndarray:
    """Linearly deposit a discrete probability measure on a fixed y grid."""
    y=np.asarray(y,float); p=np.asarray(p,float); g=np.asarray(grid,float)
    out=np.zeros(len(g),float)
    h=float(g[1]-g[0])
    t=(y-g[0])/h
    i=np.floor(t).astype(int); frac=t-i
    for jj,w,ff in zip(i,p,frac):
        if jj<0: out[0]+=w
        elif jj>=len(g)-1: out[-1]+=w
        else:
            out[jj]+=w*(1.0-ff); out[jj+1]+=w*ff
    s=float(np.sum(out))
    return out/s if s>0 else out


def template_H(weights: np.ndarray, grid: np.ndarray, omega: float) -> complex:
    return complex(np.sum(np.asarray(weights,float)*np.exp(1j*float(omega)*np.asarray(grid,float))))


# =============================================================================
# Low-complexity prospective fits
# =============================================================================

def design(L: np.ndarray, family: str) -> np.ndarray:
    L=np.asarray(L,float)
    if family=="constant": return np.ones((len(L),1),float)
    if family=="linearL": return np.column_stack([np.ones(len(L)),L])
    if family=="invL": return np.column_stack([np.ones(len(L)),1.0/L])
    if family=="invL2": return np.column_stack([np.ones(len(L)),1.0/(L*L)])
    if family=="logL": return np.column_stack([np.ones(len(L)),np.log(L)])
    raise ValueError(family)


def fit_linear(L: np.ndarray, y: np.ndarray, family: str) -> dict:
    A=design(L,family); yy=np.asarray(y,float)
    beta=np.linalg.lstsq(A,yy,rcond=None)[0]
    pred=A@beta
    return {"family":family,"beta":[float(x) for x in beta],"rmse":rms(yy-pred)}


def predict_linear(fit: dict, L: np.ndarray) -> np.ndarray:
    return design(np.asarray(L,float),fit["family"])@np.asarray(fit["beta"],float)


def fit_logmass_candidates(L: np.ndarray, mass: np.ndarray, interval: np.ndarray,
                           families: Sequence[str]) -> dict:
    y=np.log(np.maximum(np.asarray(mass,float),1e-300)); val=int(np.max(interval))
    fitmask=interval<val; valmask=interval==val
    rec=[]
    for fam in families:
        f=fit_linear(L[fitmask],y[fitmask],fam)
        pv=predict_linear(f,L[valmask])
        rec.append({**f,"validation_rmse":rms(y[valmask]-pv)})
    best=min(rec,key=lambda z:(z["validation_rmse"],len(z["beta"])))
    final=fit_linear(L,y,best["family"])
    return {"selected_family":best["family"],"blocked_validation":best,"final_fit":final,"candidates":rec}


def fit_power_decay(x: np.ndarray, y: np.ndarray) -> dict:
    xx=np.asarray(x,float); yy=np.asarray(y,float)
    m=(xx>0)&(yy>0)&np.isfinite(xx)&np.isfinite(yy)
    if np.count_nonzero(m)<2:
        return {"ok":False,"C":float("nan"),"p":float("nan"),"rmse":float("inf")}
    lx=np.log(xx[m]); ly=np.log(yy[m])
    A=np.column_stack([np.ones(len(lx)),-lx])
    beta=np.linalg.lstsq(A,ly,rcond=None)[0]
    pred=A@beta
    return {"ok":True,"C":float(math.exp(beta[0])),"p":float(beta[1]),"rmse":rms(ly-pred)}


def power_predict(fit: dict, x: float) -> float:
    return float(fit["C"]*float(x)**(-float(fit["p"])))


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--v452-module",default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--cutoffs",default="2332800,4665600,9331200,18662400,37324800,74649600")
    ap.add_argument("--modes",default="1,2,4,8,12,16,24,32")
    ap.add_argument("--nodes-per-doubling",type=int,default=17)
    ap.add_argument("--shell-bins",type=int,default=2048)
    ap.add_argument("--shell-pnt-q",type=int,default=12)
    ap.add_argument("--pnt-q",type=int,default=3072)
    ap.add_argument("--prime-chunk",type=int,default=100000)
    ap.add_argument("--root-tol",type=float,default=2e-9)
    ap.add_argument("--scan-points",type=int,default=65)
    ap.add_argument("--max-newton",type=int,default=12)
    ap.add_argument("--ridge",type=float,default=1e-8)
    ap.add_argument("--template-y-min",type=float,default=-5.0)
    ap.add_argument("--template-y-max",type=float,default=5.0)
    ap.add_argument("--template-y-points",type=int,default=1025)
    ap.add_argument("--amplitude-families",default="constant,invL,invL2")
    ap.add_argument("--phase-families",default="constant,linearL,invL,invL2")
    ap.add_argument("--mass-families",default="constant,linearL,logL,invL")
    ap.add_argument("--prediction-safety",type=float,default=2.0)
    ap.add_argument("--minimum-profile-l1-envelope",type=float,default=0.55)
    ap.add_argument("--minimum-source-rms-envelope",type=float,default=0.45)
    ap.add_argument("--minimum-sign-accuracy",type=float,default=0.55)
    ap.add_argument("--maximum-baseline-ratio",type=float,default=0.85)
    ap.add_argument("--maximum-template-fourier-abs-error",type=float,default=0.20)
    ap.add_argument("--maximum-shell-reconstruction-relative",type=float,default=2e-5)
    ap.add_argument("--maximum-phase-step-per-bin",type=float,default=1.20)
    ap.add_argument("--minimum-supported-mode-fraction",type=float,default=0.75)
    ap.add_argument("--priority-modes",default="12,32")
    ap.add_argument("--prefix",default="rot_rh_bump2_packet_fourier_cancellation_v456")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()

    started=time.perf_counter(); v452=import_v452(args.v452_module)
    cutoffs=parse_ints(args.cutoffs); modes=parse_ints(args.modes); priority=parse_ints(args.priority_modes)
    amp_fams=[x.strip() for x in args.amplitude_families.split(",") if x.strip()]
    phase_fams=[x.strip() for x in args.phase_families.split(",") if x.strip()]
    mass_fams=[x.strip() for x in args.mass_families.split(",") if x.strip()]
    if len(cutoffs)<6 or cutoffs!=sorted(cutoffs):
        raise ValueError("Need >=6 increasing cutoffs: five training endpoints plus one held-out endpoint.")
    if args.nodes_per_doubling<9 or args.nodes_per_doubling%2==0:
        raise ValueError("--nodes-per-doubling must be odd and >=9")
    if args.shell_bins<256:
        raise ValueError("--shell-bins must be >=256; phase-lock testing needs high x resolution.")
    if args.template_y_points<129 or args.template_y_points%2==0:
        raise ValueError("--template-y-points must be odd and >=129")

    prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    train_cutoffs=cutoffs[:-1]; hold_lo=cutoffs[-2]; hold_hi=cutoffs[-1]; train_max=train_cutoffs[-1]
    centers=(np.arange(args.shell_bins,dtype=float)+0.5)/float(args.shell_bins)
    ygrid=np.linspace(args.template_y_min,args.template_y_max,args.template_y_points)

    print("="*184)
    print("ROT-RH v456 — STANDARDIZED PACKET PHASE-LOCK / FOURIER CANCELLATION AUDIT")
    print("="*184)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("finite-part signed packet          : bump2 prime-shell - bump2 PNT-shell")
    print("training cutoff ladder             :",train_cutoffs)
    print("HELD-OUT interval                  :",[hold_lo,hold_hi])
    print("modes                              :",modes)
    print("nodes per doubling                 :",args.nodes_per_doubling)
    print("normalized shell bins              :",args.shell_bins)
    print("prescribed frequency               : Omega=E*log(X)*sigma  (NO frequency search)")
    print("holdout prime table policy         : NOT BUILT until pre-holdout SHA freeze")
    print("prospective target                 : signed profile + source carrier + Fourier envelope")
    print("="*184)

    print("\n[A] Building TRAINING-only prime-power table and free levels ...")
    n_train,lam_train=v452.mangoldt_terms(int(train_max)); free=v452.free_archimedean_levels(max(modes))
    print("training Mangoldt terms             :",len(n_train))

    node_rows=[]; cache={}; previous=None; global_node=0; max_recon=0.0; max_phase_step=0.0
    print("\n[B] Resolving TRAINING standardized signed packet field ...")
    for j,(xa,xb) in enumerate(zip(train_cutoffs[:-1],train_cutoffs[1:])):
        Lgrid=np.linspace(math.log(xa),math.log(xb),args.nodes_per_doubling)
        if j>0: Lgrid=Lgrid[1:]
        for local_i,L in enumerate(tqdm(Lgrid,desc=f"TRAIN phase packets {xa}->{xb}",unit="node")):
            X=float(math.exp(float(L))); ph=make_phase(v452,n_train,lam_train,X,args.pnt_q,args.prime_chunk)
            roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
            bad=[k for k,r in roots.items() if not r.ok]
            if bad: raise RuntimeError(f"training roots failed X={X:.12g}: {bad}")
            E=np.asarray([roots[k].root for k in modes],float)
            prime,pnt,finite=shell_decompose_fast(v452,ph,E,args.shell_bins,args.shell_pnt_q,args.prime_chunk)
            root_map={}
            for mi,k in enumerate(modes):
                st=packet_stats(centers,finite[mi]); sv=ph.sources(float(E[mi]))
                recon=safe_rel(float(np.sum(finite[mi])),float(sv.finitepart_L),1e-10); max_recon=max(max_recon,recon)
                omega=float(E[mi]*L*st["sigma"]); phi=float(E[mi]*L*st["mu"])
                step=float(abs(E[mi]*L)/args.shell_bins); max_phase_step=max(max_phase_step,step)
                nf=fit_node_phase(st["p"],st["y"],st["q"],omega,args.ridge)
                delta=float(np.angle(np.exp(1j*(nf["psi"]-phi))))
                tprob=deposit_template(st["y"],st["p"],ygrid)
                cache[(global_node,k)]={"p":st["p"],"y":st["y"],"q":st["q"],"template_prob":tprob,"finite":finite[mi].copy()}
                node_rows.append({
                    "phase":"TRAIN","interval":j,"global_node":global_node,"X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"E":f"{E[mi]:.17g}",
                    "root_residual":f"{roots[k].residual:.6e}","packet_mass":f"{st['mass']:.17g}","centroid_x":f"{st['mu']:.17g}","width_x":f"{st['sigma']:.17g}",
                    "omega":f"{omega:.17g}","phi_geom":f"{phi:.17g}","phase_step_per_bin":f"{step:.17g}",
                    "fit_a":f"{nf['a']:.17g}","fit_b":f"{nf['b']:.17g}","fit_R":f"{nf['R']:.17g}","fit_psi_wrapped":f"{nf['psi']:.17g}","delta_wrapped":f"{delta:.17g}",
                    "node_profile_l1":f"{nf['profile_l1']:.17g}","node_sign_accuracy":f"{nf['sign_accuracy']:.17g}",
                    "source_norm":f"{nf['source_norm']:.17g}","source_norm_nodefit":f"{nf['source_norm_pred']:.17g}",
                    "fourier_abs":f"{nf['fourier_abs']:.17g}","shell_reconstruction_relative":f"{recon:.6e}",
                })
                root_map[k]=float(E[mi])
            previous=root_map; global_node+=1

    # Fit/freeze models.  The last training interval is blocked validation.
    print("\n[C] Fitting phase-lock laws and FREEZING held-out models ...")
    model_rows=[]; template_rows=[]; manifest_modes={}; prediction_rows=[]
    train_interval_count=len(train_cutoffs)-1; val_interval=train_interval_count-1
    Lh=np.linspace(math.log(hold_lo),math.log(hold_hi),args.nodes_per_doubling)

    for k in modes:
        rows=[r for r in node_rows if int(r["mode"])==k]
        L=np.asarray([float(r["logX"]) for r in rows]); intervals=np.asarray([int(r["interval"]) for r in rows])
        R=np.asarray([float(r["fit_R"]) for r in rows]); dw=np.asarray([float(r["delta_wrapped"]) for r in rows])
        mass=np.asarray([float(r["packet_mass"]) for r in rows]); omega=np.asarray([float(r["omega"]) for r in rows])
        # unwrap residual phase in L order
        order=np.argsort(L); delta=np.empty_like(dw); delta[order]=np.unwrap(dw[order])
        fitmask=intervals<val_interval; valmask=intervals==val_interval
        if np.count_nonzero(fitmask)<4 or np.count_nonzero(valmask)<2:
            raise RuntimeError("insufficient blocked-validation nodes")

        best=None; candidates=[]
        for af in amp_fams:
            fa=fit_linear(L[fitmask],R[fitmask],af)
            for df in phase_fams:
                fd=fit_linear(L[fitmask],delta[fitmask],df)
                Rp=predict_linear(fa,L[valmask]); dp=predict_linear(fd,L[valmask])
                idxs=np.nonzero(valmask)[0]; l1s=[]; src=[]; srcpred=[]; signs=[]
                for rridx,rpv,dpv in zip(idxs,Rp,dp):
                    rr=rows[int(rridx)]; g=int(rr["global_node"]); cc=cache[(g,k)]
                    om=float(rr["omega"]); phi=float(rr["phi_geom"])
                    psi=phi+float(dpv); a=float(rpv)*math.sin(psi); b=float(rpv)*math.cos(psi)
                    qhat=cc["p"]*(a*np.cos(om*cc["y"])+b*np.sin(om*cc["y"]))
                    l1s.append(float(np.sum(np.abs(cc["q"]-qhat))))
                    signs.append(float(np.sum(cc["p"]*(np.sign(qhat)==np.sign(cc["q"])))))
                    src.append(float(np.sum(cc["q"]))); srcpred.append(float(np.sum(qhat)))
                score=float(np.mean(l1s)+0.25*rms(np.asarray(src)-np.asarray(srcpred)))
                rec={"amp_family":af,"phase_family":df,"score":score,"validation_mean_l1":float(np.mean(l1s)),"validation_max_l1":float(np.max(l1s)),"validation_sign":float(np.mean(signs)),"validation_source_rms":rms(np.asarray(src)-np.asarray(srcpred))}
                candidates.append(rec)
                if best is None or score<best["score"]: best=rec
        assert best is not None
        fa=fit_linear(L,R,best["amp_family"]); fd=fit_linear(L,delta,best["phase_family"])
        mf=fit_logmass_candidates(L,mass,intervals,mass_fams)

        # Frozen packet template from all training nodes for this mode.
        probs=np.vstack([cache[(int(r["global_node"]),k)]["template_prob"] for r in rows])
        template=np.mean(probs,axis=0); template/=np.sum(template)
        for yi,pw in zip(ygrid,template):
            template_rows.append({"mode":k,"y":f"{yi:.17g}","probability":f"{pw:.17g}"})

        # Validation-derived prospective envelopes.
        l1_upper=max(args.minimum_profile_l1_envelope,args.prediction_safety*float(best["validation_max_l1"]))
        src_upper=max(args.minimum_source_rms_envelope,args.prediction_safety*float(best["validation_source_rms"]))
        sign_lower=min(args.minimum_sign_accuracy,max(0.0,float(best["validation_sign"])/args.prediction_safety))

        # Training interval maxima of actual packet Fourier amplitude versus median Omega.
        omI=[]; hI=[]
        for jj in range(train_interval_count):
            m=intervals==jj
            if np.any(m):
                omI.append(float(np.median(omega[m])))
                hI.append(float(np.max([float(rows[ii]["fourier_abs"]) for ii in np.nonzero(m)[0]])))
        hf=fit_power_decay(np.asarray(omI),np.asarray(hI))

        manifest_modes[str(k)]={
            "amplitude_fit":fa,"delta_fit":fd,"mass_fit":mf,"selected_blocked_model":best,
            "profile_l1_upper":l1_upper,"source_norm_rms_upper":src_upper,"sign_accuracy_lower":sign_lower,
            "fourier_decay_fit":hf,"training_fourier_interval_omega":omI,"training_fourier_interval_max":hI,
            "template_probability":[float(x) for x in template],
        }
        model_rows.append({
            "mode":k,"amp_family":best["amp_family"],"phase_family":best["phase_family"],
            "validation_mean_l1":f"{best['validation_mean_l1']:.17g}","validation_max_l1":f"{best['validation_max_l1']:.17g}",
            "validation_sign":f"{best['validation_sign']:.17g}","validation_source_rms":f"{best['validation_source_rms']:.17g}",
            "profile_l1_upper":f"{l1_upper:.17g}","source_norm_rms_upper":f"{src_upper:.17g}","sign_accuracy_lower":f"{sign_lower:.17g}",
            "mass_family":mf["selected_family"],"fourier_decay_p":f"{hf['p']:.17g}" if hf["ok"] else "nan",
        })
        Rp=predict_linear(fa,Lh); dp=predict_linear(fd,Lh)
        logmp=predict_linear(mf["final_fit"],Lh); mp=np.exp(np.clip(logmp,-700,700))
        for ii,(LL,rrp,ddp,mpp) in enumerate(zip(Lh,Rp,dp,mp)):
            prediction_rows.append({"mode":k,"node_index":ii,"logX":f"{LL:.17g}","X":f"{math.exp(float(LL)):.17g}","predicted_R":f"{rrp:.17g}","predicted_delta":f"{ddp:.17g}","predicted_packet_mass":f"{mpp:.17g}"})
        print(f"  k={k:<3d} R={best['amp_family']:<8s} delta={best['phase_family']:<8s} valL1={best['validation_mean_l1']:.3f} sign={best['validation_sign']:.3f} Fourier p={hf['p']:+.3f}")

    pred_path=Path(str(prefix)+"_PREDICTED_HOLDOUT.csv"); write_csv(pred_path,prediction_rows)
    template_path=Path(str(prefix)+"_PACKET_TEMPLATE.csv"); write_csv(template_path,template_rows)
    freeze={
        "version":VERSION,"frozen_before_holdout":True,"training_cutoffs":train_cutoffs,"held_out_interval":[hold_lo,hold_hi],
        "modes":modes,"nodes_per_doubling":args.nodes_per_doubling,"shell_bins":args.shell_bins,"shell_pnt_q":args.shell_pnt_q,
        "template_y_grid":[float(x) for x in ygrid],"models":manifest_modes,
        "predicted_holdout_file":pred_path.name,"predicted_holdout_sha256":sha256_file(pred_path),
        "packet_template_file":template_path.name,"packet_template_sha256":sha256_file(template_path),
        "gates":{
            "maximum_shell_reconstruction_relative":args.maximum_shell_reconstruction_relative,
            "maximum_phase_step_per_bin":args.maximum_phase_step_per_bin,
            "maximum_baseline_ratio":args.maximum_baseline_ratio,
            "maximum_template_fourier_abs_error":args.maximum_template_fourier_abs_error,
            "minimum_supported_mode_fraction":args.minimum_supported_mode_fraction,"priority_modes":priority,
        },
        "firewall":{"known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,"holdout_prime_table_built":False,"holdout_signed_packet_evaluated":False},
    }
    freeze_path=Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json"); freeze_path.write_text(json.dumps(json_safe(freeze),indent=2),encoding="utf-8")
    freeze_sha=sha256_file(freeze_path); print("  PRE-HOLDOUT FREEZE SHA256:",freeze_sha)

    # Holdout only after freeze.
    print("\n[D] Revealing HELD-OUT prime table and signed packet field ...")
    n_all,lam_all=v452.mangoldt_terms(int(hold_hi)); print("full Mangoldt terms                 :",len(n_all))
    previous={k:float([r for r in node_rows if int(r["mode"])==k][-1]["E"]) for k in modes}
    hold_rows=[]; hold_cache={}; max_hold_recon=0.0; max_hold_step=0.0
    for ii,L in enumerate(tqdm(Lh,desc=f"HOLDOUT phase packets {hold_lo}->{hold_hi}",unit="node")):
        X=float(math.exp(float(L))); ph=make_phase(v452,n_all,lam_all,X,args.pnt_q,args.prime_chunk)
        roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
        bad=[k for k,r in roots.items() if not r.ok]
        if bad: raise RuntimeError(f"holdout roots failed X={X:.12g}: {bad}")
        E=np.asarray([roots[k].root for k in modes],float)
        prime,pnt,finite=shell_decompose_fast(v452,ph,E,args.shell_bins,args.shell_pnt_q,args.prime_chunk)
        root_map={}
        for mi,k in enumerate(modes):
            st=packet_stats(centers,finite[mi]); sv=ph.sources(float(E[mi]))
            recon=safe_rel(float(np.sum(finite[mi])),float(sv.finitepart_L),1e-10); max_hold_recon=max(max_hold_recon,recon)
            omega=float(E[mi]*L*st["sigma"]); phi=float(E[mi]*L*st["mu"]); step=float(abs(E[mi]*L)/args.shell_bins); max_hold_step=max(max_hold_step,step)
            actualfit=fit_node_phase(st["p"],st["y"],st["q"],omega,args.ridge)
            hold_cache[(ii,k)]={"p":st["p"],"y":st["y"],"q":st["q"],"mass":st["mass"],"omega":omega,"phi":phi,"actual_fourier":actualfit["fourier_abs"]}
            hold_rows.append({"phase":"HOLDOUT","node_index":ii,"X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"E":f"{E[mi]:.17g}","root_residual":f"{roots[k].residual:.6e}","packet_mass":f"{st['mass']:.17g}","centroid_x":f"{st['mu']:.17g}","width_x":f"{st['sigma']:.17g}","omega":f"{omega:.17g}","phi_geom":f"{phi:.17g}","phase_step_per_bin":f"{step:.17g}","actual_fourier_abs":f"{actualfit['fourier_abs']:.17g}","shell_reconstruction_relative":f"{recon:.6e}"})
            root_map[k]=float(E[mi])
        previous=root_map

    print("\n[E] Scoring frozen arithmetic phase-lock / Fourier carrier ...")
    scores=[]; detail=[]; supported=[]
    pred_by={(int(r["mode"]),int(r["node_index"])):r for r in prediction_rows}
    for k in modes:
        mm=manifest_modes[str(k)]; template=np.asarray(mm["template_probability"],float)
        prof=[]; signacc=[]; src=[]; srcpred=[]; srctempl=[]; srcfull=[]; fourier_err=[]; actualH=[]; templateH=[]
        for ii,L in enumerate(Lh):
            cc=hold_cache[(ii,k)]; pr=pred_by[(k,ii)]
            Rpred=float(pr["predicted_R"]); dpred=float(pr["predicted_delta"]); masspred=float(pr["predicted_packet_mass"])
            psi=cc["phi"]+dpred; a=Rpred*math.sin(psi); b=Rpred*math.cos(psi)
            qhat=cc["p"]*(a*np.cos(cc["omega"]*cc["y"])+b*np.sin(cc["omega"]*cc["y"]))
            prof.append(float(np.sum(np.abs(cc["q"]-qhat))))
            signacc.append(float(np.sum(cc["p"]*(np.sign(qhat)==np.sign(cc["q"])))))
            r=float(np.sum(cc["q"])); rp=float(np.sum(qhat)); src.append(r); srcpred.append(rp)
            Ht=template_H(template,ygrid,cc["omega"]); rt=float(a*Ht.real+b*Ht.imag); srctempl.append(rt)
            # Fully frozen mass + template carrier (geometry E,mu,sigma is measured after freeze, amplitude envelope is frozen).
            srcfull.append(float(masspred*rt));
            fourier_err.append(abs(abs(Ht)-float(cc["actual_fourier"])))
            actualH.append(float(cc["actual_fourier"])); templateH.append(float(abs(Ht)))
            detail.append({"mode":k,"node_index":ii,"X":f"{math.exp(float(L)):.17g}","logX":f"{L:.17g}","omega":f"{cc['omega']:.17g}","pred_R":f"{Rpred:.17g}","pred_delta":f"{dpred:.17g}","conditional_profile_l1":f"{prof[-1]:.17g}","conditional_sign_accuracy":f"{signacc[-1]:.17g}","actual_source_norm":f"{r:.17g}","conditional_source_norm_pred":f"{rp:.17g}","template_source_norm_pred":f"{rt:.17g}","actual_fourier_abs":f"{actualH[-1]:.17g}","template_fourier_abs":f"{templateH[-1]:.17g}","fourier_abs_error":f"{fourier_err[-1]:.17g}"})
        profmax=float(np.max(prof)); signmean=float(np.mean(signacc)); sr=np.asarray(src); sp=np.asarray(srcpred); stp=np.asarray(srctempl)
        src_rms=rms(sr-sp); template_src_rms=rms(sr-stp); zero_rms=rms(sr); last=float([r for r in node_rows if int(r["mode"])==k][-1]["source_norm"]); last_rms=rms(sr-last)
        baseline=max(min(zero_rms,last_rms),1e-14); baseline_ratio=float(src_rms/baseline)
        template_baseline_ratio=float(template_src_rms/baseline)
        src_corr=corr(sr,sp); templ_corr=corr(sr,stp); ferr=float(np.max(fourier_err))
        # Fourier envelope: compare heldout max to training-frozen power fit if it has positive decay.
        hf=mm["fourier_decay_fit"]; hold_om=float(np.median([hold_cache[(ii,k)]["omega"] for ii in range(len(Lh))])); hold_h=float(np.max(actualH))
        if hf.get("ok",False) and float(hf["p"])>0:
            hp=power_predict(hf,hold_om); hupper=args.prediction_safety*max(hp,1e-12); hpass=hold_h<=hupper
        else:
            hp=float("nan"); hupper=float("nan"); hpass=False
        passes={
            "profile":profmax<=float(mm["profile_l1_upper"]),
            "sign":signmean>=max(args.minimum_sign_accuracy,float(mm["sign_accuracy_lower"])),
            "source":src_rms<=float(mm["source_norm_rms_upper"]),
            "baseline":baseline_ratio<=args.maximum_baseline_ratio,
            "template_fourier":ferr<=args.maximum_template_fourier_abs_error,
        }
        ok=bool(all(passes.values())); supported.append(ok)
        scores.append({"mode":k,"max_profile_l1":f"{profmax:.17g}","profile_upper":f"{mm['profile_l1_upper']:.17g}","mean_sign_accuracy":f"{signmean:.17g}","source_norm_rms":f"{src_rms:.17g}","source_upper":f"{mm['source_norm_rms_upper']:.17g}","source_corr":f"{src_corr:.17g}","baseline_ratio":f"{baseline_ratio:.17g}","template_source_rms":f"{template_src_rms:.17g}","template_source_corr":f"{templ_corr:.17g}","template_baseline_ratio":f"{template_baseline_ratio:.17g}","max_fourier_abs_error":f"{ferr:.17g}","fourier_decay_p":f"{hf.get('p',float('nan')):.17g}","holdout_fourier_max":f"{hold_h:.17g}","predicted_fourier_max":f"{hp:.17g}","fourier_upper":f"{hupper:.17g}","fourier_decay_pass":hpass,"pass":ok})

    recon_pass=bool(max(max_recon,max_hold_recon)<=args.maximum_shell_reconstruction_relative)
    phase_res_pass=bool(max(max_phase_step,max_hold_step)<=args.maximum_phase_step_per_bin)
    roots_clean=all(float(r["root_residual"])<=max(1e-7,50*args.root_tol) for r in hold_rows)
    frac=float(np.mean(supported)); priority_pass=all(supported[modes.index(k)] for k in priority if k in modes)
    fourier_decay_frac=float(np.mean([bool(r["fourier_decay_pass"]) for r in scores]))
    if recon_pass and phase_res_pass and roots_clean and frac>=args.minimum_supported_mode_fraction and priority_pass and fourier_decay_frac>=args.minimum_supported_mode_fraction:
        verdict="STANDARDIZED_PACKET_FOURIER_CANCELLATION_SUPPORTED_PROSPECTIVELY"
    elif recon_pass and phase_res_pass and roots_clean and frac>=args.minimum_supported_mode_fraction and priority_pass:
        verdict="PACKET_PHASE_LOCK_SUPPORTED__FOURIER_DECAY_NOT_YET_CLOSED"
    elif recon_pass and roots_clean and frac>0:
        verdict="STANDARDIZED_PACKET_PHASE_LOCK_PARTIAL__NOT_ALL_GATES"
    else:
        verdict="STANDARDIZED_PACKET_PHASE_LOCK_NOT_SUPPORTED"

    paths={
        "nodes":Path(str(prefix)+"_PACKET_PHASE_NODES.csv"),
        "models":Path(str(prefix)+"_MODEL_FITS.csv"),
        "template":template_path,"predictions":pred_path,
        "holdout_detail":Path(str(prefix)+"_HOLDOUT_TRAJECTORY.csv"),
        "holdout_score":Path(str(prefix)+"_HOLDOUT_SCORE.csv"),
        "summary":Path(str(prefix)+"_SUMMARY.json"),"theorem":Path(str(prefix)+"_THEOREM.md"),
    }
    write_csv(paths["nodes"],node_rows+hold_rows); write_csv(paths["models"],model_rows); write_csv(paths["holdout_detail"],detail); write_csv(paths["holdout_score"],scores)
    summary={
        "version":VERSION,"verdict":verdict,"pre_holdout_freeze_sha256":freeze_sha,"training_cutoffs":train_cutoffs,"holdout_interval":[hold_lo,hold_hi],"modes":modes,
        "max_shell_reconstruction_relative":max(max_recon,max_hold_recon),"shell_reconstruction_pass":recon_pass,
        "max_phase_step_per_bin":max(max_phase_step,max_hold_step),"phase_resolution_pass":phase_res_pass,"holdout_roots_clean":roots_clean,
        "supported_mode_fraction":frac,"priority_modes":priority,"priority_modes_pass":priority_pass,"fourier_decay_supported_fraction":fourier_decay_frac,
        "mode_scores":scores,"runtime_seconds":time.perf_counter()-started,"outputs":{k:str(v) for k,v in paths.items()},
        "scope_limit":"Finite prospective phase-lock/Fourier-cancellation evidence only; no all-L source theorem, operator cutoff-independence theorem, exact Fredholm identity proof, or RH proof.",
    }
    paths["summary"].write_text(json.dumps(json_safe(summary),indent=2),encoding="utf-8")
    theorem=f"""# ROT-RH v456 — standardized packet Fourier-cancellation theorem target

Verdict: **{verdict}**

Let `s_{{k,b}}(L)` be the signed bump-2 finite-part source in normalized logarithmic shell `x_b`, and let `p_{{k,b}}=|s_{{k,b}}|/sum_j|s_{{k,j}}|`.  With `mu_k`, `sigma_k`, `y=(x-mu_k)/sigma_k`, and `Omega_k=E_k L sigma_k`, v456 tests the prescribed-frequency representation

`q_k(y,L) ~= p_k(y,L) R_k(L) sin(Omega_k(L) y + E_k(L)L mu_k(L) + delta_k(L))`.

No frequency is tuned.  The prospective theorem would combine: (i) convergence of the absolute standardized packet from v455, (ii) controlled amplitude/phase-offset laws, and (iii) Fourier decay of the limiting packet measure at `Omega_k(L) -> infinity`.  This would yield a signed source estimate through the characteristic function of the packet and could supply the integrable/resonance-subtracted numerator bound required by the implicit root-flow theorem.

This numerical audit does not prove those all-L hypotheses or RH.
"""
    paths["theorem"].write_text(theorem,encoding="utf-8")

    print("\n"+"="*184); print("KEY RESULTS"); print("="*184)
    print("verdict                                  :",verdict)
    print("pre-holdout freeze SHA256                :",freeze_sha)
    print("holdout prime table built after freeze   : True")
    print("max shell reconstruction relative        :",f"{max(max_recon,max_hold_recon):.6e}","pass=",recon_pass)
    print("max arithmetic phase step / shell        :",f"{max(max_phase_step,max_hold_step):.6e}","pass=",phase_res_pass)
    print("holdout roots clean                      :",roots_clean)
    print("phase-lock supported mode fraction       :",f"{frac:.3f}")
    print("priority modes pass                      :",priority_pass,priority)
    print("Fourier-decay supported mode fraction    :",f"{fourier_decay_frac:.3f}")
    print("holdout mode diagnostics                 :")
    for r in scores:
        print(f"  k={int(r['mode']):<3d} L1={float(r['max_profile_l1']):.3f}/{float(r['profile_upper']):.3f} "
              f"sign={float(r['mean_sign_accuracy']):.3f} srcRMS={float(r['source_norm_rms']):.3e}/{float(r['source_upper']):.3e} "
              f"base={float(r['baseline_ratio']):.3f} corr={float(r['source_corr']):+.3f} "
              f"H_err={float(r['max_fourier_abs_error']):.3f} H_p={float(r['fourier_decay_p']):+.3f} Hpass={r['fourier_decay_pass']} pass={r['pass']}")
    print("summary                                  :",paths["summary"])
    print("="*184)
    if args.strict and verdict not in {"STANDARDIZED_PACKET_FOURIER_CANCELLATION_SUPPORTED_PROSPECTIVELY","PACKET_PHASE_LOCK_SUPPORTED__FOURIER_DECAY_NOT_YET_CLOSED"}:
        return 2
    return 0


if __name__=="__main__":
    raise SystemExit(main())
