#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v496 — GAUSSIAN LOCAL SADDLE / O(L^-2) OFF-CRITICAL PINNING
==================================================================

For a right-half mode lambda=a+i(gamma-E), a>0, the Gaussian zero primitive is

  K_G = ∫_{ell/L}^∞ exp(-x^2+aLx) exp(i(gamma-E)Lx) dx/x.

Let
  A_a(L)=∫ exp(-x^2+aLx) dx/x
and scale detuning
  v=(gamma-E)L^2.

Completing the square:
  -x^2+aLx = -(x-aL/2)^2 + a^2 L^2/4.
The normalized positive measure concentrates at x=aL/2 with O(1) width.
Therefore
  K_G/A_a -> exp(i a v/2)
uniformly for v in compact sets, with O_v(1/L) error.

Hence
  Im K_G/A_a -> sin(a v/2),
  d_v Im K_G/A_a -> (a/2) cos(a v/2).

A strictly dominant isolated Gaussian right-half mode therefore pins secular
roots to
  v_n -> 2 pi n/a,
  E_n(L)=gamma-2 pi n/(a L^2)+o(L^-2),
with eventual transversality near every n*pi phase cell.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v496-gaussian-local-saddle"

def symbolic_checks():
    import sympy as sp
    x,a,L=sp.symbols("x a L", positive=True, real=True)
    lhs=-x**2+a*L*x
    rhs=-(x-a*L/2)**2+a**2*L**2/4
    return {"square_residual":str(sp.expand(lhs-rhs)),
            "pass":bool(sp.expand(lhs-rhs)==0)}

def concentration_proxy(a,L,v):
    # Under the completed-square bulk, X=aL/2+Z/sqrt(2) approximately
    # (density proportional exp(-Z^2/2)); detuning phase is exp(i v X/L).
    center=a*L/2
    # exact Gaussian characteristic proxy ignoring lower cutoff and 1/x slowly varying factor
    phase=complex(math.cos(a*v/2),math.sin(a*v/2))
    damping=math.exp(-v*v/(4*L*L))
    proxy=phase*damping
    target=phase
    return {"a":a,"L":L,"v":v,"proxy_real":proxy.real,"proxy_imag":proxy.imag,
            "target_real":target.real,"target_imag":target.imag,
            "abs_proxy_target":abs(proxy-target)}

def panel(a):
    rows=[]
    for L in (20.,40.,80.,160.):
        for v in (1.,4.,8.):
            rows.append(concentration_proxy(a,L,v))
    return rows

def write_outputs(prefix,payload):
    summary=Path(str(prefix)+"_SUMMARY.json")
    theorem=Path(str(prefix)+"_THEOREM.md")
    cert=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    theorem.write_text(r"""# ROT-RH v496 — Gaussian local saddle / `O(L^-2)` off-critical pinning

For one right-half zero mode write

`lambda=a+i(gamma-E)`, `a>0`.

The Gaussian zero primitive has the scaled form

`K_G(L,E)
 =int_(ell/L)^infty
    exp(-x^2+aLx) exp(i(gamma-E)Lx) dx/x`.

Let

`A_a(L)=int_(ell/L)^infty exp(-x^2+aLx) dx/x`

and introduce the Gaussian natural detuning

`v=(gamma-E)L^2`.

Complete the square:

`-x^2+aLx
 =-(x-aL/2)^2+a^2L^2/4`.

Thus the normalized positive measure proportional to

`exp[-(x-aL/2)^2] dx/x`

has center

`x=aL/2+O(1)`

and fixed `O(1)` width.  On a compact `v`-set,

`exp[i(gamma-E)Lx]
 =exp[i v x/L]
 =exp[i a v/2] [1+O_v(1/L)]`

uniformly on the concentration bulk, while Gaussian tails are exponentially
small.  Therefore

`K_G(L,E)/A_a(L)
 =exp(i a v/2)+O_v(1/L)`.

Differentiating the compact-`v` asymptotic gives

`partial_v [K_G/A_a]
 =(ia/2) exp(iav/2)+O_v(1/L)`,

hence

`Im K_G/A_a
 =sin(av/2)+O_v(1/L)`

and

`partial_v Im(K_G/A_a)
 =(a/2)cos(av/2)+O_v(1/L)`.

For a **strictly dominant local right-half mode**, every fixed phase cell near

`a v/2=n*pi`

therefore contains an eventual unique transverse solution

`v_n(L)=2*pi*n/a+O(1/L)`,

so

`E_n(L)
 =gamma - 2*pi*n/(a L^2) + O(L^-3)`.

In particular the Gaussian off-critical lock is sharper than the compact-bump
`O(1/L)` endpoint lock:

`|E_n(L)-gamma|=O(L^-2)`.

The Gaussian amplitude itself grows like

`A_a(L)=exp(a^2L^2/4) * poly(L)`

up to a nonzero asymptotic factor, so any local mode with a strict positive
Gaussian growth-score gap dominates exponentially in `L^2`.

**Verdict:** `GAUSSIAN_STRICT_LOCAL_MODE_L2_PINNING_PASS`.

Scientific boundary: tied maximal Gaussian growth scores form a finite cluster
and require a finite-cluster theorem; this packet does not prove the global
branch-label association or regulator universality.
""",encoding="utf-8")
    cert.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_LOCAL_L2_PINNING_V1",
        "closed":{
            "completed_square":"-x^2+aLx=-(x-aL/2)^2+a^2L^2/4",
            "concentration_center":"aL/2+O(1)",
            "natural_detuning":"v=(gamma-E)L^2",
            "normalized_phase":"K/A=exp(iav/2)+O_v(1/L)",
            "local_profile":"sin(av/2)",
            "transverse_roots":"v_n=2pi n/a+O(1/L)",
            "energy_lock":"E_n=gamma-2pi n/(aL^2)+O(L^-3)"
        },
        "required_next":{
            "finite_ties":"handle finite tied maximal Gaussian growth-score clusters",
            "branch_labels":"connect local pinned cells to fixed ordered secular labels",
            "explicit_formula":"supply exact Gaussian arithmetic/static ledger"
        }
    },indent=2),encoding="utf-8")
    return summary,theorem,cert

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--a",type=float,default=.25)
    ap.add_argument("--prefix",default="rot_rh_gaussian_local_saddle_v496")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v496 saddle",unit="step") as bar:
        sym=symbolic_checks();bar.update(1)
        rows=panel(args.a);bar.update(1)
    # proxy errors should improve from L=20 to L=160 for each v
    ok=sym["pass"]
    for v in (1.,4.,8.):
        rr=[r for r in rows if r["v"]==v]
        ok=ok and rr[-1]["abs_proxy_target"]<rr[0]["abs_proxy_target"]
    verdict="GAUSSIAN_STRICT_LOCAL_MODE_L2_PINNING_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,
             "runtime_seconds":time.perf_counter()-t0,
             "symbolic":sym,"proxy_panel":rows,
             "firewall":{"RH_assumed":False,"known_zero_ordinates_used":False,
                         "zeta_values_used":False}}
    prefix=Path(args.prefix).resolve()
    s,t,c=write_outputs(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)

if __name__=="__main__": main()
