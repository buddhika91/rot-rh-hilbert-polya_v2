#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v497 — GAUSSIAN OFF-CRITICAL EXPOSED-MODE / LOCAL OCCUPANCY EXPLOSION
============================================================================

For a Gaussian-regulated zero mode
    lambda_j(E)=a_j+i(gamma_j-E),   a_j>0,
the large-L saddle has real growth score
    s_j(E)=a_j^2-(gamma_j-E)^2
and phase
    theta_j(E,L)=a_j(gamma_j-E)L^2/2+O(1).

Because |a_j|<1/2 while |gamma_j|->infinity, s_j(E)->-infinity uniformly on
every compact E interval. Thus the upper score envelope is attained by finitely
many candidates locally.

If any off-critical zero exists, the envelope is positive somewhere. Pairwise
score differences are affine in E, so after combining exact duplicate
(a,gamma) multiplicities there is a compact interval J on which one exposed
right-half mode is uniquely dominant, with
    s_*(E)>=c>0,
    s_*(E)-sup_{j!=*}s_j(E)>=g>0.

On J its Gaussian residue therefore has amplitude
    A_*(L,E)>=C exp(c L^2/4)/L
and phase derivative
    partial_E theta_*=-a_* L^2/2+O(1),
while the complete remainder is exponentially smaller after the uniform
Gaussian saddle/zero-count estimate.

Hence the full secular phase attains alternating values of magnitude
>> exp(cL^2/4)/L on successive half waves. By continuity it crosses at least
    M_L >= C' exp(cL^2/4)/L
distinct positive half-integer levels below the fixed right endpoint E_* of J.

Therefore the selected local occupancy N_L(E_*) diverges if any off-critical
zero exists.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v497-gaussian-occupancy-explosion"

def score(a,g,E):
    return a*a-(g-E)**2

def score_gap_symbolic():
    import sympy as sp
    a,b,g,h,E=sp.symbols("a b g h E",real=True)
    sj=a*a-(g-E)**2
    sk=b*b-(h-E)**2
    d=sp.expand(sj-sk)
    second=sp.diff(d,E,2)
    return {"difference":str(d),"second_E_derivative":str(second),
            "affine_in_E":bool(second==0),"pass":bool(second==0)}

def envelope_demo():
    modes=[(.24,14.0),(.23,14.7),(.20,16.0),(.10,25.0)]
    rows=[]
    for E in (13.8,14.0,14.2,14.4,14.6):
        vals=[score(a,g,E) for a,g in modes]
        j=max(range(len(vals)),key=lambda k:vals[k])
        sorted_vals=sorted(vals,reverse=True)
        rows.append({"E":E,"winner":j,"score":vals[j],
                     "gap":sorted_vals[0]-sorted_vals[1]})
    return rows

def occupancy_lower(c,L,C=1.0):
    return C*math.exp(c*L*L/4.0)/max(L,1.0)

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    cfile=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v497 — Gaussian off-critical exposed mode / local occupancy explosion

For every right-half nontrivial zero write

`rho_j=1/2+a_j+i gamma_j`, `a_j>0`.

The Gaussian residue has the large-`L` exponential factor

`exp[(a_j+i(gamma_j-E))^2 L^2/4]`.

Its real growth score is

`s_j(E)=a_j^2-(gamma_j-E)^2`.

Because every nontrivial zero satisfies `|a_j|<1/2`, while zero ordinates are
locally finite and tend to infinity,

`s_j(E)->-infinity`

uniformly in `E` on each compact interval as `|gamma_j|->infinity`.
Consequently the upper envelope

`S(E)=sup_j s_j(E)`

is locally attained by a finite set of zero modes.

If an off-critical zero exists, then at its own ordinate

`S(gamma_j)>=a_j^2>0`.

Hence `S>0` on an open interval.  For two modes,

`s_j(E)-s_k(E)`

is affine in `E`.  After identical `(a,gamma)` modes are combined into their
integer multiplicity, pairwise ties are isolated.  We may therefore choose a
compact subinterval `J=[E_-,E_+]` and one exposed mode `*` such that

`s_*(E)>=c>0`

and

`s_*(E)-sup_(j!=*)s_j(E)>=g>0`

throughout `J`.

The exact Gaussian transform / steepest-descent formula then gives uniformly
on `J`

`K_*(L,E)
 = [2 sqrt(pi)/(lambda_*(E)L)]`
`   exp[lambda_*(E)^2 L^2/4] [1+o(1)]`,

with

`lambda_*=a_*+i(gamma_*-E)`.

Thus

`|K_*| >= C_J L^-1 exp(cL^2/4)`

and its unwrapped phase obeys

`partial_E arg K_*
 =-a_*L^2/2+O_J(1)`.

The positive score gap `g` makes every other local saddle exponentially smaller
by `exp(-gL^2/4)`; the remote infinite family is summable using the same Gaussian
outer-sector/zero-count estimates as v494.  Static and Archimedean terms are
negligible compared with the displayed exponential amplitude.

Therefore on every sufficiently late `L`, successive positive and negative
antinodes of the exposed mode inside `J` force the **full secular count**
`F_L(E)` to attain values whose magnitude is at least

`C'_J L^-1 exp(cL^2/4)`.

By continuity, between one such negative and positive antinode the equation

`F_L(E)=k-1/2`

has a solution for every positive integer `k` up to

`M_L=floor(C''_J L^-1 exp(cL^2/4))`.

Since the canonical selected root for level `k-1/2` is the first later
crossing, it occurs no later than that solution.  Hence for the fixed endpoint
`E_*=E_+`,

`N_L(E_*)=#{k:E_k(L)<=E_*}`
`          >= M_L -> infinity`.

So a single off-critical zero forces **cutoff-dependent local spectral
multiplicity explosion** for the Gaussian regulator.

**Verdict:** `GAUSSIAN_OFFCRITICAL_LOCAL_OCCUPANCY_EXPLOSION_REDUCTION_PASS`.

A publication proof should state the uniform Gaussian saddle remainder and
remote-family summation as inequalities.  No numerical zeta values or known
zero ordinates are used.
""",encoding="utf-8")
    cfile.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_OCCUPANCY_EXPLOSION_V1",
        "closed":{
            "score":"s_j(E)=a_j^2-(gamma_j-E)^2",
            "local_attainment":"score envelope attained by finitely many modes on compact E intervals",
            "tie_geometry":"pairwise score differences affine; non-identical ties isolated",
            "offcritical_positive_score":"S(gamma)>=a^2>0",
            "exposed_interval":"choose J with score >=c>0 and strict score gap g>0",
            "phase_frequency":"partial_E arg K=-aL^2/2+O(1)",
            "occupancy_conclusion":"N_L(E_*) >= C exp(cL^2/4)/L -> infinity"
        },
        "required_precision":{
            "uniform_Gaussian_saddle":"publication-grade bound on J",
            "remote_sum":"uniform zero-count summation of lower-score Gaussian saddles"
        }
    },indent=2),encoding="utf-8")
    return s,t,cfile

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--c",type=float,default=.02)
    ap.add_argument("--prefix",default="rot_rh_gaussian_occupancy_explosion_v497")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=3,desc="v497 occupancy",unit="step") as bar:
        sym=score_gap_symbolic();bar.update(1)
        demo=envelope_demo();bar.update(1)
        panel=[{"L":L,"occupancy_proxy":occupancy_lower(args.c,L)}
               for L in (10.,20.,30.,40.)];bar.update(1)
    ok=bool(sym["pass"] and panel[-1]["occupancy_proxy"]>panel[0]["occupancy_proxy"])
    verdict="GAUSSIAN_OFFCRITICAL_LOCAL_OCCUPANCY_EXPLOSION_REDUCTION_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-t0,
             "symbolic":sym,"envelope_demo":demo,"occupancy_growth_demo":panel,
             "firewall":{"RH_assumed":False,"known_zero_ordinates_used":False,
                         "numerical_zeta_used":False}}
    prefix=Path(args.prefix).resolve()
    s,t,cfile=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",cfile)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
