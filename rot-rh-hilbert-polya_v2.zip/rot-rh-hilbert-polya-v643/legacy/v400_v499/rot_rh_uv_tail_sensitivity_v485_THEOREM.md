# ROT-RH v485 — ultraviolet-tail sensitivity theorem

Work after removal of the common nonattained right-edge exponential factor.
For a fixed large base cutoff `L`, let the full grouped resonance signal on the
v478 proportional window be

`H_L(s)=H_(<=R sqrt L)(s)+Tail_(>R sqrt L)(s)`.

Assume the full rotated signal lies in a fixed strict sector

`|arg Z_L(s)|<=Theta<pi/2`

throughout the proportional window.  Choose once and for all
`Theta<Theta'<pi/2`.

## 1. Tail envelope

The uniform sectorial version of the v473 bump saddle gives, after the common
edge factor is removed,

`|mode_gamma(L)| <= poly(L,gamma)
                     exp[-k L^(2/3) gamma^(2/3)]`.

Using the classical zero count `N(T)=O(T log T)` to sum the tail, for each fixed
`R` one obtains

`sup_window |Tail_(>R sqrt L)|
   <= poly_R(L) exp[-k_R L]`,

with `k_R -> infinity` as `R->infinity` (indeed `k_R` grows on the
`R^(2/3)` scale).

## 2. Sector perturbation

If `Z` lies in the `Theta` sector and a perturbation `r` satisfies

`|r| < |Z| sin(Theta'-Theta)`,

then `Z-r` remains in the wider `Theta'` sector.  Therefore, contrapositively,
if the finite truncation leaves the `Theta'` sector at some point while the full
sum stays in `Theta`, then

`|Z| <= |r|/sin(Theta'-Theta)`.

## 3. Invoke v484

After excising any genuinely local bounded shifted-frequency collision handled
by the attained/local theory, the truncation below `R sqrt L` is finite and has
only

`O(sqrt L log L)=o(L)`

zeta modes.  v483+v478 (v484) says such a finite truncation cannot stay in a
strict sector throughout a window of length `cL`.

Hence for every fixed `R`, at some point of every sufficiently late
proportional window,

`|H_L(s)|
  <= C_(Theta,Theta') poly_R(L) exp[-k_R L]`.

Since `R` can be taken arbitrarily large and `k_R->infinity`, any surviving
full infinite-family lock necessarily satisfies the superexponential-collapse
condition

`for every D>0:
   inf_(proportional window) |H_L| <= exp[-D L]`

for all sufficiently large `L` (up to harmless fixed polynomial factors and in
the common-edge normalization).

**Verdict:** `UV_TAIL_SUPEREXPONENTIAL_COLLAPSE_REDUCTION_PASS`.

This does **not** yet prove cutoff independence.  It changes the last loophole
from “a sparse zeta family might superoscillate” to the much sharper statement:

> a surviving nonattained branch must use arbitrarily remote ultraviolet modes
> to engineer cancellations whose residual amplitude is smaller than every
> fixed exponential scale in the cutoff.

The next target is to show that this superexponential collapse is incompatible
with the fixed zeta coefficient geometry / root-tube transversality, or that it
forces a v419-subquadratic signed primitive.
