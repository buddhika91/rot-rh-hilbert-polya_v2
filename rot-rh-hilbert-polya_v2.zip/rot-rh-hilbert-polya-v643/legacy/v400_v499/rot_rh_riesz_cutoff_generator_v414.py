#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v414 — EXACT RIESZ CUTOFF-GENERATOR / POINTWISE HOLDOUT
==============================================================

Purpose
-------
Attack the two remaining all-X cutoff-independence hypotheses through the
EXACT cutoff derivative of the actual v71 Riesz phase.

Let L=log X and

  F_L(E) = theta(E) - P_L(E) + M_L(E),

with the same prime-power Riesz sum and PNT counterterm used by v71/v77/v78.

Define

  C0(L,E)
    = sum_{p^m<e^L} log(p) p^(-m/2) sin(m E log p)
      - integral_2^(e^L) t^(-1/2) sin(E log t) dt,

and

  C1(L,E)
    = sum_{p^m<e^L} [m log(p)^2] p^(-m/2) cos(m E log p)
      - integral_2^(e^L) (log t)t^(-1/2) cos(E log t) dt.

Equivalently, with n=p^m,

  C0 = sum Lambda(n)/sqrt(n) sin(E log n) - smooth_0,

  C1 = sum Lambda(n)log(n)/sqrt(n) cos(E log n) - smooth_1.

Then, away from the harmless entry points L=log n and hence a.e. in L,

  d_L F_L(E) = -C0(L,E)/L^2

EXACTLY.

Also

  d_L F'_L(E) = -C1(L,E)/L^2,

so for the collision-normalized stiffness defect

  A_L(E)=F'_L(E)-L/2,

  d_L A_L(E)
    = -[C1(L,E)+L^2/2]/L^2.

Define

  D1(L,E)=C1(L,E)+L^2/2.

Therefore the two pointwise generator bounds

  |C0(L,E)| <= K0_k L,

  |D1(L,E)| <= K1_k L,

on an eventual fixed-k tube imply:

TRANSFER
--------
For L<=M<=L+log2,

  |F_M(E)-F_L(E)|
    <= K0_k int_L^M ds/s
    = K0_k log(M/L)
    <= K0_k log2/L.

Hence the exact v392 O(1/log X) transfer bound.

TRANSVERSALITY
--------------
For fixed E in an eventual compact tube,

  |A_M(E)-A_L0(E)|
    <= K1_k log(M/L0).

Thus

  A_M(E)=O_k(log M)=o(M),

and therefore

  F'_M(E)/M -> 1/2.

In particular, for every c_k<1/2,

  F'_M(E)>=c_k M

eventually, uniformly wherever the K1 bound is uniform.

The point of v414 is twofold:

1. prove/check the exact generator algebra;
2. prospectively test whether the stronger POINTWISE generator scale already
   visible in v413 is stable from the 8M development anchor to the 16M
   holdout anchor, over Y<=2X.

No roots are solved at Y.

Scientific firewall
-------------------
NO Xi.
NO zeta evaluations.
NO known zero ordinates.
NO root solves at transfer Y.
NO finite scan accepted as proof.

Version: 414
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 414


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def energy_col(df):
    for c in ("energy", "E", "root", "root_energy"):
        if c in df.columns:
            return c
    raise KeyError("No energy column found.")


def index_col(df):
    for c in ("root_index", "mode_index", "k", "index"):
        if c in df.columns:
            return c
    raise KeyError("No root index column found.")


def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    """
    integral_2^(e^L) t^-1/2 sin(E log t) dt
    = Im[(e^(aL)-e^(a log2))/a], a=1/2+iE.
    """
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    lo = math.log(2.0)
    z = (np.exp(a*L)-np.exp(a*lo))/a
    return np.imag(z)


def smooth1(E: np.ndarray, L: float) -> np.ndarray:
    """
    integral_2^(e^L) (log t)t^-1/2 cos(E log t) dt
    = Re[ integral_log2^L u e^(a u) du ]
    = Re[e^(au)(u/a-1/a^2)]_log2^L.
    """
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    lo = math.log(2.0)

    def primitive(u):
        return np.exp(a*u)*(u/a - 1.0/(a*a))

    return np.real(primitive(L)-primitive(lo))


def generator_arrays(base, primes, Y: int, energies: np.ndarray):
    """
    Compute C0, C1, D1 using the exact prime-power support of v71.

    prime_power_riesz_terms returns log n and exponent m.
    Lambda(n)=log p=(log n)/m.
    """
    logs, _, exponents = base.prime_power_riesz_terms(primes, int(Y))
    m = exponents.astype(float)
    lam = logs/m
    decay = np.exp(-0.5*logs)

    w0 = lam*decay                    # Lambda(n)/sqrt(n)
    w1 = lam*logs*decay               # Lambda(n)log(n)/sqrt(n)

    prime0 = base.trig_sum(energies, logs, w0, "sin")
    prime1 = base.trig_sum(energies, logs, w1, "cos")

    L = math.log(float(Y))
    C0 = np.asarray(prime0, float) - smooth0(energies, L)
    C1 = np.asarray(prime1, float) - smooth1(energies, L)
    D1 = C1 + 0.5*L*L

    return C0, C1, D1, len(logs)


def symbolic_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, u, lam, E = sp.symbols(
        "L u lam E",
        positive=True,
        real=True,
    )

    # Riesz prime coefficient:
    # lam/(logn) * (1-u/L), logn=u.
    coeff = lam/u*(1-u/L)
    dcoeff = sp.simplify(sp.diff(coeff, L))
    expected = lam/L**2
    r0 = sp.simplify(dcoeff-expected)

    # Smooth coefficient in u variable:
    # original M uses (1/u-1/L)e^(u/2) sin(Eu) du*?:
    # after t=e^u, dt=e^u du, t^-1/2=e^-u/2, so e^(u/2).
    smooth_coeff = 1/u - 1/L
    dsmooth = sp.simplify(sp.diff(smooth_coeff, L))
    rs = sp.simplify(dsmooth-1/L**2)

    # E derivative coefficients:
    # derivative prime coefficient becomes lam*(1-u/L)
    slope_coeff = lam*(1-u/L)
    dslope = sp.simplify(sp.diff(slope_coeff, L))
    r1 = sp.simplify(dslope-lam*u/L**2)

    # collision normalized derivative:
    C1 = sp.symbols("C1", real=True)
    Aderiv = -C1/L**2 - sp.Rational(1, 2)
    expected_A = -(C1+L**2/2)/L**2
    rA = sp.simplify(Aderiv-expected_A)

    return {
        "prime_phase_generator_residual": str(r0),
        "smooth_phase_generator_residual": str(rs),
        "prime_slope_generator_residual": str(r1),
        "collision_defect_generator_residual": str(rA),
        "pass": bool(r0 == 0 and rs == 0 and r1 == 0 and rA == 0),
    }


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--roots-csv",
        default="rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--anchors", default="8000000,16000000")
    ap.add_argument(
        "--y-fractions",
        default="1.125,1.25,1.5,1.75,2.0",
    )
    ap.add_argument("--max-modes", type=int, default=32)
    ap.add_argument("--tube-samples", type=int, default=7)
    ap.add_argument("--eta", type=float, default=0.10)
    ap.add_argument("--c-coordinate", type=float, default=1.0)
    ap.add_argument("--sep-fraction", type=float, default=0.60)

    ap.add_argument(
        "--generator-safety",
        type=float,
        default=1.50,
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_riesz_cutoff_generator_v414",
    )

    args = ap.parse_args()
    started = time.time()

    if args.generator_safety <= 1:
        raise ValueError("--generator-safety must be >1")
    if args.tube_samples < 3:
        raise ValueError("--tube-samples must be >=3")

    anchors = sorted(set(parse_ints(args.anchors)))
    qvals = sorted(set(parse_floats(args.y_fractions)))
    if len(anchors) < 2:
        raise ValueError("Need at least two anchors.")
    if any(q <= 1 or q > 2 for q in qvals):
        raise ValueError("Y/X fractions must lie in (1,2].")

    roots_path = Path(args.roots_csv)
    if not roots_path.exists():
        raise FileNotFoundError(roots_path)

    rdf = pd.read_csv(roots_path)
    if "cutoff" not in rdf.columns:
        raise KeyError("roots CSV needs cutoff.")

    ec = energy_col(rdf)
    kc = index_col(rdf)

    roots: Dict[int, np.ndarray] = {}
    for X in anchors:
        g = rdf[rdf["cutoff"].astype(int) == X].sort_values(kc)
        if g.empty:
            raise ValueError(f"Anchor {X} not found.")
        e = g[ec].to_numpy(float)
        if args.max_modes > 0:
            e = e[:args.max_modes]
        roots[X] = e

    common = min(len(v) for v in roots.values())
    roots = {X: v[:common] for X, v in roots.items()}

    dev_anchors = anchors[:-1]
    hold_anchor = anchors[-1]
    maxY = int(math.ceil(max(anchors)*max(qvals)))

    base = importlib.import_module(args.v71_module)

    print("="*236)
    print("ROT-RH v414 — EXACT RIESZ CUTOFF-GENERATOR / POINTWISE HOLDOUT")
    print("="*236)
    print("Xi / zeta / known-zero data             : NONE")
    print("root solves at Y                         : NONE")
    print("anchors                                  :", anchors)
    print("development anchors                      :", dev_anchors)
    print("holdout anchor                           :", hold_anchor)
    print("Y/X fractions                            :", qvals)
    print("common modes                             :", common)
    print("maximum arithmetic Y                     :", f"{maxY:,}")
    print("="*236)

    print("[1] Exact symbolic generator identities")
    sym = symbolic_checks()
    print("symbolic identity pass                   :", sym.get("pass"))
    if not sym.get("pass") and args.strict:
        raise RuntimeError(f"Symbolic identity failure: {sym}")

    print("\n[2] Prime table")
    t0 = time.time()
    primes = base.sieve_primes(maxY)
    print("primes <= maxY                           :", f"{len(primes):,}")
    print("sieve seconds                            :", f"{time.time()-t0:.3f}")

    rows = []
    total = len(anchors)*len(qvals)
    bar = tqdm(total=total, desc="cutoff generators", unit="X,Y")

    for X in anchors:
        E0 = roots[X]
        LX = math.log(float(X))
        radius = (
            (1.0-args.sep_fraction)
            * args.c_coordinate
            / ((0.5+args.eta)*LX)
        )
        offsets = np.linspace(-radius, radius, args.tube_samples)

        for q in qvals:
            Y = int(round(q*X))
            LY = math.log(float(Y))

            C0, C1, D1, terms = generator_arrays(
                base, primes, Y, E0
            )

            # D1 tube for the stiffness-generator theorem.
            Etube = (E0[:, None] + offsets[None, :]).reshape(-1)
            _, _, D1tube_flat, _ = generator_arrays(
                base, primes, Y, Etube
            )
            D1tube = D1tube_flat.reshape(
                len(E0), len(offsets)
            )

            # Also compute actual slope for context, not as part of the
            # generator algebra.
            logsY, weightsY, _ = base.prime_power_riesz_terms(primes, Y)
            slopes_flat = base.phase_prime_grid(
                Etube, Y, logsY, weightsY
            )
            slopes = np.asarray(slopes_flat, float).reshape(
                len(E0), len(offsets)
            )

            for j, E in enumerate(E0, start=1):
                absC0_over_LY = abs(float(C0[j-1]))/LY
                max_absD1tube_over_LY = (
                    float(np.max(np.abs(D1tube[j-1]))) / LY
                )

                # Pointwise generator implies an explicit dyadic transfer bound:
                # |DeltaF| <= K0 log(LY/LX).
                pointwise_scaled_transfer_upper = (
                    absC0_over_LY
                    * LX
                    * math.log(LY/LX)
                    if LY > LX
                    else 0.0
                )

                rows.append({
                    "set": "holdout" if X == hold_anchor else "development",
                    "X": X,
                    "Y": Y,
                    "Y_over_X": q,
                    "root_index": j,
                    "E_k_X": float(E),
                    "logX": LX,
                    "logY": LY,
                    "C0": float(C0[j-1]),
                    "abs_C0_over_logY": absC0_over_LY,
                    "C1": float(C1[j-1]),
                    "D1_collision_subtracted": float(D1[j-1]),
                    "abs_D1_root_over_logY": abs(float(D1[j-1]))/LY,
                    "max_abs_D1_tube_over_logY": max_absD1tube_over_LY,
                    "tube_min_slope_over_logX": (
                        float(np.min(slopes[j-1]))/LX
                    ),
                    "pointwise_generator_scaled_transfer_upper_proxy": (
                        pointwise_scaled_transfer_upper
                    ),
                    "term_count_Y": int(terms),
                })

            bar.update(1)

    bar.close()
    df = pd.DataFrame(rows)

    dev = df[df["set"] == "development"].copy()
    hold = df[df["set"] == "holdout"].copy()

    c0col = "abs_C0_over_logY"
    d1col = "max_abs_D1_tube_over_logY"

    dev_c0 = float(dev[c0col].max())
    dev_d1 = float(dev[d1col].max())

    cap_c0 = args.generator_safety*dev_c0
    cap_d1 = args.generator_safety*dev_d1

    hold_c0 = float(hold[c0col].max())
    hold_d1 = float(hold[d1col].max())

    c0_pass = bool(hold_c0 <= cap_c0)
    d1_pass = bool(hold_d1 <= cap_d1)

    print("\n[3] Prospective pointwise-generator holdout")
    print("development max |C0|/logY               :", f"{dev_c0:.12e}")
    print("frozen C0 generator cap                  :", f"{cap_c0:.12e}")
    print("holdout max |C0|/logY                   :", f"{hold_c0:.12e}")
    print("holdout / C0 cap                         :", f"{hold_c0/cap_c0:.9f}")
    print("C0 pointwise holdout pass                :", c0_pass)
    print()
    print("development max |D1|_tube/logY           :", f"{dev_d1:.12e}")
    print("frozen D1 generator cap                  :", f"{cap_d1:.12e}")
    print("holdout max |D1|_tube/logY              :", f"{hold_d1:.12e}")
    print("holdout / D1 cap                         :", f"{hold_d1/cap_d1:.9f}")
    print("D1 pointwise holdout pass                :", d1_pass)

    print("\nWorst holdout C0 rows:")
    print(
        hold.nlargest(12, c0col)[
            [
                "X","Y","Y_over_X","root_index","E_k_X",
                c0col,"abs_D1_root_over_logY",
                "tube_min_slope_over_logX",
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nWorst holdout D1 tube rows:")
    print(
        hold.nlargest(12, d1col)[
            [
                "X","Y","Y_over_X","root_index","E_k_X",
                c0col,d1col,
                "tube_min_slope_over_logX",
            ]
        ].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    shape = (
        df.groupby(["set","Y_over_X"], as_index=False)
        .agg(
            maximum_abs_C0_over_logY=(c0col, "max"),
            median_abs_C0_over_logY=(c0col, "median"),
            maximum_D1_tube_over_logY=(d1col, "max"),
            minimum_slope_over_logX=(
                "tube_min_slope_over_logX","min"
            ),
        )
        .sort_values(["Y_over_X","set"])
    )

    print("\n[4] Y/X generator shape")
    print(
        shape.to_string(
            index=False,
            float_format=lambda x: f"{x:.12e}",
        )
    )

    theorem_steps = [
        (
            "PHASE_GENERATOR",
            "d_L F_L(E)=-C0(L,E)/L^2 exactly a.e. in L.",
        ),
        (
            "SLOPE_GENERATOR",
            "d_L F'_L(E)=-C1(L,E)/L^2 exactly a.e. in L.",
        ),
        (
            "COLLISION_DEFECT_GENERATOR",
            "d_L(F'_L-L/2)=-D1(L,E)/L^2 with D1=C1+L^2/2.",
        ),
        (
            "TRANSFER_SUFFICIENT_BOUND",
            "|C0|<=K0 L gives |F_M-F_L|<=K0 log(M/L)=O(1/L) for M-L<=log2.",
        ),
        (
            "TRANSVERSALITY_SUFFICIENT_BOUND",
            "|D1|<=K1 L uniformly on a compact fixed-k tube gives F'_L/L->1/2.",
        ),
    ]

    print("\n[5] Exact analytic closure chain")
    for key, txt in theorem_steps:
        print(f"{key:45s}: {txt}")

    gates = {
        "symbolic_generator_identities": bool(sym.get("pass")),
        "C0_pointwise_holdout_pass": c0_pass,
        "D1_pointwise_holdout_pass": d1_pass,
        "all_holdout_slopes_positive": bool(
            (hold["tube_min_slope_over_logX"] > 0).all()
        ),
    }
    failed = [k for k,v in gates.items() if not v]

    if not failed:
        verdict = (
            "PROSPECTIVE_POINTWISE_RIESZ_GENERATOR_HOLDOUT_PASS"
        )
        next_theorem = (
            "PROVE_ALL_X_ROOT_CONDITIONED_C0_O_LOGX_AND_COLLISION_SUBTRACTED_D1_O_LOGX"
        )
    elif not c0_pass and d1_pass:
        verdict = (
            "POINTWISE_TRANSFER_GENERATOR_FREEZE_BREAKS__INTEGRATED_V413_TRANSFER_STILL_MAY_HOLD"
        )
        next_theorem = (
            "USE_SIGNED_SHORT_WINDOW_C0_INTEGRAL_NOT_POINTWISE_C0_MAJORANT"
        )
    elif c0_pass and not d1_pass:
        verdict = (
            "POINTWISE_TRANSFER_GENERATOR_SURVIVES__STIFFNESS_GENERATOR_FREEZE_BREAKS"
        )
        next_theorem = (
            "USE_SUBLINEAR_COLLISION_DEFECT_ROUTE_OR_LOCALIZE_D1_TUBE_GROWTH"
        )
    else:
        verdict = (
            "POINTWISE_GENERATOR_FREEZE_BREAKS_BOTH_CHANNELS"
        )
        next_theorem = (
            "RETAIN_EXACT_GENERATOR_IDENTITIES_BUT_ATTACK_SIGNED_INTEGRATED_BOUNDS"
        )

    print("\n" + "="*236)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print("FAILED GATES                             :", failed if failed else "NONE")
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT PROVED — EXACT GENERATOR REDUCTION + FINITE PROSPECTIVE TEST ONLY",
    )
    print("="*236)

    prefix = Path(args.prefix)
    detail_path = Path(str(prefix) + "_DETAIL.csv")
    shape_path = Path(str(prefix) + "_Y_FRACTION_SHAPE.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    df.to_csv(detail_path, index=False)
    shape.to_csv(shape_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "roots_solved_at_Y": False,
            "finite_scan_accepted_as_proof": False,
        },
        "exact_identities": sym,
        "anchors": {
            "all": anchors,
            "development": dev_anchors,
            "holdout": hold_anchor,
            "y_fractions": qvals,
            "common_modes": common,
        },
        "freeze": {
            "generator_safety": args.generator_safety,
            "development_max_abs_C0_over_logY": dev_c0,
            "frozen_C0_cap": cap_c0,
            "development_max_abs_D1_tube_over_logY": dev_d1,
            "frozen_D1_cap": cap_d1,
        },
        "holdout": {
            "max_abs_C0_over_logY": hold_c0,
            "max_abs_D1_tube_over_logY": hold_d1,
            "C0_pass": c0_pass,
            "D1_pass": d1_pass,
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
        "proof_status": (
            "The cutoff-generator identities are exact. The holdout is finite "
            "arithmetic evidence only. An all-X proof still requires root-conditioned "
            "bounds on C0 and the collision-subtracted D1."
        ),
    }
    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v414 — exact Riesz cutoff-generator theorem

Let `L=log X`.

Define

`C0(L,E)
 = sum Lambda(n)n^(-1/2)sin(E log n)
   - int_2^(e^L)t^(-1/2)sin(E log t)dt`.

For the actual v71 phase,

`d_L F_L(E)=-C0(L,E)/L^2`.

Define

`C1(L,E)
 = sum Lambda(n)log(n)n^(-1/2)cos(E log n)
   - int_2^(e^L)(log t)t^(-1/2)cos(E log t)dt`

and

`D1(L,E)=C1(L,E)+L^2/2`.

Then

`d_L(F'_L(E)-L/2)=-D1(L,E)/L^2`.

Consequently, uniform fixed-k tube bounds

`|C0(L,E)|<=K0_k L`

and

`|D1(L,E)|<=K1_k L`

imply respectively:

`|F_M(E)-F_L(E)|=O_k(1/L)` on every dyadic cutoff window,

and

`F'_L(E)/L -> 1/2`,

hence eventual transversality.

These identities preserve the full prime/PNT cancellation and do not split
endpoint and interior pieces before estimating them.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", detail_path)
    print(" ", shape_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
