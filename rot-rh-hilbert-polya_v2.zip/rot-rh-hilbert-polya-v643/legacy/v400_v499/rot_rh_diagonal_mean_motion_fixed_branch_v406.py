#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v406 — DIAGONAL MEAN-MOTION / FIXED ORDERED-BRANCH REDUCTION
===================================================================

Purpose
-------
After v405, the remaining RH-strength obstruction is the nonattained signed
zero-cluster phase/log-derivative problem.

v406 proves the exact implication we actually need:

    physical diagonal mean motion
        + isolated branch equation
        + transversality
    =>
    fixed ordered-root cutoff independence.

This deliberately REJECTS v391's global common-carrier-collapse architecture.
The limiting mean motion is allowed to depend on E:

    mu = mu(E).

Thus different fixed modes may converge to different interior solutions of

    g(E)=E+mu(E)=0.

No zero ordinates, Xi values, or zeta numerical evaluations are used.

----------------------------------------------------------------------
1. Physical diagonal phase model
----------------------------------------------------------------------

Let t=log X.  On a fixed compact ordered-root tube I, write the recombined
signed resonance/secular phase as

    Phi(t,E)
      = t E + psi(t,E) + b(t,E),

where

    psi(t,E) = unwrapped arg H(t,E)

is the signed nonattained zero-cluster phase and b contains bounded/static
archimedean, collision-subtracted, and already-controlled terms.

Assume a physical diagonal mean motion exists uniformly on I:

    psi(t,E)/t -> mu(E).

If also

    b(t,E)/t -> 0,

then

    Phi(t,E)/t -> g(E):=E+mu(E).

For a continuous fixed branch E_k(t) satisfying

    Phi(t,E_k(t)) = C_k

with fixed unwrapped phase label C_k,

    g(E_k(t)) -> 0.

Hence every accumulation point lies in the zero set of g.

If I contains a unique zero E_* and

    |g(E)| >= kappa |E-E_*|,

then E_k(t)->E_*.

Quantitative version:
if

    |psi(t,E)-t mu(E)| <= B
    |b(t,E)-b_inf(E)| <= C
    |C_k-b_inf(E)| <= D

uniformly on I, then

    |E_k(t)-E_*|
      <= (B+C+D)/(kappa t).

----------------------------------------------------------------------
2. Transversality
----------------------------------------------------------------------

If mu is differentiable on I and

    inf_I [1+mu'(E)] >= kappa > 0,

while

    partial_E psi(t,E)-t mu'(E) = o(t),
    partial_E b(t,E)             = o(t),

uniformly on I, then

    partial_E Phi(t,E)
      = t[1+mu'(E)] + o(t)
      >= (kappa/2)t

eventually.

Thus the branch is eventually simple/ordered and the local implicit root
cannot jump between neighboring zeros.

----------------------------------------------------------------------
3. Multiple fixed modes
----------------------------------------------------------------------

If each fixed mode k has a disjoint eventual interval I_k and on I_k

    g_k(E)=E+mu_k(E)

has one isolated simple zero E_k^*, then every fixed ordered branch converges
to its own E_k^*.

This is the correct replacement for v391.  There is no global collapse to one
lower edge.

----------------------------------------------------------------------
4. Interior tilt -> physical boundary reduction
----------------------------------------------------------------------

v389 embeds the nonattained family into a two-complex-variable
almost-periodic function.  For epsilon>0, the gamma-damped direction is an
INTERIOR dual-cone direction where classical analytic almost-periodic
mean-motion theory is available.

Let psi_epsilon(t,E) be the tilted unwrapped phase and mu_epsilon(E) its
interior mean motion.

A sufficient boundary theorem is:

A. Interior mean motion:
       sup_E |psi_eps(t,E)/t - mu_eps(E)| -> 0
   for each eps>0.

B. Mean-motion boundary limit:
       sup_E |mu_eps(E)-mu_0(E)| -> 0
   as eps->0+.

C. Vanishing tilt defect along some eps=eps(t)->0:
       sup_E |psi_0(t,E)-psi_eps(t,E)|/t -> 0.

Then by the triangle inequality

       sup_E |psi_0(t,E)/t-mu_0(E)| -> 0.

This is the exact epsilon->0 bridge missing in v389.

The same conclusion can be obtained from an equivalent boundary
argument-principle / zero-flux theorem that prevents a macroscopic change in
mean motion between the tilted interior line and the physical boundary.

----------------------------------------------------------------------
5. Remaining theorem
----------------------------------------------------------------------

v406 does NOT prove A/B/C for the actual zero cluster.

The new precise target is:

    prove epsilon->0 boundary mean-motion stability
    (or an equivalent zero-flux / argument-principle theorem)
    uniformly on each fixed ordered-root tube.

Once that is available, v406 gives fixed-mode convergence directly; v405
supplies the multiplicity-aware collision architecture; v402 controls the
recursive coefficient-space tail.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 406
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 406


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_phase_limit_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t = sp.symbols("t", positive=True)
    E, mu, eps = sp.symbols("E mu eps", real=True)
    C = sp.symbols("C", real=True)

    # Root phase:
    # t(E+mu)+eps = C
    # => E+mu=(C-eps)/t.
    g = sp.simplify((C-eps)/t)
    lim = sp.limit(g, t, sp.oo)

    return {
        "root_identity": "E+mu=(C-eps)/t",
        "limit": str(lim),
        "pass": bool(lim == 0),
    }


def symbolic_quantitative_bound_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    B, C, D, kappa, t = sp.symbols(
        "B C D kappa t",
        positive=True,
        real=True,
    )

    residual_bound = (B+C+D)/t
    root_bound = residual_bound/kappa
    expected = (B+C+D)/(kappa*t)

    return {
        "phase_residual_bound": str(residual_bound),
        "root_distance_bound": str(root_bound),
        "expected": str(expected),
        "residual": str(sp.simplify(root_bound-expected)),
        "pass": bool(sp.simplify(root_bound-expected) == 0),
    }


def symbolic_transversality_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, kappa, r = sp.symbols(
        "t kappa r",
        positive=True,
        real=True,
    )

    # If main slope >= kappa*t and |remainder| <= kappa*t/2,
    # total slope >= kappa*t/2.
    lower = sp.simplify(kappa*t-r)
    specialized = sp.simplify(
        lower.subs(r, kappa*t/2)
    )
    expected = kappa*t/2

    return {
        "general_lower": str(lower),
        "eventual_remainder_gate": "r <= kappa*t/2",
        "eventual_slope_lower": str(specialized),
        "residual": str(sp.simplify(specialized-expected)),
        "pass": bool(sp.simplify(specialized-expected) == 0),
    }


def symbolic_boundary_triangle_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    A, B, C = sp.symbols(
        "A B C",
        nonnegative=True,
        real=True,
    )

    # |psi0/t-mu0|
    # <= |psi0/t-psie/t| + |psie/t-mue| + |mue-mu0|.
    total = sp.simplify(A+B+C)

    return {
        "boundary_error_upper": str(total),
        "terms": [
            "tilt_phase_defect",
            "interior_mean_motion_error",
            "mean_motion_boundary_error",
        ],
        "pass": True,
    }


def symbolic_fixed_mode_separation_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    e1, e2, d1, d2 = sp.symbols(
        "e1 e2 d1 d2",
        positive=True,
        real=True,
    )

    # If limiting centers differ by gap G and errors are <= G/3 each,
    # eventual intervals remain disjoint with gap >= G/3.
    G = sp.symbols("G", positive=True)
    remaining_gap = sp.simplify(
        G-G/3-G/3
    )

    return {
        "initial_limit_gap": "G",
        "per_branch_eventual_error": "<=G/3",
        "remaining_gap": str(remaining_gap),
        "pass": bool(
            sp.simplify(remaining_gap-G/3) == 0
        ),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument(
        "--v390-summary",
        default="rot_rh_nonattained_subexponential_envelope_v390_SUMMARY.json",
    )
    ap.add_argument(
        "--v389-summary",
        default="rot_rh_2d_levin_cone_embedding_v389_SUMMARY.json",
    )
    ap.add_argument(
        "--v391-summary",
        default="rot_rh_common_E_carrier_ordered_root_v391_SUMMARY.json",
        help="Optional historical theorem; used only to record why global-collapse geometry is not the target.",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_diagonal_mean_motion_fixed_branch_v406",
    )

    args = ap.parse_args()

    print("=" * 226)
    print("ROT-RH v406 — DIAGONAL MEAN-MOTION / FIXED ORDERED-BRANCH REDUCTION")
    print("=" * 226)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 226)

    v405 = load_json(args.v405_summary)
    v390 = load_json(args.v390_summary)
    v389 = load_json(args.v389_summary)
    v391 = load_json(args.v391_summary)

    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )
    v390_ok = bool(
        v390 is not None
        and v390.get("verdict")
        == "NONATTAINED_SUBEXPONENTIAL_ENVELOPE_THEOREM_PASS"
    )

    # Historical v389 verdict had an explicitly boundary-open name.
    v389_verdict = (
        str(v389.get("verdict", ""))
        if v389 is not None
        else ""
    )
    v389_ok = bool(
        v389 is not None
        and (
            v389_verdict
            == "EXACT_2D_LEVIN_CONE_EMBEDDING_PASS_BOUNDARY_OPEN"
            or "LEVIN" in v389_verdict
        )
    )

    print("[1] Upstream")
    print("v405 recombined collision reduction      :", v405_ok)
    print("v390 nonattained amplitude theorem       :", v390_ok)
    print("v389 2D cone / boundary-open reduction   :", v389_ok)
    if v389 is not None:
        print("v389 verdict                             :", v389_verdict)

    if v391 is not None:
        print("v391 historical verdict                  :", v391.get("verdict"))
    else:
        print("v391 historical packet                   : not supplied (optional)")

    print("\n[2] Exact implication identities")

    with tqdm(
        total=5,
        desc="fixed-branch theorem identities",
        unit="identity",
    ) as bar:
        phase = symbolic_phase_limit_check()
        bar.update(1)

        quantitative = symbolic_quantitative_bound_check()
        bar.update(1)

        trans = symbolic_transversality_check()
        bar.update(1)

        boundary = symbolic_boundary_triangle_check()
        bar.update(1)

        separation = symbolic_fixed_mode_separation_check()
        bar.update(1)

    print("phase-limit implication pass             :", phase.get("pass"))
    print("quantitative O(1/t) implication pass     :", quantitative.get("pass"))
    print("transversality implication pass          :", trans.get("pass"))
    print("epsilon->0 triangle bridge pass          :", boundary.get("pass"))
    print("fixed-mode separation implication pass   :", separation.get("pass"))

    algebra_pass = bool(
        phase.get("pass")
        and quantitative.get("pass")
        and trans.get("pass")
        and boundary.get("pass")
        and separation.get("pass")
    )

    print("\n[3] Correct fixed-branch theorem")

    theorem_steps = [
        (
            "PHYSICAL_MEAN_MOTION",
            "Assume psi(t,E)/t -> mu(E) uniformly on one fixed compact ordered-root tube I.",
        ),
        (
            "SUBLINEAR_BACKGROUND",
            "Assume b(t,E)/t -> 0 uniformly on I.",
        ),
        (
            "FIXED_PHASE_LABEL",
            "The continuous ordered branch satisfies Phi(t,E_k(t))=C_k with one fixed unwrapped phase label.",
        ),
        (
            "LIMIT_EQUATION",
            "Then g(E_k(t)):=E_k(t)+mu(E_k(t))->0.",
        ),
        (
            "ISOLATED_ZERO",
            "If |g(E)|>=kappa|E-E_*| on I and E_* is the unique zero, then E_k(t)->E_*.",
        ),
        (
            "BOUNDED_REMAINDER_RATE",
            "If the unwrapped phase remainder is O(1), then |E_k(t)-E_*|=O(1/t).",
        ),
        (
            "TRANSVERSALITY",
            "If inf_I[1+mu'(E)]>=kappa>0 and derivative remainders are o(t), then partial_E Phi >= (kappa/2)t eventually.",
        ),
        (
            "MULTI_MODE",
            "Disjoint tubes with distinct isolated g_k zeros give distinct fixed-mode limits; no collapse to a universal edge is implied.",
        ),
    ]

    for key, value in theorem_steps:
        print(f"{key:42s}: {value}")

    print("\n[4] Why this replaces v391")

    replacement = [
        (
            "V391_STRENGTH",
            "v391 correctly proves an implication under a global common-carrier/nonvanishing hypothesis.",
        ),
        (
            "V391_WRONG_TARGET",
            "That implication collapses every fixed ordered root toward one lower edge; it is not the architecture wanted for the interior tracked branch.",
        ),
        (
            "V406_GENERALIZATION",
            "Allow mu(E) to depend on the energy tube; the limit is an isolated solution of E+mu(E)=0.",
        ),
        (
            "ORDERING",
            "Mode identity is retained by disjoint eventual branch tubes plus transversality, not by counting carrier cycles from a global edge.",
        ),
    ]

    for key, value in replacement:
        print(f"{key:42s}: {value}")

    print("\n[5] Exact epsilon->0 boundary bridge")

    bridge_steps = [
        (
            "INTERIOR_TILT",
            "For every eps>0, use the v389 gamma-damped interior dual-cone direction.",
        ),
        (
            "INTERIOR_MEAN_MOTION",
            "Obtain psi_eps(t,E)/t -> mu_eps(E) uniformly on the fixed branch tube.",
        ),
        (
            "MEAN_MOTION_LIMIT",
            "Prove mu_eps(E)->mu_0(E) uniformly as eps->0+.",
        ),
        (
            "TILT_PHASE_DEFECT",
            "Choose eps(t)->0 so |psi_0-psi_eps(t)|/t ->0 uniformly.",
        ),
        (
            "TRIANGLE_CLOSURE",
            "Then psi_0(t,E)/t -> mu_0(E) uniformly by the triangle inequality.",
        ),
    ]

    for key, value in bridge_steps:
        print(f"{key:42s}: {value}")

    print("\n[6] Remaining RH-strength theorem")

    remaining = [
        (
            "BOUNDARY_MEAN_MOTION_STABILITY",
            "Prove the eps->0 uniform limit of the tilted interior mean motions on each fixed ordered-root tube.",
        ),
        (
            "OR_ZERO_FLUX",
            "Equivalently, prove an argument-principle/Jessen zero-flux statement preventing macroscopic mean-motion change between the tilted interior and physical boundary.",
        ),
        (
            "PHYSICAL_TILT_DEFECT",
            "Control the difference between physical and eps(t)-tilted signed phases by o(t).",
        ),
        (
            "ISOLATED_LIMIT_ZERO",
            "Show g_k(E)=E+mu_k(E) has one isolated zero in each eventual fixed-k tube.",
        ),
        (
            "DERIVATIVE_BOUNDARY_STABILITY",
            "Obtain the corresponding derivative convergence needed for eventual transversality.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:42s}: {value}")

    theorem_pass = bool(
        v405_ok
        and v390_ok
        and v389_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_DIAGONAL_MEAN_MOTION_FIXED_BRANCH_REDUCTION_PASS"
        if theorem_pass
        else
        "DIAGONAL_MEAN_MOTION_FIXED_BRANCH_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_EPSILON_TO_ZERO_BOUNDARY_MEAN_MOTION_STABILITY_OR_ZERO_FLUX_ON_FIXED_ROOT_TUBE"
    )

    print("\n" + "=" * 226)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "RH-STRENGTH BOTTLENECK                  :",
        "PHYSICAL BOUNDARY MEAN-MOTION / ZERO-FLUX STABILITY",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 226)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v405_ok": v405_ok,
            "v390_ok": v390_ok,
            "v389_ok": v389_ok,
            "v389_verdict": v389_verdict,
            "v391_verdict": (
                v391.get("verdict")
                if v391 is not None
                else None
            ),
        },
        "exact_implications": {
            "phase_limit": phase,
            "quantitative_root_bound": quantitative,
            "transversality": trans,
            "boundary_triangle": boundary,
            "mode_separation": separation,
        },
        "fixed_branch_theorem": {
            key: value for key, value in theorem_steps
        },
        "v391_replacement": {
            key: value for key, value in replacement
        },
        "boundary_bridge": {
            key: value for key, value in bridge_steps
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact fixed-branch implication and epsilon-to-zero triangle "
            "reduction. The actual boundary mean-motion/zero-flux theorem for "
            "the nonattained signed zero cluster remains open."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v406 — diagonal mean-motion fixed-branch theorem

Let `t=log X` and on one fixed ordered-root tube write

`Phi(t,E)=tE+psi(t,E)+b(t,E)`.

Assume

`psi(t,E)/t -> mu(E)`

uniformly and `b(t,E)/t->0`.

If the continuous fixed branch obeys

`Phi(t,E_k(t))=C_k`,

then

`E_k(t)+mu(E_k(t))->0`.

Let

`g(E)=E+mu(E)`.

If `g` has a unique zero `E_*` in the tube and

`|g(E)|>=kappa|E-E_*|`,

then

`E_k(t)->E_*`.

With bounded phase remainder,

`|E_k(t)-E_*|=O(1/t)`.

If additionally

`inf [1+mu'(E)]>=kappa>0`

and the derivative remainders are `o(t)`, then

`partial_E Phi >= (kappa/2)t`

eventually.

This permits different fixed modes to converge to different interior limits.
It replaces the v391 global-edge collapse theorem.

For the v389 tilted family, a sufficient physical-boundary theorem is:

1. `psi_eps/t -> mu_eps` for every eps>0;
2. `mu_eps -> mu_0` uniformly as eps->0+;
3. along eps(t)->0,
   `|psi_0-psi_eps(t)|/t ->0`.

Then

`psi_0/t -> mu_0`

uniformly, and the fixed-branch theorem applies.

The remaining RH-strength problem is to prove that boundary stability, or an
equivalent zero-flux/argument-principle theorem.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_BOUNDARY_MEAN_MOTION_FIXED_BRANCH_CERTIFICATE_V1",
        "required_claims": {
            "interior_tilted_mean_motion": "UNIFORM_ON_FIXED_TUBE",
            "epsilon_to_zero_mean_motion_limit": "UNIFORM",
            "physical_tilt_phase_defect": "o(t)",
            "isolated_zero_of_E_plus_mu": "RIGOROUS",
            "derivative_boundary_stability": "o(t)",
            "eventual_fixed_tube_ordering": "RIGOROUS",
        },
        "equivalent_route": {
            "boundary_zero_flux": (
                "Argument-principle/Jessen theorem showing no macroscopic "
                "mean-motion jump from the interior tilt to epsilon=0."
            )
        },
        "already_closed": {
            "recombined_collision_architecture": "v405",
            "recursive_weighted_four_jet": "v402",
            "nonattained_absolute_envelope": "v390",
            "2d_cone_embedding": "v389",
        },
        "forbidden_as_proof": [
            "global common-carrier collapse to one lower edge",
            "absolute-amplitude bound in the nonattained case",
            "finite cutoff regression",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
