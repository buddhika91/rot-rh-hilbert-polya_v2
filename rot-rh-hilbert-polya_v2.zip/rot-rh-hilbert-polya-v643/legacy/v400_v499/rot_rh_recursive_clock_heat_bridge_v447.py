#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v447 — RECURSIVE-CLOCK HEAT-SEMIGROUP BRIDGE AUDIT
==========================================================

PURPOSE
-------
Attack the v446 heat-semigroup formulation directly, without known Riemann-zero
ordinates and without zeta()/Xi() calls.

The target identity is

    Tr exp(-u H_ROT^2) = K_Xi(u),

where

    M(z) = d/dz log[ Xi(i sqrt(z)) / Xi(0) ]
         = integral_0^infinity exp(-z u) K_Xi(u) du.

This audit uses three routes:

A) DIRECT THETA TARGET (zero-ordinate-free)
   Evaluate M(z) directly from the Jacobi-theta integral on the Euclidean axis,
   then numerically invert its Laplace transform with Stehfest.  This yields a
   pointwise heat target K_Xi(u) without using known zeros.

B) v446 STIELTJES/JACOBI OPERATOR
   Build the positive finite Jacobi approximation to K = H_ROT^{-2} from theta
   logarithmic moments q_m.  Its heat trace is

       K_J,N(u) = sum_j m_j exp(-u/lambda_j),
       m_j = q1 * w_j / lambda_j.

   Compare K_J,N(u) against the direct theta target and check dimension
   convergence.

C) v445 RECURSIVE-CLOCK PRIME SPECTRUM
   Build the zero-free arithmetic clock spectra E_k(X) and compare

       K_clock,X(u) = sum_k exp(-u E_k(X)^2)

   with K_Xi(u).  Also compute Riesz-1 and free-Gamma controls.

The clock branch is the scientifically interesting bridge test.  A close match
at one cutoff is not enough: the script reports the full cutoff trajectory and
successive heat-vector drift, so a resonant finite-cutoff hit is not mistaken
for cutoff independence.

SCIENTIFIC BOUNDARY
-------------------
This is a finite numerical audit, not an RH proof.  The direct theta target and
v446 moment branch use the same theta representation through different
computational routes; only the v445 arithmetic clock branch is an independent
operator-side construction.  All-order positivity and an analytic ROT
heat-generator theorem remain separate tasks.

Required local modules:
    rot_rh_clock_theta_jacobi_v445.py
    rot_rh_stieltjes_thorin_heat_v446.py

Typical PowerShell run:
    python .\rot_rh_recursive_clock_heat_bridge_v447.py `
      --depth 48 `
      --clock-cutoffs 72900,145800,291600,583200 `
      --riesz-cutoffs 72900,145800,291600,583200 `
      --grid-points 64 `
      --moment-order 32 `
      --jacobi-dims 8,12,16 `
      --mp-dps 130 `
      --heat-u 0.008,0.010,0.0125,0.015,0.020,0.030 `
      --stehfest-degree-low 18 `
      --stehfest-degree-high 22 `
      --prefix rot_rh_recursive_clock_heat_bridge_v447
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import numpy as np
from tqdm import tqdm

VERSION = "2026-08-25-v447-recursive-clock-heat-semigroup-bridge"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def rms(values: Iterable[float]) -> float:
    a = np.asarray(list(values), dtype=float)
    return float(np.sqrt(np.mean(a * a))) if a.size else float("nan")


def relerr(a: float, b: float, floor: float = 1.0e-300) -> float:
    return abs(float(a) - float(b)) / max(abs(float(b)), floor)


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def module_sha(module) -> Dict[str, str]:
    p = Path(module.__file__).resolve()
    return {"path": str(p), "sha256": sha256_file(p)}


def import_required(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place the v445/v446 scripts in the same directory as v447 "
            "or pass --v445-module/--v446-module."
        )


# =============================================================================
# Route A: direct theta resolvent and inverse-Laplace heat target
# =============================================================================

class DirectThetaTarget:
    """
    Fast high-precision quadrature for the Euclidean theta representation.

    Put x=e^r in the standard theta integral.  With

        phi(r) = psi(e^r) e^(r/4),
        I(z)   = int_0^inf phi(r) cosh(sqrt(z) r/2) dr,

    the unnormalized Euclidean Xi function is

        N(z) = 1/2 - (1/4-z) I(z),

    and M(z)=(log N)' is independent of the normalization N(0).

    No zeta, xi, Xi, or known-zero calls are used.
    """

    def __init__(
        self,
        dps: int,
        quad_order: int,
        breakpoints: Sequence[float],
    ) -> None:
        mp.mp.dps = int(dps)
        self.dps = int(dps)
        self.quad_order = int(quad_order)
        self.breakpoints = [mp.mpf(str(x)) for x in breakpoints]

        xg, wg = mp.gauss_quadrature(self.quad_order, "legendre")
        nodes: List[mp.mpf] = []
        weighted_phi: List[mp.mpf] = []

        for a, b in zip(self.breakpoints[:-1], self.breakpoints[1:]):
            mid = (a + b) / 2
            half = (b - a) / 2
            for i in range(self.quad_order):
                r = mid + half * xg[i]
                q = mp.e ** (-mp.pi * mp.e ** r)
                psi = (mp.jtheta(3, 0, q) - 1) / 2
                phi = psi * mp.e ** (r / 4)
                nodes.append(r)
                weighted_phi.append(half * wg[i] * phi)

        self.nodes = nodes
        self.weighted_phi = weighted_phi
        self.xi0 = self.N(mp.mpf("0"))

    def _I_Iz(self, z):
        if isinstance(z, (complex, mp.mpc)):
            z = mp.mpc(z)
            I = mp.mpc("0")
            Iz = mp.mpc("0")
        else:
            z = mp.mpf(z)
            I = mp.mpf("0")
            Iz = mp.mpf("0")
        y = mp.sqrt(z)

        if abs(y) < mp.mpf("1e-40"):
            for r, w in zip(self.nodes, self.weighted_phi):
                I += w
                Iz += w * r * r / 8
        else:
            for r, w in zip(self.nodes, self.weighted_phi):
                a = y * r / 2
                I += w * mp.cosh(a)
                Iz += w * (r / (4 * y)) * mp.sinh(a)
        return I, Iz

    def N(self, z):
        I, _ = self._I_Iz(z)
        return mp.mpf("0.5") - (mp.mpf("0.25") - z) * I

    def M(self, z):
        I, Iz = self._I_Iz(z)
        N = mp.mpf("0.5") - (mp.mpf("0.25") - z) * I
        Np = I - (mp.mpf("0.25") - z) * Iz
        return Np / N

    def heat_stehfest(self, u: mp.mpf, degree: int):
        # Stehfest samples only the positive real Laplace axis.
        return mp.invertlaplace(self.M, u, method="stehfest", degree=int(degree))


# =============================================================================
# Route B: v446 moment/Jacobi finite operator
# =============================================================================

def jacobi_at_dim(q: Sequence[mp.mpf], dim: int, support_scale: mp.mpf):
    """
    Build one finite Jacobi quadrature without re-running every lower-order
    Hankel audit.  The full positivity audit is run once at max(dim) via v446.
    """
    q1 = q[0]
    moments = [q[k] / (q1 * support_scale**k) for k in range(len(q))]

    M0 = mp.matrix(dim)
    M1 = mp.matrix(dim)
    for i in range(dim):
        for j in range(dim):
            M0[i, j] = moments[i + j]
            M1[i, j] = moments[i + j + 1]

    L = mp.cholesky(M0)
    Linv = L**-1
    Jy = Linv * M1 * Linv.T
    Jy = (Jy + Jy.T) / 2
    J = support_scale * Jy
    evals, evecs = mp.eigsy(J)

    lam = [evals[i] for i in range(dim)]
    w = [evecs[0, i] ** 2 for i in range(dim)]
    mult = [
        q1 * w[i] / lam[i] if lam[i] > 0 else mp.nan
        for i in range(dim)
    ]
    return J, lam, w, mult


def jacobi_heat(q1, lam, w, u):
    return mp.fsum(
        [
            (q1 * w[i] / lam[i]) * mp.e ** (-u / lam[i])
            for i in range(len(lam))
            if lam[i] > 0
        ]
    )


def jacobi_resolvent(q1, lam, w, z):
    return q1 * mp.fsum(
        [w[i] / (1 + z * lam[i]) for i in range(len(lam))]
    )


# =============================================================================
# Route C: recursive-clock / Riesz / free spectral traces
# =============================================================================

def spectral_heat(levels: np.ndarray, u: float) -> float:
    e = np.asarray(levels, dtype=float)
    return float(np.sum(np.exp(-float(u) * e * e)))


def spectral_resolvent(levels: np.ndarray, z: float) -> float:
    e = np.asarray(levels, dtype=float)
    return float(np.sum(1.0 / (float(z) + e * e)))


def vector_rel_rms(candidate: Sequence[float], target: Sequence[float]) -> float:
    c = np.asarray(candidate, dtype=float)
    t = np.asarray(target, dtype=float)
    r = np.abs(c - t) / np.maximum(np.abs(t), 1.0e-300)
    return float(np.sqrt(np.mean(r * r)))


def successive_vector_drift(a: Sequence[float], b: Sequence[float]) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum.reduce([np.abs(aa), np.abs(bb), np.full_like(aa, 1e-300)])
    return float(np.sqrt(np.mean(((aa - bb) / scale) ** 2)))


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v447 recursive-clock heat-semigroup bridge audit",
    )

    ap.add_argument("--v445-module", default="rot_rh_clock_theta_jacobi_v445")
    ap.add_argument("--v446-module", default="rot_rh_stieltjes_thorin_heat_v446")

    # Independent arithmetic operator branch.
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument(
        "--clock-cutoffs",
        default="72900,145800,291600,583200",
    )
    ap.add_argument(
        "--riesz-cutoffs",
        default="72900,145800,291600,583200",
    )
    ap.add_argument("--grid-points", type=int, default=64)

    # v446 moment/Jacobi route.
    ap.add_argument("--moment-order", type=int, default=32)
    ap.add_argument("--jacobi-dims", default="8,12,16")
    ap.add_argument("--mp-dps", type=int, default=130)

    # Direct theta heat target.
    ap.add_argument(
        "--heat-u",
        default="0.008,0.010,0.0125,0.015,0.020,0.030",
    )
    ap.add_argument("--resolvent-z", default="0,1,5,10,25,50,100")
    ap.add_argument("--theta-quad-order", type=int, default=22)
    ap.add_argument(
        "--theta-breakpoints",
        default="0,0.5,1,1.5,2,2.5,3,3.5,4,5,6",
    )
    ap.add_argument("--stehfest-degree-low", type=int, default=18)
    ap.add_argument("--stehfest-degree-high", type=int, default=22)

    # Direct complete-monotonicity spot checks of M(z).
    ap.add_argument("--cm-z", default="1,10,50")
    ap.add_argument("--cm-order", type=int, default=5)

    # Numerical reliability / interpretation gates.
    ap.add_argument("--maximum-inversion-relative-gap", type=float, default=0.005)
    ap.add_argument("--maximum-jacobi-heat-relative-rms", type=float, default=0.002)
    ap.add_argument("--maximum-jacobi-resolvent-relative-rms", type=float, default=0.002)
    ap.add_argument("--clock-interesting-relative-rms", type=float, default=0.005)
    ap.add_argument("--depth-check-fraction", type=float, default=0.75)

    ap.add_argument("--prefix", default="rot_rh_recursive_clock_heat_bridge_v447")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.depth < 8:
        raise ValueError("--depth must be >= 8")
    if not (0.25 <= args.depth_check_fraction < 1.0):
        raise ValueError("--depth-check-fraction must lie in [0.25,1)")
    if args.stehfest_degree_low < 8:
        raise ValueError("--stehfest-degree-low too small")
    if args.stehfest_degree_high <= args.stehfest_degree_low:
        raise ValueError("--stehfest-degree-high must exceed --stehfest-degree-low")

    jacobi_dims = sorted(set(parse_ints(args.jacobi_dims)))
    if not jacobi_dims:
        raise ValueError("empty --jacobi-dims")
    if args.moment_order < 2 * max(jacobi_dims):
        raise ValueError("--moment-order must be >= 2*max(--jacobi-dims)")

    heat_u = parse_floats(args.heat_u)
    if any(u <= 0 for u in heat_u):
        raise ValueError("all --heat-u values must be positive")
    resolvent_z = parse_floats(args.resolvent_z)
    if any(z < 0 for z in resolvent_z):
        raise ValueError("--resolvent-z must be nonnegative")

    clock_cutoffs = parse_ints(args.clock_cutoffs)
    riesz_cutoffs = parse_ints(args.riesz_cutoffs)
    if clock_cutoffs != sorted(clock_cutoffs):
        raise ValueError("--clock-cutoffs must be increasing")
    if riesz_cutoffs != sorted(riesz_cutoffs):
        raise ValueError("--riesz-cutoffs must be increasing")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    v445 = import_required(args.v445_module)
    v446 = import_required(args.v446_module)
    mp.mp.dps = int(args.mp_dps)

    print("=" * 154)
    print("ROT-RH v447 — RECURSIVE-CLOCK HEAT-SEMIGROUP BRIDGE AUDIT")
    print("=" * 154)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("direct target                      : theta integral -> M(z) -> inverse Laplace")
    print("operator route A                   : v446 positive Stieltjes/Jacobi K=H^-2")
    print("operator route B                   : v445 recursive-clock Mangoldt spectrum")
    print("controls                           : free Gamma + Riesz-1")
    print("scientific target                  : Tr exp(-u H_ROT^2) = K_Xi(u)")
    print("=" * 154)

    # -------------------------------------------------------------------------
    # A. Direct theta target
    # -------------------------------------------------------------------------
    theta_breaks = parse_floats(args.theta_breakpoints)
    print("\n[A] Building direct theta Euclidean target ...")
    target = DirectThetaTarget(
        dps=args.mp_dps,
        quad_order=args.theta_quad_order,
        breakpoints=theta_breaks,
    )
    print("theta Xi(0) direct =", mp.nstr(target.xi0, 50))

    target_rows: List[dict] = []
    target_heat: List[float] = []
    target_reliable: List[bool] = []
    max_inv_gap = 0.0
    all_target_positive = True

    for uu in tqdm(heat_u, desc="direct theta inverse Laplace", unit="u"):
        u = mp.mpf(str(uu))
        klo = target.heat_stehfest(u, args.stehfest_degree_low)
        khi = target.heat_stehfest(u, args.stehfest_degree_high)
        gap = float(abs(khi - klo) / max(abs(khi), mp.mpf("1e-100")))
        reliable = gap <= args.maximum_inversion_relative_gap
        positive = bool(mp.re(khi) > 0 and abs(mp.im(khi)) < mp.mpf("1e-50"))
        kval = float(mp.re(khi))
        target_heat.append(kval)
        target_reliable.append(reliable)
        max_inv_gap = max(max_inv_gap, gap)
        all_target_positive = all_target_positive and positive
        target_rows.append(
            {
                "u": f"{uu:.17g}",
                "K_theta_stehfest_low": mp.nstr(klo, 70),
                "K_theta_stehfest_high": mp.nstr(khi, 70),
                "relative_degree_gap": f"{gap:.17g}",
                "reliable": reliable,
                "positive": positive,
            }
        )

    target_heat_path = Path(str(prefix) + "_THETA_HEAT_TARGET.csv")
    write_csv(target_heat_path, list(target_rows[0].keys()), target_rows)

    # Direct complete-monotonicity spot checks.
    cm_rows: List[dict] = []
    cm_pass = True
    cm_min_signed = mp.inf
    for zz in tqdm(parse_floats(args.cm_z), desc="direct M complete monotonicity", unit="z"):
        z = mp.mpf(str(zz))
        for n in range(args.cm_order + 1):
            deriv = mp.diff(target.M, z, n)
            signed = ((-1) ** n) * deriv
            ok = bool(mp.re(signed) >= 0 and abs(mp.im(signed)) < mp.mpf("1e-45"))
            cm_pass = cm_pass and ok
            cm_min_signed = min(cm_min_signed, mp.re(signed))
            cm_rows.append(
                {
                    "z": f"{zz:.17g}",
                    "derivative_order": n,
                    "M_derivative": mp.nstr(deriv, 60),
                    "signed_minus1n_derivative": mp.nstr(signed, 60),
                    "pass_nonnegative": ok,
                }
            )
    cm_path = Path(str(prefix) + "_DIRECT_COMPLETE_MONOTONICITY.csv")
    write_csv(cm_path, list(cm_rows[0].keys()), cm_rows)

    # -------------------------------------------------------------------------
    # B. v446 Stieltjes/Jacobi finite operator
    # -------------------------------------------------------------------------
    print("\n[B] Building v446 theta moments and Jacobi operators ...")
    c, unit, q = v446.theta_data(args.moment_order, args.mp_dps)
    q1 = q[0]
    xi0_route_gap = float(
        abs(target.xi0 - c[0]) / max(abs(target.xi0), mp.mpf("1e-100"))
    )

    # Run the full v446 positivity audit once at largest dimension.
    support_scale, hankel_rows, Jmax_audit, lam_audit, w_audit, mult_audit = (
        v446.stieltjes_jacobi(q, max(jacobi_dims))
    )

    jacobi_rows: List[dict] = []
    jacobi_summary_rows: List[dict] = []
    jacobi_models = {}

    for dim in jacobi_dims:
        J, lam, w, mult = jacobi_at_dim(q, dim, support_scale)
        jacobi_models[dim] = (J, lam, w, mult)

        vec = []
        rels = []
        for uu, kt in zip(heat_u, target_heat):
            kj = jacobi_heat(q1, lam, w, mp.mpf(str(uu)))
            kjf = float(mp.re(kj))
            er = relerr(kjf, kt)
            vec.append(kjf)
            rels.append(er)
            jacobi_rows.append(
                {
                    "dim": dim,
                    "u": f"{uu:.17g}",
                    "K_jacobi": mp.nstr(kj, 70),
                    "K_theta_target": f"{kt:.17g}",
                    "relative_error": f"{er:.17g}",
                }
            )

        jacobi_summary_rows.append(
            {
                "dim": dim,
                "heat_relative_rms": f"{rms(rels):.17g}",
                "heat_relative_max": f"{max(rels):.17g}",
            }
        )

    jacobi_heat_path = Path(str(prefix) + "_JACOBI_HEAT.csv")
    write_csv(jacobi_heat_path, list(jacobi_rows[0].keys()), jacobi_rows)

    jacobi_summary_path = Path(str(prefix) + "_JACOBI_DIM_SUMMARY.csv")
    write_csv(
        jacobi_summary_path,
        list(jacobi_summary_rows[0].keys()),
        jacobi_summary_rows,
    )

    # Direct theta resolvent vs largest Jacobi model.
    max_dim = max(jacobi_dims)
    _, lam_max, w_max, mult_max = jacobi_models[max_dim]
    resolvent_rows: List[dict] = []
    jac_res_rels: List[float] = []

    for zz in tqdm(resolvent_z, desc="direct theta/Jacobi resolvent", unit="z"):
        z = mp.mpf(str(zz))
        mt = target.M(z)
        mj = jacobi_resolvent(q1, lam_max, w_max, z)
        er = float(abs(mt - mj) / max(abs(mt), mp.mpf("1e-100")))
        jac_res_rels.append(er)
        resolvent_rows.append(
            {
                "model": f"jacobi_dim_{max_dim}",
                "cutoff": "",
                "z": f"{zz:.17g}",
                "M_theta_direct": mp.nstr(mt, 70),
                "M_model": mp.nstr(mj, 70),
                "relative_error": f"{er:.17g}",
            }
        )

    # Spectral node/multiplicity diagnostics.
    node_rows: List[dict] = []
    positive_nodes = [
        i for i in range(len(lam_max)) if lam_max[i] > 0 and mult_max[i] > mp.mpf("1e-20")
    ]
    positive_nodes.sort(key=lambda i: lam_max[i], reverse=True)
    for rank, i in enumerate(positive_nodes, 1):
        node_rows.append(
            {
                "rank": rank,
                "lambda": mp.nstr(lam_max[i], 80),
                "gamma_from_lambda": mp.nstr(1 / mp.sqrt(lam_max[i]), 80),
                "quadrature_weight": mp.nstr(w_max[i], 80),
                "implied_multiplicity": mp.nstr(mult_max[i], 80),
            }
        )
    nodes_path = Path(str(prefix) + "_JACOBI_NODES.csv")
    write_csv(nodes_path, list(node_rows[0].keys()), node_rows)

    # -------------------------------------------------------------------------
    # C. v445 recursive-clock and controls
    # -------------------------------------------------------------------------
    print("\n[C] Building v445 recursive-clock/Riesz spectra ...")
    free_ext = v445.free_archimedean_levels(args.depth)
    free = np.asarray(free_ext[: args.depth], dtype=float)
    check_depth = max(4, int(math.floor(args.depth * args.depth_check_fraction)))

    spectrum_records = []

    # Free control.
    spectrum_records.append(
        {
            "mode": "free_gamma",
            "cutoff": 0,
            "roots": free,
            "residuals": np.zeros_like(free),
            "counts": np.ones_like(free, dtype=int),
            "epsilon": 0.0,
            "term_count": 0,
        }
    )

    for X in clock_cutoffs:
        spectrum_records.append(
            v445.quantize(
                args.depth,
                int(X),
                "clock",
                free_ext,
                int(args.grid_points),
            )
        )

    for X in riesz_cutoffs:
        spectrum_records.append(
            v445.quantize(
                args.depth,
                int(X),
                "riesz1",
                free_ext,
                int(args.grid_points),
            )
        )

    clock_heat_rows: List[dict] = []
    model_vectors: Dict[Tuple[str, int], List[float]] = {}
    model_summary_rows: List[dict] = []

    for rec in spectrum_records:
        mode = str(rec["mode"])
        cutoff = int(rec["cutoff"])
        roots = np.asarray(rec["roots"], dtype=float)
        vec = []
        trunc_gaps = []
        rels = []

        for uu, kt in zip(heat_u, target_heat):
            kfull = spectral_heat(roots, uu)
            kcheck = spectral_heat(roots[:check_depth], uu)
            trunc_gap = abs(kfull - kcheck) / max(abs(kfull), 1e-300)
            er = relerr(kfull, kt)
            vec.append(kfull)
            trunc_gaps.append(trunc_gap)
            rels.append(er)
            clock_heat_rows.append(
                {
                    "mode": mode,
                    "cutoff": cutoff,
                    "u": f"{uu:.17g}",
                    "depth": args.depth,
                    "check_depth": check_depth,
                    "K_model": f"{kfull:.17g}",
                    "K_check_depth": f"{kcheck:.17g}",
                    "relative_depth_tail_proxy": f"{trunc_gap:.17g}",
                    "K_theta_target": f"{kt:.17g}",
                    "relative_error_to_target": f"{er:.17g}",
                }
            )

        model_vectors[(mode, cutoff)] = vec
        model_summary_rows.append(
            {
                "mode": mode,
                "cutoff": cutoff,
                "heat_relative_rms": f"{rms(rels):.17g}",
                "heat_relative_max": f"{max(rels):.17g}",
                "max_depth_tail_proxy": f"{max(trunc_gaps):.17g}",
                "max_quantization_residual": f"{float(np.max(rec['residuals'])):.17g}",
                "missing_cells": int(np.sum(np.asarray(rec["counts"]) == 0)),
                "ambiguous_cells": int(np.sum(np.asarray(rec["counts"]) > 1)),
                "term_count": int(rec.get("term_count", 0)),
                "epsilon": f"{float(rec.get('epsilon', 0.0)):.17g}",
            }
        )

    clock_heat_path = Path(str(prefix) + "_CLOCK_HEAT.csv")
    write_csv(clock_heat_path, list(clock_heat_rows[0].keys()), clock_heat_rows)

    model_summary_path = Path(str(prefix) + "_MODEL_SUMMARY.csv")
    write_csv(
        model_summary_path,
        list(model_summary_rows[0].keys()),
        model_summary_rows,
    )

    # Add finite spectral resolvent diagnostics.  This is secondary because the
    # finite-depth tail is much less suppressed here than in the heat test.
    for rec in spectrum_records:
        mode = str(rec["mode"])
        cutoff = int(rec["cutoff"])
        roots = np.asarray(rec["roots"], dtype=float)
        for zz in resolvent_z:
            mt = target.M(mp.mpf(str(zz)))
            mm = spectral_resolvent(roots, zz)
            er = float(abs(mt - mm) / max(abs(mt), mp.mpf("1e-100")))
            resolvent_rows.append(
                {
                    "model": mode,
                    "cutoff": cutoff,
                    "z": f"{zz:.17g}",
                    "M_theta_direct": mp.nstr(mt, 70),
                    "M_model": f"{mm:.17g}",
                    "relative_error": f"{er:.17g}",
                }
            )

    resolvent_path = Path(str(prefix) + "_RESOLVENT.csv")
    write_csv(resolvent_path, list(resolvent_rows[0].keys()), resolvent_rows)

    # Successive cutoff heat-vector drift, the key cutoff-independence diagnostic.
    drift_rows: List[dict] = []
    for mode, cutoffs in [("clock", clock_cutoffs), ("riesz1", riesz_cutoffs)]:
        for a, b in zip(cutoffs[:-1], cutoffs[1:]):
            va = model_vectors[(mode, int(a))]
            vb = model_vectors[(mode, int(b))]
            drift = successive_vector_drift(va, vb)
            drift_rows.append(
                {
                    "mode": mode,
                    "cutoff_from": int(a),
                    "cutoff_to": int(b),
                    "successive_heat_vector_relative_rms": f"{drift:.17g}",
                }
            )
    drift_path = Path(str(prefix) + "_CUTOFF_DRIFT.csv")
    if drift_rows:
        write_csv(drift_path, list(drift_rows[0].keys()), drift_rows)

    # -------------------------------------------------------------------------
    # Interpretation
    # -------------------------------------------------------------------------
    jac_largest_heat_rms = float(
        next(
            row["heat_relative_rms"]
            for row in jacobi_summary_rows
            if int(row["dim"]) == max_dim
        )
    )
    jac_res_rms = rms(jac_res_rels)

    target_pass = (
        all(target_reliable)
        and all_target_positive
        and cm_pass
    )
    jacobi_pass = (
        jac_largest_heat_rms <= args.maximum_jacobi_heat_relative_rms
        and jac_res_rms <= args.maximum_jacobi_resolvent_relative_rms
    )

    def summary_error(mode: str, cutoff: int) -> float:
        for row in model_summary_rows:
            if row["mode"] == mode and int(row["cutoff"]) == int(cutoff):
                return float(row["heat_relative_rms"])
        return float("nan")

    free_rms = summary_error("free_gamma", 0)
    clock_errors = [(X, summary_error("clock", X)) for X in clock_cutoffs]
    riesz_errors = [(X, summary_error("riesz1", X)) for X in riesz_cutoffs]
    best_clock = min(clock_errors, key=lambda p: p[1]) if clock_errors else (None, float("nan"))
    best_riesz = min(riesz_errors, key=lambda p: p[1]) if riesz_errors else (None, float("nan"))

    clock_drift = [
        float(row["successive_heat_vector_relative_rms"])
        for row in drift_rows
        if row["mode"] == "clock"
    ]
    clock_tail_drift_shrinking = (
        len(clock_drift) >= 2 and clock_drift[-1] < clock_drift[-2]
    )
    last_clock_error = clock_errors[-1][1] if clock_errors else float("nan")
    clock_last_interesting = (
        math.isfinite(last_clock_error)
        and last_clock_error <= args.clock_interesting_relative_rms
    )

    if not target_pass:
        verdict = "TARGET_NUMERICS_NOT_RELIABLE_ENOUGH"
    elif not jacobi_pass:
        verdict = "THETA_TARGET_OK_BUT_JACOBI_HEAT_BRIDGE_NOT_CLOSED"
    elif clock_last_interesting and clock_tail_drift_shrinking:
        verdict = "FINITE_CLOCK_HEAT_BRIDGE_SUPPORTED_PROSPECTIVELY"
    elif best_clock[0] is not None and best_clock[1] <= args.clock_interesting_relative_rms:
        verdict = "FINITE_CLOCK_HIT_ONLY__CUTOFF_CONVERGENCE_NOT_ESTABLISHED"
    else:
        verdict = "JACOBI_HEAT_BRIDGE_SUPPORTED__CLOCK_GENERATOR_NOT_YET_MATCHED"

    manifest = {
        "version": VERSION,
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_function_called": False,
            "theta_integral_used": True,
        },
        "modules": {
            "v445": module_sha(v445),
            "v446": module_sha(v446),
        },
        "parameters": vars(args),
        "derived": {
            "check_depth": check_depth,
            "theta_xi0_direct": mp.nstr(target.xi0, 80),
            "theta_xi0_moment_route": mp.nstr(c[0], 80),
            "q1": mp.nstr(q1, 80),
            "theta_xi0_relative_route_gap": xi0_route_gap,
            "support_scale": mp.nstr(support_scale, 80),
        },
    }
    manifest_path = Path(str(prefix) + "_FREEZE.json")
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time() - t0,
        "verdict": verdict,
        "scientific_boundary": (
            "Finite zero-ordinate-free audit only. A matching heat trace does not "
            "prove all-order Stieltjes positivity or RH. Cutoff-independent clock "
            "convergence and an analytic ROT generator theorem remain required."
        ),
        "target": {
            "all_heat_points_reliable": bool(all(target_reliable)),
            "all_heat_points_positive": bool(all_target_positive),
            "maximum_stehfest_degree_relative_gap": max_inv_gap,
            "theta_xi0_relative_route_gap": xi0_route_gap,
            "direct_M_complete_monotonicity_spotcheck_pass": bool(cm_pass),
            "minimum_signed_complete_monotonicity_value": mp.nstr(cm_min_signed, 60),
        },
        "jacobi": {
            "largest_dim": max_dim,
            "heat_relative_rms": jac_largest_heat_rms,
            "resolvent_relative_rms": jac_res_rms,
            "pass": bool(jacobi_pass),
            "all_tested_Hankel_Cholesky_positive": True,
            "minimum_final_H0_pivot": hankel_rows[-1]["min_cholesky_pivot_H0"],
            "minimum_final_H1_pivot": hankel_rows[-1]["min_cholesky_pivot_H1"],
        },
        "recursive_clock": {
            "free_heat_relative_rms": free_rms,
            "clock_errors_by_cutoff": [
                {"cutoff": int(X), "heat_relative_rms": float(e)}
                for X, e in clock_errors
            ],
            "riesz_errors_by_cutoff": [
                {"cutoff": int(X), "heat_relative_rms": float(e)}
                for X, e in riesz_errors
            ],
            "best_clock_cutoff_post_target_diagnostic": best_clock[0],
            "best_clock_heat_relative_rms_post_target_diagnostic": best_clock[1],
            "best_riesz_cutoff_post_target_diagnostic": best_riesz[0],
            "best_riesz_heat_relative_rms_post_target_diagnostic": best_riesz[1],
            "clock_successive_heat_vector_drifts": clock_drift,
            "clock_tail_drift_shrinking": bool(clock_tail_drift_shrinking),
            "last_clock_heat_relative_rms": last_clock_error,
            "last_clock_below_interesting_threshold": bool(clock_last_interesting),
            "warning": (
                "The best-cutoff statistic is post-target diagnostic only. "
                "Scientific evidence for cutoff independence must come from the "
                "trajectory/drift, not from choosing the best finite cutoff."
            ),
        },
        "outputs": {
            "theta_heat_target": target_heat_path.name,
            "direct_complete_monotonicity": cm_path.name,
            "jacobi_heat": jacobi_heat_path.name,
            "jacobi_dim_summary": jacobi_summary_path.name,
            "jacobi_nodes": nodes_path.name,
            "clock_heat": clock_heat_path.name,
            "model_summary": model_summary_path.name,
            "resolvent": resolvent_path.name,
            "cutoff_drift": drift_path.name if drift_rows else None,
            "freeze_manifest": manifest_path.name,
        },
    }

    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n" + "=" * 154)
    print("KEY RESULTS")
    print("=" * 154)
    print("verdict                                  :", verdict)
    print("theta target stable/positive             :", target_pass)
    print("max Stehfest degree gap                  :", f"{max_inv_gap:.3e}")
    print("direct M complete-monotonicity spotcheck :", cm_pass)
    print("largest Jacobi dim                       :", max_dim)
    print("Jacobi heat relative RMS                 :", f"{jac_largest_heat_rms:.3e}")
    print("Jacobi resolvent relative RMS            :", f"{jac_res_rms:.3e}")
    print("free Gamma heat relative RMS             :", f"{free_rms:.3e}")
    if clock_errors:
        print("clock heat RMS trajectory                :")
        for X, e in clock_errors:
            print(f"  X={X:<10d} {e:.6e}")
    if clock_drift:
        print("clock successive heat-vector drift       :")
        for row in drift_rows:
            if row["mode"] == "clock":
                print(
                    f"  {row['cutoff_from']} -> {row['cutoff_to']}: "
                    f"{float(row['successive_heat_vector_relative_rms']):.6e}"
                )
    if riesz_errors:
        print("Riesz-1 heat RMS trajectory              :")
        for X, e in riesz_errors:
            print(f"  X={X:<10d} {e:.6e}")
    print("summary                                  :", summary_path)
    print("=" * 154)

    if args.strict and (not target_pass or not jacobi_pass):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
