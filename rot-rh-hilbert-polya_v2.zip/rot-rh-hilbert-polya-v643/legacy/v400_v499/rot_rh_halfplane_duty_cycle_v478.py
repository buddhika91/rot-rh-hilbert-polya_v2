#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v478 — HALF-PLANE LOCK / VANISHING COHERENCE DUTY CYCLE
===============================================================

PURPOSE
-------
Sharpen v476 from smooth-test-function collapse to an exact whole-window
inequality.

At a large base cutoff t and fixed energy E in the root tube, write

    H(s)
      = sum_j a_j exp(-delta_j s) exp(i gamma_j s),
      0<=s<=T,

with delta_j>=0 and positive grouped ordinates gamma_j.

Let

    W0=sum_j |a_j|.

Allow a bounded carrier nu and a constant phase rotation theta0:

    Z(s)=exp(-i theta0) exp(i nu s) H(s).

Assume the LOCKED HALF-PLANE condition

    |arg Z(s)| <= Theta < pi/2

whenever Z(s)!=0, throughout [0,T].

Then

    Re Z(s) >= cos(Theta)|H(s)|.

But exactly

    int_0^T Z(s) ds
      = sum_j A_j
          [ exp((-delta_j+i(gamma_j+nu))T)-1 ]
          /[-delta_j+i(gamma_j+nu)],

where |A_j|=|a_j|.

Therefore

    |int_0^T Z|
      <= 2 sum_j |a_j|/|gamma_j+nu|.

Combining:

    int_0^T |H(s)| ds / W0
      <= 2 sec(Theta)
         * I_-1,

where

    I_-1
      = [sum_j |a_j|/|gamma_j+nu|]/W0.

This bound is INDEPENDENT OF T.

---------------------------------------------------------------------------
A. Frequency escape implies I_-1 -> 0
---------------------------------------------------------------------------

Assume |nu|<=Nu and the nonattained absolute-frequency escape property:

for every fixed M,

    sum_(gamma_j<=M)|a_j|/W0 ->0.

Choose M>2Nu.  On gamma_j>M,

    |gamma_j+nu| >= gamma_j-Nu >= M-Nu,

hence

    high contribution <= 1/(M-Nu).

The low contribution is at most

    [1/min_positive_denominator] * low mass,

after first choosing a fixed M above the finitely many possible
gamma+nu=0 collisions; equivalently one may excise an arbitrarily small fixed
finite-frequency set, whose normalized mass tends to zero.

Thus

    I_-1 ->0.

So any half-plane-locked nonattained collective signal obeys

    int_0^T |H| ds / W0 ->0

for EVERY interval length T on which the half-plane lock holds.

---------------------------------------------------------------------------
B. Vanishing duty cycle
---------------------------------------------------------------------------

For any fixed kappa>0 let

    A_kappa
      ={s in [0,T]: |H(s)| >= kappa W0}.

Then Markov/Chebyshev gives

    |A_kappa|
      <= [1/(kappa W0)] int_0^T |H(s)|ds
      <= 2 sec(Theta) I_-1/kappa
      ->0.

The ABSOLUTE measure of all times carrying kappa-level normalized coherence
tends to zero.  This is much stronger than saying their fraction tends to zero.

---------------------------------------------------------------------------
C. Linear windows from v411
---------------------------------------------------------------------------

Suppose v411's short-window lock transfer holds at every sufficiently large
base point:

    phase increment over each h-window <= C/t.

Chain N adjacent windows from t to (1+c)t.  The accumulated phase excursion is

    <= (C/h) int_t^((1+c)t) ds/s + o(1)
     = (C/h) log(1+c)+o(1).

Choose c>0 small enough that

    (C/h) log(1+c) < pi/2.

After including any explicit bounded carrier/reference term in nu, the entire
proportional window [t,(1+c)t] lies in one open half-plane.

Hence v411 LOCK_TRANSFER in the genuinely nonattained sector forces

    |{s in [0,c t]:
        |H_t(s)| >= kappa W0(t)}|
      ->0

for every kappa>0.

So a bounded fixed branch must track a high-coherence exceptional set whose
TOTAL temporal thickness tends to zero even inside a window whose length grows
linearly like t.

---------------------------------------------------------------------------
D. Remaining geometric theorem
---------------------------------------------------------------------------

This is now a joint (t,E) tracking problem:

Can a continuously ordered, transversely simple action-label branch remain
inside a coherence set whose t-sections have vanishing absolute measure?

Abstract harmonic analysis alone cannot answer yes/no: v477 gives
superoscillatory coefficient families that can create extremely thin locked
sets.

The next theorem must exploit the E-motion/Jacobian of the actual arithmetic
coherence set, or the operator/Fredholm realization.

No Xi values, zeta values, known zeros, RH, simple zeros, or finite scans are
used.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v478-halfplane-duty-cycle"


def symbolic_integral_check() -> Dict[str, Any]:
    import sympy as sp
    d, w, T = sp.symbols("d w T", positive=True, real=True)
    lam = -d + sp.I*w
    integral = (sp.exp(lam*T)-1)/lam
    deriv = sp.simplify(sp.diff(integral, T)-sp.exp(lam*T))
    at0 = sp.simplify(integral.subs(T, 0))
    return {
        "integral_formula": str(integral),
        "derivative_residual": str(deriv),
        "zero_endpoint": str(at0),
        "modulus_bound": "|exp((-d+iw)T)-1|<=2 => |integral|<=2/|w|",
        "pass": bool(deriv == 0 and at0 == 0),
    }


def synthetic_panel():
    # Diagnostic only: inverse-frequency moment for escaping packets.
    rows = []
    nu = 1.5
    for M in (10.0, 40.0, 160.0, 640.0):
        gammas = [M+j for j in range(20)]
        weights = [1.0/(j+1) for j in range(20)]
        W0 = sum(weights)
        inv = sum(
            weights[j]/abs(gammas[j]+nu)
            for j in range(20)
        )/W0
        rows.append({
            "minimum_frequency": M,
            "inverse_frequency_moment": inv,
            "two_times_inverse_moment": 2.0*inv,
        })
    return rows


def chaining_bound(C: float, h: float, c: float):
    theta = (C/h)*math.log(1.0+c)
    return {
        "C": C,
        "h": h,
        "c": c,
        "accumulated_sector_angle": theta,
        "halfplane": theta < math.pi/2,
        "secant": (
            1.0/math.cos(theta)
            if theta < math.pi/2 else None
        ),
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v478 — half-plane lock / vanishing coherence duty cycle

Let

`H(s)=sum a_j e^(-delta_j s)e^(i gamma_j s)`

and `W0=sum|a_j|`.

After one constant rotation and a bounded carrier `nu`, suppose the whole
window lies in a sector

`|arg Z(s)|<=Theta<pi/2`.

Then

`Re Z>=cos(Theta)|H|`.

The exponential integral is exact:

`int_0^T e^((-delta+i omega)s)ds
 =[e^((-delta+i omega)T)-1]/(-delta+i omega)`,

so

`|int_0^T e^((-delta+i omega)s)ds|
 <=2/|omega|`.

Consequently

`int_0^T |H|ds/W0
 <=2 sec(Theta)
   [sum |a_j|/|gamma_j+nu|]/W0`.

The right side contains no factor `T`.

Nonattained absolute-frequency escape implies the weighted inverse-frequency
moment tends to zero. Hence the total normalized coherence area tends to zero
on ANY locked window.

For every `kappa>0`,

`measure{{s:|H(s)|>=kappa W0}}
 <=2 sec(Theta) I_-1/kappa
 ->0`.

If the v411 `O(1/t)` short-window lock estimate is chained from `t` to
`(1+c)t`, its total phase excursion is

`(C/h)log(1+c)+o(1)`.

Choosing `c` so this is `<pi/2` produces a locked window of length `c t`.

Thus any bounded nonattained branch satisfying v411 must track a normalized
high-coherence set whose **absolute t-thickness tends to zero inside a
linearly growing window**.

**Verdict:** {payload['verdict']}

The remaining theorem is necessarily joint in `(t,E)`: exclude a transverse
ordered root from tracking this vanishing-duty-cycle set, or realize the
tracking through the arithmetic/Fredholm structure.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_HALFPLANE_DUTY_CYCLE_V1",
        "closed": {
            "whole_window_integral":
                "int |H|/W0 <= 2 secTheta * weighted inverse-frequency moment",
            "inverse_frequency":
                "absolute frequency escape => I_-1->0",
            "duty_cycle":
                "measure{|H|>=kappa W0}->0",
            "linear_window":
                "v411 chaining gives T=c t with fixed half-plane angle for c small",
        },
        "remaining": {
            "joint_tracking":
                "prove ordered transverse E_k(t) cannot track a coherence set of vanishing t-thickness",
            "structure":
                "must use E-Jacobian/arithmetic residue structure or Fredholm realization; v477 blocks a purely generic spectral argument",
        },
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--C", type=float, default=1.0)
    ap.add_argument("--h", type=float, default=math.log(2.0))
    ap.add_argument("--c", type=float, default=0.25)
    ap.add_argument("--prefix", default="rot_rh_halfplane_duty_cycle_v478")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*194)
    print("ROT-RH v478 — HALF-PLANE LOCK / VANISHING COHERENCE DUTY CYCLE")
    print("="*194)

    with tqdm(total=3, desc="v478 theorem", unit="step") as bar:
        sym = symbolic_integral_check()
        bar.update(1)
        panel = synthetic_panel()
        bar.update(1)
        chain = chaining_bound(args.C, args.h, args.c)
        bar.update(1)

    passed = bool(sym["pass"] and chain["halfplane"])
    verdict = (
        "EXACT_HALFPLANE_LOCK_VANISHING_DUTY_CYCLE_PASS"
        if passed else
        "HALFPLANE_DUTY_CYCLE_CHECK_INCOMPLETE"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "inverse_frequency_diagnostic": panel,
        "chaining": chain,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "diagnostic_used_as_proof": False,
        },
        "proof_status":
            "Exact exponential-integral/half-plane inequality plus nonattained frequency escape. Remaining issue is joint (t,E) exceptional-set tracking.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("integral algebra                :", sym["pass"])
    print("linear-window halfplane         :", chain["halfplane"])
    print("sector angle                    :", f"{chain['accumulated_sector_angle']:.6e}")
    print("inverse moment first/last       :",
          f"{panel[0]['inverse_frequency_moment']:.6e}",
          "/",
          f"{panel[-1]['inverse_frequency_moment']:.6e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
