#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v424 — CESARO-MEAN PRIMITIVE-BETA FIXED-MODE CUTOFF AUDIT
=========================================================================

Purpose
-------
Advance the remaining fixed-mode Riesz cutoff-removal problem after v422.

v418/v419 give the exact branch flow

    E_k'(L) = B_k(L)/L^2,
    B_k(L)  = C0(L,E_k(L))/F'_L(E_k(L)),
    L       = log X.

The correct nonperturbative cutoff criterion is the signed primitive

    Pi_k(L) = integral B_k(s) ds.

If |Pi_k(L)| <= C L^(2-eps), eps>0, eventually, and the ordered branch does
not fold, then E_k(L) converges.  In particular Pi=O(L) gives the natural
O(1/L) tail.

This script is a PROSPECTIVE NUMERICAL / FALSIFICATION AUDIT, not a proof.
It deliberately focuses on the real zero-free arithmetic branch rather than
abstract synthetic resonance families.

Main tests
----------
1. RK REFINEMENT / BLIND ANCHOR VALIDATION
   Starting from the frozen root vector at the first anchor, integrate the
   exact root-flow ODE to the next already-frozen anchor using several fixed
   step counts.  Verify that the blind endpoint error is small and numerically
   stable under refinement.

2. CONTINUOUS PROSPECTIVE ROOT FLOW
   Starting only from the first frozen anchor, continue the same ordered roots
   through successive dyadic cutoffs without solving any new roots.

3. PRIMITIVE-BETA / CESARO-MEAN DIAGNOSTICS
   For every shell and mode record

       sup |B_k|,
       integral_shell B_k,
       shell_mean_beta = integral_shell B_k / Delta L,
       Pi_k(L) = integral_(L0)^L B_k(s) ds,
       Cesaro_mean_beta = Pi_k(L)/(L-L0),
       integral |B_k|,
       signed-cancellation ratio,
       min F'_L/L,
       dyadic displacement.

4. FROZEN DEVELOPMENT -> HOLDOUT CAPS
   The first N dyadic shells are development only.  Global caps are frozen for

       sup |B_k|,
       |shell_mean_beta|,
       |Cesaro_mean_beta|.

   This fixes the v423 gate error: |Pi_k(L)|/L initialized at Pi(L0)=0 must
   naturally rise from zero even when Pi_k(L)=O(L).  The correct finite
   diagnostic for the strong v419 class is bounded Pi_k(L)/(L-L0).

Optimization
------------
The v71 prime-power table is built ONCE at the maximum cutoff, sorted by log n,
and sliced for every intermediate cutoff.  Riesz weights are regenerated from
that cached table.  This avoids rebuilding millions of prime-power terms at
all RK stages.

Scientific firewall
-------------------
NO Xi evaluations.
NO zeta numerical values.
NO known Riemann-zero ordinates.
NO root solves beyond the supplied frozen anchors.
NO RH assumption.
NO simple-zero assumption.
NO finite numerical PASS is accepted as proof.

Version: 424
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 424
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def finite(x) -> bool:
    try:
        return bool(np.isfinite(x))
    except Exception:
        return False


def energy_col(df: pd.DataFrame) -> str:
    for c in ("energy", "E", "root", "root_energy"):
        if c in df.columns:
            return c
    raise KeyError("No energy column found in roots CSV")


def index_col(df: pd.DataFrame) -> str:
    for c in ("root_index", "mode_index", "k", "index"):
        if c in df.columns:
            return c
    raise KeyError("No root-index column found in roots CSV")


def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    """integral_2^(e^L) t^-1/2 sin(E log t) dt."""
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j * E
    lo = math.log(2.0)
    z = (np.exp(a * L) - np.exp(a * lo)) / a
    return np.imag(z)


EXPECTED_UPSTREAM = {
    "v408": "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS",
    "v409": "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS",
    "v410": "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS",
    "v411": "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS",
    "v418": "EXACT_NONPERTURBATIVE_BETA_FUNCTION_CUTOFF_CLOSURE_REDUCTION_PASS",
    "v419": "EXACT_PRIMITIVE_BETA_NONPERTURBATIVE_CUTOFF_REDUCTION_PASS",
    "v420": "EXACT_ATTAINED_NOFOLD_RG_CHARACTERISTIC_COMPLETION_PASS",
    "v421": "EXACT_RIESZ_ATTAINED_CLUSTER_REGULATOR_REPAIR_PASS",
}


def check_upstream(args) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    for key, expected in EXPECTED_UPSTREAM.items():
        path = getattr(args, f"{key}_summary")
        obj = load_json(path)
        verdict = None if obj is None else obj.get("verdict")
        out[key] = {
            "path": path,
            "available": obj is not None,
            "verdict": verdict,
            "expected": expected,
            "pass": bool(verdict == expected),
        }
    return out


# -----------------------------------------------------------------------------
# Cached v71 arithmetic
# -----------------------------------------------------------------------------

@dataclass
class CachedPrimePowers:
    logs: np.ndarray
    exponents: np.ndarray
    base_weight: np.ndarray      # 1/(m sqrt(n))
    generator_weight: np.ndarray # Lambda(n)/sqrt(n)=log(n)/(m sqrt(n))
    max_cutoff: int


@dataclass
class Eval:
    cutoff: int
    L: float
    E: np.ndarray
    C0: np.ndarray
    Fp: np.ndarray
    beta: np.ndarray
    terms: int


def build_cached_prime_powers(base, primes: np.ndarray, max_cutoff: int) -> CachedPrimePowers:
    logs, _, exponents = base.prime_power_riesz_terms(primes, int(max_cutoff))
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)

    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    base_weight = np.exp(-0.5 * logs) / exponents
    generator_weight = base_weight * logs

    return CachedPrimePowers(
        logs=logs,
        exponents=exponents,
        base_weight=base_weight,
        generator_weight=generator_weight,
        max_cutoff=int(max_cutoff),
    )


class ArithmeticEvaluator:
    def __init__(self, base, table: CachedPrimePowers):
        self.base = base
        self.table = table

    def eval(self, cutoff: int, energies: np.ndarray) -> Eval:
        cutoff = int(cutoff)
        if cutoff > self.table.max_cutoff:
            raise ValueError("cutoff exceeds cached prime-power table")

        E = np.atleast_1d(np.asarray(energies, float))
        L = math.log(float(cutoff))
        # v71 includes p^m only for log n < log X - 1e-14.
        k = int(np.searchsorted(self.table.logs, L - 1.0e-14, side="left"))
        logs = self.table.logs[:k]
        basew = self.table.base_weight[:k]
        genw = self.table.generator_weight[:k]

        riesz_weights = basew * (1.0 - logs / L)

        prime0 = self.base.trig_sum(E, logs, genw, "sin")
        C0 = np.asarray(prime0, float) - smooth0(E, L)
        Fp = np.asarray(
            self.base.phase_prime_grid(E, cutoff, logs, riesz_weights),
            float,
        )

        beta = np.full_like(C0, np.nan, dtype=float)
        good = np.isfinite(Fp) & (np.abs(Fp) > EPS)
        beta[good] = C0[good] / Fp[good]

        return Eval(
            cutoff=cutoff,
            L=L,
            E=E.copy(),
            C0=C0,
            Fp=Fp,
            beta=beta,
            terms=k,
        )


# -----------------------------------------------------------------------------
# Roots and shell continuation
# -----------------------------------------------------------------------------

def load_roots(path: str, max_modes: int) -> Dict[int, np.ndarray]:
    df = pd.read_csv(path)
    if "cutoff" not in df.columns:
        raise KeyError("roots CSV requires cutoff column")
    ec = energy_col(df)
    kc = index_col(df)
    roots: Dict[int, np.ndarray] = {}
    for cutoff, g in df.groupby(df["cutoff"].astype(int)):
        e = g.sort_values(kc)[ec].to_numpy(float)
        if max_modes > 0:
            e = e[:max_modes]
        roots[int(cutoff)] = e
    return roots


@dataclass
class ShellResult:
    endpoint: np.ndarray
    track: pd.DataFrame
    shell: pd.DataFrame


def integrate_shell(
    evaluator: ArithmeticEvaluator,
    *,
    anchor: int,
    endpoint_cutoff: int,
    E_start: np.ndarray,
    steps: int,
    minimum_slope_ratio: float,
    cumulative_pi_start: np.ndarray,
    global_L_start: float,
    progress: Optional[tqdm] = None,
    label: str = "production",
) -> ShellResult:
    E = np.asarray(E_start, float).copy()
    nmode = len(E)
    L0 = math.log(float(anchor))
    L1 = math.log(float(endpoint_cutoff))
    Lgrid = np.linspace(L0, L1, int(steps) + 1)

    pi_shell = np.zeros(nmode, float)
    abs_beta_mass = np.zeros(nmode, float)
    int_sE = np.zeros(nmode, float)
    cumulative_pi = np.asarray(cumulative_pi_start, float).copy()

    min_slope = np.full(nmode, np.inf)
    max_abs_beta = np.zeros(nmode)
    nofold = np.ones(nmode, dtype=bool)

    rows: List[dict] = []
    cur = evaluator.eval(anchor, E)

    def accumulate_eval(ev: Eval):
        nonlocal min_slope, max_abs_beta, nofold
        sr = ev.Fp / max(ev.L, 1e-30)
        min_slope = np.minimum(min_slope, sr)
        max_abs_beta = np.maximum(max_abs_beta, np.abs(ev.beta))
        nofold &= np.isfinite(ev.Fp) & (ev.Fp > minimum_slope_ratio * ev.L)

    accumulate_eval(cur)

    for i in range(int(steps)):
        La = float(Lgrid[i])
        Lb = float(Lgrid[i + 1])
        Lm = 0.5 * (La + Lb)
        h = Lb - La

        # Midpoint RK2 on E'=beta/L^2.
        va = cur.beta / (La * La)
        Emid_guess = E + 0.5 * h * va
        Xmid = int(round(math.exp(Lm)))
        mid = evaluator.eval(Xmid, Emid_guess)
        vmid = mid.beta / (Lm * Lm)
        Enew = E + h * vmid

        Xnew = endpoint_cutoff if i == int(steps) - 1 else int(round(math.exp(Lb)))
        end = evaluator.eval(Xnew, Enew)

        pi_shell += h * mid.beta
        abs_beta_mass += h * np.abs(mid.beta)
        int_sE += h * Lm * Emid_guess
        cumulative_pi += h * mid.beta

        accumulate_eval(mid)
        accumulate_eval(end)

        sr = end.Fp / end.L
        for j in range(nmode):
            rows.append({
                "label": label,
                "anchor": int(anchor),
                "endpoint_cutoff": int(endpoint_cutoff),
                "step": int(i + 1),
                "cutoff": int(end.cutoff),
                "L": float(end.L),
                "root_index": int(j + 1),
                "E": float(end.E[j]),
                "C0": float(end.C0[j]),
                "Fp": float(end.Fp[j]),
                "slope_over_L": float(sr[j]),
                "beta": float(end.beta[j]),
                "primitive_beta_shell_running": float(pi_shell[j]),
                "primitive_beta_cumulative": float(cumulative_pi[j]),
                "terms": int(end.terms),
            })

        E = Enew
        cur = end
        if progress is not None:
            progress.update(1)

    # Numerical consistency check of Pi=int L^2 E' dL:
    # Pi = [L^2 E] - 2 int L E dL.
    pi_ibp = (L1 * L1 * E - L0 * L0 * np.asarray(E_start, float)) - 2.0 * int_sE
    pi_identity_resid = pi_shell - pi_ibp

    dE = E - np.asarray(E_start, float)
    shell_rows: List[dict] = []
    for j in range(nmode):
        cancellation = abs(pi_shell[j]) / max(abs_beta_mass[j], EPS)
        shell_rows.append({
            "label": label,
            "anchor": int(anchor),
            "endpoint_cutoff": int(endpoint_cutoff),
            "root_index": int(j + 1),
            "L_start": float(L0),
            "L_end": float(L1),
            "E_start": float(E_start[j]),
            "E_end_flow": float(E[j]),
            "dyadic_displacement": float(dE[j]),
            "scaled_displacement_L2": float(abs(dE[j]) * L0 * L0 / max(L1 - L0, EPS)),
            "max_abs_beta": float(max_abs_beta[j]),
            "primitive_beta_shell": float(pi_shell[j]),
            "delta_L": float(L1-L0),
            "shell_mean_beta": float(pi_shell[j] / max(L1-L0, EPS)),
            "abs_shell_mean_beta": float(abs(pi_shell[j]) / max(L1-L0, EPS)),
            "abs_primitive_beta_shell_over_L": float(abs(pi_shell[j]) / L0),
            "absolute_beta_mass_shell": float(abs_beta_mass[j]),
            "signed_cancellation_ratio": float(cancellation),
            "primitive_beta_cumulative": float(cumulative_pi[j]),
            "elapsed_L": float(L1-global_L_start),
            "cesaro_mean_beta": float(cumulative_pi[j] / max(L1-global_L_start, EPS)),
            "abs_cesaro_mean_beta": float(abs(cumulative_pi[j]) / max(L1-global_L_start, EPS)),
            "abs_primitive_beta_cumulative_over_L": float(abs(cumulative_pi[j]) / L1),
            "min_slope_over_L": float(min_slope[j]),
            "nofold": bool(nofold[j]),
            "primitive_beta_ibp_residual": float(pi_identity_resid[j]),
        })

    return ShellResult(
        endpoint=E.copy(),
        track=pd.DataFrame(rows),
        shell=pd.DataFrame(shell_rows),
    )


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v424 Cesaro-mean primitive-beta fixed-mode cutoff audit",
    )

    # Upstream theorem lineage.
    ap.add_argument("--v408-summary", default="rot_rh_nonattained_support_migration_v408_SUMMARY.json")
    ap.add_argument("--v409-summary", default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json")
    ap.add_argument("--v410-summary", default="rot_rh_bohr_frequency_escape_v410_SUMMARY.json")
    ap.add_argument("--v411-summary", default="rot_rh_collective_phase_lock_v411_SUMMARY.json")
    ap.add_argument("--v418-summary", default="rot_rh_nonperturbative_beta_closure_v418_SUMMARY.json")
    ap.add_argument("--v419-summary", default="rot_rh_primitive_beta_renormalization_v419_SUMMARY.json")
    ap.add_argument("--v420-summary", default="rot_rh_attained_nofold_rg_characteristic_v420_SUMMARY.json")
    ap.add_argument("--v421-summary", default="rot_rh_riesz_attained_cluster_regulator_repair_v421_SUMMARY.json")
    ap.add_argument("--require-upstream", action="store_true")

    # Arithmetic inputs.
    ap.add_argument("--roots-csv", default="rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv")
    ap.add_argument("--v71-module", default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71")
    ap.add_argument("--start-anchor", type=int, default=8000000)
    ap.add_argument("--blind-anchor", type=int, default=16000000)
    ap.add_argument("--max-cutoff", type=int, default=64000000)
    ap.add_argument("--max-modes", type=int, default=12)

    # Numerical refinement.
    ap.add_argument("--refinement-steps", default="2,4,8,16")
    ap.add_argument("--production-steps-per-doubling", type=int, default=8)
    ap.add_argument("--maximum-refined-blind-error", type=float, default=1.0e-4)
    ap.add_argument("--maximum-refinement-endpoint-change", type=float, default=1.0e-4)
    ap.add_argument("--maximum-primitive-identity-residual", type=float, default=5.0e-3)

    # Prospective gates.
    ap.add_argument("--development-shells", type=int, default=1)
    ap.add_argument("--cap-safety", type=float, default=2.0)
    ap.add_argument("--minimum-slope-ratio", type=float, default=0.45)
    ap.add_argument("--maximum-holdout-shell-growth", type=float, default=2.0, help="Deprecated compatibility option; v424 does not use near-zero shell ratios as a gate")

    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--prefix", default="rot_rh_cesaro_mean_primitive_beta_v424")

    args = ap.parse_args()
    started = time.perf_counter()

    if args.start_anchor <= 1 or args.blind_anchor <= args.start_anchor:
        raise ValueError("Need blind-anchor > start-anchor > 1")
    if args.max_cutoff < args.blind_anchor:
        raise ValueError("max-cutoff must be >= blind-anchor")
    if args.production_steps_per_doubling < 2:
        raise ValueError("production steps must be >=2")
    if args.development_shells < 1:
        raise ValueError("development-shells must be >=1")
    if args.cap_safety <= 1.0:
        raise ValueError("cap-safety must exceed 1")

    refinement_steps = sorted(set(parse_ints(args.refinement_steps)))
    if not refinement_steps or min(refinement_steps) < 2:
        raise ValueError("refinement-steps must contain integers >=2")

    print("=" * 238)
    print("ROT-RH v424 — CESARO-MEAN PRIMITIVE-BETA FIXED-MODE CUTOFF AUDIT")
    print("=" * 238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("future root solves                        : NONE")
    print("finite scan accepted as proof             : NO")
    print("=" * 238)

    # Upstream.
    upstream = check_upstream(args)
    print("[1] Upstream theorem lineage")
    for key in EXPECTED_UPSTREAM:
        u = upstream[key]
        print(f"{key:8s} available={str(u['available']):5s} pass={str(u['pass']):5s} verdict={u['verdict']}")
    all_upstream_ok = bool(all(u["pass"] for u in upstream.values()))
    if args.require_upstream and not all_upstream_ok:
        raise RuntimeError("Required upstream theorem lineage is incomplete")

    roots_path = Path(args.roots_csv)
    if not roots_path.exists():
        raise FileNotFoundError(roots_path)
    roots = load_roots(str(roots_path), args.max_modes)
    if args.start_anchor not in roots:
        raise ValueError(f"start anchor {args.start_anchor:,} missing from roots CSV")
    if args.blind_anchor not in roots:
        raise ValueError(f"blind anchor {args.blind_anchor:,} missing from roots CSV")

    common = min(len(roots[args.start_anchor]), len(roots[args.blind_anchor]))
    if common < 1:
        raise ValueError("No common modes")
    E0 = roots[args.start_anchor][:common].copy()
    Eblind = roots[args.blind_anchor][:common].copy()

    base = importlib.import_module(args.v71_module)

    print("\n[2] Cached arithmetic table")
    print("start anchor                               :", f"{args.start_anchor:,}")
    print("blind anchor                               :", f"{args.blind_anchor:,}")
    print("maximum prospective cutoff                :", f"{args.max_cutoff:,}")
    print("common modes                               :", common)
    print("refinement steps                           :", refinement_steps)
    print("production steps / doubling               :", args.production_steps_per_doubling)

    t0 = time.perf_counter()
    primes = base.sieve_primes(args.max_cutoff)
    print("primes <= max cutoff                      :", f"{len(primes):,}")
    print("sieve seconds                              :", f"{time.perf_counter()-t0:.3f}")

    t0 = time.perf_counter()
    table = build_cached_prime_powers(base, primes, args.max_cutoff)
    evaluator = ArithmeticEvaluator(base, table)
    print("cached prime-power terms                   :", f"{len(table.logs):,}")
    print("prime-power cache seconds                  :", f"{time.perf_counter()-t0:.3f}")

    # ------------------------------------------------------------------
    # Refinement audit on the blind 8M->16M-type shell.
    # ------------------------------------------------------------------
    print("\n[3] RK refinement / blind-anchor validation")
    refinement_rows: List[dict] = []
    endpoints: Dict[int, np.ndarray] = {}
    shells_by_ref: Dict[int, pd.DataFrame] = {}

    with tqdm(total=sum(refinement_steps), desc="blind RK refinement", unit="RK2-step") as bar:
        for nstep in refinement_steps:
            res = integrate_shell(
                evaluator,
                anchor=args.start_anchor,
                endpoint_cutoff=args.blind_anchor,
                E_start=E0,
                steps=nstep,
                minimum_slope_ratio=args.minimum_slope_ratio,
                cumulative_pi_start=np.zeros(common),
                global_L_start=math.log(float(args.start_anchor)),
                progress=bar,
                label=f"refine_{nstep}",
            )
            endpoints[nstep] = res.endpoint
            shells_by_ref[nstep] = res.shell
            err = np.abs(res.endpoint - Eblind)
            for j in range(common):
                refinement_rows.append({
                    "steps": int(nstep),
                    "root_index": int(j + 1),
                    "E_start": float(E0[j]),
                    "E_endpoint_flow": float(res.endpoint[j]),
                    "E_blind": float(Eblind[j]),
                    "abs_blind_error": float(err[j]),
                    "min_slope_over_L": float(res.shell.iloc[j]["min_slope_over_L"]),
                    "max_abs_beta": float(res.shell.iloc[j]["max_abs_beta"]),
                    "primitive_beta_shell": float(res.shell.iloc[j]["primitive_beta_shell"]),
                    "primitive_beta_ibp_residual": float(res.shell.iloc[j]["primitive_beta_ibp_residual"]),
                })

    refinement_df = pd.DataFrame(refinement_rows)
    finest = refinement_steps[-1]
    fine_err = np.abs(endpoints[finest] - Eblind)
    max_refined_blind = float(np.max(fine_err))

    if len(refinement_steps) >= 2:
        prev = refinement_steps[-2]
        max_refinement_change = float(np.max(np.abs(endpoints[finest] - endpoints[prev])))
    else:
        max_refinement_change = float("nan")

    max_refine_identity = float(np.max(np.abs(shells_by_ref[finest]["primitive_beta_ibp_residual"].to_numpy(float))))
    refinement_pass = bool(
        max_refined_blind <= args.maximum_refined_blind_error
        and (not finite(max_refinement_change) or max_refinement_change <= args.maximum_refinement_endpoint_change)
        and max_refine_identity <= args.maximum_primitive_identity_residual
        and bool(shells_by_ref[finest]["nofold"].all())
    )

    print("finest-step maximum blind error           :", f"{max_refined_blind:.12e}")
    print("finest-vs-previous endpoint change        :", f"{max_refinement_change:.12e}" if finite(max_refinement_change) else "N/A")
    print("maximum primitive-beta IBP residual       :", f"{max_refine_identity:.12e}")
    print("refinement / blind validation pass        :", refinement_pass)

    refine_summary = (
        refinement_df.groupby("steps", as_index=False)
        .agg(
            maximum_blind_error=("abs_blind_error", "max"),
            median_blind_error=("abs_blind_error", "median"),
            minimum_slope_over_L=("min_slope_over_L", "min"),
            maximum_abs_beta=("max_abs_beta", "max"),
            maximum_abs_IBP_residual=("primitive_beta_ibp_residual", lambda x: float(np.max(np.abs(x)))),
        )
    )
    print("\nRefinement summary:")
    print(refine_summary.to_string(index=False, float_format=lambda x: f"{x:.9e}"))

    # ------------------------------------------------------------------
    # Prospective continuous flow through untouched dyadic cutoffs.
    # ------------------------------------------------------------------
    print("\n[4] Prospective continuous primitive-beta flow")
    shell_pairs: List[Tuple[int, int]] = []
    X = int(args.start_anchor)
    while X < args.max_cutoff:
        Y = min(2 * X, int(args.max_cutoff))
        shell_pairs.append((X, Y))
        if Y == X:
            break
        X = Y

    total_prod_steps = len(shell_pairs) * args.production_steps_per_doubling
    production_tracks: List[pd.DataFrame] = []
    production_shells: List[pd.DataFrame] = []
    Ecur = E0.copy()
    cumulative_pi = np.zeros(common)

    with tqdm(total=total_prod_steps, desc="primitive-beta continuation", unit="RK2-step") as bar:
        for ish, (Xa, Xb) in enumerate(shell_pairs):
            res = integrate_shell(
                evaluator,
                anchor=Xa,
                endpoint_cutoff=Xb,
                E_start=Ecur,
                steps=args.production_steps_per_doubling,
                minimum_slope_ratio=args.minimum_slope_ratio,
                cumulative_pi_start=cumulative_pi,
                global_L_start=math.log(float(args.start_anchor)),
                progress=bar,
                label="development" if ish < args.development_shells else "holdout",
            )
            sh = res.shell.copy()
            sh["shell_index"] = ish
            sh["set"] = "development" if ish < args.development_shells else "holdout"

            # Blind comparison is diagnostic only; continuation is never reset.
            if Xb in roots and len(roots[Xb]) >= common:
                blind = roots[Xb][:common]
                sh["blind_endpoint_available"] = True
                sh["blind_endpoint_error"] = res.endpoint - blind
                sh["abs_blind_endpoint_error"] = np.abs(res.endpoint - blind)
            else:
                sh["blind_endpoint_available"] = False
                sh["blind_endpoint_error"] = np.nan
                sh["abs_blind_endpoint_error"] = np.nan

            production_tracks.append(res.track)
            production_shells.append(sh)
            Ecur = res.endpoint.copy()
            cumulative_pi = sh.sort_values("root_index")["primitive_beta_cumulative"].to_numpy(float)

    track_df = pd.concat(production_tracks, ignore_index=True)
    shells_df = pd.concat(production_shells, ignore_index=True)

    dev = shells_df[shells_df["set"] == "development"].copy()
    hold = shells_df[shells_df["set"] == "holdout"].copy()

    if dev.empty:
        raise RuntimeError("No development shells")

    dev_beta = float(dev["max_abs_beta"].max())
    dev_shell_mean = float(dev["abs_shell_mean_beta"].max())
    dev_cesaro_mean = float(dev["abs_cesaro_mean_beta"].max())

    beta_cap = args.cap_safety * dev_beta
    shell_mean_cap = args.cap_safety * dev_shell_mean
    cesaro_mean_cap = args.cap_safety * dev_cesaro_mean

    if hold.empty:
        hold_beta = hold_shell_mean = hold_cesaro_mean = float("nan")
        beta_hold_pass = shell_mean_hold_pass = cesaro_mean_hold_pass = True
    else:
        hold_beta = float(hold["max_abs_beta"].max())
        hold_shell_mean = float(hold["abs_shell_mean_beta"].max())
        hold_cesaro_mean = float(hold["abs_cesaro_mean_beta"].max())
        beta_hold_pass = bool(hold_beta <= beta_cap)
        shell_mean_hold_pass = bool(hold_shell_mean <= shell_mean_cap)
        cesaro_mean_hold_pass = bool(hold_cesaro_mean <= cesaro_mean_cap)

    # A bounded Cesaro mean is exactly the strong primitive-beta scaling
    # Pi_k(L)=O(L-L0)=O(L).  This is the finite prospective diagnostic that
    # v423 intended to test.  We deliberately do NOT use successive ratios
    # of near-zero shell primitives.
    numerical_O_L_pass = bool(shell_mean_hold_pass and cesaro_mean_hold_pass)

    min_slope_all = float(shells_df["min_slope_over_L"].min())
    nofold_all = bool(shells_df["nofold"].all())
    max_identity_all = float(np.max(np.abs(shells_df["primitive_beta_ibp_residual"].to_numpy(float))))

    blind_rows = shells_df[shells_df["blind_endpoint_available"]]
    max_prod_blind = float(blind_rows["abs_blind_endpoint_error"].max()) if len(blind_rows) else float("nan")

    prospective_pass = bool(
        refinement_pass
        and nofold_all
        and min_slope_all >= args.minimum_slope_ratio
        and max_identity_all <= args.maximum_primitive_identity_residual
        and beta_hold_pass
        and shell_mean_hold_pass
        and cesaro_mean_hold_pass
        and numerical_O_L_pass
    )

    print("development max |beta|                   :", f"{dev_beta:.12e}")
    print("frozen |beta| cap                        :", f"{beta_cap:.12e}")
    print("holdout max |beta|                       :", f"{hold_beta:.12e}" if finite(hold_beta) else "N/A")
    print("beta holdout pass                        :", beta_hold_pass)
    print()
    print("development max |shell mean beta|        :", f"{dev_shell_mean:.12e}")
    print("frozen |shell mean beta| cap             :", f"{shell_mean_cap:.12e}")
    print("holdout max |shell mean beta|            :", f"{hold_shell_mean:.12e}" if finite(hold_shell_mean) else "N/A")
    print("shell mean beta holdout pass              :", shell_mean_hold_pass)
    print()
    print("development max |Cesaro mean beta|       :", f"{dev_cesaro_mean:.12e}")
    print("frozen |Cesaro mean beta| cap             :", f"{cesaro_mean_cap:.12e}")
    print("holdout max |Cesaro mean beta|           :", f"{hold_cesaro_mean:.12e}" if finite(hold_cesaro_mean) else "N/A")
    print("Cesaro mean beta holdout pass             :", cesaro_mean_hold_pass)
    print("finite O(L) primitive diagnostic pass     :", numerical_O_L_pass)
    print()
    print("minimum F'/L over all prospective flow   :", f"{min_slope_all:.12e}")
    print("maximum primitive-beta IBP residual      :", f"{max_identity_all:.12e}")
    print("maximum available blind endpoint error   :", f"{max_prod_blind:.12e}" if finite(max_prod_blind) else "N/A")
    print("all branches no-fold                     :", nofold_all)
    print("prospective arithmetic pass              :", prospective_pass)

    print("\nShell summary:")
    display_cols = [
        "set", "shell_index", "anchor", "endpoint_cutoff", "root_index",
        "dyadic_displacement", "max_abs_beta", "primitive_beta_shell",
        "shell_mean_beta", "signed_cancellation_ratio",
        "primitive_beta_cumulative", "cesaro_mean_beta",
        "min_slope_over_L", "abs_blind_endpoint_error", "nofold",
    ]
    print(shells_df[display_cols].to_string(index=False, float_format=lambda x: f"{x:.6e}"))

    # ------------------------------------------------------------------
    # Verdict and output.
    # ------------------------------------------------------------------
    if prospective_pass:
        verdict = "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS"
        next_theorem = "PROVE_UNIFORM_RIESZ_PRIMITIVE_BETA_SUBQUADRATIC_BOUND_AND_EVENTUAL_NOFOLD"
    elif not refinement_pass:
        verdict = "ROOT_FLOW_NUMERICAL_REFINEMENT_OR_BLIND_VALIDATION_FAILED"
        next_theorem = "FIX_CHARACTERISTIC_NUMERICS_BEFORE_ANALYTIC_CUTOFF_CLAIMS"
    elif not nofold_all or min_slope_all < args.minimum_slope_ratio:
        verdict = "PROSPECTIVE_NOFOLD_FAILURE"
        next_theorem = "LOCALIZE_RIESZ_STIFFNESS_LOSS"
    else:
        verdict = "PROSPECTIVE_CESARO_MEAN_OR_BETA_CAP_FAILURE"
        next_theorem = "LOCALIZE_CESARO_MEAN_BETA_GROWTH_BEFORE_CUTOFF_CLOSURE"

    prefix = Path(args.prefix)
    refinement_path = Path(str(prefix) + "_REFINEMENT.csv")
    track_path = Path(str(prefix) + "_TRACK.csv")
    shells_path = Path(str(prefix) + "_SHELLS.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    refinement_df.to_csv(refinement_path, index=False)
    track_df.to_csv(track_path, index=False)
    shells_df.to_csv(shells_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "future_root_solves": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": upstream,
        "arithmetic": {
            "start_anchor": int(args.start_anchor),
            "blind_anchor": int(args.blind_anchor),
            "max_cutoff": int(args.max_cutoff),
            "modes": int(common),
            "cached_prime_power_terms": int(len(table.logs)),
        },
        "refinement": {
            "steps": refinement_steps,
            "max_refined_blind_error": max_refined_blind,
            "max_finest_vs_previous_endpoint_change": max_refinement_change,
            "max_primitive_identity_residual": max_refine_identity,
            "pass": refinement_pass,
        },
        "frozen_caps": {
            "development_shells": int(args.development_shells),
            "safety": float(args.cap_safety),
            "beta_cap": beta_cap,
            "shell_mean_beta_cap": shell_mean_cap,
            "cesaro_mean_beta_cap": cesaro_mean_cap,
        },
        "holdout": {
            "holdout_max_beta": hold_beta,
            "holdout_max_shell_mean_beta": hold_shell_mean,
            "holdout_max_cesaro_mean_beta": hold_cesaro_mean,
            "beta_pass": beta_hold_pass,
            "shell_mean_beta_pass": shell_mean_hold_pass,
            "cesaro_mean_beta_pass": cesaro_mean_hold_pass,
            "finite_O_L_primitive_diagnostic_pass": numerical_O_L_pass,
        },
        "global_diagnostics": {
            "minimum_slope_over_L": min_slope_all,
            "nofold_all": nofold_all,
            "maximum_primitive_identity_residual": max_identity_all,
            "maximum_available_blind_endpoint_error": max_prod_blind,
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "FINITE PROSPECTIVE ZERO-FREE ARITHMETIC AUDIT ONLY. A pass supplies "
            "strong evidence for the v419 primitive-beta route but does not prove "
            "the required all-L subquadratic primitive bound. The analytic target "
            "remains: on every fixed ordered nonattained Riesz branch, prove eventual "
            "no-fold and |Pi_k(L)|=O_k(L^(2-eps)) for some eps>0; Pi=O(L) would give "
            "the natural O(1/L) cutoff tail."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    cert = {
        "schema": "ROT_RH_CESARO_MEAN_PRIMITIVE_BETA_CERTIFICATE_V1",
        "regulator": "Riesz/log-Cesaro only",
        "already_closed": {
            "exact_root_flow": "v418",
            "primitive_beta_implication": "v419",
            "RG_characteristic_and_cell_conservation": "v420",
            "attained_Riesz_rightmost_sector": "v421 under stable chamber",
        },
        "required_final_claims": {
            "fixed_ordered_branch_persistence": "RIGOROUS_OR_BRANCH_EXCLUDED",
            "eventual_no_fold": "F'_L(E_k(L)) != 0",
            "primitive_beta": "|int B_k| <= C_k L^(2-epsilon), epsilon>0",
            "preferred_strong_form": "Pi_k(L)=O_k(L)",
        },
        "numerical_evidence_from_v423": {
            "refinement_pass": refinement_pass,
            "prospective_holdout_pass": prospective_pass,
            "minimum_slope_over_L": min_slope_all,
            "holdout_max_beta": hold_beta,
            "holdout_max_shell_mean_beta": hold_shell_mean,
            "holdout_max_cesaro_mean_beta": hold_cesaro_mean,
        },
        "forbidden_as_proof": [
            "finite cutoff holdout",
            "finite regression of beta or Pi",
            "known zero ordinates",
            "Xi fitting",
            "magnitude-only PNT bounds",
            "synthetic resonance typicality",
        ],
    }
    cert_path.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("\n" + "=" * 238)
    print("VERDICT                                   :", verdict)
    print("NEXT THEOREM                              :", next_theorem)
    print("FIXED-MODE CUTOFF REMOVAL                 : NOT YET PROVED")
    print("=" * 238)
    print("Files written:")
    print(" ", refinement_path)
    print(" ", track_path)
    print(" ", shells_path)
    print(" ", summary_path)
    print(" ", cert_path)

    if args.strict and not prospective_pass:
        raise SystemExit(2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
