#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v431 — DYADIC RENEWAL / LOCAL FORCING THEOREM FOR OLD-HISTORY CARRIER
============================================================================

Purpose
-------
v430 proved that the stable v429 transfer carrier is OLD_HISTORY dominated.

Let h=log 2, a=log 2, and

    g_E(u)=e^(-u/2) sin(Eu),

    A(u)=psi(e^u)-log(2)-(e^u-2),

    H_L(E)=int_a^L A(u) g'_E(u) du.

The v430 old-history carrier on the shell [L,L+h] is

    S_L(E) := L D_old(L,E)
            = h/(L+h) H_L(E).

The key observation is the exact dyadic renewal law

    H_(L+h)=H_L+J_L,

where the LOCAL forcing is

    J_L(E)=int_L^(L+h) A(u)g'_E(u)du.

Therefore

    S_(L+h)(E)
      = h/(L+2h) H_(L+h)(E)
      = [(L+h)/(L+2h)] S_L(E)
        + [h/(L+2h)] J_L(E).

The two coefficients are positive and sum to 1 EXACTLY.

Consequently, if for a fixed-k compact tube I_k

    sup_(L large, E in I_k) |J_L(E)| <= J_k < infinity,

then by induction

    sup_n |S_(L0+n h)(E)|
      <= max(
           sup_(E in I_k)|S_L0(E)|,
           J_k
         ).

Thus the GLOBAL old-history theorem is reduced to a LOCAL DYADIC forcing
bound.

Pure locality of J
------------------
The v414 centered generator satisfies

    C0(L,E)
      = int_a^L g_E(u) dDelta_psi(u).

After removing the fixed n=2 atom,

    H_L(E)
      = A(L)g_E(L)
        - C0(L,E)
        + log(2) g_E(log2).

Hence

    J_L(E)
      = A(L+h)g_E(L+h)-A(L)g_E(L)
        - [C0(L+h,E)-C0(L,E)].

But

    C0(L+h,E)-C0(L,E)
      = sum_(X <= n < 2X)
          Lambda(n)/sqrt(n) sin(E log n)
        - integral_X^(2X)
          t^(-1/2) sin(E log t) dt.

So J_L depends ONLY on the current dyadic shell plus its two endpoint
Chebyshev discrepancies.  No old prime support remains.

What v431 does
--------------
1. Loads the exact v430 point table.
2. Reuses the zero-free v71 prime/PNT arithmetic; no roots are solved.
3. Builds psi(e^u) from exact prime-power Lambda weights.
4. Reconstructs A(L) and checks it against v430.
5. Evaluates C0 at X and 2X for every fixed energy/tube point.
6. Independently evaluates the local shell increment Delta C0 from ONLY
   prime powers X<=n<2X plus the smooth shell integral.
7. Verifies all exact identities:
     * endpoint C0 difference = local shell C0 increment;
     * v430 S_L identity;
     * J=H_(L+h)-H_L;
     * convex renewal recurrence for S_(L+h).
8. Diagnoses the finite size/stability of J_L and whether its boundedness
   comes from endpoint dominance, local-C0 dominance, additive structure,
   or signed endpoint/local-C0 cancellation.
9. Writes the exact analytic certificate:
       sup |J_L(E)| < infinity
   plus transversality.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO new root solves.
NO cutoffs beyond v429/v430.
NO finite J bound is accepted as a proof.

Version: 431
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 431
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def sha256_file(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists():
        return None
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, Path):
        return str(x)
    raise TypeError(type(x).__name__)


def call_trig_sum(
    base,
    energies: np.ndarray,
    logs: np.ndarray,
    weights: np.ndarray,
    trig: str,
    *,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}

    try:
        return np.asarray(
            fn(energies, logs, weights, trig, **kwargs),
            float,
        )
    except TypeError:
        return np.asarray(
            fn(energies, logs, weights, trig),
            float,
        )


def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    return np.imag(
        (np.exp(a*L)-np.exp(a*LOG2))/a
    )


def support_count(logs: np.ndarray, L: float) -> int:
    return int(
        np.searchsorted(
            logs,
            float(L)-1.0e-14,
            side="left",
        )
    )


# -----------------------------------------------------------------------------
# Exact symbolic theorem
# -----------------------------------------------------------------------------

def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, h = sp.symbols("L h", positive=True, real=True)
    H, J = sp.symbols("H J", real=True)

    S = h/(L+h)*H
    Snext = h/(L+2*h)*(H+J)

    alpha = (L+h)/(L+2*h)
    beta = h/(L+2*h)

    recurrence = sp.simplify(
        Snext - (alpha*S + beta*J)
    )
    partition = sp.simplify(alpha+beta-1)

    A0, A1, g0, g1, C00, C01 = sp.symbols(
        "A0 A1 g0 g1 C00 C01",
        real=True,
    )
    ell, ga = sp.symbols("ell ga", real=True)

    H0 = A0*g0-C00+ell*ga
    H1 = A1*g1-C01+ell*ga
    J_endpoint = A1*g1-A0*g0
    J_c0 = -(C01-C00)
    J_formula = sp.simplify(
        (H1-H0) - (J_endpoint+J_c0)
    )

    # Convex-envelope theorem:
    # if |S|<=M and |J|<=M, alpha,beta>=0, alpha+beta=1,
    # then |alpha*S+beta*J|<=M.
    # Record exact coefficients; positivity follows from L,h>0.
    return {
        "renewal_residual": str(recurrence),
        "convex_partition_residual": str(partition),
        "local_forcing_endpoint_residual": str(J_formula),
        "alpha": "(L+h)/(L+2h)",
        "beta": "h/(L+2h)",
        "alpha_positive": True,
        "beta_positive": True,
        "convex_envelope_implication": (
            "|S_L|<=M and |J_L|<=M => |S_(L+h)|<=M"
        ),
        "pass": bool(
            recurrence == 0
            and partition == 0
            and J_formula == 0
        ),
    }


# -----------------------------------------------------------------------------
# Prime-power cache / Chebyshev discrepancy
# -----------------------------------------------------------------------------

def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)

    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    lambda_w = logs/exponents
    lambda_cumsum = np.cumsum(lambda_w, dtype=np.float64)
    generator_w = np.exp(-0.5*logs)*lambda_w

    return (
        primes,
        logs,
        exponents,
        lambda_w,
        lambda_cumsum,
        generator_w,
    )


def psi_minus(
    logs: np.ndarray,
    lambda_cumsum: np.ndarray,
    L: float,
) -> float:
    k = support_count(logs, L)
    return (
        float(lambda_cumsum[k-1])
        if k > 0
        else 0.0
    )


def A_of_L(
    logs: np.ndarray,
    lambda_cumsum: np.ndarray,
    L: float,
) -> float:
    X = math.exp(L)
    return (
        psi_minus(logs, lambda_cumsum, L)
        - LOG2
        - (X-2.0)
    )


def eval_C0(
    *,
    base,
    logs: np.ndarray,
    generator_w: np.ndarray,
    X: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L = math.log(float(X))
    k = support_count(logs, L)
    prime = call_trig_sum(
        base,
        np.asarray(E, float),
        logs[:k],
        generator_w[:k],
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    return prime-smooth0(E, L)


def eval_local_delta_C0(
    *,
    base,
    logs: np.ndarray,
    generator_w: np.ndarray,
    X0: int,
    X1: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L0 = math.log(float(X0))
    L1 = math.log(float(X1))
    k0 = support_count(logs, L0)
    k1 = support_count(logs, L1)

    prime_shell = call_trig_sum(
        base,
        np.asarray(E, float),
        logs[k0:k1],
        generator_w[k0:k1],
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    smooth_shell = smooth0(E, L1)-smooth0(E, L0)
    return prime_shell-smooth_shell


# -----------------------------------------------------------------------------
# Mechanism classification for local J
# -----------------------------------------------------------------------------

def classify_forcing(
    endpoint: np.ndarray,
    c0part: np.ndarray,
    total: np.ndarray,
    *,
    dominance_threshold: float,
    cancellation_threshold: float,
) -> Dict[str, Any]:
    ae = np.abs(endpoint)
    ac = np.abs(c0part)
    denom = ae+ac
    eshare = ae/np.maximum(denom, EPS)
    cshare = ac/np.maximum(denom, EPS)
    cancel = np.abs(total)/np.maximum(denom, EPS)

    me = float(np.mean(eshare))
    mc = float(np.mean(cshare))
    med_cancel = float(np.median(cancel))

    if me >= dominance_threshold:
        mechanism = "ENDPOINT_DISCREPANCY_DOMINANT"
    elif mc >= dominance_threshold:
        mechanism = "LOCAL_C0_SHELL_DOMINANT"
    elif med_cancel <= cancellation_threshold:
        mechanism = "SIGNED_ENDPOINT_LOCAL_C0_CANCELLATION"
    else:
        mechanism = "MIXED_LOCAL_FORCING"

    return {
        "mechanism": mechanism,
        "mean_endpoint_abs_share": me,
        "mean_local_C0_abs_share": mc,
        "median_cancellation_ratio": med_cancel,
    }


def next_target(mechanism: str) -> str:
    if mechanism == "ENDPOINT_DISCREPANCY_DOMINANT":
        return (
            "PROVE_UNIFORM_DYADIC_ENDPOINT_CHEBYSHEV_INCREMENT_BOUND"
        )
    if mechanism == "LOCAL_C0_SHELL_DOMINANT":
        return (
            "PROVE_UNIFORM_CENTERED_DYADIC_MANGOLDT_SHELL_TRANSFORM_BOUND"
        )
    if mechanism == "SIGNED_ENDPOINT_LOCAL_C0_CANCELLATION":
        return (
            "PROVE_EXACT_LOCAL_STIELTJES_DYADIC_FORCING_BOUND_PRESERVING_SIGNED_CANCELLATION"
        )
    return (
        "PROVE_UNIFORM_LOCAL_DYADIC_FORCING_BOUND_BY_JOINT_ENDPOINT_AND_SHELL_ESTIMATES"
    )


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v430-points",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v430-summary",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_SUMMARY.json",
    )
    ap.add_argument(
        "--v425-summary",
        default="rot_rh_renormalized_stiffness_rg_v425_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--energy-chunk", type=int, default=6)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument(
        "--dominance-threshold",
        type=float,
        default=0.65,
    )
    ap.add_argument(
        "--cancellation-threshold",
        type=float,
        default=0.45,
    )
    ap.add_argument(
        "--maximum-A-reconstruction",
        type=float,
        default=2.0e-6,
        help="Absolute A(L) reconstruction tolerance; psi accumulation is float64.",
    )
    ap.add_argument(
        "--maximum-C0-start-relative",
        type=float,
        default=5.0e-10,
    )
    ap.add_argument(
        "--maximum-local-C0-relative",
        type=float,
        default=5.0e-10,
    )
    ap.add_argument(
        "--maximum-renewal-relative",
        type=float,
        default=5.0e-11,
    )
    ap.add_argument(
        "--development-cap-safety",
        type=float,
        default=1.25,
        help="Finite J diagnostic only; never proof.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_old_history_dyadic_renewal_local_forcing_v431",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.energy_chunk < 1 or args.term_chunk < 1:
        raise ValueError("chunk sizes must be positive")
    if args.development_cap_safety <= 1:
        raise ValueError("--development-cap-safety must be >1")

    started = time.time()

    v430 = load_json(args.v430_summary)
    v425 = load_json(args.v425_summary)

    v430_ok = bool(
        v430 is not None
        and str(v430.get("verdict", "")).startswith(
            "EXACT_DYADIC_OLD_FRESH_TRANSFER_DECOMPOSITION_PASS_"
        )
    )
    v430_old = bool(
        v430_ok
        and v430.get("mechanism", {}).get(
            "final_carrier_diagnosis"
        ) == "OLD_HISTORY_CARRIER"
    )
    v425_ok = bool(
        v425 is not None
        and v425.get("verdict")
        == "RENORMALIZED_STIFFNESS_RG_PROSPECTIVE_NOFOLD_PASS"
    )

    print("=" * 232)
    print("ROT-RH v431 — DYADIC RENEWAL / LOCAL FORCING THEOREM FOR OLD-HISTORY CARRIER")
    print("=" * 232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("new larger cutoffs                        : NONE")
    print("finite local-forcing bound accepted proof : NO")
    print("=" * 232)

    print("[1] Upstream")
    print(
        "v430 exact old/fresh decomposition       :",
        v430_ok,
        None if v430 is None else v430.get("verdict"),
    )
    print(
        "v430 old-history carrier                 :",
        v430_old,
    )
    print(
        "v425 finite RG/no-fold evidence          :",
        v425_ok,
        None if v425 is None else v425.get("verdict"),
    )

    print("\n[2] Exact renewal theorem")
    sym = symbolic_checks()
    print("symbolic renewal identities pass          :", sym.get("pass"))
    print("alpha                                      :", sym.get("alpha"))
    print("beta                                       :", sym.get("beta"))
    print("alpha+beta                                 : 1 EXACTLY")
    print(
        "convex envelope                          :",
        sym.get("convex_envelope_implication"),
    )
    if not sym.get("pass") and args.strict:
        return 2

    p = Path(args.v430_points)
    if not p.exists():
        raise FileNotFoundError(p)

    df = pd.read_csv(p)
    required = {
        "set",
        "shell_index",
        "X0",
        "X1",
        "L0",
        "L1",
        "root_index",
        "E_fixed",
        "tube_coordinate",
        "A_at_L",
        "C0_at_shell_start",
        "LD_old",
    }
    missing = sorted(required-set(df.columns))
    if missing:
        raise KeyError(
            f"v430 points missing columns: {missing}"
        )

    df = df.sort_values(
        ["L0", "root_index", "tube_coordinate"]
    ).reset_index(drop=True)

    max_X1 = int(df["X1"].max())
    base = importlib.import_module(args.v71_module)

    print("\n[3] Zero-free prime-power / Chebyshev cache")
    t0 = time.time()
    (
        primes,
        logs,
        exponents,
        lambda_w,
        lambda_cumsum,
        generator_w,
    ) = build_cache(base, max_X1)
    print("maximum reused cutoff                    :", f"{max_X1:,}")
    print("primes <= maximum cutoff                 :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    out_parts = []
    group_cols = [
        "set",
        "shell_index",
        "X0",
        "X1",
        "L0",
        "L1",
    ]
    groups = list(df.groupby(group_cols, sort=True, dropna=False))

    max_A_resid = 0.0
    max_C0_start_rel = 0.0
    max_local_C0_rel = 0.0
    max_renewal_rel = 0.0

    bar = tqdm(
        total=len(groups),
        desc="dyadic local forcing shells",
        unit="shell",
    )

    for key, gdf in groups:
        setname, shell_index, X0, X1, L0, L1 = key
        X0 = int(X0)
        X1 = int(X1)
        L0 = float(L0)
        L1 = float(L1)
        h = L1-L0

        gg = gdf.copy().reset_index(drop=True)
        E = gg["E_fixed"].to_numpy(float)

        A0 = A_of_L(logs, lambda_cumsum, L0)
        A1 = A_of_L(logs, lambda_cumsum, L1)

        A0_old = gg["A_at_L"].to_numpy(float)
        A_resid = np.abs(A0_old-A0)
        max_A_resid = max(
            max_A_resid,
            float(np.max(A_resid)),
        )

        C00 = eval_C0(
            base=base,
            logs=logs,
            generator_w=generator_w,
            X=X0,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        C01 = eval_C0(
            base=base,
            logs=logs,
            generator_w=generator_w,
            X=X1,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )

        C00_old = gg["C0_at_shell_start"].to_numpy(float)
        C0_start_abs = np.abs(C00-C00_old)
        C0_start_rel = (
            C0_start_abs
            / np.maximum(np.abs(C00_old), 1.0e-12)
        )
        max_C0_start_rel = max(
            max_C0_start_rel,
            float(np.max(C0_start_rel)),
        )

        deltaC0_endpoint = C01-C00
        deltaC0_local = eval_local_delta_C0(
            base=base,
            logs=logs,
            generator_w=generator_w,
            X0=X0,
            X1=X1,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        local_abs = np.abs(
            deltaC0_endpoint-deltaC0_local
        )
        local_rel = (
            local_abs
            / np.maximum(
                np.abs(deltaC0_endpoint),
                1.0e-12,
            )
        )
        max_local_C0_rel = max(
            max_local_C0_rel,
            float(np.max(local_rel)),
        )

        g0 = np.exp(-0.5*L0)*np.sin(E*L0)
        g1 = np.exp(-0.5*L1)*np.sin(E*L1)
        ga = math.exp(-0.5*LOG2)*np.sin(E*LOG2)

        H0 = A0*g0-C00+LOG2*ga
        H1 = A1*g1-C01+LOG2*ga

        J_endpoint = A1*g1-A0*g0
        J_local_C0 = -deltaC0_endpoint
        J = J_endpoint+J_local_C0
        J_H = H1-H0

        S0 = h/(L0+h)*H0
        S1 = h/(L0+2*h)*H1
        alpha = (L0+h)/(L0+2*h)
        beta = h/(L0+2*h)
        S1_rec = alpha*S0+beta*J

        S0_old = gg["LD_old"].to_numpy(float)

        renewal_abs = np.abs(S1-S1_rec)
        renewal_rel = renewal_abs/np.maximum(
            np.abs(S1),
            1.0e-12,
        )
        max_renewal_rel = max(
            max_renewal_rel,
            float(np.max(renewal_rel)),
        )

        old_S0_abs = np.abs(S0-S0_old)
        old_S0_rel = old_S0_abs/np.maximum(
            np.abs(S0_old),
            1.0e-12,
        )

        forcing_abs_sum = (
            np.abs(J_endpoint)+np.abs(J_local_C0)
        )
        endpoint_share = (
            np.abs(J_endpoint)
            / np.maximum(forcing_abs_sum, EPS)
        )
        local_C0_share = (
            np.abs(J_local_C0)
            / np.maximum(forcing_abs_sum, EPS)
        )
        forcing_cancel = (
            np.abs(J)
            / np.maximum(forcing_abs_sum, EPS)
        )

        gg["A0_reconstructed"] = A0
        gg["A1_reconstructed"] = A1
        gg["A0_absolute_residual"] = A_resid
        gg["C0_X0_reconstructed"] = C00
        gg["C0_X1_reconstructed"] = C01
        gg["C0_X0_relative_residual"] = C0_start_rel
        gg["delta_C0_endpoint"] = deltaC0_endpoint
        gg["delta_C0_local_shell"] = deltaC0_local
        gg["delta_C0_local_relative_residual"] = local_rel
        gg["g0"] = g0
        gg["g1"] = g1
        gg["H0"] = H0
        gg["H1"] = H1
        gg["J_endpoint"] = J_endpoint
        gg["J_local_C0"] = J_local_C0
        gg["J_total"] = J
        gg["J_from_H_difference"] = J_H
        gg["S0_old_history"] = S0
        gg["S1_same_fixed_E"] = S1
        gg["renewal_alpha"] = alpha
        gg["renewal_beta"] = beta
        gg["S1_recurrence"] = S1_rec
        gg["renewal_relative_residual"] = renewal_rel
        gg["v430_S0_relative_residual"] = old_S0_rel
        gg["forcing_endpoint_abs_share"] = endpoint_share
        gg["forcing_local_C0_abs_share"] = local_C0_share
        gg["forcing_signed_cancellation_ratio"] = forcing_cancel
        gg["convex_envelope_bound"] = np.maximum(
            np.abs(S0),
            np.abs(J),
        )
        gg["S1_over_convex_envelope"] = (
            np.abs(S1)
            / np.maximum(
                gg["convex_envelope_bound"].to_numpy(float),
                EPS,
            )
        )

        out_parts.append(gg)
        bar.update(1)

    bar.close()
    out = pd.concat(out_parts, ignore_index=True)

    reconstruction_pass = bool(
        max_A_resid <= args.maximum_A_reconstruction
        and max_C0_start_rel <= args.maximum_C0_start_relative
        and max_local_C0_rel <= args.maximum_local_C0_relative
        and max_renewal_rel <= args.maximum_renewal_relative
    )

    print("\n[4] Exact locality / renewal reconstruction")
    print(
        "maximum A(L) absolute reconstruction     :",
        f"{max_A_resid:.12e}",
    )
    print(
        "maximum C0(X) start relative residual    :",
        f"{max_C0_start_rel:.12e}",
    )
    print(
        "maximum local-shell DeltaC0 rel residual :",
        f"{max_local_C0_rel:.12e}",
    )
    print(
        "maximum renewal recurrence rel residual  :",
        f"{max_renewal_rel:.12e}",
    )
    print("exact locality/renewal pass               :", reconstruction_pass)

    # ------------------------------------------------------------------
    # Shell diagnostics
    # ------------------------------------------------------------------
    shell_rows = []
    for key, g in out.groupby(
        group_cols,
        sort=True,
        dropna=False,
    ):
        setname, shell_index, X0, X1, L0, L1 = key
        endpoint = g["J_endpoint"].to_numpy(float)
        c0part = g["J_local_C0"].to_numpy(float)
        total = g["J_total"].to_numpy(float)

        cls = classify_forcing(
            endpoint,
            c0part,
            total,
            dominance_threshold=args.dominance_threshold,
            cancellation_threshold=args.cancellation_threshold,
        )

        ij = int(np.argmax(np.abs(total)))
        jr = g.iloc[ij]

        shell_rows.append({
            "set": str(setname),
            "shell_index": int(shell_index),
            "X0": int(X0),
            "X1": int(X1),
            "L0": float(L0),
            "L1": float(L1),
            "forcing_mechanism": cls["mechanism"],
            "mean_endpoint_abs_share": cls["mean_endpoint_abs_share"],
            "mean_local_C0_abs_share": cls["mean_local_C0_abs_share"],
            "median_forcing_cancellation_ratio": cls[
                "median_cancellation_ratio"
            ],
            "max_abs_J": float(np.max(np.abs(total))),
            "rms_J": float(np.sqrt(np.mean(total*total))),
            "max_abs_J_endpoint": float(
                np.max(np.abs(endpoint))
            ),
            "max_abs_J_local_C0": float(
                np.max(np.abs(c0part))
            ),
            "max_abs_S0": float(
                np.max(
                    np.abs(
                        g["S0_old_history"].to_numpy(float)
                    )
                )
            ),
            "max_abs_S1": float(
                np.max(
                    np.abs(
                        g["S1_same_fixed_E"].to_numpy(float)
                    )
                )
            ),
            "max_S1_over_convex_envelope": float(
                np.max(
                    g[
                        "S1_over_convex_envelope"
                    ].to_numpy(float)
                )
            ),
            "maxJ_root_index": int(jr["root_index"]),
            "maxJ_tube_coordinate": float(
                jr["tube_coordinate"]
            ),
            "maxJ_E_fixed": float(jr["E_fixed"]),
            "maxJ_value": float(jr["J_total"]),
            "maxJ_endpoint_part": float(jr["J_endpoint"]),
            "maxJ_local_C0_part": float(jr["J_local_C0"]),
            "maxJ_cancellation_ratio": float(
                jr["forcing_signed_cancellation_ratio"]
            ),
        })

    shell_df = pd.DataFrame(shell_rows).sort_values(
        ["L0", "shell_index"]
    ).reset_index(drop=True)

    dev = shell_df[
        shell_df["set"].str.lower() == "development"
    ].copy()
    hold = shell_df[
        shell_df["set"].str.lower() != "development"
    ].copy()
    if dev.empty:
        dev = shell_df.iloc[:1].copy()
        hold = shell_df.iloc[1:].copy()

    dev_max_J = float(dev["max_abs_J"].max())
    frozen_J_cap = (
        args.development_cap_safety*dev_max_J
    )
    hold_max_J = (
        float(hold["max_abs_J"].max())
        if not hold.empty
        else float("nan")
    )
    finite_J_holdout_pass = bool(
        not hold.empty
        and math.isfinite(hold_max_J)
        and hold_max_J <= frozen_J_cap
    )

    dev_mechs = dev["forcing_mechanism"].tolist()
    dev_mech = (
        dev_mechs[0]
        if len(set(dev_mechs)) == 1
        else "DEVELOPMENT_FORCING_MIXED"
    )
    hold_mech_stable = bool(
        not hold.empty
        and dev_mech != "DEVELOPMENT_FORCING_MIXED"
        and np.all(
            hold["forcing_mechanism"].to_numpy(str)
            == dev_mech
        )
    )

    # If mechanism changes across shells, use aggregate shares.
    aggregate = classify_forcing(
        out["J_endpoint"].to_numpy(float),
        out["J_local_C0"].to_numpy(float),
        out["J_total"].to_numpy(float),
        dominance_threshold=args.dominance_threshold,
        cancellation_threshold=args.cancellation_threshold,
    )
    final_mech = (
        dev_mech
        if hold_mech_stable
        else aggregate["mechanism"]
    )
    next_theorem = next_target(final_mech)

    print("\n[5] Local dyadic forcing diagnosis")
    print(
        "development max |J|                     :",
        f"{dev_max_J:.12e}",
    )
    print(
        "frozen finite J cap                     :",
        f"{frozen_J_cap:.12e}",
    )
    print(
        "holdout max |J|                         :",
        f"{hold_max_J:.12e}",
    )
    print(
        "finite J holdout pass                   :",
        finite_J_holdout_pass,
    )
    print(
        "development forcing mechanism           :",
        dev_mech,
    )
    print(
        "holdout mechanism stable                :",
        hold_mech_stable,
    )
    print(
        "FINAL LOCAL FORCING DIAGNOSIS           :",
        final_mech,
    )
    print(
        "NEXT ANALYTIC TARGET                    :",
        next_theorem,
    )
    print(
        "IMPORTANT                               : finite |J| stability is NOT proof"
    )

    print("\nShell renewal summary:")
    display = [
        "set",
        "shell_index",
        "X0",
        "X1",
        "forcing_mechanism",
        "max_abs_J",
        "max_abs_J_endpoint",
        "max_abs_J_local_C0",
        "median_forcing_cancellation_ratio",
        "max_abs_S0",
        "max_abs_S1",
        "max_S1_over_convex_envelope",
    ]
    print(
        shell_df[display].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    exact_pass = bool(
        sym.get("pass")
        and v430_old
        and reconstruction_pass
    )

    verdict = (
        "EXACT_OLD_HISTORY_DYADIC_RENEWAL_LOCAL_FORCING_REDUCTION_PASS"
        if exact_pass
        else
        "OLD_HISTORY_DYADIC_RENEWAL_LOCAL_FORCING_REDUCTION_INCOMPLETE"
    )

    print("\n" + "=" * 232)
    print("VERDICT                                   :", verdict)
    print(
        "GLOBAL OLD-HISTORY CARRIER REDUCED TO     :",
        "LOCAL DYADIC |J_L(E)| BOUND",
    )
    print(
        "RENEWAL COEFFICIENTS                      :",
        "POSITIVE, SUM TO 1 EXACTLY",
    )
    print(
        "LOCAL FORCING SUPPORT                     :",
        "ONLY X <= n < 2X + ENDPOINT DISCREPANCIES",
    )
    print(
        "FIXED-MODE CUTOFF REMOVAL                 :",
        "NOT PROVED BY v431",
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 232)

    prefix = Path(args.prefix)
    points_out = Path(str(prefix) + "_POINTS.csv.gz")
    shell_out = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix) + "_SUMMARY.json")
    theorem_out = Path(str(prefix) + "_THEOREM.md")
    cert_out = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    out.to_csv(
        points_out,
        index=False,
        compression="gzip",
    )
    shell_df.to_csv(shell_out, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v430": False,
            "finite_J_bound_accepted_as_proof": False,
        },
        "upstream": {
            "v430_ok": v430_ok,
            "v430_old_history_carrier": v430_old,
            "v430_verdict": (
                None if v430 is None
                else v430.get("verdict")
            ),
            "v425_ok": v425_ok,
        },
        "inputs": {
            "v430_points": args.v430_points,
            "v430_points_sha256": sha256_file(args.v430_points),
            "v71_module": args.v71_module,
            "energy_chunk": args.energy_chunk,
            "term_chunk": args.term_chunk,
        },
        "exact_symbolic_theorem": sym,
        "reconstruction": {
            "maximum_A_absolute_residual": max_A_resid,
            "maximum_C0_start_relative_residual": max_C0_start_rel,
            "maximum_local_C0_relative_residual": max_local_C0_rel,
            "maximum_renewal_relative_residual": max_renewal_rel,
            "pass": reconstruction_pass,
        },
        "finite_J_diagnostic": {
            "development_max_abs_J": dev_max_J,
            "safety": args.development_cap_safety,
            "frozen_J_cap": frozen_J_cap,
            "holdout_max_abs_J": hold_max_J,
            "holdout_pass": finite_J_holdout_pass,
            "proof_status": "EVIDENCE_ONLY",
        },
        "local_forcing_mechanism": {
            "development": dev_mech,
            "holdout_stable": hold_mech_stable,
            "aggregate": aggregate,
            "final": final_mech,
        },
        "exact_reduction_pass": exact_pass,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
        "outputs": {
            "points": str(points_out),
            "shell_summary": str(shell_out),
            "summary": str(summary_out),
            "theorem": str(theorem_out),
            "certificate": str(cert_out),
        },
    }
    summary_out.write_text(
        json.dumps(payload, indent=2, default=json_safe),
        encoding="utf-8",
    )

    theorem_text = f"""# ROT-RH v431 — exact dyadic renewal theorem

Let `h=log 2` and

`H_L(E)=int_(log2)^L A(u)g'_E(u)du`.

Define the old-history transfer carrier

`S_L(E)=h/(L+h) H_L(E)=L D_old(L,E)`.

Let the local dyadic forcing be

`J_L(E)=int_L^(L+h) A(u)g'_E(u)du`.

Then

`H_(L+h)=H_L+J_L`

and therefore exactly

`S_(L+h)
 =[(L+h)/(L+2h)]S_L
  +[h/(L+2h)]J_L`.

The coefficients

`alpha_L=(L+h)/(L+2h)`

and

`beta_L=h/(L+2h)`

are positive and satisfy

`alpha_L+beta_L=1`.

Therefore, if on a fixed-k eventual compact tube `I_k`

`|J_L(E)|<=J_k`

for every sufficiently large dyadic `L` and every `E in I_k`, then

`|S_(L+n h)(E)|
 <= max(|S_L(E)|,J_k)`

for all `n>=0`.

Hence the global old-history bound follows from a local shell theorem.

The forcing is exactly local:

`J_L
 =A(L+h)g_E(L+h)-A(L)g_E(L)
  -[C0(L+h,E)-C0(L,E)]`,

and

`C0(L+h,E)-C0(L,E)
 =sum_(X<=n<2X) Lambda(n)/sqrt(n) sin(E log n)
  -int_X^(2X)t^(-1/2)sin(E log t)dt`.

Thus no prime powers below `X` occur in the forcing after the exact
renewal reduction.

## Finite v431 forcing diagnosis

`{final_mech}`

The corresponding next theorem is

`{next_theorem}`.

This finite diagnosis is not proof of the uniform all-L bound.

Once the local theorem

`sup_(E in I_k)|J_L(E)|<=J_k`

is proved, v431 gives a uniform old-history carrier bound.  v429 then gives
the O(1/L) signed dyadic phase transfer after the separately controlled
fresh contribution.  Together with the all-L transversality theorem,
v411 yields summable fixed-mode root motion and fixed-mode cutoff removal.
"""
    theorem_out.write_text(
        theorem_text,
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_DYADIC_RENEWAL_LOCAL_FORCING_CERTIFICATE_V1",
        "finite_diagnosis": final_mech,
        "finite_values_are_not_proof": True,
        "required_claims": {
            "fixed_mode_tube": {
                "proved": False,
                "statement": (
                    "There is an eventual compact fixed-k tube I_k on "
                    "which the local forcing estimate is uniform."
                ),
            },
            "local_dyadic_forcing": {
                "proved": False,
                "statement": (
                    "There exists J_k<infinity such that for all sufficiently "
                    "large dyadic L and E in I_k, "
                    "|J_L(E)|=|int_L^(L+log2) A(u)g'_E(u)du|<=J_k."
                ),
                "constant_J_k": None,
            },
            "fresh_transfer": {
                "proved": False,
                "statement": (
                    "The v430 fresh contribution obeys "
                    "sup |L D_fresh(L,E)|<infinity, or is absorbed into a "
                    "joint local theorem."
                ),
            },
            "transversality": {
                "proved": False,
                "statement": (
                    "F'_L(E)>=c_k L uniformly on the eventual fixed-k tube, "
                    "or equivalently the v425 signed RG primitive is bounded above."
                ),
            },
        },
        "exact_consequence": (
            "The convex renewal gives a uniform old-history carrier; "
            "with fresh control, v429 gives Delta_log2 F=O_k(1/L); "
            "with transversality, v411 gives fixed-mode cutoff removal."
        ),
        "forbidden_shortcuts": [
            "finite v431 J cap marked as proof",
            "known zero ordinates",
            "Xi fitting",
            "absolute PNT bound substituted for signed local forcing",
        ],
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_out)
    print(" ", shell_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
