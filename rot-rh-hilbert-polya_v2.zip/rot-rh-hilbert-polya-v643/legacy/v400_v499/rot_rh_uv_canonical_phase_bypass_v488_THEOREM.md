# ROT-RH v488 — UV-collapse / canonical-phase bypass

The v485-v487 survivor is an **auxiliary resonance-amplitude** pathology, not
automatically a singularity of the exact scalar characteristic.

For real `E` the canonical bump half-phase is

`r_L(E)=exp(-i Im Q_L(E))`,

so

`|r_L(E)|=1`

identically, even if an auxiliary zero-side resonance sum used to represent its
phase becomes extremely small.

The exact cutoff ODE is

`d_L log r_L(E)=-i C_q(L,E)/L^2`.

On the moving boundary

`E_u(L)=gamma-u/L`,

the exact chain rule gives

`d_L log r_L(E_u)=-i H_u(L)/L^2`,

with

`H_u=C_q+u B_E`.

For the principal multiplicity-`m` local collision,

`C_coll+u B_E,coll=0`

**exactly**.  v470 also places every remote critical-line collision in an
absolutely summable `O(L^-3)` boundary-phase tail.

Therefore the superexponential UV collapse isolated in v485-v487 does **not**
need to be excluded by a lower bound on the auxiliary amplitude.  The only
remaining cutoff-sensitive boundary contribution is the **recombined
off-critical collective regular generator**.

This is structurally consistent with the completed target: an off-critical
functional-equation quartet contributes the positive real factor

`|(1-t^2/tau^2)|^2>0`

on the real axis and hence has zero fractional completed phase.

So the correct final target is:

1. for `u=+U` and `u=-U`, prove a signed primitive
   `Pi_u(L)=int H_u^off(s) ds = O(L^(2-eps))` for some `eps>0`,
   **or directly prove** that the two boundary phases enter and stay in the
   v470 safe half-plane;
2. identify their limiting phase class with the completed midpoint/sign class.

Then the v470 two-boundary barrier traps the fixed label in

`|E(L)-gamma|<U/L`.

**Verdict:** `EXACT_UV_COLLAPSE_CANONICAL_PHASE_BYPASS_REDUCTION_PASS`.

This is a reduction theorem, not yet the missing off-critical primitive bound,
not RH, and not the Fredholm-Xi identity.
