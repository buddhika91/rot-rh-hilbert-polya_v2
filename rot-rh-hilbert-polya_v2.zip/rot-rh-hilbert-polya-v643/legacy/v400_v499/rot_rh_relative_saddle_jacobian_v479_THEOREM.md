# ROT-RH v479 — relative saddle Jacobian / two-mode transfer exclusion

For two high-ordinate bump saddle modes,

`lambda_j=a_j+i(Gamma_j-E)`.

The leading saddle term `L lambda_j` has relative difference

`L[(a_1-a_2)+i(Gamma_1-Gamma_2)]`;

therefore the universal `-EL` carrier cancels exactly.

For a comparable pair at common large ordinate `Gamma`,

`partial_E DeltaPhi
 =-[2^(1/3)sqrt(3)/6]
   L^(2/3) DeltaGamma Gamma^(-4/3)[1+o(1)]`

while

`partial_L DeltaPhi
 =DeltaGamma[1+o(1)]`.

Hence a regular relative-phase contour has

`dE/dL
 =[2sqrt(3)/2^(1/3)]
  Gamma^(4/3)L^(-2/3)[1+o(1)]`.

This dominates `L^-2` by

`(Gamma L)^(4/3)->infinity`.

So an `O(L^-2)` convergent cutoff branch cannot be transported over a late
interval by one comparable two-mode handoff.

**Verdict:** RELATIVE_SADDLE_TWO_MODE_TRANSFER_EXCLUSION_PASS

This does not exclude isolated two-mode crossing points and does not exclude
many-mode superoscillatory cancellation.  It removes pair-controlled window
transport from the final nonattained sector.
