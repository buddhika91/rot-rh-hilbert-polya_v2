#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v404 — G7 LOCAL SINGULARITY / MULTIPLICITY / MONODROMY REDUCTION
=======================================================================

Purpose
-------
v403 reduced the remaining head problem to collision-subtracted Mellin contour
bounds for the single G7 primitive.  v404 analyzes the LOCAL singularity
structure of that head around a hypothetical nontrivial zero.

This is important because the desired O_k(1) contour theorem is not a generic
absolute-value estimate: it is already an RH-strength singularity-cancellation
statement.

Upstream exact identities
-------------------------
v383 gives

    X(s) = -zeta'(s)/zeta(s) - (zeta(s)-1),

and

    X - G7 = R^7 X,

where locally

    R[A](s)
      = mu(s)^(-1)
        int_s^infty
          mu(w) [zeta'(w)/zeta(w)] A(w) dw,

    mu(s)
      = exp(int_s^infty (zeta(w)-1) dw).

Let rho be a nontrivial zero of multiplicity m and put

    t=s-rho.

Then

    zeta'/zeta = m/t + q0 + O(t),
    X            = -m/t + x0 + O(t),

while mu is analytic and nonzero at rho because zeta(rho)=0.

Principal-pole transport
------------------------
If

    A(t)=a_{-1}/t + O(log^p t),

then the double-pole part of

    mu(t) (zeta'/zeta)(t) A(t)

is

    mu(rho) m a_{-1}/t^2.

Integrating from t to a fixed point gives

    R[A](t)
      = m a_{-1}/t + lower singularity order.

Therefore the principal pole coefficient is multiplied by m under each R:

    Res_principal(R^j A) = m^j Res_principal(A).

Since Res_principal(X)=-m,

    Res_principal(R^7 X)=-m^8,

and hence

    Res_principal(G7)
      = Res(X-R^7 X)
      = m^8-m
      = m(m^7-1).

Consequences:
  * simple zero m=1: principal pole cancels exactly;
  * multiple zero m>1: a nonzero principal pole remains.

Logarithmic monodromy
---------------------
Even when m=1 and the principal pole cancels, R acting on a meromorphic A
generically creates logarithmic terms, because the coefficient of 1/t in

    mu (zeta'/zeta) A

integrates to log t.

Equivalently, analytic continuation of the Volterra integral around rho has
monodromy proportional to

    2 pi i Res_rho [mu(zeta'/zeta) A].

Thus the simple-zero G7 head need not be meromorphic even though its principal
pole vanishes.  The remaining v403 contour theorem must control this
monodromy/branch contribution.

Off-critical growth
-------------------
For the collision-safe Riesz kernel

    R_L(a)
      = [exp(L a)-1-L a]/(L a^2),

with

    a=rho-s,

an off-critical zero with Re(rho)-1/2 = delta>0 introduces the exponential
factor

    exp(L delta)=X^delta.

Therefore any surviving pole OR logarithmic/branch singularity on the
right of the critical line can obstruct an O_k(1) collision-subtracted head
bound.

So the final head theorem has the following dichotomy:

  1. prove every off-critical local singularity coefficient/monodromy cancels
     identically in the FULL relevant secular combination; or
  2. show that any surviving off-critical singularity forces growth
     incompatible with the v78 O_k(1) stiffness/tube theorem.

This is RH-strength.  It must not be replaced by finite cutoff extrapolation.

Multiplicity warning
--------------------
v69's displayed collision normalization was derived locally for a SIMPLE
nontrivial zero.  A complete proof must either:
  * derive simplicity from the operator/contour theorem, or
  * formulate a multiplicity-aware local Fredholm/collision normalization.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO assumption of RH.
NO assumption of simple zeros in PASS algebra.
No finite scan accepted as proof.

Version: 404
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

from tqdm import tqdm

VERSION = 404


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_local_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    m, ares = sp.symbols(
        "m ares",
        positive=True,
    )
    t = sp.symbols("t")

    # Principal singularity model only:
    # q = m/t + regular
    # A = ares/t + lower-order
    #
    # q*A has m*ares/t^2, whose integral from t to fixed endpoint
    # has +m*ares/t.
    q_principal = m/t
    A_principal = ares/t
    product = sp.expand(q_principal*A_principal)

    integrated_principal = m*ares/t
    derivative_check = sp.simplify(
        sp.diff(integrated_principal, t)
        + product
    )
    # Because d/dt int_t^T f(w)dw = -f(t).

    # Seven iterations on a residue.
    res_X = -m
    res_R7X = sp.expand((m**7)*res_X)
    res_G7 = sp.factor(res_X-res_R7X)
    expected_G7 = sp.factor(m*(m**7-1))

    residue_residual = sp.simplify(
        res_G7-expected_G7
    )

    simple_value = sp.simplify(
        res_G7.subs(m, 1)
    )
    double_value = sp.simplify(
        res_G7.subs(m, 2)
    )

    return {
        "principal_product": str(product),
        "integrated_principal": str(integrated_principal),
        "lower_limit_derivative_residual": str(derivative_check),
        "res_X": str(res_X),
        "res_R7X": str(res_R7X),
        "res_G7": str(res_G7),
        "expected_res_G7": str(expected_G7),
        "residue_residual": str(residue_residual),
        "simple_zero_res_G7": str(simple_value),
        "double_zero_res_G7": str(double_value),
        "pass": bool(
            derivative_check == 0
            and residue_residual == 0
            and simple_value == 0
            and double_value != 0
        ),
    }


def symbolic_collision_growth_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    L, delta, omega = sp.symbols(
        "L delta omega",
        positive=True,
        real=True,
    )
    a = delta + sp.I*omega

    R = (
        sp.exp(L*a)-1-L*a
    )/(L*a**2)

    # The exact modulus contains exp(L*delta) in the exponential term.
    exponential_modulus = sp.simplify(
        sp.Abs(sp.exp(L*a))
    )

    # SymPy may or may not simplify Abs(exp(...)) automatically.
    expected = sp.exp(L*delta)

    # Use exp(L(delta+iomega)) = exp(Ldelta)*exp(iLomega).
    factorization = (
        sp.exp(L*delta)
        * sp.exp(sp.I*L*omega)
    )
    factor_residual = sp.simplify(
        sp.exp(L*a)-factorization
    )

    return {
        "R_L_offcritical": str(R),
        "exp_factorization": str(factorization),
        "factor_residual": str(factor_residual),
        "exponential_magnitude": str(expected),
        "pass": bool(factor_residual == 0),
    }


def symbolic_monodromy_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    C, t = sp.symbols(
        "C t",
        nonzero=True,
    )

    # The local primitive of C/t is C log t.
    primitive = C*sp.log(t)
    derivative_residual = sp.simplify(
        sp.diff(primitive, t)-C/t
    )

    # One positive loop changes log t by 2*pi*i.
    monodromy = 2*sp.pi*sp.I*C

    return {
        "local_integrand": "C/t",
        "primitive": str(primitive),
        "derivative_residual": str(derivative_residual),
        "one_loop_monodromy": str(monodromy),
        "pass": bool(derivative_residual == 0),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v403-summary",
        default="rot_rh_G7_riesz_mellin_collision_v403_SUMMARY.json",
    )
    ap.add_argument(
        "--v383-summary",
        default="rot_rh_G7_mellin_volterra_head_v383_SUMMARY.json",
    )
    ap.add_argument(
        "--v402-summary",
        default="rot_rh_weighted_factorial_four_jet_v402_SUMMARY.json",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_G7_local_singularity_v404",
    )

    args = ap.parse_args()

    print("=" * 224)
    print("ROT-RH v404 — G7 LOCAL SINGULARITY / MULTIPLICITY / MONODROMY REDUCTION")
    print("=" * 224)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 224)

    v403 = load_json(args.v403_summary)
    v383 = load_json(args.v383_summary)
    v402 = load_json(args.v402_summary)

    v403_ok = bool(
        v403 is not None
        and v403.get("verdict")
        == "EXACT_G7_RIESZ_MELLIN_COLLISION_REDUCTION_PASS"
    )
    v383_ok = bool(
        v383 is not None
        and v383.get("verdict")
        == "EXACT_MELLIN_VOLTERRA_G7_REDUCTION_PASS"
    )
    v402_ok = bool(
        v402 is not None
        and v402.get("verdict")
        == "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
    )

    print("[1] Upstream")
    print("v403 reduction pass                      :", v403_ok)
    print("v383 fixed-point/Volterra pass           :", v383_ok)
    print("v402 regular recursive jet pass          :", v402_ok)

    print("\n[2] Exact local singularity identities")

    with tqdm(
        total=3,
        desc="local singularity identities",
        unit="identity",
    ) as bar:
        local = symbolic_local_checks()
        bar.update(1)

        mono = symbolic_monodromy_check()
        bar.update(1)

        growth = symbolic_collision_growth_checks()
        bar.update(1)

    print("principal-pole transport pass            :", local.get("pass"))
    print("Res X                                    :", local.get("res_X"))
    print("Res R^7 X                                :", local.get("res_R7X"))
    print("Res G7                                   :", local.get("res_G7"))
    print("simple-zero G7 principal residue         :", local.get("simple_zero_res_G7"))
    print("double-zero G7 principal residue         :", local.get("double_zero_res_G7"))
    print("logarithmic monodromy identity pass      :", mono.get("pass"))
    print("off-critical exponential factor pass     :", growth.get("pass"))
    print("off-critical magnitude factor            :", growth.get("exponential_magnitude"))

    algebra_pass = bool(
        local.get("pass")
        and mono.get("pass")
        and growth.get("pass")
    )

    print("\n[3] Multiplicity-aware theorem consequences")

    consequences = [
        (
            "PRINCIPAL_POLE_MAP",
            "At a zero of multiplicity m, one R multiplies the principal pole coefficient by m.",
        ),
        (
            "R7_PRINCIPAL_POLE",
            "Res_principal(R^7 X)=-m^8 because Res(X)=-m.",
        ),
        (
            "G7_PRINCIPAL_POLE",
            "Res_principal(G7)=m^8-m=m(m^7-1).",
        ),
        (
            "SIMPLE_ZERO",
            "For m=1 the G7 principal pole cancels exactly.",
        ),
        (
            "MULTIPLE_ZERO",
            "For m>1 a nonzero principal G7 pole survives; bounded simple-collision normalization cannot simply be assumed.",
        ),
        (
            "LOG_MONODROMY",
            "Even for m=1, a 1/t coefficient in the Volterra integrand creates log(t), hence nontrivial local monodromy.",
        ),
        (
            "OFF_CRITICAL",
            "If Re(rho)-1/2=delta>0, the Riesz collision kernel contains exp(L delta)=X^delta.",
        ),
    ]

    for key, value in consequences:
        print(f"{key:42s}: {value}")

    print("\n[4] Correction to the v403 target")

    corrections = [
        (
            "NOT_A_GENERIC_O1_BOUND",
            "The remaining head estimate cannot be proved by a naive absolute contour majorant without resolving zero singularities.",
        ),
        (
            "SIMPLE_COLLISION_SCOPE",
            "The L/2 normalization is the simple-zero local collision model; multiplicity must be handled explicitly.",
        ),
        (
            "FULL_COMBINATION_REQUIRED",
            "One must track the complete collision/residue/monodromy combination, not G7 in isolation if additional secular channels cancel local branch terms.",
        ),
        (
            "R7_WEIGHTED_CLOSURE_LIMIT",
            "v402 controls the coefficient-space recursive regular jet, but does not by itself erase analytic-continuation singularities of individual head/tail transforms.",
        ),
    ]

    for key, value in corrections:
        print(f"{key:42s}: {value}")

    print("\n[5] True remaining RH-strength theorem")

    obligations = [
        (
            "MULTIPLICITY_AWARE_COLLISION_FORMULA",
            "Derive the regularized local Fredholm/Riesz collision formula for a zero of arbitrary multiplicity m.",
        ),
        (
            "SIMPLE_ZERO_MONODROMY",
            "For m=1, compute the exact logarithmic monodromy coefficients of G7=(I-R^7)X through seven Volterra steps.",
        ),
        (
            "OFF_CRITICAL_DICHOTOMY",
            "Show that a surviving right-half off-critical singularity produces X^(beta-1/2) growth incompatible with the all-X v78/v392 bounds, OR prove exact cancellation forces a companion constraint.",
        ),
        (
            "CRITICAL_LINE_REMAINDER",
            "For beta=1/2, prove the collision-subtracted critical singularity system leaves only O_k(1) stiffness defect and O_k(1) tube oscillation.",
        ),
        (
            "NO_SIMPLICITY_ASSUMPTION",
            "Do not assume zero simplicity; either derive it or formulate the operator/Fredholm multiplicity correctly.",
        ),
    ]

    for key, value in obligations:
        print(f"{key:42s}: {value}")

    theorem_pass = bool(
        v403_ok
        and v383_ok
        and v402_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_G7_LOCAL_SINGULARITY_MULTIPLICITY_REDUCTION_PASS"
        if theorem_pass
        else
        "G7_LOCAL_SINGULARITY_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "DERIVE_MULTIPLICITY_AWARE_G7_MONODROMY_AND_OFF_CRITICAL_GROWTH_DICHOTOMY"
    )

    print("\n" + "=" * 224)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "RH-STRENGTH BOTTLENECK                  :",
        "OFF-CRITICAL SINGULARITY / MONODROMY CANCELLATION-OR-GROWTH DICHOTOMY",
    )
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT YET PROVED",
    )
    print("=" * 224)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
        },
        "upstream": {
            "v403_ok": v403_ok,
            "v383_ok": v383_ok,
            "v402_ok": v402_ok,
        },
        "exact_local_algebra": {
            "principal_pole": local,
            "monodromy": mono,
            "offcritical_growth": growth,
        },
        "consequences": {
            key: value for key, value in consequences
        },
        "corrections_to_v403": {
            key: value for key, value in corrections
        },
        "remaining_obligations": {
            key: value for key, value in obligations
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact local principal-pole/multiplicity/monodromy reduction. "
            "This identifies the remaining contour theorem as RH-strength. "
            "It does not prove the off-critical cancellation-or-growth dichotomy."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v404 — G7 local singularity theorem reduction

Let `rho` be a nontrivial zero of multiplicity `m`, `t=s-rho`.

The exact fixed-point transform is

`X(s)=-zeta'/zeta-(zeta-1)`

and

`G7=X-R^7 X`.

Locally,

`zeta'/zeta = m/t + O(1)`,
`X = -m/t + O(1)`.

For the v383 Volterra map

`R[A]=mu^-1 int_s^infty mu (zeta'/zeta) A`,

the principal pole coefficient is multiplied by `m`:

`a_-1 -> m a_-1`.

Therefore

`Res_principal(R^7 X)=-m^8`

and

`Res_principal(G7)=m^8-m=m(m^7-1)`.

Hence:
- simple zero `m=1`: principal G7 pole cancels;
- multiple zero `m>1`: it does not.

Even for `m=1`, the `1/t` coefficient in the Volterra integrand creates
`log t` terms, so the remaining local obstruction is monodromy/branch
structure.

For an off-critical zero with `delta=Re(rho)-1/2>0`, the collision-safe
Riesz kernel contains the factor `exp(L delta)=X^delta`.

Therefore the final head theorem is an RH-strength dichotomy:
either all such off-critical local singularities cancel in the full secular
combination, or they force growth incompatible with the desired all-X
collision-subtracted O(1) bounds.

A complete theorem must also be multiplicity-aware; the simple-collision
`L/2` normalization cannot be silently assumed for multiple zeros.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_G7_MULTIPLICITY_MONODROMY_DICHOTOMY_V1",
        "required_claims": {
            "arbitrary_m_collision_formula": "EXACT",
            "simple_zero_G7_monodromy_coefficients": "EXACT",
            "offcritical_survival_implies_growth": "RIGOROUS",
            "offcritical_cancellation_companion_constraint": "RIGOROUS_IF_CANCELLATION",
            "critical_line_collision_subtracted_O1": "RIGOROUS",
        },
        "forbidden_assumptions": [
            "RH",
            "all zeros simple",
            "known zero ordinates",
            "finite cutoff regression",
        ],
        "already_closed": {
            "regular_recursive_weighted_four_jet": "v402",
            "Riesz_Mellin_head_reduction": "v403",
            "summability_implication": "v392",
        },
    }

    cert_path.write_text(
        json.dumps(certificate, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
