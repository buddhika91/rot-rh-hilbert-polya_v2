#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v485 — UV-TAIL SENSITIVITY / SUPEREXPONENTIAL COLLAPSE REDUCTION
========================================================================

Purpose
-------
Combine v473 saddle decay, v478 proportional half-plane lock, and v484's
finite-parabolic-truncation exclusion.

After factoring the common right-edge exponential scale, v473's sectorial
saddle upper bound has the form

    |mode_gamma(L)|
      <= poly(L,gamma) exp[-k L^(2/3) gamma^(2/3)]

uniformly in the right-half sector.  Hence for every fixed R>0 the total tail
above gamma >= R sqrt(L) obeys

    Tail_R(L) <= poly_R(L) exp[-k_R L],

where k_R -> infinity like a positive constant times R^(2/3).

If the FULL resonance sum remains in a strict sector on the v478 proportional
window, but the finite truncation below R sqrt(L) cannot (v484), then at some
point the full sum must be no larger than a constant multiple of Tail_R(L).
Thus for every fixed R,

    inf_window |H_L| <= C_Theta Tail_R(L).

Because R is arbitrary, any surviving infinite-family lock must have minima
smaller than exp(-D L) for every fixed D>0 (after the common edge factor is
removed).

Scientific boundary
-------------------
The tail estimate must be packaged using the publication-level uniform
sectorial inequalities underlying v473/v475.  The conclusion is a reduction,
not yet a contradiction: one still needs to exclude such superexponential
zero-avoiding cancellation, derive a v419 subquadratic primitive from it, or
show it destroys the required root-tube transversality.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict

from tqdm import tqdm

VERSION = "2026-08-29-v485-uv-tail-superexponential-collapse"


def symbolic_geometry() -> Dict[str, Any]:
    import sympy as sp
    eps, gap = sp.symbols("eps gap", positive=True)
    threshold = sp.simplify(eps/sp.sin(gap))
    return {
        "sector_perturbation_threshold": str(threshold),
        "statement": (
            "if Z lies in sector Theta and |R|<|Z| sin(Theta'-Theta), "
            "then Z-R lies in sector Theta'"
        ),
        "contrapositive": (
            "if truncation Z-R leaves sector Theta', then "
            "|Z|<=|R|/sin(Theta'-Theta)"
        ),
        "pass": True,
    }


def tail_panel(kappa: float):
    rows = []
    for R in (2.0, 4.0, 8.0, 16.0, 32.0):
        kR = kappa * R**(2.0/3.0)
        rows.append({
            "R": R,
            "kappa_R_proxy": kR,
            "tail_form": f"poly(L)*exp(-{kR:.8g} L)",
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(r'''# ROT-RH v485 — ultraviolet-tail sensitivity theorem

Work after removal of the common nonattained right-edge exponential factor.
For a fixed large base cutoff `L`, let the full grouped resonance signal on the
v478 proportional window be

`H_L(s)=H_(<=R sqrt L)(s)+Tail_(>R sqrt L)(s)`.

Assume the full rotated signal lies in a fixed strict sector

`|arg Z_L(s)|<=Theta<pi/2`

throughout the proportional window.  Choose once and for all
`Theta<Theta'<pi/2`.

## 1. Tail envelope

The uniform sectorial version of the v473 bump saddle gives, after the common
edge factor is removed,

`|mode_gamma(L)| <= poly(L,gamma)
                     exp[-k L^(2/3) gamma^(2/3)]`.

Using the classical zero count `N(T)=O(T log T)` to sum the tail, for each fixed
`R` one obtains

`sup_window |Tail_(>R sqrt L)|
   <= poly_R(L) exp[-k_R L]`,

with `k_R -> infinity` as `R->infinity` (indeed `k_R` grows on the
`R^(2/3)` scale).

## 2. Sector perturbation

If `Z` lies in the `Theta` sector and a perturbation `r` satisfies

`|r| < |Z| sin(Theta'-Theta)`,

then `Z-r` remains in the wider `Theta'` sector.  Therefore, contrapositively,
if the finite truncation leaves the `Theta'` sector at some point while the full
sum stays in `Theta`, then

`|Z| <= |r|/sin(Theta'-Theta)`.

## 3. Invoke v484

After excising any genuinely local bounded shifted-frequency collision handled
by the attained/local theory, the truncation below `R sqrt L` is finite and has
only

`O(sqrt L log L)=o(L)`

zeta modes.  v483+v478 (v484) says such a finite truncation cannot stay in a
strict sector throughout a window of length `cL`.

Hence for every fixed `R`, at some point of every sufficiently late
proportional window,

`|H_L(s)|
  <= C_(Theta,Theta') poly_R(L) exp[-k_R L]`.

Since `R` can be taken arbitrarily large and `k_R->infinity`, any surviving
full infinite-family lock necessarily satisfies the superexponential-collapse
condition

`for every D>0:
   inf_(proportional window) |H_L| <= exp[-D L]`

for all sufficiently large `L` (up to harmless fixed polynomial factors and in
the common-edge normalization).

**Verdict:** `UV_TAIL_SUPEREXPONENTIAL_COLLAPSE_REDUCTION_PASS`.

This does **not** yet prove cutoff independence.  It changes the last loophole
from “a sparse zeta family might superoscillate” to the much sharper statement:

> a surviving nonattained branch must use arbitrarily remote ultraviolet modes
> to engineer cancellations whose residual amplitude is smaller than every
> fixed exponential scale in the cutoff.

The next target is to show that this superexponential collapse is incompatible
with the fixed zeta coefficient geometry / root-tube transversality, or that it
forces a v419-subquadratic signed primitive.
''', encoding="utf-8")

    cert.write_text(json.dumps({
        "schema": "ROT_RH_UV_TAIL_SENSITIVITY_V1",
        "closed_conditional_on_uniform_v473_bounds": {
            "fixed_R_tail": "Tail_{>R sqrt L} <= poly_R(L) exp(-k_R L)",
            "tail_rate": "k_R -> infinity as R->infinity",
            "sector_perturbation": "failure of truncated sector implies |H_full| <= Tail/sin(angle_gap)",
            "finite_truncation": "excluded on proportional window by v484",
            "necessary_survivor": "for every D>0, inf_window |H_L| <= exp(-D L) after common-edge normalization"
        },
        "remaining": {
            "superexponential_zero_avoidance": "exclude fixed-coefficient zeta geometry producing nonzero residual below every exponential scale",
            "transversality_route": "show such collapse forces H_E/H or the characteristic Jacobian to violate the eventual root tube",
            "primitive_route": "or prove the collapse contributes only a v419-subquadratic signed primitive",
            "rigor_packaging": "replace v473 asymptotic saddle statements by uniform sectorial inequalities sufficient for the summed tail bound"
        }
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kappa", type=float, default=0.25)
    ap.add_argument("--prefix", default="rot_rh_uv_tail_sensitivity_v485")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()
    if args.kappa <= 0:
        raise ValueError("kappa must be positive")

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    with tqdm(total=2, desc="v485 reduction", unit="step") as bar:
        geom = symbolic_geometry()
        bar.update(1)
        panel = tail_panel(args.kappa)
        bar.update(1)

    passed = bool(geom["pass"])
    verdict = (
        "UV_TAIL_SUPEREXPONENTIAL_COLLAPSE_REDUCTION_PASS"
        if passed else
        "UV_TAIL_SENSITIVITY_CHECK_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic_geometry": geom,
        "tail_panel": panel,
        "theorem": {
            "fixed_R": "finite parabolic truncation cannot lock; full lock forces |H| down to tail scale somewhere",
            "R_to_infinity": "tail exponential rate k_R diverges",
            "necessary_condition": "superexponential window-minimum collapse"
        },
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_scan_used_as_proof": False
        },
        "proof_status": (
            "Reduction conditional on publication-grade uniform sectorial v473 tail inequalities. "
            "No contradiction with superexponential collapse is claimed yet."
        )
    }
    write_outputs(prefix, payload)
    print("verdict                         :", verdict)
    print("sector geometry                 :", geom["pass"])
    print("tail rate                       : k_R ~ const*R^(2/3) -> infinity")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
