# ROT-RH v443 — uniform all-mode dyadic displacement theorem

## Setup

Let

`L_n = L_0 + n h`, with `h = log 2`,

and let `E_(k,n)` be the same arithmetic mode at cutoff `X_n=exp(L_n)`.

The finite audit used `6` dyadic pairs and
`320` modes, with no Xi, zeta, or known-zero input.

## Theorem U_STEP -> uniform moving displacement

Assume there is one constant `C_E < infinity`, independent of both `k` and `n`,
such that eventually

`|E_(k,n+1)-E_(k,n)| <= C_E/[L_n L_(n+1)]`.

Then

`1/[L_n L_(n+1)]
   = (1/h)[1/L_n - 1/L_(n+1)]`.

Therefore, for every `N`,

`|E_(k,N)-E_(k,0)|
 <= C_E sum_(n<N) 1/[L_n L_(n+1)]
 = (C_E/h)[1/L_0 - 1/L_N]
 <= C_E/(h L_0)`.

The bound is independent of `k`. Hence

`sup_(k,N)|E_(k,N)-E_(k,0)| <= C_E/(h L_0) < infinity`.

This is exactly the moving-cutoff theorem left open by v236/v238.

## v438 reduction to U_STEP

The exact v438 mean-value identity is

`E_(k,L+h)-E_(k,L)
 = -Delta_h F_L(E_(k,L))/F'_(L+h)(xi_(k,L))`.

Thus the two all-mode hypotheses

`sup_(k,L)|L Delta_h F_L(E_(k,L))| <= C_F < infinity`

and

`inf_(k,L) F'_(L+h)(xi_(k,L))/(L+h) >= c > 0`

imply

`|Delta E_(k,L)| <= (C_F/c)/[L(L+h)]`.

So U_STEP holds with

`C_E = C_F/c`.

This is a moving-characteristic theorem. It does not require a uniform
fixed-energy prime-prefix bound.

## Fixed-reference Archimedean term

v238 analytically establishes, at any one fixed finite reference cutoff `L_0`,

`D_0 := sup_k |E_(k,L_0)-A_k| < infinity`,

where `A_k` is the free Gamma/Archimedean level.

Combining with U_STEP,

`sup_(k,N)|E_(k,L_N)-A_k|
 <= D_0 + C_E/(h L_0) < infinity`.

This is the v235 uniform free-level displacement theorem.

## Trace-tail consequence

v232 gives eventually

`A_k >= 2k/log(k+e)`.

Let

`D = D_0 + C_E/(hL_0)`.

For sufficiently large `k`, `k/log(k+e) >= D`, so

`E_(k,L) >= k/log(k+e)` uniformly in cutoff.

Therefore

`E_(k,L)^(-2) <= [log(k+e)/k]^2`,

and the right side is summable. Hence

`sup_L sum_(k>N) E_(k,L)^(-2) -> 0`.

If, in addition, v438 is promoted to fixed-mode convergence for every fixed `k`,
then dominated convergence gives

`||K_L-K_infinity||_1 -> 0`,

for `K_L=H_L^(-2)`.

## Finite v443 audit

Development-only frozen constant:

`C_E_safe = 0.950537209520935`.

Holdout maximum of `L(L+h)|Delta E|`:

`0.726288831442373`.

Holdout pass:

`True`.

Conditional telescoping moving bound from the frozen finite constant:

`C_E_safe/(log(2)L_0) = 0.122475166073551`.

Maximum observed displacement from the reference cutoff:

`0.015682537572161`.

Observed reference free displacement maximum (diagnostic only):

`0.975143792285536`.

Numerical global displacement candidate:

`1.09761895835909`.

## Logical status

The algebraic implication

`U_STEP => uniform moving displacement => uniform free displacement => T_TAIL`

is proved.

What is **not** proved is the all-scale premise U_STEP itself.

The clean non-circular next theorem is therefore either:

1. prove U_STEP directly on the moving arithmetic root characteristics; or
2. prove the uniform all-mode v438 pair:
   `|L Delta_h F| <= C_F` and whole-segment `F'/L >= c>0`.

Endpoint `F'/L` values in the finite table are supporting diagnostics only and
must not be promoted to the whole-segment transversality theorem.

This is not an RH proof and does not establish the Xi Fredholm identity.
