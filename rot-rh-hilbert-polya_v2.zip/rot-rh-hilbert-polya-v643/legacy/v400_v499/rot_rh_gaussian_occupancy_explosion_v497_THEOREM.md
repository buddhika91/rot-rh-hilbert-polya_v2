# ROT-RH v497 — Gaussian off-critical exposed mode / local occupancy explosion

For every right-half nontrivial zero write

`rho_j=1/2+a_j+i gamma_j`, `a_j>0`.

The Gaussian residue has the large-`L` exponential factor

`exp[(a_j+i(gamma_j-E))^2 L^2/4]`.

Its real growth score is

`s_j(E)=a_j^2-(gamma_j-E)^2`.

Because every nontrivial zero satisfies `|a_j|<1/2`, while zero ordinates are
locally finite and tend to infinity,

`s_j(E)->-infinity`

uniformly in `E` on each compact interval as `|gamma_j|->infinity`.
Consequently the upper envelope

`S(E)=sup_j s_j(E)`

is locally attained by a finite set of zero modes.

If an off-critical zero exists, then at its own ordinate

`S(gamma_j)>=a_j^2>0`.

Hence `S>0` on an open interval.  For two modes,

`s_j(E)-s_k(E)`

is affine in `E`.  After identical `(a,gamma)` modes are combined into their
integer multiplicity, pairwise ties are isolated.  We may therefore choose a
compact subinterval `J=[E_-,E_+]` and one exposed mode `*` such that

`s_*(E)>=c>0`

and

`s_*(E)-sup_(j!=*)s_j(E)>=g>0`

throughout `J`.

The exact Gaussian transform / steepest-descent formula then gives uniformly
on `J`

`K_*(L,E)
 = [2 sqrt(pi)/(lambda_*(E)L)]`
`   exp[lambda_*(E)^2 L^2/4] [1+o(1)]`,

with

`lambda_*=a_*+i(gamma_*-E)`.

Thus

`|K_*| >= C_J L^-1 exp(cL^2/4)`

and its unwrapped phase obeys

`partial_E arg K_*
 =-a_*L^2/2+O_J(1)`.

The positive score gap `g` makes every other local saddle exponentially smaller
by `exp(-gL^2/4)`; the remote infinite family is summable using the same Gaussian
outer-sector/zero-count estimates as v494.  Static and Archimedean terms are
negligible compared with the displayed exponential amplitude.

Therefore on every sufficiently late `L`, successive positive and negative
antinodes of the exposed mode inside `J` force the **full secular count**
`F_L(E)` to attain values whose magnitude is at least

`C'_J L^-1 exp(cL^2/4)`.

By continuity, between one such negative and positive antinode the equation

`F_L(E)=k-1/2`

has a solution for every positive integer `k` up to

`M_L=floor(C''_J L^-1 exp(cL^2/4))`.

Since the canonical selected root for level `k-1/2` is the first later
crossing, it occurs no later than that solution.  Hence for the fixed endpoint
`E_*=E_+`,

`N_L(E_*)=#{k:E_k(L)<=E_*}`
`          >= M_L -> infinity`.

So a single off-critical zero forces **cutoff-dependent local spectral
multiplicity explosion** for the Gaussian regulator.

**Verdict:** `GAUSSIAN_OFFCRITICAL_LOCAL_OCCUPANCY_EXPLOSION_REDUCTION_PASS`.

A publication proof should state the uniform Gaussian saddle remainder and
remote-family summation as inequalities.  No numerical zeta values or known
zero ordinates are used.
