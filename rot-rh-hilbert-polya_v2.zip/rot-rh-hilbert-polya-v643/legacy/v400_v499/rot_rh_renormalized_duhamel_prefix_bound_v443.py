#!/usr/bin/env python3
"""
ROT-RH v443 — RENORMALIZED DUHAMEL PREFIX / FIXED-MODE CUTOFF CLOSURE AUDIT

Purpose
-------
v442 reduced the moving-branch beta equation to

    d/dL [ L exp(-Q_k(L)) beta_k(L) ]
        = exp(-Q_k(L)) S_k(L),

where
    L = log(cutoff),
    Q_k(L) = integral kappa_k(s)/s ds,
    S_k = L partial_L beta at fixed E, interpreted with the arithmetic
          jump measure.

Define
    Y_k(L) = L exp(-Q_k(L)) beta_k(L)
and
    I_k(L) = Y_k(L) - Y_k(L0).

A sufficient all-L theorem is

    sup_L |Q_k(L)| < infinity
    and
    |I_k(L)| <= C_k L

on each eventual ordered branch.

Then beta_k(L)=O_k(1), the primitive Pi_k(L)=O_k(L), and the v419
primitive-beta result gives an O_k(1/L) fixed-mode root tail.

This script does NOT claim to prove the all-L theorem.  It attacks the
correct quantity directly, freezes development envelopes prospectively,
checks untouched holdout shells, measures signed-vs-total-variation
cancellation, and emits the exact analytic certificate still required.

Firewall
--------
* no Xi values
* no zeta values
* no known zero ordinates
* no new root solves
* no larger cutoff
* no finite regression accepted as proof

Important notation
------------------
The beta/B in v424-v443 is the characteristic root-flow forcing.  It is
NOT the bounded Jacobi operator B_L used later in the Hilbert-Polya
operator construction.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(x=None, *args, **kwargs):
        return x if x is not None else _NullBar()

    class _NullBar:
        def update(self, n=1):
            pass
        def close(self):
            pass


VERSION = "443"
EXPECTED_V442 = "EXACT_LOG_BETA_DUHAMEL_REDUCTION_PASS_SOURCE_BOUND_OPEN"
EPS = 1.0e-300


def load_json(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return json.loads(p.read_text(encoding="utf-8"))


def finite(x: float) -> bool:
    return bool(np.isfinite(float(x)))


def safe_max_abs(a: np.ndarray) -> float:
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    return float(np.max(np.abs(a))) if len(a) else float("nan")


def safe_min(a: np.ndarray) -> float:
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    return float(np.min(a)) if len(a) else float("nan")


def require_columns(df: pd.DataFrame, cols: set[str], label: str) -> None:
    missing = sorted(cols - set(df.columns))
    if missing:
        raise KeyError(f"{label} missing columns: {missing}")


def shell_order(steps: pd.DataFrame) -> List[int]:
    tmp = (
        steps[["shell_index", "shell_anchor", "shell_endpoint"]]
        .drop_duplicates()
        .sort_values(["shell_anchor", "shell_endpoint", "shell_index"])
    )
    return tmp["shell_index"].astype(int).tolist()


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "ROT-RH v443 renormalized Duhamel-prefix / fixed-mode "
            "cutoff-closure audit"
        ),
    )

    ap.add_argument(
        "--v442-nodes",
        default="rot_rh_logbeta_source_stiffness_damping_v442_NODES.csv",
    )
    ap.add_argument(
        "--v442-steps",
        default="rot_rh_logbeta_source_stiffness_damping_v442_STEPS.csv.gz",
    )
    ap.add_argument(
        "--v442-shells",
        default="rot_rh_logbeta_source_stiffness_damping_v442_SHELL_SUMMARY.csv",
    )
    ap.add_argument(
        "--v442-summary",
        default="rot_rh_logbeta_source_stiffness_damping_v442_SUMMARY.json",
    )

    # Prospective gates.  Caps are frozen ONLY from development shells.
    ap.add_argument("--development-shells", type=int, default=1)
    ap.add_argument("--input-cap-safety", type=float, default=1.75)
    ap.add_argument("--q-cap-safety", type=float, default=1.50)
    ap.add_argument("--minimum-input-cap", type=float, default=1.0e-12)
    ap.add_argument("--minimum-q-cap", type=float, default=1.0e-12)
    ap.add_argument("--minimum-slope-over-L", type=float, default=1.0e-12)

    # Exact/reconstruction tolerances.
    ap.add_argument("--maximum-Y-reconstruction-relative", type=float, default=5.0e-11)
    ap.add_argument("--maximum-step-duhamel-relative", type=float, default=5.0e-11)
    ap.add_argument("--maximum-telescope-relative", type=float, default=5.0e-11)

    # Optional finite-diagnostic gate.  It is not part of the proof claim.
    ap.add_argument(
        "--maximum-holdout-cap-ratio",
        type=float,
        default=1.0,
        help="Require holdout quantity / frozen development cap <= this value.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_renormalized_duhamel_prefix_bound_v443",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.development_shells < 1:
        raise ValueError("--development-shells must be >= 1")
    if args.input_cap_safety <= 1.0:
        raise ValueError("--input-cap-safety must exceed 1")
    if args.q_cap_safety <= 1.0:
        raise ValueError("--q-cap-safety must exceed 1")
    if args.maximum_holdout_cap_ratio <= 0:
        raise ValueError("--maximum-holdout-cap-ratio must be positive")

    started = time.perf_counter()

    summary442 = load_json(args.v442_summary)
    upstream_verdict = str(summary442.get("verdict", ""))
    upstream_exact = bool(
        upstream_verdict == EXPECTED_V442
        or summary442.get("exact_beta_split", {}).get("pass", False)
    )

    nodes = pd.read_csv(args.v442_nodes)
    steps = pd.read_csv(args.v442_steps)
    shell442_path = Path(args.v442_shells)
    shell442 = pd.read_csv(shell442_path) if shell442_path.exists() else None

    require_columns(
        nodes,
        {
            "cutoff", "L", "root_index", "E", "Fp", "beta",
            "Q", "Y", "slope_over_L",
        },
        "v442 nodes",
    )
    require_columns(
        steps,
        {
            "set", "shell_index", "shell_anchor", "shell_endpoint",
            "root_index", "cutoff_start", "cutoff_end",
            "L_start", "L_end", "E_start", "E_end",
            "B_start", "B_moving_end",
            "Q_start", "Q_end", "Y_start", "Y_end",
            "renormalized_source_L_secant",
            "slope_over_L_start", "slope_over_L_end",
        },
        "v442 steps",
    )

    nodes["root_index"] = nodes["root_index"].astype(int)
    nodes["cutoff"] = nodes["cutoff"].astype(int)
    steps["root_index"] = steps["root_index"].astype(int)
    steps["shell_index"] = steps["shell_index"].astype(int)
    steps["cutoff_start"] = steps["cutoff_start"].astype(int)
    steps["cutoff_end"] = steps["cutoff_end"].astype(int)

    nodes = nodes.sort_values(["root_index", "L", "cutoff"]).reset_index(drop=True)
    steps = steps.sort_values(["root_index", "L_start", "cutoff_start"]).reset_index(drop=True)

    roots = sorted(nodes["root_index"].unique().tolist())
    shell_ids = shell_order(steps)
    if len(shell_ids) <= args.development_shells:
        raise RuntimeError(
            "Need at least one untouched holdout shell after development. "
            f"Found shell ids {shell_ids} with development-shells={args.development_shells}."
        )

    dev_shells = set(shell_ids[: args.development_shells])
    hold_shells = set(shell_ids[args.development_shells :])

    print("=" * 238)
    print("ROT-RH v443 — RENORMALIZED DUHAMEL PREFIX / FIXED-MODE CUTOFF CLOSURE AUDIT")
    print("=" * 238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff                             : NONE")
    print("finite holdout accepted as proof          : NO")
    print("v442 exact Duhamel reduction              :", upstream_exact, upstream_verdict)
    print("modes                                     :", len(roots))
    print("shells                                    :", shell_ids)
    print("development shells                        :", sorted(dev_shells))
    print("holdout shells                            :", sorted(hold_shells))
    print("=" * 238)

    # ------------------------------------------------------------------
    # 1. Exact Y reconstruction:
    #       Y = L exp(-Q) beta
    # ------------------------------------------------------------------
    Y_reconstructed = (
        nodes["L"].to_numpy(float)
        * np.exp(-nodes["Q"].to_numpy(float))
        * nodes["beta"].to_numpy(float)
    )
    Y_stored = nodes["Y"].to_numpy(float)
    Y_scale = np.maximum.reduce(
        [np.abs(Y_reconstructed), np.abs(Y_stored), np.full(len(nodes), 1.0e-14)]
    )
    Y_rel = np.abs(Y_reconstructed - Y_stored) / Y_scale
    max_Y_rel = float(np.max(Y_rel)) if len(Y_rel) else float("nan")
    Y_pass = bool(
        finite(max_Y_rel)
        and max_Y_rel <= args.maximum_Y_reconstruction_relative
    )

    # ------------------------------------------------------------------
    # 2. Exact finite-step Duhamel increment:
    #       Delta Y = source_secant * Delta L
    # ------------------------------------------------------------------
    dL = steps["L_end"].to_numpy(float) - steps["L_start"].to_numpy(float)
    dY = steps["Y_end"].to_numpy(float) - steps["Y_start"].to_numpy(float)
    dY_from_source = (
        steps["renormalized_source_L_secant"].to_numpy(float) * dL
    )
    dY_scale = np.maximum.reduce(
        [np.abs(dY), np.abs(dY_from_source), np.full(len(steps), 1.0e-14)]
    )
    dY_rel = np.abs(dY - dY_from_source) / dY_scale
    max_step_rel = float(np.max(dY_rel)) if len(dY_rel) else float("nan")
    step_pass = bool(
        finite(max_step_rel)
        and max_step_rel <= args.maximum_step_duhamel_relative
    )

    # ------------------------------------------------------------------
    # 3. Build exact global Duhamel-prefix observable.
    #
    #    I_k(L) = Y_k(L)-Y_k(L0)
    #    M_k(L) = |I_k(L)|/L
    #
    # The all-L theorem needed by v442 is sup_L M_k(L) < infinity.
    # ------------------------------------------------------------------
    point_rows: List[Dict[str, Any]] = []
    branch_rows: List[Dict[str, Any]] = []
    frozen_caps: Dict[int, Tuple[float, float]] = {}

    for rk in tqdm(roots, desc="v443 branches", unit="branch"):
        gn = nodes[nodes["root_index"] == rk].copy()
        gs = steps[steps["root_index"] == rk].copy()

        if gn.empty or gs.empty:
            continue

        gn = gn.sort_values(["L", "cutoff"]).reset_index(drop=True)
        gs = gs.sort_values(["L_start", "cutoff_start"]).reset_index(drop=True)

        L0 = float(gn.iloc[0]["L"])
        Y0 = float(gn.iloc[0]["Y"])
        B0 = float(gn.iloc[0]["beta"])
        Q0 = float(gn.iloc[0]["Q"])

        # Map each step endpoint to its exact global prefix.
        cumulative_dY = 0.0
        shell_start_Y: Dict[int, float] = {}
        shell_abs_variation: Dict[int, float] = {}
        shell_signed_dY: Dict[int, float] = {}

        local_points: List[Dict[str, Any]] = []

        for _, r in gs.iterrows():
            sh = int(r["shell_index"])
            if sh not in shell_start_Y:
                shell_start_Y[sh] = float(r["Y_start"])
                shell_abs_variation[sh] = 0.0
                shell_signed_dY[sh] = 0.0

            ddy = float(r["Y_end"] - r["Y_start"])
            cumulative_dY += ddy
            shell_abs_variation[sh] += abs(ddy)
            shell_signed_dY[sh] += ddy

            Lend = float(r["L_end"])
            Yend = float(r["Y_end"])
            Qend = float(r["Q_end"])
            Bend = float(r["B_moving_end"])
            global_input = Yend - Y0

            # Telescope check: cumulative source increments must equal Y-Y0.
            telescope_abs = abs(cumulative_dY - global_input)
            telescope_scale = max(abs(cumulative_dY), abs(global_input), 1.0e-14)
            telescope_rel = telescope_abs / telescope_scale

            global_input_over_L = abs(global_input) / max(Lend, EPS)
            local_shell_input = Yend - shell_start_Y[sh]
            local_shell_input_over_L = abs(local_shell_input) / max(Lend, EPS)

            # This is diagnostic only: it shows whether the signed weighted
            # source is being controlled by cancellation rather than TV.
            tv = shell_abs_variation[sh]
            cancellation_ratio = (
                abs(shell_signed_dY[sh]) / tv if tv > 0 else 0.0
            )

            local_points.append(
                {
                    "set": str(r["set"]),
                    "shell_index": sh,
                    "root_index": rk,
                    "cutoff_end": int(r["cutoff_end"]),
                    "L_end": Lend,
                    "E_end": float(r["E_end"]),
                    "B_end": Bend,
                    "Q_end": Qend,
                    "Y_end": Yend,
                    "Y0": Y0,
                    "global_weighted_input": global_input,
                    "abs_global_weighted_input_over_L": global_input_over_L,
                    "local_shell_weighted_input": local_shell_input,
                    "abs_local_shell_weighted_input_over_L": local_shell_input_over_L,
                    "shell_total_variation_so_far": tv,
                    "shell_signed_input_so_far": shell_signed_dY[sh],
                    "signed_over_total_variation": cancellation_ratio,
                    "telescope_relative_residual": telescope_rel,
                    "slope_over_L_end": float(r["slope_over_L_end"]),
                }
            )

        gp = pd.DataFrame(local_points)
        if gp.empty:
            continue

        dev = gp[gp["shell_index"].isin(dev_shells)]
        hold = gp[gp["shell_index"].isin(hold_shells)]
        if dev.empty or hold.empty:
            continue

        dev_input = float(dev["abs_global_weighted_input_over_L"].max())
        dev_Q = float(np.max(np.abs(dev["Q_end"].to_numpy(float))))

        input_cap = max(
            args.minimum_input_cap,
            args.input_cap_safety * dev_input,
        )
        q_cap = max(
            args.minimum_q_cap,
            args.q_cap_safety * dev_Q,
        )
        frozen_caps[rk] = (input_cap, q_cap)

        hold_input = float(hold["abs_global_weighted_input_over_L"].max())
        hold_Q = float(np.max(np.abs(hold["Q_end"].to_numpy(float))))
        hold_input_ratio = hold_input / max(input_cap, EPS)
        hold_q_ratio = hold_Q / max(q_cap, EPS)

        input_hold_pass = bool(
            hold_input_ratio <= args.maximum_holdout_cap_ratio
        )
        q_hold_pass = bool(
            hold_q_ratio <= args.maximum_holdout_cap_ratio
        )

        min_slope = float(
            min(
                gn["slope_over_L"].min(),
                gs["slope_over_L_start"].min(),
                gs["slope_over_L_end"].min(),
            )
        )
        nofold_pass = bool(min_slope >= args.minimum_slope_over_L)

        max_tel_rel = float(gp["telescope_relative_residual"].max())
        telescope_pass = bool(
            max_tel_rel <= args.maximum_telescope_relative
        )

        # If the frozen caps were valid for all future L, v442 gives:
        #
        # |beta(L)| <= exp(q_cap) * [ |Y0|/L + input_cap ]
        #          <= exp(q_cap) * [ |Y0|/L0 + input_cap ] = beta_star.
        #
        # Then |E(infty)-E(L)| <= beta_star / L.
        beta_star = math.exp(q_cap) * (
            abs(Y0) / max(L0, EPS) + input_cap
        )

        Lmax = float(gn["L"].max())
        current_tail_envelope = beta_star / max(Lmax, EPS)

        # Actual latest finite increment, diagnostic only.
        Evals = gn["E"].to_numpy(float)
        latest_increment = (
            abs(float(Evals[-1] - Evals[-2]))
            if len(Evals) >= 2
            else float("nan")
        )

        branch_pass = bool(
            input_hold_pass and q_hold_pass and nofold_pass and telescope_pass
        )

        gp["frozen_input_cap"] = input_cap
        gp["frozen_Q_cap"] = q_cap
        gp["input_cap_ratio"] = (
            gp["abs_global_weighted_input_over_L"] / max(input_cap, EPS)
        )
        gp["Q_cap_ratio"] = (
            np.abs(gp["Q_end"].to_numpy(float)) / max(q_cap, EPS)
        )
        gp["branch_holdout_pass"] = branch_pass
        point_rows.extend(gp.to_dict("records"))

        branch_rows.append(
            {
                "root_index": rk,
                "L0": L0,
                "Y0": Y0,
                "B0": B0,
                "Q0": Q0,
                "development_max_abs_input_over_L": dev_input,
                "frozen_input_cap": input_cap,
                "holdout_max_abs_input_over_L": hold_input,
                "holdout_input_cap_ratio": hold_input_ratio,
                "input_holdout_pass": input_hold_pass,
                "development_max_abs_Q": dev_Q,
                "frozen_Q_cap": q_cap,
                "holdout_max_abs_Q": hold_Q,
                "holdout_Q_cap_ratio": hold_q_ratio,
                "Q_holdout_pass": q_hold_pass,
                "minimum_slope_over_L": min_slope,
                "nofold_pass": nofold_pass,
                "maximum_telescope_relative_residual": max_tel_rel,
                "telescope_pass": telescope_pass,
                "conditional_beta_star": beta_star,
                "current_Lmax": Lmax,
                "conditional_tail_envelope_at_Lmax": current_tail_envelope,
                "latest_observed_E_increment": latest_increment,
                "branch_holdout_pass": branch_pass,
            }
        )

    points = pd.DataFrame(point_rows)
    branches = pd.DataFrame(branch_rows)
    if points.empty or branches.empty:
        raise RuntimeError("No branch/prefix rows were produced")

    # ------------------------------------------------------------------
    # 4. Shell summary: signed source vs total variation.
    # ------------------------------------------------------------------
    shell_rows: List[Dict[str, Any]] = []
    grouped = points.groupby(["set", "shell_index"], sort=True)
    for (setname, sh), g in grouped:
        shell_rows.append(
            {
                "set": str(setname),
                "shell_index": int(sh),
                "roots": int(g["root_index"].nunique()),
                "max_abs_global_input_over_L": float(
                    g["abs_global_weighted_input_over_L"].max()
                ),
                "max_input_cap_ratio": float(g["input_cap_ratio"].max()),
                "max_abs_Q": float(np.max(np.abs(g["Q_end"].to_numpy(float)))),
                "max_Q_cap_ratio": float(g["Q_cap_ratio"].max()),
                "min_slope_over_L": float(g["slope_over_L_end"].min()),
                "median_signed_over_total_variation": float(
                    g["signed_over_total_variation"].median()
                ),
                "max_signed_over_total_variation": float(
                    g["signed_over_total_variation"].max()
                ),
                "max_telescope_relative_residual": float(
                    g["telescope_relative_residual"].max()
                ),
            }
        )
    shell_summary = pd.DataFrame(shell_rows).sort_values("shell_index")

    # ------------------------------------------------------------------
    # 5. Global gates.
    # ------------------------------------------------------------------
    max_tel = float(points["telescope_relative_residual"].max())
    telescope_global_pass = bool(
        max_tel <= args.maximum_telescope_relative
    )
    all_branch_hold = bool(branches["branch_holdout_pass"].all())
    all_nofold = bool(branches["nofold_pass"].all())

    hold_points = points[points["shell_index"].isin(hold_shells)]
    max_hold_input_ratio = float(hold_points["input_cap_ratio"].max())
    max_hold_q_ratio = float(hold_points["Q_cap_ratio"].max())

    finite_prefix_pass = bool(
        upstream_exact
        and Y_pass
        and step_pass
        and telescope_global_pass
        and all_branch_hold
        and all_nofold
    )

    verdict = (
        "FINITE_RENORMALIZED_DUHAMEL_PREFIX_BOUND_PASS_ALL_L_ANALYTIC_BOUND_OPEN"
        if finite_prefix_pass
        else
        "RENORMALIZED_DUHAMEL_PREFIX_BOUND_FAIL_OR_INCOMPLETE"
    )

    print("\n[1] Exact reconstruction")
    print("max Y=L exp(-Q) beta relative residual    :", f"{max_Y_rel:.12e}")
    print("Y reconstruction pass                     :", Y_pass)
    print("max finite-step Duhamel relative residual :", f"{max_step_rel:.12e}")
    print("finite-step Duhamel pass                  :", step_pass)
    print("max global telescope relative residual    :", f"{max_tel:.12e}")
    print("global telescope pass                     :", telescope_global_pass)

    print("\n[2] Prospective weighted-input holdout")
    print("all branch input/Q holdouts pass          :", all_branch_hold)
    print("all branch no-fold checks pass            :", all_nofold)
    print("maximum holdout input-cap ratio           :", f"{max_hold_input_ratio:.12e}")
    print("maximum holdout Q-cap ratio               :", f"{max_hold_q_ratio:.12e}")

    display_cols = [
        "root_index",
        "development_max_abs_input_over_L",
        "frozen_input_cap",
        "holdout_max_abs_input_over_L",
        "holdout_input_cap_ratio",
        "development_max_abs_Q",
        "frozen_Q_cap",
        "holdout_max_abs_Q",
        "holdout_Q_cap_ratio",
        "minimum_slope_over_L",
        "conditional_beta_star",
        "conditional_tail_envelope_at_Lmax",
        "branch_holdout_pass",
    ]
    print("\nBranch summary:")
    print(
        branches[display_cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    print("\nShell summary:")
    print(
        shell_summary.to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    next_theorem = (
        "PROVE_ALL_L_WEIGHTED_DUHAMEL_PREFIX_BOUND_AND_SIGNED_RG_BOUND_"
        "ON_EACH_EVENTUAL_ORDERED_BRANCH"
    )

    print("\n" + "=" * 238)
    print("VERDICT                                   :", verdict)
    print("EXACT DUHAMEL PREFIX IDENTITY             :", Y_pass and step_pass and telescope_global_pass)
    print("FINITE PROSPECTIVE PREFIX BOUND           :", finite_prefix_pass)
    print("ALL-L |I_k(L)| <= C_k L                   : NOT PROVED")
    print("ALL-L |Q_k(L)| <= Q_k*                    : NOT PROVED")
    print("FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED")
    print("JACOBI STRONG-RESOLVENT LIMIT             : NOT YET PROVED")
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 238)

    # ------------------------------------------------------------------
    # Outputs.
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)
    points_out = Path(str(prefix) + "_POINTS.csv.gz")
    branches_out = Path(str(prefix) + "_BRANCH_SUMMARY.csv")
    shells_out = Path(str(prefix) + "_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix) + "_SUMMARY.json")
    theorem_out = Path(str(prefix) + "_THEOREM.md")
    cert_out = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    points.to_csv(points_out, index=False, compression="gzip")
    branches.to_csv(branches_out, index=False)
    shell_summary.to_csv(shells_out, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_numeric_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff": False,
            "finite_holdout_accepted_as_proof": False,
        },
        "upstream": {
            "v442_verdict": upstream_verdict,
            "v442_exact_reduction_available": upstream_exact,
        },
        "exact_reconstruction": {
            "maximum_Y_reconstruction_relative": max_Y_rel,
            "Y_pass": Y_pass,
            "maximum_step_duhamel_relative": max_step_rel,
            "step_duhamel_pass": step_pass,
            "maximum_telescope_relative": max_tel,
            "telescope_pass": telescope_global_pass,
        },
        "prospective_design": {
            "development_shells": sorted(dev_shells),
            "holdout_shells": sorted(hold_shells),
            "input_cap_safety": args.input_cap_safety,
            "q_cap_safety": args.q_cap_safety,
            "maximum_holdout_cap_ratio": args.maximum_holdout_cap_ratio,
        },
        "finite_diagnostics": {
            "modes": len(branches),
            "all_branch_holdout_pass": all_branch_hold,
            "all_nofold_pass": all_nofold,
            "maximum_holdout_input_cap_ratio": max_hold_input_ratio,
            "maximum_holdout_Q_cap_ratio": max_hold_q_ratio,
            "maximum_conditional_beta_star": float(
                branches["conditional_beta_star"].max()
            ),
            "maximum_conditional_tail_envelope_at_current_Lmax": float(
                branches["conditional_tail_envelope_at_Lmax"].max()
            ),
            "proof_status": "FINITE_PROSPECTIVE_EVIDENCE_ONLY",
        },
        "verdict": verdict,
        "weighted_duhamel_all_L_bound_proved": False,
        "signed_RG_all_L_bound_proved": False,
        "fixed_mode_cutoff_independence_proved": False,
        "jacobi_strong_resolvent_limit_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.perf_counter() - started,
    }
    summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    theorem_out.write_text(
        r"""# ROT-RH v443 — renormalized Duhamel-prefix cutoff closure

Along each ordered moving characteristic, v442 gives

`d/dL [L exp(-Q_k(L)) beta_k(L)] = exp(-Q_k(L)) S_k(L)`.

Define

`Y_k(L) = L exp(-Q_k(L)) beta_k(L)`

and

`I_k(L) = Y_k(L)-Y_k(L0)`.

Then

`beta_k(L) = exp(Q_k(L))/L [Y_k(L0)+I_k(L)]`.

Therefore the two all-`L` estimates

`|Q_k(L)| <= Q_k^*`

and

`|I_k(L)| <= C_k L`

imply

`|beta_k(L)| <= exp(Q_k^*) (|Y_k(L0)|/L0 + C_k) =: B_k^*`.

The root-flow equation is

`E_k'(L)=beta_k(L)/L^2`.

Hence

`|E_k(infinity)-E_k(L)| <= B_k^*/L`.

Thus the fixed spectral mode is cutoff-independent with an `O_k(1/L)`
tail. Combined with the v419 primitive-beta implication, eventual branch
persistence, and v425 no-fold, this is the direct route to fixed-mode
cutoff independence.

v443 tests the exact finite Duhamel telescope and prospectively freezes
development envelopes for `|I_k|/L` and `|Q_k|`, then applies them without
refitting to untouched holdout shells.

A finite pass is **not** the all-`L` proof. The remaining theorem is to
derive the two displayed bounds analytically from the arithmetic jump
source and signed RG law on every eventual ordered branch.

After that theorem is closed, the next operator-level step is to use the
cutoff-independent spectral/moment data to prove convergence of the
Jacobi coefficients and then strong-resolvent convergence of the
self-adjoint Jacobi operators.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_RENORMALIZED_DUHAMEL_PREFIX_CERTIFICATE_V1",
        "finite_exact_identity_pass": bool(
            Y_pass and step_pass and telescope_global_pass
        ),
        "finite_prospective_holdout_pass": finite_prefix_pass,
        "required_all_L_claims": {
            "weighted_duhamel_prefix": {
                "proved": False,
                "statement": (
                    "For every fixed eventual ordered branch k, "
                    "|Y_k(L)-Y_k(L0)| <= C_k L for all sufficiently large L, "
                    "with Y_k=L exp(-Q_k) beta_k."
                ),
            },
            "signed_RG_primitive": {
                "proved": False,
                "statement": (
                    "For every fixed eventual ordered branch k, "
                    "|Q_k(L)| <= Q_k^* for all sufficiently large L."
                ),
            },
            "branch_persistence_and_nofold": {
                "proved": False,
                "statement": (
                    "The ordered branch persists eventually and F'_L(E_k(L))/L "
                    "stays uniformly positive."
                ),
            },
        },
        "consequence_if_proved": (
            "beta_k=O_k(1) => Pi_k=O_k(L) => "
            "|E_k(infinity)-E_k(L)|=O_k(1/L) => fixed-mode cutoff independence"
        ),
        "operator_upgrade_after_fixed_modes": (
            "derive cutoff-independent moment/Jacobi coefficients, prove "
            "coefficient convergence on a common dense core, then establish "
            "strong-resolvent convergence of the self-adjoint Jacobi operators"
        ),
        "forbidden_shortcuts": [
            "uniform fixed-E Gate A",
            "RH",
            "known zero ordinates",
            "Xi fitting",
            "square-root PNT error",
            "finite regression as proof",
            "finite holdout cap as proof",
        ],
    }
    cert_out.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("Files written:")
    for p in [
        points_out, branches_out, shells_out,
        summary_out, theorem_out, cert_out,
    ]:
        print(" ", p)

    if args.strict and not finite_prefix_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
