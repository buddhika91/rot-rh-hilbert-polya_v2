# ROT-RH v477 — superoscillatory countermodel / arithmetic-structure barrier

Define

`F_N(t)
 =e^(iM_N t)[cos(t/N)-iM_N sin(t/N)]^N`.

Its frequencies are exactly

`gamma_(N,k)=M_N+(2k-N)/N`,

so the full support lies in

`[M_N-1,M_N+1]`.

If `M_N->infinity`, every frequency escapes to `+infinity`.

For `M_N>1`, the coefficient `l1` mass is exactly

`W0_N=M_N^N`.

Choose

`M_N=N^alpha`, `0<alpha<1/2`.

Uniformly on each fixed `|t|<=h`,

`F_N(t)->1`.

Thus the phase tends uniformly to zero while the actual amplitude tends to one.

But

`|F_N|/W0_N ~ M_N^(-N)->0`.

Hence an escaping positive-frequency family can exhibit perfect-looking
fixed-window phase lock by superoscillatory cancellation, provided its
normalized coefficient coherence collapses.

**Verdict:** EXACT_SUPEROSCILLATORY_GENERIC_HARMONIC_NO_GO_PASS

Therefore v476's final coherence-collapse sector cannot be eliminated using
only generic spectral escape, positivity of ordinates, window freezing, or
Bohr typicality.  The next proof must use actual arithmetic residue constraints
or the operator/Fredholm structure.
