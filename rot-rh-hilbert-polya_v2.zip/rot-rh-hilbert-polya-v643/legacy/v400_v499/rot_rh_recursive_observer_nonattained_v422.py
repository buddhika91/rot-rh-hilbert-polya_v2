#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v422 — RECURSIVE-OBSERVER NONATTAINED LOCK / FIXED-MODE CUTOFF STRESS TEST
=================================================================================

Purpose
-------
Test the ROT-inspired mechanism proposed after v421 for the only remaining
fixed-mode cutoff-removal sector: a genuinely NONATTAINED / forever-switching
rightmost Riesz resonance family.

This file is deliberately a TEST / FALSIFICATION ENGINE, not a proof.

It has two independent halves.

A. ZERO-FREE ARITHMETIC ROOT-FLOW TEST
-------------------------------------
Using the actual prime/Riesz phase implementation from the v71 module and roots
already frozen at arithmetic anchors, integrate the exact cutoff-flow ODE

    dE_k/dL = B_k(L)/L^2,
    B_k(L)  = C0(L,E_k(L)) / F'_L(E_k(L)),
    L       = log X.

No future root solve is used.  The script checks

  * no-fold / transversality along the transported branch,
  * signed beta and its primitive,
  * dyadic O(L^-2) displacement scaling,
  * blind closure against the next frozen anchor when available.

B. SYNTHETIC NONATTAINED RIESZ ADVERSARY
----------------------------------------
Construct abstract rightmost Riesz families of the exact v421 form

    H(L,E) = sum_j m_j a_j(E)^(-2)
                   exp(-eps_j L) exp(i gamma_j L),

where

    a_j(E) = delta_j + i(gamma_j-E),
    delta_j = delta_* - eps_j,
    eps_j > 0, eps_j -> 0,
    gamma_j -> infinity.

Thus the supremal real part delta_* is NOT attained and the active support can
migrate to arbitrarily large frequency.

Track a fixed phase label through the exact v411 characteristic ODE

    E'(L) = - Lcal/Tcal,
    Lcal  = E + Im(H_L/H),
    Tcal  = L + Im(H_E/H).

Measure

  * escaping Bohr mean frequency mu=S1/S0,
  * Fisher/projective spread sigma,
  * no-fold loss or compact-tube escape,
  * dyadic root displacement,
  * a hierarchy of projected/coherent frequency-moment cancellations.

The adversary is successful against the proposed mechanism if it produces a
persistent bounded no-fold branch whose velocity is non-integrable and whose
dyadic displacement fails to become summable.

Scientific firewall
-------------------
NO Xi evaluations.
NO zeta numerical values.
NO known Riemann-zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite numerical PASS is accepted as proof.

The synthetic resonance families are NOT claimed to be actual zeta-zero data.
They are adversarial structural tests of the nonattained loophole.

Version: 422
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 422
EPS = 1.0e-300
LOG2 = math.log(2.0)


# -----------------------------------------------------------------------------
# Generic helpers
# -----------------------------------------------------------------------------

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def finite(x) -> bool:
    try:
        return bool(np.isfinite(x))
    except Exception:
        return False


def energy_col(df: pd.DataFrame) -> str:
    for c in ("energy", "E", "root", "root_energy"):
        if c in df.columns:
            return c
    raise KeyError("No energy column found in roots CSV.")


def index_col(df: pd.DataFrame) -> str:
    for c in ("root_index", "mode_index", "k", "index"):
        if c in df.columns:
            return c
    raise KeyError("No root-index column found in roots CSV.")


def safe_power_fit(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """Fit y ~ C x^s in log-log coordinates. Returns (slope, r2)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    mask = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 1e-18)
    if np.count_nonzero(mask) < 5:
        return float("nan"), float("nan")
    lx = np.log(x[mask])
    ly = np.log(y[mask])
    A = np.column_stack([np.ones_like(lx), lx])
    coef, *_ = np.linalg.lstsq(A, ly, rcond=None)
    pred = A @ coef
    ss_res = float(np.sum((ly-pred)**2))
    ss_tot = float(np.sum((ly-np.mean(ly))**2))
    r2 = 1.0 - ss_res/max(ss_tot, 1e-30)
    return float(coef[1]), float(r2)


def interp_at(x: np.ndarray, y: np.ndarray, q: float) -> float:
    if q < x[0] or q > x[-1]:
        return float("nan")
    return float(np.interp(q, x, y))


# -----------------------------------------------------------------------------
# Upstream theorem lineage
# -----------------------------------------------------------------------------

EXPECTED_UPSTREAM = {
    "v408": "EXACT_NONATTAINED_SUPPORT_MIGRATION_ZERO_FLUX_NOGO_PASS",
    "v409": "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS",
    "v410": "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS",
    "v411": "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS",
    "v419": "EXACT_PRIMITIVE_BETA_NONPERTURBATIVE_CUTOFF_REDUCTION_PASS",
    "v420": "EXACT_ATTAINED_NOFOLD_RG_CHARACTERISTIC_COMPLETION_PASS",
    "v421": "EXACT_RIESZ_ATTAINED_CLUSTER_REGULATOR_REPAIR_PASS",
}


def check_upstream(args) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    for key, expected in EXPECTED_UPSTREAM.items():
        path = getattr(args, f"{key}_summary")
        obj = load_json(path)
        verdict = None if obj is None else obj.get("verdict")
        out[key] = {
            "path": path,
            "available": obj is not None,
            "verdict": verdict,
            "expected": expected,
            "pass": bool(verdict == expected),
        }
    return out


# -----------------------------------------------------------------------------
# Exact v414/v418 arithmetic objects
# -----------------------------------------------------------------------------

def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    """
    integral_2^(e^L) t^-1/2 sin(E log t) dt
      = Im[(e^(aL)-e^(a log2))/a], a=1/2+iE.
    """
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    lo = math.log(2.0)
    z = (np.exp(a*L)-np.exp(a*lo))/a
    return np.imag(z)


@dataclass
class ArithmeticEval:
    cutoff: int
    L: float
    E: np.ndarray
    C0: np.ndarray
    Fp: np.ndarray
    beta: np.ndarray
    terms: int


def arithmetic_eval(base, primes: np.ndarray, cutoff: int, energies: np.ndarray) -> ArithmeticEval:
    """Evaluate C0, actual v71 phase slope F', and beta=C0/F'."""
    cutoff = int(cutoff)
    E = np.atleast_1d(np.asarray(energies, float))
    logs, riesz_weights, exponents = base.prime_power_riesz_terms(primes, cutoff)

    m = np.asarray(exponents, float)
    logs = np.asarray(logs, float)
    lam = logs/m
    w0 = lam*np.exp(-0.5*logs)

    prime0 = base.trig_sum(E, logs, w0, "sin")
    L = math.log(float(cutoff))
    C0 = np.asarray(prime0, float)-smooth0(E, L)

    Fp = np.asarray(
        base.phase_prime_grid(E, cutoff, logs, riesz_weights),
        float,
    )

    beta = np.full_like(C0, np.nan, dtype=float)
    good = np.isfinite(Fp) & (np.abs(Fp) > 1e-300)
    beta[good] = C0[good]/Fp[good]

    return ArithmeticEval(
        cutoff=cutoff,
        L=L,
        E=E.copy(),
        C0=C0,
        Fp=Fp,
        beta=beta,
        terms=int(len(logs)),
    )


def load_roots_by_cutoff(path: str, max_modes: int) -> Tuple[pd.DataFrame, Dict[int, np.ndarray]]:
    rdf = pd.read_csv(path)
    if "cutoff" not in rdf.columns:
        raise KeyError("roots CSV requires a 'cutoff' column")
    ec = energy_col(rdf)
    kc = index_col(rdf)
    roots: Dict[int, np.ndarray] = {}
    for cutoff, g in rdf.groupby(rdf["cutoff"].astype(int)):
        e = g.sort_values(kc)[ec].to_numpy(float)
        if max_modes > 0:
            e = e[:max_modes]
        roots[int(cutoff)] = e
    return rdf, roots


def arithmetic_shell_track(
    *,
    base,
    primes: np.ndarray,
    roots: Dict[int, np.ndarray],
    anchor: int,
    steps_per_doubling: int,
    minimum_slope_ratio: float,
    progress: tqdm,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if anchor not in roots:
        raise ValueError(f"Arithmetic anchor {anchor:,} not found in roots CSV")

    E = roots[anchor].copy()
    nmode = len(E)
    L0 = math.log(float(anchor))
    L1 = math.log(float(2*anchor))
    Lgrid = np.linspace(L0, L1, steps_per_doubling+1)

    pi_beta = np.zeros(nmode, dtype=float)
    min_slope_ratio = np.full(nmode, np.inf, dtype=float)
    max_abs_beta = np.zeros(nmode, dtype=float)
    max_abs_scaled_velocity = np.zeros(nmode, dtype=float)
    nofold = np.ones(nmode, dtype=bool)

    rows: List[dict] = []
    cur = arithmetic_eval(base, primes, anchor, E)

    def record(ev: ArithmeticEval, stage: str):
        slope_ratio = ev.Fp/max(ev.L, 1e-30)
        for j in range(nmode):
            rows.append({
                "anchor": int(anchor),
                "stage": stage,
                "cutoff": int(ev.cutoff),
                "L": float(ev.L),
                "root_index": int(j+1),
                "E": float(ev.E[j]),
                "C0": float(ev.C0[j]),
                "Fp": float(ev.Fp[j]),
                "slope_over_L": float(slope_ratio[j]),
                "beta": float(ev.beta[j]),
                "primitive_beta": float(pi_beta[j]),
                "terms": int(ev.terms),
            })

    record(cur, "start")

    for i in range(steps_per_doubling):
        La = float(Lgrid[i])
        Lb = float(Lgrid[i+1])
        h = Lb-La
        Lm = 0.5*(La+Lb)

        # Midpoint RK2 on the exact v418 root-flow ODE E'=beta/L^2.
        vcur = cur.beta/(La*La)
        Emid = E + 0.5*h*vcur
        Xmid = max(anchor, int(round(math.exp(Lm))))
        mid = arithmetic_eval(base, primes, Xmid, Emid)
        vmid = mid.beta/(Lm*Lm)
        Enew = E + h*vmid

        Xnew = int(2*anchor) if i == steps_per_doubling-1 else int(round(math.exp(Lb)))
        end = arithmetic_eval(base, primes, Xnew, Enew)

        pi_beta += h*mid.beta

        for ev in (cur, mid, end):
            sr = ev.Fp/max(ev.L, 1e-30)
            min_slope_ratio = np.minimum(min_slope_ratio, sr)
            max_abs_beta = np.maximum(max_abs_beta, np.abs(ev.beta))
            nofold &= np.isfinite(ev.Fp) & (ev.Fp > minimum_slope_ratio*ev.L)

        step_scaled = np.abs(Enew-E)*(Lm*Lm)/max(h, 1e-30)
        max_abs_scaled_velocity = np.maximum(max_abs_scaled_velocity, step_scaled)

        E = Enew
        cur = end
        record(cur, "flow")
        progress.update(1)

    endpoint = E.copy()
    blind = roots.get(2*anchor)
    blind_error = np.full(nmode, np.nan)
    if blind is not None and len(blind) >= nmode:
        blind_error = endpoint-blind[:nmode]

    shell_rows: List[dict] = []
    startE = roots[anchor][:nmode]
    for j in range(nmode):
        dE = endpoint[j]-startE[j]
        shell_rows.append({
            "anchor": int(anchor),
            "endpoint_cutoff": int(2*anchor),
            "root_index": int(j+1),
            "E_start": float(startE[j]),
            "E_endpoint_flow": float(endpoint[j]),
            "dyadic_displacement": float(dE),
            "scaled_dyadic_displacement_L2": float(abs(dE)*L0*L0/LOG2),
            "primitive_beta_shell": float(pi_beta[j]),
            "abs_primitive_beta_over_L": float(abs(pi_beta[j])/L0),
            "max_abs_beta": float(max_abs_beta[j]),
            "max_abs_scaled_velocity": float(max_abs_scaled_velocity[j]),
            "min_slope_over_L": float(min_slope_ratio[j]),
            "nofold": bool(nofold[j]),
            "blind_endpoint_available": bool(blind is not None and len(blind) >= nmode),
            "blind_endpoint_error": float(blind_error[j]),
            "abs_blind_endpoint_error": float(abs(blind_error[j])) if np.isfinite(blind_error[j]) else float("nan"),
        })

    return pd.DataFrame(rows), pd.DataFrame(shell_rows)


# -----------------------------------------------------------------------------
# Synthetic nonattained adversary
# -----------------------------------------------------------------------------

@dataclass
class SyntheticFamily:
    eps: np.ndarray
    delta: np.ndarray
    gamma: np.ndarray
    multiplicity: np.ndarray
    label: str


def make_synthetic_family(
    n: int,
    ensemble: int,
    delta_star: float,
    eps_scale: float,
    gamma0: float,
    gamma_scale: float,
) -> SyntheticFamily:
    j = np.arange(1, n+1, dtype=float)

    # Cycle through several nonattained approach rates.
    powers = (0.55, 0.8, 1.0, 1.25, 1.6, 2.0)
    p = powers[ensemble % len(powers)]
    shift = 2.0 + 0.75*(ensemble % 5)
    eps = eps_scale/(j+shift)**p

    # Strictly increasing ordinate ladder with slowly shrinking spacing,
    # qualitatively mimicking an increasing spectral density without importing
    # any real zeta-zero ordinate.
    q = np.arange(1, n+1, dtype=float)
    spacing = gamma_scale*(2.0*math.pi)/np.log(q+20.0+3.0*(ensemble % 3))
    gamma = gamma0 + np.cumsum(spacing)

    # Positive integer multiplicities only.  Most ensembles are simple; a few
    # contain deterministic multiplicity-2/3 events to stress multiplicity safety.
    multiplicity = np.ones(n, dtype=float)
    if ensemble % 4 == 1:
        multiplicity[::17] = 2.0
    elif ensemble % 4 == 2:
        multiplicity[::23] = 3.0
    elif ensemble % 4 == 3:
        multiplicity[::19] = 2.0
        multiplicity[::43] = 3.0

    delta = delta_star-eps
    label = f"p{p:.2f}_shift{shift:.2f}_gscale{gamma_scale:.3f}_ens{ensemble:02d}"
    return SyntheticFamily(eps=eps, delta=delta, gamma=gamma, multiplicity=multiplicity, label=label)


@dataclass
class SyntheticEval:
    E: float
    L: float
    H: complex
    W0: float
    psi_L: float
    psi_E: float
    Lcal: float
    Tcal: float
    velocity: float
    mu: float
    sigma: float
    rel_H: float
    projected: np.ndarray
    coherence: np.ndarray


def synthetic_eval(fam: SyntheticFamily, L: float, E: float, moment_order: int) -> SyntheticEval:
    a = fam.delta + 1j*(fam.gamma-E)
    coeff = fam.multiplicity/(a*a)
    envelope = np.exp(-fam.eps*L)
    osc = np.exp(1j*fam.gamma*L)
    terms = coeff*envelope*osc

    H = complex(np.sum(terms))
    abs_terms = np.abs(terms)
    W0 = float(np.sum(abs_terms))
    rel_H = abs(H)/max(W0, EPS)

    HL = complex(np.sum((-fam.eps+1j*fam.gamma)*terms))
    # d/dE [a(E)^-2] = 2 i a^-3 because a_E=-i.
    HE_terms = (2j*fam.multiplicity/(a*a*a))*envelope*osc
    HE = complex(np.sum(HE_terms))

    if abs(H) <= EPS:
        psi_L = float("nan")
        psi_E = float("nan")
    else:
        psi_L = float(np.imag(HL/H))
        psi_E = float(np.imag(HE/H))

    Lcal = float(E+psi_L) if finite(psi_L) else float("nan")
    Tcal = float(L+psi_E) if finite(psi_E) else float("nan")
    velocity = float(-Lcal/Tcal) if finite(Lcal) and finite(Tcal) and abs(Tcal) > EPS else float("nan")

    sq = abs_terms*abs_terms
    S0 = float(np.sum(sq))
    S1 = float(np.sum(fam.gamma*sq))
    S2 = float(np.sum((fam.gamma*fam.gamma)*sq))
    mu = S1/max(S0, EPS)
    var = max(S2/max(S0, EPS)-mu*mu, 0.0)
    sigma = math.sqrt(var)

    projected = np.full(moment_order, np.nan)
    coherence = np.full(moment_order, np.nan)
    gp = np.ones_like(fam.gamma)
    for m in range(1, moment_order+1):
        gp = gp*fam.gamma
        Mm = complex(np.sum(gp*terms))
        Wm = float(np.sum(gp*abs_terms))
        projected[m-1] = abs(float(np.real(Mm*np.conj(H))))/max(Wm*W0, EPS)
        coherence[m-1] = abs(Mm)/max(Wm, EPS)

    return SyntheticEval(
        E=float(E), L=float(L), H=H, W0=W0,
        psi_L=psi_L, psi_E=psi_E,
        Lcal=Lcal, Tcal=Tcal, velocity=velocity,
        mu=float(mu), sigma=float(sigma), rel_H=float(rel_H),
        projected=projected, coherence=coherence,
    )


def track_synthetic_family(
    fam: SyntheticFamily,
    *,
    L_start: float,
    L_end: float,
    step: float,
    E0: float,
    E_bound: float,
    min_transversality_ratio: float,
    relative_H_floor: float,
    moment_order: int,
    sample_stride: int,
    dark_threshold: float,
    progress: tqdm,
) -> Tuple[pd.DataFrame, dict]:
    E = float(E0)
    L = float(L_start)
    rows: List[dict] = []
    breakdown_reason = ""
    steps = int(math.ceil((L_end-L_start)/step))

    velocities: List[float] = []
    Lvals: List[float] = []
    Evals: List[float] = []
    muvals: List[float] = []
    sigvals: List[float] = []
    relhvals: List[float] = []
    tvals: List[float] = []
    projected_tail: List[np.ndarray] = []
    coherence_tail: List[np.ndarray] = []

    for it in range(steps+1):
        ev = synthetic_eval(fam, L, E, moment_order)

        Lvals.append(L)
        Evals.append(E)
        velocities.append(abs(ev.velocity) if finite(ev.velocity) else float("nan"))
        muvals.append(ev.mu)
        sigvals.append(ev.sigma)
        relhvals.append(ev.rel_H)
        tvals.append(ev.Tcal/L if finite(ev.Tcal) and L > 0 else float("nan"))

        if it >= int(0.6*steps):
            projected_tail.append(ev.projected.copy())
            coherence_tail.append(ev.coherence.copy())

        if it % max(sample_stride, 1) == 0 or it == steps:
            row = {
                "family": fam.label,
                "iteration": int(it),
                "L": float(L),
                "E": float(E),
                "velocity_abs": float(abs(ev.velocity)) if finite(ev.velocity) else float("nan"),
                "mu": float(ev.mu),
                "sigma": float(ev.sigma),
                "sigma_over_mu": float(ev.sigma/max(ev.mu, EPS)),
                "relative_H": float(ev.rel_H),
                "Lcal": float(ev.Lcal),
                "Tcal": float(ev.Tcal),
                "Tcal_over_L": float(ev.Tcal/L) if finite(ev.Tcal) else float("nan"),
            }
            for m in range(moment_order):
                row[f"projected_m{m+1}"] = float(ev.projected[m])
                row[f"coherence_m{m+1}"] = float(ev.coherence[m])
            rows.append(row)

        # Persistence/falsification gates.
        if not finite(ev.velocity) or not finite(ev.Tcal):
            breakdown_reason = "NONFINITE_CHARACTERISTIC"
            break
        if ev.rel_H < relative_H_floor:
            breakdown_reason = "PHASE_AMPLITUDE_ZERO_OR_DARK_SINGULARITY"
            break
        if abs(ev.Tcal) < min_transversality_ratio*L:
            breakdown_reason = "NO_FOLD_TRANSVERSALITY_LOST"
            break
        if abs(E) > E_bound:
            breakdown_reason = "LEFT_COMPACT_E_TUBE"
            break
        if L >= L_end-0.5*step:
            break

        h = min(step, L_end-L)
        # Midpoint RK2 characteristic continuation.
        Emid = E + 0.5*h*ev.velocity
        mid = synthetic_eval(fam, L+0.5*h, Emid, moment_order)
        if not finite(mid.velocity):
            breakdown_reason = "NONFINITE_MIDPOINT_CHARACTERISTIC"
            break
        E = E + h*mid.velocity
        L = L+h
        progress.update(1)

    Larr = np.asarray(Lvals, float)
    Earr = np.asarray(Evals, float)
    Varr = np.asarray(velocities, float)
    muarr = np.asarray(muvals, float)
    sigarr = np.asarray(sigvals, float)
    relharr = np.asarray(relhvals, float)
    trarr = np.asarray(tvals, float)

    tail0 = max(0, int(0.6*len(Larr)))
    slope, r2 = safe_power_fit(Larr[tail0:], Varr[tail0:])
    velocity_decay_power = -slope if finite(slope) else float("nan")

    # Fixed log-2 transfer diagnostic along the sampled characteristic.
    dyadic_scaled: List[float] = []
    dyadic_raw: List[float] = []
    for idx in range(tail0, len(Larr), max(1, len(Larr)//24)):
        La = Larr[idx]
        Eb = interp_at(Larr, Earr, La+LOG2)
        if finite(Eb):
            d = abs(Eb-Earr[idx])
            dyadic_raw.append(d)
            dyadic_scaled.append(d*La*La/LOG2)

    proj = np.asarray(projected_tail, float) if projected_tail else np.empty((0, moment_order))
    coh = np.asarray(coherence_tail, float) if coherence_tail else np.empty((0, moment_order))
    proj_med = np.nanmedian(proj, axis=0) if len(proj) else np.full(moment_order, np.nan)
    coh_med = np.nanmedian(coh, axis=0) if len(coh) else np.full(moment_order, np.nan)

    dark_depth_projected = 0
    dark_depth_coherent = 0
    for m in range(moment_order):
        if finite(proj_med[m]) and proj_med[m] < dark_threshold:
            dark_depth_projected = m+1
        else:
            break
    for m in range(moment_order):
        if finite(coh_med[m]) and coh_med[m] < dark_threshold:
            dark_depth_coherent = m+1
        else:
            break

    persisted = (breakdown_reason == "") and (Larr[-1] >= L_end-2*step)
    bounded = bool(np.nanmax(np.abs(Earr)) <= E_bound)
    nofold = bool(np.nanmin(np.abs(trarr)) >= min_transversality_ratio)

    # A persistent branch is numerically compatible with cutoff convergence if
    # its tail velocity looks integrable or its log-2 displacements show bounded
    # L^2 scaling.  These are diagnostics, not theorem statements.
    max_scaled_dyadic = float(np.nanmax(dyadic_scaled)) if dyadic_scaled else float("nan")
    med_scaled_dyadic = float(np.nanmedian(dyadic_scaled)) if dyadic_scaled else float("nan")
    integrable_tail = bool(finite(velocity_decay_power) and velocity_decay_power > 1.02)

    if breakdown_reason:
        mechanism_class = breakdown_reason
        adversarial_counterexample = False
    elif not bounded:
        mechanism_class = "LEFT_COMPACT_E_TUBE"
        adversarial_counterexample = False
    elif integrable_tail:
        mechanism_class = "PERSISTENT_INTEGRABLE_LOCK"
        adversarial_counterexample = False
    else:
        mechanism_class = "PERSISTENT_NONINTEGRABLE_LOCK"
        adversarial_counterexample = True

    summary = {
        "family": fam.label,
        "terms": int(len(fam.gamma)),
        "L_start": float(Larr[0]),
        "L_end_reached": float(Larr[-1]),
        "E_start": float(Earr[0]),
        "E_end": float(Earr[-1]),
        "max_abs_E": float(np.nanmax(np.abs(Earr))),
        "persisted": bool(persisted),
        "bounded": bool(bounded),
        "nofold": bool(nofold),
        "breakdown_reason": breakdown_reason,
        "mu_start": float(muarr[0]),
        "mu_end": float(muarr[-1]),
        "mu_growth_ratio": float(muarr[-1]/max(muarr[0], EPS)),
        "sigma_end": float(sigarr[-1]),
        "sigma_over_mu_end": float(sigarr[-1]/max(muarr[-1], EPS)),
        "min_relative_H": float(np.nanmin(relharr)),
        "min_abs_Tcal_over_L": float(np.nanmin(np.abs(trarr))),
        "velocity_decay_power": float(velocity_decay_power),
        "velocity_loglog_r2": float(r2),
        "tail_max_scaled_dyadic_L2": max_scaled_dyadic,
        "tail_median_scaled_dyadic_L2": med_scaled_dyadic,
        "tail_max_raw_dyadic": float(np.nanmax(dyadic_raw)) if dyadic_raw else float("nan"),
        "dark_depth_projected": int(dark_depth_projected),
        "dark_depth_coherent": int(dark_depth_coherent),
        "mechanism_class": mechanism_class,
        "adversarial_counterexample_candidate": bool(adversarial_counterexample),
    }
    for m in range(moment_order):
        summary[f"tail_median_projected_m{m+1}"] = float(proj_med[m])
        summary[f"tail_median_coherence_m{m+1}"] = float(coh_med[m])

    return pd.DataFrame(rows), summary


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v422 recursive-observer nonattained cutoff stress test",
    )

    # Upstream lineage.
    ap.add_argument("--v408-summary", default="rot_rh_nonattained_support_migration_v408_SUMMARY.json")
    ap.add_argument("--v409-summary", default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json")
    ap.add_argument("--v410-summary", default="rot_rh_bohr_frequency_escape_v410_SUMMARY.json")
    ap.add_argument("--v411-summary", default="rot_rh_collective_phase_lock_v411_SUMMARY.json")
    ap.add_argument("--v419-summary", default="rot_rh_primitive_beta_renormalization_v419_SUMMARY.json")
    ap.add_argument("--v420-summary", default="rot_rh_attained_nofold_rg_characteristic_v420_SUMMARY.json")
    ap.add_argument("--v421-summary", default="rot_rh_riesz_attained_cluster_regulator_repair_v421_SUMMARY.json")
    ap.add_argument("--require-upstream", action="store_true")

    # Arithmetic test.
    ap.add_argument("--skip-arithmetic", action="store_true")
    ap.add_argument(
        "--roots-csv",
        default="rot_rh_collision_normalized_stiffness_forward_v78_EXTENDED_ROOTS.csv",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--anchors", default="8000000,16000000")
    ap.add_argument("--max-modes", type=int, default=12)
    ap.add_argument("--steps-per-doubling", type=int, default=4)
    ap.add_argument("--minimum-slope-ratio", type=float, default=0.02)
    ap.add_argument("--maximum-blind-endpoint-error", type=float, default=2.0e-2)
    ap.add_argument("--maximum-shell-growth", type=float, default=2.0)
    ap.add_argument("--maximum-scaled-displacement", type=float, default=100.0)

    # Synthetic adversary.
    ap.add_argument("--skip-synthetic", action="store_true")
    ap.add_argument("--synthetic-terms", type=int, default=256)
    ap.add_argument("--synthetic-ensembles", type=int, default=8)
    ap.add_argument("--synthetic-L-start", type=float, default=8.0)
    ap.add_argument("--synthetic-L-end", type=float, default=50.0)
    ap.add_argument("--synthetic-step", type=float, default=0.01)
    ap.add_argument("--synthetic-E0", type=float, default=20.25)
    ap.add_argument("--synthetic-E-bound", type=float, default=250.0)
    ap.add_argument("--synthetic-delta-star", type=float, default=0.25)
    ap.add_argument("--synthetic-eps-scale", type=float, default=0.30)
    ap.add_argument("--synthetic-gamma0", type=float, default=8.0)
    ap.add_argument("--synthetic-gamma-scale", type=float, default=0.12)
    ap.add_argument("--synthetic-min-transversality-ratio", type=float, default=1.0e-3)
    ap.add_argument("--synthetic-relative-H-floor", type=float, default=1.0e-10)
    ap.add_argument("--moment-order", type=int, default=6)
    ap.add_argument("--dark-threshold", type=float, default=1.0e-3)
    ap.add_argument("--synthetic-sample-stride", type=int, default=20)

    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--prefix", default="rot_rh_recursive_observer_nonattained_v422")

    args = ap.parse_args()
    started = time.perf_counter()

    if args.steps_per_doubling < 2:
        raise ValueError("--steps-per-doubling must be >=2")
    if args.synthetic_terms < 16:
        raise ValueError("--synthetic-terms must be >=16")
    if args.synthetic_ensembles < 1:
        raise ValueError("--synthetic-ensembles must be >=1")
    if args.synthetic_step <= 0:
        raise ValueError("--synthetic-step must be >0")
    if args.synthetic_L_end <= args.synthetic_L_start:
        raise ValueError("synthetic L_end must exceed L_start")
    if args.moment_order < 1 or args.moment_order > 10:
        raise ValueError("--moment-order must lie in [1,10]")

    print("="*236)
    print("ROT-RH v422 — RECURSIVE-OBSERVER NONATTAINED LOCK / FIXED-MODE CUTOFF STRESS TEST")
    print("="*236)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("finite scan accepted as proof             : NO")
    print("arithmetic root solves beyond anchors     : NONE")
    print("="*236)

    # [1] Upstream theorem lineage.
    upstream = check_upstream(args)
    print("[1] Upstream theorem lineage")
    for key in EXPECTED_UPSTREAM:
        u = upstream[key]
        print(f"{key:8s} available={str(u['available']):5s} pass={str(u['pass']):5s} verdict={u['verdict']}")
    upstream_available = [u["pass"] for u in upstream.values() if u["available"]]
    upstream_ok = bool(upstream_available and all(upstream_available))
    if args.require_upstream:
        upstream_ok = bool(all(u["pass"] for u in upstream.values()))
        if not upstream_ok:
            raise RuntimeError("Required upstream theorem lineage is incomplete")

    arithmetic_track = pd.DataFrame()
    arithmetic_shells = pd.DataFrame()
    arithmetic_summary: Dict[str, object] = {"skipped": bool(args.skip_arithmetic)}

    # [2] Zero-free arithmetic characteristic flow.
    if not args.skip_arithmetic:
        print("\n[2] Zero-free arithmetic fixed-root flow")
        roots_path = Path(args.roots_csv)
        if not roots_path.exists():
            raise FileNotFoundError(roots_path)

        _, roots = load_roots_by_cutoff(str(roots_path), args.max_modes)
        anchors = sorted(set(parse_ints(args.anchors)))
        for X in anchors:
            if X not in roots:
                raise ValueError(f"Anchor {X:,} missing from roots CSV")

        maxY = 2*max(anchors)
        base = importlib.import_module(args.v71_module)
        print("anchors                                    :", anchors)
        print("modes                                      :", min(len(roots[X]) for X in anchors))
        print("steps per doubling                         :", args.steps_per_doubling)
        print("maximum arithmetic cutoff                 :", f"{maxY:,}")

        t0 = time.perf_counter()
        primes = base.sieve_primes(maxY)
        print("primes <= max cutoff                      :", f"{len(primes):,}")
        print("sieve seconds                             :", f"{time.perf_counter()-t0:.3f}")

        tracks = []
        shells = []
        with tqdm(
            total=len(anchors)*args.steps_per_doubling,
            desc="arithmetic root flow",
            unit="RK2-step",
        ) as bar:
            for X in anchors:
                tr, sh = arithmetic_shell_track(
                    base=base,
                    primes=primes,
                    roots=roots,
                    anchor=X,
                    steps_per_doubling=args.steps_per_doubling,
                    minimum_slope_ratio=args.minimum_slope_ratio,
                    progress=bar,
                )
                tracks.append(tr)
                shells.append(sh)

        arithmetic_track = pd.concat(tracks, ignore_index=True)
        arithmetic_shells = pd.concat(shells, ignore_index=True)

        blind_rows = arithmetic_shells[arithmetic_shells["blind_endpoint_available"]]
        max_blind = float(blind_rows["abs_blind_endpoint_error"].max()) if len(blind_rows) else float("nan")
        min_slope = float(arithmetic_shells["min_slope_over_L"].min())
        max_scaled = float(arithmetic_shells["scaled_dyadic_displacement_L2"].max())
        max_beta = float(arithmetic_shells["max_abs_beta"].max())
        max_pi_over_L = float(arithmetic_shells["abs_primitive_beta_over_L"].max())
        nofold_all = bool(arithmetic_shells["nofold"].all())

        # Compare per-mode L^2-scaled dyadic displacement across successive shells.
        growth_ratios: List[float] = []
        for k, g in arithmetic_shells.groupby("root_index"):
            g = g.sort_values("anchor")
            vals = g["scaled_dyadic_displacement_L2"].to_numpy(float)
            for a, b in zip(vals[:-1], vals[1:]):
                growth_ratios.append(float(b/max(a, 1e-15)))
        max_growth = float(max(growth_ratios)) if growth_ratios else float("nan")

        blind_pass = bool(not len(blind_rows) or max_blind <= args.maximum_blind_endpoint_error)
        growth_pass = bool(not growth_ratios or max_growth <= args.maximum_shell_growth)
        scaled_pass = bool(max_scaled <= args.maximum_scaled_displacement)
        arithmetic_pass = bool(nofold_all and blind_pass and growth_pass and scaled_pass)

        arithmetic_summary = {
            "skipped": False,
            "anchors": anchors,
            "max_cutoff": int(maxY),
            "modes": int(arithmetic_shells["root_index"].nunique()),
            "min_slope_over_L": min_slope,
            "max_abs_beta": max_beta,
            "max_abs_primitive_beta_over_L": max_pi_over_L,
            "max_scaled_dyadic_displacement_L2": max_scaled,
            "max_successive_shell_growth_ratio": max_growth,
            "max_blind_endpoint_abs_error": max_blind,
            "nofold_all": nofold_all,
            "blind_endpoint_pass": blind_pass,
            "shell_growth_pass": growth_pass,
            "scaled_displacement_pass": scaled_pass,
            "diagnostic_pass": arithmetic_pass,
        }

        print("minimum F'/L along flow                    :", f"{min_slope:.12e}")
        print("maximum |beta|                            :", f"{max_beta:.12e}")
        print("maximum |Pi_shell|/L                      :", f"{max_pi_over_L:.12e}")
        print("maximum L^2-scaled dyadic displacement    :", f"{max_scaled:.12e}")
        print("maximum successive-shell growth ratio     :", f"{max_growth:.9f}" if finite(max_growth) else "N/A")
        print("maximum blind next-anchor endpoint error  :", f"{max_blind:.12e}" if finite(max_blind) else "N/A")
        print("no-fold all                               :", nofold_all)
        print("arithmetic diagnostic pass                :", arithmetic_pass)

        print("\nArithmetic shell summary:")
        cols = [
            "anchor", "root_index", "dyadic_displacement",
            "scaled_dyadic_displacement_L2", "primitive_beta_shell",
            "min_slope_over_L", "abs_blind_endpoint_error", "nofold",
        ]
        print(arithmetic_shells[cols].to_string(index=False, float_format=lambda x: f"{x:.6e}"))

    # [3] Synthetic nonattained adversary.
    synthetic_track = pd.DataFrame()
    synthetic_summary_df = pd.DataFrame()
    synthetic_summary: Dict[str, object] = {"skipped": bool(args.skip_synthetic)}

    if not args.skip_synthetic:
        print("\n[3] Synthetic nonattained Riesz adversary")
        total_steps = args.synthetic_ensembles*int(math.ceil(
            (args.synthetic_L_end-args.synthetic_L_start)/args.synthetic_step
        ))
        tracks = []
        sums = []
        with tqdm(total=total_steps, desc="nonattained adversary", unit="step") as bar:
            for ens in range(args.synthetic_ensembles):
                fam = make_synthetic_family(
                    n=args.synthetic_terms,
                    ensemble=ens,
                    delta_star=args.synthetic_delta_star,
                    eps_scale=args.synthetic_eps_scale,
                    gamma0=args.synthetic_gamma0,
                    gamma_scale=args.synthetic_gamma_scale,
                )
                # Small deterministic L-origin shifts expose different phase cells
                # without adding arbitrary coefficient phases.
                Ls = args.synthetic_L_start + 0.037*(ens % 5)
                Le = args.synthetic_L_end + 0.037*(ens % 5)
                tr, sm = track_synthetic_family(
                    fam,
                    L_start=Ls,
                    L_end=Le,
                    step=args.synthetic_step,
                    E0=args.synthetic_E0,
                    E_bound=args.synthetic_E_bound,
                    min_transversality_ratio=args.synthetic_min_transversality_ratio,
                    relative_H_floor=args.synthetic_relative_H_floor,
                    moment_order=args.moment_order,
                    sample_stride=args.synthetic_sample_stride,
                    dark_threshold=args.dark_threshold,
                    progress=bar,
                )
                tracks.append(tr)
                sums.append(sm)

        synthetic_track = pd.concat(tracks, ignore_index=True) if tracks else pd.DataFrame()
        synthetic_summary_df = pd.DataFrame(sums)

        counter = synthetic_summary_df[synthetic_summary_df["adversarial_counterexample_candidate"]]
        n_counter = int(len(counter))
        n_integrable = int(np.sum(synthetic_summary_df["mechanism_class"] == "PERSISTENT_INTEGRABLE_LOCK"))
        n_break = int(len(synthetic_summary_df)-n_counter-n_integrable)
        mu_growth_min = float(synthetic_summary_df["mu_growth_ratio"].min())
        deepest_projected = int(synthetic_summary_df["dark_depth_projected"].max())
        deepest_coherent = int(synthetic_summary_df["dark_depth_coherent"].max())
        synthetic_pass = bool(n_counter == 0)

        synthetic_summary = {
            "skipped": False,
            "ensembles": int(args.synthetic_ensembles),
            "terms_per_ensemble": int(args.synthetic_terms),
            "counterexample_candidates": n_counter,
            "persistent_integrable_locks": n_integrable,
            "branches_excluded_or_broken": n_break,
            "minimum_mu_growth_ratio": mu_growth_min,
            "deepest_projected_dark_hierarchy": deepest_projected,
            "deepest_coherent_dark_hierarchy": deepest_coherent,
            "diagnostic_pass": synthetic_pass,
        }

        print("counterexample candidates                 :", n_counter)
        print("persistent integrable locks               :", n_integrable)
        print("branches excluded/broken                  :", n_break)
        print("minimum mu growth ratio                   :", f"{mu_growth_min:.6e}")
        print("deepest projected dark hierarchy          :", deepest_projected)
        print("deepest coherent dark hierarchy           :", deepest_coherent)
        print("synthetic diagnostic pass                 :", synthetic_pass)
        print("\nSynthetic family summary:")
        display_cols = [
            "family", "mechanism_class", "mu_growth_ratio",
            "sigma_over_mu_end", "velocity_decay_power",
            "tail_median_scaled_dyadic_L2", "dark_depth_projected",
            "dark_depth_coherent", "min_abs_Tcal_over_L",
            "adversarial_counterexample_candidate",
        ]
        print(synthetic_summary_df[display_cols].to_string(index=False, float_format=lambda x: f"{x:.6e}"))

    # Final falsification-oriented verdict.
    arithmetic_ok = True if args.skip_arithmetic else bool(arithmetic_summary.get("diagnostic_pass", False))
    synthetic_ok = True if args.skip_synthetic else bool(synthetic_summary.get("diagnostic_pass", False))

    if arithmetic_ok and synthetic_ok:
        verdict = "RECURSIVE_OBSERVER_NONATTAINED_MECHANISM_SURVIVES_V422_STRESS_TEST"
        next_theorem = "PROVE_EXCEPTIONAL_DIAGONAL_NO_ETERNAL_TRACKING_OR_PRIMITIVE_BETA_BOUND"
    elif not synthetic_ok:
        verdict = "SYNTHETIC_NONATTAINED_PERSISTENT_NONINTEGRABLE_LOCK_FOUND"
        next_theorem = "ANALYZE_COUNTEREXAMPLE_FAMILY_BEFORE_ANY_CUTOFF_CLOSURE_CLAIM"
    else:
        verdict = "ARITHMETIC_FIXED_ROOT_FLOW_STRESS_TEST_FAILED"
        next_theorem = "LOCALIZE_ARITHMETIC_BETA_OR_NOFOLD_FAILURE"

    prefix = Path(args.prefix)
    arithmetic_track_path = Path(str(prefix)+"_ARITHMETIC_TRACK.csv")
    arithmetic_shell_path = Path(str(prefix)+"_ARITHMETIC_SHELLS.csv")
    synthetic_track_path = Path(str(prefix)+"_SYNTHETIC_TRACK.csv.gz")
    synthetic_summary_path = Path(str(prefix)+"_SYNTHETIC_SUMMARY.csv")
    summary_path = Path(str(prefix)+"_SUMMARY.json")
    cert_path = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if not arithmetic_track.empty:
        arithmetic_track.to_csv(arithmetic_track_path, index=False)
    if not arithmetic_shells.empty:
        arithmetic_shells.to_csv(arithmetic_shell_path, index=False)
    if not synthetic_track.empty:
        synthetic_track.to_csv(synthetic_track_path, index=False, compression="gzip")
    if not synthetic_summary_df.empty:
        synthetic_summary_df.to_csv(synthetic_summary_path, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
            "future_arithmetic_root_solves": False,
        },
        "upstream": upstream,
        "arithmetic": arithmetic_summary,
        "synthetic_nonattained": synthetic_summary,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "TEST ONLY. A PASS means the proposed recursive-observer mechanism survived "
            "the zero-free arithmetic characteristic-flow audit and the selected synthetic "
            "nonattained Riesz adversaries. It does not prove the exceptional-diagonal theorem, "
            "does not prove fixed-mode cutoff removal, and does not prove RH. A synthetic "
            "persistent nonintegrable lock is a serious counterexample to the proposed mechanism "
            "and must be understood before proceeding."
        ),
        "runtime_seconds": float(time.perf_counter()-started),
    }
    summary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    cert = {
        "schema": "ROT_RH_RECURSIVE_OBSERVER_NONATTAINED_CERTIFICATE_V1",
        "regulator": "Riesz/log-Cesaro only",
        "already_closed": {
            "support_migration": "v408",
            "phase_moment_necessity": "v409",
            "Bohr_frequency_escape": "v410",
            "collective_phase_lock_reduction": "v411",
            "primitive_beta_implication": "v419",
            "RG_characteristic_cell_conservation": "v420",
            "Riesz_attained_cluster": "v421",
        },
        "required_analytic_claims": {
            "observer_lock_dichotomy": (
                "For every compact fixed-k tube in the genuinely nonattained Riesz family, "
                "frequency escape forces either loss of branch persistence/no-fold or a signed "
                "collective-lock law with subquadratic primitive beta."
            ),
            "exceptional_diagonal": (
                "A continuous transversely ordered physical diagonal cannot remain forever in "
                "the exceptional cancellation set while active frequency support escapes."
            ),
            "dark_hierarchy_rigidity": (
                "If eternal tracking forces an infinite hierarchy of frequency-moment "
                "cancellations, prove that the Riesz 1/a^2 coefficient family admits no "
                "nontrivial persistent solution compatible with H!=0 and F'!=0."
            ),
            "fixed_mode_conclusion": (
                "Either the nonattained bounded ordered branch is excluded, or "
                "Pi_k(L)=O(L^(2-eps)) and E_k(L) converges."
            ),
        },
        "forbidden_as_proof": [
            "this v422 numerical PASS",
            "synthetic-family typicality",
            "random-phase heuristic",
            "Bohr typicality on x=L",
            "magnitude-only PNT bounds",
            "known zero ordinates",
            "Xi fitting",
        ],
    }
    cert_path.write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("\n"+"="*236)
    print("VERDICT                                   :", verdict)
    print("NEXT THEOREM                              :", next_theorem)
    print("FIXED-MODE CUTOFF REMOVAL                 : NOT PROVED BY THIS TEST")
    print("="*236)
    print("Files written:")
    for p in (
        arithmetic_track_path,
        arithmetic_shell_path,
        synthetic_track_path,
        synthetic_summary_path,
        summary_path,
        cert_path,
    ):
        if p.exists():
            print(" ", p)

    if args.strict and not (arithmetic_ok and synthetic_ok):
        raise SystemExit(2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
