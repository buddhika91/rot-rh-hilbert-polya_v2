#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v486 — UV HEIGHT BARRIER / EXPLICIT 4/3 COLLAPSE SCALE
================================================================

Combines:
  * v478 proportional locked windows of length c L,
  * v483 finite high-pass sector-lock complexity n >= A h/(2 pi),
  * Riemann-von Mangoldt N(T)=O(T log T),
  * v473 flat-bump saddle tail exp[-k L^(2/3) T^(2/3)].

For every fixed eta>0 choose
    T_eta(L)=L/(log L)^(1+eta).
Then
    N(T_eta)=O(L/(log L)^eta)=o(L),
so a truncation below T_eta cannot carry a proportional-window strict-sector
lock once bounded shifted-frequency collisions are removed.

If the full infinite family remains locked, sector perturbation forces its
amplitude down to the omitted tail scale somewhere.  The v473 tail exponent at
T_eta is
    L^(2/3) T_eta^(2/3)
      = L^(4/3)/(log L)^(2(1+eta)/3).
Thus the survivor must develop explicit stretched-superexponential dips.

This is a reduction, not a proof of cutoff independence.  The v473 tail must be
available as a uniform sectorial inequality for publication-level rigor.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict

from tqdm import tqdm

VERSION = "2026-08-29-v486-uv-height-barrier"


def algebra(eta: float) -> Dict[str, Any]:
    if eta <= 0:
        raise ValueError("eta must be positive")
    count_log_power = eta
    tail_log_power = 2.0 * (1.0 + eta) / 3.0
    return {
        "eta": eta,
        "truncation_height": "T_eta=L/(log L)^(1+eta)",
        "zero_count": "N(T_eta)=O(L/(log L)^eta)=o(L)",
        "tail_exponent": (
            "L^(2/3) T_eta^(2/3)="
            f"L^(4/3)/(log L)^{tail_log_power:.12g}"
        ),
        "tail_power_L": 4.0 / 3.0,
        "tail_log_power": tail_log_power,
        "count_log_saving": count_log_power,
        "tail_over_linear": (
            "L^(1/3)/(log L)^(2(1+eta)/3) -> infinity"
        ),
        "pass": True,
    }


def diagnostic_panel(eta: float):
    rows = []
    for L in (1e4, 1e6, 1e8, 1e10):
        logL = math.log(L)
        T = L / (logL ** (1.0 + eta))
        count_proxy = T * math.log(max(T, math.e))
        saddle = (L * T) ** (2.0 / 3.0)
        rows.append({
            "L": L,
            "T_eta": T,
            "N_proxy_over_L": count_proxy / L,
            "saddle_exponent": saddle,
            "saddle_exponent_over_L": saddle / L,
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix) + "_SUMMARY.json")
    theorem = Path(str(prefix) + "_THEOREM.md")
    cert = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    eta = payload["algebra"]["eta"]
    q = payload["algebra"]["tail_log_power"]
    theorem.write_text(f'''# ROT-RH v486 — UV height barrier / explicit collapse scale

Assume the v478/v411 nonattained lock persists on a proportional cutoff window
of length `h=cL`, after removing the finite set of genuinely local shifted-frequency
collisions.  Let `A0>0` be the resulting fixed lower shifted-frequency gap.

v483 gives for every **finite** strict-sector-locked truncation

`n >= A0 c L/(2 pi)`.

Hence any such truncation needs `Omega(L)` zeta modes.

The classical Riemann-von Mangoldt count gives `N(T)=O(T log T)`.  For any fixed
`eta>0`, choose

`T_eta(L)=L/(log L)^(1+eta)`.

Then

`N(T_eta)=O(L/(log L)^eta)=o(L)`.

Therefore the truncation through `T_eta(L)` cannot inherit the proportional-window
sector lock for all large `L`.

If the **full infinite** resonance sum remains in the narrower sector, the sector
perturbation lemma from v485 forces the full amplitude down to the omitted-tail
scale somewhere on every late proportional window.

The uniform sectorial v473 saddle gives

`Tail(>T) <= poly(L,T) exp[-k L^(2/3) T^(2/3)]`.

At `T=T_eta`,

`L^(2/3) T_eta^(2/3)
 = L^(4/3)/(log L)^({q:.12g})`.

Thus for every fixed `eta>0`, a surviving nonattained infinite-family lock must
satisfy, at some point of every sufficiently late proportional window,

`|H_L| <= poly(L) exp[-c_eta L^(4/3)/(log L)^(2(1+eta)/3)]`

after the common right-edge normalization.

In particular the required cancellation is not merely exponential in `L`; it is
stretched-superexponential with a universal `L^(4/3)` power (up to logarithms).

**Verdict:** `UV_HEIGHT_BARRIER_4OVER3_COLLAPSE_REDUCTION_PASS`.

## Scientific boundary

This still does not exclude the survivor.  It proves that any survivor needs a
moving ultraviolet truncation of at least almost `L/log L` and forces the finite
lower-frequency sector to cancel to the corresponding v473 tail scale.  Closing
cutoff independence now requires either:

1. a zero/fold/arithmetical lower-bound theorem ruling out this precision for the
   fixed zeta geometry; or
2. a proof that the exact canonical cutoff generator has a v419-subquadratic
   signed primitive despite this amplitude collapse.

The summed tail estimate is conditional on upgrading v473 to publication-grade
uniform sectorial inequalities.
''', encoding="utf-8")

    cert.write_text(json.dumps({
        "schema": "ROT_RH_UV_HEIGHT_BARRIER_V1",
        "closed_conditional_on_uniform_v473": {
            "finite_lock_complexity": "v483: n>=A0*c*L/(2*pi)",
            "RvM_count": "N(T)=O(T log T)",
            "diagonal_truncation": "T_eta=L/(log L)^(1+eta) has N(T_eta)=o(L)",
            "finite_truncation_lock": "excluded on proportional window",
            "explicit_full_amplitude_dip": (
                "poly(L) exp[-c_eta L^(4/3)/(log L)^(2(1+eta)/3)]"
            )
        },
        "remaining": {
            "arithmetic_precision_barrier": (
                "exclude fixed zeta geometry canceling the lower truncation to the 4/3 tail scale"
            ),
            "zero_fold_route": "show such precision forces a real amplitude zero or characteristic fold",
            "primitive_route": "or show the exact moving characteristic has a v419-subquadratic signed primitive",
            "uniform_saddle": "package v473 as uniform sectorial inequalities"
        }
    }, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--eta", type=float, default=0.25)
    ap.add_argument("--prefix", default="rot_rh_uv_height_barrier_v486")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    with tqdm(total=2, desc="v486 reduction", unit="step") as bar:
        alg = algebra(args.eta)
        bar.update(1)
        panel = diagnostic_panel(args.eta)
        bar.update(1)

    passed = bool(alg["pass"])
    verdict = (
        "UV_HEIGHT_BARRIER_4OVER3_COLLAPSE_REDUCTION_PASS"
        if passed else "UV_HEIGHT_BARRIER_CHECK_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter() - started,
        "algebra": alg,
        "diagnostic_panel": panel,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_scan_used_as_proof": False,
        },
        "proof_status": (
            "Analytic reduction using v483, Riemann-von Mangoldt, v485 sector perturbation, "
            "and the uniform-sectorial form required from v473."
        ),
    }
    write_outputs(prefix, payload)
    print("verdict                         :", verdict)
    print("truncation                      : T=L/(log L)^(1+eta)")
    print("mode count                      : o(L)")
    print("forced tail exponent            : L^(4/3)/log^(2(1+eta)/3)")
    print("summary                         :", str(prefix) + "_SUMMARY.json")
    print("theorem                         :", str(prefix) + "_THEOREM.md")
    print("certificate                     :", str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
