#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v402 — EXACT BETA=2 WEIGHTED FACTORIAL FOUR-JET R^7 CERTIFICATE
======================================================================

Purpose
-------
Combine:

  * v327's exact rational all-M/all-support beta=2 weighted R^7 certificate;
  * v401's Bernstein quotient-frequency / factorial-jet reduction.

The result is an exact global contraction theorem for the R^7 transfer in a
beta=2 scale-covariant factorial four-jet prefix geometry.

IMPORTANT SCOPE
---------------
This does NOT prove the unweighted scalar supremum V_*<3/8 from v401.
Instead, it replaces that target by the already-certified beta=2 weighted
geometry.

It also does NOT by itself prove the G7 head asymptotics, the v78 collision
normalization, or fixed-mode cutoff independence.

Weighted prefix geometry
------------------------
For beta=2,

    ||u||_(2,s,D)
      = sup_(s<=m<=D)
          (s/m)^2 |A_u(m)|.

For output M starting after the seven-step support jump 128s, v323 uses the
normalization

    w_out = (M/(128s))^2.

v327 proves for every M, every finite support [s,D], and every phase E:

    weighted endpoint + weighted variation <= Q2,

where exactly

    Q2 = 82247680000000 / 617673396283947
       ~= 0.1331572324384
       < 1.

Quotient-frequency Bernstein lift
---------------------------------
The phase-normalized R^7 dual kernel has frequencies log q, where q=n/d.
For every transfer path q<=M/s, so its exponential type tau satisfies

    tau <= log(M/s) <= log M.

Classical Bernstein inequality for entire functions of exponential type,
applied to the finite-dimensional weighted BV-valued dual kernel by duality,
gives

    ||d_E^m H(E)||_weighted
      <= tau^m sup_x ||H(x)||_weighted
      <= (log M)^m Q2.

Use factorially scaled E-jets

    input_j  / [j! (log D)^j],
    output_r / [r! (log M)^r].

The Leibniz/binomial coefficients reduce to 1/m!, m=r-j, and since

    log D <= log M,
    tau <= log M,

the r-th row is bounded by

    Q2 * sum_(m=0)^r 1/m!.

For r<=3,

    H3 = 1 + 1 + 1/2 + 1/6 = 8/3.

Therefore the exact global weighted four-jet contraction constant is

    Qjet = (8/3) Q2
         = 657981440000000 / 1853020188851841
         ~= 0.3550859531691
         < 1.

Fixed-prefix packet factor
--------------------------
The support jumps by 128 per R^7 block.  Removing the output beta=2
normalization at a fixed prefix introduces 128^-2 per packet, so

    rho_jet = Qjet / 128^2
            = 40160000000 / 1853020188851841
            ~= 2.167272663e-5.

Thus repeated regular factorial-jet packet transfers decay extremely rapidly
at a fixed output prefix.

Scientific firewall
-------------------
NO Xi.
NO zeta numerical evaluations.
NO known zero ordinates.
NO floating arithmetic in the decisive PASS inequalities.
The only external theorem input is classical Bernstein inequality for entire
functions of exponential type; the finite-dimensional Banach-valued form
follows by scalar duality.

Version: 402
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

from tqdm import tqdm

VERSION = 402

EXPECTED_Q2 = Fraction(
    82247680000000,
    617673396283947,
)
H3 = Fraction(8, 3)
EXPECTED_QJET = Fraction(
    657981440000000,
    1853020188851841,
)
EXPECTED_RHOJET = Fraction(
    40160000000,
    1853020188851841,
)
SUPPORT_FACTOR = 128
BETA = 2


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def parse_fraction(text):
    if text is None:
        return None
    s = str(text).strip()
    if "/" in s:
        a, b = s.split("/", 1)
        return Fraction(int(a), int(b))
    return Fraction(s)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v327-certificate",
        default="rot_rh_R7_closed_form_rational_BV_v327_CERTIFICATE.json",
    )
    ap.add_argument(
        "--v401-summary",
        default="rot_rh_bernstein_factorial_jet_v401_SUMMARY.json",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_weighted_factorial_four_jet_v402",
    )

    args = ap.parse_args()

    print("=" * 222)
    print("ROT-RH v402 — EXACT BETA=2 WEIGHTED FACTORIAL FOUR-JET R^7 CERTIFICATE")
    print("=" * 222)
    print("Xi / zeta / known-zero data             : NONE")
    print("floating arithmetic in PASS decision    : NONE")
    print("beta                                     :", BETA)
    print("support factor                           :", SUPPORT_FACTOR)
    print("=" * 222)

    v327 = load_json(args.v327_certificate)
    v401 = load_json(args.v401_summary)

    print("[1] Upstream theorem packets")

    v327_ok = False
    q2_from_file = None

    if v327 is None:
        print("v327 certificate                         : NOT FOUND")
    else:
        print("v327 verdict                             :", v327.get("verdict"))
        q2_from_file = parse_fraction(
            v327.get("global_Q2_fraction")
        )
        v327_ok = bool(
            v327.get("verdict")
            == "CLOSED_FORM_RATIONAL_GLOBAL_BV_R7_PASS"
            and q2_from_file == EXPECTED_Q2
            and bool(
                v327.get(
                    "exact_internal_identity_pass",
                    False,
                )
            )
        )
        print("v327 exact Q2 matches                    :", q2_from_file == EXPECTED_Q2)

    v401_ok = False
    if v401 is None:
        print("v401 summary                             : NOT FOUND")
    else:
        print("v401 verdict                             :", v401.get("verdict"))
        exact = v401.get("exact_theorem", {})
        v401_ok = bool(
            v401.get("verdict")
            == "BERNSTEIN_FACTORIAL_FOUR_JET_REDUCTION_PASS"
            and exact.get("H3_fraction") == "8/3"
        )
        print("v401 H3=8/3 compatible                  :", exact.get("H3_fraction") == "8/3")

    # ------------------------------------------------------------------
    # Exact proof algebra.
    # ------------------------------------------------------------------
    print("\n[2] Exact rational contraction algebra")

    with tqdm(
        total=5,
        desc="exact weighted-jet proof",
        unit="step",
    ) as bar:
        q2 = EXPECTED_Q2
        bar.update(1)

        h3 = H3
        bar.update(1)

        qjet = h3 * q2
        bar.update(1)

        rhojet = qjet / Fraction(
            SUPPORT_FACTOR ** BETA,
            1,
        )
        bar.update(1)

        internal_identity_pass = bool(
            qjet == EXPECTED_QJET
            and rhojet == EXPECTED_RHOJET
        )
        bar.update(1)

    q2_contraction = q2 < 1
    qjet_contraction = qjet < 1

    print(
        "Q2 exact                                 :",
        f"{q2.numerator}/{q2.denominator}",
    )
    print(
        "Q2 decimal                               :",
        f"{float(q2):.15e}",
    )
    print(
        "H3 exact                                 :",
        f"{h3.numerator}/{h3.denominator}",
    )
    print(
        "Qjet=(8/3)Q2 exact                       :",
        f"{qjet.numerator}/{qjet.denominator}",
    )
    print(
        "Qjet decimal                             :",
        f"{float(qjet):.15e}",
    )
    print("Qjet < 1                                 :", qjet_contraction)
    print(
        "rhojet=Qjet/128^2 exact                  :",
        f"{rhojet.numerator}/{rhojet.denominator}",
    )
    print(
        "rhojet decimal                           :",
        f"{float(rhojet):.15e}",
    )
    print("exact internal identities                :", internal_identity_pass)

    # ------------------------------------------------------------------
    # Theorem chain.
    # ------------------------------------------------------------------
    print("\n[3] Weighted factorial four-jet theorem chain")

    theorem_steps = [
        (
            "BETA2_PREFIX_GEOMETRY",
            "v323: scale-covariant input prefix norm with output normalization (M/(128s))^2.",
        ),
        (
            "GLOBAL_ZERO_JET",
            "v327: exact all-M/all-support weighted endpoint+variation certificate Q2.",
        ),
        (
            "QUOTIENT_TYPE",
            "Phase-normalized dual frequencies are log q with q<=M/s, hence exponential type tau<=log M.",
        ),
        (
            "BANACH_BERNSTEIN",
            "Classical Bernstein + finite-dimensional duality bounds the m-th E derivative by tau^m times the zero-jet weighted norm.",
        ),
        (
            "FACTORIAL_SCALING",
            "j! and r! scaling converts Leibniz binomial coefficients to 1/(r-j)!.",
        ),
        (
            "FOUR_JET_BOUND",
            "For r<=3 the maximal row sum is (8/3)Q2.",
        ),
        (
            "GLOBAL_WEIGHTED_CONTRACTION",
            "Qjet=(8/3)Q2<1 exactly.",
        ),
        (
            "FIXED_PREFIX_PACKET_DECAY",
            "Undoing one beta=2 support normalization per R7 packet gives rhojet=Qjet/128^2.",
        ),
    ]

    for key, value in theorem_steps:
        print(f"{key:44s}: {value}")

    # ------------------------------------------------------------------
    # Scope / remaining obligations.
    # ------------------------------------------------------------------
    print("\n[4] What this closes and what remains")

    closed = [
        "ALL_M_ALL_SUPPORT_BETA2_ZERO_JET_R7_CONTRACTION",
        "ALL_M_ALL_SUPPORT_BETA2_FACTORIAL_FOUR_JET_R7_CONTRACTION",
        "FIXED_PREFIX_REGULAR_DERIVATIVE_PACKET_DECAY",
    ]

    remaining = [
        "G7_HEAD_RIESZ_TRANSFER_AND_STIFFNESS_ASYMPTOTICS",
        "RESONANCE_JET_TO_V78_COLLISION_NORMALIZATION",
        "UNWEIGHT_WEIGHTED_BRIDGE_FOR_THE_FINITE_EARLY_HEAD",
        "V392_ALL_X_PHASE_TRANSFER_BOUND",
        "V78_ALL_X_TRANSVERSALITY",
    ]

    print("Closed:")
    for item in closed:
        print("  +", item)

    print("Still open:")
    for item in remaining:
        print("  -", item)

    print()
    print(
        "IMPORTANT                                :",
        "v401's unweighted V_*<3/8 target is no longer required for the recursive transfer theorem.",
    )
    print(
        "IMPORTANT                                :",
        "the beta=2 theorem does not by itself control the unweighted G7/P0 head at arbitrarily large output M.",
    )

    pass_all = bool(
        v327_ok
        and v401_ok
        and q2_contraction
        and qjet_contraction
        and internal_identity_pass
    )

    verdict = (
        "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
        if pass_all
        else
        "WEIGHTED_FACTORIAL_FOUR_JET_CERTIFICATE_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_G7_HEAD_RIESZ_MOMENT_BOUNDS_AND_MATCH_RESONANCE_JET_TO_V78_COLLISION_TERM"
    )

    print("\n" + "=" * 222)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT YET PROVED; RECURSIVE REGULAR FOUR-JET TRANSFER CLOSED IN BETA=2 WEIGHTED GEOMETRY",
    )
    print("=" * 222)

    # ------------------------------------------------------------------
    # Outputs.
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)

    summary_path = Path(
        str(prefix) + "_SUMMARY.json"
    )
    theorem_path = Path(
        str(prefix) + "_THEOREM.md"
    )
    certificate_path = Path(
        str(prefix) + "_CERTIFICATE.json"
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "floating_arithmetic_in_pass": False,
        },
        "external_input": {
            "theorem": (
                "Classical Bernstein inequality for entire functions "
                "of exponential type bounded on the real axis; "
                "finite-dimensional Banach-valued form by duality."
            )
        },
        "upstream": {
            "v327_ok": v327_ok,
            "v401_ok": v401_ok,
        },
        "exact_constants": {
            "beta": BETA,
            "support_factor": SUPPORT_FACTOR,
            "Q2_fraction": (
                f"{q2.numerator}/{q2.denominator}"
            ),
            "Q2_decimal": float(q2),
            "H3_fraction": (
                f"{h3.numerator}/{h3.denominator}"
            ),
            "Qjet_fraction": (
                f"{qjet.numerator}/{qjet.denominator}"
            ),
            "Qjet_decimal": float(qjet),
            "Qjet_below_one_exact": qjet_contraction,
            "rhojet_fraction": (
                f"{rhojet.numerator}/{rhojet.denominator}"
            ),
            "rhojet_decimal": float(rhojet),
            "internal_identity_pass": internal_identity_pass,
        },
        "theorem_steps": {
            key: value
            for key, value in theorem_steps
        },
        "closed": closed,
        "remaining": remaining,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact rational contraction given v327's exact beta=2 "
            "weighted certificate and the classical Bernstein theorem. "
            "This closes the recursive R7 factorial four-jet transfer "
            "in the scale-covariant weighted geometry, not the G7 head."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )
    certificate_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v402 — exact weighted factorial four-jet theorem

v327 gives the exact beta=2 all-scale constant

`Q2 = {q2.numerator}/{q2.denominator}`.

The phase-normalized R7 dual kernel has quotient frequencies `log q`.
Classical Bernstein inequality, applied in the weighted finite-dimensional
BV space by duality, bounds the m-th E derivative by `tau^m Q2`.

Factorially scale the first four E-jets.  The maximal row factor is

`H3 = 1 + 1 + 1/2 + 1/6 = 8/3`.

Therefore

`Qjet = (8/3)Q2
      = {qjet.numerator}/{qjet.denominator}
      ~= {float(qjet):.16e}
      < 1`.

So R7 is a strict contraction in the beta=2 scale-covariant factorial
four-jet geometry.

The associated fixed-prefix packet factor is

`rhojet = Qjet/128^2
        = {rhojet.numerator}/{rhojet.denominator}
        ~= {float(rhojet):.16e}`.

This does not prove the unweighted G7 head theorem or fixed-mode cutoff
independence.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", certificate_path)

    if args.strict and not pass_all:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
