#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v448 — RIESZ / REGULATOR UNIVERSALITY HEAT-LIMIT AUDIT
===============================================================

PURPOSE
-------
Test whether the prime-side finite operators approach the same positive theta
heat semigroup independently of the admissible arithmetic regulator.

The target is

    Tr exp(-u H_ROT^2) = K_Xi(u),

with the zero-ordinate-free Euclidean resolvent

    M(z) = d/dz log[Xi(i sqrt(z))/Xi(0)]
         = integral_0^infinity exp(-z u) K_Xi(u) du.

This script attacks three distinct requirements:

  A_X(r) = || h_X^(r) - K_Xi ||              target error,
  B_X(r) = || h_nextX^(r) - h_X^(r) ||       cutoff Cauchy drift,
  C_X(r,s)=|| h_X^(r) - h_X^(s) ||           regulator universality.

A credible cutoff-independent prime realization should show, prospectively,

    A_X -> 0,  B_X -> 0,  C_X -> 0,

rather than merely producing one unusually accurate finite cutoff.

REGULATOR FAMILIES
------------------
The arithmetic phase law is

    theta(E)/pi + 1 - (1/pi) sum_n [Lambda(n)/(log n sqrt(n))] W_X(n)
                  * sin(E log n)
      = k - 1/2.

Implemented windows W_X(n):

  clock:
      n^(-1/log X)

  riesz:r:
      (1 - log(n)/log(X))_+^r

  bump:p:
      exp(-(x/(1-x))^p), x=log(n)/log(X)<1; 0 otherwise.

The bump family is compact C-infinity at the endpoint and avoids the artificial
hard truncation that would arise from using exp(-x^p) only up to n=X.

THETA TARGET FIREWALL
---------------------
Known zero ordinates are NEVER used.  zeta(), xi(), and Xi() are NEVER called.
The direct heat target is obtained by two independent numerical inverse-Laplace
algorithms applied to the theta-integral resolvent:

  * Stehfest
  * de Hoog

The v446 Stieltjes/Jacobi heat trace is retained as a third numerical consistency
check, not as the definition of the direct target.

SCIENTIFIC BOUNDARY
-------------------
This is a finite numerical audit, not an RH proof and not a proof of regulator
universality.  A PASS means the tested regulator families exhibit prospective
finite evidence for a common theta heat limit under frozen gates.  An analytic
uniform convergence / operator-limit theorem remains required.

Required local modules:
    rot_rh_clock_theta_jacobi_v445.py
    rot_rh_stieltjes_thorin_heat_v446.py

Typical PowerShell run:
    python .\\rot_rh_regulator_universality_heat_v448.py `
      --depth 48 `
      --cutoffs 72900,145800,291600,583200 `
      --riesz-orders 0.5,1,2,3 `
      --bump-orders 1,2 `
      --include-clock `
      --grid-points 64 `
      --moment-order 32 `
      --jacobi-dim 16 `
      --mp-dps 130 `
      --heat-u 0.008,0.010,0.0125,0.015,0.020,0.030 `
      --stehfest-degree 22 `
      --dehoog-degree 34 `
      --prefix rot_rh_regulator_universality_heat_v448
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp
import numpy as np
from scipy.optimize import brentq
from tqdm import tqdm

VERSION = "2026-08-25-v448-riesz-regulator-universality-heat-limit"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def rms(values: Iterable[float]) -> float:
    a = np.asarray(list(values), dtype=float)
    return float(np.sqrt(np.mean(a * a))) if a.size else float("nan")


def vector_rel_rms(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum(np.abs(bb), floor)
    return float(np.sqrt(np.mean(((aa - bb) / scale) ** 2)))


def symmetric_vector_drift(a: Sequence[float], b: Sequence[float], floor: float = 1e-300) -> float:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    scale = np.maximum.reduce([np.abs(aa), np.abs(bb), np.full_like(aa, floor)])
    return float(np.sqrt(np.mean(((aa - bb) / scale) ** 2)))


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(fieldnames))
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def module_sha(module) -> Dict[str, str]:
    p = Path(module.__file__).resolve()
    return {"path": str(p), "sha256": sha256_file(p)}


def import_required(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place the v445/v446 scripts in the same directory as v448 or pass "
            "--v445-module/--v446-module."
        )


def fmt_param(x: float) -> str:
    return f"{x:g}".replace("-", "m").replace(".", "p")


# =============================================================================
# Direct zero-ordinate-free theta target
# =============================================================================

class DirectThetaTarget:
    """High-precision theta-integral Euclidean resolvent M(z)."""

    def __init__(self, dps: int, quad_order: int, breakpoints: Sequence[float]) -> None:
        mp.mp.dps = int(dps)
        self.dps = int(dps)
        self.quad_order = int(quad_order)
        self.breakpoints = [mp.mpf(str(x)) for x in breakpoints]

        xg, wg = mp.gauss_quadrature(self.quad_order, "legendre")
        nodes: List[mp.mpf] = []
        weighted_phi: List[mp.mpf] = []
        for a, b in zip(self.breakpoints[:-1], self.breakpoints[1:]):
            mid = (a + b) / 2
            half = (b - a) / 2
            for i in range(self.quad_order):
                r = mid + half * xg[i]
                q = mp.e ** (-mp.pi * mp.e ** r)
                psi = (mp.jtheta(3, 0, q) - 1) / 2
                phi = psi * mp.e ** (r / 4)
                nodes.append(r)
                weighted_phi.append(half * wg[i] * phi)
        self.nodes = nodes
        self.weighted_phi = weighted_phi
        self.xi0 = self.N(mp.mpf("0"))

    def _I_Iz(self, z):
        z = mp.mpc(z) if isinstance(z, (complex, mp.mpc)) else mp.mpf(z)
        I = mp.mpc("0") if isinstance(z, mp.mpc) else mp.mpf("0")
        Iz = mp.mpc("0") if isinstance(z, mp.mpc) else mp.mpf("0")
        y = mp.sqrt(z)
        if abs(y) < mp.mpf("1e-40"):
            for r, w in zip(self.nodes, self.weighted_phi):
                I += w
                Iz += w * r * r / 8
        else:
            for r, w in zip(self.nodes, self.weighted_phi):
                a = y * r / 2
                I += w * mp.cosh(a)
                Iz += w * (r / (4 * y)) * mp.sinh(a)
        return I, Iz

    def N(self, z):
        I, _ = self._I_Iz(z)
        return mp.mpf("0.5") - (mp.mpf("0.25") - z) * I

    def M(self, z):
        I, Iz = self._I_Iz(z)
        N = mp.mpf("0.5") - (mp.mpf("0.25") - z) * I
        Np = I - (mp.mpf("0.25") - z) * Iz
        return Np / N

    def heat(self, u: mp.mpf, method: str, degree: int):
        return mp.invertlaplace(self.M, u, method=method, degree=int(degree))


# =============================================================================
# Regulator definitions and arithmetic phase quantization
# =============================================================================

@dataclass(frozen=True)
class Regulator:
    family: str
    parameter: float
    name: str


def build_regulators(riesz_orders: Sequence[float], bump_orders: Sequence[float], include_clock: bool) -> List[Regulator]:
    regs: List[Regulator] = []
    if include_clock:
        regs.append(Regulator("clock", 1.0, "clock"))
    for r in riesz_orders:
        if r <= 0:
            raise ValueError("Riesz orders must be positive")
        regs.append(Regulator("riesz", float(r), f"riesz_{fmt_param(r)}"))
    for p in bump_orders:
        if p <= 0:
            raise ValueError("bump orders must be positive")
        regs.append(Regulator("bump", float(p), f"bump_{fmt_param(p)}"))
    if not regs:
        raise ValueError("No regulators selected")
    return regs


def regulator_window(logs: np.ndarray, X: int, reg: Regulator) -> np.ndarray:
    L = math.log(float(X))
    x = logs / L
    if reg.family == "clock":
        # n^{-1/log X} = exp(-log n / log X)
        return np.exp(-x)
    if reg.family == "riesz":
        return np.power(np.maximum(0.0, 1.0 - x), reg.parameter)
    if reg.family == "bump":
        out = np.zeros_like(x)
        mask = x < 1.0
        xm = np.maximum(x[mask], 0.0)
        denom = np.maximum(1.0 - xm, 1e-300)
        y = xm / denom
        out[mask] = np.exp(-np.power(y, reg.parameter))
        return out
    raise ValueError(reg.family)


def weights_from_table(n: np.ndarray, lam: np.ndarray, X: int, reg: Regulator) -> Tuple[np.ndarray, np.ndarray]:
    nf = n.astype(float)
    logs = np.log(nf)
    base = lam / (logs * np.sqrt(nf))
    return logs, base * regulator_window(logs, X, reg)


def phase_sum(E: np.ndarray, logs: np.ndarray, w: np.ndarray, chunk: int) -> np.ndarray:
    e = np.atleast_1d(np.asarray(E, float))
    out = np.zeros(len(e), float)
    for j in range(0, len(logs), int(chunk)):
        out += np.sin(np.outer(e, logs[j:j+chunk])) @ w[j:j+chunk]
    return out


def quantize_regulator(
    v445,
    depth: int,
    X: int,
    reg: Regulator,
    free_ext: np.ndarray,
    n: np.ndarray,
    lam: np.ndarray,
    grid_points: int,
    prime_chunk: int,
) -> Dict[str, object]:
    free = np.asarray(free_ext[:depth], dtype=float)
    logs, w = weights_from_table(n, lam, X, reg)
    roots = np.zeros(depth, float)
    residuals = np.zeros(depth, float)
    counts = np.zeros(depth, int)

    def fvals(E: np.ndarray, target: float) -> np.ndarray:
        e = np.atleast_1d(np.asarray(E, float))
        sm = np.asarray([v445.smooth_count(x) for x in e], float)
        return sm - phase_sum(e, logs, w, prime_chunk) / math.pi - target

    desc = f"{reg.name} X={X}"
    for idx in tqdm(range(depth), desc=desc, unit="cell"):
        target = idx + 1 - 0.5
        lo = 7.0 if idx == 0 else 0.5 * (free[idx - 1] + free[idx])
        if idx + 1 < depth:
            hi = 0.5 * (free[idx] + free[idx + 1])
        else:
            hi = free[idx] + 0.5 * (free[idx] - free[idx - 1])

        grid = np.linspace(lo, hi, int(grid_points))
        vals = fvals(grid, target)
        crossings = np.flatnonzero(vals[:-1] * vals[1:] <= 0.0)
        counts[idx] = len(crossings)

        if len(crossings) == 0:
            j = int(np.argmin(np.abs(vals)))
            roots[idx] = grid[j]
            residuals[idx] = abs(vals[j])
            continue

        centers = 0.5 * (grid[crossings] + grid[crossings + 1])
        jcross = int(crossings[np.argmin(np.abs(centers - free[idx]))])
        r = brentq(
            lambda z: float(fvals(np.asarray([z]), target)[0]),
            float(grid[jcross]),
            float(grid[jcross + 1]),
            xtol=1e-13,
            rtol=1e-13,
            maxiter=400,
        )
        roots[idx] = r
        residuals[idx] = abs(float(fvals(np.asarray([r]), target)[0]))

    return {
        "regulator": reg.name,
        "family": reg.family,
        "parameter": reg.parameter,
        "cutoff": int(X),
        "roots": roots,
        "residuals": residuals,
        "counts": counts,
        "term_count": int(len(logs)),
        "weight_l1": float(np.sum(np.abs(w))),
        "weight_l2": float(np.linalg.norm(w)),
    }


# =============================================================================
# Heat/Jacobi helpers
# =============================================================================

def spectral_heat(levels: np.ndarray, u: float) -> float:
    e = np.asarray(levels, dtype=float)
    return float(np.sum(np.exp(-float(u) * e * e)))


def jacobi_at_dim(q: Sequence[mp.mpf], dim: int, support_scale: mp.mpf):
    q1 = q[0]
    moments = [q[k] / (q1 * support_scale**k) for k in range(len(q))]
    M0 = mp.matrix(dim)
    M1 = mp.matrix(dim)
    for i in range(dim):
        for j in range(dim):
            M0[i, j] = moments[i + j]
            M1[i, j] = moments[i + j + 1]
    L = mp.cholesky(M0)
    Linv = L**-1
    Jy = Linv * M1 * Linv.T
    Jy = (Jy + Jy.T) / 2
    J = support_scale * Jy
    evals, evecs = mp.eigsy(J)
    lam = [evals[i] for i in range(dim)]
    w = [evecs[0, i] ** 2 for i in range(dim)]
    return J, lam, w


def jacobi_heat(q1: mp.mpf, lam: Sequence[mp.mpf], w: Sequence[mp.mpf], u: mp.mpf):
    return mp.fsum([
        (q1 * w[i] / lam[i]) * mp.e ** (-u / lam[i])
        for i in range(len(lam)) if lam[i] > 0
    ])


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v448 Riesz/regulator universality heat-limit audit",
    )

    ap.add_argument("--v445-module", default="rot_rh_clock_theta_jacobi_v445")
    ap.add_argument("--v446-module", default="rot_rh_stieltjes_thorin_heat_v446")

    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--cutoffs", default="72900,145800,291600,583200")
    ap.add_argument("--riesz-orders", default="0.5,1,2,3")
    ap.add_argument("--bump-orders", default="1,2")
    ap.add_argument("--include-clock", action="store_true")
    ap.add_argument("--grid-points", type=int, default=64)
    ap.add_argument("--prime-chunk", type=int, default=20000)
    ap.add_argument("--depth-check-fraction", type=float, default=0.75)

    ap.add_argument("--moment-order", type=int, default=32)
    ap.add_argument("--jacobi-dim", type=int, default=16)
    ap.add_argument("--mp-dps", type=int, default=130)

    ap.add_argument("--heat-u", default="0.008,0.010,0.0125,0.015,0.020,0.030")
    ap.add_argument("--theta-quad-order", type=int, default=22)
    ap.add_argument("--theta-breakpoints", default="0,0.5,1,1.5,2,2.5,3,3.5,4,5,6")
    ap.add_argument("--stehfest-degree", type=int, default=22)
    ap.add_argument("--dehoog-degree", type=int, default=34)

    # Frozen interpretation gates.  These are intentionally prospective and
    # must not be tuned after inspecting the target errors of a run.
    ap.add_argument("--maximum-target-method-relative-gap", type=float, default=0.003)
    ap.add_argument("--maximum-jacobi-target-relative-rms", type=float, default=0.001)
    ap.add_argument("--maximum-final-target-relative-rms", type=float, default=0.005)
    ap.add_argument("--maximum-final-cutoff-drift", type=float, default=0.01)
    ap.add_argument("--maximum-final-regulator-spread", type=float, default=0.01)
    ap.add_argument("--minimum-universality-regulators", type=int, default=3)

    ap.add_argument("--prefix", default="rot_rh_regulator_universality_heat_v448")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.depth < 8:
        raise ValueError("--depth must be >= 8")
    if not (0.25 <= args.depth_check_fraction < 1.0):
        raise ValueError("--depth-check-fraction must lie in [0.25,1)")
    if args.moment_order < 2 * args.jacobi_dim:
        raise ValueError("--moment-order must be >= 2*--jacobi-dim")
    if args.stehfest_degree < 8 or args.dehoog_degree < 12:
        raise ValueError("inverse-Laplace degrees are too small")

    cutoffs = parse_ints(args.cutoffs)
    if len(cutoffs) < 3 or cutoffs != sorted(cutoffs):
        raise ValueError("--cutoffs must contain >=3 increasing values")
    heat_u = parse_floats(args.heat_u)
    if not heat_u or any(u <= 0 for u in heat_u):
        raise ValueError("--heat-u values must be positive")

    regs = build_regulators(
        parse_floats(args.riesz_orders),
        parse_floats(args.bump_orders),
        bool(args.include_clock),
    )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    v445 = import_required(args.v445_module)
    v446 = import_required(args.v446_module)
    mp.mp.dps = int(args.mp_dps)

    print("=" * 158)
    print("ROT-RH v448 — RIESZ / REGULATOR UNIVERSALITY HEAT-LIMIT AUDIT")
    print("=" * 158)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("direct theta heat target           : Stehfest + de Hoog inverse Laplace")
    print("positive operator consistency      : v446 Stieltjes/Jacobi K=H^-2")
    print("prime-side regulators              :", ", ".join(r.name for r in regs))
    print("cutoffs                            :", cutoffs)
    print("scientific test                    : target convergence + cutoff Cauchy + regulator collapse")
    print("=" * 158)

    # ---------------------------------------------------------------------
    # A. Direct theta heat target with two independent inversion algorithms.
    # ---------------------------------------------------------------------
    print("\n[A] Building dual-method direct theta heat target ...")
    target = DirectThetaTarget(
        dps=args.mp_dps,
        quad_order=args.theta_quad_order,
        breakpoints=parse_floats(args.theta_breakpoints),
    )
    target_rows: List[dict] = []
    target_heat: List[float] = []
    target_method_gaps: List[float] = []
    target_positive = True

    for uu in tqdm(heat_u, desc="theta inverse Laplace (2 methods)", unit="u"):
        u = mp.mpf(str(uu))
        ks = target.heat(u, "stehfest", args.stehfest_degree)
        kd = target.heat(u, "dehoog", args.dehoog_degree)
        gap = float(abs(ks - kd) / max(abs(kd), mp.mpf("1e-100")))
        positive = bool(mp.re(kd) > 0 and abs(mp.im(kd)) < mp.mpf("1e-45"))
        target_positive = target_positive and positive
        target_method_gaps.append(gap)
        kval = float(mp.re(kd))
        target_heat.append(kval)
        target_rows.append({
            "u": f"{uu:.17g}",
            "K_theta_stehfest": mp.nstr(ks, 75),
            "K_theta_dehoog": mp.nstr(kd, 75),
            "relative_method_gap": f"{gap:.17g}",
            "reference_method": "dehoog",
            "positive": positive,
        })

    target_path = Path(str(prefix) + "_THETA_HEAT_DUAL.csv")
    write_csv(target_path, list(target_rows[0].keys()), target_rows)
    max_target_gap = max(target_method_gaps)
    target_numerics_pass = bool(target_positive and max_target_gap <= args.maximum_target_method_relative_gap)

    # ---------------------------------------------------------------------
    # B. v446 positive Jacobi consistency route.
    # ---------------------------------------------------------------------
    print("\n[B] Building v446 Jacobi heat consistency check ...")
    c, unit, q = v446.theta_data(args.moment_order, args.mp_dps)
    q1 = q[0]
    support_scale, hankel_rows, _, _, _, _ = v446.stieltjes_jacobi(q, args.jacobi_dim)
    J, lamj, wj = jacobi_at_dim(q, args.jacobi_dim, support_scale)
    jacobi_vec: List[float] = []
    jacobi_rows: List[dict] = []
    for uu, kt in zip(heat_u, target_heat):
        kj = float(mp.re(jacobi_heat(q1, lamj, wj, mp.mpf(str(uu)))))
        jacobi_vec.append(kj)
        jacobi_rows.append({
            "u": f"{uu:.17g}",
            "K_jacobi": f"{kj:.17g}",
            "K_theta_dehoog": f"{kt:.17g}",
            "relative_error": f"{abs(kj-kt)/max(abs(kt),1e-300):.17g}",
        })
    jacobi_rms = vector_rel_rms(jacobi_vec, target_heat)
    jacobi_path = Path(str(prefix) + "_JACOBI_HEAT.csv")
    write_csv(jacobi_path, list(jacobi_rows[0].keys()), jacobi_rows)
    jacobi_pass = jacobi_rms <= args.maximum_jacobi_target_relative_rms

    # ---------------------------------------------------------------------
    # C. Prime-side spectra. Cache one Mangoldt table per cutoff and reuse it
    #    across every regulator family.
    # ---------------------------------------------------------------------
    print("\n[C] Building regulator family spectra ...")
    free_ext = v445.free_archimedean_levels(args.depth)
    free = np.asarray(free_ext[:args.depth], dtype=float)
    check_depth = max(4, int(math.floor(args.depth * args.depth_check_fraction)))

    heat_rows: List[dict] = []
    summary_rows: List[dict] = []
    vectors: Dict[Tuple[str, int], List[float]] = {}
    root_records: Dict[Tuple[str, int], Dict[str, object]] = {}

    free_vec = [spectral_heat(free, u) for u in heat_u]
    free_rms = vector_rel_rms(free_vec, target_heat)

    for X in cutoffs:
        print(f"\n  [Mangoldt cache] X={X}")
        n, lam = v445.mangoldt_terms(int(X))
        for reg in regs:
            rec = quantize_regulator(
                v445=v445,
                depth=args.depth,
                X=int(X),
                reg=reg,
                free_ext=free_ext,
                n=n,
                lam=lam,
                grid_points=args.grid_points,
                prime_chunk=args.prime_chunk,
            )
            root_records[(reg.name, int(X))] = rec
            roots = np.asarray(rec["roots"], dtype=float)
            vec: List[float] = []
            tail_proxy: List[float] = []
            rels: List[float] = []
            for uu, kt in zip(heat_u, target_heat):
                kfull = spectral_heat(roots, uu)
                kcheck = spectral_heat(roots[:check_depth], uu)
                tail = abs(kfull-kcheck)/max(abs(kfull),1e-300)
                er = abs(kfull-kt)/max(abs(kt),1e-300)
                vec.append(kfull)
                tail_proxy.append(tail)
                rels.append(er)
                heat_rows.append({
                    "regulator": reg.name,
                    "family": reg.family,
                    "parameter": f"{reg.parameter:.17g}",
                    "cutoff": int(X),
                    "u": f"{uu:.17g}",
                    "K_model": f"{kfull:.17g}",
                    "K_theta_target": f"{kt:.17g}",
                    "relative_error_to_target": f"{er:.17g}",
                    "relative_depth_tail_proxy": f"{tail:.17g}",
                })
            vectors[(reg.name, int(X))] = vec
            summary_rows.append({
                "regulator": reg.name,
                "family": reg.family,
                "parameter": f"{reg.parameter:.17g}",
                "cutoff": int(X),
                "heat_relative_rms": f"{rms(rels):.17g}",
                "heat_relative_max": f"{max(rels):.17g}",
                "max_depth_tail_proxy": f"{max(tail_proxy):.17g}",
                "max_quantization_residual": f"{float(np.max(rec['residuals'])):.17g}",
                "missing_cells": int(np.sum(np.asarray(rec["counts"]) == 0)),
                "ambiguous_cells": int(np.sum(np.asarray(rec["counts"]) > 1)),
                "term_count": int(rec["term_count"]),
                "weight_l1": f"{float(rec['weight_l1']):.17g}",
                "weight_l2": f"{float(rec['weight_l2']):.17g}",
            })

    heat_path = Path(str(prefix) + "_REGULATOR_HEAT.csv")
    write_csv(heat_path, list(heat_rows[0].keys()), heat_rows)
    summary_table_path = Path(str(prefix) + "_REGULATOR_SUMMARY.csv")
    write_csv(summary_table_path, list(summary_rows[0].keys()), summary_rows)

    # ---------------------------------------------------------------------
    # D. Within-family cutoff Cauchy drift B_X(r).
    # ---------------------------------------------------------------------
    print("\n[D] Auditing within-regulator cutoff Cauchy drift ...")
    drift_rows: List[dict] = []
    drift_by_reg: Dict[str, List[float]] = {r.name: [] for r in regs}
    for reg in regs:
        for xa, xb in zip(cutoffs[:-1], cutoffs[1:]):
            d = symmetric_vector_drift(vectors[(reg.name, xa)], vectors[(reg.name, xb)])
            drift_by_reg[reg.name].append(d)
            drift_rows.append({
                "regulator": reg.name,
                "family": reg.family,
                "parameter": f"{reg.parameter:.17g}",
                "cutoff_from": xa,
                "cutoff_to": xb,
                "successive_heat_vector_relative_rms": f"{d:.17g}",
            })
    drift_path = Path(str(prefix) + "_CUTOFF_DRIFT.csv")
    write_csv(drift_path, list(drift_rows[0].keys()), drift_rows)

    # ---------------------------------------------------------------------
    # E. Cross-regulator universality C_X(r,s).
    # ---------------------------------------------------------------------
    print("\n[E] Auditing cross-regulator universality ...")
    universality_rows: List[dict] = []
    spread_by_cutoff: Dict[int, float] = {}
    pair_values_by_cutoff: Dict[int, List[float]] = {}
    for X in cutoffs:
        vals: List[float] = []
        for i in range(len(regs)):
            for j in range(i+1, len(regs)):
                ri, rj = regs[i], regs[j]
                d = symmetric_vector_drift(vectors[(ri.name, X)], vectors[(rj.name, X)])
                vals.append(d)
                universality_rows.append({
                    "cutoff": X,
                    "regulator_a": ri.name,
                    "regulator_b": rj.name,
                    "pair_heat_vector_relative_rms": f"{d:.17g}",
                })
        pair_values_by_cutoff[X] = vals
        spread_by_cutoff[X] = max(vals) if vals else float("nan")
    universality_path = Path(str(prefix) + "_REGULATOR_UNIVERSALITY.csv")
    write_csv(universality_path, list(universality_rows[0].keys()), universality_rows)

    # A less brittle central-cluster spread excluding the clock regulator.  This
    # is diagnostic only and never substitutes for the all-regulator verdict.
    compact_regs = [r for r in regs if r.family in ("riesz", "bump")]
    compact_spread_by_cutoff: Dict[int, float] = {}
    if len(compact_regs) >= 2:
        for X in cutoffs:
            vv = []
            for i in range(len(compact_regs)):
                for j in range(i+1, len(compact_regs)):
                    vv.append(symmetric_vector_drift(
                        vectors[(compact_regs[i].name, X)],
                        vectors[(compact_regs[j].name, X)],
                    ))
            compact_spread_by_cutoff[X] = max(vv)

    # ---------------------------------------------------------------------
    # F. Prospective trend diagnostics.  No best-cutoff selection is used in
    #    the verdict.  Only the final cutoff and tail drifts/spreads matter.
    # ---------------------------------------------------------------------
    def error_of(regname: str, X: int) -> float:
        return vector_rel_rms(vectors[(regname, X)], target_heat)

    final_X = cutoffs[-1]
    final_errors = {r.name: error_of(r.name, final_X) for r in regs}
    final_drifts = {r.name: drift_by_reg[r.name][-1] for r in regs}
    final_all_spread = spread_by_cutoff[final_X]
    final_compact_spread = compact_spread_by_cutoff.get(final_X, float("nan"))

    eligible = [
        r.name for r in regs
        if final_errors[r.name] <= args.maximum_final_target_relative_rms
        and final_drifts[r.name] <= args.maximum_final_cutoff_drift
    ]

    # Tail trend: require the last drift to improve relative to the preceding
    # drift when at least two drift observations are available.
    tail_shrinking = {
        r.name: (
            len(drift_by_reg[r.name]) >= 2
            and drift_by_reg[r.name][-1] < drift_by_reg[r.name][-2]
        )
        for r in regs
    }
    eligible_shrinking = [name for name in eligible if tail_shrinking[name]]

    compact_universality_pass = (
        len(compact_regs) >= args.minimum_universality_regulators
        and math.isfinite(final_compact_spread)
        and final_compact_spread <= args.maximum_final_regulator_spread
    )
    all_regulator_universality_pass = (
        len(regs) >= args.minimum_universality_regulators
        and final_all_spread <= args.maximum_final_regulator_spread
    )

    if not target_numerics_pass:
        verdict = "TARGET_DUAL_INVERSION_NOT_STABLE_ENOUGH"
    elif not jacobi_pass:
        verdict = "THETA_TARGET_OK_BUT_JACOBI_HEAT_CONSISTENCY_FAILED"
    elif all_regulator_universality_pass and len(eligible_shrinking) >= args.minimum_universality_regulators:
        verdict = "FINITE_REGULATOR_UNIVERSALITY_SUPPORTED_PROSPECTIVELY"
    elif compact_universality_pass and len([n for n in eligible_shrinking if not n.startswith("clock")]) >= args.minimum_universality_regulators:
        verdict = "COMPACT_RIESZ_BUMP_UNIVERSALITY_SUPPORTED__CLOCK_OUTLIER"
    elif len(eligible) >= args.minimum_universality_regulators:
        verdict = "FINITE_COMMON_NEIGHBORHOOD_ONLY__TAIL_CAUCHY_NOT_ESTABLISHED"
    else:
        verdict = "REGULATOR_UNIVERSALITY_NOT_YET_SUPPORTED"

    # ---------------------------------------------------------------------
    # Outputs / freeze manifest / summary.
    # ---------------------------------------------------------------------
    manifest = {
        "version": VERSION,
        "firewall": {
            "known_zero_ordinates_used": False,
            "zeta_used": False,
            "Xi_function_called": False,
            "theta_integral_used": True,
        },
        "modules": {"v445": module_sha(v445), "v446": module_sha(v446)},
        "parameters": vars(args),
        "regulators": [r.__dict__ for r in regs],
        "derived": {
            "theta_xi0_direct": mp.nstr(target.xi0, 80),
            "theta_xi0_moment": mp.nstr(c[0], 80),
            "theta_xi0_route_relative_gap": float(abs(target.xi0-c[0])/max(abs(target.xi0),mp.mpf("1e-100"))),
            "q1": mp.nstr(q1, 80),
            "support_scale": mp.nstr(support_scale, 80),
            "check_depth": check_depth,
        },
    }
    manifest_path = Path(str(prefix) + "_FREEZE.json")
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time() - t0,
        "verdict": verdict,
        "scientific_boundary": (
            "Finite zero-ordinate-free audit only. Prospective regulator collapse is not an analytic "
            "operator-limit theorem and does not prove all-order Stieltjes positivity or RH."
        ),
        "target": {
            "reference_method": "dehoog",
            "maximum_stehfest_vs_dehoog_relative_gap": max_target_gap,
            "all_dehoog_heat_values_positive": bool(target_positive),
            "dual_inversion_pass": bool(target_numerics_pass),
        },
        "jacobi": {
            "dim": args.jacobi_dim,
            "heat_relative_rms_to_dehoog": jacobi_rms,
            "pass": bool(jacobi_pass),
            "minimum_final_H0_pivot": hankel_rows[-1]["min_cholesky_pivot_H0"],
            "minimum_final_H1_pivot": hankel_rows[-1]["min_cholesky_pivot_H1"],
        },
        "free_gamma_heat_relative_rms": free_rms,
        "final_cutoff": final_X,
        "final_errors": final_errors,
        "final_successive_cutoff_drifts": final_drifts,
        "tail_drift_shrinking": tail_shrinking,
        "eligible_final_error_and_drift": eligible,
        "eligible_with_shrinking_tail_drift": eligible_shrinking,
        "cross_regulator": {
            "maximum_pairwise_spread_by_cutoff": {str(k): v for k, v in spread_by_cutoff.items()},
            "maximum_compact_riesz_bump_spread_by_cutoff": {str(k): v for k, v in compact_spread_by_cutoff.items()},
            "final_all_regulator_spread": final_all_spread,
            "final_compact_riesz_bump_spread": final_compact_spread,
            "all_regulator_universality_pass": bool(all_regulator_universality_pass),
            "compact_riesz_bump_universality_pass": bool(compact_universality_pass),
        },
        "gates": {
            "maximum_target_method_relative_gap": args.maximum_target_method_relative_gap,
            "maximum_jacobi_target_relative_rms": args.maximum_jacobi_target_relative_rms,
            "maximum_final_target_relative_rms": args.maximum_final_target_relative_rms,
            "maximum_final_cutoff_drift": args.maximum_final_cutoff_drift,
            "maximum_final_regulator_spread": args.maximum_final_regulator_spread,
            "minimum_universality_regulators": args.minimum_universality_regulators,
        },
        "outputs": {
            "theta_heat_dual": target_path.name,
            "jacobi_heat": jacobi_path.name,
            "regulator_heat": heat_path.name,
            "regulator_summary": summary_table_path.name,
            "cutoff_drift": drift_path.name,
            "regulator_universality": universality_path.name,
            "freeze_manifest": manifest_path.name,
        },
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("KEY RESULTS")
    print("=" * 158)
    print("verdict                                  :", verdict)
    print("dual theta inversion stable              :", target_numerics_pass)
    print("max Stehfest/de Hoog gap                 :", f"{max_target_gap:.6e}")
    print("Jacobi heat RMS vs de Hoog               :", f"{jacobi_rms:.6e}")
    print("free Gamma heat RMS                      :", f"{free_rms:.6e}")
    print("\nfinal-cutoff regulator diagnostics       : X=", final_X, sep="")
    for reg in regs:
        print(
            f"  {reg.name:<14s} target={final_errors[reg.name]:.6e}  "
            f"drift={final_drifts[reg.name]:.6e}  "
            f"tail_shrinking={tail_shrinking[reg.name]}"
        )
    print("\nmax pairwise regulator spread trajectory :")
    for X in cutoffs:
        compact = compact_spread_by_cutoff.get(X, float("nan"))
        print(f"  X={X:<10d} all={spread_by_cutoff[X]:.6e}  compact={compact:.6e}")
    print("eligible + shrinking tail                :", eligible_shrinking)
    print("summary                                   :", summary_path)
    print("=" * 158)

    if args.strict and not (
        target_numerics_pass
        and jacobi_pass
        and verdict in (
            "FINITE_REGULATOR_UNIVERSALITY_SUPPORTED_PROSPECTIVELY",
            "COMPACT_RIESZ_BUMP_UNIVERSALITY_SUPPORTED__CLOCK_OUTLIER",
        )
    ):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
