#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v474 — NONATTAINED COHERENCE/SPREAD DICHOTOMY
====================================================

PURPOSE
-------
Sharpen the final v409-v411 exceptional-cancellation sector.

For a grouped positive-ordinate collective resonance family write

    H = sum_j b_j,
    G = sum_j gamma_j b_j,
    D = sum_j delta_j b_j,

with gamma_j>=0 and 0<=delta_j<=1.  Let

    W0 = sum |b_j|,
    W1 = sum gamma_j |b_j|,
    mu = W1/W0,

and define the normalized coherence

    c = |H|/W0.

Also define the absolute first centered frequency spread

    A1 = sum |gamma_j-mu| |b_j|,
    s  = A1/(mu W0).

Then

    G = mu H + R,
    |R| <= A1,

so exactly

    Re(G conj(H))
      >= mu |H|^2 - A1 |H|
      = mu W0^2 c(c-s).

The exact phase identity from v409 is

    omega |H|^2
      = -Im(D conj(H)) + Re(G conj(H)),

where omega=partial_t arg H.

Since |D|<=W0 and |H|<=W0, a bounded phase velocity |omega|<=C implies

    |Re(G conj(H))| <= (C+1) W0^2.

Using the exact |H|-dependent upper bound,

    |Re(G conj(H))|
      <= C |H|^2 + |D||H|
      <= W0^2 (C c^2 + c).

Combining with the lower bound gives, for c>0,

    mu(c-s) <= C c + 1.

Hence whenever mu>C,

    c <= (mu s + 1)/(mu-C)
      = (s + 1/mu)/(1-C/mu).

This formula also trivially covers c<=s.

Thus, if the absolute mean frequency escapes

    mu -> infinity

(as proved in the nonattained sector by v409/v410 and reproduced
bump-specifically after v473), then:

NARROW-BAND CONSEQUENCE
-----------------------
If

    s -> 0,

then

    c -> 0.

So a bounded physical phase velocity cannot coexist with both

    (i) relative frequency concentration, and
    (ii) a noncollapsed collective amplitude.

Using the RMS spread

    sigma^2
      = sum (gamma_j-mu)^2 |b_j| / W0,

Cauchy-Schwarz gives

    s <= sigma/mu =: CV.

Therefore, for mu>C,

    c <= (CV + 1/mu)/(1-C/mu).

In particular, if CV->0 and mu->infinity then c->0.

Conversely, if there is an eventual noncollapse

    c >= kappa > 0,

then bounded phase velocity forces

    s >= kappa - O(1/(kappa mu)),

and hence

    CV >= kappa - O(1/mu).

So every noncollapsed bounded nonattained branch must remain genuinely
BROAD-BAND in relative frequency.

INTERPRETATION
--------------
The final nonattained sector splits into only two exceptional mechanisms:

  A. AMPLITUDE COLLAPSE:
         |H|/W0 -> 0
     (persistent destructive cancellation of the collective amplitude);

  B. BROAD-BAND SUPPORT:
         sigma/mu not -> 0
     (the active mass never concentrates around one escaping frequency scale).

An isolated winner, narrow moving cluster, or any frequency-concentrated
escaping packet is therefore excluded from supporting a bounded phase branch
unless its total amplitude collapses.

This is stronger than v409's first-moment statement because it converts the
required projected cancellation into a quantitative coherence/spread
dichotomy.

It does not exclude the broad-band/amplitude-collapse exceptional set itself.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v474-nonattained-coherence-spread-dichotomy"


def symbolic_check() -> Dict[str, Any]:
    import sympy as sp
    mu, c, s, C = sp.symbols(
        "mu c s C", positive=True, real=True
    )
    # mu(c-s) <= C c + 1
    # => (mu-C)c <= mu s + 1
    root = sp.simplify((mu*s+1)/(mu-C))
    residual = sp.simplify(
        (mu-C)*root-(mu*s+1)
    )
    return {
        "sharp_coherence_upper": str(root),
        "linear_rearrangement_residual": str(residual),
        "pass": bool(residual == 0),
    }


def finite_vector_check(seed: int = 7, trials: int = 5000) -> Dict[str, Any]:
    rng = random.Random(seed)
    worst = 0.0
    violations = 0
    for _ in tqdm(range(trials), desc="v474 finite vectors", unit="trial", leave=False):
        n = rng.randint(2, 12)
        gammas = [10**rng.uniform(0.0, 3.0) for _ in range(n)]
        mags = [10**rng.uniform(-2.0, 1.0) for _ in range(n)]
        phases = [rng.uniform(-math.pi, math.pi) for _ in range(n)]
        b = [
            mags[j]*complex(math.cos(phases[j]), math.sin(phases[j]))
            for j in range(n)
        ]
        W0 = sum(abs(z) for z in b)
        mu = sum(gammas[j]*abs(b[j]) for j in range(n))/W0
        H = sum(b)
        G = sum(gammas[j]*b[j] for j in range(n))
        A1 = sum(abs(gammas[j]-mu)*abs(b[j]) for j in range(n))
        lhs = (G*H.conjugate()).real
        rhs = mu*abs(H)**2-A1*abs(H)
        defect = rhs-lhs
        worst = max(worst, defect)
        if defect > 2e-10*max(1.0, abs(lhs), abs(rhs)):
            violations += 1
    return {
        "trials": trials,
        "max_rhs_minus_lhs": worst,
        "violations": violations,
        "pass": violations == 0,
    }


def bound_panel(C: float):
    rows = []
    for mu in (10.0, 100.0, 1e3, 1e5):
        for cv in (0.0, 0.05, 0.20, 0.50):
            bound = (
                (cv+1.0/mu)/(1.0-C/mu)
                if mu > C else float("inf")
            )
            rows.append({
                "mu": mu,
                "CV": cv,
                "coherence_upper": bound,
            })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v474 — nonattained coherence/spread dichotomy

For

`H=sum b_j`,
`G=sum gamma_j b_j`,
`W0=sum|b_j|`,
`mu=sum gamma_j|b_j|/W0`,

define

`c=|H|/W0`

and

`s=sum |gamma_j-mu||b_j|/(mu W0)`.

Because

`G=mu H+R`,
`|R|<=mu W0 s`,

we have exactly

`Re(G Hbar)>=mu W0^2 c(c-s)`.

The v409 phase identity plus `|delta_j|<=1` implies that
`|omega|<=C` gives

the sharper exact bound is

`|Re(G Hbar)| <= W0^2(C c^2+c)`.

Combining with the lower bound and dividing by `c>0` gives

`mu(c-s)<=C c+1`.

Thus, whenever `mu>C`,

`c <= (s+1/mu)/(1-C/mu)`.

If

`CV=sigma/mu`

is the absolute-weighted coefficient of variation of the frequencies,
Cauchy-Schwarz gives `s<=CV`, hence

`c <= (CV+1/mu)/(1-C/mu)`.

Since the nonattained sector has `mu->infinity`:

* `CV->0` forces `c->0`;
* if `c>=kappa>0`, then necessarily `CV>=kappa-o(1)`.

Thus a bounded nonattained branch can no longer be supported by a coherent
narrow moving packet.  It must be either:

1. **amplitude-collapsed**: `|H|/W0->0`; or
2. **genuinely broad-band**: relative frequency spread does not vanish.

**Verdict:** {payload['verdict']}

This does not yet exclude those two exceptional sectors.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_NONATTAINED_COHERENCE_SPREAD_V1",
        "closed": {
            "centered_decomposition": "G=mu H+R, |R|<=A1",
            "projection_lower":
                "Re(G Hbar)>=mu W0^2 c(c-s)",
            "bounded_velocity_upper":
                "|Re(G Hbar)|<=(C+1)W0^2",
            "coherence_bound":
                "c<=(s+1/mu)/(1-C/mu) for mu>C",
            "RMS_corollary":
                "replace s by CV=sigma/mu",
            "narrow_band":
                "mu->infinity and CV->0 => |H|/W0<=CV+o(1)->0",
            "noncollapse":
                "c>=kappa forces CV>=kappa-o(1)",
        },
        "remaining": {
            "amplitude_collapse":
                "classify persistent zeros/small values of the collective amplitude on the physical diagonal",
            "broad_band":
                "show broad relative frequency support cannot satisfy the short-window lock transfer, or derive its primitive-beta law",
        },
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase-velocity-C", type=float, default=2.0)
    ap.add_argument("--trials", type=int, default=5000)
    ap.add_argument("--prefix", default="rot_rh_nonattained_coherence_spread_v474")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*190)
    print("ROT-RH v474 — NONATTAINED COHERENCE/SPREAD DICHOTOMY")
    print("="*190)
    with tqdm(total=3, desc="v474 theorem", unit="step") as bar:
        sym = symbolic_check()
        bar.update(1)
        finite = finite_vector_check(trials=args.trials)
        bar.update(1)
        panel = bound_panel(args.phase_velocity_C)
        bar.update(1)

    passed = bool(sym["pass"] and finite["pass"])
    verdict = (
        "EXACT_NONATTAINED_COHERENCE_SPREAD_DICHOTOMY_PASS"
        if passed else
        "NONATTAINED_COHERENCE_SPREAD_CHECK_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "finite_sanity": finite,
        "bound_panel": panel,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_sanity_used_as_proof": False,
        },
        "proof_status":
            "Exact finite-dimensional inequality applied to the already-established nonattained frequency escape. Broad-band/amplitude-collapse sector remains open.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("symbolic                       :", sym["pass"])
    print("finite-vector sanity           :", finite["pass"])
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
