#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v454 — BUMP-2 FINITE-PART MOVING-SHELL / RESONANCE AUTOPSY
===================================================================

PURPOSE
-------
v453 verified, to high numerical accuracy, the exact implicit/Duhamel flow

    dE_k/dL = -F_L/F_E,      L = log X,

but a simple modewise monotone decay extrapolation failed on the held-out
interval.  v454 asks whether the finite-part source is instead controlled by a
moving logarithmic-shell resonance.

For the frozen bump-2 window

    phi(x) = exp(-(x/(1-x))^2),  0 <= x < 1,

write the exact finite-part L-source as

    S_k(L) = partial_L P_L(E_k) - partial_L M_L(E_k),

where P is the Mangoldt prime-power sum and M is its PNT carrier.  v454 splits
S_k into fixed normalized shells

    x = log n / log X in [b_j,b_{j+1}),

and records, shell by shell,

    S_{k,j} = S^prime_{k,j} - S^PNT_{k,j}.

It then freezes a LOW-DIMENSIONAL phase-tied carrier model from TRAINING data.
For each mode, only a few training-dominant shell centers c_j are used:

    S_hat_k(L) = L^{-q} [a0 + sum_j {a_j sin(E*_k c_j L)
                                      + b_j cos(E*_k c_j L)}],

where E*_k is the FINAL TRAINING root and q is chosen by blocked validation on
training data only.  The final doubling is untouched until the selected bins,
q, coefficients, prediction trajectory, and gates are SHA256-frozen.

The held-out score asks whether the carrier predicts the FULL source trajectory,
beats both zero and last-value baselines, preserves the dominant shell region,
and leaves a substantially smaller resonance-subtracted remainder.

SCIENTIFIC BOUNDARY
-------------------
This is a finite prospective mechanism audit.  It does not prove an all-L
resonance expansion, source integrability, cutoff independence, or RH.

Required local module:
    rot_rh_bump2_finite_part_source_flow_v452.py
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.special import roots_legendre
from tqdm import tqdm

VERSION = "2026-08-26-v454-bump2-moving-shell-resonance"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def rms(x: Sequence[float]) -> float:
    a = np.asarray(x, float)
    return float(np.sqrt(np.mean(a*a))) if a.size else float("nan")


def corr(a: Sequence[float], b: Sequence[float]) -> float:
    x = np.asarray(a, float); y = np.asarray(b, float)
    if x.size < 3 or float(np.std(x)) < 1e-300 or float(np.std(y)) < 1e-300:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def sign_accuracy(a: Sequence[float], b: Sequence[float], tol: float = 1e-15) -> float:
    x = np.asarray(a, float); y = np.asarray(b, float)
    m = np.abs(x) > tol
    if not np.any(m):
        return 1.0
    return float(np.mean(np.sign(x[m]) == np.sign(y[m])))


def safe_rel(a: float, b: float, floor: float = 1e-14) -> float:
    return abs(float(a)-float(b))/max(abs(float(a)), abs(float(b)), float(floor))


def json_safe(obj):
    if isinstance(obj, (np.integer,)): return int(obj)
    if isinstance(obj, (np.floating,)): return float(obj)
    if isinstance(obj, np.ndarray): return [json_safe(x) for x in obj.tolist()]
    if isinstance(obj, dict): return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)): return [json_safe(x) for x in obj]
    return obj


def import_v452(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise SystemExit(
            f"ERROR: could not import {name!r}: {exc}\n"
            "Place rot_rh_bump2_finite_part_source_flow_v452.py beside v454, "
            "or pass --v452-module."
        )


# =============================================================================
# Phase/root helpers
# =============================================================================

def make_phase(v452, n_all: np.ndarray, lam_all: np.ndarray, X: float,
               pnt_q: int, prime_chunk: int):
    idx = int(np.searchsorted(n_all, float(X), side="left"))
    return v452.FinitePartBump2(
        n_all[:idx], lam_all[:idx], float(X), int(pnt_q), int(prime_chunk)
    )


def quantize_silent(v452, phase, modes: Sequence[int], free: np.ndarray,
                    previous: Dict[int, float] | None,
                    root_tol: float, max_newton: int,
                    scan_points: int) -> Dict[int, object]:
    out: Dict[int, object] = {}
    previous_ordered: float | None = None
    for k in modes:
        seed = float(previous[int(k)]) if previous and int(k) in previous else float(free[int(k)-1])
        if int(k) == 1:
            spacing = float(free[1]-free[0]) if len(free) > 1 else 2.0
        elif int(k) < len(free):
            spacing = 0.5*float(free[int(k)]-free[int(k)-2])
        else:
            spacing = float(free[-1]-free[-2])
        rr = v452.locate_root(
            phase, int(k), seed, spacing, previous_ordered,
            float(root_tol), int(max_newton), int(scan_points)
        )
        out[int(k)] = rr
        if rr.ok:
            previous_ordered = float(rr.root)
    return out


# =============================================================================
# Exact normalized shell decomposition
# =============================================================================

def shell_decompose_source(v452, phase, E_values: np.ndarray,
                           bin_edges: np.ndarray, shell_q: int,
                           prime_chunk: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return prime_L, pnt_L, finite_L arrays of shape (nmodes, nbins)."""
    E_values = np.asarray(E_values, float)
    nb = len(bin_edges)-1
    nm = len(E_values)
    prime = np.zeros((nm, nb), float)
    pnt = np.zeros((nm, nb), float)
    L = float(phase.L)

    # Prime source: exact partition of the already-built w_L array.
    logs = np.asarray(phase.logs, float)
    wL = np.asarray(phase.w_L, float)
    for b in range(nb):
        lo_y = float(bin_edges[b])*L
        hi_y = float(bin_edges[b+1])*L
        ia = int(np.searchsorted(logs, lo_y, side="left"))
        ib = int(np.searchsorted(logs, hi_y, side="left"))
        for a in range(ia, ib, int(prime_chunk)):
            z = min(ib, a+int(prime_chunk))
            if z <= a: continue
            lg = logs[a:z]; ww = wL[a:z]
            prime[:, b] += np.sin(np.outer(E_values, lg)) @ ww

    # PNT carrier: independent Gauss-Legendre rule INSIDE every fixed x-bin.
    zg, wg = roots_legendre(int(shell_q))
    y_floor = math.log(2.0)
    for b in range(nb):
        a = max(y_floor, float(bin_edges[b])*L)
        c = min(L, float(bin_edges[b+1])*L)
        if c <= a:
            continue
        y = 0.5*(c-a)*zg + 0.5*(c+a)
        jac = 0.5*(c-a)
        _, dphi = v452.bump2_and_dL(y, L)
        ww = jac*wg*np.exp(0.5*y)*dphi/y
        pnt[:, b] = np.sin(np.outer(E_values, y)) @ ww

    return prime, pnt, prime-pnt


def analytic_window_G(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, float)
    out = np.zeros_like(x)
    m = (x > 0.0) & (x < 1.0)
    z = x[m]
    out[m] = 2.0*z*z/(1.0-z)**3 * np.exp(-(z/(1.0-z))**2)
    return out


def bare_window_peak() -> float:
    x = np.linspace(1e-5, 0.99999, 200000)
    return float(x[int(np.argmax(analytic_window_G(x)))])


def pnt_effective_peak(L: float) -> float:
    # Up to L-only constants, absolute PNT source carrier in normalized x is
    # exp(Lx/2) * G(x)/x.  This is a diagnostic only, not a fitted parameter.
    x = np.linspace(max(math.log(2.0)/float(L), 1e-4), 0.9999, 120000)
    G = analytic_window_G(x)
    logw = 0.5*float(L)*x + np.log(np.maximum(G, 1e-300)) - np.log(x)
    return float(x[int(np.argmax(logw))])


# =============================================================================
# Carrier regression
# =============================================================================

def carrier_matrix(L: np.ndarray, E_ref: float, centers: Sequence[float], q: float) -> np.ndarray:
    L = np.asarray(L, float)
    env = np.power(L, -float(q))
    cols = [env]
    for c in centers:
        ph = float(E_ref)*float(c)*L
        cols.append(env*np.sin(ph))
        cols.append(env*np.cos(ph))
    return np.column_stack(cols)


def ridge_fit(A: np.ndarray, y: np.ndarray, ridge: float) -> Tuple[np.ndarray, np.ndarray]:
    A = np.asarray(A, float); y = np.asarray(y, float)
    scale = np.sqrt(np.mean(A*A, axis=0))
    scale = np.maximum(scale, 1e-15)
    Z = A/scale
    M = Z.T@Z + float(ridge)*np.eye(Z.shape[1])
    beta_z = np.linalg.solve(M, Z.T@y)
    beta = beta_z/scale
    return beta, A@beta


def carrier_predict(L: np.ndarray, E_ref: float, centers: Sequence[float], q: float,
                    beta: Sequence[float]) -> np.ndarray:
    return carrier_matrix(np.asarray(L,float), E_ref, centers, q) @ np.asarray(beta,float)


def top_bins_from_rows(shell_rows: List[dict], mode: int, interval_max: int,
                       top_k: int, nbins: int) -> List[int]:
    score = np.zeros(nbins, float)
    count = np.zeros(nbins, int)
    for r in shell_rows:
        if int(r["mode"]) != int(mode) or int(r["interval_index"]) > int(interval_max):
            continue
        b = int(r["bin"])
        val = float(r["finite_source"])
        score[b] += val*val; count[b] += 1
    m = count > 0
    score[m] = np.sqrt(score[m]/count[m])
    order = np.argsort(-score)
    return [int(x) for x in order[:int(top_k)]]


def choose_carrier_q(L: np.ndarray, y: np.ndarray, interval_idx: np.ndarray,
                     E_ref: float, centers: Sequence[float], q_grid: Sequence[float],
                     ridge: float) -> dict:
    val_interval = int(np.max(interval_idx))
    fit_mask = interval_idx < val_interval
    val_mask = interval_idx == val_interval
    if np.sum(fit_mask) < 8 or np.sum(val_mask) < 3:
        fit_mask = np.ones_like(interval_idx, dtype=bool)
        val_mask = np.ones_like(interval_idx, dtype=bool)
    last_pre = float(y[np.flatnonzero(fit_mask)[-1]])
    records=[]
    for q in q_grid:
        A0 = carrier_matrix(L[fit_mask], E_ref, centers, q)
        beta,_ = ridge_fit(A0, y[fit_mask], ridge)
        pred = carrier_predict(L[val_mask], E_ref, centers, q, beta)
        yy = y[val_mask]
        er = rms(yy-pred)
        zero = rms(yy)
        last = rms(yy-last_pre)
        base = min(zero,last)
        records.append({
            "q":float(q), "validation_rmse":er,
            "validation_baseline_rmse":base,
            "validation_ratio": er/max(base,1e-300),
            "validation_corr": corr(yy,pred),
            "validation_sign_accuracy": sign_accuracy(yy,pred),
        })
    best = min(records, key=lambda r:(r["validation_ratio"], r["validation_rmse"]))
    return {"best":best, "candidates":records}


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("--v452-module", default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--cutoffs", default="583200,1166400,2332800,4665600,9331200,18662400")
    ap.add_argument("--modes", default="1,2,4,8,12,16,24,32")
    ap.add_argument("--nodes-per-doubling", type=int, default=33)
    ap.add_argument("--shell-bins", type=int, default=32)
    ap.add_argument("--top-shells", type=int, default=3)
    ap.add_argument("--shell-pnt-q", type=int, default=40)
    ap.add_argument("--pnt-q", type=int, default=3072)
    ap.add_argument("--prime-chunk", type=int, default=100000)
    ap.add_argument("--root-tol", type=float, default=2e-9)
    ap.add_argument("--scan-points", type=int, default=65)
    ap.add_argument("--max-newton", type=int, default=12)
    ap.add_argument("--q-grid", default="0,1,2,3,4,6")
    ap.add_argument("--ridge", type=float, default=1e-8)
    ap.add_argument("--maximum-shell-reconstruction-relative", type=float, default=2e-5)
    ap.add_argument("--maximum-carrier-baseline-ratio", type=float, default=0.85)
    ap.add_argument("--minimum-carrier-correlation", type=float, default=0.40)
    ap.add_argument("--minimum-carrier-sign-accuracy", type=float, default=0.60)
    ap.add_argument("--minimum-heldout-shell-capture", type=float, default=0.35)
    ap.add_argument("--maximum-remainder-tv-ratio", type=float, default=0.75)
    ap.add_argument("--minimum-supported-mode-fraction", type=float, default=0.75)
    ap.add_argument("--priority-modes", default="12,32")
    ap.add_argument("--prefix", default="rot_rh_bump2_moving_shell_resonance_v454")
    args=ap.parse_args()

    started=time.perf_counter()
    v452=import_v452(args.v452_module)
    cutoffs=parse_ints(args.cutoffs); modes=parse_ints(args.modes)
    q_grid=parse_floats(args.q_grid); priority_modes=parse_ints(args.priority_modes)
    if len(cutoffs) < 5 or cutoffs != sorted(cutoffs):
        raise ValueError("Need at least five increasing cutoffs.")
    if args.nodes_per_doubling < 9 or args.nodes_per_doubling % 2 == 0:
        raise ValueError("--nodes-per-doubling must be odd and >=9.")
    if args.shell_bins < 8 or args.top_shells < 1 or args.top_shells >= args.shell_bins:
        raise ValueError("Need shell-bins>=8 and 1<=top-shells<shell-bins.")
    if max(modes) < 2:
        raise ValueError("Need positive spectral modes.")

    prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    train_cutoffs=cutoffs[:-1]; hold_lo=cutoffs[-2]; hold_hi=cutoffs[-1]
    train_max=train_cutoffs[-1]
    edges=np.linspace(0.0,1.0,args.shell_bins+1)
    centers=0.5*(edges[:-1]+edges[1:])
    x_bare=bare_window_peak()

    print("="*176)
    print("ROT-RH v454 — BUMP-2 FINITE-PART MOVING-SHELL / RESONANCE AUTOPSY")
    print("="*176)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("finite-part source                 : bump2 prime - bump2 PNT")
    print("training cutoff ladder             :", train_cutoffs)
    print("HELD-OUT interval                  :", [hold_lo,hold_hi])
    print("modes                              :", modes)
    print("nodes per doubling                 :", args.nodes_per_doubling)
    print("normalized shell bins              :", args.shell_bins)
    print("training-selected shells / mode    :", args.top_shells)
    print("bare d(window)/dlogX peak x        :", f"{x_bare:.9f}")
    print("holdout prime table policy         : NOT BUILT until pre-holdout SHA freeze")
    print("prospective target                 : full held-out source trajectory")
    print("="*176)

    print("\n[A] Building TRAINING-only prime-power table and free levels ...")
    n_train,lam_train=v452.mangoldt_terms(int(train_max))
    free=v452.free_archimedean_levels(max(modes))
    print("training Mangoldt terms             :",len(n_train))

    mode_rows: List[dict]=[]; shell_rows: List[dict]=[]
    previous: Dict[int,float]|None=None
    train_node_counter=0
    max_recon_rel=0.0

    print("\n[B] Resolving TRAINING moving-shell source field ...")
    for j,(xa,xb) in enumerate(zip(train_cutoffs[:-1],train_cutoffs[1:])):
        La,Lb=math.log(xa),math.log(xb)
        Lgrid=np.linspace(La,Lb,args.nodes_per_doubling)
        if j>0: Lgrid=Lgrid[1:]
        for L in tqdm(Lgrid,desc=f"TRAIN shells {xa}->{xb}",unit="node"):
            X=float(math.exp(float(L)))
            ph=make_phase(v452,n_train,lam_train,X,args.pnt_q,args.prime_chunk)
            roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
            bad=[k for k,r in roots.items() if not r.ok]
            if bad: raise RuntimeError(f"training roots failed X={X:.12g}: {bad}")
            E=np.asarray([roots[k].root for k in modes],float)
            prime,pnt,finite=shell_decompose_source(v452,ph,E,edges,args.shell_pnt_q,args.prime_chunk)
            root_map={}
            pnt_peak=pnt_effective_peak(L)
            for mi,k in enumerate(modes):
                sv=ph.sources(float(E[mi]))
                shell_sum=float(np.sum(finite[mi]))
                recon=safe_rel(shell_sum,float(sv.finitepart_L),1e-10)
                max_recon_rel=max(max_recon_rel,recon)
                fE=v452.smooth_count_prime(float(E[mi]))-float(sv.finitepart_E)/math.pi
                fL=-float(sv.finitepart_L)/math.pi
                flow=-fL/fE
                abs_shell=np.abs(finite[mi]); den=float(np.sum(abs_shell))
                centroid=float(np.sum(centers*abs_shell)/den) if den>0 else float("nan")
                dom=int(np.argmax(abs_shell)) if den>0 else 0
                mode_rows.append({
                    "phase":"TRAIN","interval_index":j,"node_index":train_node_counter,
                    "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,
                    "E":f"{E[mi]:.17g}","root_residual":f"{roots[k].residual:.6e}",
                    "F_E":f"{fE:.17g}","finite_source":f"{sv.finitepart_L:.17g}",
                    "F_logX":f"{fL:.17g}","flow":f"{flow:.17g}",
                    "shell_reconstruction_relative":f"{recon:.6e}",
                    "abs_shell_centroid_x":f"{centroid:.17g}",
                    "dominant_bin":dom,"dominant_bin_center":f"{centers[dom]:.17g}",
                    "bare_window_peak_x":f"{x_bare:.17g}",
                    "pnt_effective_peak_x":f"{pnt_peak:.17g}",
                })
                for b in range(args.shell_bins):
                    shell_rows.append({
                        "phase":"TRAIN","interval_index":j,"node_index":train_node_counter,
                        "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,
                        "E":f"{E[mi]:.17g}","bin":b,
                        "x_lo":f"{edges[b]:.17g}","x_hi":f"{edges[b+1]:.17g}",
                        "x_center":f"{centers[b]:.17g}",
                        "prime_source":f"{prime[mi,b]:.17g}",
                        "pnt_source":f"{pnt[mi,b]:.17g}",
                        "finite_source":f"{finite[mi,b]:.17g}",
                        "abs_fraction":f"{(abs(finite[mi,b])/den if den>0 else 0.0):.17g}",
                    })
                root_map[k]=float(E[mi])
            previous=root_map
            train_node_counter += 1

    # Convert training rows to arrays per mode.
    max_train_interval=len(train_cutoffs)-2
    prevalidation_interval=max_train_interval-1
    if prevalidation_interval < 1:
        raise ValueError("Need >=3 training intervals for blocked carrier validation.")

    print("\n[C] Selecting shells/carriers and FREEZING held-out trajectory predictions ...")
    fit_rows=[]; prediction_rows=[]; fit_manifest={}
    for k in modes:
        rows=[r for r in mode_rows if r["phase"]=="TRAIN" and int(r["mode"])==k]
        Larr=np.asarray([float(r["logX"]) for r in rows],float)
        yarr=np.asarray([float(r["finite_source"]) for r in rows],float)
        iarr=np.asarray([int(r["interval_index"]) for r in rows],int)
        E_ref=float(rows[-1]["E"])
        selected=top_bins_from_rows(shell_rows,k,prevalidation_interval,args.top_shells,args.shell_bins)
        selected_centers=[float(centers[b]) for b in selected]
        cv=choose_carrier_q(Larr,yarr,iarr,E_ref,selected_centers,q_grid,args.ridge)
        q=float(cv["best"]["q"])
        A=carrier_matrix(Larr,E_ref,selected_centers,q)
        beta,pred_train=ridge_fit(A,yarr,args.ridge)

        # Freeze predictions on exact requested holdout L-grid WITHOUT touching holdout primes.
        Lh=np.linspace(math.log(hold_lo),math.log(hold_hi),args.nodes_per_doubling)
        pred_h=carrier_predict(Lh,E_ref,selected_centers,q,beta)
        for ii,(L,pv) in enumerate(zip(Lh,pred_h)):
            prediction_rows.append({
                "mode":k,"node_index":ii,"logX":f"{L:.17g}","X":f"{math.exp(L):.17g}",
                "predicted_finite_source":f"{pv:.17g}",
            })
        val_supported=bool(
            cv["best"]["validation_ratio"] <= args.maximum_carrier_baseline_ratio and
            cv["best"]["validation_corr"] >= args.minimum_carrier_correlation and
            cv["best"]["validation_sign_accuracy"] >= args.minimum_carrier_sign_accuracy
        )
        fit_rows.append({
            "mode":k,"E_ref":f"{E_ref:.17g}",
            "selected_bins":",".join(str(x) for x in selected),
            "selected_centers":",".join(f"{x:.8f}" for x in selected_centers),
            "q":f"{q:.8g}",
            "validation_rmse":f"{cv['best']['validation_rmse']:.17g}",
            "validation_baseline_rmse":f"{cv['best']['validation_baseline_rmse']:.17g}",
            "validation_ratio":f"{cv['best']['validation_ratio']:.17g}",
            "validation_corr":f"{cv['best']['validation_corr']:.17g}",
            "validation_sign_accuracy":f"{cv['best']['validation_sign_accuracy']:.17g}",
            "training_carrier_supported":val_supported,
        })
        fit_manifest[str(k)]={
            "E_ref":E_ref,"selected_bins":selected,"selected_centers":selected_centers,
            "q":q,"beta":[float(x) for x in beta],"blocked_validation":cv,
            "training_carrier_supported":val_supported,
        }
        print(f"  k={k:<3d} bins={selected} q={q:g} val_ratio={cv['best']['validation_ratio']:.3f} corr={cv['best']['validation_corr']:+.3f} sign={cv['best']['validation_sign_accuracy']:.3f}")

    pred_path=Path(str(prefix)+"_PREDICTED_HOLDOUT_SOURCE.csv")
    write_csv(pred_path,prediction_rows)
    manifest={
        "version":VERSION,"frozen_before_holdout":True,
        "training_cutoffs":train_cutoffs,"holdout_interval":[hold_lo,hold_hi],
        "modes":modes,"nodes_per_doubling":args.nodes_per_doubling,
        "shell_bins":args.shell_bins,"top_shells":args.top_shells,
        "shell_edges":[float(x) for x in edges],"bare_window_peak_x":x_bare,
        "carrier_q_grid":q_grid,"ridge":args.ridge,"fits":fit_manifest,
        "predicted_holdout_file":pred_path.name,
        "predicted_holdout_sha256":sha256_file(pred_path),
        "gates":{
            "maximum_shell_reconstruction_relative":args.maximum_shell_reconstruction_relative,
            "maximum_carrier_baseline_ratio":args.maximum_carrier_baseline_ratio,
            "minimum_carrier_correlation":args.minimum_carrier_correlation,
            "minimum_carrier_sign_accuracy":args.minimum_carrier_sign_accuracy,
            "minimum_heldout_shell_capture":args.minimum_heldout_shell_capture,
            "maximum_remainder_tv_ratio":args.maximum_remainder_tv_ratio,
            "minimum_supported_mode_fraction":args.minimum_supported_mode_fraction,
            "priority_modes":priority_modes,
        },
        "firewall":{
            "known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,
            "holdout_prime_table_built":False,"holdout_source_evaluated":False,
        },
    }
    freeze_path=Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json")
    freeze_path.write_text(json.dumps(json_safe(manifest),indent=2),encoding="utf-8")
    freeze_sha=sha256_file(freeze_path)
    print("  PRE-HOLDOUT FREEZE SHA256:",freeze_sha)

    # NOW build the holdout prime table. This is intentionally after SHA freeze.
    print("\n[D] Revealing HELD-OUT prime table and full source trajectory ...")
    n_all,lam_all=v452.mangoldt_terms(int(hold_hi))
    print("full Mangoldt terms                 :",len(n_all))
    hold_mode_rows=[]; hold_shell_rows=[]
    previous={k:float([r for r in mode_rows if int(r["mode"])==k][-1]["E"]) for k in modes}
    Lh=np.linspace(math.log(hold_lo),math.log(hold_hi),args.nodes_per_doubling)
    max_hold_recon=0.0
    for ii,L in enumerate(tqdm(Lh,desc=f"HOLDOUT shells {hold_lo}->{hold_hi}",unit="node")):
        X=float(math.exp(float(L)))
        ph=make_phase(v452,n_all,lam_all,X,args.pnt_q,args.prime_chunk)
        roots=quantize_silent(v452,ph,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
        bad=[k for k,r in roots.items() if not r.ok]
        if bad: raise RuntimeError(f"holdout roots failed X={X:.12g}: {bad}")
        E=np.asarray([roots[k].root for k in modes],float)
        prime,pnt,finite=shell_decompose_source(v452,ph,E,edges,args.shell_pnt_q,args.prime_chunk)
        root_map={}
        pnt_peak=pnt_effective_peak(L)
        for mi,k in enumerate(modes):
            sv=ph.sources(float(E[mi]))
            shell_sum=float(np.sum(finite[mi])); recon=safe_rel(shell_sum,float(sv.finitepart_L),1e-10)
            max_hold_recon=max(max_hold_recon,recon)
            fE=v452.smooth_count_prime(float(E[mi]))-float(sv.finitepart_E)/math.pi
            fL=-float(sv.finitepart_L)/math.pi; flow=-fL/fE
            abs_shell=np.abs(finite[mi]); den=float(np.sum(abs_shell))
            centroid=float(np.sum(centers*abs_shell)/den) if den>0 else float("nan")
            dom=int(np.argmax(abs_shell)) if den>0 else 0
            hold_mode_rows.append({
                "phase":"HOLDOUT","interval_index":max_train_interval+1,"node_index":ii,
                "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,
                "E":f"{E[mi]:.17g}","root_residual":f"{roots[k].residual:.6e}",
                "F_E":f"{fE:.17g}","finite_source":f"{sv.finitepart_L:.17g}",
                "F_logX":f"{fL:.17g}","flow":f"{flow:.17g}",
                "shell_reconstruction_relative":f"{recon:.6e}",
                "abs_shell_centroid_x":f"{centroid:.17g}",
                "dominant_bin":dom,"dominant_bin_center":f"{centers[dom]:.17g}",
                "bare_window_peak_x":f"{x_bare:.17g}",
                "pnt_effective_peak_x":f"{pnt_peak:.17g}",
            })
            for b in range(args.shell_bins):
                hold_shell_rows.append({
                    "phase":"HOLDOUT","interval_index":max_train_interval+1,"node_index":ii,
                    "X":f"{X:.17g}","logX":f"{L:.17g}","mode":k,"E":f"{E[mi]:.17g}",
                    "bin":b,"x_lo":f"{edges[b]:.17g}","x_hi":f"{edges[b+1]:.17g}",
                    "x_center":f"{centers[b]:.17g}",
                    "prime_source":f"{prime[mi,b]:.17g}","pnt_source":f"{pnt[mi,b]:.17g}",
                    "finite_source":f"{finite[mi,b]:.17g}",
                    "abs_fraction":f"{(abs(finite[mi,b])/den if den>0 else 0.0):.17g}",
                })
            root_map[k]=float(E[mi])
        previous=root_map

    # Score frozen source predictions and shell persistence.
    print("\n[E] Scoring ORIGINAL frozen carrier predictions ...")
    score_rows=[]; supported=[]
    pred_by_mode={}
    for k in modes:
        pr=[r for r in prediction_rows if int(r["mode"])==k]
        pred=np.asarray([float(r["predicted_finite_source"]) for r in pr],float)
        hr=[r for r in hold_mode_rows if int(r["mode"])==k]
        actual=np.asarray([float(r["finite_source"]) for r in hr],float)
        Larr=np.asarray([float(r["logX"]) for r in hr],float)
        last_train=float([r for r in mode_rows if int(r["mode"])==k][-1]["finite_source"])
        rm=rms(actual-pred); zrm=rms(actual); lrm=rms(actual-last_train); base=min(zrm,lrm)
        ratio=rm/max(base,1e-300); cc=corr(actual,pred); sa=sign_accuracy(actual,pred)
        # Continuous-L total variation of source/remainder, normalized as an autopsy metric.
        src_tv=float(np.trapezoid(np.abs(actual),Larr))
        rem_tv=float(np.trapezoid(np.abs(actual-pred),Larr))
        rem_ratio=rem_tv/max(src_tv,1e-300)

        selected=fit_manifest[str(k)]["selected_bins"]
        sh=[r for r in hold_shell_rows if int(r["mode"])==k]
        bybin=np.zeros(args.shell_bins,float)
        for r in sh: bybin[int(r["bin"])]+=abs(float(r["finite_source"]))
        tot=float(np.sum(bybin)); capture=float(np.sum(bybin[selected])/tot) if tot>0 else 0.0
        hold_top=list(np.argsort(-bybin)[:args.top_shells].astype(int))
        overlap=len(set(selected)&set(hold_top))/float(args.top_shells)
        pass_mode=bool(
            ratio <= args.maximum_carrier_baseline_ratio and
            cc >= args.minimum_carrier_correlation and
            sa >= args.minimum_carrier_sign_accuracy and
            capture >= args.minimum_heldout_shell_capture and
            rem_ratio <= args.maximum_remainder_tv_ratio
        )
        supported.append(pass_mode); pred_by_mode[k]=pred
        score_rows.append({
            "mode":k,"selected_training_bins":",".join(str(x) for x in selected),
            "holdout_top_bins":",".join(str(x) for x in hold_top),
            "top_bin_overlap_fraction":f"{overlap:.17g}",
            "heldout_selected_shell_capture":f"{capture:.17g}",
            "carrier_rmse":f"{rm:.17g}","zero_baseline_rmse":f"{zrm:.17g}",
            "last_value_baseline_rmse":f"{lrm:.17g}","carrier_baseline_ratio":f"{ratio:.17g}",
            "carrier_correlation":f"{cc:.17g}","carrier_sign_accuracy":f"{sa:.17g}",
            "source_total_variation":f"{src_tv:.17g}","remainder_total_variation":f"{rem_tv:.17g}",
            "remainder_tv_ratio":f"{rem_ratio:.17g}","prospective_carrier_pass":pass_mode,
        })

    shell_recon_pass=bool(max(max_recon_rel,max_hold_recon)<=args.maximum_shell_reconstruction_relative)
    supported_fraction=float(np.mean(supported)) if supported else 0.0
    priority_pass=all(score_rows[modes.index(k)]["prospective_carrier_pass"] for k in priority_modes if k in modes)
    strong=bool(shell_recon_pass and supported_fraction==1.0)
    partial=bool(shell_recon_pass and supported_fraction>=args.minimum_supported_mode_fraction and priority_pass)
    if strong:
        verdict="MOVING_SHELL_RESONANCE_SUPPORTED_PROSPECTIVELY_ALL_MODES"
    elif partial:
        verdict="MOVING_SHELL_RESONANCE_SUPPORTED_PROSPECTIVELY_PARTIAL"
    elif shell_recon_pass:
        verdict="LOW_DIMENSIONAL_MOVING_SHELL_CARRIER_NOT_SUPPORTED"
    else:
        verdict="SHELL_DECOMPOSITION_NUMERICALLY_UNRESOLVED"

    # Output all data.
    all_mode_rows=mode_rows+hold_mode_rows; all_shell_rows=shell_rows+hold_shell_rows
    paths={
        "mode_nodes":Path(str(prefix)+"_MODE_NODES.csv"),
        "shell_nodes":Path(str(prefix)+"_SHELL_NODES.csv"),
        "carrier_fits":Path(str(prefix)+"_CARRIER_FITS.csv"),
        "holdout_score":Path(str(prefix)+"_HOLDOUT_SCORE.csv"),
        "summary":Path(str(prefix)+"_SUMMARY.json"),
        "theorem":Path(str(prefix)+"_THEOREM.md"),
    }
    write_csv(paths["mode_nodes"],all_mode_rows); write_csv(paths["shell_nodes"],all_shell_rows)
    write_csv(paths["carrier_fits"],fit_rows); write_csv(paths["holdout_score"],score_rows)

    # Compact location diagnostics.
    train_centroids=[float(r["abs_shell_centroid_x"]) for r in mode_rows]
    hold_centroids=[float(r["abs_shell_centroid_x"]) for r in hold_mode_rows]
    pnt_peaks=[float(r["pnt_effective_peak_x"]) for r in hold_mode_rows]
    summary={
        "version":VERSION,"verdict":verdict,"pre_holdout_freeze_sha256":freeze_sha,
        "firewall":{"known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,
                    "holdout_prime_table_built_only_after_freeze":True},
        "cutoffs":cutoffs,"modes":modes,"nodes_per_doubling":args.nodes_per_doubling,
        "shell_bins":args.shell_bins,"top_shells":args.top_shells,
        "bare_window_peak_x":x_bare,
        "mean_training_abs_shell_centroid_x":float(np.mean(train_centroids)),
        "mean_holdout_abs_shell_centroid_x":float(np.mean(hold_centroids)),
        "mean_holdout_pnt_effective_peak_x":float(np.mean(pnt_peaks)),
        "maximum_shell_reconstruction_relative":max(max_recon_rel,max_hold_recon),
        "shell_reconstruction_pass":shell_recon_pass,
        "supported_mode_fraction":supported_fraction,"priority_modes_pass":priority_pass,
        "mode_scores":score_rows,"gates":manifest["gates"],
        "runtime_seconds":time.perf_counter()-started,
        "outputs":{k:str(v) for k,v in paths.items()},
    }
    paths["summary"].write_text(json.dumps(json_safe(summary),indent=2),encoding="utf-8")

    theorem=f"""# ROT-RH v454 — moving-shell resonance theorem target\n\nVerdict: **{verdict}**\n\nThe exact finite-part source is decomposed as\n\n`S_k(L) = sum_b [S_prime(k,b,L) - S_PNT(k,b,L)]`.\n\nThe bump derivative itself has normalized profile\n\n`G(x)=2 x^2 (1-x)^(-3) exp(-(x/(1-x))^2)`,\n\nwith bare window peak `x={x_bare:.9f}`.  The full PNT source carrier also\ncontains `exp(L x/2)/x`, so its effective peak is L-dependent and is reported\nseparately; v454 does not assume the bare-window peak is the arithmetic source\npeak.\n\nA low-dimensional resonance theorem would require, for each fixed k, a frozen\nfinite set of shell centers c_j and coefficients such that\n\n`S_k(L) = L^(-q) [a0 + sum_j(a_j sin(E_k* c_j L)+b_j cos(E_k* c_j L))] + r_k(L)`\n\nwith an integrable or summably controlled remainder r_k.  v454 only tests a\nfinite prospective precursor of that statement.  It does not establish the\nall-L expansion.\n"""
    paths["theorem"].write_text(theorem,encoding="utf-8")

    print("\n"+"="*176)
    print("KEY RESULTS")
    print("="*176)
    print("verdict                                  :",verdict)
    print("pre-holdout freeze SHA256                :",freeze_sha)
    print("holdout prime table built after freeze   : True")
    print("max shell reconstruction relative        :",f"{max(max_recon_rel,max_hold_recon):.6e}","pass=",shell_recon_pass)
    print("bare d(window)/dlogX peak x              :",f"{x_bare:.9f}")
    print("mean training |shell|-centroid x         :",f"{np.mean(train_centroids):.9f}")
    print("mean holdout |shell|-centroid x          :",f"{np.mean(hold_centroids):.9f}")
    print("mean holdout PNT effective peak x        :",f"{np.mean(pnt_peaks):.9f}")
    print("prospectively supported mode fraction    :",f"{supported_fraction:.3f}")
    print("priority modes pass                      :",priority_pass,priority_modes)
    print("holdout mode diagnostics                 :")
    for r in score_rows:
        print(f"  k={int(r['mode']):<3d} bins={r['selected_training_bins']:<8s} hold={r['holdout_top_bins']:<8s} capture={float(r['heldout_selected_shell_capture']):.3f} ratio={float(r['carrier_baseline_ratio']):.3f} corr={float(r['carrier_correlation']):+.3f} sign={float(r['carrier_sign_accuracy']):.3f} remTV={float(r['remainder_tv_ratio']):.3f} pass={r['prospective_carrier_pass']}")
    print("summary                                  :",paths["summary"])
    print("="*176)


if __name__=="__main__":
    main()
