#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v401 — BERNSTEIN QUOTIENT-TYPE / FACTORIAL FOUR-JET REDUCTION
===================================================================

Purpose
-------
Replace v400's fragile empirical derivative-shape envelope by a rigorous
functional-analytic implication.

For the exact resonance-subtracted R^7 dual kernel, the E-dependence occurs
only through multiplicative quotient phases exp(i E log q).  Hence the regular
difference vector is a Banach-valued exponential polynomial of finite
exponential type.

Classical Bernstein inequality for entire functions of exponential type then
controls ALL E derivatives from the zeroth regular variation.

Exact quotient-frequency geometry
---------------------------------
Let

    h_M(E,d)=d^(-iE)((R^T)^7 ell_M(E))_d,
    ell_M(E,n)=e^(iE log n) 1_(n<=M).

Every R^7 path from input d to terminal n has multiplicative quotient

    q=n/d.

After multiplying by d^(-iE), its phase is exactly

    e^(iE log q).

Since n<=M and d>=s,

    q<=M/s.

Therefore every coordinate of the regular adjacent-difference vector

    F_M,s(E)
      = ( h_M(E,d)-h_M(E,d+1) )_(s<=d<D_eff)

is an entire exponential polynomial of type at most

    tau=log(M/s).

The endpoint resonance subtraction c_M does not alter adjacent differences,
so

    V_m(E)
      := sum_d |Delta partial_E^m h_M(E,d)|
       = || F_M,s^(m)(E) ||_1.

Bernstein theorem
-----------------
For a scalar entire function f of exponential type tau bounded on R,

    sup_R |f^(m)| <= tau^m sup_R |f|.

Apply this to every bounded linear functional on the finite-dimensional
l1-valued exponential polynomial F, then use duality:

    ||F^(m)(E)||_1
      <= tau^m sup_(x in R) ||F(x)||_1.

Hence, with

    V_* = sup_(x in R) V_0(x),

we have

    V_m(E) <= tau^m V_*.

Factorially scaled prefix jets
------------------------------
Use the input/output scaled jet components

    X_j = ||A_D^[j]|| / [j! (log D)^j],
    Y_r = ||R_reg^[r]|| / [r! (log M)^r].

The regular Leibniz channel gives

    Y_r
      <= sum_(j=0)^r
           [ V_(r-j)/(r-j)! ]
           [ (log D)^j/(log M)^r ]
           X_j.

Put m=r-j.  Since

    tau=log(M/s) <= log M
and
    log D <= log M,

Bernstein gives the universal row bound

    Y_r
      <= V_* sum_(m=0)^r 1/m! * max_j X_j.

For jet orders 0,1,2,3,

    H_3 = max_r sum_(m=0)^r 1/m!
        = 1 + 1 + 1/2 + 1/6
        = 8/3.

Therefore

    ||R_reg||_(factorial four-jet)
      <= (8/3) V_*.

A sufficient all-scale theorem is simply

    V_* < 3/8.

This removes the need to prove independent all-scale bounds for V1,V2,V3.

IMPORTANT
---------
v401 proves the implication algebraically and checks the finite historical
panels in the factorial scaling.  It does NOT prove the all-scale scalar bound

    sup_(M,s,E real) V_0(M,s,E) < 3/8.

That scalar regular-variation theorem is the next analytic obligation.

Scientific firewall
-------------------
NO Xi.
NO zeta numerical evaluations.
NO known zero ordinates.
No finite scan accepted as proof.

Version: 401
"""

from __future__ import annotations

import argparse
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 401
JET_ORDER = 3


def factorial_shape_constant(order=3):
    total = Fraction(0, 1)
    terms = []
    for m in range(order + 1):
        term = Fraction(1, math.factorial(m))
        terms.append(term)
        total += term
    return total, terms


def load_optional_json(path):
    p = Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def prepare_frame(df, source):
    required = {
        "V0", "V1", "V2", "V3",
        "logM", "logD",
        "support_s", "output_M",
        "depth", "lambda",
        "energy_offset_fraction",
    }
    missing = sorted(required - set(df.columns))
    if missing:
        raise KeyError(f"{source} missing columns: {missing}")

    out = df.copy()
    out["source"] = source

    tau = np.log(
        out["output_M"].to_numpy(float)
        / out["support_s"].to_numpy(float)
    )
    out["tau"] = tau
    out["tau_over_logM"] = (
        tau / out["logM"].to_numpy(float)
    )
    out["logD_over_logM"] = (
        out["logD"].to_numpy(float)
        / out["logM"].to_numpy(float)
    )

    # Exact factorially scaled empirical regular matrix:
    #
    # Kfac[r,j]
    #   = V_m/m! * (logD)^j/(logM)^r,
    #   m=r-j.
    #
    for r in range(4):
        for j in range(4):
            col = f"Kfac{r}{j}"
            if j > r:
                out[col] = 0.0
                continue

            m = r - j
            out[col] = (
                out[f"V{m}"].to_numpy(float)
                / math.factorial(m)
                * np.power(
                    out["logD"].to_numpy(float),
                    j,
                )
                / np.power(
                    out["logM"].to_numpy(float),
                    r,
                )
            )

        rowcols = [f"Kfac{r}{j}" for j in range(4)]
        out[f"qfac_row_{r}"] = out[rowcols].sum(axis=1)

    out["qfac_case"] = out[
        [f"qfac_row_{r}" for r in range(4)]
    ].max(axis=1)

    return out


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v397-cases",
        default="rot_rh_regular_four_jet_variation_v397_CASES.csv",
    )
    ap.add_argument(
        "--v399-detail",
        default="rot_rh_fresh_regular_jet_holdout_v399_DETAIL.csv",
    )
    ap.add_argument(
        "--v400-summary",
        default="rot_rh_regular_jet_shape_amplitude_v400_SUMMARY.json",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_bernstein_factorial_jet_v401",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()

    p397 = Path(args.v397_cases)
    p399 = Path(args.v399_detail)

    if not p397.exists():
        raise FileNotFoundError(p397)
    if not p399.exists():
        raise FileNotFoundError(p399)

    v400 = load_optional_json(args.v400_summary)

    Hfrac, Hterms = factorial_shape_constant(JET_ORDER)
    H = float(Hfrac)
    Vcrit_frac = Fraction(1, 1) / Hfrac
    Vcrit = float(Vcrit_frac)

    print("=" * 224)
    print("ROT-RH v401 — BERNSTEIN QUOTIENT-TYPE / FACTORIAL FOUR-JET REDUCTION")
    print("=" * 224)
    print("Xi / zeta / known-zero data             : NONE")
    print("finite scanning accepted as proof       : NO")
    if v400 is not None:
        print("v400 verdict                             :", v400.get("verdict"))
    print("jet order                                :", JET_ORDER)
    print(
        "H_3=sum_(m=0)^3 1/m!                   :",
        f"{Hfrac.numerator}/{Hfrac.denominator}",
        f"= {H:.15f}",
    )
    print(
        "critical scalar V_* < 1/H_3             :",
        f"{Vcrit_frac.numerator}/{Vcrit_frac.denominator}",
        f"= {Vcrit:.15f}",
    )
    print("=" * 224)

    # ------------------------------------------------------------------
    # Exact symbolic/rational theorem algebra.
    # ------------------------------------------------------------------
    print("[1] Exact factorial-jet theorem algebra")

    checks = []
    with tqdm(total=4, desc="theorem identities", unit="identity") as bar:
        checks.append(Hfrac == Fraction(8, 3))
        bar.update(1)

        checks.append(Vcrit_frac == Fraction(3, 8))
        bar.update(1)

        # tau/logM <=1 follows from s>=1:
        # log(M/s)<=logM.
        checks.append(True)
        bar.update(1)

        # logD/logM <=1 follows from D<=M in this geometry.
        checks.append(True)
        bar.update(1)

    theorem_algebra_pass = bool(all(checks))

    print("H_3 exact                                : 8/3")
    print("critical V_* exact                       : 3/8")
    print(
        "Bernstein derivative theorem             :",
        "V_m(E) <= tau^m sup_x V_0(x)",
    )
    print(
        "factorial regular-jet theorem             :",
        "q_reg <= (8/3) V_*",
    )
    print("exact theorem algebra pass               :", theorem_algebra_pass)

    # ------------------------------------------------------------------
    # Historical finite panels under factorial scaling.
    # ------------------------------------------------------------------
    print("\n[2] Historical/fresh factorial scaling")

    old = prepare_frame(
        pd.read_csv(p397),
        "v397",
    )
    fresh = prepare_frame(
        pd.read_csv(p399),
        "v399",
    )

    combined = pd.concat(
        [old, fresh],
        ignore_index=True,
        sort=False,
    )

    geometry_pass = bool(
        np.all(
            combined["tau_over_logM"].to_numpy(float)
            >= -1e-14
        )
        and np.all(
            combined["tau_over_logM"].to_numpy(float)
            <= 1.0 + 1e-14
        )
        and np.all(
            combined["logD_over_logM"].to_numpy(float)
            > 0.0
        )
        and np.all(
            combined["logD_over_logM"].to_numpy(float)
            <= 1.0 + 1e-14
        )
    )

    max_qfac = float(combined["qfac_case"].max())
    max_V0 = float(combined["V0"].max())
    current_margin = Vcrit / max(max_V0, 1e-300)

    print(
        "min/max tau/logM                         :",
        f"{combined['tau_over_logM'].min():.12e}",
        "/",
        f"{combined['tau_over_logM'].max():.12e}",
    )
    print(
        "min/max logD/logM                        :",
        f"{combined['logD_over_logM'].min():.12e}",
        "/",
        f"{combined['logD_over_logM'].max():.12e}",
    )
    print("finite quotient geometry pass            :", geometry_pass)
    print("maximum finite V0                        :", f"{max_V0:.15e}")
    print("maximum factorial-scaled q_case          :", f"{max_qfac:.15e}")
    print("finite Vcrit/max(V0) margin              :", f"{current_margin:.9f}")
    print("all finite factorial q_case < 1          :", bool(max_qfac < 1.0))

    # ------------------------------------------------------------------
    # Bernstein consistency diagnostic.
    #
    # NOTE: finite data only contains selected E values, not sup_R V0,
    # so this is NOT a proof check. It asks whether observed higher jets
    # are below tau^m times the observed same-row V0.
    # ------------------------------------------------------------------
    print("\n[3] Same-row Bernstein-ratio diagnostic (descriptive only)")

    bern_rows = []
    for m in range(1, 4):
        denom = (
            np.power(
                combined["tau"].to_numpy(float),
                m,
            )
            * np.maximum(
                combined["V0"].to_numpy(float),
                1e-300,
            )
        )

        ratio = (
            combined[f"V{m}"].to_numpy(float)
            / np.maximum(denom, 1e-300)
        )

        combined[f"bernstein_same_E_ratio_{m}"] = ratio

        finite_ratio = ratio[np.isfinite(ratio)]
        bern_rows.append({
            "jet": m,
            "max_same_E_ratio": (
                float(np.max(finite_ratio))
                if len(finite_ratio)
                else float("nan")
            ),
            "median_same_E_ratio": (
                float(np.median(finite_ratio))
                if len(finite_ratio)
                else float("nan")
            ),
            "interpretation": (
                "Only diagnostic: theorem denominator is sup over all real E, "
                "not the same-row V0."
            ),
        })

    for row in bern_rows:
        print(
            f"m={row['jet']}  "
            f"max V_m/(tau^m V0_sameE)="
            f"{row['max_same_E_ratio']:.9f}  "
            f"median={row['median_same_E_ratio']:.9f}"
        )

    # ------------------------------------------------------------------
    # Worst rows.
    # ------------------------------------------------------------------
    print("\n[4] Worst factorial-jet cases")

    worst = (
        combined
        .sort_values("qfac_case", ascending=False)
        .head(10)
        .copy()
    )

    show_cols = [
        "source",
        "depth",
        "lambda",
        "energy_offset_fraction",
        "output_M",
        "support_s",
        "V0",
        "qfac_case",
        "tau_over_logM",
    ]

    print(
        worst[show_cols].to_string(
            index=False,
            float_format=lambda x: f"{x:.9e}",
        )
    )

    # ------------------------------------------------------------------
    # Theorem obligations.
    # ------------------------------------------------------------------
    print("\n[5] Remaining theorem after Bernstein reduction")

    obligations = [
        (
            "QUOTIENT_EXPONENTIAL_TYPE",
            "Exact: every regular difference coordinate has frequencies log q with q<=M/s, hence type tau<=log M.",
        ),
        (
            "BANACH_BERNSTEIN",
            "External classical theorem + duality: V_m(E)<=tau^m sup_x V0(x).",
        ),
        (
            "FACTORIAL_JET_SCALING",
            "Exact: binomial coefficients reduce to 1/m! in the factorially scaled four-jet norm.",
        ),
        (
            "ONLY_OPEN_REGULAR_BOUND",
            "Prove V_*:=sup over all admissible M,s and real E of V0(M,s,E) < 3/8.",
        ),
        (
            "DOWNSTREAM",
            "Then regular four-jet contraction is rigorous; resonance-jet/collision identification and G7 head remain separate obligations.",
        ),
    ]

    for key, value in obligations:
        print(f"{key:42s}: {value}")

    reduction_pass = bool(
        theorem_algebra_pass
        and geometry_pass
        and max_qfac < 1.0
    )

    verdict = (
        "BERNSTEIN_FACTORIAL_FOUR_JET_REDUCTION_PASS"
        if reduction_pass
        else
        "BERNSTEIN_FACTORIAL_FOUR_JET_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_GLOBAL_SCALAR_RESONANCE_SUBTRACTED_VARIATION_VSTAR_LT_3_OVER_8"
    )

    print("\n" + "=" * 224)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "REGULAR FOUR-JET ALL-SCALE STATUS        :",
        "CONDITIONAL ONLY ON THE SINGLE SCALAR V_*<3/8 THEOREM",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 224)

    # ------------------------------------------------------------------
    # Outputs.
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)

    detail_path = Path(str(prefix) + "_DETAIL.csv")
    bern_path = Path(str(prefix) + "_BERNSTEIN_DIAGNOSTIC.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    combined.to_csv(detail_path, index=False)
    pd.DataFrame(bern_rows).to_csv(bern_path, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream_v400": (
            v400.get("verdict")
            if v400 is not None
            else None
        ),
        "exact_theorem": {
            "quotient_phase": "exp(i E log q), q=n/d",
            "exponential_type": "tau=log(M/s)<=log M",
            "bernstein": "V_m(E)<=tau^m sup_x V0(x)",
            "factorial_scaling": (
                "A^[j]/[j!(log D)^j] -> "
                "R^[r]/[r!(log M)^r]"
            ),
            "H3_fraction": f"{Hfrac.numerator}/{Hfrac.denominator}",
            "H3": H,
            "critical_Vstar_fraction": (
                f"{Vcrit_frac.numerator}/{Vcrit_frac.denominator}"
            ),
            "critical_Vstar": Vcrit,
            "regular_operator_bound": "q_reg <= (8/3) V_*",
        },
        "finite_diagnostics": {
            "rows": len(combined),
            "geometry_pass": geometry_pass,
            "maximum_V0": max_V0,
            "maximum_factorial_q_case": max_qfac,
            "Vcrit_over_max_finite_V0": current_margin,
            "bernstein_same_E_diagnostics": bern_rows,
        },
        "remaining_obligation": (
            "Prove uniform scalar resonance-subtracted regular variation "
            "V_*<3/8 for all admissible scales/supports and real E."
        ),
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact quotient-frequency/factorial algebra plus a classical "
            "Bernstein implication. The only open regular-jet theorem is the "
            "uniform zeroth-variation bound V_*<3/8."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v401 — Bernstein/factorial four-jet reduction

For the resonance-subtracted R7 dual difference vector, all E frequencies
are quotient frequencies `log q` with `q<=M/s`.  Hence its exponential type is

`tau=log(M/s)<=logM`.

Bernstein's inequality for entire functions of exponential type, applied in
the finite-dimensional `l1` Banach space by duality, gives

`V_m(E)<=tau^m V_*`

where

`V_*=sup_(real x) V_0(x)`.

Use factorially scaled prefix jets

`A^[j]/[j!(logD)^j]`.

Then the r-th regular row is bounded by

`V_* sum_(m=0)^r 1/m!`.

For orders 0 through 3,

`H_3=1+1+1/2+1/6=8/3`.

Therefore

`q_reg <= (8/3)V_*`.

A sufficient strict contraction theorem is exactly

`V_* < 3/8`.

Finite historical/fresh diagnostics:
- maximum observed V0 = `{max_V0:.16e}`
- maximum factorial-scaled q_case = `{max_qfac:.16e}`
- current finite margin `(3/8)/max(V0)` = `{current_margin:.12f}`

Verdict: `{verdict}`

This does NOT prove the all-scale scalar bound.
""",
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", detail_path)
    print(" ", bern_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and not reduction_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
