#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v476 — NONATTAINED WINDOW-LOCK IMPLIES COHERENCE COLLAPSE
================================================================

PURPOSE
-------
Close the BROAD-BAND NONCOLLAPSED branch left by v474-v475.

Work in the standard nonattained grouped resonance representation.  At a large
base cutoff t, write the forward physical window as

    H_t(s)
      = sum_j a_j(t) exp(-delta_j s) exp(i gamma_j s),
      0 <= s <= h,

where

    a_j(t)
      = c_j(E_t) exp(-delta_j t) exp(i gamma_j t),

    delta_j = beta_* - beta_j > 0,
    inf_j delta_j = 0,

and gamma_j >= 0 are grouped positive ordinates.

Define

    W0(t) = sum_j |a_j(t)|.

The old v408-v410 nonattained theorem gives ABSOLUTE FREQUENCY ESCAPE:

for every fixed M,

    sum_(gamma_j <= M) |a_j(t)| / W0(t) -> 0.

The same nonattained exponential weighting gives DEFICIT ESCAPE:

for every fixed eps>0,

    sum_(delta_j >= eps) |a_j(t)| / W0(t) -> 0,

and hence

    D0(t)/W0(t) -> 0,

where

    D0(t)=sum delta_j |a_j(t)|.

Therefore on every fixed window [0,h],

    H_t(s)
      = H_t^fr(s) + o(W0(t))

uniformly, where the frozen-amplitude signal is

    H_t^fr(s)=sum_j a_j(t)e^(i gamma_j s).

Indeed,

    |e^(-delta s)-1| <= h e^h delta

for 0<=s<=h, 0<=delta<=1.

---------------------------------------------------------------------------
A. Escaping-spectrum test-function lemma
---------------------------------------------------------------------------

Let phi be any C_c^infinity(0,h) test function.  Then

    integral phi(s) H_t^fr(s) ds
      = sum_j a_j(t) phi_hat(-gamma_j).

Normalize by W0(t).

Given epsilon>0, choose M so that

    sup_(gamma>=M)|phi_hat(-gamma)| < epsilon,

using repeated integration by parts / Riemann-Lebesgue.

The low-frequency part gamma<M has normalized absolute mass o(1).

Thus

    (1/W0)
    integral phi H_t^fr -> 0.

The amplitude-freezing error is o(W0), so also

    (1/W0)
    integral phi H_t -> 0.

This is a deterministic consequence of absolute spectral escape.  No
typicality, randomness, Bohr averaging, or frequency gap is required.

---------------------------------------------------------------------------
B. Phase-sector contradiction
---------------------------------------------------------------------------

Suppose there exist bounded real carrier frequencies nu_t and errors eps_t->0
such that throughout the entire window

    | arg H_t(s) - arg H_t(0) + nu_t s | <= eps_t

whenever H_t(s) != 0.

Equivalently, after the rotation

    Z_t(s)
      = exp(-i arg H_t(0)) exp(i nu_t s) H_t(s),

all nonzero values lie in a sector of half-angle eps_t around the positive real
axis.

Because |nu_t| is bounded, shifting gamma_j by nu_t does not affect frequency
escape.

Take phi>=0, phi not identically zero, compactly supported inside (0,h).
Then

    Re Z_t(s) >= cos(eps_t)|H_t(s)|.

But the escaping-spectrum lemma applied after the bounded carrier shift gives

    (1/W0)
    integral phi Z_t -> 0.

Taking real parts:

    cos(eps_t)
    (1/W0)
    integral phi(s)|H_t(s)| ds
      -> 0.

Hence

    (1/W0)
    integral phi(s)|H_t(s)| ds
      -> 0.

So WINDOW PHASE LOCK forces WINDOW-AVERAGED NORMALIZED COHERENCE COLLAPSE.

In particular, it is impossible to have simultaneously

    phase-sector width eps_t -> 0

and

    |H_t(s)| >= kappa W0(t)

for every s in the support of phi, with any fixed kappa>0.

More generally, any positive lower bound on the phi-weighted average coherence
is impossible.

---------------------------------------------------------------------------
C. Connection to v411
---------------------------------------------------------------------------

v411's sharp LOCK_TRANSFER condition is

    sup_(0<=Delta<=h)
      | integral_t^(t+Delta) Lcal(s,E) ds |
        <= C_k/t.

After subtracting the explicit bounded carrier/reference contribution, this is
precisely a shrinking phase-sector condition of the form above with

    eps_t = O(1/t).

Therefore, in a genuinely nonattained off-critical sector:

    LOCK_TRANSFER
        =>
    window-averaged collective coherence collapse.

This eliminates the entire NONCOLLAPSED broad-band alternative from v474.

---------------------------------------------------------------------------
D. New final frontier
---------------------------------------------------------------------------

A bounded fixed ordered root in the nonattained sector can now survive only
through a much stronger mechanism:

    PERSISTENT WINDOW COHERENCE COLLAPSE,

namely

    integral phi |H_t| / W0(t) -> 0

on every late fixed window for every nonnegative interior test function phi,
while the secular phase nevertheless remains well-defined and transverse.

This is stronger than:
  * pointwise first-moment cancellation (v409),
  * exceptional Bohr sampling (v410),
  * broad-band support (v474).

It says the full collective residue sum must remain almost completely cancelled
throughout every fixed physical window.

The remaining theorem is to prove that such window coherence collapse is
incompatible with the fixed action-label transversality/no-fold condition, or
to derive its exact primitive-beta law.

No Xi values, numerical zeta values, known zero ordinates, RH, simple zeros, or
finite scans are used.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v476-window-lock-coherence-collapse"


def symbolic_freeze_bound() -> Dict[str, Any]:
    import sympy as sp
    d, s, h = sp.symbols("d s h", nonnegative=True, real=True)
    # We record the elementary mean-value theorem inequality:
    # |e^{-ds}-1| <= ds <= h d for d,s>=0.
    # The e^h factor used in the text is a deliberately loose two-sided version.
    derivative = sp.diff(sp.exp(-d*s), s)
    at0 = sp.simplify(sp.exp(-d*0))
    return {
        "d_ds_exp_minus_ds": str(derivative),
        "value_at_zero": str(at0),
        "freeze_bound": "|exp(-delta s)-1|<=delta s<=h delta",
        "pass": bool(at0 == 1),
    }


def finite_escape_demo(seed: int = 11):
    """
    Diagnostic only. Construct frequency packets whose minimum frequency grows.
    Verify a smooth compactly-supported test integral decays while L1 coefficient
    mass stays normalized.
    """
    rng = random.Random(seed)
    rows = []

    # Smooth polynomial bump on [0,1], C^2 at endpoints; enough for the numerical
    # sanity panel. The theorem itself uses C_c^infinity.
    def phi(s):
        if not (0.0 < s < 1.0):
            return 0.0
        return (s*(1.0-s))**4

    ngrid = 12000
    ds = 1.0/ngrid
    grid = [(j+0.5)*ds for j in range(ngrid)]

    for M in (20.0, 80.0, 320.0, 1280.0):
        n = 12
        gammas = [M + j*(0.7+0.1*rng.random()) for j in range(n)]
        phases = [rng.uniform(-math.pi, math.pi) for _ in range(n)]
        mags = [rng.uniform(0.5, 1.5) for _ in range(n)]
        W0 = sum(mags)
        coeff = [
            mags[j]*complex(math.cos(phases[j]), math.sin(phases[j]))/W0
            for j in range(n)
        ]

        integ = 0j
        for s in grid:
            H = sum(
                coeff[j]*complex(
                    math.cos(gammas[j]*s),
                    math.sin(gammas[j]*s),
                )
                for j in range(n)
            )
            integ += phi(s)*H*ds

        rows.append({
            "minimum_frequency": M,
            "test_integral_abs": abs(integ),
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v476 — nonattained window-lock implies coherence collapse

At a large base cutoff `t`, write

`H_t(s)=sum a_j(t)e^(-delta_j s)e^(i gamma_j s)`,
`0<=s<=h`,

and

`W0=sum|a_j|`.

The nonattained sector has:

1. for every fixed `M`,
   `sum_(gamma_j<=M)|a_j|/W0 ->0`;

2. for every fixed `eps>0`,
   `sum_(delta_j>=eps)|a_j|/W0 ->0`,
   hence `sum delta_j|a_j|/W0->0`.

Therefore the amplitudes freeze on fixed windows:

`sup_(0<=s<=h)|H_t(s)-sum a_j e^(i gamma_j s)|/W0 ->0`.

For every `phi in C_c^infinity(0,h)`,

`int phi(s) sum a_j e^(i gamma_j s) ds
 =sum a_j phi_hat(-gamma_j)`.

Fourier decay plus absolute frequency escape gives

`(1/W0) int phi H_t ->0`.

Now assume a shrinking phase-sector lock: after multiplication by a bounded
carrier and one constant phase rotation,

`|arg Z_t(s)|<=eps_t`,
`eps_t->0`.

For every nonnegative interior test function,

`Re Z_t(s)>=cos(eps_t)|H_t(s)|`.

But the test integral of `Z_t/W0` tends to zero. Hence

`(1/W0) int phi(s)|H_t(s)| ds ->0`.

So a genuinely nonattained family satisfying the v411 short-window phase lock
must undergo **window-averaged normalized coherence collapse**.

This rules out the complete noncollapsed broad-band alternative left by v474.

**Verdict:** {payload['verdict']}

Remaining theorem: show this persistent window coherence collapse contradicts
fixed-action-label transversality/no-fold, or derive its signed primitive-beta
law.
""",
        encoding="utf-8",
    )

    cert.write_text(
        json.dumps({
            "schema": "ROT_RH_NONATTAINED_WINDOW_COHERENCE_COLLAPSE_V1",
            "closed": {
                "frequency_escape_test":
                    "normalized test integral of frozen collective signal tends to zero",
                "deficit_escape":
                    "normalized delta-moment tends to zero",
                "fixed_window_freeze":
                    "actual and frozen collective signals differ by o(W0)",
                "phase_sector":
                    "shrinking sector + escaping spectrum forces weighted L1 coherence collapse",
                "v411_consequence":
                    "LOCK_TRANSFER => window-averaged |H|/W0 ->0",
            },
            "eliminated":
                "nonattained broad-band but noncollapsed fixed-window phase-lock branch",
            "remaining": {
                "window_collapse_transversality":
                    "prove persistent normalized coherence collapse incompatible with Phi_E>=c t / branch no-fold",
                "alternative":
                    "derive exact primitive-beta law if a collapsed collective branch can persist",
            },
        }, indent=2),
        encoding="utf-8",
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--prefix",
        default="rot_rh_nonattained_window_coherence_collapse_v476",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*196)
    print("ROT-RH v476 — NONATTAINED WINDOW-LOCK IMPLIES COHERENCE COLLAPSE")
    print("="*196)

    with tqdm(total=2, desc="v476 theorem", unit="step") as bar:
        sym = symbolic_freeze_bound()
        bar.update(1)
        demo = finite_escape_demo()
        bar.update(1)

    passed = bool(sym["pass"])
    verdict = (
        "EXACT_NONATTAINED_WINDOW_LOCK_COHERENCE_COLLAPSE_PASS"
        if passed else
        "NONATTAINED_WINDOW_COLLAPSE_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic": demo,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "diagnostic_used_as_proof": False,
        },
        "proof_status": (
            "Exact abstract Fourier/test-function reduction using the already "
            "established nonattained absolute frequency escape and elementary "
            "deficit concentration. The only remaining zero-side mechanism is "
            "persistent window coherence collapse."
        ),
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("freeze algebra                  :", sym["pass"])
    print("diagnostic first/last           :",
          f"{demo[0]['test_integral_abs']:.6e}",
          "/",
          f"{demo[-1]['test_integral_abs']:.6e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
