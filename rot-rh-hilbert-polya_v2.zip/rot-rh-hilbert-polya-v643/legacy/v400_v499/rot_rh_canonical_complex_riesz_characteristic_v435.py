#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v435 — CANONICAL COMPLEX RIESZ CHARACTERISTIC NORMALIZATION
==================================================================

Purpose
-------
v434 proved that the diagonal root spectrum, even augmented by first slopes at
the roots, does NOT determine the off-shell secular function.

That does NOT mean the arithmetic construction itself lacks a canonical
off-shell function.  The v71 Riesz/PNT-centered phase already supplies one.

Let

    a = log 2,
    s_E = 1/2 + iE,

and let

    dDelta_psi(u)
      = sum_n Lambda(n) delta_(log n)(du) - e^u du.

Define the COMPLEX Riesz primitive

    Q_L(E)
      = int_a^L
          [(1-u/L)/u] e^(-s_E u) dDelta_psi(u).

Equivalently,

    Q_L(E)
      = sum_(n<e^L)
          [Lambda(n)/log n]
          n^(-1/2-iE)
          (1-log n/L)
        - int_a^L
          [(1-u/L)/u]
          e^((1/2-iE)u) du.

This object is:
  * zero-free/arithmetic-only;
  * defined OFF SHELL, independently of roots;
  * canonically normalized by Q_a(E)=0.

Exact generator identity
------------------------
Because the Riesz kernel vanishes at u=L,

    partial_L Q_L(E)
      = C0^C(L,E)/L^2,

where

    C0^C(L,E)
      = int_a^L e^(-s_Eu) dDelta_psi(u)

      = sum_(n<e^L) Lambda(n)n^(-1/2-iE)
        - int_a^L e^((1/2-iE)u)du.

For real E,

    Im C0^C(L,E) = -C0^sin(L,E),

hence

    partial_L Im Q_L(E)
      = -C0^sin(L,E)/L^2,

which is exactly the v414/v429 cutoff generator for the real secular phase.

Connection to v71 phase
-----------------------
For real E,

    Im Q_L(E)
      = -P_L^R(E) + M_L^R(E)
      = F_L(E) - theta(E).

Therefore the normalized arithmetic determinant correction is

    chi_L(E)
      = exp(2i Im Q_L(E)).

To obtain an analytic off-shell formula without complex conjugation, define

    chi_L(z)
      = exp(Q_L(z)-Q_L(-z)).

On the real axis Q_L(-E)=conj(Q_L(E)), so the two definitions agree:

    chi_L(E)
      = exp(2i Im Q_L(E))
      = exp(2i[F_L(E)-theta(E)]).

Canonical normalization
-----------------------
At the empty arithmetic cutoff L=a=log2,

    Q_a(z)=0,
    chi_a(z)=1.

Moreover chi is the unique solution of

    partial_L log chi_L(z)
      = [C0^C(L,z)-C0^C(L,-z)]/L^2,
    chi_a(z)=1.

Thus the zero-free multiplicative ambiguity identified by v434 is removed
at the SCALAR arithmetic level by the explicit prime/PNT cutoff ODE plus the
empty-cutoff normalization.

What remains open
-----------------
v435 does NOT claim that chi_L is already the characteristic function of an
energy-independent Hilbert-space colligation or a Fredholm determinant.

The next theorem is:

    REALIZE chi_L(z), or the full centered D_L(z), EXACTLY as a canonical
    characteristic/Fredholm function of an energy-independent zero-free
    arithmetic operator, preserving the empty-cutoff normalization.

Only then can operator norm/resolvent/trace-class estimates legitimately be
used to control the v432 complex forcing.

What the script does
--------------------
1. Symbolically proves the Riesz generator and analytic chi identities.
2. Uses the exact v71 prime-power arithmetic, no roots.
3. Computes Q_L(E) at the v432 fixed-energy/tube points.
4. Independently compares Im Q_L(E) with v71 phase_grid(E)-theta(E).
5. Compares chi_L(E) with exp(2i[phase_grid-theta]).
6. Verifies Q_(log2)=0 and chi_(log2)=1.
7. Checks the exact dyadic complex Riesz increment in two forms:
       direct Q_(2X)-Q_X,
       swapped Stieltjes kernel.
8. Writes the canonical characteristic/Fredholm operator-realization
   certificate.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates used in construction.
NO RH assumption.
NO new root solves.
NO larger cutoff than v432.
Finite reconstruction checks are identity validation, not RH proof.

Version: 435
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 435
LOG2 = math.log(2.0)
EPS = 1.0e-300


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def call_trig_sum(
    base,
    energies: np.ndarray,
    logs: np.ndarray,
    weights: np.ndarray,
    trig: str,
    *,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}

    try:
        return np.asarray(
            fn(energies, logs, weights, trig, **kwargs),
            float,
        )
    except TypeError:
        return np.asarray(
            fn(energies, logs, weights, trig),
            float,
        )


def support_count(logs: np.ndarray, L: float) -> int:
    return int(
        np.searchsorted(
            logs,
            float(L)-1.0e-14,
            side="left",
        )
    )


def relative_error(a, b, floor=1e-12):
    return np.abs(a-b)/np.maximum(np.abs(b), floor)


# -----------------------------------------------------------------------------
# Symbolic identities
# -----------------------------------------------------------------------------

def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, u = sp.symbols("L u", positive=True, real=True)
    z = sp.symbols("z")
    f = sp.Function("f")

    kernel = (1-u/L)/u
    dkernel = sp.simplify(sp.diff(kernel, L))
    expected = 1/L**2

    boundary = sp.simplify(kernel.subs(u, L))

    Qp, Qm, Cp, Cm = sp.symbols(
        "Qp Qm Cp Cm"
    )
    chi = sp.exp(Qp-Qm)

    # Formal cutoff logarithmic derivative under Q'_+=C+/L^2,
    # Q'_- = C-/L^2.
    dlogchi = sp.simplify((Cp-Cm)/L**2)

    return {
        "riesz_kernel": "(1-u/L)/u",
        "kernel_L_derivative": str(dkernel),
        "expected_kernel_L_derivative": str(expected),
        "upper_boundary_kernel": str(boundary),
        "complex_generator": (
            "partial_L Q_L(z)=C0^C(L,z)/L^2"
        ),
        "analytic_characteristic": (
            "chi_L(z)=exp(Q_L(z)-Q_L(-z))"
        ),
        "characteristic_generator": (
            "partial_L log chi_L(z)="
            "[C0^C(L,z)-C0^C(L,-z)]/L^2"
        ),
        "empty_cutoff_normalization": (
            "Q_log2(z)=0, chi_log2(z)=1"
        ),
        "formal_dlogchi": str(dlogchi),
        "pass": bool(
            sp.simplify(dkernel-expected) == 0
            and boundary == 0
        ),
    }


# -----------------------------------------------------------------------------
# Arithmetic cache
# -----------------------------------------------------------------------------

def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(
        primes,
        int(max_cutoff),
    )
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)

    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    # Lambda(n)/log n = 1/m for n=p^m.
    coeff = 1.0/exponents
    return primes, logs, exponents, coeff


def smooth_complex_riesz(E: np.ndarray, L: float) -> np.ndarray:
    """
    Integral_a^L [(1-u/L)/u] exp[(1/2-iE)u] du.

    Closed form:
      Ei(alpha L)-Ei(alpha a)
      -(1/L)(exp(alpha L)-exp(alpha a))/alpha

    with alpha=1/2-iE.
    """
    try:
        from scipy.special import expi
    except Exception as exc:
        raise RuntimeError(
            "v435 requires scipy.special.expi. "
            "Install/repair scipy with: python -m pip install scipy"
        ) from exc

    E = np.atleast_1d(np.asarray(E, float))
    alpha = 0.5-1j*E

    return (
        expi(alpha*L)
        - expi(alpha*LOG2)
        - (
            np.exp(alpha*L)
            - np.exp(alpha*LOG2)
        )/(L*alpha)
    )


def Q_complex(
    *,
    base,
    logs: np.ndarray,
    coeff: np.ndarray,
    X: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L = math.log(float(X))
    E = np.atleast_1d(np.asarray(E, float))

    if L <= LOG2 + 5e-15:
        return np.zeros(len(E), dtype=complex)

    k = support_count(logs, L)
    l = logs[:k]
    c = coeff[:k]

    amp = c*np.exp(-0.5*l)*(1.0-l/L)

    real = call_trig_sum(
        base,
        E,
        l,
        amp,
        "cos",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    # e^(-i E log n) = cos - i sin.
    imagminus = call_trig_sum(
        base,
        E,
        l,
        amp,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )

    prime = real-1j*imagminus
    smooth = smooth_complex_riesz(E, L)
    return prime-smooth


def C0_complex(
    *,
    base,
    logs: np.ndarray,
    coeff: np.ndarray,
    X: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    L = math.log(float(X))
    E = np.atleast_1d(np.asarray(E, float))

    k = support_count(logs, L)
    l = logs[:k]

    # Lambda(n) = log n / m = log n * coeff.
    lam_amp = coeff[:k]*l*np.exp(-0.5*l)

    real = call_trig_sum(
        base,
        E,
        l,
        lam_amp,
        "cos",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    sinv = call_trig_sum(
        base,
        E,
        l,
        lam_amp,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    prime = real-1j*sinv

    alpha = 0.5-1j*E
    smooth = (
        np.exp(alpha*L)
        - np.exp(alpha*LOG2)
    )/alpha

    return prime-smooth


def swapped_dyadic_Q_increment(
    *,
    base,
    logs: np.ndarray,
    coeff: np.ndarray,
    X0: int,
    X1: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
) -> np.ndarray:
    """
    Exact Fubini form of Q_(L1)-Q_(L0):

      int_a^L1 K_(L0,L1)(u) e^(-s u) dDelta_psi(u)

    with
      K=1/L0-1/L1       on a<=u<=L0
      K=1/u-1/L1        on L0<u<=L1.
    """
    try:
        from scipy.integrate import quad_vec
    except Exception as exc:
        raise RuntimeError(
            "v435 requires scipy.integrate.quad_vec"
        ) from exc

    L0 = math.log(float(X0))
    L1 = math.log(float(X1))
    E = np.atleast_1d(np.asarray(E, float))

    k1 = support_count(logs, L1)
    l = logs[:k1]
    lam = coeff[:k1]*l

    K = np.where(
        l <= L0,
        1.0/L0-1.0/L1,
        1.0/l-1.0/L1,
    )
    amp = lam*np.exp(-0.5*l)*K

    real = call_trig_sum(
        base,
        E,
        l,
        amp,
        "cos",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    sinv = call_trig_sum(
        base,
        E,
        l,
        amp,
        "sin",
        energy_chunk=energy_chunk,
        term_chunk=term_chunk,
    )
    prime = real-1j*sinv

    # Smooth integral of K(u) exp[(1/2-iE)u] du.
    # Use vector quadrature only as an independent reconstruction check.
    alpha = 0.5-1j*E

    def integrand(u):
        if u <= L0:
            Kval = 1.0/L0-1.0/L1
        else:
            Kval = 1.0/u-1.0/L1
        return Kval*np.exp(alpha*u)

    smooth, _ = quad_vec(
        integrand,
        LOG2,
        L1,
        epsabs=2e-11,
        epsrel=2e-11,
    )

    return prime-smooth


def phase_correction_v71(
    *,
    base,
    logs: np.ndarray,
    coeff: np.ndarray,
    X: int,
    E: np.ndarray,
) -> np.ndarray:
    """
    Evaluate v71 F_X(E)-theta(E), using phase_grid if available.

    v71 phase_grid signature:
        phase_grid(E, X, logs, weights)
    where weights are the Riesz base weights 1/(m sqrt n)*(1-log n/log X).
    """
    if not hasattr(base, "phase_grid") or not hasattr(base, "theta"):
        raise AttributeError(
            "v71 module must expose phase_grid and theta."
        )

    L = math.log(float(X))
    k = support_count(logs, L)
    l = logs[:k]
    w = coeff[:k]*np.exp(-0.5*l)*(1.0-l/L)

    F = np.asarray(
        base.phase_grid(
            np.asarray(E, float),
            int(X),
            l,
            w,
        ),
        float,
    )
    theta = np.asarray(
        base.theta(np.asarray(E, float)),
        float,
    )
    return F-theta


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v432-points",
        default=(
            "rot_rh_complex_dyadic_forcing_laplace_pole_v432_"
            "POINTS.csv.gz"
        ),
    )
    ap.add_argument(
        "--v432-summary",
        default=(
            "rot_rh_complex_dyadic_forcing_laplace_pole_v432_"
            "SUMMARY.json"
        ),
    )
    ap.add_argument(
        "--v434-summary",
        default=(
            "rot_rh_spectral_offshell_ambiguity_characteristic_bridge_v434_"
            "SUMMARY.json"
        ),
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )
    ap.add_argument("--energy-chunk", type=int, default=6)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument(
        "--maximum-phase-absolute",
        type=float,
        default=2e-9,
    )
    ap.add_argument(
        "--maximum-characteristic-absolute",
        type=float,
        default=2e-9,
    )
    ap.add_argument(
        "--maximum-dyadic-increment-relative",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--direct-check-modes",
        type=int,
        default=3,
        help="Modes per shell for the slower independent swapped-integral check.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_canonical_complex_riesz_characteristic_v435",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    v432 = load_json(args.v432_summary)
    v434 = load_json(args.v434_summary)

    v432_ok = bool(
        v432 is not None
        and v432.get("verdict")
        == "EXACT_COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_PASS"
    )
    v434_ok = bool(
        v434 is not None
        and str(v434.get("verdict", "")).startswith(
            "EXACT_ROOTS_AND_SLOPES_OFFSHELL_NONUNIQUENESS_PASS"
        )
    )

    print("="*232)
    print("ROT-RH v435 — CANONICAL COMPLEX RIESZ CHARACTERISTIC NORMALIZATION")
    print("="*232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff than v432                   : NONE")
    print("finite identity checks accepted as proof  : NO")
    print("="*232)

    print("[1] Upstream")
    print(
        "v432 complex forcing reduction            :",
        v432_ok,
        None if v432 is None else v432.get("verdict"),
    )
    print(
        "v434 off-shell ambiguity theorem          :",
        v434_ok,
        None if v434 is None else v434.get("verdict"),
    )

    print("\n[2] Exact scalar normalization algebra")
    sym = symbolic_checks()
    print("symbolic Riesz generator pass             :", sym.get("pass"))
    print("complex generator                         :", sym.get("complex_generator"))
    print("analytic characteristic                  :", sym.get("analytic_characteristic"))
    print("empty-cutoff normalization               :", sym.get("empty_cutoff_normalization"))
    if not sym.get("pass") and args.strict:
        return 2

    points_path = Path(args.v432_points)
    if not points_path.exists():
        raise FileNotFoundError(points_path)

    df = pd.read_csv(points_path)
    required = {
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate", "E_fixed",
    }
    missing = sorted(required-set(df.columns))
    if missing:
        raise KeyError(
            f"v432 points missing columns: {missing}"
        )

    max_X = int(df["X1"].max())
    base = importlib.import_module(args.v71_module)

    print("\n[3] Cached zero-free arithmetic")
    t0 = time.time()
    primes, logs, exponents, coeff = build_cache(
        base,
        max_X,
    )
    print("maximum reused cutoff                    :", f"{max_X:,}")
    print("primes                                   :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    rows = []
    direct_rows = []
    max_phase_abs = 0.0
    max_chi_abs = 0.0
    max_dyadic_rel = 0.0

    groups = list(
        df.groupby(
            ["set","shell_index","X0","X1"],
            sort=True,
            dropna=False,
        )
    )

    bar = tqdm(
        total=len(groups),
        desc="canonical complex Riesz shells",
        unit="shell",
    )

    for key, g in groups:
        setname, shell_index, X0, X1 = key
        X0 = int(X0)
        X1 = int(X1)
        gg = g.sort_values(
            ["root_index","tube_coordinate"]
        ).reset_index(drop=True)

        E = gg["E_fixed"].to_numpy(float)

        Q0 = Q_complex(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X0,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        Q1 = Q_complex(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X1,
            E=E,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )

        corr0 = phase_correction_v71(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X0,
            E=E,
        )
        corr1 = phase_correction_v71(
            base=base,
            logs=logs,
            coeff=coeff,
            X=X1,
            E=E,
        )

        phase_res0 = np.abs(np.imag(Q0)-corr0)
        phase_res1 = np.abs(np.imag(Q1)-corr1)
        phase_res = np.maximum(phase_res0, phase_res1)
        max_phase_abs = max(
            max_phase_abs,
            float(np.max(phase_res)),
        )

        # Analytic real-axis characteristic:
        # Q(-E)=conj(Q(E)).
        chi0 = np.exp(Q0-np.conjugate(Q0))
        chi1 = np.exp(Q1-np.conjugate(Q1))
        phase_chi0 = np.exp(2j*corr0)
        phase_chi1 = np.exp(2j*corr1)
        chi_res = np.maximum(
            np.abs(chi0-phase_chi0),
            np.abs(chi1-phase_chi1),
        )
        max_chi_abs = max(
            max_chi_abs,
            float(np.max(chi_res)),
        )

        dQ = Q1-Q0

        # Slower independent check for central tube coordinate and first modes.
        central = gg[
            np.abs(gg["tube_coordinate"].to_numpy(float)) <= 1e-15
        ].head(int(args.direct_check_modes))
        if len(central):
            Ec = central["E_fixed"].to_numpy(float)
            Q0c = Q_complex(
                base=base, logs=logs, coeff=coeff,
                X=X0, E=Ec,
                energy_chunk=args.energy_chunk,
                term_chunk=args.term_chunk,
            )
            Q1c = Q_complex(
                base=base, logs=logs, coeff=coeff,
                X=X1, E=Ec,
                energy_chunk=args.energy_chunk,
                term_chunk=args.term_chunk,
            )
            direct = swapped_dyadic_Q_increment(
                base=base,
                logs=logs,
                coeff=coeff,
                X0=X0,
                X1=X1,
                E=Ec,
                energy_chunk=args.energy_chunk,
                term_chunk=args.term_chunk,
            )
            rel = relative_error(
                direct,
                Q1c-Q0c,
                floor=1e-10,
            )
            max_dyadic_rel = max(
                max_dyadic_rel,
                float(np.max(rel)),
            )
            for i in range(len(Ec)):
                direct_rows.append({
                    "set": str(setname),
                    "shell_index": int(shell_index),
                    "X0": X0,
                    "X1": X1,
                    "root_index": int(
                        central.iloc[i]["root_index"]
                    ),
                    "E_fixed": float(Ec[i]),
                    "direct_increment_real": float(
                        np.real(Q1c[i]-Q0c[i])
                    ),
                    "direct_increment_imag": float(
                        np.imag(Q1c[i]-Q0c[i])
                    ),
                    "swapped_increment_real": float(
                        np.real(direct[i])
                    ),
                    "swapped_increment_imag": float(
                        np.imag(direct[i])
                    ),
                    "relative_residual": float(rel[i]),
                })

        for i in range(len(gg)):
            rows.append({
                "set": str(setname),
                "shell_index": int(shell_index),
                "X0": X0,
                "X1": X1,
                "root_index": int(gg.iloc[i]["root_index"]),
                "tube_coordinate": float(
                    gg.iloc[i]["tube_coordinate"]
                ),
                "E_fixed": float(E[i]),
                "Q_X0_real": float(np.real(Q0[i])),
                "Q_X0_imag": float(np.imag(Q0[i])),
                "Q_X1_real": float(np.real(Q1[i])),
                "Q_X1_imag": float(np.imag(Q1[i])),
                "phase_correction_X0": float(corr0[i]),
                "phase_correction_X1": float(corr1[i]),
                "phase_absolute_residual": float(phase_res[i]),
                "chi_X0_real": float(np.real(chi0[i])),
                "chi_X0_imag": float(np.imag(chi0[i])),
                "chi_X1_real": float(np.real(chi1[i])),
                "chi_X1_imag": float(np.imag(chi1[i])),
                "chi_modulus_X0": float(np.abs(chi0[i])),
                "chi_modulus_X1": float(np.abs(chi1[i])),
                "characteristic_absolute_residual": float(
                    chi_res[i]
                ),
                "dQ_real": float(np.real(dQ[i])),
                "dQ_imag": float(np.imag(dQ[i])),
            })

        bar.update(1)

    bar.close()

    out = pd.DataFrame(rows)
    direct_df = pd.DataFrame(direct_rows)

    # Empty cutoff normalization is exact by definition and can be checked
    # without sieving support.
    sampleE = np.array([0.0, 1.25, 7.0], float)
    Qempty = Q_complex(
        base=base,
        logs=logs,
        coeff=coeff,
        X=2,
        E=sampleE,
        energy_chunk=args.energy_chunk,
        term_chunk=args.term_chunk,
    )
    empty_Q_abs = float(np.max(np.abs(Qempty)))
    empty_chi_abs = float(
        np.max(
            np.abs(
                np.exp(Qempty-np.conjugate(Qempty))-1.0
            )
        )
    )

    reconstruction_pass = bool(
        max_phase_abs <= args.maximum_phase_absolute
        and max_chi_abs <= args.maximum_characteristic_absolute
        and max_dyadic_rel <= args.maximum_dyadic_increment_relative
        and empty_Q_abs <= 1e-15
        and empty_chi_abs <= 1e-15
    )

    print("\n[4] Canonical phase/characteristic reconstruction")
    print(
        "maximum |Im Q - (F-theta)|              :",
        f"{max_phase_abs:.12e}",
    )
    print(
        "maximum |chi-exp(2i(F-theta))|          :",
        f"{max_chi_abs:.12e}",
    )
    print(
        "maximum dyadic Q increment relative     :",
        f"{max_dyadic_rel:.12e}",
    )
    print(
        "empty-cutoff max |Q_log2|               :",
        f"{empty_Q_abs:.12e}",
    )
    print(
        "empty-cutoff max |chi_log2-1|           :",
        f"{empty_chi_abs:.12e}",
    )
    print(
        "canonical scalar reconstruction pass    :",
        reconstruction_pass,
    )

    exact_pass = bool(
        sym.get("pass")
        and v432_ok
        and v434_ok
        and reconstruction_pass
    )

    verdict = (
        "EXACT_CANONICAL_COMPLEX_RIESZ_SCALAR_CHARACTERISTIC_NORMALIZATION_PASS"
        if exact_pass
        else
        "CANONICAL_COMPLEX_RIESZ_SCALAR_CHARACTERISTIC_NORMALIZATION_INCOMPLETE"
    )
    next_theorem = (
        "REALIZE_CANONICAL_CHI_L_AS_ENERGY_INDEPENDENT_COLLOCATION_OR_FREDHOLM_CHARACTERISTIC_WITH_UNIFORM_CUTOFF_CONTROL"
    )

    print("\n" + "="*232)
    print("VERDICT                                   :", verdict)
    print(
        "v434 ZERO-FREE FACTOR AMBIGUITY           :",
        "REMOVED AT SCALAR ARITHMETIC LEVEL"
        if exact_pass else "NOT YET REMOVED",
    )
    print(
        "CANONICAL NORMALIZATION                   : Q_log2=0, chi_log2=1"
    )
    print(
        "OPERATOR/FREDHOLM REALIZATION             : OPEN"
    )
    print(
        "BOUND |J_complex|                         : NOT PROVED"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*232)

    prefix = Path(args.prefix)
    points_out = Path(str(prefix)+"_POINTS.csv.gz")
    direct_out = Path(str(prefix)+"_DIRECT_INCREMENT_CHECK.csv")
    summary_out = Path(str(prefix)+"_SUMMARY.json")
    theorem_out = Path(str(prefix)+"_THEOREM.md")
    cert_out = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    out.to_csv(
        points_out,
        index=False,
        compression="gzip",
    )
    direct_df.to_csv(direct_out, index=False)

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used_in_construction": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v432": False,
        },
        "upstream": {
            "v432_ok": v432_ok,
            "v434_ok": v434_ok,
        },
        "symbolic": sym,
        "canonical_function": {
            "Q": (
                "int_log2^L ((1-u/L)/u) exp(-(1/2+iE)u) dDelta_psi(u)"
            ),
            "chi": "exp(Q_L(z)-Q_L(-z))",
            "real_axis_identity": (
                "chi_L(E)=exp(2i Im Q_L(E))="
                "exp(2i(F_L(E)-theta(E)))"
            ),
            "normalization": "Q_log2=0, chi_log2=1",
            "cutoff_ODE": (
                "partial_L log chi="
                "[C0^C(L,z)-C0^C(L,-z)]/L^2"
            ),
        },
        "reconstruction": {
            "maximum_phase_absolute_residual": max_phase_abs,
            "maximum_characteristic_absolute_residual": max_chi_abs,
            "maximum_dyadic_increment_relative_residual": max_dyadic_rel,
            "empty_Q_max_abs": empty_Q_abs,
            "empty_chi_minus_one_max_abs": empty_chi_abs,
            "pass": reconstruction_pass,
        },
        "logical_conclusion": {
            "roots_needed_to_define_Q_or_chi": False,
            "root_slopes_needed": False,
            "scalar_zero_free_factor_ambiguity_remaining": False,
            "operator_realization_remaining": True,
            "bounded_complex_forcing_proved": False,
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_out.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        r"""# ROT-RH v435 — canonical scalar off-shell normalization

Let

`Q_L(z)
 =int_(log2)^L [(1-u/L)/u] e^(-(1/2+iz)u) dDelta_psi(u)`.

This is defined entirely from the prime-power Chebyshev measure and the
unconditional PNT main measure.

Because the Riesz kernel vanishes at the moving upper endpoint,

`partial_L Q_L(z)=C0^C(L,z)/L^2`.

At `L=log2` the integration interval is empty:

`Q_log2(z)=0`.

Define

`chi_L(z)=exp(Q_L(z)-Q_L(-z))`.

Then

`chi_log2(z)=1`

and

`partial_L log chi_L(z)
 =[C0^C(L,z)-C0^C(L,-z)]/L^2`.

For real `E`,

`Q_L(-E)=conj(Q_L(E))`,

so

`chi_L(E)=exp(2i Im Q_L(E))`.

The v71 real phase satisfies

`Im Q_L(E)=F_L(E)-theta(E)`,

hence

`chi_L(E)=exp(2i[F_L(E)-theta(E)])`.

Therefore the off-shell scalar arithmetic correction is canonically fixed
without using its roots.  The roots+slopes ambiguity of v434 applies only if
one tries to reconstruct the secular function from spectral data after the
fact.

The remaining Hilbert-Polya bridge is now precise:

Construct an energy-independent zero-free arithmetic colligation or
trace/Fredholm operator whose characteristic function is exactly `chi_L(z)`
(or the full centered determinant after adjoining the explicit theta factor),
with the empty-cutoff normalization preserved.

Only after that exact operator identity is established can a uniform operator
bound be used non-circularly to control the v432 complex forcing.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_CANONICAL_CHI_OPERATOR_REALIZATION_V1",
        "scalar_characteristic": {
            "proved": exact_pass,
            "Q": (
                "Q_L(z)=int_log2^L ((1-u/L)/u)"
                " exp(-(1/2+iz)u)dDelta_psi(u)"
            ),
            "chi": "chi_L(z)=exp(Q_L(z)-Q_L(-z))",
            "normalization": "Q_log2=0; chi_log2=1",
        },
        "required_operator_claims": {
            "energy_independent_realization": {
                "proved": False,
                "statement": (
                    "Construct A_L,B_L,C_L,D_L independent of spectral "
                    "parameter z, or a Fredholm family with fixed operator data, "
                    "whose characteristic determinant equals canonical chi_L(z)."
                ),
            },
            "normalization_preservation": {
                "proved": False,
                "statement": (
                    "The operator realization must give identity characteristic "
                    "at the empty cutoff L=log2 without fitting a zero-free factor."
                ),
            },
            "forcing_observable": {
                "proved": False,
                "statement": (
                    "Derive the v432 J_X^C(E) as a cutoff increment/log derivative/"
                    "controlled matrix or trace observable of this exact realization."
                ),
            },
            "uniform_bound": {
                "proved": False,
                "statement": (
                    "Prove the resulting forcing observable uniformly bounded in X "
                    "from operator estimates independent of RH."
                ),
            },
        },
        "forbidden_shortcuts": [
            "reconstruct chi from roots",
            "reconstruct chi from roots plus slopes",
            "fit the zero-free factor to Xi or known zeros",
            "assume bounded J_complex",
            "assume RH",
            "revive simple full-centered Schur/Herglotz positivity",
        ],
        "consequence": (
            "exact canonical operator realization + uniform forcing bound => "
            "v432 RH implication route, subject to completion of v432's "
            "analytic-continuation certificate"
        ),
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", points_out)
    print(" ", direct_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
