#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v481 — EXPLICIT-FORMULA COEFFICIENT RIGIDITY / ARITHMETIC
SUPERO-SCILLATION TARGET
=================================================================

PURPOSE
-------
Identify exactly which coefficients are available to the remaining v477-style
superoscillatory mechanism.

Start from the symmetrized classical explicit formula for y>log 2:

    psi_0(e^y)
      = e^y
        - sum_rho m_rho e^(rho y)/rho
        - log(2pi)
        - 1/2 log(1-e^(-2y)).

Differentiate with respect to y:

    d psi_0(e^y)
      = [
          e^y
          - sum_rho m_rho e^(rho y)
          - 1/(e^(2y)-1)
        ] dy.

Therefore the centered measure

    dmu(y)=d psi(e^y)-e^y dy

has nontrivial-zero part EXACTLY

    dmu_zero(y)
      = - sum_rho m_rho e^(rho y) dy.

The 1/rho factor has disappeared.

For the canonical compact-bump primitive

    Q_L(E)
      = int p(y/L)e^(-y/2+iEy)dmu(y)/y,

the nontrivial-zero contribution is

    Q_L^zero(E)
      = - sum_rho m_rho
          K_L(rho-1/2+iE),

where

    K_L(lambda)
      = int_(log2)^L
          p(y/L)e^(lambda y) dy/y.

Thus the raw zero coefficients are ONLY

    -m_rho,

with m_rho positive integer multiplicities.

For a right-half zero beta+iGamma, the resonant conjugate channel near
E=Gamma is

    -m_rho K_L(
        (beta-1/2)+i(E-Gamma)
      ).

All such resonant channels have the same raw sign.

MULTIPLICITY SIZE
-----------------
The Riemann-von Mangoldt count gives, classically,

    N(T+1)-N(T-1)=O(log T),

so any individual multiplicity satisfies

    m_rho=O(log(2+|Gamma|)).

Therefore there are no freely tunable exponentially large residue
coefficients.  Any enormous effective coefficient hierarchy must be generated
by the kernel magnitudes

    exp[
      (beta-1/2)L
      - c L^(2/3)Re((beta-1/2+i(E-Gamma))^(2/3))
      + ...
    ]

from v473.

CONSEQUENCE
-----------
v477's generic superoscillatory countermodel remains a valid warning, but its
coefficient freedom is NOT present here.

An actual nonattained ROT-RH superoscillation must be realized by a highly
structured zero configuration satisfying simultaneously:

  1. ordinate placement gamma_rho creates the required destructive phases;
  2. real-part deficits beta_*-beta_rho generate the required effective
     magnitude hierarchy through exp[-delta_rho L];
  3. multiplicities contribute only O(log gamma) factors;
  4. the same fixed zero set must keep producing the v411 lock as L changes;
  5. pairwise transport is excluded by v479-v480.

This defines the exact remaining arithmetic theorem:

ARITHMETIC NO-SUPEROSCILLATION / LOCK THEOREM
---------------------------------------------
Prove that the fixed zeta-zero geometry cannot make

    Q_L^zero(E_k(L))

remain in the v411 shrinking phase sector on every late window while its
normalized coefficient coherence collapses as required by v476-v478;

OR prove that if it can, the induced ordered-root velocity has a subquadratic
v419 primitive.

This is a genuinely arithmetic zero-geometry statement.  It is no longer a
generic Fourier cancellation problem.

No numerical zeta values or known zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v481-explicit-formula-coefficient-rigidity"


def symbolic_explicit_formula() -> Dict[str, Any]:
    import sympy as sp

    y, rho = sp.symbols("y rho", positive=True)
    # One zero term -exp(rho*y)/rho.
    zero_primitive = -sp.exp(rho*y)/rho
    zero_derivative = sp.simplify(sp.diff(zero_primitive, y))

    trivial_primitive = -sp.Rational(1,2)*sp.log(1-sp.exp(-2*y))
    trivial_derivative = sp.simplify(sp.diff(trivial_primitive, y))

    return {
        "zero_primitive": str(zero_primitive),
        "zero_derivative": str(zero_derivative),
        "expected_zero_derivative": "-exp(rho*y)",
        "zero_residual":
            str(sp.simplify(zero_derivative + sp.exp(rho*y))),
        "trivial_derivative": str(trivial_derivative),
        "expected_trivial": "-1/(exp(2*y)-1)",
        "trivial_residual": str(
            sp.simplify(
                trivial_derivative
                + 1/(sp.exp(2*y)-1)
            )
        ),
        "pass": bool(
            sp.simplify(zero_derivative + sp.exp(rho*y)) == 0
            and sp.simplify(
                trivial_derivative
                + 1/(sp.exp(2*y)-1)
            ) == 0
        ),
    }


def multiplicity_comparison():
    # Pure symbolic/asymptotic bookkeeping. No zero data.
    return {
        "classical_input":
            "m(rho)<=N(gamma+1)-N(gamma-1)=O(log(2+|gamma|))",
        "raw_coefficient":
            "-m_rho",
        "free_complex_residue_coefficient": False,
        "exponential_hierarchy_source":
            "kernel saddle exp[(beta-1/2)L-c L^(2/3)Re(lambda^(2/3))+...]",
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v481 — explicit-formula coefficient rigidity

The symmetrized explicit formula contains each nontrivial zero through

`-m_rho e^(rho y)/rho`.

Differentiation gives

`d/dy[-m_rho e^(rho y)/rho]
 =-m_rho e^(rho y)`.

Therefore the centered measure has zero part

`dmu_zero
 =-sum_rho m_rho e^(rho y)dy`.

Consequently the compact-bump primitive has the exact zero expansion

`Q_L^zero(E)
 =-sum_rho m_rho K_L(rho-1/2+iE)`,

where

`K_L(lambda)
 =int p(y/L)e^(lambda y)dy/y`.

There is **no free complex residue coefficient** and no surviving `1/rho`
factor.  The raw coefficients are common-sign integer multiplicities.

Classically,

`m_rho=O(log(2+|gamma_rho|))`.

Thus every exponential coefficient hierarchy needed for v477-style
superoscillation must come from the fixed zero locations through the bump
kernel itself.

**Verdict:** {payload['verdict']}

The remaining theorem is precisely an arithmetic no-superoscillation theorem
for this fixed zero geometry, or a proof that the resulting exceptional lock
still lies in the v419 subquadratic primitive class.
""",
        encoding="utf-8",
    )

    cert.write_text(
        json.dumps({
            "schema": "ROT_RH_EXPLICIT_FORMULA_COEFFICIENT_RIGIDITY_V1",
            "closed": {
                "measure_zero_part":
                    "dmu_zero=-sum m_rho e^(rho y)dy",
                "bump_zero_sum":
                    "Q_L^zero=-sum m_rho K_L(rho-1/2+iE)",
                "raw_coefficients":
                    "common-sign positive integer multiplicities",
                "multiplicity_growth":
                    "m_rho=O(log(2+|gamma|)) from local Riemann-von Mangoldt count",
                "free_coefficients": False,
            },
            "required_next": {
                "arithmetic_no_superoscillation":
                    "use joint beta-gamma geometry to rule out persistent v411 lock with v476-v478 coherence collapse",
                "or_primitive":
                    "prove any such exceptional arithmetic lock has subquadratic v419 characteristic primitive",
            },
        }, indent=2),
        encoding="utf-8",
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--prefix",
        default="rot_rh_explicit_formula_coefficient_rigidity_v481",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*198)
    print("ROT-RH v481 — EXPLICIT-FORMULA COEFFICIENT RIGIDITY")
    print("="*198)
    with tqdm(total=2, desc="v481 theorem", unit="step") as bar:
        sym = symbolic_explicit_formula()
        bar.update(1)
        mult = multiplicity_comparison()
        bar.update(1)

    passed = bool(sym["pass"])
    verdict = (
        "EXACT_EXPLICIT_FORMULA_BUMP_COEFFICIENT_RIGIDITY_PASS"
        if passed else
        "EXPLICIT_FORMULA_COEFFICIENT_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "multiplicity": mult,
        "firewall": {
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
        },
        "proof_status":
            "Exact explicit-formula differentiation plus classical local zero-count multiplicity bound. Remaining issue is arithmetic geometry, not coefficient freedom.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("explicit-formula algebra        :", sym["pass"])
    print("raw zero coefficient            :", mult["raw_coefficient"])
    print("free complex coefficients       :", mult["free_complex_residue_coefficient"])
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
