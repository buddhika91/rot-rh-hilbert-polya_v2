#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v437 — EXACT SIGNED DYADIC KREIN FORCING BRIDGE
=======================================================

Purpose
-------
v436 constructed the exact common-space Krein realization

    Q_L(z)=<psi_L, J e^(-izU) psi_L>

but the ordinary Hilbert norm of psi_L grows and therefore cannot control the
RH-strength complex forcing.

v437 derives the forcing itself as an EXACT dyadic Krein transfer.

Notation
--------
Let

    h = log 2,
    s_E = 1/2 + iE,
    G_E(u)=e^(-s_E u),

and let the centered Chebyshev cumulative error be

    A(L)
      = psi(e^L)-log 2-(e^L-2).

On the fresh shell L<u<L+h define a positive counting vector xi_(L,h) in the
same cutoff-independent space

    K = l2(prime powers) direct_sum L2([log2,infinity),du)

by

discrete:
    |xi(n)|^2 = Lambda(n),      e^L <= n < e^(L+h),

continuum:
    |xi(u)|^2 = e^u,           L <= u < L+h.

Let

    U = multiplication by log-coordinate,
    J = +I_discrete direct_sum -I_continuum.

Then

    <xi,J xi>
       = [psi(e^(L+h))-psi(e^L)] - [e^(L+h)-e^L]
       = A(L+h)-A(L),

and

    <xi,J e^(-s_E U) xi>
       = C0^C(L+h,E)-C0^C(L,E).

Exact forcing identity
----------------------
The v432 complex forcing satisfies

    J_L^C(E)
      = A(L+h)G_E(L+h)-A(L)G_E(L)
        -[C0^C(L+h,E)-C0^C(L,E)].

Using A(L+h)=A(L)+<xi,Jxi> gives

    J_L^C(E)
      = A(L)[G_E(L+h)-G_E(L)]
        + <xi,
            J [G_E(L+h)I-e^(-s_E U)]
            xi>.

This is the exact operator bridge requested after v436.

Important no-go
---------------
For real E, e^(-iEU) is unitary and commutes with J, but that does NOT bound
the forcing because the shell vector is not uniformly bounded in Hilbert norm.

The total-variation shell mass is

    ||xi||^2
      = sum_(X<=n<2X) Lambda(n) + X
      ~ 2X.

Also

    ||G(L+h)I-e^(-sU)||
      <= e^(-(L+h)/2)+e^(-L/2)
      = O(X^(-1/2)).

Hence the generic positive-Hilbert envelope is only

    O(sqrt X),

which diverges.

Therefore support localization, self-adjointness of U, J-unitarity, and the
fixed shell width h=log2 are all insufficient by themselves.  The desired
bound must be a genuinely SIGNED arithmetic Krein-neutrality theorem.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO new root solves.
NO larger cutoff than v432/v436.
Finite cancellation ratios are evidence only.

Version: 437
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 437
LOG2 = math.log(2.0)
EPS = 1.0e-300


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def call_trig_sum(base, energies, logs, weights, trig, *, energy_chunk, term_chunk):
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}
    try:
        return np.asarray(fn(energies, logs, weights, trig, **kwargs), float)
    except TypeError:
        return np.asarray(fn(energies, logs, weights, trig), float)


def support_count(logs: np.ndarray, L: float) -> int:
    return int(np.searchsorted(logs, float(L)-1.0e-14, side="left"))


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}
    A0, dA, dC, G0, G1 = sp.symbols("A0 dA dC G0 G1")
    A1 = A0+dA
    endpoint_form = sp.expand(A1*G1-A0*G0-dC)
    operator_form = sp.expand(A0*(G1-G0)+G1*dA-dC)
    residual = sp.simplify(endpoint_form-operator_form)
    return {
        "memory_update": "A1=A0+<xi,Jxi>",
        "fresh_C0": "Delta C0=<xi,J exp(-sU)xi>",
        "forcing_bridge": "Jc=A0(G1-G0)+<xi,J[G1 I-exp(-sU)]xi>",
        "bridge_residual": str(residual),
        "generic_positive_envelope_scale": "O(sqrt(X))",
        "no_go_counterexample": (
            "On a purely positive channel choose ||xi||^2~X; shell localization "
            "and J-unitarity still allow an O(sqrt(X)) transfer."
        ),
        "pass": bool(residual == 0),
    }


def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(primes, int(max_cutoff))
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)
    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]
    lambda_w = logs/exponents
    lambda_cumsum = np.cumsum(lambda_w, dtype=np.float64)
    return primes, logs, exponents, lambda_w, lambda_cumsum


def psi_minus(logs, lambda_cumsum, L):
    k = support_count(logs, L)
    return float(lambda_cumsum[k-1]) if k > 0 else 0.0


def A_of_L(logs, lambda_cumsum, L):
    return psi_minus(logs, lambda_cumsum, L)-LOG2-(math.exp(L)-2.0)


def shell_indices(logs, L0, L1):
    return support_count(logs, L0), support_count(logs, L1)


def complex_shell_C0(*, base, logs, lambda_w, L0, L1, E, energy_chunk, term_chunk):
    E = np.atleast_1d(np.asarray(E, float))
    k0, k1 = shell_indices(logs, L0, L1)
    l = logs[k0:k1]
    lam = lambda_w[k0:k1]
    amp = lam*np.exp(-0.5*l)
    real = call_trig_sum(base, E, l, amp, "cos", energy_chunk=energy_chunk, term_chunk=term_chunk)
    sinv = call_trig_sum(base, E, l, amp, "sin", energy_chunk=energy_chunk, term_chunk=term_chunk)
    discrete = real-1j*sinv
    s = 0.5+1j*E
    one_minus_s = 1.0-s
    continuum = (np.exp(one_minus_s*L1)-np.exp(one_minus_s*L0))/one_minus_s
    return discrete-continuum


def shell_signed_count(*, logs, lambda_w, L0, L1):
    k0, k1 = shell_indices(logs, L0, L1)
    discrete = float(np.sum(lambda_w[k0:k1]))
    continuum = math.exp(L1)-math.exp(L0)
    return {
        "discrete_mass": discrete,
        "continuum_mass": continuum,
        "signed_mass": discrete-continuum,
        "total_variation_mass": discrete+continuum,
    }


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--v432-points", default="rot_rh_complex_dyadic_forcing_laplace_pole_v432_POINTS.csv.gz")
    ap.add_argument("--v432-summary", default="rot_rh_complex_dyadic_forcing_laplace_pole_v432_SUMMARY.json")
    ap.add_argument("--v436-summary", default="rot_rh_exact_krein_fock_characteristic_v436_SUMMARY.json")
    ap.add_argument("--v71-module", default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71")
    ap.add_argument("--energy-chunk", type=int, default=6)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument("--maximum-forcing-absolute", type=float, default=3e-9)
    ap.add_argument("--maximum-memory-update-absolute", type=float, default=2e-6)
    ap.add_argument("--development-gain-safety", type=float, default=1.5)
    ap.add_argument("--prefix", default="rot_rh_signed_dyadic_krein_forcing_bridge_v437")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    v432 = load_json(args.v432_summary)
    v436 = load_json(args.v436_summary)

    v432_ok = bool(v432 is not None and v432.get("verdict") == "EXACT_COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_PASS")
    v436_ok = bool(v436 is not None and v436.get("verdict") == "EXACT_CANONICAL_KREIN_FOCK_CHARACTERISTIC_REALIZATION_PASS_POSITIVE_NORM_BOUND_NO_GO")

    print("="*232)
    print("ROT-RH v437 — EXACT SIGNED DYADIC KREIN FORCING BRIDGE")
    print("="*232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves / larger cutoff           : NONE")
    print("finite cancellation accepted as proof     : NO")
    print("="*232)

    print("[1] Upstream")
    print("v432 complex forcing reduction            :", v432_ok, None if v432 is None else v432.get("verdict"))
    print("v436 exact Krein/Fock realization         :", v436_ok, None if v436 is None else v436.get("verdict"))

    print("\n[2] Exact signed-shell operator algebra")
    sym = symbolic_checks()
    print("symbolic bridge pass                      :", sym.get("pass"))
    print("forcing bridge                           :", sym.get("forcing_bridge"))
    print("generic positive envelope                :", sym.get("generic_positive_envelope_scale"))
    print("operator-only no-go                      :", sym.get("no_go_counterexample"))

    p = Path(args.v432_points)
    if not p.exists():
        raise FileNotFoundError(p)
    df = pd.read_csv(p)
    required = {
        "set","shell_index","X0","X1","root_index","tube_coordinate","E_fixed",
        "J_complex_real","J_complex_imag",
    }
    missing = sorted(required-set(df.columns))
    if missing:
        raise KeyError(f"v432 points missing columns: {missing}")

    max_X = int(df["X1"].max())
    base = importlib.import_module(args.v71_module)

    print("\n[3] Zero-free fresh-shell arithmetic cache")
    t0 = time.time()
    primes, logs, exponents, lambda_w, lambda_cumsum = build_cache(base, max_X)
    print("maximum reused cutoff                    :", f"{max_X:,}")
    print("primes                                   :", f"{len(primes):,}")
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    rows = []
    shell_rows = []
    max_forcing_abs = 0.0
    max_memory_update_abs = 0.0

    groups = list(df.groupby(["set","shell_index","X0","X1"], sort=True, dropna=False))
    bar = tqdm(total=len(groups), desc="signed dyadic Krein forcing", unit="shell")

    for key, g in groups:
        setname, shell_index, X0, X1 = key
        X0, X1 = int(X0), int(X1)
        L0, L1 = math.log(float(X0)), math.log(float(X1))
        gg = g.sort_values(["root_index","tube_coordinate"]).reset_index(drop=True)
        E = gg["E_fixed"].to_numpy(float)
        s = 0.5+1j*E
        G0, G1 = np.exp(-s*L0), np.exp(-s*L1)

        A0 = A_of_L(logs, lambda_cumsum, L0)
        A1 = A_of_L(logs, lambda_cumsum, L1)
        shell = shell_signed_count(logs=logs, lambda_w=lambda_w, L0=L0, L1=L1)
        dA = shell["signed_mass"]
        memory_update_resid = abs((A0+dA)-A1)
        max_memory_update_abs = max(max_memory_update_abs, memory_update_resid)

        dC = complex_shell_C0(
            base=base, logs=logs, lambda_w=lambda_w, L0=L0, L1=L1, E=E,
            energy_chunk=args.energy_chunk, term_chunk=args.term_chunk
        )

        memory_term = A0*(G1-G0)
        shell_operator_term = G1*dA-dC
        forcing = memory_term+shell_operator_term
        forcing_ref = gg["J_complex_real"].to_numpy(float) + 1j*gg["J_complex_imag"].to_numpy(float)
        forcing_abs_resid = np.abs(forcing-forcing_ref)
        max_forcing_abs = max(max_forcing_abs, float(np.max(forcing_abs_resid)))

        kernel_envelope = np.abs(G1) + math.exp(-0.5*L0)
        shell_positive_envelope = shell["total_variation_mass"]*kernel_envelope
        memory_positive_envelope = abs(A0)*np.abs(G1-G0)
        total_positive_envelope = shell_positive_envelope+memory_positive_envelope
        shell_gain = np.abs(shell_operator_term)/np.maximum(shell_positive_envelope, EPS)
        total_gain = np.abs(forcing)/np.maximum(total_positive_envelope, EPS)

        for i in range(len(gg)):
            rows.append({
                "set": str(setname), "shell_index": int(shell_index), "X0": X0, "X1": X1,
                "root_index": int(gg.iloc[i]["root_index"]),
                "tube_coordinate": float(gg.iloc[i]["tube_coordinate"]),
                "E_fixed": float(E[i]),
                "A0": A0, "A1": A1,
                "shell_signed_count": dA,
                "shell_total_variation_mass": shell["total_variation_mass"],
                "memory_update_absolute_residual": memory_update_resid,
                "delta_C0_real": float(np.real(dC[i])),
                "delta_C0_imag": float(np.imag(dC[i])),
                "memory_term_real": float(np.real(memory_term[i])),
                "memory_term_imag": float(np.imag(memory_term[i])),
                "shell_operator_term_real": float(np.real(shell_operator_term[i])),
                "shell_operator_term_imag": float(np.imag(shell_operator_term[i])),
                "forcing_real": float(np.real(forcing[i])),
                "forcing_imag": float(np.imag(forcing[i])),
                "forcing_reference_real": float(np.real(forcing_ref[i])),
                "forcing_reference_imag": float(np.imag(forcing_ref[i])),
                "forcing_absolute_residual": float(forcing_abs_resid[i]),
                "memory_positive_envelope": float(memory_positive_envelope[i]),
                "shell_positive_envelope": float(shell_positive_envelope[i]),
                "total_positive_envelope": float(total_positive_envelope[i]),
                "shell_krein_cancellation_gain": float(shell_gain[i]),
                "total_krein_cancellation_gain": float(total_gain[i]),
            })

        shell_rows.append({
            "set": str(setname), "shell_index": int(shell_index), "X0": X0, "X1": X1,
            "A0": A0, "A1": A1, "shell_signed_count": dA,
            "shell_total_variation_mass": shell["total_variation_mass"],
            "memory_update_absolute_residual": memory_update_resid,
            "max_abs_memory_term": float(np.max(np.abs(memory_term))),
            "max_abs_shell_operator_term": float(np.max(np.abs(shell_operator_term))),
            "max_abs_total_forcing": float(np.max(np.abs(forcing))),
            "max_positive_shell_envelope": float(np.max(shell_positive_envelope)),
            "max_positive_total_envelope": float(np.max(total_positive_envelope)),
            "max_shell_krein_cancellation_gain": float(np.max(shell_gain)),
            "median_shell_krein_cancellation_gain": float(np.median(shell_gain)),
            "max_total_krein_cancellation_gain": float(np.max(total_gain)),
            "median_total_krein_cancellation_gain": float(np.median(total_gain)),
        })
        bar.update(1)
    bar.close()

    out = pd.DataFrame(rows)
    shell_df = pd.DataFrame(shell_rows).sort_values(["X0","shell_index"]).reset_index(drop=True)

    reconstruction_pass = bool(
        max_forcing_abs <= args.maximum_forcing_absolute
        and max_memory_update_abs <= args.maximum_memory_update_absolute
    )

    dev = shell_df[shell_df["set"].str.lower() == "development"]
    hold = shell_df[shell_df["set"].str.lower() != "development"]
    if dev.empty:
        dev = shell_df.iloc[:1]
        hold = shell_df.iloc[1:]

    dev_gain = float(dev["max_total_krein_cancellation_gain"].max())
    frozen_gain_cap = args.development_gain_safety*dev_gain
    hold_gain = float(hold["max_total_krein_cancellation_gain"].max()) if not hold.empty else float("nan")
    finite_gain_holdout_pass = bool(not hold.empty and math.isfinite(hold_gain) and hold_gain <= frozen_gain_cap)

    print("\n[4] Exact v432 forcing reconstruction")
    print("maximum forcing absolute residual         :", f"{max_forcing_abs:.12e}")
    print("maximum A-memory update residual          :", f"{max_memory_update_abs:.12e}")
    print("exact signed Krein forcing bridge pass    :", reconstruction_pass)

    print("\n[5] Cancellation versus positive envelope")
    display = [
        "set","shell_index","X0","X1","max_abs_memory_term","max_abs_shell_operator_term",
        "max_abs_total_forcing","max_positive_total_envelope",
        "max_total_krein_cancellation_gain","median_total_krein_cancellation_gain",
    ]
    print(shell_df[display].to_string(index=False, float_format=lambda x: f"{x:.9e}"))
    print("development max cancellation gain         :", f"{dev_gain:.12e}")
    print("frozen finite gain cap                   :", f"{frozen_gain_cap:.12e}")
    print("holdout max cancellation gain             :", f"{hold_gain:.12e}")
    print("finite cancellation-gain holdout pass     :", finite_gain_holdout_pass)

    exact_pass = bool(sym.get("pass") and v432_ok and v436_ok and reconstruction_pass)
    verdict = (
        "EXACT_V432_COMPLEX_FORCING_AS_SIGNED_DYADIC_KREIN_TRANSFER_PASS"
        if exact_pass else
        "V432_COMPLEX_FORCING_SIGNED_DYADIC_KREIN_TRANSFER_INCOMPLETE"
    )
    next_theorem = "PROVE_UNIFORM_ARITHMETIC_KREIN_NEUTRALITY_OF_DYADIC_SHELL_TRANSFER_AND_MEMORY_COUPLING"

    print("\n" + "="*232)
    print("VERDICT                                   :", verdict)
    print("J_complex OPERATOR BRIDGE                 :", "EXACT" if exact_pass else "INCOMPLETE")
    print("SELF-ADJOINT U + J-UNITARITY ALONE        : INSUFFICIENT")
    print("POSITIVE ENVELOPE SCALE                   : O(sqrt X), DIVERGENT")
    print("REQUIRED MISSING PROPERTY                 : ARITHMETIC KREIN NEUTRALITY")
    print("BOUND |J_complex|                         : NOT PROVED")
    print("NEXT THEOREM                              :", next_theorem)
    print("="*232)

    prefix = Path(args.prefix)
    out.to_csv(Path(str(prefix)+"_POINTS.csv.gz"), index=False, compression="gzip")
    shell_df.to_csv(Path(str(prefix)+"_SHELL_SUMMARY.csv"), index=False)

    summary = {
        "version": VERSION,
        "firewall": {"Xi_used":False,"zeta_values_evaluated":False,"known_zero_ordinates_used":False,"RH_assumed":False},
        "upstream":{"v432_ok":v432_ok,"v436_ok":v436_ok},
        "symbolic":sym,
        "reconstruction":{"maximum_forcing_absolute_residual":max_forcing_abs,"maximum_memory_update_absolute_residual":max_memory_update_abs,"pass":reconstruction_pass},
        "finite_cancellation":{"development_max_gain":dev_gain,"frozen_gain_cap":frozen_gain_cap,"holdout_max_gain":hold_gain,"holdout_pass":finite_gain_holdout_pass,"proof_status":"EVIDENCE_ONLY"},
        "verdict":verdict,
        "next_theorem":next_theorem,
        "runtime_seconds":time.time()-started,
    }
    Path(str(prefix)+"_SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    Path(str(prefix)+"_THEOREM.md").write_text(
        """# ROT-RH v437 — exact signed dyadic Krein forcing bridge

For the fresh-shell vector `xi_(L,h)`,

`A(L+h)-A(L)=<xi,Jxi>`

and

`C0^C(L+h,E)-C0^C(L,E)=<xi,J exp(-(1/2+iE)U)xi>`.

Therefore

`J_L^C(E)
 =A(L)[G_E(L+h)-G_E(L)]
  +<xi,J[G_E(L+h)I-exp(-(1/2+iE)U)]xi>`.

This is the exact operator bridge from the canonical arithmetic/Krein system
to the v432 complex forcing.

However `||xi||^2~2X` while the localized operator kernel has norm only
`O(X^-1/2)`, so a positive-Hilbert majorant is merely `O(sqrt X)` and diverges.

The remaining theorem must preserve the signed discrete-minus-continuum
arithmetic cancellation.
""",
        encoding="utf-8"
    )

    cert = {
        "schema":"ROT_RH_ARITHMETIC_KREIN_NEUTRALITY_CERTIFICATE_V1",
        "exact_forcing_bridge_proved":exact_pass,
        "required_claim":{
            "proved":False,
            "statement":"Uniformly bound the exact signed dyadic Krein forcing for each fixed real E without replacing it by total variation or assuming an RH-equivalent prime error bound."
        },
        "forbidden_shortcuts":["assume RH","assume bounded J_complex","square-root PNT error","known zero ordinates","Xi fitting","absolute total-variation majorant"],
        "consequence":"signed arithmetic Krein-neutrality bound + completed v432 analytic-continuation theorem => RH"
    }
    Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps(cert, indent=2), encoding="utf-8")

    print("Files written:")
    print(" ", str(prefix)+"_POINTS.csv.gz")
    print(" ", str(prefix)+"_SHELL_SUMMARY.csv")
    print(" ", str(prefix)+"_SUMMARY.json")
    print(" ", str(prefix)+"_THEOREM.md")
    print(" ", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
