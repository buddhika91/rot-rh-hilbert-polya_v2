# ROT-RH v444 — uniform moving-RG / Duhamel trace-closure theorem

## 1. Exact theorem

Let `L=log X`, and let the ordered arithmetic branches satisfy

`F(L,E_k(L)) = q_k`

and

`partial_L F = -C0/L^2`.

Define

`J_k(L)=partial_E F(L,E_k(L))`

and

`B_k(L)=C0(L,E_k(L))/J_k(L)`.

Then

`E_k'(L)=B_k(L)/L^2`.

Define

`kappa_k=1+(partial_E B_k)/L`

and

`Q_k(L)=int_(L0)^L kappa_k(s)/s ds`.

The v425 RG identity is

`J_k(L)/L = [J_k(L0)/L0] exp(-Q_k(L))`.

Therefore the ONE-SIDED estimate

`Q_k(L)<=Q_*`

implies the root-point no-fold floor

`J_k(L)/L >= c0 exp(-Q_*)`

where

`c0=inf_k J_k(L0)/L0`.

No whole root-to-root segment estimate is needed.

Now define

`Y_k(L)=L exp(-Q_k(L)) B_k(L)`.

Across the arithmetic jump measure let the signed Duhamel theorem be

`|Y_k(L)-Y_k(L0)| <= M(L-L0)`

uniformly in `k,L`.

If

`B0=sup_k |B_k(L0)|<infinity`,

then

`|Y_k(L)| <= L0 B0 + M(L-L0) <= (B0+M)L`

and hence

`|B_k(L)| <= exp(Q_*)[B0+M] =: B_*`.

Thus

`|E_k(infinity)-E_k(L)|
 <= B_* int_L^infinity s^-2 ds
 = B_*/L`.

So fixed-mode convergence is automatic.

For `h=log 2`,

`|E_k(L+h)-E_k(L)|
 <= B_* int_L^(L+h) s^-2 ds
 = B_* h/[L(L+h)]`.

Therefore v443 `U_STEP` holds with

`C_E=h B_*`.

This gives the uniform moving displacement

`sup_(k,L>=L0)|E_k(L)-E_k(L0)| <= B_*/L0`.

Together with the fixed-reference v238 theorem

`D0=sup_k|E_k(L0)-A_k|<infinity`,

we get

`sup_(k,L)|E_k(L)-A_k| <= D0+B_*/L0`.

The free Archimedean Weyl lower bound then gives eventually, uniformly in `L`,

`E_k(L)>=k/log(k+e)`,

hence

`E_k(L)^(-2)<= [log(k+e)/k]^2`.

The majorant is summable. Since the uniform beta theorem already gave

`E_k(L)->E_k(infinity)`

for every fixed `k`, dominated convergence yields

`||H_L^(-2)-H_infinity^(-2)||_1 -> 0`.

Therefore **U_Q + U_D close both the fixed-mode and high-mode parts of the
trace-norm cutoff-removal problem simultaneously.**

## 2. Why this is better than whole-segment v438 transversality

The discrete MVT proof required

`inf_(E between roots) F'_L(E)/L > 0`.

The moving-RG proof does not.

It requires only the root-point stiffness, whose exact evolution is already

`J_k(L)/L=[J_k(L0)/L0] exp(-Q_k(L))`.

So the transversality obstruction becomes the one-sided characteristic theorem

`sup_(k,L) Q_k(L)<infinity`.

This is strictly closer to the physical moving root and avoids asking for
control of a whole fixed-energy interval.

## 3. Why U_D is the right arithmetic target

A pointwise bound on the fixed-energy source is unnecessarily strong and can
destroy the prime/PNT cancellation. Because the cutoff has prime jumps, the
natural object is the signed distributional primitive:

`int_(L0,L] exp(-Q_k(s)) dSigma_k(s)`.

The required statement is only linear signed growth:

`|int exp(-Q)dSigma| <= M(L-L0)`.

This is a moving-characteristic theorem. It does not assert polynomial control
on a nonempty fixed-E tube, so it does not invoke the v440 RH-equivalent
shortcut.

## 4. Native 320-mode finite evidence

The table contains `320` common modes and cutoffs

`[72900, 145800, 291600, 583200, 1166400, 2332800, 4665600]`.

The native RG coordinate was reconstructed only from the stored phase
derivatives:

`Q=-log[(F'/L)/(F'_0/L0)]`.

Observed:

- `max Q = 0.141208485378`
- `min Q = -0.0610423302573`
- `min F'/L = 0.457898210279`

Cutoff-direction Q cap frozen from the first `3` transitions:

- training positive `Q_max = 0.085884477203`
- frozen cap = `0.150297835105`
- future maximum = `0.141208485378`
- future pass = `True`

The exact weighted root-flow observable

`B_eff=(E_b-E_a)/(1/L_a-1/L_b)`

has global finite maximum

`max |B_eff| = 1.09706825469`.

Development-frozen cutoff cap:

`1.37133531836`

Future maximum:

`1.04781329537`

Future pass:

`True`.

These are strong finite all-mode diagnostics. They are **not** U_D.

## 5. Remaining theorem

The deepest remaining analytic target has now been compressed to:

### U_Q
`sup_(k,L) Q_k(L) < infinity`.

### U_D
`sup_(k,L) |Y_k(L)-Y_k(L0)|/(L-L0) < infinity`

with

`Y_k=L exp(-Q_k)B_k`

interpreted using the exact arithmetic jump measure.

If those two statements are proved, the trace-norm cutoff-removal theorem
follows by the chain above. No additional whole-segment transversality theorem
and no separate fixed-mode convergence theorem are needed.

This does not prove RH or the Xi/Fredholm identity.
