#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v403 — G7 RIESZ–MELLIN–BARNES / COLLISION-SEPARATION REDUCTION
=====================================================================

Purpose
-------
After v402, the recursive regular R^7 four-jet transfer is globally
contractive in the beta=2 weighted geometry.  The remaining hard arithmetic
piece is the early G7 head.

v403 puts the G7 Riesz head, its E-jets, the X->Y transfer, and the v71/v78
collision normalization into one exact Mellin-Barnes framework.

No numerical zeta values are evaluated.  SymPy is used only for formal
identities.

Normalized Dirichlet transform
------------------------------
For a coefficient sequence u_n define

    a_n = sqrt(n) log(n) u_n,
    A(s) = sum_(n>=2) a_n n^(-s).

Define its Dirichlet primitive

    P[A](s)
      = int_s^infty A(w) dw
      = sum_(n>=2) a_n n^(-s)/log n,

on a half-plane of absolute convergence.

Since

    u_n e^(iE log n)
      = a_n n^(-1/2+iE)/log n,

the compact Riesz/log-Cesaro functional

    Z_X^u(E)
      = sum_(n<=X)
          u_n e^(iE log n)
          (1-log n/log X)

has the exact Perron/Mellin-Barnes representation

    Z_X^u(E)
      = 1/(2 pi i log X)
        int_(c-iinf)^(c+iinf)
          X^z/z^2
          P[A](1/2-iE+z) dz,

with c chosen so Re(1/2+z)>1.

The scalar kernel identity behind this is

    1/(2 pi i)
      int y^z/z^2 dz
      = log y,  y>1,

so dividing by log X gives precisely

    log(X/n)/log X
      = 1-log n/log X.

E-jets
------
Let s_E(z)=1/2-iE+z.  Then

    partial_E^r P[A](s_E)
      = (-i)^r partial_s^r P[A](s_E).

Thus the first four hard Riesz jets use one and the same analytic head
function P[A].

Cutoff transfer
---------------
For X<=Y,

    Z_Y^u(E)-Z_X^u(E)
      = 1/(2 pi i)
        int
          [Y^z/logY - X^z/logX]/z^2
          P[A](s_E(z)) dz.

So the v392 transfer theorem becomes a contour estimate on ONE frozen head
transform.

G7 insertion
------------
v383 proves exactly, on Re(s)>1,

    G7hat
      = (I+R+...+R^6) S Fhat,

with the Volterra formulas for S and R, and

    Xhat-G7hat = R^7 Xhat.

Thus v403 does not re-expand 21 Selberg/layer channels.  The entire G7 head is
represented by the single primitive

    P[G7hat](s)=int_s^infty G7hat(w)dw.

Collision separation
--------------------
The first-order Riesz contour kernel used by v71 is

    H_L(a)=(exp(L a)-1)/(L a^2),

and after subtracting the simple-pole term 1/a,

    R_L(a)
      = H_L(a)-1/a
      = (exp(L a)-1-L a)/(L a^2).

Taylor expansion gives exactly

    R_L(0)=L/2.

Therefore the v78 leading stiffness

    F'_X(E_k)=L/2 + arithmetic defect

belongs to the universal collision kernel.  It should NOT be assigned to G7.

The analytic head theorem to prove is instead that, after collision
subtraction, the G7 contour contribution has

    root stiffness defect = O_k(1),
    tube oscillation       = O_k(1),

and the X->Y head transfer is

    O_k(1/log X),  X<=Y<=2X.

v402 handles the differentiated recursive regular tail.

Scientific status
-----------------
v403 is an exact algebraic/contour reduction.  It does NOT prove the required
contour bounds.

Scientific firewall
-------------------
NO Xi.
NO zeta numerical values.
NO known zero ordinates.
NO numerical zero fitting.
NO finite scan accepted as proof.

Version: 403
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

from tqdm import tqdm

VERSION = 403


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_kernel_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    L, a = sp.symbols(
        "L a",
        positive=True,
        real=True,
    )

    H = (sp.exp(L*a)-1)/(L*a**2)
    R = sp.simplify(H-1/a)
    expected_R = (
        sp.exp(L*a)-1-L*a
    )/(L*a**2)

    residual_R = sp.simplify(R-expected_R)
    collision_limit = sp.simplify(
        sp.limit(R, a, 0)
    )

    series = sp.series(
        R,
        a,
        0,
        4,
    )

    # Cutoff kernel:
    # K_X(z)=exp(Lz)/(L z^2).
    # d/dL K is a purely explicit expression.
    z = sp.symbols("z")
    K = sp.exp(L*z)/(L*z**2)
    dK = sp.simplify(sp.diff(K, L))
    dK_expected = sp.simplify(
        sp.exp(L*z)
        * (L*z-1)
        / (L**2*z**2)
    )
    residual_dK = sp.simplify(
        dK-dK_expected
    )

    return {
        "H_L": str(H),
        "R_L": str(R),
        "collision_residual": str(residual_R),
        "R_L_at_zero": str(collision_limit),
        "R_L_series": str(series),
        "cutoff_kernel": str(K),
        "cutoff_log_derivative": str(dK),
        "cutoff_log_derivative_residual": str(residual_dK),
        "pass": bool(
            residual_R == 0
            and collision_limit == L/2
            and residual_dK == 0
        ),
    }


def symbolic_E_jet_checks():
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    E, z = sp.symbols(
        "E z",
        real=True,
    )
    s = sp.Rational(1, 2) - sp.I*E + z
    P = sp.Function("P")

    rows = []
    passes = []

    expr = P(s)
    for r in range(4):
        lhs = sp.diff(expr, E, r)
        rhs = (
            (-sp.I)**r
            * sp.diff(P(s), s, r)
            if False
            else None
        )

        # SymPy cannot differentiate with respect to a non-symbolic expression
        # directly in that syntax.  Build the expected chain rule by using a
        # dummy symbol.
        q = sp.symbols("q")
        Pq = P(q)
        expected = (
            (-sp.I)**r
            * sp.diff(Pq, q, r)
        ).subs(q, s)

        residual = sp.simplify(lhs-expected)

        rows.append({
            "order": r,
            "lhs": str(lhs),
            "expected": str(expected),
            "residual": str(residual),
        })
        passes.append(residual == 0)

    return {
        "s_E": str(s),
        "rows": rows,
        "pass": bool(all(passes)),
    }


def symbolic_riesz_weight_check():
    """
    Algebraic coefficient extraction once the standard Perron identity
    I(y)=log(y) 1_(y>1) is supplied.

    We do not ask SymPy to evaluate the Bromwich contour itself.
    """
    try:
        import sympy as sp
    except Exception as exc:
        return {
            "pass": False,
            "error": str(exc),
        }

    LX, ln = sp.symbols(
        "LX ln",
        positive=True,
        real=True,
    )

    derived = sp.simplify(
        (LX-ln)/LX
    )
    expected = 1-ln/LX
    residual = sp.simplify(
        derived-expected
    )

    return {
        "perron_input": (
            "(1/2pii) int (X/n)^z z^-2 dz = log(X/n) for n<X"
        ),
        "derived_weight": str(derived),
        "expected_weight": str(expected),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v383-summary",
        default="rot_rh_G7_mellin_volterra_head_v383_SUMMARY.json",
    )
    ap.add_argument(
        "--v402-summary",
        default="rot_rh_weighted_factorial_four_jet_v402_SUMMARY.json",
    )
    ap.add_argument(
        "--v392-summary",
        default="rot_rh_summable_dyadic_cutoff_closure_v392_SUMMARY.json",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_G7_riesz_mellin_collision_v403",
    )

    args = ap.parse_args()

    print("=" * 224)
    print("ROT-RH v403 — G7 RIESZ–MELLIN–BARNES / COLLISION-SEPARATION REDUCTION")
    print("=" * 224)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("finite scanning accepted as proof       : NO")
    print("=" * 224)

    v383 = load_json(args.v383_summary)
    v402 = load_json(args.v402_summary)
    v392 = load_json(args.v392_summary)

    print("[1] Upstream theorem packets")

    v383_ok = bool(
        v383 is not None
        and str(v383.get("verdict", ""))
        == "EXACT_MELLIN_VOLTERRA_G7_REDUCTION_PASS"
    )
    v402_ok = bool(
        v402 is not None
        and str(v402.get("verdict", ""))
        == "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
    )
    v392_ok = bool(
        v392 is not None
        and str(v392.get("verdict", ""))
        == "SUMMABLE_DYADIC_CUTOFF_INDEPENDENCE_IMPLICATION_PASS"
    )

    print(
        "v383 exact G7 Mellin-Volterra reduction   :",
        v383_ok,
    )
    if v383 is not None:
        print(
            "v383 verdict                             :",
            v383.get("verdict"),
        )

    print(
        "v402 weighted factorial R7 theorem        :",
        v402_ok,
    )
    if v402 is not None:
        print(
            "v402 verdict                             :",
            v402.get("verdict"),
        )

    print(
        "v392 summable cutoff implication          :",
        v392_ok,
    )

    print("\n[2] Exact symbolic identities")

    with tqdm(
        total=3,
        desc="G7/Riesz theorem identities",
        unit="identity",
    ) as bar:
        riesz = symbolic_riesz_weight_check()
        bar.update(1)

        jets = symbolic_E_jet_checks()
        bar.update(1)

        collision = symbolic_kernel_checks()
        bar.update(1)

    print("Riesz coefficient identity pass          :", riesz.get("pass"))
    print("E-jet chain-rule identities pass         :", jets.get("pass"))
    print("collision kernel identities pass         :", collision.get("pass"))
    print(
        "collision-safe R_L(0)                    :",
        collision.get("R_L_at_zero"),
    )
    print(
        "R_L Taylor series                        :",
        collision.get("R_L_series"),
    )

    algebra_pass = bool(
        riesz.get("pass")
        and jets.get("pass")
        and collision.get("pass")
    )

    print("\n[3] Exact G7 Riesz-Mellin representation")

    statements = [
        (
            "DIRICHLET_PRIMITIVE",
            "P[A](s)=int_s^infty A(w)dw=sum a_n n^(-s)/log n.",
        ),
        (
            "RIESZ_HEAD",
            "Z_X^G7(E)=(2pii logX)^(-1) int X^z z^(-2) P[G7hat](1/2-iE+z) dz.",
        ),
        (
            "E_JETS",
            "partial_E^r acts as (-i)^r partial_s^r on the same primitive P[G7hat].",
        ),
        (
            "CUTOFF_TRANSFER",
            "Z_Y-Z_X uses only the explicit kernel [Y^z/logY-X^z/logX]/z^2.",
        ),
        (
            "G7_VOLterra",
            "v383: G7hat=(I+R+...+R^6) S Fhat exactly on Re(s)>1.",
        ),
        (
            "R7_TAIL",
            "v402: the differentiated recursive regular tail is globally contractive in beta=2 factorial four-jet geometry.",
        ),
    ]

    for key, value in statements:
        print(f"{key:42s}: {value}")

    print("\n[4] Collision/stiffness separation")

    separation = [
        (
            "UNIVERSAL_COLLISION",
            "R_L(a)=[exp(La)-1-La]/(La^2), with R_L(0)=L/2.",
        ),
        (
            "V78_TARGET",
            "F'_X(E_k)=L/2 + O_k(1); the L/2 term is universal collision normalization.",
        ),
        (
            "G7_ROLE",
            "G7 must supply only the bounded arithmetic defect/tube oscillation, not the L/2 leading term.",
        ),
        (
            "TRANSFER_ROLE",
            "The G7 contour difference must be O_k(1/L) uniformly for X<=Y<=2X.",
        ),
    ]

    for key, value in separation:
        print(f"{key:42s}: {value}")

    print("\n[5] Remaining analytic contour theorem")

    obligations = [
        (
            "HEAD_STIFFNESS_DEFECT",
            "After collision subtraction, prove the first E-jet of the G7 Riesz contour is O_k(1) at the root branch.",
        ),
        (
            "HEAD_TUBE_OSCILLATION",
            "Prove the second/third G7 contour jets give O_k(1) slope oscillation on |u|=O(1/logX).",
        ),
        (
            "HEAD_CUTOFF_TRANSFER",
            "Prove the explicit X-to-Y kernel difference applied to P[G7hat] is O_k(1/logX), uniformly X<=Y<=2X.",
        ),
        (
            "CONTOUR_DEFORMATION",
            "Carry the Mellin-Barnes line from Re(1/2+z)>1 to the collision-safe contour while accounting for residues exactly.",
        ),
        (
            "NO_G7_L_OVER_2",
            "Do not force the G7 head to generate L/2; that term belongs to the universal collision kernel.",
        ),
    ]

    for key, value in obligations:
        print(f"{key:42s}: {value}")

    implication = [
        "G7_HEAD_CONTOUR_BOUNDS",
        "+ V402_GLOBAL_REGULAR_R7_FOUR_JET",
        "+ V77_CANONICAL_PHASE_NORMALIZATION",
        "+ V78_COLLISION_NORMALIZATION",
        "+ V76_CONTOUR_TRANSFER_GEOMETRY",
        "=> V392_ALL_X_SUMMABLE_ROOT_DISPLACEMENT",
        "=> FIXED_MODE_CUTOFF_INDEPENDENCE",
    ]

    print("\n[6] Closure chain")
    for x in implication:
        print(" ", x)

    theorem_pass = bool(
        v383_ok
        and v402_ok
        and v392_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_G7_RIESZ_MELLIN_COLLISION_REDUCTION_PASS"
        if theorem_pass
        else
        "G7_RIESZ_MELLIN_COLLISION_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_COLLISION_SUBTRACTED_G7_MELLIN_CONTOUR_O1_AND_TRANSFER_O1_OVER_LOGX"
    )

    print("\n" + "=" * 224)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "GLOBAL CUTOFF INDEPENDENCE               :",
        "NOT YET PROVED; ONLY THE G7 COLLISION-SUBTRACTED CONTOUR BOUNDS REMAIN ON THE HEAD SIDE",
    )
    print("=" * 224)

    prefix = Path(args.prefix)
    summary_path = Path(
        str(prefix) + "_SUMMARY.json"
    )
    theorem_path = Path(
        str(prefix) + "_THEOREM.md"
    )
    cert_path = Path(
        str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json"
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v383_ok": v383_ok,
            "v402_ok": v402_ok,
            "v392_ok": v392_ok,
        },
        "exact_identities": {
            "riesz_weight": riesz,
            "E_jets": jets,
            "collision_kernel": collision,
        },
        "G7_riesz_mellin": {
            key: value
            for key, value in statements
        },
        "collision_separation": {
            key: value
            for key, value in separation
        },
        "remaining_obligations": {
            key: value
            for key, value in obligations
        },
        "closure_chain": implication,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact Mellin-Barnes/Riesz/collision reduction. The recursive regular "
            "R7 four-jet is already closed by v402. The remaining head theorem is "
            "a collision-subtracted contour estimate on the single primitive "
            "P[G7hat]."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v403 — G7 Riesz–Mellin collision reduction

For normalized coefficients

`a_n=sqrt(n)log(n)u_n`

let

`A(s)=sum a_n n^(-s)`

and

`P[A](s)=int_s^infty A(w)dw`.

Then the compact Riesz functional is exactly

`Z_X^u(E)
 = 1/(2 pi i logX)
   int X^z/z^2 P[A](1/2-iE+z) dz`.

For the G7 head, insert the exact v383 transform

`G7hat=(I+R+...+R^6) S Fhat`.

All first four E-jets are derivatives of the same primitive.

For X<=Y,

`Z_Y-Z_X
 = 1/(2 pi i)
   int [Y^z/logY-X^z/logX]/z^2
       P[G7hat](1/2-iE+z) dz`.

The collision-safe Riesz kernel is

`R_L(a)=[exp(La)-1-La]/(La^2)`

and

`R_L(0)=L/2`.

Therefore the v78 leading stiffness `L/2` is universal collision
normalization. The G7 arithmetic head only needs bounded collision-subtracted
defect and tube oscillation.

With v402 controlling the recursive differentiated tail, the remaining
head theorem is:

1. collision-subtracted G7 first jet = `O_k(1)`;
2. tube derivative variation = `O_k(1)`;
3. X-to-Y G7 Riesz transfer = `O_k(1/logX)`;
4. residue accounting is uniform on the collision-safe contour.

Those bounds, together with v76-v78 and v392, imply fixed-mode cutoff
independence.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_G7_COLLISION_SUBTRACTED_CONTOUR_CERTIFICATE_V1",
        "required_claims": {
            "G7_first_jet_defect": "UNIFORM_O_K_1",
            "G7_tube_oscillation": "UNIFORM_O_K_1",
            "G7_X_to_Y_transfer": "UNIFORM_C_K_OVER_LOGX",
            "collision_residue": "EXACT_L_OVER_2_PLUS_BOUNDED_REMAINDER",
            "contour_residue_control": "UNIFORM_COLLISION_SAFE",
        },
        "already_closed": {
            "recursive_regular_four_jet": "v402",
            "summability_implication": "v392",
        },
        "forbidden_as_proof": [
            "finite cutoff regression",
            "assigning L/2 collision growth to G7",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
