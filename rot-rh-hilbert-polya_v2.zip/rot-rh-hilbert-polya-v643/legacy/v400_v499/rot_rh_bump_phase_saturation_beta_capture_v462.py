#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v462 — BUMP PHASE-SATURATION / EXACT BETA CAPTURE THEOREM
================================================================

PURPOSE
-------
Sharpen v461's bump-collision bridge.

v461 used a sufficient collision window |u|<=pi/2 to obtain separately

    C_q,coll = O(L),
    F_E,coll ~ L,

where

    u = (gamma-E)L.

That is stronger than necessary.

For the bump

    p(x)=exp(-(x/(1-x))^2),  0<=x<1,
    q(x)=-p'(x),

define

    P_c(u)=int_0^1 p(x) cos(ux) dx,
    Q_s(u)=int_0^1 q(x) sin(ux) dx,

and the collision phase profile

    S_p(u)=int_0^1 p(x) sin(ux)/x dx.

The key exact identities are

    S_p'(u)=P_c(u),
    Q_s(u)=u P_c(u).

Therefore the bump collision beta function is EXACTLY

    B_coll = Q_s/P_c = u

with removable continuation through common zeros of numerator and denominator.

More importantly, because

    p(x)=int_x^1 q(t)dt,

Fubini gives

    S_p(u)=int_0^1 q(t) Si(ut)dt.

Now q is a probability density:

    int_0^1 q(t)dt=1,

and exactly

    int_0^1 q(t)/t dt = 1+sqrt(pi).

Using

    |Si(z)-pi/2| <= 2/z,  z>0,

we obtain for u>0

    |S_p(u)-pi/2|
      <= 2(1+sqrt(pi))/u.

By oddness, for u<0

    |S_p(u)+pi/2|
      <= 2(1+sqrt(pi))/|u|.

Hence, if a persistent recombined collision branch obeys the exact phase equation

    sigma*m*S_p(u(L)) + R_k(L) = C_k,

with sigma in {+1,-1}, m>=1, and the NON-SATURATION condition

    dist( C_k-R_k(L),
          {+sigma*m*pi/2, -sigma*m*pi/2} )
      >= m*delta

for some delta>0 and all sufficiently large L, then

    |u(L)| <= U_delta
           := 2(1+sqrt(pi))/delta.

Consequently

    |E_k(L)-gamma|
      <= U_delta/L,

so E_k(L)->gamma directly.

This proof does NOT require:
  * a separate O(L) bound on C_q;
  * a separate lower bound F_E >= cL;
  * differentiability of the root branch;
  * a no-fold theorem for the implicit quotient;
  * a first-lobe assumption;
  * a simple-zero assumption.

Only persistence of the chosen phase branch and a positive non-saturation
margin are needed in this isolated recombined collision chamber.

WHY THE HALF-INTEGER QUANTIZATION MATTERS
-----------------------------------------
For the bump-2 secular law

    F_L(E)=theta(E)/pi+1-P_L^FP(E)/pi,

the root label is k-1/2.  A multiplicity-m collision contributes a smoothed
phase jump whose normalized saturation values are +/-m/2.  Therefore the
natural next theorem is NOT a source-growth theorem.  It is a phase-index
separation theorem showing that the fixed half-integer branch remains in the
interior of its collision jump after all other recombined channels are included.

That theorem would supply delta>0 above and immediately give O(1/L) capture.

MULTIPLICITY SAFETY
-------------------
The local collision term must be extracted from the RECOMBINED meromorphic
fixed point.  Do not analytically continue G7 and R^7X separately.  The
multiplicity m cancels from the beta ratio and only scales the phase jump.

SCIENTIFIC BOUNDARY
-------------------
v462 closes the elementary bump collision phase/beta/capture algebra.
It does NOT prove the required all-L non-saturation margin for the complete
ROT-RH characteristic, nor RH, nor the exact Fredholm identity.

No Xi values, numerical zeta values, zeta derivatives, or known zero ordinates
are used.

Version: 2026-08-28-v462-bump-phase-saturation-beta-capture
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v462-bump-phase-saturation-beta-capture"


def p_bump(x: float) -> float:
    x = float(x)
    if x < 0.0:
        return math.nan
    if x >= 1.0:
        return 0.0
    r = x/(1.0-x)
    z = -(r*r)
    if z < -745.0:
        return 0.0
    return math.exp(z)


def q_bump(x: float) -> float:
    x = float(x)
    if x < 0.0:
        return math.nan
    if x <= 0.0 or x >= 1.0:
        return 0.0
    return 2.0*x*p_bump(x)/(1.0-x)**3


def analytic_constants(delta: float) -> Dict[str, Any]:
    if delta <= 0.0:
        raise ValueError("delta must be positive")
    Csat = 2.0*(1.0+math.sqrt(math.pi))
    return {
        "q_mass_exact": "1",
        "q_over_x_mass_exact": "1+sqrt(pi)",
        "saturation_remainder_constant_exact": "2*(1+sqrt(pi))",
        "saturation_remainder_constant_decimal": Csat,
        "delta": delta,
        "capture_U_delta": Csat/delta,
        "capture_statement": (
            "|u| <= 2*(1+sqrt(pi))/delta under the non-saturation margin"
        ),
    }


def symbolic_checks() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available": False, "pass": False, "error": str(exc)}

    x, u = sp.symbols("x u", positive=True)
    p = sp.exp(-(x/(1-x))**2)
    q = 2*x/(1-x)**3*p
    q_resid = sp.simplify(-sp.diff(p, x)-q)

    # Exact q/x moment after r=x/(1-x).
    r = sp.symbols("r", positive=True)
    transformed = sp.simplify(
        (2*x/(1-x)**3*p / x).subs(x, r/(1+r)) / (1+r)**2
    )
    expected = 2*(1+r)*sp.exp(-r**2)
    transform_resid = sp.simplify(transformed-expected)

    q_over_x_exact = sp.integrate(expected, (r, 0, sp.oo))
    moment_resid = sp.simplify(q_over_x_exact-(1+sp.sqrt(sp.pi)))

    return {
        "available": True,
        "minus_pprime_equals_q_residual": str(q_resid),
        "q_over_x_change_of_variable_residual": str(transform_resid),
        "q_over_x_integral": str(q_over_x_exact),
        "q_over_x_integral_residual": str(moment_resid),
        "pass": bool(q_resid == 0 and transform_resid == 0 and moment_resid == 0),
    }


def numerical_diagnostics() -> Dict[str, Any]:
    try:
        from scipy.integrate import quad
        from scipy.special import sici
    except Exception as exc:
        return {"available": False, "error": str(exc)}

    def Pc(u: float) -> float:
        return quad(
            lambda x: p_bump(x)*math.cos(u*x),
            0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
        )[0]

    def Qs(u: float) -> float:
        return quad(
            lambda x: q_bump(x)*math.sin(u*x),
            0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
        )[0]

    def Sp(u: float) -> float:
        if u == 0.0:
            return 0.0
        return quad(
            lambda x: p_bump(x)*math.sin(u*x)/x if x > 0.0 else u,
            0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
        )[0]

    qmass = quad(
        lambda x: q_bump(x),
        0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
    )[0]
    qxmass = quad(
        lambda x: q_bump(x)/x if x > 0.0 else 2.0,
        0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
    )[0]

    us = [0.1, 0.5, 1.0, 2.0, 4.0, 7.0, 10.0, 20.0, 50.0, 100.0]
    rows = []
    max_beta_identity = 0.0
    max_phase_mixture_identity = 0.0

    for u in tqdm(us, desc="v462 bump identities", unit="u", leave=False):
        pc = Pc(u)
        qs = Qs(u)
        spv = Sp(u)
        beta_gap = abs(qs-u*pc)
        max_beta_identity = max(max_beta_identity, beta_gap)

        # Fubini/Si mixture:
        mix = quad(
            lambda t: q_bump(t)*float(sici(u*t)[0]),
            0.0, 1.0, epsabs=2e-13, epsrel=2e-13, limit=300
        )[0]
        mix_gap = abs(spv-mix)
        max_phase_mixture_identity = max(max_phase_mixture_identity, mix_gap)

        sat_err = abs(spv-math.pi/2.0)
        sat_upper = 2.0*(1.0+math.sqrt(math.pi))/u

        rows.append({
            "u": u,
            "Pc": pc,
            "Qs": qs,
            "Qs_minus_uPc": qs-u*pc,
            "Sp": spv,
            "Sp_minus_Si_mixture": spv-mix,
            "abs_Sp_minus_pi_over_2": sat_err,
            "saturation_upper": sat_upper,
            "saturation_bound_pass": sat_err <= sat_upper + 1e-11,
        })

    return {
        "available": True,
        "q_mass_numeric": qmass,
        "q_mass_error": abs(qmass-1.0),
        "q_over_x_mass_numeric": qxmass,
        "q_over_x_mass_error": abs(qxmass-(1.0+math.sqrt(math.pi))),
        "maximum_abs_Qs_minus_uPc": max_beta_identity,
        "maximum_abs_Sp_minus_qSi_mixture": max_phase_mixture_identity,
        "all_saturation_bounds_pass": all(r["saturation_bound_pass"] for r in rows),
        "rows": rows,
    }


def capture_bound(delta: float, L: float) -> Dict[str, Any]:
    Csat = 2.0*(1.0+math.sqrt(math.pi))
    U = Csat/delta
    return {
        "delta": delta,
        "L": L,
        "U_delta": U,
        "energy_capture_bound": U/L,
        "formula": "|E(L)-gamma| <= 2(1+sqrt(pi))/(delta L)",
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    Csat = payload["constants"]["saturation_remainder_constant_decimal"]

    theorem.write_text(
f"""# ROT-RH v462 — bump phase-saturation / exact beta capture theorem

## 1. Exact bump collision identities

Let

`p(x)=exp(-(x/(1-x))^2)`, `q(x)=-p'(x)`,

and define

`P_c(u)=int_0^1 p(x)cos(ux)dx`,

`Q_s(u)=int_0^1 q(x)sin(ux)dx`,

`S_p(u)=int_0^1 p(x)sin(ux)/x dx`.

Then

`S_p'(u)=P_c(u)`.

Integration by parts gives exactly

`Q_s(u)=u P_c(u)`.

Therefore the recombined bump collision beta function is

`B_coll=Q_s/P_c=u`

with removable continuation across common zeros.

Multiplicity cancels from this ratio.

## 2. Collision phase as a q-weighted sine integral

Because

`p(x)=int_x^1 q(t)dt`,

Fubini gives

`S_p(u)=int_0^1 q(t) Si(ut) dt`.

Also

`int_0^1 q(t)dt=1`

and, with `r=t/(1-t)`,

`int_0^1 q(t)/t dt = 1+sqrt(pi)`.

Using the elementary Dirichlet remainder

`|Si(z)-pi/2| <= 2/z`, `z>0`,

we obtain

`|S_p(u)-pi/2| <= 2(1+sqrt(pi))/u`, `u>0`.

By oddness,

`|S_p(u)+pi/2| <= 2(1+sqrt(pi))/|u|`, `u<0`.

The exact saturation constant used here is

`C_sat=2(1+sqrt(pi)) ~= {Csat:.16e}`.

## 3. Non-saturation capture theorem

Suppose a persistent recombined multiplicity-`m` collision branch satisfies

`sigma*m*S_p(u(L)) + R_k(L) = C_k`,

where

`u(L)=(gamma-E_k(L))L`

and `sigma=+/-1`.

Assume that for some `delta>0`, eventually

`dist(C_k-R_k(L), {{+sigma*m*pi/2,-sigma*m*pi/2}}) >= m delta`.

Then the saturation estimate forces

`|u(L)| <= 2(1+sqrt(pi))/delta`.

Therefore

`|E_k(L)-gamma| <= 2(1+sqrt(pi))/(delta L)`,

and hence

`E_k(L) -> gamma`.

This proves cutoff independence in this isolated recombined collision chamber
without differentiating the root equation.

## 4. Why this is stronger than v461

v461 asked for separate all-`L` estimates on the regular numerator and
transversality denominator.  v462 shows that, in an isolated collision chamber,
those are unnecessary for convergence.

The only new phase theorem required is a **non-saturation margin** for the
complete recombined remainder.

In the bump-2 secular normalization the root label is half-integer while a
multiplicity-`m` collision has normalized saturation plateaus `+/-m/2`.
This makes the next analytic target naturally an **index / phase-jump interior
theorem**, not another source-growth envelope.

## 5. Multiplicity safety

The collision must be extracted from the recombined fixed point.  Singular
`G7` and `R^7X` cannot be analytically continued separately for multiplicity
`m>1`.

## 6. Remaining theorem

Prove, for each eventual fixed ordered branch, one of:

1. **isolated collision chamber:** the recombined residual phase has a uniform
   positive distance from the two saturation labels;

2. **attained finite cluster:** reduce the other collisions to their saturated
   integer/half-integer jumps and retain one interior collision;

3. **nonattained infinite cluster:** use the v411/v419 signed collective
   phase/primitive-beta theorem.

v462 proves the exact local bump algebra only.  It does not prove RH or the
Fredholm-Xi identity.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_BUMP_PHASE_SATURATION_CAPTURE_CERTIFICATE_V1",
        "already_closed": {
            "Q_s_identity": "Q_s(u)=u P_c(u)",
            "collision_beta": "B_coll=u with removable continuation",
            "phase_profile": "S_p(u)=int q(t) Si(ut)dt",
            "q_mass": "int q=1",
            "q_over_x_mass": "int q(t)/t dt=1+sqrt(pi)",
            "saturation_bound":
                "|S_p(u)-sgn(u)pi/2|<=2(1+sqrt(pi))/|u|",
            "capture_implication":
                "non-saturation margin delta => |u|<=2(1+sqrt(pi))/delta",
            "energy_tail":
                "|E(L)-gamma|<=2(1+sqrt(pi))/(delta L)",
        },
        "required_claims": {
            "recombined_collision_decomposition":
                "sigma*m*S_p((gamma-E)L)+R_k(L)=C_k on the eventual branch",
            "non_saturation_margin":
                "dist(C_k-R_k(L),{+sigma*m*pi/2,-sigma*m*pi/2})>=m*delta",
            "branch_persistence":
                "the selected fixed phase branch exists for all sufficiently large L",
        },
        "next_attack": (
            "Exploit the half-integer action label k-1/2 and the +/-m/2 "
            "collision plateaus to prove the non-saturation margin as an "
            "index/phase-jump theorem for the recombined bump characteristic."
        ),
        "forbidden_as_proof": [
            "separate singular G7/R7 analytic continuation",
            "simple-zero assumption",
            "finite cutoff extrapolation",
            "known zero ordinates",
            "treating no-fold as necessary for the direct phase-capture implication",
        ],
    }
    cert.write_text(json.dumps(certificate, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--delta", type=float, default=0.25)
    ap.add_argument("--L", type=float, default=20.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_bump_phase_saturation_beta_capture_v462",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.delta <= 0:
        raise ValueError("--delta must be positive")
    if args.L <= 0:
        raise ValueError("--L must be positive")

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*180)
    print("ROT-RH v462 — BUMP PHASE-SATURATION / EXACT BETA CAPTURE THEOREM")
    print("="*180)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("simple-zero assumption                     : NONE")
    print("root differentiability needed for capture  : NO")
    print("="*180)

    with tqdm(total=4, desc="v462 analytic theorem", unit="step") as bar:
        const = analytic_constants(float(args.delta))
        bar.update(1)
        sym = symbolic_checks()
        bar.update(1)
        diag = numerical_diagnostics()
        bar.update(1)
        bound = capture_bound(float(args.delta), float(args.L))
        bar.update(1)

    passed = bool(sym.get("pass", False))
    if diag.get("available"):
        passed = passed and (
            diag["q_mass_error"] <= 1e-10
            and diag["q_over_x_mass_error"] <= 1e-10
            and diag["maximum_abs_Qs_minus_uPc"] <= 1e-10
            and diag["maximum_abs_Sp_minus_qSi_mixture"] <= 1e-10
            and diag["all_saturation_bounds_pass"]
        )

    verdict = (
        "EXACT_BUMP_PHASE_SATURATION_BETA_CAPTURE_THEOREM_PASS"
        if passed else
        "BUMP_PHASE_SATURATION_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "constants": const,
        "symbolic_checks": sym,
        "numerical_diagnostics": diag,
        "illustrative_capture_bound": bound,
        "proof_status": (
            "Exact bump collision beta identity and explicit phase-saturation "
            "capture theorem.  The complete recombined non-saturation margin "
            "remains the next all-L theorem."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*180)
    print("verdict                                :", verdict)
    print("int q                                  : 1")
    print("int q/x                                : 1+sqrt(pi)")
    print("C_sat=2(1+sqrt(pi))                    :", f"{const['saturation_remainder_constant_decimal']:.16e}")
    print("delta                                  :", args.delta)
    print("capture |u| upper                      :", f"{const['capture_U_delta']:.16e}")
    print("illustrative |E-gamma| upper at L      :", f"{bound['energy_capture_bound']:.16e}")
    if diag.get("available"):
        print("max |Q_s-uP_c|                         :", f"{diag['maximum_abs_Qs_minus_uPc']:.3e}")
        print("max |S_p-q*Si mixture|                 :", f"{diag['maximum_abs_Sp_minus_qSi_mixture']:.3e}")
        print("all saturation diagnostics pass        :", diag["all_saturation_bounds_pass"])
    print("summary                                :", str(prefix)+"_SUMMARY.json")
    print("theorem                                :", str(prefix)+"_THEOREM.md")
    print("next certificate                       :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*180)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
