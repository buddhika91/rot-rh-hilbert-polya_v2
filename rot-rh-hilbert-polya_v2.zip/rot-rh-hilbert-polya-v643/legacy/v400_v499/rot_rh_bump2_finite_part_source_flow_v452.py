#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v452 — BUMP-2 FINITE-PART SOURCE-FLOW / INTEGRABILITY AUDIT
==================================================================

PURPOSE
-------
Attack the analytic mechanism suggested by v449-v451 rather than merely extend
finite-cutoff heat fits.

The frozen bump-2 window is

    phi_L(y) = exp(-(y/(L-y))^2),  y<L;  0 otherwise,
    L = log X.

On s=1/2-iE define

    P_L(E) = sum_n Lambda(n)/(log n sqrt(n)) phi_L(log n) sin(E log n),

and its smooth PNT carrier

    M_L(E) = int_{log 2}^L exp(y/2) phi_L(y) sin(Ey)/y dy.

The canonical finite-part phase is

    P_L^FP(E) = P_L(E) - M_L(E) + M_inf^AC(E),
    M_inf^AC(E) = Im E1((-1/2-iE) log 2).

The secular law is

    F_L(E) = theta(E)/pi + 1 - P_L^FP(E)/pi,
    F_L(E_k(L)) = k - 1/2.

Because phi_L is C-infinity flat at y=L, no boundary delta term occurs and

    d_L phi_L(y) = 2 y^2/(L-y)^3 phi_L(y).

Hence

    partial_L F_L = -(partial_L P_L - partial_L M_L)/pi,

and at a simple branch

    dE_k/dL = - partial_L F_L / partial_E F_L.

This audit measures exactly the theorem ingredients:
  1. prime source flow partial_L P_L,
  2. PNT-carrier flow partial_L M_L,
  3. finite-part residual partial_L F_L,
  4. transversality partial_E F_L,
  5. implicit root flow dE/dL,
  6. dyadic root increments versus integrated implicit flow,
  7. training-only decay fits and a prospective largest-cutoff holdout,
  8. PNT quadrature refinement at the holdout cutoff.

No known Riemann zero ordinates, zeta(), Xi(), or xi() are used.

A PASS is finite prospective evidence for the exact source-flow lemma needed by
the cutoff-independence theorem. It is NOT a proof of all-L integrability and is
NOT an RH proof.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from scipy.optimize import brentq
from scipy.special import digamma, exp1, loggamma, roots_legendre
from tqdm import tqdm

VERSION = "2026-08-26-v452-bump2-finite-part-source-flow"


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_rel(a: float, b: float, floor: float = 1e-30) -> float:
    return abs(a-b) / max(abs(a), abs(b), floor)


def rms(x: Sequence[float]) -> float:
    a = np.asarray(x, float)
    return float(np.sqrt(np.mean(a*a))) if a.size else float("nan")


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


# =============================================================================
# Archimedean phase and prime-power table
# =============================================================================

def theta(E: float) -> float:
    z = 0.25 + 0.5j*float(E)
    return float(np.imag(loggamma(z)) - 0.5*float(E)*math.log(math.pi))


def smooth_count(E: float) -> float:
    return theta(E)/math.pi + 1.0


def smooth_count_prime(E: float) -> float:
    z = 0.25 + 0.5j*float(E)
    thp = 0.5*float(np.real(digamma(z))) - 0.5*math.log(math.pi)
    return thp/math.pi


def free_archimedean_levels(depth: int) -> np.ndarray:
    out: List[float] = []
    lo = 7.0
    for k in tqdm(range(1, depth+2), desc="free Gamma levels", unit="level"):
        target = k - 0.5
        hi = max(20.0, 8.0*k + 20.0)
        while smooth_count(hi) < target:
            hi *= 1.5
        r = brentq(lambda x: smooth_count(x)-target, lo, hi,
                   xtol=1e-13, rtol=1e-13, maxiter=500)
        out.append(float(r))
    return np.asarray(out, float)


def sieve_primes(limit: int) -> np.ndarray:
    s = np.ones(limit+1, dtype=np.bool_)
    s[:2] = False
    for p in range(2, int(math.isqrt(limit))+1):
        if s[p]:
            s[p*p:limit+1:p] = False
    return np.flatnonzero(s).astype(np.int64)


def mangoldt_terms(limit: int) -> Tuple[np.ndarray, np.ndarray]:
    nums: List[int] = []
    vals: List[float] = []
    for pr in tqdm(sieve_primes(limit), desc="Mangoldt prime powers", unit="prime"):
        p = int(pr); lp = math.log(float(p)); q = p
        while q <= limit:
            nums.append(q); vals.append(lp)
            if q > limit//p:
                break
            q *= p
    order = np.argsort(nums)
    return np.asarray(nums, np.int64)[order], np.asarray(vals, float)[order]


# =============================================================================
# Frozen bump-2 window
# =============================================================================

def bump2_and_dL(y: np.ndarray, L: float) -> Tuple[np.ndarray, np.ndarray]:
    """Return phi_L(y) and partial_L phi_L(y), safely near the flat endpoint."""
    yy = np.asarray(y, float)
    phi = np.zeros_like(yy)
    dphi = np.zeros_like(yy)
    mask = yy < L
    if not np.any(mask):
        return phi, dphi
    a = yy[mask]
    gap = L-a
    r = a/gap
    expo = -(r*r)
    live = expo > -745.0
    pv = np.zeros_like(a)
    dv = np.zeros_like(a)
    if np.any(live):
        al = a[live]; gl = gap[live]
        p = np.exp(expo[live])
        pv[live] = p
        dv[live] = p * (2.0*al*al/(gl*gl*gl))
    phi[mask] = pv
    dphi[mask] = dv
    return phi, dphi


def pnt_ac_phase(E: float) -> float:
    z = (-0.5 - 1j*float(E))*math.log(2.0)
    return float(np.imag(exp1(z)))


def pnt_ac_phase_derivative(E: float) -> float:
    z = (-0.5 - 1j*float(E))*math.log(2.0)
    d = 1j*math.log(2.0)*np.exp(-z)/z
    return float(np.imag(d))


# =============================================================================
# Finite-part phase object
# =============================================================================

@dataclass
class SourceValues:
    prime_phase: float
    pnt_phase: float
    ac_phase: float
    finitepart_phase: float
    prime_E: float
    pnt_E: float
    ac_E: float
    finitepart_E: float
    prime_L: float
    pnt_L: float
    finitepart_L: float


class FinitePartBump2:
    def __init__(self, n: np.ndarray, lam: np.ndarray, X: float,
                 pnt_q: int = 3072, prime_chunk: int = 100000):
        self.X = float(X)
        self.L = math.log(self.X)
        self.n = np.asarray(n, np.int64)
        self.lam = np.asarray(lam, float)
        self.logs = np.log(self.n.astype(float))
        self.sqrt_n = np.sqrt(self.n.astype(float))
        self.prime_chunk = int(prime_chunk)

        phi, dphi = bump2_and_dL(self.logs, self.L)
        self.w_phase = self.lam/(self.logs*self.sqrt_n) * phi
        self.w_E = self.lam/self.sqrt_n * phi
        self.w_L = self.lam/(self.logs*self.sqrt_n) * dphi

        # Gauss-Legendre quadrature for the compact PNT carrier in y=log x.
        z, wg = roots_legendre(int(pnt_q))
        a = math.log(2.0); b = self.L
        self.y = 0.5*(b-a)*z + 0.5*(b+a)
        jac = 0.5*(b-a)
        phi_y, dphi_y = bump2_and_dL(self.y, self.L)
        ey = np.exp(0.5*self.y)
        self.pnt_phase_w = jac*wg * ey*phi_y/self.y
        self.pnt_E_w = jac*wg * ey*phi_y
        self.pnt_L_w = jac*wg * ey*dphi_y/self.y

    def _prime_trig(self, E: float, kind: str) -> float:
        total = 0.0
        if kind == "phase":
            w = self.w_phase; trig = np.sin
        elif kind == "E":
            w = self.w_E; trig = np.cos
        elif kind == "L":
            w = self.w_L; trig = np.sin
        else:
            raise ValueError(kind)
        for j in range(0, len(self.logs), self.prime_chunk):
            lg = self.logs[j:j+self.prime_chunk]
            ww = w[j:j+self.prime_chunk]
            total += float(np.dot(trig(float(E)*lg), ww))
        return total

    def phase_component(self, E: float) -> float:
        E=float(E)
        pp=self._prime_trig(E, "phase")
        mp=float(np.dot(np.sin(E*self.y), self.pnt_phase_w))
        return float(pp-mp+pnt_ac_phase(E))

    def E_component(self, E: float) -> float:
        E=float(E)
        pe=self._prime_trig(E, "E")
        me=float(np.dot(np.cos(E*self.y), self.pnt_E_w))
        return float(pe-me+pnt_ac_phase_derivative(E))

    def L_component(self, E: float) -> float:
        E=float(E)
        pl=self._prime_trig(E, "L")
        ml=float(np.dot(np.sin(E*self.y), self.pnt_L_w))
        return float(pl-ml)

    def sources(self, E: float) -> SourceValues:
        E = float(E)
        pp = self._prime_trig(E, "phase")
        pe = self._prime_trig(E, "E")
        pl = self._prime_trig(E, "L")
        st = np.sin(E*self.y); ct = np.cos(E*self.y)
        mp = float(np.dot(st, self.pnt_phase_w))
        me = float(np.dot(ct, self.pnt_E_w))
        ml = float(np.dot(st, self.pnt_L_w))
        ap = pnt_ac_phase(E)
        ae = pnt_ac_phase_derivative(E)
        return SourceValues(
            prime_phase=pp, pnt_phase=mp, ac_phase=ap,
            finitepart_phase=pp-mp+ap,
            prime_E=pe, pnt_E=me, ac_E=ae,
            finitepart_E=pe-me+ae,
            prime_L=pl, pnt_L=ml, finitepart_L=pl-ml,
        )

    def f(self, E: float, k: int) -> float:
        return float(smooth_count(E) - self.phase_component(E)/math.pi - (float(k)-0.5))

    def fp(self, E: float, k: int) -> float:
        return float(smooth_count_prime(E) - self.E_component(E)/math.pi)

    def fL(self, E: float, k: int) -> float:
        return float(-self.L_component(E)/math.pi)

    def flow(self, E: float, k: int) -> float:
        fe = self.fp(E, k)
        return float(-self.fL(E, k)/fe)


# =============================================================================
# Root continuation/certification
# =============================================================================

@dataclass
class RootResult:
    ok: bool
    root: float
    residual: float
    derivative: float
    reason: str


def locate_root(phase: FinitePartBump2, k: int, seed: float,
                local_scale: float, previous_root: float | None,
                root_tol: float, max_newton: int,
                scan_points: int) -> RootResult:
    x = float(seed)
    # Newton first, with conservative step limiting.
    for _ in range(int(max_newton)):
        fx = phase.f(x, k); d = phase.fp(x, k)
        if abs(fx) <= root_tol and (previous_root is None or x > previous_root + 1e-9):
            return RootResult(True, x, abs(fx), d, "newton")
        if not np.isfinite(d) or abs(d) < 1e-10:
            break
        step = -fx/d
        cap = max(0.25, 0.75*local_scale)
        step = float(np.clip(step, -cap, cap))
        xn = x + step
        if xn <= 6.5 or (previous_root is not None and xn <= previous_root + 1e-8):
            break
        x = xn

    # Adaptive expanded bracket scan.
    for mult in (1.0, 2.0, 4.0, 8.0):
        half = max(0.5, mult*local_scale)
        lo = max(7.0, float(seed)-half)
        if previous_root is not None:
            lo = max(lo, previous_root+1e-7)
        hi = float(seed)+half
        grid = np.linspace(lo, hi, int(scan_points))
        vals = np.asarray([phase.f(float(e), k) for e in grid], float)
        idx = np.flatnonzero(vals[:-1]*vals[1:] <= 0.0)
        if idx.size:
            centers = 0.5*(grid[idx]+grid[idx+1])
            j = int(idx[np.argmin(abs(centers-float(seed)))])
            try:
                r = brentq(lambda e: phase.f(float(e), k), float(grid[j]), float(grid[j+1]),
                           xtol=min(root_tol, 1e-12), rtol=1e-13, maxiter=500)
                rr = abs(phase.f(r, k)); d = phase.fp(r, k)
                if rr <= max(10*root_tol, 1e-9):
                    return RootResult(True, float(r), float(rr), float(d), f"brent_x{mult:g}")
            except Exception:
                pass
    return RootResult(False, float(seed), abs(phase.f(seed, k)), phase.fp(seed, k), "unresolved")


def quantize_continued(phase: FinitePartBump2, modes: Sequence[int], free: np.ndarray,
                       previous: Dict[int, float] | None,
                       root_tol: float, max_newton: int, scan_points: int) -> Dict[int, RootResult]:
    out: Dict[int, RootResult] = {}
    prev_ordered: float | None = None
    max_mode = max(modes)
    for k in tqdm(modes, desc=f"finite-part roots X={int(round(phase.X))}", unit="mode"):
        if previous and k in previous:
            seed = float(previous[k])
        else:
            seed = float(free[k-1])
        if k == 1:
            spacing = float(free[1]-free[0]) if len(free)>1 else 2.0
        elif k < len(free):
            spacing = 0.5*float(free[k]-free[k-2])
        else:
            spacing = float(free[-1]-free[-2])
        rr = locate_root(phase, int(k), seed, spacing, prev_ordered,
                         root_tol, max_newton, scan_points)
        out[int(k)] = rr
        if rr.ok:
            prev_ordered = rr.root
    return out


# =============================================================================
# Decay fits and prospective envelope
# =============================================================================

def fit_decay(X: np.ndarray, y: np.ndarray, family: str) -> dict:
    X = np.asarray(X, float); y = np.maximum(np.asarray(y, float), 1e-300)
    if family == "power_X":
        z = np.log(X); label = "C X^-p"
    elif family == "power_logX":
        z = np.log(np.log(X)); label = "C (log X)^-p"
    else:
        raise ValueError(family)
    A = np.column_stack([np.ones(len(z)), -z])
    coef, *_ = np.linalg.lstsq(A, np.log(y), rcond=None)
    logC, p = float(coef[0]), float(coef[1])
    pred = np.exp(A@coef)
    lr = np.log(y)-np.log(pred)
    return {
        "family": family, "label": label, "C": float(math.exp(logC)), "p": p,
        "log_rms": float(np.sqrt(np.mean(lr*lr))),
        "max_abs_log_residual": float(np.max(np.abs(lr))),
    }


def predict_fit(fit: dict, X: float) -> float:
    if fit["family"] == "power_X":
        return float(fit["C"]*float(X)**(-fit["p"]))
    return float(fit["C"]*math.log(float(X))**(-fit["p"]))


def choose_decay(X: Sequence[float], y: Sequence[float]) -> dict:
    fits = [fit_decay(np.asarray(X,float), np.asarray(y,float), f)
            for f in ("power_X","power_logX")]
    positive = [f for f in fits if f["p"] > 0]
    best = min(positive or fits, key=lambda f: f["log_rms"])
    best = dict(best); best["candidates"] = fits
    if best["family"] == "power_X":
        best["integrable_in_dlogX"] = bool(best["p"] > 0)
    else:
        best["integrable_in_dlogX"] = bool(best["p"] > 1)
    return best


def upper_envelope(pred: float, fit: dict, safety: float) -> float:
    return float(pred*math.exp(float(fit["max_abs_log_residual"]))*float(safety))


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--cutoffs", default="291600,583200,1166400,2332800,4665600,9331200")
    ap.add_argument("--modes", default="1,2,3,4,5,6,7,8,12,16,24,32")
    ap.add_argument("--pnt-q", type=int, default=3072)
    ap.add_argument("--pnt-qcheck", type=int, default=4608)
    ap.add_argument("--prime-chunk", type=int, default=100000)
    ap.add_argument("--root-tol", type=float, default=2e-9)
    ap.add_argument("--minimum-transversality", type=float, default=1e-3)
    ap.add_argument("--scan-points", type=int, default=97)
    ap.add_argument("--max-newton", type=int, default=14)
    ap.add_argument("--prediction-safety", type=float, default=2.0)
    ap.add_argument("--maximum-source-holdout-ratio", type=float, default=1.0)
    ap.add_argument("--maximum-flow-holdout-ratio", type=float, default=1.0)
    ap.add_argument("--maximum-pnt-refinement-relative", type=float, default=5e-6)
    ap.add_argument("--maximum-step-identity-relative", type=float, default=1.0,
                    help="Dyadic trapezoid-flow vs actual root increment; finite-difference diagnostic, not exact local identity.")
    ap.add_argument("--identity-h", type=float, default=2e-4)
    ap.add_argument("--identity-modes", default="1,8,16,32")
    ap.add_argument("--prefix", default="rot_rh_bump2_finite_part_source_flow_v452")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.time()
    cutoffs = parse_ints(args.cutoffs)
    modes = sorted(set(parse_ints(args.modes)))
    identity_modes = sorted(set(parse_ints(args.identity_modes)))
    if len(cutoffs) < 4 or cutoffs != sorted(cutoffs):
        raise ValueError("--cutoffs must contain >=4 increasing values")
    if max(modes) < 2:
        raise ValueError("need at least mode 2")
    if args.pnt_qcheck <= args.pnt_q:
        raise ValueError("--pnt-qcheck must exceed --pnt-q")

    train_X = cutoffs[:-1]; hold_X = cutoffs[-1]
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*168)
    print("ROT-RH v452 — BUMP-2 FINITE-PART SOURCE-FLOW / INTEGRABILITY AUDIT")
    print("="*168)
    print("known Riemann zero ordinates       : NEVER USED")
    print("zeta()/Xi()/xi() calls             : NONE")
    print("finite-part source                 : bump2 prime - bump2 PNT + E1 analytic continuation")
    print("training cutoffs                   :", train_X)
    print("HELD-OUT cutoff                    :", hold_X)
    print("modes                              :", modes)
    print("theorem quantity                   : dE/dlogX = -F_logX/F_E")
    print("prospective decay models           : C X^-p ; C (log X)^-p")
    print("="*168)

    maxX = int(hold_X)
    print("\n[A] Building shared prime-power table and free levels ...")
    n, lam = mangoldt_terms(maxX)
    print("Mangoldt/prime-power terms         :", len(n))
    free = free_archimedean_levels(max(modes))

    # Training construction.
    node_rows: List[dict] = []
    root_maps: Dict[int, Dict[int,float]] = {}
    flow_maps: Dict[int, Dict[int,float]] = {}
    source_env_train: List[float] = []
    flow_env_train: List[float] = []
    trans_min_train: List[float] = []
    phases: Dict[int, FinitePartBump2] = {}
    previous: Dict[int,float] | None = None

    print("\n[B] Constructing TRAINING finite-part branches and exact source flows ...")
    for X in train_X:
        ph = FinitePartBump2(n, lam, X, args.pnt_q, args.prime_chunk)
        phases[X] = ph
        roots = quantize_continued(ph, modes, free, previous, args.root_tol,
                                   args.max_newton, args.scan_points)
        if not all(r.ok for r in roots.values()):
            bad=[k for k,r in roots.items() if not r.ok]
            raise RuntimeError(f"training root certification failed at X={X}, modes={bad}")
        previous = {k:r.root for k,r in roots.items()}
        root_maps[X] = dict(previous)
        fmap: Dict[int,float] = {}
        source_vals=[]; flow_vals=[]; trans=[]
        for k in modes:
            r=roots[k]; sv=ph.sources(r.root)
            fL = -sv.finitepart_L/math.pi
            fE = smooth_count_prime(r.root) - sv.finitepart_E/math.pi
            flow = -fL/fE
            fmap[k]=flow
            source_vals.append(abs(fL)); flow_vals.append(abs(flow)); trans.append(abs(fE))
            cancellation = abs(sv.finitepart_L)/max(abs(sv.prime_L)+abs(sv.pnt_L),1e-300)
            node_rows.append({
                "stage":"TRAIN","X":X,"L=logX":fmt(math.log(X)),"k":k,
                "root":fmt(r.root),"root_residual":fmt(r.residual),"root_method":r.reason,
                "F_E":fmt(fE),"abs_F_E":fmt(abs(fE)),
                "prime_phase":fmt(sv.prime_phase),"pnt_phase":fmt(sv.pnt_phase),"ac_phase":fmt(sv.ac_phase),
                "finitepart_phase":fmt(sv.finitepart_phase),
                "prime_logX_source":fmt(sv.prime_L),"pnt_logX_source":fmt(sv.pnt_L),
                "prime_minus_pnt_source":fmt(sv.finitepart_L),"F_logX":fmt(fL),
                "dE_dlogX":fmt(flow),"source_cancellation_ratio":fmt(cancellation),
            })
        flow_maps[X]=fmap
        source_env_train.append(max(source_vals)); flow_env_train.append(max(flow_vals)); trans_min_train.append(min(trans))
        print(f"  X={X:<9d} max|F_logX|={source_env_train[-1]:.6e} max|dE/dlogX|={flow_env_train[-1]:.6e} min|F_E|={trans_min_train[-1]:.6e}")

    # Step identity over training intervals.
    step_rows: List[dict] = []
    for Xa,Xb in zip(train_X[:-1],train_X[1:]):
        dL=math.log(Xb)-math.log(Xa)
        for k in modes:
            actual=root_maps[Xb][k]-root_maps[Xa][k]
            trap=0.5*(flow_maps[Xa][k]+flow_maps[Xb][k])*dL
            step_rows.append({
                "Xa":Xa,"Xb":Xb,"k":k,"delta_logX":fmt(dL),
                "actual_delta_E":fmt(actual),"trapezoid_integrated_flow":fmt(trap),
                "relative_gap":fmt(safe_rel(actual,trap,1e-14)),
            })

    # Direct analytic-vs-central-difference F_L identity at final training cutoff.
    print("\n[C] Checking analytic partial_logX F against central finite differences ...")
    Xid=train_X[-1]; Lid=math.log(Xid); h=float(args.identity_h)
    ph0=phases[Xid]
    php=FinitePartBump2(n,lam,math.exp(Lid+h),args.pnt_q,args.prime_chunk)
    phm=FinitePartBump2(n,lam,math.exp(Lid-h),args.pnt_q,args.prime_chunk)
    identity_rows=[]
    for k in identity_modes:
        if k not in root_maps[Xid]:
            continue
        E=root_maps[Xid][k]
        analytic=ph0.fL(E,k)
        central=(php.f(E,k)-phm.f(E,k))/(2*h)
        identity_rows.append({"X":Xid,"k":k,"E":fmt(E),"analytic_F_logX":fmt(analytic),
                              "central_difference":fmt(central),"relative_gap":fmt(safe_rel(analytic,central,1e-15))})
        print(f"  k={k:<4d} analytic={analytic:+.6e} central={central:+.6e} rel={safe_rel(analytic,central,1e-15):.3e}")

    # Fit training-only envelopes and freeze before holdout.
    print("\n[D] Fitting and FREEZING prospective source-flow decay ...")
    source_fit=choose_decay(train_X,source_env_train)
    flow_fit=choose_decay(train_X,flow_env_train)
    pred_source=predict_fit(source_fit,hold_X); pred_flow=predict_fit(flow_fit,hold_X)
    upper_source=upper_envelope(pred_source,source_fit,args.prediction_safety)
    upper_flow=upper_envelope(pred_flow,flow_fit,args.prediction_safety)

    fit_rows=[]
    for kind,fit in (("source",source_fit),("flow",flow_fit)):
        for f in fit["candidates"]:
            fit_rows.append({"quantity":kind,"family":f["family"],"label":f["label"],"C":fmt(f["C"]),
                             "p":fmt(f["p"]),"log_rms":fmt(f["log_rms"]),
                             "max_abs_log_residual":fmt(f["max_abs_log_residual"]),
                             "selected":bool(f["family"]==fit["family"]),
                             "integrable_in_dlogX":bool((f["p"]>0) if f["family"]=="power_X" else (f["p"]>1))})

    freeze={
        "version":VERSION,"frozen_before_holdout":True,
        "regulator":"bump_2 finite part: prime - PNT + E1 AC",
        "training_cutoffs":train_X,"held_out_cutoff":hold_X,"modes":modes,
        "source_envelope_training":source_env_train,"flow_envelope_training":flow_env_train,
        "source_fit":source_fit,"flow_fit":flow_fit,
        "predicted_holdout_max_abs_F_logX":pred_source,"source_upper_envelope":upper_source,
        "predicted_holdout_max_abs_dE_dlogX":pred_flow,"flow_upper_envelope":upper_flow,
        "gates":vars(args),
        "firewall":{"known_zero_ordinates_used":False,"zeta_used":False,"Xi_used":False,"holdout_constructed":False},
    }
    freeze_path=Path(str(prefix)+"_PRE_HOLDOUT_FREEZE.json")
    freeze_path.write_text(json.dumps(freeze,indent=2,default=str),encoding="utf-8")
    freeze_sha=sha256_file(freeze_path)
    print("  PRE-HOLDOUT FREEZE SHA256:",freeze_sha)
    print(f"  source fit: {source_fit['family']} p={source_fit['p']:.6g} integrable={source_fit['integrable_in_dlogX']}")
    print(f"  flow fit  : {flow_fit['family']} p={flow_fit['p']:.6g} integrable={flow_fit['integrable_in_dlogX']}")
    print(f"  predicted holdout max|F_logX| : {pred_source:.6e} upper={upper_source:.6e}")
    print(f"  predicted holdout max|flow|   : {pred_flow:.6e} upper={upper_flow:.6e}")

    # Holdout reveal.
    print("\n[E] Revealing HELD-OUT finite-part branches ...")
    phh=FinitePartBump2(n,lam,hold_X,args.pnt_q,args.prime_chunk)
    roots_h=quantize_continued(phh,modes,free,previous,args.root_tol,args.max_newton,args.scan_points)
    hold_root_clean=all(r.ok for r in roots_h.values())
    if not hold_root_clean:
        bad=[k for k,r in roots_h.items() if not r.ok]
        print("  WARNING unresolved holdout modes:",bad)
    root_maps[hold_X]={k:r.root for k,r in roots_h.items() if r.ok}
    source_h=[]; flow_h=[]; trans_h=[]
    hold_fmap={}
    for k in modes:
        r=roots_h[k]
        if not r.ok:
            continue
        sv=phh.sources(r.root)
        fL=-sv.finitepart_L/math.pi
        fE=smooth_count_prime(r.root)-sv.finitepart_E/math.pi
        flow=-fL/fE
        hold_fmap[k]=flow
        source_h.append(abs(fL)); flow_h.append(abs(flow)); trans_h.append(abs(fE))
        cancellation=abs(sv.finitepart_L)/max(abs(sv.prime_L)+abs(sv.pnt_L),1e-300)
        node_rows.append({
            "stage":"HOLDOUT","X":hold_X,"L=logX":fmt(math.log(hold_X)),"k":k,
            "root":fmt(r.root),"root_residual":fmt(r.residual),"root_method":r.reason,
            "F_E":fmt(fE),"abs_F_E":fmt(abs(fE)),
            "prime_phase":fmt(sv.prime_phase),"pnt_phase":fmt(sv.pnt_phase),"ac_phase":fmt(sv.ac_phase),
            "finitepart_phase":fmt(sv.finitepart_phase),
            "prime_logX_source":fmt(sv.prime_L),"pnt_logX_source":fmt(sv.pnt_L),
            "prime_minus_pnt_source":fmt(sv.finitepart_L),"F_logX":fmt(fL),
            "dE_dlogX":fmt(flow),"source_cancellation_ratio":fmt(cancellation),
        })
    flow_maps[hold_X]=hold_fmap
    actual_source=max(source_h) if source_h else float("inf")
    actual_flow=max(flow_h) if flow_h else float("inf")
    min_trans=min(trans_h) if trans_h else 0.0

    # Holdout step identity.
    Xa=train_X[-1]; Xb=hold_X; dL=math.log(Xb)-math.log(Xa)
    hold_step_gaps=[]
    for k in modes:
        if k not in root_maps.get(Xb,{}) or k not in flow_maps[Xb]:
            continue
        actual=root_maps[Xb][k]-root_maps[Xa][k]
        trap=0.5*(flow_maps[Xa][k]+flow_maps[Xb][k])*dL
        gap=safe_rel(actual,trap,1e-14); hold_step_gaps.append(gap)
        step_rows.append({"Xa":Xa,"Xb":Xb,"k":k,"delta_logX":fmt(dL),
                          "actual_delta_E":fmt(actual),"trapezoid_integrated_flow":fmt(trap),
                          "relative_gap":fmt(gap)})

    # PNT quadrature refinement on holdout roots (carrier only; prime sum unchanged).
    print("\n[F] Checking held-out PNT carrier with refined quadrature ...")
    phq=FinitePartBump2(n,lam,hold_X,args.pnt_qcheck,args.prime_chunk)
    refine_rows=[]; refine_max=0.0
    for k in tqdm(modes,desc="PNT q-refinement",unit="mode"):
        if k not in root_maps.get(hold_X,{}): continue
        E=root_maps[hold_X][k]
        a=phh.sources(E); b=phq.sources(E)
        gaps={
            "pnt_phase_rel":safe_rel(a.pnt_phase,b.pnt_phase,1e-12),
            "pnt_E_rel":safe_rel(a.pnt_E,b.pnt_E,1e-12),
            "pnt_L_rel":safe_rel(a.pnt_L,b.pnt_L,1e-12),
            "finitepart_L_rel":safe_rel(a.finitepart_L,b.finitepart_L,1e-12),
        }
        refine_max=max(refine_max,*gaps.values())
        refine_rows.append({"k":k,"E":fmt(E),**{kk:fmt(vv) for kk,vv in gaps.items()}})

    source_pass=actual_source <= upper_source*args.maximum_source_holdout_ratio
    flow_pass=actual_flow <= upper_flow*args.maximum_flow_holdout_ratio
    trans_pass=min_trans >= args.minimum_transversality
    refine_pass=refine_max <= args.maximum_pnt_refinement_relative
    analytic_identity_max=max([float(r["relative_gap"]) for r in identity_rows],default=float("inf"))
    analytic_identity_pass=analytic_identity_max <= 5e-4
    step_max=max(hold_step_gaps,default=float("inf"))
    step_pass=step_max <= args.maximum_step_identity_relative
    source_tail_improved=actual_source <= source_env_train[-1]
    flow_tail_improved=actual_flow <= flow_env_train[-1]
    integrable_fit=bool(source_fit["integrable_in_dlogX"] and flow_fit["integrable_in_dlogX"])

    if not hold_root_clean:
        verdict="HOLDOUT_ROOT_CERTIFICATION_FAILED"
    elif not refine_pass:
        verdict="PNT_QUADRATURE_REFINEMENT_FAILED"
    elif not trans_pass:
        verdict="FINITE_PART_TRANSVERSALITY_FAILED"
    elif not analytic_identity_pass:
        verdict="ANALYTIC_SOURCE_DERIVATIVE_IDENTITY_FAILED"
    elif source_pass and flow_pass and source_tail_improved and flow_tail_improved and integrable_fit:
        verdict="FINITE_PART_SOURCE_FLOW_INTEGRABILITY_SUPPORTED_PROSPECTIVELY"
    elif source_pass and flow_pass and source_tail_improved and flow_tail_improved:
        verdict="FINITE_PART_SOURCE_FLOW_DECAYS__INTEGRABILITY_NOT_YET_SUPPORTED"
    else:
        verdict="FINITE_PART_SOURCE_FLOW_HOLDOUT_NOT_SUPPORTED"

    # Output files.
    node_path=Path(str(prefix)+"_NODES.csv"); write_csv(node_path,node_rows)
    step_path=Path(str(prefix)+"_STEPS.csv"); write_csv(step_path,step_rows)
    id_path=Path(str(prefix)+"_DERIVATIVE_IDENTITY.csv"); write_csv(id_path,identity_rows)
    fit_path=Path(str(prefix)+"_FITS.csv"); write_csv(fit_path,fit_rows)
    ref_path=Path(str(prefix)+"_PNT_REFINEMENT.csv"); write_csv(ref_path,refine_rows)

    theorem_text = r"""# ROT-RH v452 finite-part source-flow theorem target

For the bump-2 finite-part secular function

    F_L(E)=theta(E)/pi+1-[P_L(E)-M_L(E)+M_inf^AC(E)]/pi,

the exact continuous cutoff derivative is

    partial_L F_L(E)=-(partial_L P_L(E)-partial_L M_L(E))/pi,

with

    partial_L phi_L(y)=2 y^2/(L-y)^3 phi_L(y).

At a simple branch F_L(E_k(L))=k-1/2,

    dE_k/dL = -partial_L F_L / partial_E F_L.

A proof of fixed-mode cutoff independence follows if eventually

    |partial_E F_L(E_k(L))| >= d_k > 0

and

    integral_{L0}^infinity |partial_L F_L(E_k(L))| dL < infinity.

Uniform heat convergence on every [u0,u1] subset (0,infinity), strong-resolvent
convergence of the ordered diagonal realization, and trace-norm convergence of
H_L^{-2} then follow under the standard uniform Weyl lower bound and a summable
mode envelope.

This finite audit does not prove the all-L source estimate. Its purpose is to
identify whether the exact finite-part prime-minus-PNT numerator shows the
prospective decay required by that theorem.
"""
    theorem_path=Path(str(prefix)+"_THEOREM.md"); theorem_path.write_text(theorem_text,encoding="utf-8")

    summary={
        "version":VERSION,"elapsed_seconds":time.time()-t0,"verdict":verdict,
        "zero_ordinate_firewall":True,"cutoffs":cutoffs,"modes":modes,
        "pre_holdout_freeze_sha256":freeze_sha,
        "training_max_abs_F_logX":source_env_train,"training_max_abs_dE_dlogX":flow_env_train,
        "source_fit":source_fit,"flow_fit":flow_fit,
        "holdout":{"X":hold_X,"root_clean":hold_root_clean,
                   "actual_max_abs_F_logX":actual_source,"predicted":pred_source,"upper":upper_source,"pass":source_pass,
                   "actual_max_abs_dE_dlogX":actual_flow,"predicted_flow":pred_flow,"flow_upper":upper_flow,"flow_pass":flow_pass,
                   "minimum_abs_F_E":min_trans,"transversality_pass":trans_pass,
                   "maximum_step_relative_gap":step_max,"step_identity_pass":step_pass,
                   "PNT_refinement_max_relative":refine_max,"PNT_refinement_pass":refine_pass},
        "analytic_F_logX_identity_max_relative":analytic_identity_max,
        "analytic_F_logX_identity_pass":analytic_identity_pass,
        "source_tail_improved":source_tail_improved,"flow_tail_improved":flow_tail_improved,
        "selected_fits_integrable_in_dlogX":integrable_fit,
        "scientific_boundary":"Finite prospective evidence only; all-L signed prime-minus-PNT source-flow theorem remains open.",
        "outputs":[str(p) for p in [node_path,step_path,id_path,fit_path,ref_path,freeze_path,theorem_path]],
    }
    summary_path=Path(str(prefix)+"_SUMMARY.json"); summary_path.write_text(json.dumps(summary,indent=2,default=str),encoding="utf-8")

    print("\n"+"="*168)
    print("KEY RESULTS")
    print("="*168)
    print("verdict                                  :",verdict)
    print("pre-holdout freeze SHA256                :",freeze_sha)
    print(f"source fit                               : {source_fit['family']} p={source_fit['p']:.6g} integrable={source_fit['integrable_in_dlogX']}")
    print(f"flow fit                                 : {flow_fit['family']} p={flow_fit['p']:.6g} integrable={flow_fit['integrable_in_dlogX']}")
    print("training max |F_logX|                    :",[f"{x:.6e}" for x in source_env_train])
    print("training max |dE/dlogX|                  :",[f"{x:.6e}" for x in flow_env_train])
    print(f"holdout max |F_logX| pred/upper/actual   : {pred_source:.6e} / {upper_source:.6e} / {actual_source:.6e} pass={source_pass}")
    print(f"holdout max |flow| pred/upper/actual     : {pred_flow:.6e} / {upper_flow:.6e} / {actual_flow:.6e} pass={flow_pass}")
    print(f"holdout minimum |F_E|                    : {min_trans:.6e} pass={trans_pass}")
    print(f"analytic F_logX derivative identity max  : {analytic_identity_max:.6e} pass={analytic_identity_pass}")
    print(f"holdout dyadic flow-step max rel gap     : {step_max:.6e} pass={step_pass}")
    print(f"PNT q refinement max relative            : {refine_max:.6e} pass={refine_pass}")
    print("source / flow tail improved              :",source_tail_improved,"/",flow_tail_improved)
    print("selected fits integrable in dlogX        :",integrable_fit)
    print("summary                                  :",summary_path)
    print("="*168)

    failed = verdict not in {
        "FINITE_PART_SOURCE_FLOW_INTEGRABILITY_SUPPORTED_PROSPECTIVELY",
        "FINITE_PART_SOURCE_FLOW_DECAYS__INTEGRABILITY_NOT_YET_SUPPORTED",
    }
    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
