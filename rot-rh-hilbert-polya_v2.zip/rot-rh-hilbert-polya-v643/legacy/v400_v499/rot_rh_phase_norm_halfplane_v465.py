#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v465 — PHASE-FUNCTIONAL NORM MISMATCH / HALF-PLANE CAPTURE THEOREM
========================================================================

PURPOSE
-------
Continue the v464 Rouché attack in two directions:

1. Prove an exact NO-GO for the naive idea that v402's beta=2 weighted-prefix
   contraction automatically controls the bump PHASE factor.

2. Weaken v464's disk criterion |R-1|<1 to the genuinely necessary
   HALF-PLANE / half-integer-plateau criterion.

PART A — EXACT DUAL NORM OF THE BUMP PHASE FUNCTIONAL
------------------------------------------------------
Fix phase E and support s<=n<=D. Let

    A_u(m)=sum_(s<=n<=m) u_n exp(iE log n).

For beta>=0 define

    ||u||_(beta,s,D)
      = sup_(s<=m<=D) (s/m)^beta |A_u(m)|.

For any nonnegative nonincreasing weight b_n, Abel summation gives

    L_b(u)
      = sum_(n=s)^D u_n exp(iElog n)b_n
      = A_u(D)b_D
        + sum_(m=s)^(D-1) A_u(m)(b_m-b_(m+1)).

Therefore

    |L_b(u)|
      <= W_beta(b;s,D) ||u||_beta,

where

    W_beta
      = (D/s)^beta b_D
        + sum_(m=s)^(D-1)
            (m/s)^beta (b_m-b_(m+1)).

This is not merely an upper bound.  It is the EXACT complex dual norm:
choose every A_u(m) with maximal allowed modulus and the common phase of the
positive Abel coefficients; then recover u from prefix increments.

For the bump phase

    b_L(n)=p(log n/L),
    p(x)=exp(-(x/(1-x))^2),

b_L is nonnegative and decreasing.

For beta=0 the exact norm telescopes:

    W_0=b_L(s)<=1.

So the bump phase is uniformly continuous on the ordinary unweighted
phase-prefix space.

For every beta>0, choose any fixed alpha in (0,1) and

    D_L=floor(exp(alpha L)).

Then

    b_L(D_L) >= approximately p(alpha)>0

and hence

    W_beta >= (D_L/s)^beta b_L(D_L)
             ~ p(alpha) exp(alpha beta L)/s^beta.

Thus the bump phase functional is NOT uniformly bounded on any polynomially
growing weighted-prefix geometry, including v402's beta=2 space.

This is an exact functional-analytic obstruction.  Qjet<1 cannot simply be
multiplied by a bounded bump-phase dual norm, because that dual norm is not
bounded in the v402 geometry.

This is consistent with v323's historical conclusion that ordinary unweighted
BV/prefix geometry and scale-covariant weighted geometry solve different
problems.

PART B — THE TRUE HALF-INTEGER GEOMETRY
----------------------------------------
Let the normalized regular-phase shift relative to the canonical local
argument-principle reference be epsilon_L.  The collision plateaus move from
integers to

    Z + epsilon_L.

The secular labels are

    Z + 1/2.

Hence the actual plateau-label gap is

    d_L = dist(epsilon_L, Z+1/2).

v463's condition |epsilon|<1/2 around zero was only one sufficient chart.
Integer windings of epsilon are harmless.

If a specific branch label lambda obeys

    m s_p(u_L) = lambda - B_L,

then v462 gives the general exact implication

    |u_L|
      <= m Csat / (pi d_L),

where

    Csat=2(1+sqrt(pi)).

Therefore

    |E(L)-gamma|
      <= m Csat / [pi L d_L].

So a fixed positive gap is sufficient, but not necessary.  The minimal
asymptotic condition is

    L d_L -> infinity.

More generally, if

    d_L >= c L^(-alpha),    alpha<1,

then

    |E(L)-gamma|=O(L^(alpha-1)) -> 0.

HALF-PLANE FORM
---------------
Let the multiplicative regular factor ratio have phase

    R_L/|R_L| = exp(i pi epsilon_L).

Half-integer plateau resonance means

    epsilon_L in Z+1/2,

equivalently

    Re R_L = 0.

If quantitatively

    |Re R_L|/|R_L| >= h_L,

then the angular distance from the imaginary axis is at least

    a_L = arcsin(h_L),

so

    d_L >= a_L/pi

and

    |u_L|
      <= m Csat / a_L
      = 2m(1+sqrt(pi))/arcsin(h_L).

Thus v464's disk condition is replaced by the weaker HALF-PLANE condition.

If |R_L-1|<=eta<1, then h_L>=sqrt(1-eta^2) and
arcsin(h_L)=arccos(eta), recovering v464 exactly.

NEW FRONTIER
------------
For the phase-factor route one needs a norm/structure with BOTH:

  (i) the bump phase functional is bounded or relatively controlled;
  (ii) the regular R7 transfer is contractive.

v402 solves (ii) in beta=2 but fails (i) for the full phase observable.
The unweighted prefix space solves (i), but the unconstrained complex R7
contraction was rejected by v281 and ordinary scale behavior motivated v323.

Therefore the next non-circular routes are:

  A. prove contraction on the REAL/arithmetic phase-prefix subspace;
  B. construct a cancellation-preserving bounded-weight norm;
  C. control only a RELATIVE collision-subtracted phase functional whose beta=2
     dual norm has the needed scale cancellation;
  D. derive half-plane avoidance from an independent operator/index property
     rather than a scalar prime-discrepancy majorant.

SCIENTIFIC BOUNDARY
-------------------
v465 proves the dual-norm obstruction and the half-plane capture algebra.
It does not prove the required arithmetic half-plane theorem, cutoff
independence, RH, or Fredholm-Xi.

No Xi values, numerical zeta values, zeta derivatives, or known zero ordinates
are used.

Version: 2026-08-28-v465-phase-norm-halfplane
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any, List

from tqdm import tqdm

VERSION = "2026-08-28-v465-phase-norm-halfplane"
CSAT = 2.0*(1.0+math.sqrt(math.pi))
QJET = 657981440000000 / 1853020188851841
RHOJET = 40160000000 / 1853020188851841


def p_bump(x: float) -> float:
    if x < 0:
        return math.nan
    if x >= 1:
        return 0.0
    r = x/(1.0-x)
    z = -(r*r)
    return 0.0 if z < -745 else math.exp(z)


def bump_weight(n: int, L: float) -> float:
    return p_bump(math.log(float(n))/L)


def exact_dual_weight(beta: float, s: int, D: int, L: float) -> float:
    b_prev = bump_weight(s, L)
    # Direct formula:
    total = 0.0
    for m in range(s, D):
        b_m = bump_weight(m, L)
        b_next = bump_weight(m+1, L)
        total += (m/s)**beta * max(0.0, b_m-b_next)
    total += (D/s)**beta * bump_weight(D, L)
    return total


def extremizer_check(beta: float, s: int, D: int, L: float) -> Dict[str, Any]:
    """
    Construct prefix values A_m=(m/s)^beta, which define a valid complex input
    after phase demodulation.  Since all Abel coefficients are nonnegative, this
    attains the dual bound exactly up to floating arithmetic.
    """
    W = exact_dual_weight(beta, s, D, L)

    # Reconstruct the demodulated increments v_n = A_n-A_(n-1).
    A_prev = 0.0
    direct = 0.0
    norm = 0.0
    for n in range(s, D+1):
        A = (n/s)**beta
        v = A-A_prev
        direct += v*bump_weight(n, L)
        norm = max(norm, (s/n)**beta * abs(A))
        A_prev = A

    return {
        "beta": beta,
        "dual_formula": W,
        "extremizer_value": direct,
        "extremizer_norm": norm,
        "absolute_attainment_gap": abs(W-direct),
        "pass": abs(W-direct) <= 2e-10*max(1.0, abs(W)) and abs(norm-1.0) <= 1e-12,
    }


def asymptotic_lower(beta: float, alpha: float, s: int, L: float) -> Dict[str, Any]:
    D = max(s, int(math.floor(math.exp(alpha*L))))
    bD = bump_weight(D, L)
    lower = (D/s)**beta*bD
    proxy = p_bump(alpha)*math.exp(alpha*beta*L)/(s**beta)
    return {
        "beta": beta,
        "alpha": alpha,
        "L": L,
        "D": D,
        "b_D": bD,
        "exact_boundary_lower": lower,
        "asymptotic_proxy": proxy,
        "diverges_for_beta_positive": beta > 0.0,
    }


def halfplane_capture(h: float, m: int, L: float) -> Dict[str, Any]:
    if not (0.0 < h <= 1.0):
        raise ValueError("h must satisfy 0<h<=1")
    a = math.asin(h)
    d = a/math.pi
    U = m*CSAT/a
    return {
        "h": h,
        "angular_gap_from_imag_axis": a,
        "normalized_plateau_gap": d,
        "capture_U": U,
        "capture_E_error": U/L,
        "formula": "2m(1+sqrt(pi))/(asin(h)L)",
    }


def gap_rate(alpha: float, c: float, m: int, L: float) -> Dict[str, Any]:
    d = c*(L**(-alpha))
    U = m*CSAT/(math.pi*d)
    return {
        "alpha": alpha,
        "c": c,
        "L": L,
        "gap_lower": d,
        "u_upper": U,
        "energy_error_upper": U/L,
        "decay_exponent": 1.0-alpha,
        "converges_if_alpha_below_one": alpha < 1.0,
    }


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v465 — phase-functional norm mismatch / half-plane capture theorem

## A. Exact bump-phase dual norm

For

`||u||_beta=sup_(s<=m<=D)(s/m)^beta |A_u(m)|`

and any decreasing nonnegative `b_m`,

`||L_b||_dual
 = (D/s)^beta b_D
   + sum_(m=s)^(D-1)(m/s)^beta(b_m-b_(m+1))`.

The equality is exact, not only an upper bound.

For the bump phase `b_L(n)=p(log n/L)`:

* `beta=0`: `||L_b||=b_L(s)<=1`;
* every `beta>0`: taking `D=floor(exp(alpha L))`, `0<alpha<1`, gives

  `||L_b|| >= p(alpha) exp(alpha beta L)/s^beta`

  asymptotically.

Therefore the full bump phase functional is not uniformly continuous on
v402's `beta=2` weighted-prefix geometry.

So `Qjet={QJET:.16e}<1` does **not** by itself imply a bounded local phase-factor
perturbation.

## B. Correct half-integer target

Let `epsilon_L` be the normalized regular phase shift modulo integer winding.

The collision plateaus are `Z+epsilon_L`; secular labels are `Z+1/2`.

Define

`d_L=dist(epsilon_L,Z+1/2)`.

Then v462 gives

`|u_L| <= m*2(1+sqrt(pi))/(pi d_L)`,

and hence

`|E(L)-gamma|
 <= m*2(1+sqrt(pi))/(pi L d_L)`.

A constant positive `d_L` gives the usual `O(1/L)` capture, but the weaker
condition

`L d_L -> infinity`

already suffices.

If `d_L>=c L^-alpha` with `alpha<1`, then

`|E(L)-gamma|=O(L^(alpha-1))`.

## C. Half-plane form

Write the regular factor phase as

`R_L/|R_L|=exp(i pi epsilon_L)`.

The bad half-integer set is exactly

`Re R_L=0`.

If

`|Re R_L|/|R_L| >= h_L>0`,

then

`d_L >= asin(h_L)/pi`

and

`|u_L| <= 2m(1+sqrt(pi))/asin(h_L)`.

Thus the true relative target is **avoid the imaginary axis**, not remain in a
disk around `+1`.

v464's disk condition is recovered from

`|R_L-1|<=eta<1`

because then `asin(h)>=acos(eta)`.

## D. Norm-design consequence

The desired Banach geometry must simultaneously make

1. the bump phase observable continuous, and
2. the regular `R^7` transfer contractive.

The v402 `beta=2` geometry has property 2 but not property 1.

The ordinary unweighted phase-prefix geometry has property 1, but the full
complex-prefix contraction route was already rejected and motivated the
scale-covariant v323 program.

Therefore the next serious theorem should target one of:

* the real/arithmetic prefix subspace;
* a bounded cancellation-preserving norm;
* a collision-subtracted **relative** phase functional with a bounded beta=2
  dual norm;
* an independent operator/index theorem forcing half-plane avoidance.

This is an exact obstruction/reduction, not an RH proof.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_PHASE_FUNCTIONAL_HALFPLANE_CERTIFICATE_V1",
        "closed": {
            "exact_beta_dual_norm": True,
            "beta0_uniform_phase_functional": True,
            "positive_beta_uniform_phase_functional": False,
            "v402_naive_phase_embedding": "RULED_OUT",
            "general_plateau_gap_capture":
                "|E-gamma|<=2m(1+sqrt(pi))/(pi L d_L)",
            "minimal_gap_condition": "L*d_L -> infinity",
            "halfplane_bad_set": "Re R_L=0",
            "halfplane_capture":
                "|E-gamma|<=2m(1+sqrt(pi))/(asin(h_L)L)",
        },
        "required_next": {
            "phase_adapted_R7_space":
                "find a space where the bump phase is continuous and R7 is contractive on the arithmetic subspace",
            "or_relative_functional":
                "show collision-subtracted relative phase has bounded dual norm in v402 geometry",
            "or_operator_index":
                "derive quantitative half-plane avoidance independently of scalar PNT forcing",
        },
        "warning": (
            "Do not identify Qjet or rhojet with a local determinant-factor eta "
            "without a separate observable embedding theorem."
        ),
    }
    cert.write_text(json.dumps(certificate, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--L", type=float, default=20.0)
    ap.add_argument("--s", type=int, default=2)
    ap.add_argument("--D", type=int, default=20000)
    ap.add_argument("--alpha", type=float, default=0.50)
    ap.add_argument("--multiplicity", type=int, default=1)
    ap.add_argument("--halfplane-h", type=float, default=0.5)
    ap.add_argument(
        "--prefix",
        default="rot_rh_phase_norm_halfplane_v465",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.L <= 0:
        raise ValueError("--L must be positive")
    if args.s < 2 or args.D < args.s:
        raise ValueError("need 2<=s<=D")
    if not (0.0 < args.alpha < 1.0):
        raise ValueError("--alpha must lie in (0,1)")
    if args.multiplicity < 1:
        raise ValueError("--multiplicity must be >=1")

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*190)
    print("ROT-RH v465 — PHASE-FUNCTIONAL NORM MISMATCH / HALF-PLANE CAPTURE THEOREM")
    print("="*190)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("v402 naive phase embedding                 : TESTED ANALYTICALLY")
    print("half-integer target                        : IMAGINARY-AXIS AVOIDANCE")
    print("="*190)

    with tqdm(total=5, desc="v465 theorem checks", unit="step") as bar:
        e0 = extremizer_check(0.0, args.s, args.D, args.L)
        bar.update(1)
        e2 = extremizer_check(2.0, args.s, args.D, args.L)
        bar.update(1)
        low = asymptotic_lower(2.0, args.alpha, args.s, args.L)
        bar.update(1)
        hp = halfplane_capture(args.halfplane_h, args.multiplicity, args.L)
        bar.update(1)
        rates = [
            gap_rate(a, 0.25, args.multiplicity, args.L)
            for a in (0.0, 0.25, 0.50, 0.75, 0.99, 1.0)
        ]
        bar.update(1)

    passed = bool(
        e0["pass"]
        and e2["pass"]
        and e0["dual_formula"] <= 1.0+1e-12
        and low["exact_boundary_lower"] > 1.0
        and hp["normalized_plateau_gap"] > 0.0
    )

    verdict = (
        "EXACT_PHASE_NORM_MISMATCH_AND_HALFPLANE_CAPTURE_PASS"
        if passed else
        "PHASE_NORM_HALFPLANE_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "finite_scan_accepted_as_proof": False,
        },
        "beta0_extremizer": e0,
        "beta2_extremizer": e2,
        "beta2_asymptotic_lower": low,
        "halfplane_capture": hp,
        "gap_rate_panel": rates,
        "v402": {
            "Qjet": QJET,
            "rhojet": RHOJET,
            "naive_full_bump_phase_embedding_valid": False,
        },
        "proof_status": (
            "Exact dual-norm theorem and exact half-plane capture reduction. "
            "Arithmetic half-plane avoidance / phase-adapted R7 contraction remains open."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*190)
    print("verdict                                  :", verdict)
    print("beta=0 exact bump-phase dual norm        :", f"{e0['dual_formula']:.16e}")
    print("beta=2 exact bump-phase dual norm        :", f"{e2['dual_formula']:.16e}")
    print("beta=2 exp(alpha L) boundary lower       :", f"{low['exact_boundary_lower']:.16e}")
    print("Qjet                                     :", f"{QJET:.16e}")
    print("naive Qjet -> factor disk                : INVALID WITHOUT NEW EMBEDDING")
    print("half-plane h                             :", args.halfplane_h)
    print("normalized plateau gap from h            :", f"{hp['normalized_plateau_gap']:.16e}")
    print("capture |u| upper                        :", f"{hp['capture_U']:.16e}")
    print("capture |E-gamma| upper at L             :", f"{hp['capture_E_error']:.16e}")
    print("summary                                  :", str(prefix)+"_SUMMARY.json")
    print("theorem                                  :", str(prefix)+"_THEOREM.md")
    print("next certificate                         :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*190)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
