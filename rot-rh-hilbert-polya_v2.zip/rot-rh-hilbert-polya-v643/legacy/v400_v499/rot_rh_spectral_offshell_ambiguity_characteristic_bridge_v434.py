#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v434 — SPECTRAL-DATA OFF-SHELL AMBIGUITY / CHARACTERISTIC-FUNCTION BRIDGE
=================================================================================

Purpose
-------
v433 showed that fixed-X self-adjointness alone cannot bound the v432 complex
dyadic forcing J_X^C(E).  A natural next attempt would be to derive J_X^C from
the diagonal operator H_X, its resolvent, or the existing cyclic/CMV weights.

v434 proves a sharper obstruction:

    ROOTS ALONE do not determine an off-shell secular function.

More strongly,

    ROOTS + FIRST DERIVATIVES AT THE ROOTS

still do not determine it.

This matters because the current fixed-cutoff operator data consist of

    E_(n,X)

and, in the cyclic/CMV realization, weights of the form

    q_(n,X)
      proportional to
      1/[F'_X(E_(n,X)) (1+E_(n,X)^2)^2].

Those data are invariant under an infinite analytic ambiguity that changes the
off-shell secular function.

Exact ambiguity theorem
-----------------------
Let S(z) be analytic in a domain and let a be any constant. Define

    S_a(z) = exp(a S(z)) S(z).

At every zero z_n of S,

    S_a(z_n)=0.

Moreover

    S_a'(z)
      = exp(aS(z)) S'(z) [1+aS(z)],

so at S(z_n)=0,

    S_a'(z_n)=S'(z_n).

Thus S and S_a have identical zeros and identical first derivatives at every
zero, hence the same root-only diagonal operator and the same weights built
only from roots and first derivatives.

But off shell,

    S_a/S = exp(aS)

is nonconstant for a != 0 and nonconstant S.  Also at a simple root,

    S_a''(z_n)
      = S''(z_n) + 2a [S'(z_n)]^2,

so even the local second-order shape changes while roots and slopes remain
fixed.

Concrete example
----------------
Take

    S(z)=sin z,
    S_a(z)=exp(a sin z) sin z.

Both have zeros z_n=n*pi and derivatives (-1)^n at those zeros.  Therefore any
diagonal resolvent constructed only from n*pi, and any cyclic weights depending
only on n*pi and (-1)^n, are identical.  Nevertheless S_a(z) != S(z) off shell.

Consequence for ROT-RH
----------------------
The v432 forcing is an off-shell prime/cutoff observable.  Therefore it cannot
be inferred from the existing diagonal spectrum or root-slope weights alone.

A NON-CIRCULAR operator bridge must add one of the following:

1. EXACT CHARACTERISTIC-FUNCTION REALIZATION
   Construct an energy-independent colligation/operator whose characteristic or
   scattering function is EXACTLY the zero-free arithmetic secular function
   D_X(z) or J_X(z), with its normalization fixed independently of zeros.

2. EXACT FREDHOLM DETERMINANT NORMALIZATION
   Prove
       secular_X(z)=G_X(z) det(I+T_X(z))
   and determine/control the zero-free factor G_X independently.

3. WEYL-M-FUNCTION RECONSTRUCTION WITH ARITHMETIC NORMALIZATION
   Prove that the cyclic m-function plus a specified asymptotic/boundary
   normalization reconstructs the actual arithmetic phase, not merely another
   function with the same poles/residues.

The simple global centered Schur/Herglotz route is not revived; v273 already
falsified that finite mechanism.  The preferred route is therefore a canonical
possibly-indefinite/unitary characteristic-function or Fredholm realization of
the FULL centered arithmetic system.

What v434 does
--------------
1. Symbolically proves the roots+slopes ambiguity theorem.
2. Numerically demonstrates it with S=sin z and S_a=e^(a sin z)sin z.
3. Checks the current fixed-operator theorem scope and v433/v432 lineage.
4. If the v71 source file is available locally, scans its text for the
   prime-colligation/transfer-function architecture to identify whether a
   characteristic-function route is already present in the code base.
5. Writes the exact next certificate.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO finite compatibility accepted as proof.

Version: 434
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import re
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
from tqdm import tqdm

VERSION = 434


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_ambiguity() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    S, Sp, Spp, a = sp.symbols(
        "S Sp Spp a",
        real=True,
    )

    # Treat S(z), S'(z), S''(z) as jet coordinates.
    Sa = sp.exp(a*S)*S

    # Chain-rule first derivative:
    Sap = sp.exp(a*S)*Sp*(1+a*S)

    # Differentiate the first derivative with respect to z using
    # dS/dz=Sp, dSp/dz=Spp.
    d_dS = sp.diff(Sap, S)
    d_dSp = sp.diff(Sap, Sp)
    Sapp = sp.simplify(
        d_dS*Sp + d_dSp*Spp
    )

    root_value = sp.simplify(Sa.subs(S, 0))
    root_slope = sp.simplify(Sap.subs(S, 0)-Sp)
    root_curvature_shift = sp.simplify(
        Sapp.subs(S, 0)-Spp
    )
    expected_shift = 2*a*Sp**2

    ratio = sp.simplify(Sa/S)

    return {
        "transformation": "S_a=exp(a S) S",
        "root_value_residual": str(root_value),
        "root_slope_residual": str(root_slope),
        "root_curvature_shift": str(root_curvature_shift),
        "expected_curvature_shift": str(expected_shift),
        "off_shell_ratio": str(ratio),
        "pass": bool(
            root_value == 0
            and root_slope == 0
            and sp.simplify(
                root_curvature_shift-expected_shift
            ) == 0
            and ratio == sp.exp(a*S)
        ),
    }


def numerical_counterexample(a: float, points: int) -> Dict[str, Any]:
    n = np.arange(-20, 21, dtype=float)
    roots = n*math.pi

    Sroot = np.sin(roots)
    Saroot = np.exp(a*np.sin(roots))*np.sin(roots)

    # Derivatives:
    # S'=cos z
    # Sa'=e^(a sin z) cos z (1+a sin z)
    Sp = np.cos(roots)
    Sap = (
        np.exp(a*np.sin(roots))
        * np.cos(roots)
        * (1+a*np.sin(roots))
    )

    z = np.linspace(-2.75, 2.75, int(points))
    mask = np.abs(np.sin(z)) > 1e-4
    z = z[mask]
    S = np.sin(z)
    Sa = np.exp(a*S)*S

    return {
        "a": float(a),
        "root_count": int(len(roots)),
        "maximum_root_value_difference": float(
            np.max(np.abs(Sroot-Saroot))
        ),
        "maximum_root_slope_difference": float(
            np.max(np.abs(Sp-Sap))
        ),
        "maximum_off_shell_absolute_difference": float(
            np.max(np.abs(S-Sa))
        ),
        "maximum_off_shell_relative_difference": float(
            np.max(
                np.abs(S-Sa)
                / np.maximum(np.abs(S), 1e-12)
            )
        ),
        "counterexample_pass": bool(
            np.max(np.abs(Sroot-Saroot)) < 1e-12
            and np.max(np.abs(Sp-Sap)) < 1e-12
            and np.max(np.abs(S-Sa)) > 1e-3
        ),
    }


def scan_v71_source(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {
            "available": False,
            "path": str(p),
        }

    text = p.read_text(
        encoding="utf-8",
        errors="replace",
    )

    patterns = {
        "prime_colligation": r"colligation",
        "transfer_factor": r"transfer factor",
        "julia": r"Julia",
        "secular_phase": r"F_X\(E\)",
        "determinant": r"D_X\(E\)",
        "riesz": r"Riesz",
        "local_fredholm": r"Fredholm",
    }
    found = {
        key: bool(re.search(pattern, text, flags=re.I))
        for key, pattern in patterns.items()
    }

    return {
        "available": True,
        "path": str(p),
        "bytes": p.stat().st_size,
        "signals": found,
        "characteristic_architecture_present": bool(
            found["prime_colligation"]
            and found["transfer_factor"]
            and found["secular_phase"]
            and found["determinant"]
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v432-summary",
        default="rot_rh_complex_dyadic_forcing_laplace_pole_v432_SUMMARY.json",
    )
    ap.add_argument(
        "--v433-summary",
        default="rot_rh_operator_complex_forcing_bridge_v433_SUMMARY.json",
    )
    ap.add_argument(
        "--fixed-operator-summary",
        default="rot_rh_fixed_cutoff_infinite_operator_theorem_summary.json",
    )
    ap.add_argument(
        "--v71-source",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71.py",
    )
    ap.add_argument(
        "--counterexample-a",
        type=float,
        default=0.35,
    )
    ap.add_argument(
        "--counterexample-points",
        type=int,
        default=2001,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_spectral_offshell_ambiguity_characteristic_bridge_v434",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()

    v432 = load_json(args.v432_summary)
    v433 = load_json(args.v433_summary)
    fixed = load_json(args.fixed_operator_summary)

    v432_ok = bool(
        v432 is not None
        and v432.get("verdict")
        == "EXACT_COMPLEX_DYADIC_FORCING_LAPLACE_POLE_REDUCTION_PASS"
    )
    v433_logic_ok = bool(
        v433 is not None
        and str(v433.get("verdict", "")).startswith(
            "EXACT_OPERATOR_COMPLEX_FORCING_BRIDGE_REQUIREMENTS_PASS"
        )
    )

    # The user's v433 may be INCOMPLETE only because the local summary file was
    # absent.  Preserve that distinction explicitly.
    fixed_ok = bool(
        fixed is not None
        and fixed.get("verdict")
        == "PASS_FIXED_CUTOFF_INFINITE_SELF_ADJOINT_AND_DEPTH_STRONG_RESOLVENT_GLOBAL_PRIME_LIMIT_OPEN"
    )
    fixed_missing = fixed is None

    print("="*232)
    print("ROT-RH v434 — SPECTRAL-DATA OFF-SHELL AMBIGUITY / CHARACTERISTIC-FUNCTION BRIDGE")
    print("="*232)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("finite counterexample accepted as RH proof: NO")
    print("="*232)

    print("[1] Upstream")
    print(
        "v432 complex-forcing reduction           :",
        v432_ok,
        None if v432 is None else v432.get("verdict"),
    )
    print(
        "v433 exact bridge/no-go lineage           :",
        v433_logic_ok,
        None if v433 is None else v433.get("verdict"),
    )
    print(
        "fixed-X theorem summary available         :",
        not fixed_missing,
    )
    print(
        "fixed-X theorem certified from file       :",
        fixed_ok,
        None if fixed is None else fixed.get("verdict"),
    )
    if fixed_missing:
        print(
            "NOTE                                      : missing summary is bookkeeping; "
            "v434's ambiguity theorem does not depend on that JSON."
        )

    print("\n[2] Exact roots+slopes ambiguity theorem")
    sym = symbolic_ambiguity()
    with tqdm(
        total=4,
        desc="off-shell ambiguity lemmas",
        unit="lemma",
    ) as bar:
        for _ in range(4):
            bar.update(1)

    print("symbolic ambiguity pass                   :", sym.get("pass"))
    print("transformation                            :", sym.get("transformation"))
    print("root value residual                       :", sym.get("root_value_residual"))
    print("root slope residual                       :", sym.get("root_slope_residual"))
    print("root curvature shift                      :", sym.get("root_curvature_shift"))
    print("off-shell ratio                           :", sym.get("off_shell_ratio"))

    print("\n[3] Concrete analytic counterexample")
    counter = numerical_counterexample(
        args.counterexample_a,
        args.counterexample_points,
    )
    print(
        "maximum root value difference             :",
        f"{counter['maximum_root_value_difference']:.12e}",
    )
    print(
        "maximum root slope difference             :",
        f"{counter['maximum_root_slope_difference']:.12e}",
    )
    print(
        "maximum off-shell absolute difference     :",
        f"{counter['maximum_off_shell_absolute_difference']:.12e}",
    )
    print(
        "counterexample pass                       :",
        counter["counterexample_pass"],
    )

    print("\n[4] Existing characteristic-function architecture")
    v71scan = scan_v71_source(args.v71_source)
    print("v71 source available                      :", v71scan.get("available"))
    if v71scan.get("available"):
        print(
            "prime-colligation/transfer architecture   :",
            v71scan.get("characteristic_architecture_present"),
        )
        for key, val in v71scan["signals"].items():
            print(f"  {key:34s}: {val}")

    exact_ambiguity_pass = bool(
        sym.get("pass")
        and counter["counterexample_pass"]
        and v432_ok
    )

    if exact_ambiguity_pass:
        verdict = (
            "EXACT_ROOTS_AND_SLOPES_OFFSHELL_NONUNIQUENESS_PASS_"
            "CHARACTERISTIC_FUNCTION_BRIDGE_REQUIRED"
        )
    else:
        verdict = (
            "ROOTS_AND_SLOPES_OFFSHELL_NONUNIQUENESS_INCOMPLETE"
        )

    next_theorem = (
        "CONSTRUCT_CANONICAL_FULL_CENTERED_CHARACTERISTIC_OR_FREDHOLM_"
        "FUNCTION_WITH_FIXED_ZERO_FREE_NORMALIZATION"
    )

    print("\n" + "="*232)
    print("VERDICT                                   :", verdict)
    print(
        "ROOT SPECTRUM DETERMINES J_COMPLEX        : NO"
    )
    print(
        "ROOTS + FIRST SLOPES DETERMINE J_COMPLEX : NO"
    )
    print(
        "DIAGONAL RESOLVENT-ONLY BRIDGE            : INSUFFICIENT"
    )
    print(
        "REQUIRED NEW STRUCTURE                    : CANONICAL OFF-SHELL "
        "CHARACTERISTIC/FREDHOLM NORMALIZATION"
    )
    print("NEXT THEOREM                              :", next_theorem)
    print("="*232)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix)+"_SUMMARY.json")
    theorem_path = Path(str(prefix)+"_THEOREM.md")
    cert_path = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
        },
        "upstream": {
            "v432_ok": v432_ok,
            "v433_exact_lineage_ok": v433_logic_ok,
            "v433_verdict": None if v433 is None else v433.get("verdict"),
            "fixed_summary_available": not fixed_missing,
            "fixed_summary_ok": fixed_ok,
        },
        "ambiguity_theorem": sym,
        "counterexample": counter,
        "v71_characteristic_architecture_scan": v71scan,
        "logical_conclusion": {
            "spectrum_only_sufficient": False,
            "roots_plus_first_slopes_sufficient": False,
            "reason": (
                "S_a=exp(aS)S preserves every zero and first derivative at each "
                "zero but changes the off-shell analytic function"
            ),
            "impact_on_current_operator": (
                "the diagonal H_X and slope-based cyclic weights cannot by "
                "themselves determine the v432 off-shell complex forcing"
            ),
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v434 — roots+slopes are not enough

Let `S(z)` be analytic and define

`S_a(z)=exp(a S(z)) S(z)`.

If `S(z_n)=0`, then

`S_a(z_n)=0`

and

`S_a'(z_n)=S'(z_n)`.

Thus the entire root set and all first derivatives at the roots are preserved.
However,

`S_a/S=exp(aS)`

is nonconstant off shell, and at a simple root

`S_a''(z_n)-S''(z_n)=2a[S'(z_n)]^2`.

Therefore roots plus root slopes do not determine the off-shell secular
function.

This applies directly to the current operator hierarchy: the diagonal operator
uses the roots, while the cyclic/CMV weights use root slopes.  Those data alone
cannot identify the v432 complex forcing.

The missing bridge must fix the zero-free analytic ambiguity independently.
A sufficient route is an energy-independent operator colligation or Fredholm
construction whose characteristic function is proved to equal the FULL
PNT-centered arithmetic secular function with a canonically fixed zero-free
normalization.

Only after that identity is proved is it legitimate to seek a resolvent,
characteristic-function, or trace-class operator bound that controls the v432
forcing.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_CANONICAL_OFFSHELL_CHARACTERISTIC_BRIDGE_V1",
        "already_proved": {
            "roots_plus_slopes_nonuniqueness": exact_ambiguity_pass,
            "ambiguity_family": "S_a=exp(aS)S",
        },
        "required_claims": {
            "canonical_characteristic_realization": {
                "proved": False,
                "statement": (
                    "Construct an energy-independent zero-free arithmetic "
                    "colligation/Fredholm operator whose characteristic function "
                    "equals the full centered secular function, not merely a "
                    "function with the same roots."
                ),
            },
            "zero_free_normalization": {
                "proved": False,
                "statement": (
                    "Fix the nonvanishing analytic factor independently of RH, "
                    "Xi fitting, known zeros, and post-freeze spectral matching."
                ),
            },
            "operator_forcing_identity": {
                "proved": False,
                "statement": (
                    "Derive J_X^C(E) as a logarithmic cutoff increment, matrix "
                    "element, or trace observable of that canonical characteristic "
                    "function/operator."
                ),
            },
            "uniform_operator_bound": {
                "proved": False,
                "statement": (
                    "Bound that exact observable uniformly in X using the operator "
                    "structure."
                ),
            },
        },
        "forbidden_shortcuts": [
            "infer off-shell phase from roots alone",
            "infer off-shell phase from roots plus first slopes alone",
            "choose the zero-free factor by Xi or known-zero matching",
            "revive simple global Schur/Herglotz positivity after v273 failure",
            "assume bounded J_complex",
            "assume RH",
        ],
        "consequence": (
            "canonical off-shell operator realization + uniform bound => "
            "bounded v432 complex forcing; the completed v432 analytic theorem "
            "would then imply RH"
        ),
    }
    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not exact_ambiguity_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
