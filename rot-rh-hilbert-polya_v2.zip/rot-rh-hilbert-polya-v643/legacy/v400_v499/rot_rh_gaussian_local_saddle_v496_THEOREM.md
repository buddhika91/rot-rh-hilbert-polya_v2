# ROT-RH v496 — Gaussian local saddle / `O(L^-2)` off-critical pinning

For one right-half zero mode write

`lambda=a+i(gamma-E)`, `a>0`.

The Gaussian zero primitive has the scaled form

`K_G(L,E)
 =int_(ell/L)^infty
    exp(-x^2+aLx) exp(i(gamma-E)Lx) dx/x`.

Let

`A_a(L)=int_(ell/L)^infty exp(-x^2+aLx) dx/x`

and introduce the Gaussian natural detuning

`v=(gamma-E)L^2`.

Complete the square:

`-x^2+aLx
 =-(x-aL/2)^2+a^2L^2/4`.

Thus the normalized positive measure proportional to

`exp[-(x-aL/2)^2] dx/x`

has center

`x=aL/2+O(1)`

and fixed `O(1)` width.  On a compact `v`-set,

`exp[i(gamma-E)Lx]
 =exp[i v x/L]
 =exp[i a v/2] [1+O_v(1/L)]`

uniformly on the concentration bulk, while Gaussian tails are exponentially
small.  Therefore

`K_G(L,E)/A_a(L)
 =exp(i a v/2)+O_v(1/L)`.

Differentiating the compact-`v` asymptotic gives

`partial_v [K_G/A_a]
 =(ia/2) exp(iav/2)+O_v(1/L)`,

hence

`Im K_G/A_a
 =sin(av/2)+O_v(1/L)`

and

`partial_v Im(K_G/A_a)
 =(a/2)cos(av/2)+O_v(1/L)`.

For a **strictly dominant local right-half mode**, every fixed phase cell near

`a v/2=n*pi`

therefore contains an eventual unique transverse solution

`v_n(L)=2*pi*n/a+O(1/L)`,

so

`E_n(L)
 =gamma - 2*pi*n/(a L^2) + O(L^-3)`.

In particular the Gaussian off-critical lock is sharper than the compact-bump
`O(1/L)` endpoint lock:

`|E_n(L)-gamma|=O(L^-2)`.

The Gaussian amplitude itself grows like

`A_a(L)=exp(a^2L^2/4) * poly(L)`

up to a nonzero asymptotic factor, so any local mode with a strict positive
Gaussian growth-score gap dominates exponentially in `L^2`.

**Verdict:** `GAUSSIAN_STRICT_LOCAL_MODE_L2_PINNING_PASS`.

Scientific boundary: tied maximal Gaussian growth scores form a finite cluster
and require a finite-cluster theorem; this packet does not prove the global
branch-label association or regulator universality.
