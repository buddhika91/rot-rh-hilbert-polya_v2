# ROT-RH v482 — zero-density sparsity / superoscillation complexity bridge

Ingham's classical estimate is

`N(sigma,T)
 << T^[3(1-sigma)/(2-sigma)] log^5 T`.

For every fixed `sigma>1/2`,

`theta(sigma)=3(1-sigma)/(2-sigma)<1`

because

`1-theta=(2sigma-1)/(2-sigma)>0`.

If `beta_*>1/2` is a nonattained supremum, choose fixed

`sigma_0 in (1/2,beta_*)`.

All sufficiently right-edge modes satisfy `beta>=sigma_0`, so

`n_edge(T)=O(T^theta0 log^5T)=o(T)`.

Using v475's `T_active=O(sqrt L)`,

`n_active(L)
 =O(L^(theta0/2)log^5L)
 =o(sqrt L)`.

Together with v481, these are genuinely the available arithmetic mode degrees
of freedom because raw zero coefficients are only multiplicities.

**Verdict:** ZERO_DENSITY_SPARSE_NONATTAINED_MODE_REDUCTION_PASS

The remaining bridge is a harmonic complexity theorem showing that persistent
high-pass fixed-window phase locking requires at least linear-in-carrier mode
complexity (or another exponent beating `theta0`).  v482 does not prove that
harmonic lemma.
