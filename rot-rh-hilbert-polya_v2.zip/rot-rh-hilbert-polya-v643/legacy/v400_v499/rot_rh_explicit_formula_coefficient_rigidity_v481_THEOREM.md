# ROT-RH v481 — explicit-formula coefficient rigidity

The symmetrized explicit formula contains each nontrivial zero through

`-m_rho e^(rho y)/rho`.

Differentiation gives

`d/dy[-m_rho e^(rho y)/rho]
 =-m_rho e^(rho y)`.

Therefore the centered measure has zero part

`dmu_zero
 =-sum_rho m_rho e^(rho y)dy`.

Consequently the compact-bump primitive has the exact zero expansion

`Q_L^zero(E)
 =-sum_rho m_rho K_L(rho-1/2+iE)`,

where

`K_L(lambda)
 =int p(y/L)e^(lambda y)dy/y`.

There is **no free complex residue coefficient** and no surviving `1/rho`
factor.  The raw coefficients are common-sign integer multiplicities.

Classically,

`m_rho=O(log(2+|gamma_rho|))`.

Thus every exponential coefficient hierarchy needed for v477-style
superoscillation must come from the fixed zero locations through the bump
kernel itself.

**Verdict:** EXACT_EXPLICIT_FORMULA_BUMP_COEFFICIENT_RIGIDITY_PASS

The remaining theorem is precisely an arithmetic no-superoscillation theorem
for this fixed zero geometry, or a proof that the resulting exceptional lock
still lies in the v419 subquadratic primitive class.
