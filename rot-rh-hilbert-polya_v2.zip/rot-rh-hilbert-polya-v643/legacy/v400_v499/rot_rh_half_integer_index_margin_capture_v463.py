#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v463 — HALF-INTEGER INDEX-MARGIN / MULTIPLICITY CAPTURE THEOREM
=======================================================================

PURPOSE
-------
Close the abstract "non-saturation margin" in v462 inside an isolated
multiplicity-m collision chamber by using the half-integer secular labels.

Normalize the bump collision phase by

    s_p(u) = S_p(u)/pi,

where

    S_p(u)=int_0^1 p(x) sin(ux)/x dx,
    p(x)=exp(-(x/(1-x))^2).

v462 proved

    |s_p(u)-sgn(u)/2|
      <= Csat/(pi |u|),

with

    Csat = 2(1+sqrt(pi)).

Thus m*s_p has saturation plateaus +/-m/2.

LOCAL INDEX GEOMETRY
--------------------
Suppose an isolated multiplicity-m collision has canonical local counting
jump

    N_-  --->  N_- + m.

The midpoint background count is

    B_mid = N_- + m/2.

The m half-integer action labels associated with the jump are

    lambda_j = N_- + j - 1/2,     j=1,...,m.

Relative to B_mid,

    lambda_j - B_mid
      = j - (m+1)/2.

These are strictly interior to [-m/2,+m/2].  In fact

    dist(j-(m+1)/2, { -m/2, +m/2 }) >= 1/2

for every j=1,...,m.

Now assume the finite-L recombined REGULAR background on branch j has error

    |epsilon_j(L)| <= epsilon < 1/2

relative to the canonical midpoint:

    B_reg(L,E_j(L))
      = B_mid + epsilon_j(L).

The root equation becomes, up to the fixed collision orientation,

    m*s_p(u_j(L))
      = j-(m+1)/2 - epsilon_j(L),

    u_j(L)=(gamma-E_j(L))L.

Therefore the distance of the required collision value from either saturation
plateau is at least

    d = 1/2 - epsilon > 0.

If |u_j| were large, the v462 saturation theorem would instead place
m*s_p(u_j) within

    m*Csat/(pi |u_j|)

of one of those plateaus.  Hence necessarily

    |u_j(L)|
      <= m*Csat/[pi(1/2-epsilon)]
      = 2m(1+sqrt(pi))/[pi(1/2-epsilon)].

Thus every one of the m half-integer levels is captured:

    |E_j(L)-gamma|
      <= 2m(1+sqrt(pi))
         / [pi(1/2-epsilon) L].

In the exact-midpoint case epsilon=0,

    |u_j| <= 4m(1+sqrt(pi))/pi
            ~= 3.529... m.

This gives O(1/L) cutoff independence for the entire multiplicity packet
WITHOUT:
  * separate source and stiffness estimates;
  * a no-fold theorem;
  * differentiability of E_j(L);
  * a simple-zero assumption.

WHAT REMAINS
------------
The new theorem target is sharply reduced to a REGULAR BACKGROUND MIDPOINT
statement:

    B_reg(L,E_j(L))
      = N_- + m/2 + epsilon_j(L),

with eventually

    sup_j |epsilon_j(L)| < 1/2.

A stronger and natural goal is epsilon_j(L)->0.

This is the finite-part/index theorem that should now be attacked with:
  * recombined local argument-principle normalization;
  * v402 regular R7 contraction;
  * the finite G7 regular background after the singular collision is removed.

MULTIPLICITY SAFETY
-------------------
The local multiplicity-m collision is extracted from the recombined fixed point.
Do not use separately analytically continued singular G7 and R^7X pieces.

SCIENTIFIC BOUNDARY
-------------------
v463 proves the index geometry and the implication
"midpoint background error <1/2 => O(1/L) capture".
It does not prove the all-L midpoint-background estimate itself, RH, or the
Fredholm-Xi identity.

No Xi values, numerical zeta values, zeta derivatives, or known zero ordinates
are used.

Version: 2026-08-28-v463-half-integer-index-margin-capture
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any, List

from tqdm import tqdm

VERSION = "2026-08-28-v463-half-integer-index-margin-capture"


def constants(m: int, epsilon: float) -> Dict[str, Any]:
    if m < 1:
        raise ValueError("m must be >=1")
    if not (0.0 <= epsilon < 0.5):
        raise ValueError("epsilon must satisfy 0<=epsilon<1/2")

    Csat = 2.0*(1.0+math.sqrt(math.pi))
    d = 0.5-epsilon
    U = m*Csat/(math.pi*d)

    return {
        "multiplicity": m,
        "epsilon": epsilon,
        "index_margin": d,
        "Csat_exact": "2*(1+sqrt(pi))",
        "Csat_decimal": Csat,
        "capture_U": U,
        "capture_formula":
            "2*m*(1+sqrt(pi))/(pi*(1/2-epsilon))",
        "exact_midpoint_U_per_m":
            4.0*(1.0+math.sqrt(math.pi))/math.pi,
    }


def exact_index_geometry(m: int) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    minimum_margin = float("inf")

    for j in range(1, m+1):
        z = j-(m+1)/2.0
        left = abs(z + m/2.0)
        right = abs(m/2.0-z)
        margin = min(left, right)
        minimum_margin = min(minimum_margin, margin)
        rows.append({
            "j": j,
            "relative_label": z,
            "left_plateau": -m/2.0,
            "right_plateau": m/2.0,
            "distance_left": left,
            "distance_right": right,
            "minimum_plateau_distance": margin,
        })

    return {
        "rows": rows,
        "minimum_margin": minimum_margin,
        "exact_minimum_margin": "1/2",
        "pass": abs(minimum_margin-0.5) <= 1e-15,
    }


def symbolic_check() -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"available": False, "pass": False, "error": str(exc)}

    m, j = sp.symbols("m j", integer=True, positive=True)
    z = sp.simplify(j-(m+1)/2)
    dl = sp.simplify(z-(-m/2))
    dr = sp.simplify(m/2-z)

    # For 1<=j<=m:
    # dl=j-1/2 >=1/2
    # dr=m-j+1/2 >=1/2.
    return {
        "available": True,
        "relative_label": str(z),
        "distance_from_left_plateau": str(dl),
        "distance_from_right_plateau": str(dr),
        "left_margin_reason": "j>=1 => j-1/2>=1/2",
        "right_margin_reason": "j<=m => m-j+1/2>=1/2",
        "pass": bool(
            sp.simplify(dl-(j-sp.Rational(1,2))) == 0
            and sp.simplify(dr-(m-j+sp.Rational(1,2))) == 0
        ),
    }


def multiplicity_panel(max_m: int, epsilon: float, L: float) -> List[Dict[str, Any]]:
    rows = []
    for m in tqdm(range(1, max_m+1), desc="v463 multiplicity panel", unit="m", leave=False):
        c = constants(m, epsilon)
        g = exact_index_geometry(m)
        rows.append({
            "m": m,
            "epsilon": epsilon,
            "minimum_index_margin": g["minimum_margin"],
            "capture_U": c["capture_U"],
            "energy_capture_at_L": c["capture_U"]/L,
            "index_geometry_pass": g["pass"],
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    eps = payload["parameters"]["epsilon"]
    d = 0.5-eps
    per_m = 4.0*(1.0+math.sqrt(math.pi))/math.pi

    theorem.write_text(
f"""# ROT-RH v463 — half-integer index-margin / multiplicity capture theorem

## 1. Collision plateaus

For the normalized bump phase

`s_p(u)=S_p(u)/pi`,

v462 gives

`|s_p(u)-sgn(u)/2| <= 2(1+sqrt(pi))/(pi|u|)`.

Therefore a multiplicity-`m` collision has saturation plateaus

`-m/2` and `+m/2`.

## 2. Half-integer labels are uniformly interior

Let the canonical local counting jump be

`N_- -> N_-+m`.

Its midpoint is

`B_mid=N_-+m/2`.

The `m` action labels are

`lambda_j=N_-+j-1/2`, `j=1,...,m`.

Hence

`lambda_j-B_mid=j-(m+1)/2`.

The distances to the two collision plateaus are exactly

`j-1/2`

and

`m-j+1/2`.

Both are at least `1/2`.

Thus the minimum index margin is exactly

`1/2`,

independently of multiplicity.

## 3. Finite-L midpoint error

Assume the recombined regular background satisfies on the associated branch

`B_reg(L,E_j(L))=B_mid+epsilon_j(L)`

with

`|epsilon_j(L)|<=epsilon<{1/2}`.

Then the required collision phase remains at distance at least

`d=1/2-epsilon={d:.16e}`

from either saturation plateau.

Using v462,

`|u_j(L)|
 <= 2m(1+sqrt(pi))/[pi(1/2-epsilon)]`.

Therefore

`|E_j(L)-gamma|
 <= 2m(1+sqrt(pi))
    /[pi(1/2-epsilon)L]`.

Every multiplicity branch converges to the same collision ordinate.

For exact midpoint alignment `epsilon=0`,

`|u_j| <= [4(1+sqrt(pi))/pi] m
        ~= {per_m:.16e} m`.

## 4. Important logical gain

The collision-capture problem is no longer an arbitrary transversality theorem.

It has been reduced to the **midpoint-background estimate**

`sup_j |B_reg-(N_-+m/2)| < 1/2`.

A natural stronger target is

`B_reg(L,E_j(L))-(N_-+m/2) -> 0`.

If that is proved from the recombined finite-part/index structure, fixed-mode
cutoff independence follows immediately from the v462/v463 phase geometry.

No derivative of the root branch and no no-fold condition are required for
this implication.

## 5. Remaining analytic theorem

Prove the local recombined background midpoint law without known zero
ordinates:

1. isolate the multiplicity-`m` principal collision from the full recombined
   fixed point;
2. show the remaining regular phase carries the midpoint count
   `N_-+m/2`;
3. prove its finite-bump error is eventually `<1/2`, preferably `o(1)`;
4. combine with this theorem to obtain the `O(1/L)` collision packet capture.

This is still an analytic obligation; v463 does not prove RH or the exact
Fredholm identity.
""",
        encoding="utf-8",
    )

    certificate = {
        "schema": "ROT_RH_HALF_INTEGER_INDEX_MARGIN_CAPTURE_CERTIFICATE_V1",
        "already_closed": {
            "collision_plateaus": "+/-m/2 in normalized phase units",
            "relative_labels": "j-(m+1)/2, j=1,...,m",
            "exact_index_margin": "1/2",
            "finite_error_margin": "1/2-epsilon",
            "capture_bound":
                "|u_j|<=2m(1+sqrt(pi))/(pi(1/2-epsilon))",
            "energy_capture":
                "|E_j-gamma|<=2m(1+sqrt(pi))/(pi(1/2-epsilon)L)",
            "root_differentiability_required": False,
            "no_fold_required_for_capture_implication": False,
        },
        "required_claims": {
            "local_counting_jump":
                "the isolated recombined collision carries multiplicity jump N_- -> N_-+m",
            "midpoint_background":
                "B_reg=N_-+m/2+epsilon_j(L)",
            "midpoint_error":
                "sup_j |epsilon_j(L)|<1/2 eventually",
            "branch_label_association":
                "the m fixed half-integer labels are the labels carried by this local jump",
            "branch_persistence":
                "these fixed labels continue for all sufficiently large L",
        },
        "next_attack": (
            "Prove the midpoint-background law from a local argument-principle/"
            "winding-number factorization of the recombined bump characteristic, "
            "using v402 only for the regular coefficient-space R7 remainder."
        ),
        "forbidden_as_proof": [
            "separate singular G7/R7 continuation",
            "simple-zero assumption",
            "known zero ordinates",
            "finite cutoff fit used as midpoint theorem",
        ],
    }
    cert.write_text(json.dumps(certificate, indent=2), encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--multiplicity", type=int, default=1)
    ap.add_argument("--epsilon", type=float, default=0.10)
    ap.add_argument("--L", type=float, default=20.0)
    ap.add_argument("--max-panel-multiplicity", type=int, default=8)
    ap.add_argument(
        "--prefix",
        default="rot_rh_half_integer_index_margin_capture_v463",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.multiplicity < 1:
        raise ValueError("--multiplicity must be >=1")
    if not (0.0 <= args.epsilon < 0.5):
        raise ValueError("--epsilon must satisfy 0<=epsilon<1/2")
    if args.L <= 0.0:
        raise ValueError("--L must be positive")

    started = time.perf_counter()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*184)
    print("ROT-RH v463 — HALF-INTEGER INDEX-MARGIN / MULTIPLICITY CAPTURE THEOREM")
    print("="*184)
    print("Xi / numerical zeta / known zero ordinates : NONE")
    print("simple-zero assumption                     : NONE")
    print("root derivative / no-fold needed           : NO")
    print("="*184)

    with tqdm(total=4, desc="v463 index theorem", unit="step") as bar:
        c = constants(args.multiplicity, args.epsilon)
        bar.update(1)
        geometry = exact_index_geometry(args.multiplicity)
        bar.update(1)
        sym = symbolic_check()
        bar.update(1)
        panel = multiplicity_panel(
            args.max_panel_multiplicity,
            args.epsilon,
            args.L,
        )
        bar.update(1)

    passed = bool(geometry["pass"] and sym.get("pass", False))
    verdict = (
        "EXACT_HALF_INTEGER_INDEX_MARGIN_CAPTURE_THEOREM_PASS"
        if passed else
        "HALF_INTEGER_INDEX_GEOMETRY_SELF_CHECK_FAILED"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-started,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "parameters": {
            "multiplicity": args.multiplicity,
            "epsilon": args.epsilon,
            "L": args.L,
        },
        "constants": c,
        "index_geometry": geometry,
        "symbolic_check": sym,
        "multiplicity_panel": panel,
        "proof_status": (
            "Exact half-integer/multiplicity index geometry and its v462 capture "
            "implication.  The recombined regular-background midpoint estimate "
            "remains the next theorem."
        ),
    }
    write_outputs(prefix, payload)

    print()
    print("KEY RESULTS")
    print("-"*184)
    print("verdict                                :", verdict)
    print("multiplicity                           :", args.multiplicity)
    print("exact minimum index margin             :", geometry["minimum_margin"])
    print("finite-L epsilon                       :", args.epsilon)
    print("remaining phase margin                 :", c["index_margin"])
    print("capture |u| upper                      :", f"{c['capture_U']:.16e}")
    print("capture |E-gamma| upper at L           :", f"{c['capture_U']/args.L:.16e}")
    print("exact-midpoint U/m                     :", f"{c['exact_midpoint_U_per_m']:.16e}")
    print("summary                                :", str(prefix)+"_SUMMARY.json")
    print("theorem                                :", str(prefix)+"_THEOREM.md")
    print("next certificate                       :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    print("="*184)

    if args.strict and not passed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
