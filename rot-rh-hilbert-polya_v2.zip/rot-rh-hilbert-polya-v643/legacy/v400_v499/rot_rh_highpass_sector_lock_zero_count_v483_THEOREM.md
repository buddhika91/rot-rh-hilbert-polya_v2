# ROT-RH v483 — high-pass sector-lock zero-count complexity theorem

Let

`H(s)=sum_(j=1)^n c_j exp[(-delta_j+i gamma_j)s]`, `0<=s<=h`,

and assume `H(s) != 0` throughout the window.  Suppose that after one constant
rotation and a bounded carrier `nu`,

`Z(s)=exp(-i alpha) exp(i nu s) H(s)`

obeys

`|arg Z(s)| <= Theta < pi/2`

throughout the window.

Write

`omega_j=gamma_j+nu`,

`A=min_j omega_j > 0`, `C=max_j omega_j`,

`m=(A+C)/2`, `B=C-A`.

Define

`P(s)=exp(-i m s) Z(s)`.

At the sampling points

`s_k=k pi/m`,

we have

`Re P(s_k)=(-1)^k |Z(s_k)| cos(arg Z(s_k))`,

so the signs alternate because `Theta<pi/2`.  Therefore `Re P` has at least

`floor(m h/pi)`

distinct zeros in `[0,h]`.

On the other hand,

`Re P=(P+conj(P))/2`

is an exponential polynomial with at most `2n` exponential modes.  Its exponent
imaginary parts lie in `[-B/2,B/2]`; hence their total imaginary diameter is
`B`.

Berenstein--Gay's real-zero bound for exponential polynomials gives

`N_h(Re P) <= (2n-1) + B h/(2 pi)`.

Combining this with `floor(x)>=x-1` yields

`m h/pi - 1 <= 2n - 1 + B h/(2 pi)`,

therefore

`2n >= (h/pi)(m-B/2) = A h/pi`,

and hence the exact complexity bound

`n >= A h/(2 pi)`.

Thus any finite high-pass family whose minimum shifted frequency escapes to
infinity and which stays in a fixed strict half-plane sector on a fixed physical
window requires a number of modes **linear in the minimum carrier**.

**Verdict:** `FINITE_HIGHPASS_SECTOR_LOCK_LINEAR_COMPLEXITY_PASS`.

This defeats the v477 superoscillation loophole at precisely the level requested
by v482: the v477 construction works only because its number of modes grows much
faster than its carrier.

## Arithmetic corollary

If the relevant zeta modes can be reduced to a finite family with

`n(A)=o(A)`

while the minimum shifted ordinate is `A->infinity`, persistent sector lock is
impossible.

In particular, for a bounded-ratio near-edge band `[A, C A]`, Ingham's
zero-density estimate gives `n(A)=O(A^theta log^5 A)=o(A)` for every fixed
`theta<1`, contradicting the theorem.

## Remaining ROT-RH boundary

The harmonic lemma itself is closed for finite exponential polynomials.  What
is not yet automatically closed is the infinite-family reduction in an
amplitude-collapsed configuration: one must prove that the actual compact-bump
zeta sum admits an effective finite high-pass truncation preserving the sector
lock (or show that failure of such a truncation is negligible in the v419
characteristic).  A genuinely multiscale cancellation chain is therefore the
remaining frontier, not generic finite-dimensional superoscillation.

External input: C. A. Berenstein and R. Gay, *Complex Analysis and Special
Topics in Harmonic Analysis* (1995), Cor. 3.2.45; the bound is also quoted as
Lemma 2 in B. Mu et al., *Automatica* 60 (2015), 100--114.
