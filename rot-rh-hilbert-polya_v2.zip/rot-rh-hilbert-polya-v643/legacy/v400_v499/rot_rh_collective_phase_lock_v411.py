#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v411 — COLLECTIVE PHASE-LOCK / SUMMABLE ROOT-FLOW REDUCTION
==================================================================

Purpose
-------
Correct and sharpen the final nonattained cutoff-independence target after
v410.

The physical diagonal does NOT need the projected frequency moment

    Q = Re(G conjugate(H))

to vanish.

For a fixed interior ordered root, the correct requirement is that the FULL
collective phase velocity cancels the explicit tE carrier:

    E + phase_velocity + background_t = small.

This is the infinite-resonance generalization of v385's single-resonance
phase lock

    E + gamma = O(1/t).

v411 derives the exact collective lock functional and shows that its
short-window O(1/t) control is precisely the phase-transfer hypothesis needed
by v392.  With transversality ~t it gives dyadic root displacement O(1/t^2),
hence cutoff independence.

No zeta numerical values or zero ordinates are used.

----------------------------------------------------------------------
A. Secular phase
----------------------------------------------------------------------

Put t=log X and write the recombined secular phase on one fixed ordered-root
tube as

    Phi(t,E)
      = t E + psi(t,E) + b(t,E),

where

    psi(t,E)=Arg H(t,E)

is a continuous unwrapped phase of the full signed nonattained resonance
family and b contains the already-separated bounded/static channels.

A fixed ordered branch obeys

    Phi(t,E_k(t)) = C_k.

Assume H!=0 on the branch tube so the phase derivatives are defined.

----------------------------------------------------------------------
B. Physical resonance moments
----------------------------------------------------------------------

Write

    H(t,E)
      = sum_rho c_rho(E)
          exp(-delta_rho t)
          exp(i gamma_rho t),

and define

    D = sum delta_rho b_rho,
    G = sum gamma_rho b_rho,

where b_rho denotes the complete summand.

Then exactly

    H_t = -D + iG.

Hence

    psi_t
      = Im(H_t/H)
      = [-Im(D Hbar)+Re(G Hbar)]/|H|^2.

Also

    psi_E = Im(H_E/H).

----------------------------------------------------------------------
C. Collective phase-lock residual
----------------------------------------------------------------------

Define

    Lcal(t,E)
      := partial_t Phi(t,E)
       = E + b_t(t,E) + psi_t(t,E).

Equivalently,

    Lcal |H|^2
      = (E+b_t)|H|^2
        - Im(D Hbar)
        + Re(G Hbar).

This is the CORRECT collective cancellation surface.

For a single resonance

    H=c(E)e^(-delta t)e^(i gamma t),

we have

    psi_t=gamma,

so

    Lcal=E+gamma+b_t,

recovering the v385 phase-lock structure.

Thus v409's normalized first-moment cancellation is a NECESSARY consequence
of finite Lcal in the nonattained case, but Q=0 is not the target.

----------------------------------------------------------------------
D. Exact root velocity
----------------------------------------------------------------------

Differentiate the fixed phase label:

    0 = d/dt Phi(t,E_k(t))
      = Phi_t + Phi_E E_k'(t).

Therefore

    E_k'(t)
      = -Lcal(t,E_k(t)) / Tcal(t,E_k(t)),

where the transversality denominator is

    Tcal(t,E)
      := Phi_E
       = t + b_E(t,E) + Im(H_E/H).

This is exact.

If eventually

    Tcal >= c_k t,       c_k>0,

and

    |Lcal| <= C_k/t,

then

    |E_k'(t)|
      <= C_k/(c_k t^2).

Thus for a bounded logarithmic cutoff increment 0<=Delta<=log 2,

    |E_k(t+Delta)-E_k(t)|
      <= (C_k/c_k) Delta/[t(t+Delta)]
      <= (C_k log2)/(c_k t^2).

The dyadic t_n=t_0+n log2 series of 1/t_n^2 converges, so the branch is
Cauchy.

----------------------------------------------------------------------
E. Exact short-window transfer identity
----------------------------------------------------------------------

At FIXED energy E,

    Phi(t+Delta,E)-Phi(t,E)
      = integral_t^(t+Delta) Lcal(s,E) ds.

Therefore v392's required phase-transfer estimate

    |Phi(t+Delta,E)-Phi(t,E)| <= C_k/t

for 0<=Delta<=log2 is EXACTLY a short-window signed integral bound on Lcal.

A pointwise bound

    |Lcal(t,E)|<=C_k/t

is sufficient but NOT necessary.

The true minimal target is

    sup_(0<=Delta<=log2)
    | integral_t^(t+Delta) Lcal(s,E) ds |
      <= C_k/t

uniformly on the eventual fixed-k root tube.

This permits oscillatory cancellation within one dyadic shell and is therefore
strictly weaker/more realistic than pointwise first-moment noncancellation.

----------------------------------------------------------------------
F. Relation to v409-v410
----------------------------------------------------------------------

v409:
    W1/W0 -> infinity.  Finite Lcal forces normalized signed first-moment
    cancellation.

v410:
    S1/S0 -> infinity in positive Bohr mean square.  Thus the finite physical
    phase velocity is exceptional relative to the frozen-t Bohr geometry.

v411:
    identifies exactly WHAT that exceptional diagonal must accomplish:
    it must make the short-window integral of the collective lock residual
    O(1/t).

So the remaining theorem is no longer "Q cannot be zero" or "the physical
diagonal is typical."  Either of those would be stronger than needed.

----------------------------------------------------------------------
G. Final nonattained theorem target
----------------------------------------------------------------------

Prove, or disprove, uniformly on each fixed ordered-root tube:

    LOCK_TRANSFER:
      sup_(0<=Delta<=log2)
      |int_t^(t+Delta) Lcal(s,E) ds|
        <= C_k/t.

and

    TRANSVERSALITY:
      Phi_E(t,E) >= c_k t.

If both hold, v392 closes fixed-mode cutoff independence.

If LOCK_TRANSFER cannot hold under a nonattained off-critical edge, that edge
is excluded.

This is the sharp signed diagonal theorem.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 411
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 411


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_phase_velocity_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    Dr, Di, Gr, Gi, Hr, Hi = sp.symbols(
        "D_r D_i G_r G_i H_r H_i",
        real=True,
    )

    D = Dr + sp.I*Di
    G = Gr + sp.I*Gi
    H = Hr + sp.I*Hi
    Ht = -D + sp.I*G

    modulus2 = sp.simplify(
        H*sp.conjugate(H)
    )
    num1 = sp.expand_complex(
        sp.im(Ht*sp.conjugate(H))
    )
    num2 = sp.expand_complex(
        -sp.im(D*sp.conjugate(H))
        + sp.re(G*sp.conjugate(H))
    )
    residual = sp.simplify(num1-num2)

    return {
        "H_t": "-D+iG",
        "phase_velocity": "Im(H_t/H)",
        "numerator_identity": (
            "Im(H_t Hbar)"
            "=-Im(D Hbar)+Re(G Hbar)"
        ),
        "modulus_squared": str(modulus2),
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_root_velocity_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t = sp.symbols("t", positive=True, real=True)
    E = sp.Function("E")(t)
    phi = sp.Function("Phi")

    # Use an abstract Phi(t,E(t)); chain rule.
    expr = phi(t, E)
    derivative = sp.diff(expr, t)

    expected = (
        sp.Subs(
            sp.Derivative(phi(sp.Symbol("u"), sp.Symbol("v")),
                          sp.Symbol("u")),
            (sp.Symbol("u"), sp.Symbol("v")),
            (t, E),
        )
        if False
        else None
    )

    # Robust symbolic proxy:
    Lt, Te = sp.symbols("Lcal Tcal", nonzero=True)
    Eprime = sp.simplify(-Lt/Te)
    residual = sp.simplify(Te*Eprime+Lt)

    return {
        "chain_rule": "0=Phi_t+Phi_E E_k'",
        "root_velocity": "E_k'=-Lcal/Tcal",
        "algebra_residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_single_resonance_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, delta, gamma = sp.symbols(
        "t delta gamma",
        positive=True,
        real=True,
    )
    cr, ci = sp.symbols("c_r c_i", real=True)
    c = cr + sp.I*ci

    H = c*sp.exp(-delta*t)*sp.exp(sp.I*gamma*t)
    ratio = sp.simplify(sp.diff(H, t)/H)
    imag = sp.simplify(sp.im(sp.expand_complex(ratio)))

    return {
        "H_t_over_H": str(ratio),
        "phase_velocity": str(imag),
        "expected": str(gamma),
        "residual": str(sp.simplify(imag-gamma)),
        "pass": bool(sp.simplify(imag-gamma) == 0),
    }


def symbolic_window_integral_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, d = sp.symbols(
        "t Delta",
        positive=True,
        real=True,
    )
    s = sp.symbols("s", positive=True, real=True)
    C = sp.symbols("C", positive=True, real=True)

    # Pointwise |Lcal|<=C/s gives window integral <= C log(1+d/t).
    exact = sp.integrate(C/s, (s, t, t+d))
    expected = C*sp.log((t+d)/t)
    residual = sp.simplify(exact-expected)

    # elementary bound log(1+x)<=x:
    proxy = C*d/t

    return {
        "pointwise_integral": str(exact),
        "expected": str(expected),
        "residual": str(residual),
        "upper_proxy": str(proxy),
        "pass": bool(residual == 0),
    }


def symbolic_dyadic_displacement_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    t, d, C, c = sp.symbols(
        "t Delta C c",
        positive=True,
        real=True,
    )

    # Integrate C/(c s^2).
    s = sp.symbols("s", positive=True)
    exact = sp.integrate(
        C/(c*s**2),
        (s, t, t+d),
    )
    expected = sp.simplify(
        (C/c)*d/(t*(t+d))
    )
    residual = sp.simplify(exact-expected)

    return {
        "root_displacement": str(exact),
        "expected": str(expected),
        "residual": str(residual),
        "dyadic_order": "O(t^-2) for Delta<=log 2",
        "pass": bool(residual == 0),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v410-summary",
        default="rot_rh_bohr_frequency_escape_v410_SUMMARY.json",
    )
    ap.add_argument(
        "--v409-summary",
        default="rot_rh_nonattained_phase_moment_cancellation_v409_SUMMARY.json",
    )
    ap.add_argument(
        "--v405-summary",
        default="rot_rh_recombined_multiplicity_collision_v405_SUMMARY.json",
    )
    ap.add_argument(
        "--v392-summary",
        default="rot_rh_summable_dyadic_cutoff_closure_v392_SUMMARY.json",
    )
    ap.add_argument(
        "--v385-summary",
        default="rot_rh_moving_root_single_resonance_v385_SUMMARY.json",
        help="Optional historical single-resonance phase-lock packet.",
    )
    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_collective_phase_lock_v411",
    )

    args = ap.parse_args()

    print("=" * 232)
    print("ROT-RH v411 — COLLECTIVE PHASE-LOCK / SUMMABLE ROOT-FLOW REDUCTION")
    print("=" * 232)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 232)

    v410 = load_json(args.v410_summary)
    v409 = load_json(args.v409_summary)
    v405 = load_json(args.v405_summary)
    v392 = load_json(args.v392_summary)
    v385 = load_json(args.v385_summary)

    v410_ok = bool(
        v410 is not None
        and v410.get("verdict")
        == "EXACT_BOHR_MEAN_SQUARE_FREQUENCY_ESCAPE_PASS"
    )
    v409_ok = bool(
        v409 is not None
        and v409.get("verdict")
        == "EXACT_NONATTAINED_PHASE_MOMENT_CANCELLATION_NECESSITY_PASS"
    )
    v405_ok = bool(
        v405 is not None
        and v405.get("verdict")
        == "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
    )
    v392_ok = bool(
        v392 is not None
        and v392.get("verdict")
        == "SUMMABLE_DYADIC_CUTOFF_INDEPENDENCE_IMPLICATION_PASS"
    )

    print("[1] Upstream")
    print("v410 Bohr frequency escape               :", v410_ok)
    print("v409 phase-moment necessity              :", v409_ok)
    print("v405 recombined collision                :", v405_ok)
    print("v392 summable cutoff implication         :", v392_ok)
    if v385 is not None:
        print("v385 historical verdict                  :", v385.get("verdict"))
    else:
        print("v385 historical packet                   : optional / not supplied")

    print("\n[2] Exact collective phase-lock algebra")

    with tqdm(
        total=5,
        desc="collective lock identities",
        unit="identity",
    ) as bar:
        phase = symbolic_phase_velocity_check()
        bar.update(1)

        root = symbolic_root_velocity_check()
        bar.update(1)

        single = symbolic_single_resonance_check()
        bar.update(1)

        window = symbolic_window_integral_check()
        bar.update(1)

        dyadic = symbolic_dyadic_displacement_check()
        bar.update(1)

    print("resonance phase-velocity identity        :", phase.get("pass"))
    print("implicit root-velocity identity          :", root.get("pass"))
    print("single-resonance v385 reduction          :", single.get("pass"))
    print("short-window integral identity           :", window.get("pass"))
    print("dyadic displacement identity             :", dyadic.get("pass"))

    algebra_pass = bool(
        phase.get("pass")
        and root.get("pass")
        and single.get("pass")
        and window.get("pass")
        and dyadic.get("pass")
    )

    print("\n[3] Correct collective lock functional")

    definitions = [
        (
            "SECULAR_PHASE",
            "Phi(t,E)=tE+psi(t,E)+b(t,E), psi=continuous Arg H.",
        ),
        (
            "SIGNED_MOMENTS",
            "H=sum b_rho, D=sum delta_rho b_rho, G=sum gamma_rho b_rho.",
        ),
        (
            "PHASE_VELOCITY",
            "psi_t=[-Im(D Hbar)+Re(G Hbar)]/|H|^2.",
        ),
        (
            "LOCK_RESIDUAL",
            "Lcal=Phi_t=E+b_t+psi_t.",
        ),
        (
            "TRANSVERSALITY",
            "Tcal=Phi_E=t+b_E+Im(H_E/H).",
        ),
        (
            "ROOT_FLOW",
            "E_k'=-Lcal/Tcal exactly.",
        ),
    ]

    for key, value in definitions:
        print(f"{key:46s}: {value}")

    print("\n[4] Why Q=0 is NOT the target")

    correction = [
        (
            "V409_NECESSITY",
            "Finite collective phase velocity forces Q/(W1 W0)->0 because the absolute frequency scale diverges.",
        ),
        (
            "NOT_ZERO_VELOCITY",
            "A nonzero interior root needs psi_t approximately -E (up to b_t), not psi_t approximately 0.",
        ),
        (
            "SINGLE_RESONANCE_CHECK",
            "For H=c e^(-delta t)e^(i gamma t), psi_t=gamma and Lcal=E+gamma+b_t.",
        ),
        (
            "CORRECT_EXCEPTIONAL_SET",
            "The physical branch tracks the collective phase-lock surface Lcal=small, not the raw projected-moment zero set Q=0.",
        ),
    ]

    for key, value in correction:
        print(f"{key:46s}: {value}")

    print("\n[5] Exact v392 transfer equivalence")

    transfer = [
        (
            "FIXED_E_IDENTITY",
            "Phi(t+Delta,E)-Phi(t,E)=int_t^(t+Delta) Lcal(s,E) ds.",
        ),
        (
            "DYADIC_WINDOW",
            "X<=Y<=2X corresponds to 0<=Delta=log(Y/X)<=log 2.",
        ),
        (
            "MINIMAL_TRANSFER_TARGET",
            "sup_Delta |int Lcal ds| <= C_k/t is exactly the required O(1/logX) fixed-energy phase transfer.",
        ),
        (
            "POINTWISE_SUFFICIENT",
            "|Lcal|<=C_k/t is sufficient but stronger than necessary.",
        ),
    ]

    for key, value in transfer:
        print(f"{key:46s}: {value}")

    print("\n[6] Summable root-flow theorem")

    closure = [
        (
            "LOCK",
            "|Lcal(t,E)|<=C_k/t on the eventual fixed-k tube.",
        ),
        (
            "SLOPE",
            "Tcal(t,E)>=c_k t with c_k>0.",
        ),
        (
            "VELOCITY",
            "|E_k'(t)|<=C_k/(c_k t^2).",
        ),
        (
            "DOUBLING_STEP",
            "|E_k(t+Delta)-E_k(t)|<=C_k Delta/[c_k t(t+Delta)]=O(t^-2), Delta<=log2.",
        ),
        (
            "SUMMABILITY",
            "Along t_n=t_0+n log2, sum_n t_n^-2<infinity.",
        ),
        (
            "CUTOFF_INDEPENDENCE",
            "Therefore E_k(X) is Cauchy as X->infinity.",
        ),
    ]

    for key, value in closure:
        print(f"{key:46s}: {value}")

    print("\n[7] True remaining RH-strength theorem")

    remaining = [
        (
            "SIGNED_LOCK_TRANSFER",
            "Prove sup_(0<=Delta<=log2)|int_t^(t+Delta)Lcal(s,E)ds|<=C_k/t uniformly on the fixed-k tube.",
        ),
        (
            "OR_POINTWISE_LOCK",
            "Stronger sufficient route: prove |Lcal(t,E)|<=C_k/t.",
        ),
        (
            "TRANSVERSALITY",
            "Prove Tcal>=c_k t; v405's multiplicity-aware collision term supplies the correct leading slope architecture.",
        ),
        (
            "NONATTAINED_DICHOTOMY",
            "If the lock-transfer bound is incompatible with the v408-v410 migrating off-critical family, the nonattained edge is excluded.",
        ),
        (
            "PHASE_LOCK_ROUTE",
            "If it is compatible, the bound itself already supplies the summable root motion needed for cutoff independence.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:46s}: {value}")

    theorem_pass = bool(
        v410_ok
        and v409_ok
        and v405_ok
        and v392_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_PASS"
        if theorem_pass
        else
        "COLLECTIVE_PHASE_LOCK_SUMMABILITY_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_SIGNED_SHORT_WINDOW_COLLECTIVE_LOCK_TRANSFER_O1_OVER_T_AND_TRANSVERSALITY"
    )

    print("\n" + "=" * 232)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "FIXED-MODE CUTOFF INDEPENDENCE           :",
        "CONDITIONAL ONLY ON COLLECTIVE LOCK-TRANSFER + TRANSVERSALITY",
    )
    print(
        "NONATTAINED FINAL OBJECT                 :",
        "SIGNED SHORT-WINDOW PHASE-LOCK RESIDUAL, NOT RAW BOHR TYPICALITY",
    )
    print("=" * 232)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v410_ok": v410_ok,
            "v409_ok": v409_ok,
            "v405_ok": v405_ok,
            "v392_ok": v392_ok,
            "v385_verdict": (
                v385.get("verdict")
                if v385 is not None
                else None
            ),
        },
        "exact_algebra": {
            "phase_velocity": phase,
            "root_velocity": root,
            "single_resonance": single,
            "window_integral": window,
            "dyadic_displacement": dyadic,
        },
        "definitions": {
            key: value for key, value in definitions
        },
        "correction_to_raw_cancellation": {
            key: value for key, value in correction
        },
        "v392_transfer_equivalence": {
            key: value for key, value in transfer
        },
        "summable_closure": {
            key: value for key, value in closure
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact collective phase-lock/root-flow reduction. The v392 "
            "fixed-energy phase-transfer hypothesis is exactly a signed "
            "short-window integral bound on the collective lock residual. "
            "With linear-in-t transversality it gives O(t^-2) dyadic root "
            "motion and fixed-mode cutoff independence. The lock-transfer "
            "estimate itself remains the RH-strength theorem."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v411 — collective phase-lock summability theorem

Write `t=log X` and

`Phi(t,E)=tE+psi(t,E)+b(t,E)`,

with `psi=Arg H`.

For

`H=sum c_rho(E)e^(-delta_rho t)e^(i gamma_rho t)`

define

`D=sum delta_rho b_rho`,
`G=sum gamma_rho b_rho`.

Then

`H_t=-D+iG`

and

`psi_t
 =[-Im(D Hbar)+Re(G Hbar)]/|H|^2`.

Define the collective lock residual

`Lcal=Phi_t=E+b_t+psi_t`

and transversality denominator

`Tcal=Phi_E=t+b_E+Im(H_E/H)`.

For the fixed ordered branch,

`E_k'=-Lcal/Tcal`.

Thus, if

`|Lcal|<=C_k/t`

and

`Tcal>=c_k t`,

then

`|E_k'|<=C_k/(c_k t^2)`,

so root motion over every dyadic cutoff window is `O(t^-2)` and summable.

More generally, at fixed E,

`Phi(t+Delta,E)-Phi(t,E)
 =int_t^(t+Delta)Lcal(s,E)ds`.

Hence v392's `O(1/t)` phase-transfer hypothesis is exactly a short-window
signed integral bound on the collective lock residual.

This is the correct final object in the nonattained case.  The physical root
does not need `Re(G Hbar)=0`; it needs the full collective phase velocity to
lock to `-E` with the precision required by the dyadic transfer theorem.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_COLLECTIVE_PHASE_LOCK_TRANSFER_CERTIFICATE_V1",
        "required_claims": {
            "continuous_unwrapped_phase_on_fixed_tube": "RIGOROUS",
            "collective_lock_transfer": (
                "sup_Delta<=log2 |int Lcal| <= C_k/t"
            ),
            "transversality": "Tcal>=c_k t",
            "root_tube_persistence": "RIGOROUS",
            "dyadic_summability": "CLOSED_BY_V411_V392",
        },
        "collective_lock": {
            "Lcal": (
                "E+b_t+[-Im(D Hbar)+Re(G Hbar)]/|H|^2"
            ),
            "Tcal": (
                "t+b_E+Im(H_E/H)"
            ),
        },
        "already_closed": {
            "Bohr_frequency_escape": "v410",
            "L1_frequency_escape": "v409",
            "support_migration": "v408",
            "recombined_collision": "v405",
            "summability_implication": "v392",
            "recursive_weighted_four_jet": "v402",
        },
        "forbidden_as_proof": [
            "raw projected-moment zero Q=0 as the phase-lock target",
            "Bohr typicality assumed on the physical diagonal",
            "finite cutoff regression",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
