#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v427 — PRIME-PACKET BETA / SHELL-PRIMITIVE MECHANISM AUDIT
=================================================================

Purpose
-------
v426 proves the absolute nonattained Riesz low/high decomposition but shows
that absolute amplitude tails cannot control the relative logarithmic
 derivative H_L/H.  The remaining fixed-mode theorem is shell-local:

    | int_L^(L+log 2) B_k(s) ds | <= C_k,
    B_k = C0/F'_L,

plus the renormalized no-fold primitive from v425.

v427 attacks the ACTUAL zero-free prime-side quotient rather than an abstract
resonance model.  It decomposes the Mangoldt/PNT-centered generator C0 into
fixed normalized log-coordinate packets

    u = log n / log X in [0,1),

and uses the exact additive quotient identity

    C0 = sum_j C_j,
    B  = C0/F' = sum_j (C_j/F') = sum_j B_j.

Therefore the signed shell primitive decomposes exactly (up to the same RK2
quadrature already used by v424):

    Pi_shell = int B dL = sum_j int B_j dL.

At the same midpoint evaluations the script also decomposes the denominator

    F' = theta' + sum_j F'_j,

where each prime/PNT packet is constructed from the SAME normalized u-bin.
This denominator decomposition is diagnostic only; v427 never assumes that
C_j/F'_j is meaningful.

Main questions
--------------
1. Does packet reconstruction reproduce v424 C0, F', beta and Pi_shell?
2. Is the bounded shell primitive carried by a stable small set of normalized
   prime/PNT packets, or by distributed signed cancellation?
3. Is the stiffness F'/L supplied by a stable normalized packet profile?
4. Does the development packet signature survive untouched holdout shells?

Scientific firewall
-------------------
NO Xi evaluations.
NO zeta numerical values.
NO known Riemann-zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO new root solves.
NO larger cutoff than v424.
NO finite numerical PASS is accepted as a proof.

Version: 427
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 427
LOG2 = math.log(2.0)
EPS = 1.0e-300


def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def json_safe(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, Path):
        return str(x)
    raise TypeError(type(x).__name__)


def sha256_file(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists():
        return None
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def exact_smooth0_interval(E: np.ndarray, vlo: float, vhi: float) -> np.ndarray:
    """Integral exp(v/2) sin(E v) dv on [vlo,vhi]."""
    E = np.atleast_1d(np.asarray(E, float))
    if vhi <= vlo:
        return np.zeros_like(E)
    a = 0.5 + 1j * E
    z = (np.exp(a * vhi) - np.exp(a * vlo)) / a
    return np.imag(z)


def exact_pnt_prime_interval(E: np.ndarray, L: float, vlo: float, vhi: float) -> np.ndarray:
    """Re integral_(vlo)^vhi (1-v/L) exp((1/2+iE)v) dv."""
    E = np.atleast_1d(np.asarray(E, float))
    if vhi <= vlo:
        return np.zeros_like(E)
    a = 0.5 + 1j * E

    def anti(v: float) -> np.ndarray:
        return np.exp(a * v) * ((1.0 - v / L) / a + 1.0 / (L * a * a))

    return np.real(anti(vhi) - anti(vlo))


@dataclass
class PacketEval:
    cutoff: int
    L: float
    E: np.ndarray
    C_packets: np.ndarray       # (nE, bins)
    F_packets: np.ndarray       # (nE, bins)
    F_theta: np.ndarray         # (nE,)
    C_total: np.ndarray
    F_total: np.ndarray
    beta: np.ndarray
    C_reference: np.ndarray
    F_reference: np.ndarray
    beta_reference: np.ndarray
    terms: int


class PacketEvaluator:
    def __init__(
        self,
        base,
        v424,
        table,
        *,
        bins: int,
        term_chunk: int,
    ):
        self.base = base
        self.v424 = v424
        self.table = table
        self.bins = int(bins)
        self.term_chunk = int(term_chunk)
        if self.bins < 2:
            raise ValueError("packet bins must be >=2")
        if self.term_chunk < 1000:
            raise ValueError("term chunk too small")

    def eval(self, cutoff: int, energies: np.ndarray) -> PacketEval:
        cutoff = int(cutoff)
        E = np.atleast_1d(np.asarray(energies, float))
        L = math.log(float(cutoff))
        k = int(np.searchsorted(self.table.logs, L - 1.0e-14, side="left"))
        logs = self.table.logs[:k]
        genw = self.table.generator_weight[:k]

        Cprime = np.zeros((len(E), self.bins), float)
        Fprime = np.zeros((len(E), self.bins), float)

        for a0 in range(0, k, self.term_chunk):
            a1 = min(k, a0 + self.term_chunk)
            lg = logs[a0:a1]
            gw = genw[a0:a1]
            u = lg / L
            bi = np.floor(u * self.bins).astype(np.int64)
            bi = np.clip(bi, 0, self.bins - 1)

            phase = E[:, None] * lg[None, :]
            ss = np.sin(phase)
            cc = np.cos(phase)

            for ie in range(len(E)):
                Cprime[ie] += np.bincount(
                    bi,
                    weights=gw * ss[ie],
                    minlength=self.bins,
                )[: self.bins]
                Fprime[ie] += np.bincount(
                    bi,
                    weights=-gw * (1.0 - u) * cc[ie],
                    minlength=self.bins,
                )[: self.bins]

        # Exact smooth/PNT background in the same normalized bins.
        Cpack = Cprime.copy()
        Fpack = Fprime.copy()
        lo_phys = LOG2
        for j in range(self.bins):
            vlo = max(lo_phys, L * j / self.bins)
            vhi = min(L, L * (j + 1) / self.bins)
            if vhi <= vlo:
                continue
            Cpack[:, j] -= exact_smooth0_interval(E, vlo, vhi)
            Fpack[:, j] += exact_pnt_prime_interval(E, L, vlo, vhi)

        Ftheta = np.asarray(self.base.theta_prime(E), float)
        Ctot = np.sum(Cpack, axis=1)
        Ftot = Ftheta + np.sum(Fpack, axis=1)
        beta = Ctot / Ftot

        ref = self.v424.ArithmeticEvaluator(self.base, self.table).eval(cutoff, E)

        return PacketEval(
            cutoff=cutoff,
            L=L,
            E=E.copy(),
            C_packets=Cpack,
            F_packets=Fpack,
            F_theta=Ftheta,
            C_total=Ctot,
            F_total=Ftot,
            beta=beta,
            C_reference=ref.C0.copy(),
            F_reference=ref.Fp.copy(),
            beta_reference=ref.beta.copy(),
            terms=k,
        )


def relerr(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.abs(np.asarray(a) - np.asarray(b)) / np.maximum(
        1.0, np.maximum(np.abs(a), np.abs(b))
    )


def infer_development_end(shells: pd.DataFrame) -> int:
    if "set" in shells.columns and np.any(shells["set"].astype(str) == "development"):
        d = shells[shells["set"].astype(str) == "development"]
        return int(d["endpoint_cutoff"].astype(int).max())
    return int(shells["endpoint_cutoff"].astype(int).min())


def build_midpoint_jobs(track: pd.DataFrame, shells: pd.DataFrame, max_modes: int):
    """Recreate the v424 RK2 midpoint states shell-by-shell.

    v424 used Emid_guess = Eprev + .5*h*beta_prev/Lprev^2.
    We reconstruct that exact midpoint state from the stored endpoint path.
    """
    jobs = []
    shell_meta = []

    shells2 = shells.copy()
    if max_modes > 0:
        shells2 = shells2[shells2["root_index"].astype(int) <= max_modes]

    group_cols = ["anchor", "endpoint_cutoff"]
    if "shell_index" in shells2.columns:
        group_cols = ["shell_index", "anchor", "endpoint_cutoff"]

    for key, shg in shells2.groupby(group_cols, sort=True):
        shg = shg.sort_values("root_index")
        anchor = int(shg["anchor"].iloc[0])
        endpoint = int(shg["endpoint_cutoff"].iloc[0])
        label = str(shg["set"].iloc[0]) if "set" in shg.columns else str(shg.get("label", pd.Series(["unknown"])).iloc[0])
        shell_index = int(shg["shell_index"].iloc[0]) if "shell_index" in shg.columns else -1

        tg = track[(track["anchor"].astype(int) == anchor) &
                   (track["endpoint_cutoff"].astype(int) == endpoint)].copy()
        if max_modes > 0:
            tg = tg[tg["root_index"].astype(int) <= max_modes]
        steps = sorted(tg["step"].astype(int).unique())
        if not steps:
            continue
        nsteps = len(steps)
        Lgrid = np.linspace(math.log(float(anchor)), math.log(float(endpoint)), nsteps + 1)

        # one vector state per step endpoint.  IMPORTANT: v424 integrates on the
        # exact linspace L-grid; the stored integer cutoff has log(X_round), which
        # is only an evaluation coordinate.  Reuse the exact L-grid here.
        Eprev = shg["E_start"].to_numpy(float)
        Lprev = float(Lgrid[0])
        start_cutoff = anchor
        jobs.append({
            "kind": "start_eval",
            "shell_index": shell_index,
            "set": label,
            "anchor": anchor,
            "endpoint_cutoff": endpoint,
            "step": 0,
            "cutoff": start_cutoff,
            "L": Lprev,
            "E": Eprev.copy(),
        })

        for st in steps:
            eg = tg[tg["step"].astype(int) == st].sort_values("root_index")
            Eend = eg["E"].to_numpy(float)
            Lend = float(Lgrid[int(st)])
            Lmid = 0.5 * (Lprev + Lend)
            Xmid = int(round(math.exp(Lmid)))
            jobs.append({
                "kind": "midpoint",
                "shell_index": shell_index,
                "set": label,
                "anchor": anchor,
                "endpoint_cutoff": endpoint,
                "step": int(st),
                "cutoff": Xmid,
                "L": Lmid,
                "L_left": Lprev,
                "L_right": Lend,
                "h": Lend - Lprev,
                "E_left": Eprev.copy(),
                "E_end": Eend.copy(),
            })
            Eprev = Eend
            Lprev = Lend

        shell_meta.append({
            "shell_index": shell_index,
            "set": label,
            "anchor": anchor,
            "endpoint_cutoff": endpoint,
            "steps": len(steps),
        })

    return jobs, pd.DataFrame(shell_meta)


def entropy_from_abs(x: np.ndarray) -> float:
    x = np.abs(np.asarray(x, float))
    s = float(np.sum(x))
    if not np.isfinite(s) or s <= EPS:
        return float("nan")
    p = x / s
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)) / max(math.log(len(x)), EPS))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="ROT-RH v427 prime-packet beta / shell-primitive mechanism audit",
    )
    ap.add_argument("--v424-track", default="rot_rh_cesaro_mean_primitive_beta_v424_TRACK.csv")
    ap.add_argument("--v424-shells", default="rot_rh_cesaro_mean_primitive_beta_v424_SHELLS.csv")
    ap.add_argument("--v424-summary", default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json")
    ap.add_argument("--v425-summary", default="rot_rh_renormalized_stiffness_rg_v425_SUMMARY.json")
    ap.add_argument("--v426-summary", default="rot_rh_nonattained_riesz_low_high_relative_v426_SUMMARY.json")
    ap.add_argument("--v424-module", default="rot_rh_cesaro_mean_primitive_beta_v424")
    ap.add_argument("--v71-module", default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71")
    ap.add_argument("--packet-bins", type=int, default=12)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument("--max-modes", type=int, default=12)
    ap.add_argument("--maximum-reconstruction-relative", type=float, default=2e-10)
    ap.add_argument("--maximum-shell-primitive-reconstruction", type=float, default=2e-4)
    ap.add_argument("--minimum-slope-ratio", type=float, default=0.45)
    ap.add_argument("--dominant-packet-threshold", type=float, default=0.55)
    ap.add_argument("--distributed-packet-threshold", type=float, default=0.35)
    ap.add_argument("--prefix", default="rot_rh_prime_packet_beta_mechanism_v427")
    args = ap.parse_args()

    print("=" * 214)
    print("ROT-RH v427 — PRIME-PACKET BETA / SHELL-PRIMITIVE MECHANISM AUDIT")
    print("=" * 214)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff than v424                   : NONE")
    print("finite mechanism audit accepted as proof  : NO")
    print("packet coordinate                         : u=log(n)/log(X)")
    print("packet bins                               :", args.packet_bins)
    print("=" * 214)

    v424s = load_json(args.v424_summary)
    v425s = load_json(args.v425_summary)
    v426s = load_json(args.v426_summary)
    print("[1] Upstream")
    print("v424 available/pass                       :", v424s is not None, None if v424s is None else v424s.get("verdict"))
    print("v425 available/pass                       :", v425s is not None, None if v425s is None else v425s.get("verdict"))
    print("v426 available/pass                       :", v426s is not None, None if v426s is None else v426s.get("verdict"))

    track = pd.read_csv(args.v424_track)
    shells = pd.read_csv(args.v424_shells)
    if track.empty or shells.empty:
        raise RuntimeError("v424 track/shell files are empty")

    if args.max_modes > 0:
        track = track[track["root_index"].astype(int) <= args.max_modes].copy()
        shells = shells[shells["root_index"].astype(int) <= args.max_modes].copy()

    max_cutoff = int(max(track["cutoff"].astype(int).max(), shells["endpoint_cutoff"].astype(int).max()))
    dev_end = infer_development_end(shells)
    print("maximum reused cutoff                     :", f"{max_cutoff:,}")
    print("development endpoint                     :", f"{dev_end:,}")
    print("modes                                      :", int(shells["root_index"].nunique()))

    v424 = importlib.import_module(args.v424_module)
    base = importlib.import_module(args.v71_module)

    print("\n[2] Cached arithmetic table")
    t0 = time.perf_counter()
    primes = base.sieve_primes(max_cutoff)
    table = v424.build_cached_prime_powers(base, primes, max_cutoff)
    peval = PacketEvaluator(base, v424, table, bins=args.packet_bins, term_chunk=args.term_chunk)
    print("primes <= max cutoff                      :", f"{len(primes):,}")
    print("cached prime-power terms                  :", f"{len(table.logs):,}")
    print("cache build seconds                       :", f"{time.perf_counter()-t0:.3f}")

    jobs, shell_meta = build_midpoint_jobs(track, shells, args.max_modes)
    midpoint_jobs = [j for j in jobs if j["kind"] == "midpoint"]
    start_jobs = [j for j in jobs if j["kind"] == "start_eval"]
    print("RK midpoint vector evaluations            :", len(midpoint_jobs))
    print("shell start vector evaluations            :", len(start_jobs))

    # Cache start evaluations so midpoint states can be reconstructed exactly.
    start_cache: Dict[Tuple[int, int], PacketEval] = {}
    point_rows: List[dict] = []
    packet_rows: List[dict] = []

    print("\n[3] Exact packet reconstruction")
    with tqdm(total=len(start_jobs) + len(midpoint_jobs), desc="prime packet vectors", unit="vector") as bar:
        for sj in start_jobs:
            ev = peval.eval(sj["cutoff"], sj["E"])
            start_cache[(sj["shell_index"], sj["anchor"])] = ev
            bar.update(1)

        # state beta at the left edge is needed to recreate v424 Emid_guess
        left_beta_cache: Dict[Tuple[int, int], Tuple[np.ndarray, float]] = {}
        for sj in start_jobs:
            ev = start_cache[(sj["shell_index"], sj["anchor"])]
            left_beta_cache[(sj["shell_index"], 0)] = (ev.beta.copy(), sj["L"])

        # Track prior endpoint beta from the stored v424 track (already exact).
        track_key = {}
        for _, r in track.iterrows():
            track_key[(int(r["anchor"]), int(r["endpoint_cutoff"]), int(r["step"]), int(r["root_index"]))] = float(r["beta"])

        shell_packet_accum: Dict[Tuple[int, int], np.ndarray] = {}
        shell_abs_accum: Dict[Tuple[int, int], np.ndarray] = {}
        shell_den_accum: Dict[Tuple[int, int], np.ndarray] = {}
        shell_den_theta: Dict[Tuple[int, int], float] = {}
        shell_hsum: Dict[Tuple[int, int], float] = {}

        for job in midpoint_jobs:
            shell_index = int(job["shell_index"])
            anchor = int(job["anchor"])
            endpoint = int(job["endpoint_cutoff"])
            step = int(job["step"])
            La = float(job["L_left"])
            Lm = float(job["L"])
            h = float(job["h"])
            Eleft = np.asarray(job["E_left"], float)

            # Exact v424 midpoint guess uses beta at the left endpoint.
            if step == 1:
                start_ev = start_cache[(shell_index, anchor)]
                beta_left = start_ev.beta
            else:
                beta_left = np.array([
                    track_key[(anchor, endpoint, step - 1, j + 1)]
                    for j in range(len(Eleft))
                ], float)
            Emid = Eleft + 0.5 * h * beta_left / (La * La)
            ev = peval.eval(job["cutoff"], Emid)

            c_rel = relerr(ev.C_total, ev.C_reference)
            f_rel = relerr(ev.F_total, ev.F_reference)
            b_rel = relerr(ev.beta, ev.beta_reference)

            for im in range(len(Emid)):
                rk = im + 1
                F = float(ev.F_total[im])
                C = float(ev.C_total[im])
                B = float(ev.beta[im])
                cp = ev.C_packets[im]
                fp = ev.F_packets[im]
                beta_packets = cp / F
                beta_packet_abs = np.abs(beta_packets)
                den_components = np.concatenate(([ev.F_theta[im]], fp))
                den_abs = np.abs(den_components)
                den_abs_sum = max(float(np.sum(den_abs)), EPS)
                beta_abs_sum = max(float(np.sum(beta_packet_abs)), EPS)

                point_rows.append({
                    "set": job["set"],
                    "shell_index": shell_index,
                    "anchor": anchor,
                    "endpoint_cutoff": endpoint,
                    "step": step,
                    "cutoff": int(job["cutoff"]),
                    "L": Lm,
                    "root_index": rk,
                    "E_mid": float(Emid[im]),
                    "C0": C,
                    "Fp": F,
                    "slope_over_L": F / Lm,
                    "beta": B,
                    "C_reconstruction_relative": float(c_rel[im]),
                    "Fp_reconstruction_relative": float(f_rel[im]),
                    "beta_reconstruction_relative": float(b_rel[im]),
                    "beta_packet_top_abs_share": float(np.max(beta_packet_abs) / beta_abs_sum),
                    "beta_packet_entropy": entropy_from_abs(beta_packets),
                    "denominator_top_abs_share": float(np.max(den_abs) / den_abs_sum),
                    "denominator_entropy": entropy_from_abs(den_components),
                    "theta_denominator_abs_share": float(abs(ev.F_theta[im]) / den_abs_sum),
                    "terms": int(ev.terms),
                })

                key = (shell_index, rk)
                shell_packet_accum.setdefault(key, np.zeros(args.packet_bins, float))
                shell_abs_accum.setdefault(key, np.zeros(args.packet_bins, float))
                shell_den_accum.setdefault(key, np.zeros(args.packet_bins, float))
                shell_den_theta.setdefault(key, 0.0)
                shell_hsum.setdefault(key, 0.0)
                shell_packet_accum[key] += h * beta_packets
                shell_abs_accum[key] += h * np.abs(beta_packets)
                shell_den_accum[key] += h * fp / Lm
                shell_den_theta[key] += h * float(ev.F_theta[im]) / Lm
                shell_hsum[key] += h

                for j in range(args.packet_bins):
                    packet_rows.append({
                        "set": job["set"],
                        "shell_index": shell_index,
                        "anchor": anchor,
                        "endpoint_cutoff": endpoint,
                        "step": step,
                        "cutoff": int(job["cutoff"]),
                        "L": Lm,
                        "root_index": rk,
                        "packet": j,
                        "u_lo": j / args.packet_bins,
                        "u_hi": (j + 1) / args.packet_bins,
                        "C_packet": float(cp[j]),
                        "Fp_packet": float(fp[j]),
                        "beta_packet": float(beta_packets[j]),
                        "beta_packet_abs_share": float(beta_packet_abs[j] / beta_abs_sum),
                        "denominator_packet_abs_share": float(abs(fp[j]) / den_abs_sum),
                    })
            bar.update(1)

    points = pd.DataFrame(point_rows)
    packets = pd.DataFrame(packet_rows)

    max_c_rec = float(points["C_reconstruction_relative"].max())
    max_f_rec = float(points["Fp_reconstruction_relative"].max())
    max_b_rec = float(points["beta_reconstruction_relative"].max())
    reconstruction_pass = bool(max(max_c_rec, max_f_rec, max_b_rec) <= args.maximum_reconstruction_relative)
    print("maximum C0 reconstruction relative       :", f"{max_c_rec:.12e}")
    print("maximum F' reconstruction relative       :", f"{max_f_rec:.12e}")
    print("maximum beta reconstruction relative     :", f"{max_b_rec:.12e}")
    print("exact packet reconstruction pass         :", reconstruction_pass)

    # ------------------------------------------------------------------
    # Shell packet attribution.
    # ------------------------------------------------------------------
    print("\n[4] Exact additive shell-primitive attribution")
    shell_rows = []
    attr_rows = []
    shells_keyed = shells.set_index(["shell_index", "root_index"]) if "shell_index" in shells.columns else None

    for (si, rk), pi_vec in sorted(shell_packet_accum.items()):
        hsum = shell_hsum[(si, rk)]
        abs_vec = shell_abs_accum[(si, rk)]
        den_vec = shell_den_accum[(si, rk)] / max(hsum, EPS)
        den_theta = shell_den_theta[(si, rk)] / max(hsum, EPS)
        total_pi = float(np.sum(pi_vec))
        abs_pi_sum = max(float(np.sum(np.abs(pi_vec))), EPS)
        top = int(np.argmax(np.abs(pi_vec)))

        if shells_keyed is not None and (si, rk) in shells_keyed.index:
            rr = shells_keyed.loc[(si, rk)]
            if isinstance(rr, pd.DataFrame):
                rr = rr.iloc[0]
            target_pi = float(rr["primitive_beta_shell"])
            label = str(rr["set"]) if "set" in rr.index else str(rr.get("label", "unknown"))
            anchor = int(rr["anchor"])
            endpoint = int(rr["endpoint_cutoff"])
        else:
            target_pi = float("nan")
            sm = shell_meta[shell_meta["shell_index"].astype(int) == si].iloc[0]
            label = str(sm["set"])
            anchor = int(sm["anchor"])
            endpoint = int(sm["endpoint_cutoff"])

        shell_resid = total_pi - target_pi if np.isfinite(target_pi) else float("nan")
        shell_rows.append({
            "set": label,
            "shell_index": si,
            "anchor": anchor,
            "endpoint_cutoff": endpoint,
            "root_index": rk,
            "packet_primitive_sum": total_pi,
            "v424_primitive_beta_shell": target_pi,
            "primitive_reconstruction_residual": shell_resid,
            "top_primitive_packet": top,
            "top_primitive_packet_u_mid": (top + 0.5) / args.packet_bins,
            "top_primitive_abs_share": float(abs(pi_vec[top]) / abs_pi_sum),
            "primitive_packet_entropy": entropy_from_abs(pi_vec),
            "signed_packet_cancellation_ratio": float(abs(total_pi) / abs_pi_sum),
            "theta_mean_Fp_over_L": den_theta,
            "packet_mean_Fp_over_L_sum": float(np.sum(den_vec)),
        })

        for j in range(args.packet_bins):
            attr_rows.append({
                "set": label,
                "shell_index": si,
                "anchor": anchor,
                "endpoint_cutoff": endpoint,
                "root_index": rk,
                "packet": j,
                "u_lo": j / args.packet_bins,
                "u_hi": (j + 1) / args.packet_bins,
                "u_mid": (j + 0.5) / args.packet_bins,
                "primitive_beta_packet": float(pi_vec[j]),
                "absolute_beta_packet_mass": float(abs_vec[j]),
                "primitive_abs_share": float(abs(pi_vec[j]) / abs_pi_sum),
                "mean_Fp_packet_over_L": float(den_vec[j]),
            })

    shell_attr = pd.DataFrame(shell_rows)
    attribution = pd.DataFrame(attr_rows)
    max_shell_rec = float(np.nanmax(np.abs(shell_attr["primitive_reconstruction_residual"].to_numpy(float))))
    shell_reconstruction_pass = bool(max_shell_rec <= args.maximum_shell_primitive_reconstruction)
    print("maximum shell primitive reconstruction   :", f"{max_shell_rec:.12e}")
    print("shell primitive reconstruction pass      :", shell_reconstruction_pass)

    # Development -> holdout packet stability summaries.
    dev_attr = attribution[attribution["set"].astype(str) == "development"].copy()
    hold_attr = attribution[attribution["set"].astype(str) == "holdout"].copy()

    def packet_summary(df: pd.DataFrame, label: str) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame()
        g = df.groupby("packet", as_index=False).agg(
            primitive_abs_share_mean=("primitive_abs_share", "mean"),
            primitive_abs_share_max=("primitive_abs_share", "max"),
            primitive_beta_packet_mean=("primitive_beta_packet", "mean"),
            primitive_beta_packet_abs_mean=("primitive_beta_packet", lambda x: float(np.mean(np.abs(x)))),
            mean_Fp_packet_over_L_mean=("mean_Fp_packet_over_L", "mean"),
            mean_Fp_packet_over_L_abs_mean=("mean_Fp_packet_over_L", lambda x: float(np.mean(np.abs(x)))),
        )
        g["set"] = label
        g["u_mid"] = (g["packet"].astype(float) + 0.5) / args.packet_bins
        return g

    ps_dev = packet_summary(dev_attr, "development")
    ps_hold = packet_summary(hold_attr, "holdout")
    packet_summary_df = pd.concat([ps_dev, ps_hold], ignore_index=True)

    # Mechanism diagnosis based on the exact shell attribution.
    mean_top_dev = float(shell_attr[shell_attr["set"] == "development"]["top_primitive_abs_share"].mean()) if np.any(shell_attr["set"] == "development") else float("nan")
    mean_top_hold = float(shell_attr[shell_attr["set"] == "holdout"]["top_primitive_abs_share"].mean()) if np.any(shell_attr["set"] == "holdout") else float("nan")
    med_entropy_hold = float(shell_attr[shell_attr["set"] == "holdout"]["primitive_packet_entropy"].median()) if np.any(shell_attr["set"] == "holdout") else float("nan")

    top_dev_packets = shell_attr[shell_attr["set"] == "development"]["top_primitive_packet"].astype(int).tolist()
    top_hold_packets = shell_attr[shell_attr["set"] == "holdout"]["top_primitive_packet"].astype(int).tolist()
    mode_dev = max(set(top_dev_packets), key=top_dev_packets.count) if top_dev_packets else None
    mode_hold = max(set(top_hold_packets), key=top_hold_packets.count) if top_hold_packets else None
    top_packet_stable = bool(mode_dev is not None and mode_hold is not None and mode_dev == mode_hold)

    if np.isfinite(mean_top_hold) and mean_top_hold >= args.dominant_packet_threshold and top_packet_stable:
        mechanism = "STABLE_DOMINANT_NORMALIZED_PACKET"
        next_theorem = "PROVE_DOMINANT_PACKET_RELATIVE_BOUND_AND_CONTROL_REMAINDER"
    elif np.isfinite(mean_top_hold) and mean_top_hold <= args.distributed_packet_threshold:
        mechanism = "DISTRIBUTED_SIGNED_PACKET_CANCELLATION"
        next_theorem = "PROVE_PACKETWISE_SUMMATION_BY_PARTS_SHELL_CANCELLATION"
    else:
        mechanism = "MIXED_PACKET_QUOTIENT_MECHANISM"
        next_theorem = "PROVE_FINITE_HEAD_PLUS_DISTRIBUTED_TAIL_SHELL_PRIMITIVE_BOUND"

    min_slope = float(points["slope_over_L"].min())
    nofold_numeric = bool(min_slope >= args.minimum_slope_ratio)

    print("\n[5] Mechanism diagnosis")
    print("mean top primitive abs share development :", f"{mean_top_dev:.6f}")
    print("mean top primitive abs share holdout     :", f"{mean_top_hold:.6f}")
    print("median holdout packet entropy            :", f"{med_entropy_hold:.6f}")
    print("modal top packet development / holdout   :", mode_dev, "/", mode_hold)
    print("modal top packet stable                  :", top_packet_stable)
    print("minimum F'/L on midpoint audit           :", f"{min_slope:.12e}")
    print("numerical no-fold diagnostic             :", nofold_numeric)
    print("MECHANISM                                 :", mechanism)
    print("NEXT ANALYTIC TARGET                      :", next_theorem)

    # Strongest packet table for user-visible diagnosis.
    if not ps_hold.empty:
        strongest = ps_hold.sort_values("primitive_abs_share_mean", ascending=False).head(min(8, args.packet_bins))
        print("\nHoldout packets ranked by mean |primitive contribution| share:")
        cols = ["packet", "u_mid", "primitive_abs_share_mean", "primitive_beta_packet_mean", "mean_Fp_packet_over_L_mean"]
        print(strongest[cols].to_string(index=False, float_format=lambda x: f"{x:.9e}"))

    # The v427 verdict is deliberately a mechanism result, never proof closure.
    if reconstruction_pass and shell_reconstruction_pass and nofold_numeric:
        verdict = f"PRIME_PACKET_BETA_MECHANISM_RESOLVED_{mechanism}"
    else:
        verdict = "PRIME_PACKET_BETA_MECHANISM_AUDIT_FAILED_NUMERICAL_SELF_CONSISTENCY"

    print("\n" + "=" * 214)
    print("VERDICT                                   :", verdict)
    print("FIXED-MODE CUTOFF REMOVAL                 : NOT PROVED BY V427")
    print("NEXT THEOREM                              :", next_theorem)
    print("=" * 214)

    prefix = Path(args.prefix)
    points_path = Path(str(prefix) + "_MIDPOINTS.csv.gz")
    packets_path = Path(str(prefix) + "_PACKET_POINTS.csv.gz")
    shell_path = Path(str(prefix) + "_SHELL_ATTRIBUTION.csv")
    attr_path = Path(str(prefix) + "_SHELL_PACKET_ATTRIBUTION.csv")
    ps_path = Path(str(prefix) + "_PACKET_SUMMARY.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    points.to_csv(points_path, index=False, compression="gzip")
    packets.to_csv(packets_path, index=False, compression="gzip")
    shell_attr.to_csv(shell_path, index=False)
    attribution.to_csv(attr_path, index=False)
    packet_summary_df.to_csv(ps_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "new_root_solves": False,
            "larger_cutoff_than_v424": False,
            "finite_scan_accepted_as_proof": False,
        },
        "inputs": {
            "v424_track": args.v424_track,
            "v424_shells": args.v424_shells,
            "v424_summary": args.v424_summary,
            "v425_summary": args.v425_summary,
            "v426_summary": args.v426_summary,
            "packet_bins": args.packet_bins,
            "term_chunk": args.term_chunk,
            "max_modes": args.max_modes,
            "maximum_reused_cutoff": max_cutoff,
            "development_endpoint": dev_end,
        },
        "reconstruction": {
            "maximum_C0_relative": max_c_rec,
            "maximum_Fp_relative": max_f_rec,
            "maximum_beta_relative": max_b_rec,
            "point_reconstruction_pass": reconstruction_pass,
            "maximum_shell_primitive_residual": max_shell_rec,
            "shell_primitive_reconstruction_pass": shell_reconstruction_pass,
        },
        "mechanism": {
            "mean_top_primitive_abs_share_development": mean_top_dev,
            "mean_top_primitive_abs_share_holdout": mean_top_hold,
            "median_holdout_packet_entropy": med_entropy_hold,
            "modal_top_packet_development": mode_dev,
            "modal_top_packet_holdout": mode_hold,
            "modal_top_packet_stable": top_packet_stable,
            "classification": mechanism,
        },
        "nofold_diagnostic": {
            "minimum_Fp_over_L": min_slope,
            "pass": nofold_numeric,
        },
        "exact_identity": "B=sum_j C_j/Fp, hence Pi_shell=sum_j int C_j/Fp dL",
        "proof_status": (
            "Zero-free arithmetic mechanism/falsification audit only. v427 identifies how the observed "
            "bounded shell primitive is distributed across normalized Mangoldt/PNT packets. It does not "
            "convert the observed packet structure into an all-L theorem."
        ),
        "verdict": verdict,
        "next_theorem": next_theorem,
        "runtime_seconds": time.perf_counter() - t0,
    }
    summary_path.write_text(json.dumps(summary, indent=2, default=json_safe), encoding="utf-8")

    theorem = "# ROT-RH v427 — prime-packet beta mechanism theorem/audit\n\n"
    theorem += "The exact zero-free numerator decomposition is `C0=sum_j C_j`, with packets fixed in the normalized coordinate `u=log(n)/log(X)`.\n\n"
    theorem += "Because the denominator is common, `B=C0/F'=sum_j C_j/F'` exactly. Therefore the shell primitive has the exact additive attribution `Pi_shell=sum_j int C_j/F' dL`.\n\n"
    theorem += f"Numerical mechanism classification: **{mechanism}**.\n\n"
    theorem += f"Maximum C0/F'/beta reconstruction relative error: `{max(max_c_rec,max_f_rec,max_b_rec):.6e}`.\n\n"
    theorem += f"Maximum shell primitive reconstruction residual: `{max_shell_rec:.6e}`.\n\n"
    theorem += f"Minimum midpoint `F'/L`: `{min_slope:.12f}`.\n\n"
    theorem += "This is not a proof of fixed-mode cutoff removal. The next analytic theorem must prove the shell-local signed bound using the mechanism identified here.\n"
    theorem_path.write_text(theorem, encoding="utf-8")

    print("Files written:")
    for p in [points_path, packets_path, shell_path, attr_path, ps_path, summary_path, theorem_path]:
        print(" ", p)


if __name__ == "__main__":
    main()
