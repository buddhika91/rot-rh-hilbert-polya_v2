#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v479 — RELATIVE SADDLE JACOBIAN / TWO-MODE TRANSFER EXCLUSION
===================================================================

PURPOSE
-------
Analyze the joint (L,E) geometry of a pair of high-ordinate bump saddle modes.

For
    lambda_j = a_j + i(Gamma_j-E),
    z_j = L lambda_j,

v473 gives the logarithmic saddle phase
    Psi(z)
      = z
        - c2 z^(2/3)
        + c1 z^(1/3)
        - 2/3
        -(2/3)log z
        + O(z^(-1/3)),
where
    c2=3*2^(-2/3),
    c1=2^(2/3).

Let
    R_12(L,E)=log K_1-log K_2,
    DeltaPhi=Im R_12.

A. Universal carrier cancellation
----------------------------------
Since
    z_1-z_2
      = L[(a_1-a_2)+i(Gamma_1-Gamma_2)],
the leading -E carrier cancels EXACTLY from the relative phase.

Thus
    partial_E DeltaPhi
does NOT have an O(L) leading term.

The first surviving term comes from z^(2/3):
    partial_E R_12
      = i 2^(1/3)L^(2/3)
          [lambda_1^(-1/3)-lambda_2^(-1/3)]
        + O(L^(1/3)|lambda|^(-2/3)|Delta lambda|).

B. Comparable high-ordinate pair
---------------------------------
Assume
    Gamma_1,Gamma_2 ~ Gamma -> infinity,
    |lambda_1-lambda_2|=o(Gamma),
    DeltaGamma=Gamma_1-Gamma_2 !=0,
and
    Delta a = a_1-a_2 = o(DeltaGamma).

Then
    lambda_1^(-1/3)-lambda_2^(-1/3)
      = -(1/3)(iGamma)^(-4/3)
          i DeltaGamma [1+o(1)].

Therefore
    partial_E DeltaPhi
      = -[2^(1/3)sqrt(3)/6]
          L^(2/3) DeltaGamma Gamma^(-4/3)
          [1+o(1)].

At fixed E,
    partial_L DeltaPhi
      = DeltaGamma[1+o(1)].

Hence every regular constant-relative-phase contour
    DeltaPhi(L,E)=constant
has velocity
    dE/dL
      = -partial_L DeltaPhi / partial_E DeltaPhi

and therefore

    dE/dL
      = [2sqrt(3)/2^(1/3)]
          Gamma^(4/3)L^(-2/3)
          [1+o(1)].

In magnitude,
    |dE/dL|
      asymp Gamma^(4/3)L^(-2/3).

C. Comparison with a convergent cutoff branch
---------------------------------------------
A sharp cutoff-independent branch has
    E_k'(L)=O(L^-2)
under the v419/v470 primitive-beta O(L) class.

For every Gamma(L)->infinity,

    [Gamma^(4/3)L^(-2/3)] / L^-2
      = (Gamma L)^(4/3)
      -> infinity.

Thus a branch with E_k'=O(L^-2) cannot coincide on any late interval with a
regular two-mode relative-phase contour of the above type.

Consequently:
  * isolated single-mode locking is already incompatible with bounded E when
    Gamma->infinity (v388/v473);
  * a comparable isolated TWO-MODE handoff cannot sustain the v411 window lock
    of a convergent branch either;
  * any surviving nonattained phase lock must involve genuinely many-mode
    cancellation in which the pairwise saddle Jacobians cancel collectively.

D. Important limitation
------------------------
This theorem does NOT exclude isolated crossing points.  The simultaneous
two-mode amplitude and phase cancellation equations generically define isolated
(L,E) points, and a root path may pass near such a point.

What is excluded is a late INTERVAL of pair-controlled phase transport capable
of supplying v411 LOCK_TRANSFER.

Nor does this theorem exclude many-mode superoscillation.  v477 explicitly
shows that generic many-mode coefficients can cancel the entire relative
Jacobian.

Therefore the final open sector is now:
    GENUINELY MANY-MODE / SUPEROSCILLATORY ARITHMETIC CANCELLATION.

No Xi values, numerical zeta values, known zero ordinates, RH, or simple-zero
assumption are used.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v479-relative-saddle-jacobian"

C2 = 3.0*2.0**(-2.0/3.0)
C1 = 2.0**(2.0/3.0)
A = 2.0**(1.0/3.0)
PAIR_SPEED_CONSTANT = 2.0*math.sqrt(3.0)/2.0**(1.0/3.0)


def symbolic_constants() -> Dict[str, Any]:
    import sympy as sp
    q = 2**sp.Rational(1, 3)
    const_E = sp.simplify(q*sp.sqrt(3)/6)
    speed = sp.simplify(1/const_E)
    target = sp.simplify(2*sp.sqrt(3)/q)
    return {
        "E_jacobian_constant": str(const_E),
        "speed_constant": str(speed),
        "speed_target": str(target),
        "speed_residual": str(sp.simplify(speed-target)),
        "pass": bool(sp.simplify(speed-target) == 0),
    }


def psi_prime(z: complex) -> complex:
    return (
        1.0
        - A*z**(-1.0/3.0)
        + (C1/3.0)*z**(-2.0/3.0)
        - (2.0/3.0)/z
    )


def relative_derivatives(
    L: float,
    E: float,
    a: float,
    Gamma: float,
    dGamma: float,
):
    g1 = Gamma + 0.5*dGamma
    g2 = Gamma - 0.5*dGamma
    lam1 = complex(a, g1-E)
    lam2 = complex(a, g2-E)
    z1 = L*lam1
    z2 = L*lam2

    # d_E Psi(L lambda) = -i L Psi'
    dE_R = -1j*L*(psi_prime(z1)-psi_prime(z2))
    # d_L Psi(L lambda) = lambda Psi'
    dL_R = lam1*psi_prime(z1)-lam2*psi_prime(z2)

    dE_phase = dE_R.imag
    dL_phase = dL_R.imag
    speed = -dL_phase/dE_phase

    predicted_E = (
        -A*math.sqrt(3.0)/6.0
        * L**(2.0/3.0)
        * dGamma
        * Gamma**(-4.0/3.0)
    )
    predicted_speed = (
        PAIR_SPEED_CONSTANT
        * Gamma**(4.0/3.0)
        * L**(-2.0/3.0)
    )
    return {
        "L": L,
        "Gamma": Gamma,
        "dGamma": dGamma,
        "dE_phase": dE_phase,
        "dE_phase_prediction": predicted_E,
        "dE_ratio": dE_phase/predicted_E,
        "dL_phase": dL_phase,
        "dL_ratio": dL_phase/dGamma,
        "phase_contour_speed": speed,
        "speed_prediction": predicted_speed,
        "speed_ratio": speed/predicted_speed,
        "speed_over_Lminus2": abs(speed)*L**2,
    }


def panel():
    rows = []
    for L, G in [
        (1e3, 50.0),
        (1e4, 100.0),
        (1e5, 250.0),
        (1e6, 500.0),
    ]:
        rows.append(relative_derivatives(L, 20.0, 0.20, G, 1.0))
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v479 — relative saddle Jacobian / two-mode transfer exclusion

For two high-ordinate bump saddle modes,

`lambda_j=a_j+i(Gamma_j-E)`.

The leading saddle term `L lambda_j` has relative difference

`L[(a_1-a_2)+i(Gamma_1-Gamma_2)]`;

therefore the universal `-EL` carrier cancels exactly.

For a comparable pair at common large ordinate `Gamma`,

`partial_E DeltaPhi
 =-[2^(1/3)sqrt(3)/6]
   L^(2/3) DeltaGamma Gamma^(-4/3)[1+o(1)]`

while

`partial_L DeltaPhi
 =DeltaGamma[1+o(1)]`.

Hence a regular relative-phase contour has

`dE/dL
 =[2sqrt(3)/2^(1/3)]
  Gamma^(4/3)L^(-2/3)[1+o(1)]`.

This dominates `L^-2` by

`(Gamma L)^(4/3)->infinity`.

So an `O(L^-2)` convergent cutoff branch cannot be transported over a late
interval by one comparable two-mode handoff.

**Verdict:** {payload['verdict']}

This does not exclude isolated two-mode crossing points and does not exclude
many-mode superoscillatory cancellation.  It removes pair-controlled window
transport from the final nonattained sector.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_RELATIVE_SADDLE_JACOBIAN_V1",
        "closed": {
            "carrier": "leading -EL term cancels exactly in relative mode phase",
            "relative_E_jacobian":
                "-2^(1/3)sqrt(3)/6 L^(2/3) DeltaGamma Gamma^(-4/3)",
            "relative_L_jacobian": "DeltaGamma[1+o(1)]",
            "pair_contour_speed":
                "2sqrt(3)/2^(1/3) Gamma^(4/3)L^(-2/3)[1+o(1)]",
            "velocity_mismatch":
                "pair contour speed / L^-2 = (Gamma L)^(4/3) times constant -> infinity",
        },
        "excluded":
            "late interval controlled by an isolated comparable two-mode transfer",
        "remaining":
            "genuinely many-mode collective/superoscillatory arithmetic cancellation",
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", default="rot_rh_relative_saddle_jacobian_v479")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*194)
    print("ROT-RH v479 — RELATIVE SADDLE JACOBIAN / TWO-MODE TRANSFER EXCLUSION")
    print("="*194)
    with tqdm(total=2, desc="v479 theorem", unit="step") as bar:
        sym = symbolic_constants()
        bar.update(1)
        rows = panel()
        bar.update(1)

    diag = abs(rows[-1]["speed_ratio"]-1.0) < 0.20
    passed = bool(sym["pass"] and diag)
    verdict = (
        "RELATIVE_SADDLE_TWO_MODE_TRANSFER_EXCLUSION_PASS"
        if passed else
        "RELATIVE_SADDLE_TWO_MODE_ASYMPTOTIC_CHECK_INCOMPLETE"
    )

    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic_panel": rows,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "diagnostic_used_as_proof": False,
        },
        "proof_status":
            "Asymptotic consequence of the v473 saddle expansion for a comparable isolated pair. Many-mode cancellation remains open.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("constant algebra                :", sym["pass"])
    print("last dE ratio                   :", f"{rows[-1]['dE_ratio']:.8f}")
    print("last dL ratio                   :", f"{rows[-1]['dL_ratio']:.8f}")
    print("last speed ratio                :", f"{rows[-1]['speed_ratio']:.8f}")
    print("last speed / L^-2               :", f"{rows[-1]['speed_over_Lminus2']:.8e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
