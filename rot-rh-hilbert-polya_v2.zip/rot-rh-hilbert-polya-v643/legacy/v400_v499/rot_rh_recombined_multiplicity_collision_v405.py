#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v405 — RECOMBINED FIXED-POINT / MULTIPLICITY-AWARE COLLISION REDUCTION
=============================================================================

Purpose
-------
Correct the final contour architecture after v404.

The split objects G7 and R^7 X may develop logarithmic/Volterra branch
structure under separate analytic continuation.  But the exact identity is

    G7 + R^7 X = X,

with

    X(s) = -zeta'(s)/zeta(s) - (zeta(s)-1).

Therefore the final Riesz/collision contour theorem should be applied to the
RECOMBINED meromorphic fixed point X, not to G7 and R^7 X separately.

This removes the artificial split-monodromy problem from the final contour
object.  v402 remains useful in coefficient space for recursive convergence,
but analytic continuation should be performed only after recombination.

Multiplicity-aware collision law
--------------------------------
Let rho be a nontrivial zero of multiplicity m>=1 and

    a = rho-s,
    L = log Xcut.

The differentiated first-order Riesz kernel is

    H_L(a) = (exp(L a)-1)/(L a^2).

A multiplicity-m logarithmic-derivative pole has residue m, so:
  * the z=a zero residue contributes m H_L(a);
  * the same local pole contributes -m/a at the z=0 residue.

Hence the exact collision-safe combination is

    C_{m,L}(a)
      = m [ H_L(a)-1/a ]
      = m R_L(a),

where

    R_L(a)
      = [exp(L a)-1-L a]/(L a^2).

The collision is removable and

    C_{m,L}(0)=m L/2.

Thus v78's L/2 normalization is the m=1 specialization.

Transversality does NOT require simplicity
------------------------------------------
Suppose the multiplicity-aware collision expansion is

    F'_X(E_branch)
      = m L/2 + D_X,

with m>=1 and |D_X|<=C_k.

Then

    F'_X >= L/2-C_k.

For every c_k<1/2,

    L >= C_k/(1/2-c_k)

implies

    F'_X >= c_k L.

So the v392 transversality mechanism can be multiplicity-robust.  What fails
for m>1 is only the special v78 defect normalization

    F'_X-L/2 = O(1);

instead the correct defect is

    F'_X-mL/2 = O(1).

Off-critical exact growth decomposition
---------------------------------------
For fixed a != 0,

    m R_L(a)
      = m exp(L a)/(L a^2)
        - m/a
        - m/(L a^2).

If Re(a)=delta>0, the first term has magnitude

    m exp(L delta)/(L |a|^2)
      = m Xcut^delta/(log Xcut |a|^2).

An isolated surviving right-half pole therefore has exponential-in-L
amplitude.  However a COMPLETE proof cannot lower-bound the full signed
zero sum term-by-term because equal/rightmost clusters can interfere.

Historical theorem context
--------------------------
Earlier ROT-RH contour work already reached the same hard distinction:

  * attained finite/infinite rightmost clusters can be attacked by Bohr
    mean-square / mean-motion methods;
  * if sup Re(rho) is not attained, absolute amplitude methods fail;
  * the remaining theorem becomes a SIGNED PHASE / LOG-DERIVATIVE or
    FIXED ORDERED-BRANCH theorem.

v405 therefore reconnects the new v402-v404 recursive machinery with that
older theorem frontier instead of inventing a separate G7 monodromy problem.

Monodromy sign correction to v404
---------------------------------
For a lower-limit Volterra integral

    I(t)=int_t^T C/w dw = C log T - C log t,

one positive circuit t -> t exp(2 pi i) gives

    Delta I = -2 pi i C.

v404 correctly identified nontrivial logarithmic monodromy but displayed the
opposite sign in its illustrative monodromy line.  This sign correction does
not alter the principal-pole formula

    Res_principal(G7)=m^8-m.

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO simple-zero assumption.
NO finite scan accepted as proof.

Version: 405
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from tqdm import tqdm

VERSION = 405


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def symbolic_recombination_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    X, T = sp.symbols("X T")
    G7 = X - T
    residual = sp.simplify(G7 + T - X)

    return {
        "G7_definition": "G7 = X - R7X",
        "recombination": "G7 + R7X = X",
        "residual": str(residual),
        "pass": bool(residual == 0),
    }


def symbolic_collision_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, a, m = sp.symbols(
        "L a m",
        positive=True,
        real=True,
    )

    H = (sp.exp(L*a)-1)/(L*a**2)
    R = sp.simplify(H-1/a)
    C = sp.simplify(m*R)

    expected = sp.simplify(
        m*(sp.exp(L*a)-1-L*a)/(L*a**2)
    )
    residual = sp.simplify(C-expected)

    collision = sp.simplify(sp.limit(C, a, 0))
    collision_expected = m*L/2
    collision_residual = sp.simplify(
        collision-collision_expected
    )

    simple_defect = sp.simplify(
        collision-L/2
    )

    exact_growth_split = sp.simplify(
        C
        - (
            m*sp.exp(L*a)/(L*a**2)
            - m/a
            - m/(L*a**2)
        )
    )

    return {
        "H_L": str(H),
        "R_L": str(R),
        "C_m_L": str(C),
        "collision_formula_residual": str(residual),
        "collision_value": str(collision),
        "collision_expected": str(collision_expected),
        "collision_residual": str(collision_residual),
        "simple_normalization_defect_at_collision": str(simple_defect),
        "offcritical_exact_split_residual": str(exact_growth_split),
        "pass": bool(
            residual == 0
            and collision_residual == 0
            and exact_growth_split == 0
        ),
    }


def symbolic_transversality_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, C, c, m = sp.symbols(
        "L C c m",
        positive=True,
        real=True,
    )

    lower = m*L/2-C

    # Since m>=1, lower >= L/2-C.
    universal_lower = L/2-C

    threshold = sp.simplify(
        C/(sp.Rational(1, 2)-c)
    )

    at_threshold = sp.simplify(
        universal_lower.subs(L, threshold)
        - c*threshold
    )

    return {
        "multiplicity_lower": str(lower),
        "universal_m_ge_1_lower": str(universal_lower),
        "threshold_L": str(threshold),
        "threshold_residual": str(at_threshold),
        "condition": "0<c<1/2, m>=1",
        "pass": bool(at_threshold == 0),
    }


def symbolic_monodromy_sign_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    C = sp.symbols("C")
    monodromy = -2*sp.pi*sp.I*C

    return {
        "lower_limit_primitive": "C log(T) - C log(t)",
        "positive_loop_log_change": "+2*pi*i",
        "Volterra_monodromy": str(monodromy),
        "v404_displayed_sign": "+2*pi*i*C",
        "correction": "-2*pi*i*C",
        "pass": True,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v404-summary",
        default="rot_rh_G7_local_singularity_v404_SUMMARY.json",
    )
    ap.add_argument(
        "--v403-summary",
        default="rot_rh_G7_riesz_mellin_collision_v403_SUMMARY.json",
    )
    ap.add_argument(
        "--v402-summary",
        default="rot_rh_weighted_factorial_four_jet_v402_SUMMARY.json",
    )
    ap.add_argument(
        "--v392-summary",
        default="rot_rh_summable_dyadic_cutoff_closure_v392_SUMMARY.json",
    )
    ap.add_argument(
        "--v390-summary",
        default="rot_rh_nonattained_subexponential_envelope_v390_SUMMARY.json",
        help="Optional historical nonattained-right-edge theorem packet.",
    )

    ap.add_argument("--strict", action="store_true")
    ap.add_argument(
        "--prefix",
        default="rot_rh_recombined_multiplicity_collision_v405",
    )

    args = ap.parse_args()

    print("=" * 224)
    print("ROT-RH v405 — RECOMBINED FIXED-POINT / MULTIPLICITY-AWARE COLLISION REDUCTION")
    print("=" * 224)
    print("Xi / zeta numerical values / zeros      : NONE")
    print("RH assumed                               : NO")
    print("simple zeros assumed                     : NO")
    print("finite scanning accepted as proof        : NO")
    print("=" * 224)

    v404 = load_json(args.v404_summary)
    v403 = load_json(args.v403_summary)
    v402 = load_json(args.v402_summary)
    v392 = load_json(args.v392_summary)
    v390 = load_json(args.v390_summary)

    v404_ok = bool(
        v404 is not None
        and v404.get("verdict")
        == "EXACT_G7_LOCAL_SINGULARITY_MULTIPLICITY_REDUCTION_PASS"
    )
    v403_ok = bool(
        v403 is not None
        and v403.get("verdict")
        == "EXACT_G7_RIESZ_MELLIN_COLLISION_REDUCTION_PASS"
    )
    v402_ok = bool(
        v402 is not None
        and v402.get("verdict")
        == "EXACT_WEIGHTED_FACTORIAL_FOUR_JET_R7_CONTRACTION_PASS"
    )
    v392_ok = bool(
        v392 is not None
        and v392.get("verdict")
        == "SUMMABLE_DYADIC_CUTOFF_INDEPENDENCE_IMPLICATION_PASS"
    )

    print("[1] Upstream")
    print("v404 local split-singularity reduction   :", v404_ok)
    print("v403 Riesz/Mellin collision reduction    :", v403_ok)
    print("v402 weighted recursive jet theorem      :", v402_ok)
    print("v392 summability implication             :", v392_ok)

    if v390 is not None:
        print("v390 historical verdict                  :", v390.get("verdict"))
    else:
        print("v390 historical packet                   : not supplied (optional)")

    print("\n[2] Exact symbolic identities")

    with tqdm(
        total=4,
        desc="recombined collision identities",
        unit="identity",
    ) as bar:
        recombine = symbolic_recombination_check()
        bar.update(1)

        collision = symbolic_collision_check()
        bar.update(1)

        trans = symbolic_transversality_check()
        bar.update(1)

        mono = symbolic_monodromy_sign_check()
        bar.update(1)

    print("recombination identity pass              :", recombine.get("pass"))
    print("multiplicity collision identity pass     :", collision.get("pass"))
    print("C_m,L(0)                                 :", collision.get("collision_value"))
    print(
        "simple L/2 defect for multiplicity m     :",
        collision.get("simple_normalization_defect_at_collision"),
    )
    print("multiplicity-robust transversality pass  :", trans.get("pass"))
    print("v404 monodromy sign correction           :", mono.get("correction"))

    algebra_pass = bool(
        recombine.get("pass")
        and collision.get("pass")
        and trans.get("pass")
        and mono.get("pass")
    )

    print("\n[3] Correct final contour architecture")

    architecture = [
        (
            "COEFFICIENT_SPACE",
            "Use v402 to control recursive R7 packet convergence/derivative transfer.",
        ),
        (
            "RECOMBINE_BEFORE_CONTINUATION",
            "Use G7+R7X=X exactly before contour deformation; do not contour-shift split Volterra pieces separately.",
        ),
        (
            "MEROMORPHIC_FIXED_POINT",
            "The final arithmetic transform is X=-zeta'/zeta-(zeta-1), so local zero singularities are meromorphic poles with integer multiplicity.",
        ),
        (
            "MULTIPLICITY_COLLISION",
            "A multiplicity-m zero contributes exactly m R_L(rho-s), with collision value mL/2.",
        ),
        (
            "TRANSVERSALITY",
            "If the multiplicity-normalized defect is O_k(1), m>=1 implies the same c_k<1/2 eventual slope floor needed by v392.",
        ),
    ]

    for key, value in architecture:
        print(f"{key:42s}: {value}")

    print("\n[4] Exact off-critical kernel structure")

    offcritical = [
        (
            "EXACT_SPLIT",
            "m R_L(a)=m exp(La)/(L a^2)-m/a-m/(L a^2).",
        ),
        (
            "RIGHT_HALF_GROWTH",
            "For Re(a)=delta>0 the exponential term has magnitude m exp(L delta)/(L|a|^2).",
        ),
        (
            "NO_TERM_BY_TERM_LOWER_BOUND",
            "The full signed zero sum can have phase interference; one isolated term is not a rigorous lower bound.",
        ),
        (
            "ATTAINED_CLUSTER",
            "Finite/infinite attained rightmost clusters are naturally treated by Bohr mean-square/mean-motion methods.",
        ),
        (
            "NONATTAINED_CLUSTER",
            "If sup beta is not attained, magnitude-only arguments fail; the remaining theorem is signed phase/log-derivative or fixed ordered-branch control.",
        ),
    ]

    for key, value in offcritical:
        print(f"{key:42s}: {value}")

    print("\n[5] What v404 still means")

    v404_scope = [
        (
            "PRINCIPAL_POLE_RESULT",
            "Res_principal(G7)=m^8-m remains a valid statement about the separately continued G7 piece.",
        ),
        (
            "MONODROMY_WARNING",
            "Split Volterra pieces can have logarithmic monodromy, so they are poor final contour objects.",
        ),
        (
            "FINAL_OBJECT",
            "Those split monodromies cancel on exact recombination to the meromorphic X.",
        ),
        (
            "SIGN_CORRECTION",
            "The lower-limit Volterra monodromy sign is -2pi i times the local 1/t coefficient.",
        ),
    ]

    for key, value in v404_scope:
        print(f"{key:42s}: {value}")

    print("\n[6] True remaining theorem frontier")

    remaining = [
        (
            "MULTIPLICITY_AWARE_RESIDUE_LEDGER",
            "Upgrade v69's simple-zero wording to arbitrary multiplicity m, producing m R_L(a) exactly.",
        ),
        (
            "FULL_SIGNED_ZERO_CLUSTER",
            "Control the complete recombined collision-safe zero sum on the moving fixed-k root tube.",
        ),
        (
            "NONATTAINED_PHASE_PROBLEM",
            "Prove finite diagonal log-derivative/mean motion OR a fixed ordered-branch theorem excluding migration of the effective rightmost frequency.",
        ),
        (
            "CRITICAL_REMAINDER",
            "On the critical case, prove the multiplicity-normalized collision defect and tube oscillation are O_k(1).",
        ),
        (
            "TRANSFER",
            "Combine the uniform recombined contour remainder with v392's O(1/logX) transfer and summability implication.",
        ),
    ]

    for key, value in remaining:
        print(f"{key:42s}: {value}")

    theorem_pass = bool(
        v404_ok
        and v403_ok
        and v402_ok
        and v392_ok
        and algebra_pass
    )

    verdict = (
        "EXACT_RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_PASS"
        if theorem_pass
        else
        "RECOMBINED_MULTIPLICITY_COLLISION_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_RECOMBINED_SIGNED_ZERO_CLUSTER_LOG_DERIVATIVE_OR_FIXED_ORDERED_BRANCH_THEOREM"
    )

    print("\n" + "=" * 224)
    print("VERDICT                                  :", verdict)
    print("NEXT THEOREM                             :", next_theorem)
    print(
        "FINAL RH-STRENGTH BOTTLENECK             :",
        "NONATTAINED SIGNED PHASE / LOG-DERIVATIVE / ORDERED-BRANCH CONTROL",
    )
    print("GLOBAL CUTOFF INDEPENDENCE               : NOT YET PROVED")
    print("=" * 224)

    prefix = Path(args.prefix)
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")
    cert_path = Path(str(prefix) + "_NEXT_CERTIFICATE_TEMPLATE.json")

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "simple_zeros_assumed": False,
            "finite_scan_accepted_as_proof": False,
        },
        "upstream": {
            "v404_ok": v404_ok,
            "v403_ok": v403_ok,
            "v402_ok": v402_ok,
            "v392_ok": v392_ok,
            "v390_verdict": (
                v390.get("verdict")
                if v390 is not None
                else None
            ),
        },
        "exact_identities": {
            "recombination": recombine,
            "multiplicity_collision": collision,
            "transversality": trans,
            "v404_monodromy_sign_correction": mono,
        },
        "architecture": {
            key: value for key, value in architecture
        },
        "offcritical_structure": {
            key: value for key, value in offcritical
        },
        "v404_scope": {
            key: value for key, value in v404_scope
        },
        "remaining": {
            key: value for key, value in remaining
        },
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "Exact recombination and multiplicity-aware collision reduction. "
            "This removes split G7/R7X monodromy from the final contour object. "
            "The remaining RH-strength theorem is signed zero-cluster phase/"
            "log-derivative or fixed ordered-branch control, especially for a "
            "nonattained right edge."
        ),
    }

    summary_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        r"""# ROT-RH v405 — recombined multiplicity-aware collision theorem reduction

The coefficient-space decomposition is exact:

`G7 + R^7 X = X`.

For final analytic continuation, recombine first:

`X(s)=-zeta'(s)/zeta(s)-(zeta(s)-1)`.

This removes the logarithmic branches that can occur in the separately
continued Volterra pieces.

If `rho` is a zero of multiplicity `m`, put `a=rho-s`.  The exact
collision-safe Riesz contribution is

`m R_L(a)`

with

`R_L(a)=[exp(La)-1-La]/(L a^2)`.

At collision,

`m R_L(0)=mL/2`.

Thus v78's `L/2` is the simple-zero specialization.  A multiplicity-aware
defect theorem

`F'_X-mL/2=O_k(1)`

still implies the same eventual transversality floor because `m>=1`.

For `Re(a)=delta>0`,

`m R_L(a)
 = m exp(La)/(L a^2)-m/a-m/(L a^2)`,

so a surviving right-half contribution carries `exp(L delta)`.  The full
signed zero cluster can interfere, so the final theorem cannot be obtained
from a termwise lower bound.

The remaining frontier is the same one isolated by the earlier right-edge
analysis: in the nonattained case, prove diagonal signed phase/log-derivative
mean motion or a fixed ordered-branch theorem preventing migration of the
effective rightmost frequency.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_RECOMBINED_ZERO_CLUSTER_PHASE_CERTIFICATE_V1",
        "required_claims": {
            "multiplicity_aware_residue_formula": "EXACT",
            "critical_collision_defect": "O_K_1",
            "critical_tube_oscillation": "O_K_1",
            "attained_cluster_phase_control": "RIGOROUS",
            "nonattained_diagonal_log_derivative_or_ordered_branch": "RIGOROUS",
            "uniform_recombined_contour_remainder": "O_K_1_OR_BETTER",
            "X_to_2X_transfer": "O_K_1_OVER_LOGX",
        },
        "already_closed": {
            "recursive_weighted_factorial_four_jet": "v402",
            "summability_implication": "v392",
            "recombination_identity": "v405",
        },
        "forbidden_as_proof": [
            "separate G7 and R7X contour continuation as final object",
            "simple-zero assumption",
            "termwise off-critical lower bound without cluster control",
            "finite cutoff regression",
            "known zero ordinates",
            "Xi fitting",
        ],
    }

    cert_path.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", summary_path)
    print(" ", theorem_path)
    print(" ", cert_path)

    if args.strict and not theorem_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
