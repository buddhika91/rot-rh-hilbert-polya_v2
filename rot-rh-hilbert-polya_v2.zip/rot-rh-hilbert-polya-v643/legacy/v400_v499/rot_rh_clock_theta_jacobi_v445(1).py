#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v445 — RECURSIVE-CLOCK REGULATOR + THETA-STIELTJES/JACOBI AUDIT
=======================================================================

Two independent zero-ordinate-free construction branches are frozen before
known Riemann zero ordinates are accessed.

A) Recursive-clock regulator audit
   Compare the multiplicatively composable clock regulator

       a_X(n) = Lambda(n)/(log n sqrt(n)) * n^{-epsilon_X},
       epsilon_X = 1/log X,

   with the already-successful Riesz-1 window

       a_X^R(n) = Lambda(n)/(log n sqrt(n)) * (1-log n/log X)_+.

   The root law is

       theta(E)/pi + 1 - (1/pi) sum_n a_X(n) sin(E log n) = k-1/2.

B) Theta-only Xi moment / Stieltjes-Jacobi audit
   With psi(x)=sum_{n>=1} exp(-pi n^2 x), on the critical line

       Xi(t) = 1/2 - (1/4+t^2) * int_1^inf
               psi(x) x^{-3/4} cos((t/2)log x) dx.

   From G(x)=Xi(sqrt(x))/Xi(0), compute

       log G(x) = -sum_{m>=1} q_m x^m/m.

   Test Stieltjes positivity of [q_{i+j+1}] and [q_{i+j+2}], then reconstruct
   the Jacobi multiplication operator for the normalized shifted measure

       mu_k = q_{k+1}/q_1.

No zero ordinates, zeta(), Xi() or xi() are used before the freeze manifest.
Known zeros are optional post-freeze scoring only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.optimize import brentq
from scipy.special import digamma, loggamma
from tqdm import tqdm
import mpmath as mp

VERSION = "2026-08-24-v445-recursive-clock-theta-stieltjes-jacobi"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def theta(E: float) -> float:
    z = 0.25 + 0.5j * float(E)
    return float(np.imag(loggamma(z)) - 0.5 * float(E) * math.log(math.pi))


def smooth_count(E: float) -> float:
    return theta(E) / math.pi + 1.0


def free_archimedean_levels(depth: int) -> np.ndarray:
    out = []
    lo = 7.0
    for k in tqdm(range(1, depth + 2), desc="free Gamma levels", unit="level"):
        target = k - 0.5
        hi = max(20.0, 8.0 * k + 20.0)
        while smooth_count(hi) < target:
            hi *= 1.5
        r = brentq(lambda x: smooth_count(x) - target, lo, hi,
                   xtol=1e-13, rtol=1e-13, maxiter=500)
        out.append(float(r))
    return np.asarray(out, float)


def sieve_primes(limit: int) -> np.ndarray:
    s = np.ones(limit + 1, dtype=bool)
    s[:2] = False
    for p in range(2, int(math.isqrt(limit)) + 1):
        if s[p]:
            s[p*p:limit+1:p] = False
    return np.flatnonzero(s).astype(np.int64)


def mangoldt_terms(limit: int) -> Tuple[np.ndarray, np.ndarray]:
    numbers: List[int] = []
    lambdas: List[float] = []
    for pr in sieve_primes(limit):
        p = int(pr)
        lp = math.log(float(p))
        q = p
        while q <= limit:
            numbers.append(q)
            lambdas.append(lp)
            if q > limit // p:
                break
            q *= p
    order = np.argsort(numbers)
    return np.asarray(numbers, np.int64)[order], np.asarray(lambdas, float)[order]


def arithmetic_weights(X: int, mode: str) -> Tuple[np.ndarray, np.ndarray, float]:
    n, lam = mangoldt_terms(X)
    nf = n.astype(float)
    logs = np.log(nf)
    if mode == "clock":
        eps = 1.0 / math.log(float(X))
        w = lam / (logs * np.sqrt(nf)) * np.power(nf, -eps)
    elif mode == "riesz1":
        eps = 0.0
        w = lam / (logs * np.sqrt(nf)) * np.maximum(0.0, 1.0 - logs / math.log(float(X)))
    else:
        raise ValueError(mode)
    return logs, w, eps


def phase_sum(E: np.ndarray, logs: np.ndarray, w: np.ndarray, chunk: int = 20000) -> np.ndarray:
    e = np.atleast_1d(np.asarray(E, float))
    out = np.zeros(len(e), float)
    for j in range(0, len(logs), chunk):
        out += np.sin(np.outer(e, logs[j:j+chunk])) @ w[j:j+chunk]
    return out


def quantize(depth: int, X: int, mode: str, free_ext: np.ndarray, grid_points: int) -> Dict[str, object]:
    free = free_ext[:depth]
    logs, w, eps = arithmetic_weights(X, mode)
    roots = np.zeros(depth, float)
    residuals = np.zeros(depth, float)
    counts = np.zeros(depth, int)

    def fvals(E: np.ndarray, target: float) -> np.ndarray:
        e = np.atleast_1d(np.asarray(E, float))
        sm = np.asarray([smooth_count(x) for x in e], float)
        return sm - phase_sum(e, logs, w) / math.pi - target

    for idx in tqdm(range(depth), desc=f"{mode} X={X}", unit="cell"):
        target = idx + 1 - 0.5
        lo = 7.0 if idx == 0 else 0.5 * (free[idx-1] + free[idx])
        if idx + 1 < depth:
            hi = 0.5 * (free[idx] + free[idx+1])
        else:
            hi = free[idx] + 0.5 * (free[idx] - free[idx-1])
        grid = np.linspace(lo, hi, int(grid_points))
        vals = fvals(grid, target)
        crossings = np.flatnonzero(vals[:-1] * vals[1:] <= 0.0)
        counts[idx] = len(crossings)
        if len(crossings) == 0:
            j = int(np.argmin(np.abs(vals)))
            roots[idx] = grid[j]
            residuals[idx] = abs(vals[j])
            continue
        centers = 0.5 * (grid[crossings] + grid[crossings + 1])
        j = int(crossings[np.argmin(np.abs(centers - free[idx]))])
        r = brentq(lambda z: float(fvals(np.asarray([z]), target)[0]),
                   float(grid[j]), float(grid[j+1]), xtol=1e-13, rtol=1e-13, maxiter=400)
        roots[idx] = r
        residuals[idx] = abs(float(fvals(np.asarray([r]), target)[0]))
    return {
        "mode": mode, "cutoff": int(X), "epsilon": float(eps),
        "roots": roots, "residuals": residuals, "counts": counts,
        "term_count": int(len(logs)),
    }


def psi_u(u: mp.mpf) -> mp.mpf:
    q = mp.e ** (-mp.pi * mp.e ** u)
    return (mp.jtheta(3, 0, q) - 1) / 2


def theta_xi_even_coeffs(max_n: int, dps: int) -> List[mp.mpf]:
    mp.mp.dps = int(dps)
    a: List[mp.mpf] = []
    intervals = [0, mp.mpf("0.5"), 1, mp.mpf("1.5"), 2, mp.mpf("2.5"), 3, 4, 6, 8, 10]
    for k in tqdm(range(max_n + 1), desc="theta Xi coefficients", unit="moment"):
        sign = -1 if (k & 1) else 1
        fact = mp.factorial(2*k)
        def integrand(u):
            return psi_u(u) * mp.e**(u/4) * sign * (u/2)**(2*k) / fact
        a.append(mp.quad(integrand, intervals))
    c = [mp.mpf("0") for _ in range(max_n + 1)]
    c[0] = mp.mpf("0.5") - a[0] / 4
    for n in range(1, max_n + 1):
        c[n] = -(a[n-1] + a[n] / 4)
    return c


def series_log_unit(f: Sequence[mp.mpf], N: int) -> List[mp.mpf]:
    inv = [mp.mpf("0") for _ in range(N + 1)]
    inv[0] = 1 / f[0]
    for n in range(1, N + 1):
        s = mp.mpf("0")
        for k in range(1, n + 1):
            s += f[k] * inv[n-k]
        inv[n] = -s / f[0]
    der = [(n+1) * f[n+1] for n in range(N)]
    quotient = [mp.mpf("0") for _ in range(N)]
    for i in range(N):
        for j in range(N-i):
            quotient[i+j] += der[i] * inv[j]
    out = [mp.mpf("0") for _ in range(N + 1)]
    for n in range(1, N + 1):
        out[n] = quotient[n-1] / n
    return out


def theta_power_sums(order: int, dps: int) -> Tuple[List[mp.mpf], mp.mpf, mp.mpf]:
    c = theta_xi_even_coeffs(order, dps)
    unit = [z / c[0] for z in c]
    logc = series_log_unit(unit, order)
    q = [-mp.mpf(n) * logc[n] for n in range(1, order + 1)]
    return q, c[0], c[-1]


def stieltjes_and_jacobi(q: Sequence[mp.mpf], dim: int):
    if 2 * dim > len(q):
        raise ValueError("Need moment-order >= 2*jacobi-dim")
    # Asymptotic support scale for numerical conditioning only.
    r = q[-1] / q[-2]
    q1 = q[0]
    m = [q[k] / (q1 * r**k) for k in range(len(q))]

    hankel_rows = []
    # Positive-definiteness is certified numerically by Cholesky pivots.
    # This is substantially faster and better conditioned than recomputing
    # arbitrary-precision eigenvalues at every order.
    for size in tqdm(range(1, dim + 1), desc="Stieltjes PSD", unit="size"):
        H0 = mp.matrix(size)
        H1 = mp.matrix(size)
        for i in range(size):
            for j in range(size):
                H0[i,j] = m[i+j]
                H1[i,j] = m[i+j+1]
        L0 = mp.cholesky(H0)
        L1 = mp.cholesky(H1)
        piv0 = [L0[i,i]**2 for i in range(size)]
        piv1 = [L1[i,i]**2 for i in range(size)]
        hankel_rows.append((size, min(piv0), max(piv0), min(piv1), max(piv1)))

    M = mp.matrix(dim)
    X = mp.matrix(dim)
    for i in range(dim):
        for j in range(dim):
            M[i,j] = m[i+j]
            X[i,j] = m[i+j+1]
    L = mp.cholesky(M)
    Linv = L**-1
    Jy = Linv * X * Linv.T
    Jy = (Jy + Jy.T) / 2
    J = r * Jy

    offtri = mp.mpf("0")
    for i in range(dim):
        for j in range(dim):
            if abs(i-j) > 1:
                offtri = max(offtri, abs(J[i,j]))
    diag = [J[i,i] for i in range(dim)]
    off = [J[i,i+1] for i in range(dim-1)]
    evals, evecs = mp.eigsy(J)
    lambdas = [evals[i] for i in range(dim)]
    spectral_weights = [evecs[0,i]**2 for i in range(dim)]
    gamma_nodes = [1/mp.sqrt(v) for v in reversed(lambdas) if v > 0]
    self_weight_ratios = [q1 * spectral_weights[i] / lambdas[i] if lambdas[i] > 0 else mp.nan for i in range(dim)]
    return r, m, hankel_rows, diag, off, lambdas, spectral_weights, self_weight_ratios, gamma_nodes, offtri


def write_csv(path: Path, fieldnames: Sequence[str], rows: Sequence[dict]):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(rows)


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--depth", type=int, default=120)
    ap.add_argument("--clock-cutoffs", default="36450,72900,145800,291600,583200")
    ap.add_argument("--riesz-cutoffs", default="72900,145800,291600,583200")
    ap.add_argument("--clock-grid", type=int, default=128)
    ap.add_argument("--riesz-grid", type=int, default=64)
    ap.add_argument("--moment-order", type=int, default=50)
    ap.add_argument("--jacobi-dim", type=int, default=24)
    ap.add_argument("--mp-dps", type=int, default=180)
    ap.add_argument("--zero-dps", type=int, default=80)
    ap.add_argument("--score-zeros", action="store_true")
    ap.add_argument("--prefix", default="rot_rh_clock_theta_jacobi_v445")
    args = ap.parse_args()

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    print("="*150)
    print("ROT-RH v445 — RECURSIVE-CLOCK REGULATOR + THETA-STIELTJES/JACOBI AUDIT")
    print("="*150)
    print("Known zero ordinates before freeze : NONE")
    print("zeta/Xi evaluation before freeze  : NONE")

    free_ext = free_archimedean_levels(args.depth)
    derived_X = int(math.ceil(float(free_ext[args.depth-1])**2))
    print(f"depth={args.depth} free terminal={free_ext[args.depth-1]:.12f} derived X={derived_X}")

    spectra = []
    for X in parse_ints(args.clock_cutoffs):
        spectra.append(quantize(args.depth, X, "clock", free_ext, args.clock_grid))
    for X in parse_ints(args.riesz_cutoffs):
        spectra.append(quantize(args.depth, X, "riesz1", free_ext, args.riesz_grid))

    q, xi0, _ = theta_power_sums(args.moment_order, args.mp_dps)
    r, m, hankel, diag, off, lambdas, spectral_weights, self_weight_ratios, gamma_nodes, offtri = stieltjes_and_jacobi(q, args.jacobi_dim)

    # -------- FREEZE BEFORE ZERO ACCESS --------
    root_path = Path(str(prefix) + "_ROOTS.csv")
    root_rows = []
    for rec in spectra:
        for k, (rr, rs, cc) in enumerate(zip(rec["roots"], rec["residuals"], rec["counts"]), 1):
            root_rows.append({"mode":rec["mode"], "cutoff":rec["cutoff"], "epsilon":rec["epsilon"],
                              "k":k, "root":f"{rr:.17g}", "residual":f"{rs:.17g}", "crossings":int(cc)})
    write_csv(root_path, ["mode","cutoff","epsilon","k","root","residual","crossings"], root_rows)

    moment_path = Path(str(prefix) + "_THETA_MOMENTS.csv")
    write_csv(moment_path, ["n","q_n"], [{"n":i+1,"q_n":mp.nstr(v,args.mp_dps)} for i,v in enumerate(q)])

    hankel_path = Path(str(prefix) + "_STIELTJES_HANKEL.csv")
    write_csv(hankel_path, ["size","H0_min_pivot","H0_max_pivot","H1_min_pivot","H1_max_pivot"],
              [{"size":s,"H0_min_pivot":mp.nstr(a,args.mp_dps),"H0_max_pivot":mp.nstr(b,args.mp_dps),
                "H1_min_pivot":mp.nstr(c,args.mp_dps),"H1_max_pivot":mp.nstr(d,args.mp_dps)} for s,a,b,c,d in hankel])

    jac_path = Path(str(prefix) + "_JACOBI.csv")
    write_csv(jac_path, ["index","alpha","beta_to_next"],
              [{"index":i,"alpha":mp.nstr(diag[i],args.mp_dps),
                "beta_to_next":mp.nstr(off[i],args.mp_dps) if i<len(off) else ""} for i in range(len(diag))])

    nodes_path = Path(str(prefix) + "_JACOBI_NODES.csv")
    write_csv(nodes_path, ["rank","lambda","mu_weight","q1_weight_over_lambda","gamma_from_lambda"],
              [{"rank":i+1,"lambda":mp.nstr(lambdas[-1-i],args.mp_dps),
                "mu_weight":mp.nstr(spectral_weights[-1-i],args.mp_dps),
                "q1_weight_over_lambda":mp.nstr(self_weight_ratios[-1-i],args.mp_dps),
                "gamma_from_lambda":mp.nstr(gamma_nodes[i],args.mp_dps)} for i in range(len(gamma_nodes))])

    manifest = {
        "version": VERSION,
        "depth": args.depth,
        "derived_primary_cutoff": derived_X,
        "moment_order": args.moment_order,
        "jacobi_dim": args.jacobi_dim,
        "mp_dps": args.mp_dps,
        "xi0_theta": mp.nstr(xi0, 80),
        "support_scale_r": mp.nstr(r, 80),
        "implied_largest_gamma": mp.nstr(1/mp.sqrt(r), 80),
        "minimum_H0": mp.nstr(min(row[1] for row in hankel),80),
        "minimum_H1": mp.nstr(min(row[3] for row in hankel),80),
        "minimum_jacobi_beta": mp.nstr(min(off),80),
        "offtridiagonal_defect": mp.nstr(offtri,80),
        "leading_self_weight_ratios": [mp.nstr(self_weight_ratios[-1-i],50) for i in range(min(12,len(self_weight_ratios)))],
        "firewall": {"known_zero_ordinates_used": False, "zeta_used": False, "Xi_used": False},
        "files": {},
    }
    for p in [root_path,moment_path,hankel_path,jac_path,nodes_path]:
        manifest["files"][p.name] = sha256_file(p)
    manifest_path = Path(str(prefix) + "_FREEZE.json")
    manifest_path.write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(f"FREEZE COMPLETE: {manifest_path}")

    # -------- POST-FREEZE SCORING ONLY --------
    score = {"scored": False}
    if args.score_zeros:
        mp.mp.dps = args.zero_dps
        true = np.asarray([float(mp.im(mp.zetazero(k))) for k in tqdm(range(1,args.depth+1),desc="post-freeze zeros",unit="zero")])
        target_scale = float(np.sqrt(np.mean(true*true)))
        spectral_scores = []
        for rec in spectra:
            roots = rec["roots"]
            err = roots - true
            rmse = float(np.sqrt(np.mean(err*err)))
            spectral_scores.append({
                "mode": rec["mode"], "cutoff": rec["cutoff"], "epsilon": rec["epsilon"],
                "rmse": rmse, "relative_rmse_percent": 100*rmse/target_scale,
                "mae": float(np.mean(np.abs(err))), "max_abs": float(np.max(np.abs(err))),
                "min_crossings": int(np.min(rec["counts"])), "max_crossings": int(np.max(rec["counts"])),
                "missing_cells": int(np.sum(rec["counts"]==0)), "ambiguous_cells": int(np.sum(rec["counts"]>1)),
            })
        score_path = Path(str(prefix) + "_POST_FREEZE_SCORES.csv")
        write_csv(score_path, list(spectral_scores[0].keys()), spectral_scores)

        nscore = min(len(gamma_nodes), args.depth)
        node_rows = []
        for i in range(nscore):
            pred = float(gamma_nodes[i]); tru = float(true[i])
            node_rows.append({"k":i+1,"gamma_jacobi":pred,"gamma_true":tru,
                              "abs_error":abs(pred-tru),"relative_error":abs(pred-tru)/tru})
        node_score_path = Path(str(prefix) + "_POST_FREEZE_JACOBI_ZERO_SCORE.csv")
        write_csv(node_score_path, list(node_rows[0].keys()), node_rows)
        score = {"scored": True, "spectral_scores": spectral_scores,
                 "jacobi_zero_score_file": node_score_path.name,
                 "spectral_score_file": score_path.name}

    summary = {
        "version": VERSION,
        "elapsed_seconds": time.time()-t0,
        "construction": manifest,
        "post_freeze": score,
    }
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    summary_path.write_text(json.dumps(summary,indent=2),encoding="utf-8")

    print("\nKEY ZERO-FREE RESULTS")
    print("theta Xi(0)                 :", mp.nstr(xi0,30))
    print("q1, q2, q3                  :", *(mp.nstr(x,18) for x in q[:3]))
    print("support scale r             :", mp.nstr(r,24))
    print("implied first gamma         :", mp.nstr(1/mp.sqrt(r),24))
    print("H0/H1 all positive          :", all(a>0 and c>0 for _,a,_,c,_ in hankel))
    print("minimum Jacobi beta         :", mp.nstr(min(off),18))
    print("offtridiagonal defect       :", mp.nstr(offtri,8))
    print("summary                     :", summary_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
