# ROT-RH v487 — flat-bump Gevrey / regulator barrier

Consider the endpoint-flat model family

`p_r(1-t) ~ exp(-1/t^r)`, `r>0`.

For the large complex parameter `z=lambda L`, the endpoint phase is

`Psi_r(t;z)=z-z t-1/t^r`.

The stationary equation is

`-z+r/t^(r+1)=0`,

so

`t_*=(r/z)^(1/(r+1))`.

Substitution gives a leading loss proportional to

`|z|^(r/(r+1))`.

Thus the generalized bump has Fourier/saddle decay

`exp[-c_r |lambda L|^(r/(r+1))]`.

## Active-height law

Balancing the off-critical `O(L)` real-part advantage against the vertical loss

`L^(r/(r+1)) Gamma^(r/(r+1))`

gives

`Gamma_active=O(L^(1/r))`.

For the present bump `r=2`, this is exactly the v475 `O(sqrt L)` parabolic strip.

## UV-collapse law

Use the v486 truncation

`T_eta=L/(log L)^(1+eta)`.

Then the omitted-tail exponent becomes

`(L T_eta)^(r/(r+1))
 = L^(2r/(r+1))/(log L)^((1+eta)r/(r+1))`.

For `r=2` this recovers the v486 `L^(4/3)` scale.  As `r->infinity`, the
power `2r/(r+1)` tends to `2`, so higher endpoint flatness makes the surviving
UV cancellation requirement dramatically more severe.

## Why this still does not close the theorem

The prototype `exp(-1/t^r)` is Gevrey of order

`s=1+1/r`.

For every finite `r`, `s>1`.  Gevrey classes of order greater than one are
non-quasianalytic and admit nonzero compactly supported functions; their Fourier
transforms have stretched-exponential decay of the form `exp(-c |xi|^(1/s))`.
Thus the saddle exponent `r/(r+1)=1/s` is exactly the expected Gevrey dual
exponent.

Therefore **no finite compactly supported endpoint-flat regulator can close the
v485/v486 survivor merely by a quasianalytic argument**.  Increasing `r`
strengthens the numerical/analytic barrier but does not remove the structural
possibility of arbitrarily flat cancellation.

**Verdict:** `FINITE_FLAT_BUMP_GEVREY_QUASIANALYTIC_ROUTE_NOGO_PASS`.

The remaining closure must use genuine arithmetic/Fredholm structure, or move to
a noncompact analytic regulator and re-prove regulator universality.
