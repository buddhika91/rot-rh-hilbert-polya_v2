# ROT-RH v494 — Gaussian moving-boundary quartet / remote summability

For the Gaussian regulator,

`I(z)=int_0^infty exp(-x^2+zx)dx
     =sqrt(pi)/2 exp(z^2/4) erfc(-z/2)`

and

`J(z)=int_0^infty 2x exp(-x^2)exp(zx)dx
     =1+z I(z)`.

Fix a physical center `E0` and moving boundary

`E_u(L)=E0-u/L`.

For

`lambda0=sigma*a+i(tau*gamma-E0)`,
`w=L lambda0`,
`z=w+i u`,

direct differentiation of the Gaussian zero primitive gives the **exact**
complex moving generator

`M_u(lambda0,L)
 =L[J(z)-iu I(z)]
 =L[1+w I(z)]`.

Outside a fixed finite ordinate neighborhood of `E0`, every nontrivial zero
lies in a vertical outer sector because `|a|<1/2`.  The standard complementary
error-function expansion gives there

`I(z)=-1/z+2/z^3+O(z^-5)`,

hence

`M_u
 =iu/(lambda0+iu/L)
  +O_u(1/(L |lambda0|^2))`.

The single-mode leading term is only `O(1/gamma)` and must **not** be
absolute-valued separately. Recombine the full zeta symmetry quartet first:

`lambda_(sigma,tau)
 =sigma*a+i(tau*gamma-E0)+iu/L`.

For fixed `E0,u`, put `A=E0-u/L`.  The quartet reciprocal sum is in fact
**exactly**

`sum_(sigma,tau) 1/[sigma*a+i(tau*gamma-A)]`

`= 4 i A (A^2+a^2-gamma^2)`
`  / [((gamma-A)^2+a^2)((gamma+A)^2+a^2)]`.

Therefore

`sum_(sigma,tau) 1/lambda_(sigma,tau)
 =O_(E0,u)(1/gamma^2)`

with no cancellation estimate left implicit.

Thus one complete remote quartet satisfies

`M_(u,quartet)
 =O_(E0,u)(1/gamma^2)
  +O_(E0,u)(1/(L gamma^2))`.

The classical count `N(T)=O(T log T)` implies

`sum_quartets m_gamma/gamma^2 < infinity`.

Therefore the complete remote moving-boundary generator is uniformly bounded:

`H_u^remote(L)=O_(E0,u)(1)`,

and its signed primitive satisfies

`Pi_u^remote(L)=int H_u^remote(s)ds=O_(E0,u)(L)`.

This is the **preferred sharp v419 primitive class**, giving an `O(1/L)`
cutoff tail for this entire infinite remote sector once the local finite sector
is separated.

### Consequence

The compact Gevrey bump admitted a genuinely nonattained ultraviolet
support-migration problem.  For the Gaussian moving generator, the entire
infinite remote sector is already v419-harmless after quartet recombination.
Only a fixed finite ordinate neighborhood remains potentially nontrivial.

**Verdict:** `GAUSSIAN_REMOTE_QUARTET_V419_PRIMITIVE_PASS`.

Scientific boundary: the precise Gaussian explicit-formula/static normalization,
the residual finite local cluster, and regulator universality back to the compact
bump are separate obligations.  The erfc remainder should be stated with a
uniform sector constant in a publication proof.
