# ROT-RH v474 — nonattained coherence/spread dichotomy

For

`H=sum b_j`,
`G=sum gamma_j b_j`,
`W0=sum|b_j|`,
`mu=sum gamma_j|b_j|/W0`,

define

`c=|H|/W0`

and

`s=sum |gamma_j-mu||b_j|/(mu W0)`.

Because

`G=mu H+R`,
`|R|<=mu W0 s`,

we have exactly

`Re(G Hbar)>=mu W0^2 c(c-s)`.

The v409 phase identity plus `|delta_j|<=1` implies that
`|omega|<=C` gives

the sharper exact bound is

`|Re(G Hbar)| <= W0^2(C c^2+c)`.

Combining with the lower bound and dividing by `c>0` gives

`mu(c-s)<=C c+1`.

Thus, whenever `mu>C`,

`c <= (s+1/mu)/(1-C/mu)`.

If

`CV=sigma/mu`

is the absolute-weighted coefficient of variation of the frequencies,
Cauchy-Schwarz gives `s<=CV`, hence

`c <= (CV+1/mu)/(1-C/mu)`.

Since the nonattained sector has `mu->infinity`:

* `CV->0` forces `c->0`;
* if `c>=kappa>0`, then necessarily `CV>=kappa-o(1)`.

Thus a bounded nonattained branch can no longer be supported by a coherent
narrow moving packet.  It must be either:

1. **amplitude-collapsed**: `|H|/W0->0`; or
2. **genuinely broad-band**: relative frequency spread does not vanish.

**Verdict:** EXACT_NONATTAINED_COHERENCE_SPREAD_DICHOTOMY_PASS

This does not yet exclude those two exceptional sectors.
