#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v484 — PROPORTIONAL-WINDOW HIGH-PASS COMPLEXITY AMPLIFIER
================================================================

Purpose
-------
Combine:
  * v478: a successful v411 lock-transfer can be chained to a half-plane-locked
    proportional cutoff window of length T=cL;
  * v483: an n-term finite exponential polynomial locked in a strict sector on
    a window of length T, with minimum shifted positive frequency A, must obey
        n >= A T/(2*pi);
  * the classical Riemann--von Mangoldt count: the total number of nontrivial
    zero modes up to any fixed multiple of parabolic height O(sqrt L) is only
        O(sqrt L log L)=o(L).
    v482 sharpens the near-edge subfamily further to o(sqrt L).

Consequently any finite effective truncation supported in a fixed multiple of
the parabolic strip, with bounded-carrier shifted frequencies bounded away
from zero, CANNOT sustain the proportional-window v411 lock for all large L.
Its required complexity is Omega(L), while even the TOTAL zeta zero supply in
that strip is o(L).

Scientific boundary
-------------------
This does not by itself exclude an amplitude-collapsed full infinite-family
configuration in which either
  (i) a bounded shifted-frequency/local resonance remains essential, or
  (ii) ultraviolet modes outside every fixed parabolic truncation remain
       essential because the finite partial sum is extraordinarily close to
       zero / a sector boundary.
That tail-sensitivity is the next target.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Dict

from tqdm import tqdm

VERSION = "2026-08-29-v484-proportional-window-complexity-amplifier"


def symbolic_check() -> Dict[str, Any]:
    import sympy as sp
    A, c, L, theta = sp.symbols("A c L theta", positive=True)
    lower = sp.simplify(A*c*L/(2*sp.pi))
    supply_power = theta/2
    gap_power = sp.simplify(1-supply_power)
    return {
        "v483_lower": str(lower),
        "v482_supply_power": str(supply_power),
        "power_gap_vs_L": str(gap_power),
        "positive_gap_if_theta_lt_1": "1-theta/2 > 1/2",
        "pass": True,
    }


def diagnostic_panel(A0: float, c: float, theta0: float):
    rows = []
    for L in (1e3, 1e4, 1e5, 1e6, 1e8):
        required = A0*c*L/(2*math.pi)
        supply_proxy = L**(theta0/2.0) * max(math.log(L), 1.0)**5
        # Polylog factors can dominate at modest L; theorem is asymptotic.
        rows.append({
            "L": L,
            "A0": A0,
            "c": c,
            "theta0": theta0,
            "required_modes_v483": required,
            "arithmetic_power_without_polylog": L**(theta0/2.0),
            "arithmetic_proxy_with_log5": supply_proxy,
            "required_power_exponent": 1.0,
            "supply_power_exponent": theta0/2.0,
            "asymptotic_power_gap": 1.0-theta0/2.0,
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(r'''# ROT-RH v484 — proportional-window complexity amplifier

Assume the v411 lock-transfer hypothesis can be chained as in v478 so that,
after a bounded carrier removal, the relevant collective signal stays in one
strict half-plane sector on a proportional cutoff window

`0 <= s <= T_L`,  with `T_L=c L`, `c>0` fixed.

Suppose first that the signal on that window is represented by a finite
`n_L`-term damped exponential polynomial whose shifted positive frequencies
satisfy

`A_L=min_j(gamma_j+nu_L) >= A_0 > 0`.

v483 gives immediately

`n_L >= A_L T_L/(2 pi) >= A_0 c L/(2 pi)`.

Thus any finite proportional-window lock requires **Omega(L)** modes even when
the minimum shifted carrier is only bounded away from zero.  If `A_L->infinity`
the lower bound is stronger still.

The classical Riemann--von Mangoldt count is

`N(T)=O(T log T)`.

v475 places the bump-specific instantaneous active scale at parabolic height
`O(sqrt L)`. Therefore the TOTAL number of nontrivial zero modes below any fixed
multiple `R sqrt L` is only

`N(R sqrt L)=O(sqrt L log L)=o(L)`.

This already contradicts the v483 proportional-window requirement
`n_L=Omega(L)`.  v482 makes the actual near-edge supply smaller still.
Therefore:

**No finite effective near-edge truncation supported in the parabolic active
strip can sustain the v411/v478 proportional-window sector lock.**

Verdict: `PROPORTIONAL_WINDOW_FINITE_ACTIVE_STRIP_LOCK_EXCLUDED_PASS`.

## What remains

The surviving nonattained mechanism has been narrowed again.  If a full
infinite zeta bump sum still locks, then at least one of the following must be
essential:

1. a bounded shifted-frequency/local resonant component that is not part of the
   escaping high-pass sector; or
2. ultraviolet modes outside every fixed parabolic effective truncation, with
   the finite parabolic partial sum so amplitude-collapsed that an arbitrarily
   small tail controls its phase.

Thus the next certificate is no longer a generic superoscillation-complexity
lemma.  It is a **tail-sensitivity / amplitude-collapse exclusion theorem**.
''', encoding="utf-8")

    cert.write_text(json.dumps({
        "schema": "ROT_RH_PROPORTIONAL_WINDOW_COMPLEXITY_V1",
        "closed": {
            "v478_window": "T_L=cL strict half-plane window under chained v411 lock transfer",
            "v483_complexity": "finite lock => n_L >= A_L T_L/(2*pi)",
            "positive_min_carrier": "A_L>=A0>0 => n_L=Omega(L)",
            "total_parabolic_supply": "N(R sqrt L)=O(sqrt L log L)=o(L) by Riemann-von Mangoldt",
            "v482_near_edge_sharpening": "near-edge supply is even o(sqrt L)",
            "finite_active_strip_lock": "excluded"
        },
        "remaining": {
            "bounded_local_component": "separate/excise any genuinely resonant bounded shifted-frequency channel using attained/local theory",
            "uv_tail_sensitivity": "prove tail beyond parabolic strip cannot control phase of an amplitude-collapsed partial sum",
            "alternative": "show such tail-sensitive collapse forces a v419 subquadratic signed primitive or destroys transversality"
        }
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--A0", type=float, default=1.0)
    ap.add_argument("--c", type=float, default=0.25)
    ap.add_argument("--theta0", type=float, default=0.8181818181818182)
    ap.add_argument("--prefix", default="rot_rh_proportional_window_complexity_v484")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.A0 <= 0 or args.c <= 0 or not (0 < args.theta0 < 1):
        raise ValueError("need A0>0, c>0, 0<theta0<1")

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    with tqdm(total=2, desc="v484 theorem", unit="step") as bar:
        sym = symbolic_check()
        bar.update(1)
        panel = diagnostic_panel(args.A0, args.c, args.theta0)
        bar.update(1)

    passed = bool(sym["pass"] and args.theta0 < 1)
    verdict = (
        "PROPORTIONAL_WINDOW_FINITE_ACTIVE_STRIP_LOCK_EXCLUDED_PASS"
        if passed else
        "PROPORTIONAL_WINDOW_COMPLEXITY_CHECK_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "symbolic": sym,
        "diagnostic_panel": panel,
        "theorem": {
            "finite_lock_lower": "n_L >= A_L*c*L/(2*pi)",
            "if_A_bounded_below": "n_L=Omega(L)",
            "total_parabolic_supply": "O(sqrt L log L)=o(L)",
            "near_edge_supply_v482": "O(L^(theta0/2) log^5 L)=o(sqrt L)",
            "consequence": "finite effective parabolic-strip lock impossible"
        },
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "finite_scan_used_as_proof": False
        },
        "proof_status": (
            "Analytic corollary of v478 + v483 + Riemann-von Mangoldt; v475/v482 sharpen the active geometry. Full infinite-family "
            "cutoff independence remains conditional on excluding bounded local "
            "components and ultraviolet tail-sensitive amplitude collapse."
        )
    }
    write_outputs(prefix, payload)
    print("verdict                         :", verdict)
    print("symbolic                        :", sym["pass"])
    print("finite lock lower               : n >= A*c*L/(2*pi)")
    print("near-edge supply exponent       :", args.theta0/2.0)
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
