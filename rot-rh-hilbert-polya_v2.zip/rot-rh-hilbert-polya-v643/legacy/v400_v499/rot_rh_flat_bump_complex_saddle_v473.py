#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v473 — FLAT-BUMP COMPLEX ENDPOINT SADDLE / NONATTAINED MIGRATION
======================================================================

This theorem analyzes the complex compact-bump transform

    K_L(lambda)
      = int_(ell/L)^1 p(x) exp(lambda L x) dx/x,
      p(x)=exp(-(x/(1-x))^2),
      Re(lambda)>0.

It is the natural zero-side transform for an off-critical exponent

    lambda = a + i omega,
    a = beta-1/2 > 0.

Near x=1 write t=1-x and z=lambda L.  The exponent is

    Phi(t;z)
      = z - z t - 1/t^2 + 2/t - 1.

The dominant saddle solves exactly

    z t^3 + 2 t - 2 = 0.

For |z|->infinity in the closed right-half sector, the saddle has

    t(z)
      = 2^(1/3) z^(-1/3)
        - 2^(2/3)/3 z^(-2/3)
        + 2*2^(1/3)/81 z^(-4/3)
        + O(z^(-5/3)).

Substitution gives

    Phi(t(z);z)
      = z
        - 3*2^(-2/3) z^(2/3)
        + 2^(2/3) z^(1/3)
        - 2/3
        + O(z^(-1/3)).

Since -Phi_tt ~ 6*2^(-4/3) z^(4/3), standard one-saddle
steepest descent gives

    K_L(lambda)
      = C(lambda,L) z^(-2/3)
        exp[
          z
          -3*2^(-2/3)z^(2/3)
          +2^(2/3)z^(1/3)
          -2/3
        ]
        (1+O(z^(-1/3))),

with a nonzero sectorial prefactor C tending to a nonzero constant after the
usual steepest-descent orientation is fixed.

Consequences
------------
1. Magnitude:
       log|K|
         = aL
           -3*2^(-2/3)L^(2/3) Re(lambda^(2/3))
           +O(L^(1/3)|lambda|^(1/3)+log(L|lambda|)).

   For |omega|>>a,
       Re(lambda^(2/3)) ~ |omega|^(2/3)/2,
   so the flat bump supplies the stretched-exponential frequency penalty
       exp[-(3/2)2^(-2/3)|omega|^(2/3)L^(2/3)].

2. E-carrier:
   If omega=Gamma-E, then
       partial_E log K
         = -iL[
             1
             -2^(1/3)(lambda L)^(-1/3)
             +O((lambda L)^(-2/3))
           ].
   Thus the E carrier has slope L(1+o(1)) on every escaping high-ordinate
   active mode.

3. Cutoff frequency:
       partial_L Im log K
         = omega
           +O(L^(-1/3)|lambda|^(2/3)).
   Relative to |omega|,
       error/|omega| = O((L|omega|)^(-1/3)).
   Therefore an isolated escaping winner has physical phase frequency
       omega(1+o(1)).

4. Nonattained overtaking:
   If a_j>a_k are two fixed off-critical exponents, then
       log |K_j/K_k|
         =(a_j-a_k)L+O(L^(2/3)).
   Hence j eventually overtakes k regardless of the fixed ordinate penalty.

   For every fixed L, compact C-infinity smoothness gives super-polynomial
   Fourier decay as |omega|->infinity, so an instantaneous finite-height
   winner exists.

   Therefore, if a_*=sup a_j is not attained, every sequence of instantaneous
   winners escapes to |Gamma|->infinity.

This is the current bump-specific replacement for the older Gamma/Stirling
support-migration theorem.  It proves that the flat bump changes the penalty
but DOES NOT remove the nonattained migration obstruction.

Scientific boundary
-------------------
The saddle expansion is a standard sectorial steepest-descent reduction.
The script verifies its algebra symbolically.  A journal proof should still
spell out the contour deformation/uniform remainder estimate.

This theorem does not exclude collective cancellation and does not prove RH.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Dict, Any

from tqdm import tqdm

VERSION = "2026-08-28-v473-flat-bump-complex-endpoint-saddle"


def symbolic_saddle() -> Dict[str, Any]:
    import sympy as sp

    r = sp.symbols("r")
    A, B, C, D = sp.symbols("A B C D")
    # z=r^-3 and t=A r+B r^2+C r^3+D r^4
    t = A*r + B*r**2 + C*r**3 + D*r**4
    z = r**-3
    saddle = sp.expand(z*t**3 + 2*t - 2)
    ser = sp.series(saddle, r, 0, 5).removeO().expand()
    coeff = [sp.expand(ser).coeff(r, j) for j in range(4)]

    Aval = 2**sp.Rational(1, 3)
    Bval = -2**sp.Rational(2, 3)/3
    Cval = sp.Integer(0)
    Dval = 2*2**sp.Rational(1, 3)/81

    residuals = [
        sp.simplify(c.subs({A:Aval, B:Bval, C:Cval, D:Dval}))
        for c in coeff
    ]

    phi = z - z*t - 1/t**2 + 2/t - 1
    phiser = sp.series(
        phi.subs({A:Aval, B:Bval, C:Cval, D:Dval}),
        r, 0, 2
    ).removeO().expand()

    expected = (
        r**-3
        - 3*2**sp.Rational(1, 3)/(2*r**2)
        + 2**sp.Rational(2, 3)/r
        - sp.Rational(2, 3)
        + 2*2**sp.Rational(1, 3)*r/27
    )
    phi_resid = sp.simplify(phiser-expected)

    # derivative coefficients of the exponent with respect to z
    zz = sp.symbols("z", positive=True)
    c2 = 3*2**(-sp.Rational(2,3))
    c1 = 2**(sp.Rational(2,3))
    Psi = zz - c2*zz**sp.Rational(2,3) + c1*zz**sp.Rational(1,3)
    Psip = sp.simplify(sp.diff(Psi, zz))

    return {
        "saddle_coefficients": {
            "A": str(Aval),
            "B": str(Bval),
            "C": str(Cval),
            "D": str(Dval),
        },
        "saddle_equation_residuals": [str(x) for x in residuals],
        "phase_series": str(phiser),
        "phase_expected_residual": str(phi_resid),
        "Psi_prime": str(Psip),
        "c2_exact": "3*2^(-2/3)",
        "c1_exact": "2^(2/3)",
        "pass": bool(all(x == 0 for x in residuals) and phi_resid == 0),
    }


def asymptotic_panel(a: float, omega: float):
    c2 = 3.0*2.0**(-2.0/3.0)
    c1 = 2.0**(2.0/3.0)
    lam = complex(a, omega)
    rows = []
    for L in (20.0, 80.0, 320.0, 1280.0):
        z = lam*L
        psi = z - c2*z**(2/3) + c1*z**(1/3) - 2.0/3.0
        dpsi = 1.0 - (2.0/3.0)*c2*z**(-1/3) + (1.0/3.0)*c1*z**(-2/3)
        rows.append({
            "L": L,
            "Re_exponent": psi.real,
            "Im_exponent": psi.imag,
            "E_carrier_relative_slope": dpsi.real,
            "cutoff_frequency_proxy": (lam*dpsi).imag,
            "cutoff_frequency_relative":
                (lam*dpsi).imag/omega if omega else None,
        })
    return rows


def write_outputs(prefix: Path, payload: Dict[str, Any]) -> None:
    summary = Path(str(prefix)+"_SUMMARY.json")
    theorem = Path(str(prefix)+"_THEOREM.md")
    cert = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    summary.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    theorem.write_text(
f"""# ROT-RH v473 — flat-bump complex endpoint saddle / nonattained migration

For

`K_L(lambda)=int p(x)e^(lambda Lx)dx/x`, `Re lambda>0`,

put `z=lambda L`, `t=1-x`.  The exact saddle equation is

`z t^3+2t-2=0`.

Its asymptotic solution is

`t
 =2^(1/3)z^(-1/3)
 -2^(2/3)z^(-2/3)/3
 +2*2^(1/3)z^(-4/3)/81
 +O(z^(-5/3))`.

The saddle exponent is

`Psi(z)
 =z
 -3*2^(-2/3)z^(2/3)
 +2^(2/3)z^(1/3)
 -2/3
 +O(z^(-1/3))`.

Hence the standard steepest-descent form is

`K_L(lambda)
 ~ const * z^(-2/3) exp(Psi(z))`.

For `lambda=a+i omega` this gives

`log|K|
 =aL
 -3*2^(-2/3)L^(2/3)Re(lambda^(2/3))
 +O(L^(1/3)|lambda|^(1/3)+log|lambda L|)`.

For `|omega|>>a` the leading frequency penalty is proportional to

`-|omega|^(2/3)L^(2/3)`.

At the same time

`partial_E log K
 =-iL[1-2^(1/3)(lambda L)^(-1/3)+O((lambda L)^(-2/3))]`

for `omega=Gamma-E`, so the real-energy carrier slope is `L(1+o(1))`.

And

`partial_L Im log K
 =omega+O(L^(-1/3)|lambda|^(2/3))`.

Thus an isolated active high-ordinate resonance still carries its own escaping
ordinate frequency.

Finally, if two fixed zeros satisfy `a_j>a_k`, their logarithmic magnitude
difference is

`(a_j-a_k)L+O(L^(2/3))`,

so the larger real part eventually wins.  Compact smoothness gives
super-polynomial Fourier decay at fixed L, hence a finite instantaneous winner.
If `sup a_j` is not attained, all instantaneous winners escape every finite
ordinate set.

**Verdict:** {payload['verdict']}

The bump therefore changes the vertical penalty from the old Gamma/Stirling
geometry to a `2/3` endpoint-saddle geometry, but the nonattained support
migration itself survives.

The remaining case is still genuinely collective.
""",
        encoding="utf-8",
    )

    cert.write_text(json.dumps({
        "schema": "ROT_RH_FLAT_BUMP_COMPLEX_SADDLE_V1",
        "closed": {
            "saddle_equation": "z t^3+2t-2=0",
            "saddle_location":
                "2^(1/3)z^-1/3-2^(2/3)z^-2/3/3+O(z^-4/3)",
            "saddle_exponent":
                "z-3*2^-2/3 z^2/3+2^2/3 z^1/3-2/3+O(z^-1/3)",
            "frequency_penalty":
                "stretched exponential exp[-c |omega|^(2/3)L^(2/3)]",
            "E_carrier": "partial_E phase = -L(1+o(1))",
            "cutoff_frequency": "partial_L phase = omega(1+o(1))",
            "nonattained_migration":
                "larger fixed beta eventually overtakes; instantaneous winner ordinate escapes",
        },
        "remaining": {
            "collective": "classify cancellation among infinitely many escaping saddle modes",
            "uniform_contour":
                "write full sectorial contour/remainder proof for publication",
        },
    }, indent=2), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", type=float, default=0.20)
    ap.add_argument("--omega", type=float, default=20.0)
    ap.add_argument("--prefix", default="rot_rh_flat_bump_complex_saddle_v473")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    prefix = Path(args.prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("="*190)
    print("ROT-RH v473 — FLAT-BUMP COMPLEX ENDPOINT SADDLE / NONATTAINED MIGRATION")
    print("="*190)
    with tqdm(total=2, desc="v473 saddle", unit="step") as bar:
        sym = symbolic_saddle()
        bar.update(1)
        panel = asymptotic_panel(args.a, args.omega)
        bar.update(1)

    passed = bool(sym["pass"])
    verdict = (
        "EXACT_FLAT_BUMP_SADDLE_AND_NONATTAINED_MIGRATION_REDUCTION_PASS"
        if passed else
        "FLAT_BUMP_SADDLE_ALGEBRA_FAILED"
    )
    payload = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.perf_counter()-t0,
        "firewall": {
            "Xi_used": False,
            "zeta_numerical_values_used": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
        },
        "symbolic": sym,
        "asymptotic_panel": panel,
        "proof_status":
            "Exact formal saddle algebra plus standard sectorial steepest-descent reduction; collective nonattained cancellation remains open.",
    }
    write_outputs(prefix, payload)

    print("verdict                         :", verdict)
    print("saddle algebra                  :", sym["pass"])
    print("last E-carrier relative slope   :", f"{panel[-1]['E_carrier_relative_slope']:.12e}")
    print("last cutoff-frequency ratio     :", f"{panel[-1]['cutoff_frequency_relative']:.12e}")
    print("summary                         :", str(prefix)+"_SUMMARY.json")
    print("theorem                         :", str(prefix)+"_THEOREM.md")
    print("certificate                     :", str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    if args.strict and not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
