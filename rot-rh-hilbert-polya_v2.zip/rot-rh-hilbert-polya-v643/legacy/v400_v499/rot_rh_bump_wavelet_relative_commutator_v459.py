#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v459 — BUMP-WAVELET HEAD / RELATIVE COMMUTATOR PROSPECTIVE AUDIT
=======================================================================

PURPOSE
-------
Attack the analytic theorem suggested after v458 directly on the arithmetic
bump-2 finite-part characteristic.

For p(x)=exp(-(x/(1-x))^2), 0<=x<1, define

    q(x) = -p'(x) = 2x/(1-x)^3 p(x).

With L=log X, the exact bump identity is

    partial_L p(y/L) = y/L^2 q(y/L).

For the centered Mangoldt measure

    dmu(y) = d psi(e^y) - e^y dy,

define the bump-wavelet generator

    C_q(L,E)
      = int e^(-y/2) q(y/L) sin(Ey) dmu(y).

Then exactly

    partial_L P_L^FP(E) = C_q(L,E)/L^2

(the E1 analytic-continuation term is L-independent), hence for fixed E

    F(E,L+h)-F(E,L)
      = -(1/pi) int_L^(L+h) C_q(s,E)/s^2 ds.

At a continued root E_k(L), the exact endpoint secant relation is

    Delta E_k * D* = -A_k + endpoint residuals,

where

    A_k = F(E_k(L),L+h)-F(E_k(L),L)

and D* is the right-cutoff energy secant slope.

THEOREM SCALING ATTACK
----------------------
Freeze exponents BEFORE the fresh interval.

Assume on one fixed-width logarithmic shell

    |C_q(L,E_k)| <= C_q L^b,
    |D*|          >= d L^a.

Then

    |Delta E_k| = O(L^(b-2-a)).

Writing the desired root-increment exponent as p,

    |Delta E_k| = O(L^-p),

the exact exponent relation is

    p = 2 + a - b.

The decisive summability condition is p>1, equivalently

    b < 1+a.

Default conservative theorem exponents:

    a = 0.00       (only a positive secant-slope floor is assumed)
    p = 1.10
    b = 2+a-p = 0.90.

Thus v459 does NOT assume the older Riesz normalization F_E ~ cL.

PROSPECTIVE FIREWALL
--------------------
Training data end at 149,299,200 by default. Historical roots are read from:
  * v456 packet-phase nodes through 74,649,600
  * v458 fresh-flow nodes through 149,299,200

The script:
  1. builds/loads arithmetic only through the training endpoint;
  2. recomputes exact bump-2 endpoint commutators and wavelet generators;
  3. freezes fixed-exponent envelopes and writes their SHA256;
  4. ONLY AFTER THE FREEZE extends the Mangoldt table to 298,598,400;
  5. solves the new endpoint roots and scores the unseen doubling.

No Xi, no zeta(), no zeta'/zeta(), and no known Riemann zero ordinates are used.

SCIENTIFIC BOUNDARY
-------------------
A PASS is prospective numerical evidence for the Bump-Wavelet / Relative
Commutator theorem. It is NOT an all-L proof, NOT RH, and NOT a completed
Hilbert-Polya theorem. In particular, sampled C_q control on a finite L grid is
not a proof of the continuous all-L wavelet envelope.

Version: 2026-08-26-v459-bump-wavelet-relative-commutator
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from scipy.integrate import simpson
from scipy.special import roots_legendre
from tqdm import tqdm


VERSION = "2026-08-26-v459-bump-wavelet-relative-commutator"
LOG2 = math.log(2.0)
EPS = np.finfo(float).eps


# =============================================================================
# Generic helpers
# =============================================================================

def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def fmt(x: float) -> str:
    return f"{float(x):.17g}"


def safe_rel(a: float, b: float, floor: float = 1e-14) -> float:
    return abs(float(a) - float(b)) / max(abs(float(a)), abs(float(b)), float(floor))


def json_safe(x):
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.ndarray):
        return [json_safe(v) for v in x.tolist()]
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    return x


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: Path) -> List[dict]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def power_integral(lo: float, hi: float, exponent: float) -> float:
    """Integral lo..hi s^exponent ds."""
    lo = float(lo)
    hi = float(hi)
    exponent = float(exponent)
    if abs(exponent + 1.0) < 1e-13:
        return math.log(hi / lo)
    return (hi ** (exponent + 1.0) - lo ** (exponent + 1.0)) / (exponent + 1.0)


def import_module(name: str):
    return importlib.import_module(str(name))


# =============================================================================
# Historical root nodes
# =============================================================================

def canonical_history_rows(paths: Sequence[Path]) -> List[dict]:
    """
    Merge v456 and v458 node files into canonical {mode, logX, E, source} rows.
    Later files overwrite duplicate mode/logX points, so v458 wins at its fresh
    interval if a duplicated endpoint is present.
    """
    merged: Dict[Tuple[int, float], dict] = {}
    for path in paths:
        if not path.exists():
            raise FileNotFoundError(path)
        for r in read_csv(path):
            if "mode" not in r or "E" not in r:
                continue
            if r.get("logX", "") not in ("", None):
                L = float(r["logX"])
            elif r.get("L", "") not in ("", None):
                L = float(r["L"])
            elif r.get("X", "") not in ("", None):
                L = math.log(float(r["X"]))
            else:
                continue
            mode = int(float(r["mode"]))
            E = float(r["E"])
            key = (mode, round(L, 10))
            merged[key] = {
                "mode": mode,
                "logX": L,
                "E": E,
                "source": path.name,
            }
    out = sorted(merged.values(), key=lambda z: (int(z["mode"]), float(z["logX"])))
    return out


def historical_root(nodes: Sequence[dict], mode: int, X: int, tol_L: float = 3e-6) -> float:
    target = math.log(float(X))
    rr = [r for r in nodes if int(r["mode"]) == int(mode)]
    if not rr:
        raise RuntimeError(f"no historical rows for mode {mode}")
    best = min(rr, key=lambda r: abs(float(r["logX"]) - target))
    gap = abs(float(best["logX"]) - target)
    if gap > float(tol_L):
        raise RuntimeError(
            f"no historical root close enough: mode={mode} X={X:,} "
            f"closest dlogX={gap:.3e} source={best.get('source')}"
        )
    return float(best["E"])


def endpoint_root_matrix(
    nodes: Sequence[dict], cutoffs: Sequence[int], modes: Sequence[int]
) -> Dict[int, Dict[int, float]]:
    return {
        int(X): {int(k): historical_root(nodes, int(k), int(X)) for k in modes}
        for X in cutoffs
    }


# =============================================================================
# Memory-aware segmented Mangoldt table
# =============================================================================

def simple_primes(limit: int) -> np.ndarray:
    limit = int(limit)
    if limit < 2:
        return np.empty(0, dtype=np.int64)
    s = np.ones(limit + 1, dtype=np.bool_)
    s[:2] = False
    r = int(math.isqrt(limit))
    for p in range(2, r + 1):
        if s[p]:
            s[p * p : limit + 1 : p] = False
    return np.flatnonzero(s).astype(np.int64)


def segmented_prime_chunks(lo: int, hi: int, segment_size: int) -> Iterable[np.ndarray]:
    lo = max(2, int(lo))
    hi = int(hi)
    if lo > hi:
        return
    base = simple_primes(int(math.isqrt(hi)))
    starts = list(range(lo, hi + 1, int(segment_size)))
    for start in tqdm(starts, desc=f"segmented primes {lo:,}->{hi:,}", unit="segment"):
        stop = min(hi, start + int(segment_size) - 1)
        mark = np.ones(stop - start + 1, dtype=np.bool_)
        for p0 in base:
            p = int(p0)
            pp = p * p
            if pp > stop:
                break
            first = max(pp, ((start + p - 1) // p) * p)
            mark[first - start :: p] = False
        if start <= 1:
            mark[: max(0, 2 - start)] = False
        yield np.flatnonzero(mark).astype(np.int64) + start


def prime_power_tail_terms(lo_exclusive: int, hi: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Composite prime powers p^m, m>=2, in (lo_exclusive, hi].
    Count is tiny compared with the primes, so Python lists are safe here.
    """
    lo_exclusive = int(lo_exclusive)
    hi = int(hi)
    base = simple_primes(int(math.isqrt(hi)))
    nums: List[int] = []
    vals: List[float] = []
    for p0 in base:
        p = int(p0)
        lp = math.log(float(p))
        q = p * p
        while q <= hi:
            if q > lo_exclusive:
                nums.append(q)
                vals.append(lp)
            if q > hi // p:
                break
            q *= p
    if not nums:
        return np.empty(0, np.int64), np.empty(0, float)
    order = np.argsort(np.asarray(nums, np.int64))
    return np.asarray(nums, np.int64)[order], np.asarray(vals, float)[order]


def build_mangoldt_segmented(limit: int, segment_size: int) -> Tuple[np.ndarray, np.ndarray]:
    limit = int(limit)
    chunks = list(segmented_prime_chunks(2, limit, segment_size))
    primes = np.concatenate(chunks) if chunks else np.empty(0, np.int64)
    lam_primes = np.log(primes.astype(np.float64))

    pp_n, pp_lam = prime_power_tail_terms(1, limit)
    if len(pp_n) == 0:
        return primes, lam_primes

    n = np.concatenate([primes, pp_n])
    lam = np.concatenate([lam_primes, pp_lam])
    order = np.argsort(n, kind="mergesort")
    return n[order], lam[order]


def extend_mangoldt_segmented(
    n_old: np.ndarray,
    lam_old: np.ndarray,
    old_limit: int,
    new_limit: int,
    segment_size: int,
) -> Tuple[np.ndarray, np.ndarray]:
    old_limit = int(old_limit)
    new_limit = int(new_limit)
    if new_limit <= old_limit:
        return n_old, lam_old

    chunks = list(segmented_prime_chunks(old_limit + 1, new_limit, segment_size))
    pnew = np.concatenate(chunks) if chunks else np.empty(0, np.int64)
    lpnew = np.log(pnew.astype(np.float64))
    pp_n, pp_lam = prime_power_tail_terms(old_limit, new_limit)

    if len(pp_n):
        nnew = np.concatenate([pnew, pp_n])
        lnew = np.concatenate([lpnew, pp_lam])
        order = np.argsort(nnew, kind="mergesort")
        nnew = nnew[order]
        lnew = lnew[order]
    else:
        nnew, lnew = pnew, lpnew

    # Every new term is > old_limit, hence concatenation preserves global order.
    return np.concatenate([n_old, nnew]), np.concatenate([lam_old, lnew])


def cache_path(prefix: Path, limit: int) -> Path:
    return Path(f"{prefix}_{int(limit)}.npz")


def load_or_build_training_mangoldt(
    limit: int, prefix: Path, segment_size: int
) -> Tuple[np.ndarray, np.ndarray, bool, Path]:
    path = cache_path(prefix, limit)
    if path.exists():
        with np.load(path, allow_pickle=False) as z:
            cached_limit = int(z["limit"])
            if cached_limit != int(limit):
                raise RuntimeError(f"cache limit mismatch in {path}")
            return np.asarray(z["n"], np.int64), np.asarray(z["lam"], float), True, path

    n, lam = build_mangoldt_segmented(int(limit), int(segment_size))
    np.savez(path, limit=np.asarray(int(limit), np.int64), n=n, lam=lam)
    return n, lam, False, path


def load_or_extend_fresh_mangoldt(
    n_train: np.ndarray,
    lam_train: np.ndarray,
    train_limit: int,
    fresh_limit: int,
    prefix: Path,
    segment_size: int,
) -> Tuple[np.ndarray, np.ndarray, bool, Path]:
    path = cache_path(prefix, fresh_limit)
    if path.exists():
        with np.load(path, allow_pickle=False) as z:
            cached_limit = int(z["limit"])
            if cached_limit != int(fresh_limit):
                raise RuntimeError(f"cache limit mismatch in {path}")
            return np.asarray(z["n"], np.int64), np.asarray(z["lam"], float), True, path

    n, lam = extend_mangoldt_segmented(
        n_train, lam_train, int(train_limit), int(fresh_limit), int(segment_size)
    )
    np.savez(path, limit=np.asarray(int(fresh_limit), np.int64), n=n, lam=lam)
    return n, lam, False, path


# =============================================================================
# Bump-2 p, q=-p'
# =============================================================================

def bump_p_x(x: np.ndarray) -> np.ndarray:
    xx = np.asarray(x, float)
    out = np.zeros_like(xx)
    mask = (xx >= 0.0) & (xx < 1.0)
    if not np.any(mask):
        return out
    a = xx[mask]
    gap = 1.0 - a
    r = a / gap
    expo = -(r * r)
    live = expo > -745.0
    vals = np.zeros_like(a)
    vals[live] = np.exp(expo[live])
    out[mask] = vals
    return out


def bump_q_x(x: np.ndarray) -> np.ndarray:
    """q(x)=-p'(x), evaluated without inf*0 near the flat endpoint."""
    xx = np.asarray(x, float)
    out = np.zeros_like(xx)
    mask = (xx > 0.0) & (xx < 1.0)
    if not np.any(mask):
        return out
    a = xx[mask]
    gap = 1.0 - a
    r = a / gap
    expo = -(r * r)
    live = expo > -745.0
    vals = np.zeros_like(a)
    if np.any(live):
        al = a[live]
        gl = gap[live]
        p = np.exp(expo[live])
        vals[live] = 2.0 * al * p / (gl ** 3)
    out[mask] = vals
    return out


def kernel_self_checks() -> dict:
    qhalf = float(bump_q_x(np.asarray([0.5]))[0])
    target = 8.0 / math.e

    # Numerical derivative check away from endpoints.
    x = np.linspace(0.02, 0.98, 2001)
    h = 1e-6
    dp = (bump_p_x(x + h) - bump_p_x(x - h)) / (2.0 * h)
    q = bump_q_x(x)
    deriv_rel = float(np.max(np.abs(dp + q) / np.maximum(1.0, np.abs(q))))

    # Exact structural masses from q endpoints:
    # int_0^(1/2) q' = q(1/2)-q(0)=8/e,
    # -int_(1/2)^1 q' = q(1/2)-q(1)=8/e.
    return {
        "q_half": qhalf,
        "q_half_target_8_over_e": target,
        "q_half_abs_error": abs(qhalf - target),
        "minus_pprime_numeric_max_scaled_error": deriv_rel,
        "early_qprime_mass": target,
        "late_minus_qprime_mass": target,
        "total_variation_qprime": 2.0 * target,
        "pass": bool(abs(qhalf - target) < 1e-13 and deriv_rel < 5e-8),
    }


# =============================================================================
# Vectorized bump-2 phase quantities
# =============================================================================

def make_phase(v452, n_all, lam_all, X, pnt_q, prime_chunk):
    idx = int(np.searchsorted(n_all, float(X), side="left"))
    return v452.FinitePartBump2(
        n_all[:idx], lam_all[:idx], float(X), int(pnt_q), int(prime_chunk)
    )


def vectorized_phase_quantities(
    v452, phase, E_values: np.ndarray, modes: Sequence[int], prime_chunk: int
) -> dict:
    """
    Vectorized copy of the v458 endpoint evaluator.
    One prime sin/cos pass per chunk for all requested energies.
    """
    E = np.asarray(E_values, float)
    nm = len(E)
    if len(modes) != nm:
        raise ValueError("modes must align with E_values")

    pp = np.zeros(nm)
    pe = np.zeros(nm)
    pl = np.zeros(nm)

    logs = np.asarray(phase.logs, float)
    wph = np.asarray(phase.w_phase, float)
    we = np.asarray(phase.w_E, float)
    wl = np.asarray(phase.w_L, float)

    pc = int(prime_chunk)
    for a in range(0, len(logs), pc):
        z = min(len(logs), a + pc)
        lg = logs[a:z]
        ang = np.outer(E, lg)
        s = np.sin(ang)
        c = np.cos(ang)
        pp += s @ wph[a:z]
        pl += s @ wl[a:z]
        pe += c @ we[a:z]

    yp = np.asarray(phase.y, float)
    angp = np.outer(E, yp)
    sp = np.sin(angp)
    cp = np.cos(angp)

    mp = sp @ np.asarray(phase.pnt_phase_w, float)
    ml = sp @ np.asarray(phase.pnt_L_w, float)
    me = cp @ np.asarray(phase.pnt_E_w, float)

    acp = np.asarray([v452.pnt_ac_phase(float(e)) for e in E], float)
    ace = np.asarray([v452.pnt_ac_phase_derivative(float(e)) for e in E], float)

    finite_phase = pp - mp + acp
    finite_E = pe - me + ace
    finite_L = pl - ml

    smooth = np.asarray([v452.smooth_count(float(e)) for e in E], float)
    smoothp = np.asarray([v452.smooth_count_prime(float(e)) for e in E], float)
    kval = np.asarray([float(k) - 0.5 for k in modes], float)

    f = smooth - finite_phase / math.pi - kval
    FE = smoothp - finite_E / math.pi
    FL = -finite_L / math.pi
    flow = -FL / FE

    return {
        "f": f,
        "FE": FE,
        "FL": FL,
        "flow": flow,
        "finite_L": finite_L,
        "finite_phase": finite_phase,
        "finite_E": finite_E,
    }


# =============================================================================
# Direct q-wavelet generator from centered prime-minus-PNT arithmetic
# =============================================================================

@dataclass
class QQuadrature:
    z: np.ndarray
    wg: np.ndarray


def make_q_quadrature(pnt_q: int) -> QQuadrature:
    z, wg = roots_legendre(int(pnt_q))
    return QQuadrature(np.asarray(z, float), np.asarray(wg, float))


def vectorized_cq_at_L(
    n_all: np.ndarray,
    lam_all: np.ndarray,
    logs_all: np.ndarray,
    invsqrt_all: np.ndarray,
    L: float,
    E_values: np.ndarray,
    quad: QQuadrature,
    prime_chunk: int,
) -> np.ndarray:
    """
    C_q(L,E)
      = sum Lambda(n)/sqrt(n) q(log n/L) sin(E log n)
        - int_(log2)^L e^(y/2) q(y/L) sin(Ey) dy.
    """
    L = float(L)
    E = np.asarray(E_values, float)
    X = math.exp(L)
    idx = int(np.searchsorted(n_all, X, side="left"))

    cq_prime = np.zeros(len(E), float)
    pc = int(prime_chunk)

    for a in range(0, idx, pc):
        z = min(idx, a + pc)
        lg = logs_all[a:z]
        qv = bump_q_x(lg / L)
        amp = lam_all[a:z] * invsqrt_all[a:z] * qv
        ang = np.outer(E, lg)
        cq_prime += np.sin(ang) @ amp

    # Gauss-Legendre PNT carrier on [log2,L].
    jac = 0.5 * (L - LOG2)
    y = jac * quad.z + 0.5 * (L + LOG2)
    qy = bump_q_x(y / L)
    pnt_w = jac * quad.wg * np.exp(0.5 * y) * qy
    cq_pnt = np.sin(np.outer(E, y)) @ pnt_w

    return cq_prime - cq_pnt


# =============================================================================
# Fast simultaneous fresh root solve
# =============================================================================

def free_spacings(free: np.ndarray, modes: Sequence[int]) -> np.ndarray:
    out = []
    for k0 in modes:
        k = int(k0)
        if k == 1:
            spacing = float(free[1] - free[0]) if len(free) > 1 else 2.0
        elif k < len(free):
            spacing = 0.5 * float(free[k] - free[k - 2])
        else:
            spacing = float(free[-1] - free[-2])
        out.append(max(0.25, 0.75 * spacing))
    return np.asarray(out, float)


def vectorized_newton_roots(
    v452,
    phase,
    modes: Sequence[int],
    seeds: np.ndarray,
    free: np.ndarray,
    prime_chunk: int,
    root_tol: float,
    max_newton: int,
    scan_points: int,
) -> Tuple[np.ndarray, dict]:
    E = np.asarray(seeds, float).copy()
    caps = free_spacings(free, modes)
    last = None

    for it in tqdm(range(int(max_newton)), desc="fresh vector Newton", unit="iter"):
        qv = vectorized_phase_quantities(v452, phase, E, modes, prime_chunk)
        last = qv
        maxr = float(np.max(np.abs(qv["f"])))
        if maxr <= float(root_tol) and np.all(np.diff(E) > 1e-8):
            return E, {
                "method": "vector_newton",
                "iterations": it,
                "maximum_residual": maxr,
                "minimum_abs_FE": float(np.min(np.abs(qv["FE"]))),
            }

        if np.any(~np.isfinite(qv["FE"])) or np.any(np.abs(qv["FE"]) < 1e-10):
            break

        step = np.clip(-qv["f"] / qv["FE"], -caps, caps)

        accepted = False
        factor = 1.0
        for _ in range(10):
            cand = E + factor * step
            if np.all(cand > 6.5) and np.all(np.diff(cand) > 1e-7):
                E = cand
                accepted = True
                break
            factor *= 0.5
        if not accepted:
            break

    # Conservative fallback: use v452's certified scalar locator in ordered mode.
    vals: List[float] = []
    prev_ordered = None
    for mi, k0 in enumerate(tqdm(modes, desc="fresh scalar fallback", unit="mode")):
        k = int(k0)
        if k == 1:
            spacing = float(free[1] - free[0]) if len(free) > 1 else 2.0
        elif k < len(free):
            spacing = 0.5 * float(free[k] - free[k - 2])
        else:
            spacing = float(free[-1] - free[-2])

        rr = v452.locate_root(
            phase,
            k,
            float(E[mi]),
            float(spacing),
            prev_ordered,
            float(root_tol),
            int(max_newton),
            int(scan_points),
        )
        if not rr.ok:
            raise RuntimeError(
                f"fresh root failed mode={k} X={phase.X:.12g}: "
                f"{rr.reason} residual={rr.residual:.3e}"
            )
        vals.append(float(rr.root))
        prev_ordered = float(rr.root)

    E = np.asarray(vals, float)
    qv = vectorized_phase_quantities(v452, phase, E, modes, prime_chunk)
    return E, {
        "method": "scalar_fallback",
        "iterations": int(max_newton),
        "maximum_residual": float(np.max(np.abs(qv["f"]))),
        "minimum_abs_FE": float(np.min(np.abs(qv["FE"]))),
    }


# =============================================================================
# Interval analysis
# =============================================================================

def analyze_interval(
    *,
    stage: str,
    interval_index: int,
    v452,
    n_all: np.ndarray,
    lam_all: np.ndarray,
    logs_all: np.ndarray,
    invsqrt_all: np.ndarray,
    Xa: int,
    Xb: int,
    modes: Sequence[int],
    E_left: np.ndarray,
    E_right: np.ndarray,
    pnt_q: int,
    prime_chunk: int,
    wavelet_nodes: int,
    quad: QQuadrature,
    phase_right_prebuilt=None,
) -> Tuple[List[dict], List[dict], dict]:
    La = math.log(float(Xa))
    Lb = math.log(float(Xb))

    # Left endpoint: roots E_left.
    ph_a = make_phase(v452, n_all, lam_all, Xa, pnt_q, prime_chunk)
    qa = vectorized_phase_quantities(v452, ph_a, E_left, modes, prime_chunk)
    del ph_a

    # Right endpoint: evaluate frozen-left energies and actual right roots in ONE pass.
    if phase_right_prebuilt is None:
        ph_b = make_phase(v452, n_all, lam_all, Xb, pnt_q, prime_chunk)
    else:
        ph_b = phase_right_prebuilt

    Ecat = np.concatenate([E_left, E_right])
    mcat = list(modes) + list(modes)
    qbcat = vectorized_phase_quantities(v452, ph_b, Ecat, mcat, prime_chunk)
    nm = len(modes)
    qb0 = {k: np.asarray(v[:nm]) for k, v in qbcat.items()}
    qb1 = {k: np.asarray(v[nm:]) for k, v in qbcat.items()}

    if phase_right_prebuilt is None:
        del ph_b

    # Direct q=-p' identity at the two endpoints.
    cq_left_direct = vectorized_cq_at_L(
        n_all, lam_all, logs_all, invsqrt_all, La, E_left, quad, prime_chunk
    )
    cq_right_frozen_direct = vectorized_cq_at_L(
        n_all, lam_all, logs_all, invsqrt_all, Lb, E_left, quad, prime_chunk
    )
    cq_left_from_phase = (La * La) * qa["finite_L"]
    cq_right_from_phase = (Lb * Lb) * qb0["finite_L"]

    cq_identity_rel = np.maximum(
        np.abs(cq_left_direct - cq_left_from_phase)
        / np.maximum(np.maximum(np.abs(cq_left_direct), np.abs(cq_left_from_phase)), 1e-12),
        np.abs(cq_right_frozen_direct - cq_right_from_phase)
        / np.maximum(
            np.maximum(np.abs(cq_right_frozen_direct), np.abs(cq_right_from_phase)), 1e-12
        ),
    )

    # Frozen-energy wavelet integral across the whole dyadic interval.
    Lgrid = np.linspace(La, Lb, int(wavelet_nodes))
    cq_grid = np.empty((len(Lgrid), nm), float)

    for ii, L in enumerate(
        tqdm(Lgrid, desc=f"{stage} wavelet {Xa:,}->{Xb:,}", unit="node")
    ):
        cq_grid[ii, :] = vectorized_cq_at_L(
            n_all,
            lam_all,
            logs_all,
            invsqrt_all,
            float(L),
            E_left,
            quad,
            prime_chunk,
        )

    A_wavelet = -(1.0 / math.pi) * simpson(
        cq_grid / (Lgrid[:, None] ** 2), x=Lgrid, axis=0
    )
    cq_peak = np.max(np.abs(cq_grid), axis=0)

    rows: List[dict] = []
    node_rows: List[dict] = []

    max_root_res = 0.0
    max_secant_gap = 0.0
    max_wavelet_gap = 0.0
    max_cq_identity = 0.0

    for mi, k0 in enumerate(modes):
        k = int(k0)
        dE = float(E_right[mi] - E_left[mi])
        A = float(qb0["f"][mi] - qa["f"][mi])

        if abs(dE) > 1e-15:
            Dstar = float((qb1["f"][mi] - qb0["f"][mi]) / dE)
            delta_from_A = float(-A / Dstar) if abs(Dstar) > 1e-15 else float("nan")
        else:
            Dstar = float(qb0["FE"][mi])
            delta_from_A = 0.0

        secant_gap = abs(delta_from_A - dE)
        wavelet_gap = abs(float(A_wavelet[mi]) - A)

        root_res = max(abs(float(qa["f"][mi])), abs(float(qb1["f"][mi])))
        max_root_res = max(max_root_res, root_res)
        max_secant_gap = max(max_secant_gap, secant_gap)
        max_wavelet_gap = max(max_wavelet_gap, wavelet_gap)
        max_cq_identity = max(max_cq_identity, float(cq_identity_rel[mi]))

        rows.append(
            {
                "stage": stage,
                "interval": int(interval_index),
                "Xa": int(Xa),
                "Xb": int(Xb),
                "mode": k,
                "L_left": fmt(La),
                "L_right": fmt(Lb),
                "E_left": fmt(E_left[mi]),
                "E_right": fmt(E_right[mi]),
                "actual_delta_E": fmt(dE),
                "abs_delta_E": fmt(abs(dE)),
                "f_left_root": fmt(qa["f"][mi]),
                "f_right_root": fmt(qb1["f"][mi]),
                "f_right_at_frozen_left_E": fmt(qb0["f"][mi]),
                "direct_commutator_A": fmt(A),
                "abs_direct_commutator_A": fmt(abs(A)),
                "secant_Dstar": fmt(Dstar),
                "abs_secant_Dstar": fmt(abs(Dstar)),
                "delta_from_direct_commutator": fmt(delta_from_A),
                "secant_prediction_abs_gap": fmt(secant_gap),
                "wavelet_integral_A": fmt(A_wavelet[mi]),
                "wavelet_integral_abs_gap": fmt(wavelet_gap),
                "sampled_Cq_peak": fmt(cq_peak[mi]),
                "Cq_left_direct": fmt(cq_left_direct[mi]),
                "Cq_left_from_L2_finitepart_L": fmt(cq_left_from_phase[mi]),
                "Cq_right_frozen_direct": fmt(cq_right_frozen_direct[mi]),
                "Cq_right_from_L2_finitepart_L": fmt(cq_right_from_phase[mi]),
                "Cq_identity_relative": fmt(cq_identity_rel[mi]),
                "FE_left": fmt(qa["FE"][mi]),
                "FE_right": fmt(qb1["FE"][mi]),
                "minimum_endpoint_abs_FE": fmt(
                    min(abs(float(qa["FE"][mi])), abs(float(qb1["FE"][mi])))
                ),
            }
        )

        for ii, L in enumerate(Lgrid):
            node_rows.append(
                {
                    "stage": stage,
                    "interval": int(interval_index),
                    "Xa": int(Xa),
                    "Xb": int(Xb),
                    "mode": k,
                    "node": int(ii),
                    "L": fmt(L),
                    "X": fmt(math.exp(float(L))),
                    "E_frozen": fmt(E_left[mi]),
                    "Cq": fmt(cq_grid[ii, mi]),
                    "abs_Cq": fmt(abs(cq_grid[ii, mi])),
                    "Cq_over_L2": fmt(cq_grid[ii, mi] / (L * L)),
                }
            )

    diagnostics = {
        "maximum_root_residual": max_root_res,
        "maximum_secant_prediction_abs_gap": max_secant_gap,
        "maximum_wavelet_integral_abs_gap": max_wavelet_gap,
        "maximum_Cq_identity_relative": max_cq_identity,
    }
    return rows, node_rows, diagnostics


# =============================================================================
# Fixed-exponent envelope freezing
# =============================================================================

def freeze_models(
    rows: Sequence[dict],
    modes: Sequence[int],
    *,
    a: float,
    p: float,
    blocked_intervals: int,
    envelope_safety: float,
) -> Tuple[dict, dict]:
    """
    Fixed relation:
        b = 2 + a - p
        r = p - a  so |A| <= C_A L^-r
    """
    b = 2.0 + float(a) - float(p)
    r = float(p) - float(a)

    models = {}
    blocked_all = True

    for k0 in modes:
        k = int(k0)
        rr = sorted(
            [z for z in rows if int(z["mode"]) == k],
            key=lambda z: int(z["interval"]),
        )
        if len(rr) <= int(blocked_intervals):
            raise RuntimeError(
                f"mode {k}: need more training intervals than blocked_intervals"
            )
        dev = len(rr) - int(blocked_intervals)

        L = np.asarray([float(z["L_left"]) for z in rr], float)
        A = np.asarray([float(z["abs_direct_commutator_A"]) for z in rr], float)
        Cq = np.asarray([float(z["sampled_Cq_peak"]) for z in rr], float)
        D = np.asarray([float(z["abs_secant_Dstar"]) for z in rr], float)

        # |A| <= C_A L^-r.
        scaled_A = A * (L ** r)
        C_A_dev = float(envelope_safety * np.max(scaled_A[:dev]))
        A_pred_block = C_A_dev * (L[dev:] ** (-r))
        A_ratio_block = A[dev:] / np.maximum(A_pred_block, 1e-300)
        A_block_pass = bool(np.all(A_ratio_block <= 1.0))

        # |Cq| <= C_q L^b.
        scaled_Cq = Cq / np.maximum(L ** b, 1e-300)
        C_q_dev = float(envelope_safety * np.max(scaled_Cq[:dev]))
        Cq_pred_block = C_q_dev * (L[dev:] ** b)
        Cq_ratio_block = Cq[dev:] / np.maximum(Cq_pred_block, 1e-300)
        Cq_block_pass = bool(np.all(Cq_ratio_block <= 1.0))

        # |D*| >= d L^a.
        scaled_D = D / np.maximum(L ** a, 1e-300)
        d_dev = float(np.min(scaled_D[:dev]) / envelope_safety)
        D_floor_block = d_dev * (L[dev:] ** a)
        D_ratio_block = D_floor_block / np.maximum(D[dev:], 1e-300)
        D_block_pass = bool(np.all(D_ratio_block <= 1.0))

        # Final training-only constants frozen for fresh prediction.
        C_A_final = float(envelope_safety * np.max(scaled_A))
        C_q_final = float(envelope_safety * np.max(scaled_Cq))
        d_final = float(np.min(scaled_D) / envelope_safety)

        mode_pass = bool(A_block_pass and Cq_block_pass and D_block_pass)
        blocked_all &= mode_pass

        models[str(k)] = {
            "mode": k,
            "fixed_exponents": {
                "stiffness_a": float(a),
                "increment_p": float(p),
                "wavelet_b": float(b),
                "commutator_decay_r": float(r),
                "identity_p_equals_2_plus_a_minus_b": float(2.0 + a - b),
            },
            "development_intervals": int(dev),
            "blocked_intervals": int(blocked_intervals),
            "envelope_safety": float(envelope_safety),
            "commutator": {
                "C_dev": C_A_dev,
                "C_final": C_A_final,
                "blocked_max_ratio": float(np.max(A_ratio_block)),
                "blocked_pass": A_block_pass,
                "training_scaled": [float(x) for x in scaled_A],
            },
            "wavelet": {
                "C_dev": C_q_dev,
                "C_final": C_q_final,
                "blocked_max_ratio": float(np.max(Cq_ratio_block)),
                "blocked_pass": Cq_block_pass,
                "training_scaled": [float(x) for x in scaled_Cq],
            },
            "stiffness": {
                "d_dev": d_dev,
                "d_final": d_final,
                "blocked_max_floor_ratio": float(np.max(D_ratio_block)),
                "blocked_pass": D_block_pass,
                "training_scaled": [float(x) for x in scaled_D],
            },
            "blocked_pass": mode_pass,
        }

    meta = {
        "a": float(a),
        "p": float(p),
        "b": float(b),
        "r": float(r),
        "summable_increment_exponent": bool(p > 1.0),
        "wavelet_gap_condition_b_less_1_plus_a": bool(b < 1.0 + a),
        "blocked_all_modes": bool(blocked_all),
    }
    return models, meta


# =============================================================================
# Main
# =============================================================================

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v452-module",
        default="rot_rh_bump2_finite_part_source_flow_v452",
    )
    ap.add_argument(
        "--v456-nodes",
        default="rot_rh_bump2_packet_fourier_cancellation_v456_PACKET_PHASE_NODES.csv",
    )
    ap.add_argument(
        "--v458-fresh-nodes",
        default="rot_rh_fixed_exponent_dyadic_cauchy_v458_FRESH_FLOW_NODES.csv",
    )
    ap.add_argument(
        "--training-cutoffs",
        default=(
            "2332800,4665600,9331200,18662400,"
            "37324800,74649600,149299200"
        ),
    )
    ap.add_argument(
        "--fresh-holdout",
        type=int,
        default=298598400,
        help="Must be approximately 2x the final training cutoff.",
    )
    ap.add_argument("--modes", default="1,2,4,8,12,16,24,32")

    # Frozen theorem exponents.
    ap.add_argument(
        "--stiffness-exponent",
        type=float,
        default=0.0,
        help="Frozen a in |D*| >= d L^a. Default assumes only a positive floor.",
    )
    ap.add_argument(
        "--increment-exponent",
        type=float,
        default=1.10,
        help="Frozen desired p>1 in |Delta E| <= C L^-p.",
    )

    ap.add_argument("--blocked-intervals", type=int, default=2)
    ap.add_argument("--envelope-safety", type=float, default=2.0)

    # Numerical controls.
    ap.add_argument("--wavelet-nodes", type=int, default=7)
    ap.add_argument("--pnt-q", type=int, default=2048)
    ap.add_argument("--prime-chunk", type=int, default=250000)
    ap.add_argument("--segment-size", type=int, default=5_000_000)
    ap.add_argument(
        "--prime-cache-prefix",
        default="rot_rh_mangoldt_segmented_cache",
    )
    ap.add_argument("--root-tol", type=float, default=2e-9)
    ap.add_argument("--max-newton", type=int, default=10)
    ap.add_argument("--scan-points", type=int, default=65)

    # Gates.
    ap.add_argument("--maximum-root-residual", type=float, default=2e-7)
    ap.add_argument("--maximum-secant-absolute-gap", type=float, default=2e-7)
    ap.add_argument("--maximum-wavelet-relative-gap", type=float, default=5e-3)
    ap.add_argument("--maximum-wavelet-absolute-gap", type=float, default=2e-7)
    ap.add_argument("--maximum-Cq-identity-relative", type=float, default=2e-7)
    ap.add_argument("--maximum-fresh-ratio", type=float, default=1.0)

    ap.add_argument(
        "--prefix",
        default="rot_rh_bump_wavelet_relative_commutator_v459",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.time()
    cutoffs = parse_ints(args.training_cutoffs)
    modes = sorted(set(parse_ints(args.modes)))
    if len(cutoffs) < 5 or cutoffs != sorted(cutoffs):
        raise ValueError("--training-cutoffs must have >=5 increasing values")
    if args.fresh_holdout <= cutoffs[-1]:
        raise ValueError("--fresh-holdout must exceed final training cutoff")
    if abs(args.fresh_holdout / cutoffs[-1] - 2.0) > 0.02:
        raise ValueError("--fresh-holdout must be approximately a dyadic doubling")
    if args.increment_exponent <= 1.0:
        raise ValueError("--increment-exponent must be >1")
    if args.wavelet_nodes < 5 or args.wavelet_nodes % 2 == 0:
        raise ValueError("--wavelet-nodes must be odd and >=5")
    if args.blocked_intervals < 1 or args.blocked_intervals >= len(cutoffs) - 1:
        raise ValueError("invalid --blocked-intervals")

    aexp = float(args.stiffness_exponent)
    pexp = float(args.increment_exponent)
    bexp = 2.0 + aexp - pexp
    rexp = pexp - aexp
    if not bexp < 1.0 + aexp:
        raise ValueError("fixed exponents do not imply a summable root increment")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    cache_prefix = Path(args.prime_cache_prefix).expanduser().resolve()

    v452 = import_module(args.v452_module)

    print("=" * 174)
    print("ROT-RH v459 — BUMP-WAVELET HEAD / RELATIVE COMMUTATOR PROSPECTIVE AUDIT")
    print("=" * 174)
    print("Xi / zeta / zeta' / known zero ordinates : NONE")
    print("v452 module                               :", Path(v452.__file__).name)
    print("training cutoffs                          :", cutoffs)
    print("fresh unseen cutoff                       :", f"{args.fresh_holdout:,}")
    print("modes                                     :", modes)
    print("fixed stiffness exponent a                :", aexp)
    print("fixed root increment exponent p           :", pexp)
    print("derived wavelet exponent b=2+a-p          :", bexp)
    print("derived commutator decay r=p-a            :", rexp)
    print("summability margin p-1                    :", pexp - 1.0)
    print("wavelet theorem condition b<1+a           :", bexp < 1.0 + aexp)
    print("=" * 174)

    # -------------------------------------------------------------------------
    # A. Exact kernel checks + historical roots
    # -------------------------------------------------------------------------
    print("\n[A] Exact bump-wavelet kernel and historical root lineage")
    kcheck = kernel_self_checks()
    print("  q(1/2) vs 8/e                          :", kcheck["q_half"], "/", kcheck["q_half_target_8_over_e"])
    print("  numerical q=-p' scaled error           :", f"{kcheck['minus_pprime_numeric_max_scaled_error']:.3e}")
    print("  kernel check pass                       :", kcheck["pass"])

    history_paths = [Path(args.v456_nodes), Path(args.v458_fresh_nodes)]
    hist = canonical_history_rows(history_paths)
    roots = endpoint_root_matrix(hist, cutoffs, modes)
    print("  historical canonical nodes             :", len(hist))
    print("  training endpoint roots resolved        :", len(cutoffs) * len(modes))

    # -------------------------------------------------------------------------
    # B. TRAINING arithmetic only -- no fresh data yet.
    # -------------------------------------------------------------------------
    train_max = int(cutoffs[-1])
    print("\n[B] Building/loading TRAINING Mangoldt table only through", f"{train_max:,}")
    n_train, lam_train, training_cache_hit, training_cache_path = (
        load_or_build_training_mangoldt(
            train_max, cache_prefix, int(args.segment_size)
        )
    )
    print("  training cache hit                      :", training_cache_hit)
    print("  training Mangoldt terms                 :", f"{len(n_train):,}")
    print("  training cache                          :", training_cache_path)

    logs_train = np.log(n_train.astype(np.float64))
    invsqrt_train = 1.0 / np.sqrt(n_train.astype(np.float64))
    quad = make_q_quadrature(args.pnt_q)

    # -------------------------------------------------------------------------
    # C. Recompute all training commutators / wavelet generators.
    # -------------------------------------------------------------------------
    print("\n[C] Recomputing TRAINING direct commutators and q-wavelet generators")
    training_rows: List[dict] = []
    training_wavelet_nodes: List[dict] = []

    train_diag = {
        "maximum_root_residual": 0.0,
        "maximum_secant_prediction_abs_gap": 0.0,
        "maximum_wavelet_integral_abs_gap": 0.0,
        "maximum_Cq_identity_relative": 0.0,
    }

    for j, (Xa, Xb) in enumerate(zip(cutoffs[:-1], cutoffs[1:])):
        E0 = np.asarray([roots[Xa][k] for k in modes], float)
        E1 = np.asarray([roots[Xb][k] for k in modes], float)
        rr, nr, dg = analyze_interval(
            stage="TRAIN",
            interval_index=j,
            v452=v452,
            n_all=n_train,
            lam_all=lam_train,
            logs_all=logs_train,
            invsqrt_all=invsqrt_train,
            Xa=Xa,
            Xb=Xb,
            modes=modes,
            E_left=E0,
            E_right=E1,
            pnt_q=args.pnt_q,
            prime_chunk=args.prime_chunk,
            wavelet_nodes=args.wavelet_nodes,
            quad=quad,
        )
        training_rows.extend(rr)
        training_wavelet_nodes.extend(nr)
        for key in train_diag:
            train_diag[key] = max(train_diag[key], float(dg[key]))

    # -------------------------------------------------------------------------
    # D. Freeze theorem envelopes BEFORE fresh arithmetic exists.
    # -------------------------------------------------------------------------
    print("\n[D] Freezing fixed-exponent theorem envelopes BEFORE fresh reveal")
    models, exponent_meta = freeze_models(
        training_rows,
        modes,
        a=aexp,
        p=pexp,
        blocked_intervals=args.blocked_intervals,
        envelope_safety=args.envelope_safety,
    )

    for k in modes:
        m = models[str(k)]
        print(
            f"  k={k:<3d} "
            f"Ablock={m['commutator']['blocked_max_ratio']:.3f} "
            f"Cqblock={m['wavelet']['blocked_max_ratio']:.3f} "
            f"Dblock={m['stiffness']['blocked_max_floor_ratio']:.3f} "
            f"pass={m['blocked_pass']}"
        )

    freeze = {
        "version": VERSION,
        "frozen_before_fresh_holdout": True,
        "v452_module": args.v452_module,
        "v452_sha256": sha256_file(Path(v452.__file__).resolve()),
        "history_inputs": {
            str(p): sha256_file(p) for p in history_paths
        },
        "training_cutoffs": cutoffs,
        "fresh_holdout": int(args.fresh_holdout),
        "modes": modes,
        "kernel_identity": kcheck,
        "fixed_exponents": exponent_meta,
        "models": models,
        "training_diagnostics": train_diag,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "zeta_log_derivative_used": False,
            "known_zero_ordinates_used": False,
            "fresh_prime_table_built": False,
            "fresh_endpoint_root_solved": False,
        },
        "arguments": vars(args),
    }
    freeze_path = Path(str(prefix) + "_PRE_HOLDOUT_FREEZE.json")
    freeze_path.write_text(json.dumps(json_safe(freeze), indent=2), encoding="utf-8")
    freeze_sha = sha256_file(freeze_path)
    print("  PRE-HOLDOUT SHA256                     :", freeze_sha)

    # Save training diagnostics before fresh reveal too.
    training_path = Path(str(prefix) + "_TRAINING_INTERVALS.csv")
    training_nodes_path = Path(str(prefix) + "_TRAINING_WAVELET_NODES.csv")
    write_csv(training_path, training_rows)
    write_csv(training_nodes_path, training_wavelet_nodes)

    # -------------------------------------------------------------------------
    # E. NOW reveal/construct the genuinely fresh dyadic extension.
    # -------------------------------------------------------------------------
    fresh = int(args.fresh_holdout)
    print("\n[E] PRE-HOLDOUT FREEZE COMPLETE. Revealing fresh arithmetic", f"{train_max:,}->{fresh:,}")
    n_fresh, lam_fresh, fresh_cache_hit, fresh_cache_path = load_or_extend_fresh_mangoldt(
        n_train,
        lam_train,
        train_max,
        fresh,
        cache_prefix,
        int(args.segment_size),
    )
    print("  fresh cache hit                         :", fresh_cache_hit)
    print("  fresh Mangoldt terms                    :", f"{len(n_fresh):,}")
    print("  fresh cache                             :", fresh_cache_path)

    # Release training-only derived arrays before allocating full fresh arrays.
    del logs_train, invsqrt_train
    logs_fresh = np.log(n_fresh.astype(np.float64))
    invsqrt_fresh = 1.0 / np.sqrt(n_fresh.astype(np.float64))

    # -------------------------------------------------------------------------
    # F. Solve fresh endpoint, vectorized first.
    # -------------------------------------------------------------------------
    print("\n[F] Solving genuinely fresh endpoint roots")
    E_left = np.asarray([roots[train_max][k] for k in modes], float)
    free = v452.free_archimedean_levels(max(modes))

    ph_fresh = make_phase(
        v452, n_fresh, lam_fresh, fresh, args.pnt_q, args.prime_chunk
    )
    E_right, root_solver = vectorized_newton_roots(
        v452,
        ph_fresh,
        modes,
        E_left,
        free,
        args.prime_chunk,
        args.root_tol,
        args.max_newton,
        args.scan_points,
    )
    print("  fresh root method                        :", root_solver["method"])
    print("  fresh maximum residual                  :", f"{root_solver['maximum_residual']:.3e}")
    print("  fresh minimum |F_E|                     :", f"{root_solver['minimum_abs_FE']:.6e}")

    # Analyze the fresh interval while reusing the already-built right phase.
    fresh_rows, fresh_wavelet_nodes, fresh_diag = analyze_interval(
        stage="FRESH",
        interval_index=len(cutoffs) - 1,
        v452=v452,
        n_all=n_fresh,
        lam_all=lam_fresh,
        logs_all=logs_fresh,
        invsqrt_all=invsqrt_fresh,
        Xa=train_max,
        Xb=fresh,
        modes=modes,
        E_left=E_left,
        E_right=E_right,
        pnt_q=args.pnt_q,
        prime_chunk=args.prime_chunk,
        wavelet_nodes=args.wavelet_nodes,
        quad=quad,
        phase_right_prebuilt=ph_fresh,
    )
    del ph_fresh

    # -------------------------------------------------------------------------
    # G. Score fresh interval against frozen theorem.
    # -------------------------------------------------------------------------
    print("\n[G] Scoring FRESH interval against frozen Bump-Wavelet theorem")
    La = math.log(float(train_max))
    Lb = math.log(float(fresh))
    scores: List[dict] = []
    all_mode_pass = True

    fresh_by_mode = {int(r["mode"]): r for r in fresh_rows}

    for k in modes:
        r = fresh_by_mode[int(k)]
        m = models[str(k)]

        A_actual = float(r["abs_direct_commutator_A"])
        Cq_actual = float(r["sampled_Cq_peak"])
        D_actual = float(r["abs_secant_Dstar"])
        dE_actual = float(r["abs_delta_E"])

        C_A = float(m["commutator"]["C_final"])
        C_q = float(m["wavelet"]["C_final"])
        d = float(m["stiffness"]["d_final"])

        A_upper = C_A * (La ** (-rexp))
        Cq_upper = C_q * (La ** bexp)
        D_floor = d * (La ** aexp)

        # Direct-commutator consequence.
        delta_upper_direct = A_upper / max(D_floor, 1e-300)

        # Wavelet consequence using the exact integral of s^(b-2).
        wavelet_A_upper = (
            C_q
            / math.pi
            * power_integral(La, Lb, bexp - 2.0)
        )
        delta_upper_wavelet = wavelet_A_upper / max(D_floor, 1e-300)

        rA = A_actual / max(A_upper, 1e-300)
        rCq = Cq_actual / max(Cq_upper, 1e-300)
        rD = D_floor / max(D_actual, 1e-300)
        rDeltaDirect = dE_actual / max(delta_upper_direct, 1e-300)
        rDeltaWavelet = dE_actual / max(delta_upper_wavelet, 1e-300)

        wavelet_gap = float(r["wavelet_integral_abs_gap"])
        wavelet_rel = safe_rel(
            float(r["wavelet_integral_A"]),
            float(r["direct_commutator_A"]),
            1e-12,
        )
        wavelet_identity_pass = bool(
            wavelet_gap <= args.maximum_wavelet_absolute_gap
            or wavelet_rel <= args.maximum_wavelet_relative_gap
        )

        cq_identity_pass = bool(
            float(r["Cq_identity_relative"]) <= args.maximum_Cq_identity_relative
        )
        root_pass = bool(
            max(abs(float(r["f_left_root"])), abs(float(r["f_right_root"])))
            <= args.maximum_root_residual
        )
        secant_pass = bool(
            float(r["secant_prediction_abs_gap"]) <= args.maximum_secant_absolute_gap
        )

        mode_pass = bool(
            rA <= args.maximum_fresh_ratio
            and rCq <= args.maximum_fresh_ratio
            and rD <= args.maximum_fresh_ratio
            and rDeltaDirect <= args.maximum_fresh_ratio
            and rDeltaWavelet <= args.maximum_fresh_ratio
            and wavelet_identity_pass
            and cq_identity_pass
            and root_pass
            and secant_pass
        )
        all_mode_pass &= mode_pass

        scores.append(
            {
                "mode": int(k),
                "L_left": fmt(La),
                "fixed_a": fmt(aexp),
                "fixed_p": fmt(pexp),
                "derived_b": fmt(bexp),
                "derived_r": fmt(rexp),
                "actual_abs_A": fmt(A_actual),
                "A_upper": fmt(A_upper),
                "A_ratio": fmt(rA),
                "A_pass": bool(rA <= args.maximum_fresh_ratio),
                "actual_sampled_Cq_peak": fmt(Cq_actual),
                "Cq_upper": fmt(Cq_upper),
                "Cq_ratio": fmt(rCq),
                "Cq_pass": bool(rCq <= args.maximum_fresh_ratio),
                "actual_abs_Dstar": fmt(D_actual),
                "Dstar_floor": fmt(D_floor),
                "Dstar_floor_ratio": fmt(rD),
                "Dstar_pass": bool(rD <= args.maximum_fresh_ratio),
                "actual_abs_delta_E": fmt(dE_actual),
                "delta_upper_direct": fmt(delta_upper_direct),
                "delta_direct_ratio": fmt(rDeltaDirect),
                "delta_direct_pass": bool(rDeltaDirect <= args.maximum_fresh_ratio),
                "delta_upper_wavelet": fmt(delta_upper_wavelet),
                "delta_wavelet_ratio": fmt(rDeltaWavelet),
                "delta_wavelet_pass": bool(rDeltaWavelet <= args.maximum_fresh_ratio),
                "wavelet_integral_relative_gap": fmt(wavelet_rel),
                "wavelet_integral_absolute_gap": fmt(wavelet_gap),
                "wavelet_identity_pass": wavelet_identity_pass,
                "Cq_identity_relative": r["Cq_identity_relative"],
                "Cq_identity_pass": cq_identity_pass,
                "root_pass": root_pass,
                "secant_pass": secant_pass,
                "mode_pass": mode_pass,
            }
        )

        print(
            f"  k={k:<3d} "
            f"A={rA:.3f} Cq={rCq:.3f} D={rD:.3f} "
            f"dE(dir)={rDeltaDirect:.3f} dE(wav)={rDeltaWavelet:.3f} "
            f"Wid={wavelet_rel:.2e} pass={mode_pass}"
        )

    # -------------------------------------------------------------------------
    # H. Global gates and verdict
    # -------------------------------------------------------------------------
    training_identity_pass = bool(
        train_diag["maximum_root_residual"] <= args.maximum_root_residual
        and train_diag["maximum_secant_prediction_abs_gap"]
        <= args.maximum_secant_absolute_gap
        and (
            train_diag["maximum_wavelet_integral_abs_gap"]
            <= args.maximum_wavelet_absolute_gap
            or all(
                safe_rel(
                    float(r["wavelet_integral_A"]),
                    float(r["direct_commutator_A"]),
                    1e-12,
                )
                <= args.maximum_wavelet_relative_gap
                for r in training_rows
            )
        )
        and train_diag["maximum_Cq_identity_relative"]
        <= args.maximum_Cq_identity_relative
    )

    fresh_identity_pass = bool(
        fresh_diag["maximum_root_residual"] <= args.maximum_root_residual
        and fresh_diag["maximum_secant_prediction_abs_gap"]
        <= args.maximum_secant_absolute_gap
        and fresh_diag["maximum_Cq_identity_relative"]
        <= args.maximum_Cq_identity_relative
    )

    blocked_pass = bool(exponent_meta["blocked_all_modes"])
    exponent_pass = bool(
        exponent_meta["summable_increment_exponent"]
        and exponent_meta["wavelet_gap_condition_b_less_1_plus_a"]
    )

    if not kcheck["pass"]:
        verdict = "BUMP_KERNEL_IDENTITY_FAILED"
    elif not exponent_pass:
        verdict = "FIXED_EXPONENT_THEOREM_NOT_SUMMABLE"
    elif not training_identity_pass:
        verdict = "TRAINING_EXACT_IDENTITY_GATE_FAILED"
    elif not blocked_pass:
        verdict = "TRAINING_BLOCKED_BUMP_WAVELET_ENVELOPE_FAILED"
    elif not fresh_identity_pass:
        verdict = "FRESH_EXACT_IDENTITY_GATE_FAILED"
    elif not all_mode_pass:
        verdict = "FRESH_BUMP_WAVELET_RELATIVE_COMMUTATOR_HOLDOUT_FAILED"
    else:
        verdict = "BUMP_WAVELET_RELATIVE_COMMUTATOR_SUPPORTED_PROSPECTIVELY"

    # Outputs.
    fresh_path = Path(str(prefix) + "_FRESH_INTERVAL.csv")
    fresh_nodes_path = Path(str(prefix) + "_FRESH_WAVELET_NODES.csv")
    fresh_roots_path = Path(str(prefix) + "_FRESH_ROOTS.csv")
    score_path = Path(str(prefix) + "_FRESH_SCORE.csv")
    summary_path = Path(str(prefix) + "_SUMMARY.json")
    theorem_path = Path(str(prefix) + "_THEOREM.md")

    write_csv(fresh_path, fresh_rows)
    write_csv(fresh_nodes_path, fresh_wavelet_nodes)
    write_csv(score_path, scores)
    write_csv(
        fresh_roots_path,
        [
            {
                "mode": int(k),
                "X_left": train_max,
                "E_left": fmt(E_left[mi]),
                "X_fresh": fresh,
                "E_fresh": fmt(E_right[mi]),
                "delta_E": fmt(E_right[mi] - E_left[mi]),
            }
            for mi, k in enumerate(modes)
        ],
    )

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "runtime_seconds": time.time() - started,
        "scientific_boundary": (
            "Prospective finite arithmetic evidence only. No all-L wavelet or "
            "transversality theorem is proved; this is not RH and not a complete "
            "Hilbert-Polya theorem."
        ),
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "zeta_log_derivative_used": False,
            "known_zero_ordinates_used": False,
            "fresh_arithmetic_constructed_only_after_freeze": True,
        },
        "pre_holdout_freeze_sha256": freeze_sha,
        "training_cutoffs": cutoffs,
        "fresh_holdout": fresh,
        "modes": modes,
        "kernel_checks": kcheck,
        "fixed_exponents": exponent_meta,
        "training_diagnostics": train_diag,
        "fresh_diagnostics": fresh_diag,
        "root_solver": root_solver,
        "training_cache": {
            "path": str(training_cache_path),
            "hit": training_cache_hit,
            "terms": len(n_train),
        },
        "fresh_cache": {
            "path": str(fresh_cache_path),
            "hit": fresh_cache_hit,
            "terms": len(n_fresh),
        },
        "gates": {
            "kernel_identity_pass": bool(kcheck["pass"]),
            "fixed_exponent_summability_pass": exponent_pass,
            "training_exact_identity_pass": training_identity_pass,
            "training_blocked_envelope_pass": blocked_pass,
            "fresh_exact_identity_pass": fresh_identity_pass,
            "fresh_all_mode_pass": all_mode_pass,
        },
        "models": models,
        "fresh_scores": scores,
        "outputs": [
            str(freeze_path),
            str(training_path),
            str(training_nodes_path),
            str(fresh_path),
            str(fresh_nodes_path),
            str(fresh_roots_path),
            str(score_path),
            str(summary_path),
            str(theorem_path),
        ],
    }
    summary_path.write_text(
        json.dumps(json_safe(summary), indent=2), encoding="utf-8"
    )

    theorem_text = f"""# ROT-RH v459 — Bump-Wavelet / Relative Commutator theorem target

Numerical verdict: **{verdict}**

## Exact bump identity

For

`p(x)=exp(-(x/(1-x))^2)` and `q(x)=-p'(x)`,

`partial_L p(y/L) = y q(y/L)/L^2`.

Define the centered bump-wavelet generator

`C_q(L,E) = int e^(-y/2) q(y/L) sin(Ey) d[psi(e^y)-e^y]`.

Then the bump-2 finite-part characteristic obeys, at fixed E,

`F(E,L+h)-F(E,L) = -(1/pi) int_L^(L+h) C_q(s,E) ds/s^2`.

## Fixed exponents

The preregistered exponents are

`a={aexp}` for `|D*| >= d L^a`,

`p={pexp}` for the desired `|Delta E_k| <= C L^-p`,

and therefore

`b=2+a-p={bexp}`

for the wavelet generator bound `|C_q| <= C_q L^b`.

The direct commutator exponent is

`r=p-a={rexp}`,

so a sufficient fixed-energy endpoint bound is

`|A_k(L,h)| <= C_A L^-r`.

Because `p>1`, either the direct commutator theorem plus secant transversality,
or the bump-wavelet theorem plus secant transversality, implies summable dyadic
root increments.

## Exact endpoint identity

Let

`A_k = F(E_k(L),L+h)-F(E_k(L),L)`,

and let

`D* = [F(E_k(L+h),L+h)-F(E_k(L),L+h)]/[E_k(L+h)-E_k(L)]`.

Up to the numerically certified endpoint root residuals,

`Delta E_k = -A_k/D*`.

## All-L theorem still required

For every fixed eventual ordered branch k, prove for all sufficiently large L
and `0<=h<=log 2`:

1. `|A_k(L,h)| <= C_A,k L^(-r)`;
2. equivalently/structurally, `|C_q(s,E_k(L))| <= C_q,k L^b`
   uniformly for `L<=s<=L+h`;
3. `|D*_k(L,h)| >= d_k L^a`;
4. branch persistence/no-fold.

Then

`|Delta E_k| <= C_k L^-p`, with `p={pexp}>1`,

so the dyadic endpoint series is absolutely summable. Uniform control over
`0<=h<=log 2` squeezes the continuous branch to the same limit.

## Scientific boundary

v459 is a prospective arithmetic audit of this theorem. It uses no Xi, zeta
values, zeta-log-derivative values, or known Riemann-zero ordinates. A PASS is
not an all-L proof and does not prove RH.
"""
    theorem_path.write_text(theorem_text, encoding="utf-8")

    print("\n" + "=" * 174)
    print("KEY RESULTS")
    print("=" * 174)
    print("verdict                                    :", verdict)
    print("pre-holdout freeze SHA256                  :", freeze_sha)
    print("kernel q=-p'                               :", kcheck["pass"])
    print("training exact identities                  :", training_identity_pass)
    print("training blocked envelopes                 :", blocked_pass)
    print("fresh exact identities                     :", fresh_identity_pass)
    print("fresh all-mode theorem gate                :", all_mode_pass)
    print("fixed p>1                                  :", pexp)
    print("derived b                                  :", bexp)
    print("fresh interval                             :", f"{train_max:,}->{fresh:,}")
    print("summary                                    :", summary_path)
    print("theorem                                    :", theorem_path)
    print("=" * 174)

    if args.strict and verdict != "BUMP_WAVELET_RELATIVE_COMMUTATOR_SUPPORTED_PROSPECTIVELY":
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
