#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v439 — REPAIRED FIXED-E TUBE PRIMITIVE / FRESH / TRANSVERSALITY AUDIT
============================================================================

Why v439 exists
---------------
v438 mixed two distinct bookkeeping conventions:

1. v430 `LD_total` is L times the CENTERED-DISCREPANCY Stieltjes term D.
   It excludes the explicit n=2 lower-endpoint contribution.

2. The v431 renewal
       S_(L+h)(E)=alpha S_L(E)+beta J_L(E)
   is a FIXED-E identity.
   v438 incorrectly compared rows with the same root/tube label across shells,
   although their stored `E_fixed` values change with shell.

Those issues explain the v438 failures. They are not arithmetic failures.

v439 repairs both points.

Exact lower-endpoint convention
-------------------------------
Let a=log 2, h=log 2 and

    c_(L,h)=1/L-1/(L+h).

The exact v429 integration-by-parts formula is

    Delta_h F_L(E)
      = lower_(L,h)(E) + D_(L,h)(E),

where

    lower_(L,h)(E)
      = -a c_(L,h) e^(-a/2) sin(Ea).

Thus

    L D_total
      = L Delta_h F
        - L lower.

This is the quantity stored by v430 as `LD_total`.

Fixed-E audit
-------------
For each root index k, v439 takes the observed finite tube

    I_k^finite
      = [min upstream E_fixed, max upstream E_fixed]

and samples a fixed grid of energies E* in that interval.

For each SAME E* on every dyadic shell it computes, directly from zero-free
arithmetic:

    C0(L,E*)
    H_L(E*)
    S_L(E*) = L D_old
    J_L(E*)
    Delta_h F_L(E*)
    R_L(E*) = L D_fresh
    F'_L(E*)/L.

The exact renewal is then checked correctly:

    S_(L+h)(E*)
      = [(L+h)/(L+2h)] S_L(E*)
        + [h/(L+2h)] J_L(E*).

The exact primitive identity is

    T_n(E*) := L_(n+1) S_n(E*)

    T_(n+1)-T_n = h J_n(E*),

so

    L_(n+1)S_n
      = L_1 S_0
        + h sum_(j<n) J_j.

Fixed-mode cutoff theorem
-------------------------
If on an eventual fixed-k compact tube I_k, for some epsilon>0,

(A)  sup_(E in I_k)
     |sum_(j<n) J_j(E)|
       <= C_k L_n^(2-epsilon),

(B)  sup_(E in I_k)
     |R_n(E)| = |L_n D_fresh|
       <= C'_k L_n^(1-epsilon),

(C)  inf_(E in I_k)
     F'_L(E)/L >= c_k > 0,

and the ordered branch remains in I_k, then

    Delta_h F_L(E)=O_k(L^-epsilon),

and the exact mean-value root identity gives

    Delta E_k = O_k(L^(-1-epsilon)).

Because L_n=L_0+n log2, the root increments are absolutely summable:

    E_k(L_n) -> E_k(infinity).

For epsilon=1:

    primitive O(L),
    L D_fresh=O(1),
    Delta F=O(1/L),
    Delta E=O(1/L^2),
    root tail=O(1/L).

Scientific firewall
-------------------
NO Xi.
NO numerical zeta values.
NO known zero ordinates.
NO RH assumption.
NO new root solves.
NO larger cutoff.
Finite tube sampling / holdout is evidence only.

Version: 439
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 439
A0 = math.log(2.0)
H_DYADIC = math.log(2.0)
EPS = 1e-300


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def load_json(path: str) -> Optional[dict]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def expected(summary: Optional[dict], verdict: str) -> bool:
    return bool(summary is not None and summary.get("verdict") == verdict)


def support_count(logs: np.ndarray, L: float) -> int:
    return int(np.searchsorted(logs, float(L)-1e-14, side="left"))


def call_trig_sum(base, E, logs, weights, trig, *, energy_chunk, term_chunk):
    fn = base.trig_sum
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        if "e_chunk" in params:
            kwargs["e_chunk"] = int(energy_chunk)
        if "term_chunk" in params:
            kwargs["term_chunk"] = int(term_chunk)
    except Exception:
        kwargs = {}
    try:
        return np.asarray(fn(E, logs, weights, trig, **kwargs), float)
    except TypeError:
        return np.asarray(fn(E, logs, weights, trig), float)


def smooth0(E: np.ndarray, L: float) -> np.ndarray:
    """Integral_2^(e^L) t^-1/2 sin(E log t) dt."""
    E = np.atleast_1d(np.asarray(E, float))
    a = 0.5 + 1j*E
    return np.imag((np.exp(a*L)-np.exp(a*A0))/a)


def lower_endpoint(E: np.ndarray, L: float, h: float) -> np.ndarray:
    """
    Explicit lower endpoint in
        Delta_h F = lower + D.
    """
    E = np.atleast_1d(np.asarray(E, float))
    c = 1.0/L - 1.0/(L+h)
    return (
        -A0
        * c
        * math.exp(-0.5*A0)
        * np.sin(E*A0)
    )


def build_cache(base, max_cutoff: int):
    primes = base.sieve_primes(int(max_cutoff))
    logs, _, exponents = base.prime_power_riesz_terms(primes, int(max_cutoff))
    logs = np.asarray(logs, float)
    exponents = np.asarray(exponents, float)
    order = np.argsort(logs)
    logs = logs[order]
    exponents = exponents[order]

    lambda_w = logs/exponents
    lambda_cumsum = np.cumsum(lambda_w, dtype=np.float64)
    generator_w = lambda_w*np.exp(-0.5*logs)
    base_weight = np.exp(-0.5*logs)/exponents
    return (
        primes, logs, exponents,
        lambda_w, lambda_cumsum,
        generator_w, base_weight,
    )


def psi_minus(logs, lambda_cumsum, L):
    k = support_count(logs, L)
    return float(lambda_cumsum[k-1]) if k > 0 else 0.0


def A_of_L(logs, lambda_cumsum, L):
    return (
        psi_minus(logs, lambda_cumsum, L)
        - A0
        - (math.exp(L)-2.0)
    )


def evaluate_at_cutoff(
    *,
    base,
    logs,
    lambda_cumsum,
    generator_w,
    base_weight,
    X: int,
    E: np.ndarray,
    energy_chunk: int,
    term_chunk: int,
):
    L = math.log(float(X))
    k = support_count(logs, L)
    l = logs[:k]

    C0 = (
        call_trig_sum(
            base, E, l, generator_w[:k], "sin",
            energy_chunk=energy_chunk,
            term_chunk=term_chunk,
        )
        - smooth0(E, L)
    )

    riesz_w = base_weight[:k]*(1.0-l/L)

    phase = np.asarray(
        base.phase_grid(
            np.asarray(E, float),
            int(X),
            l,
            riesz_w,
        ),
        float,
    )
    Fp = np.asarray(
        base.phase_prime_grid(
            np.asarray(E, float),
            int(X),
            l,
            riesz_w,
        ),
        float,
    )

    A = A_of_L(logs, lambda_cumsum, L)
    g = np.exp(-0.5*L)*np.sin(np.asarray(E, float)*L)
    ga = math.exp(-0.5*A0)*np.sin(np.asarray(E, float)*A0)
    H = A*g-C0+A0*ga

    return {
        "X": int(X),
        "L": L,
        "A": A,
        "C0": C0,
        "phase": phase,
        "Fp": Fp,
        "H": H,
    }


def symbolic_checks(epsilon: float) -> Dict[str, Any]:
    try:
        import sympy as sp
    except Exception as exc:
        return {"pass": False, "error": str(exc)}

    L, h, S, J = sp.symbols("L h S J", positive=True, real=True)
    alpha = (L+h)/(L+2*h)
    beta = h/(L+2*h)

    renewal = sp.simplify(
        (L+2*h)*(alpha*S+beta*J)
        - ((L+h)*S+h*J)
    )
    return {
        "alpha_plus_beta": str(sp.simplify(alpha+beta)),
        "renewal_telescoping_residual": str(renewal),
        "lower_endpoint": (
            "-log2*(1/L-1/(L+h))*2^(-1/2)*sin(E log2)"
        ),
        "all_L_A": (
            "sup_E |sum_(j<n) J_j(E)| <= C_k L_n^(2-epsilon)"
        ),
        "all_L_B": (
            "sup_E |L_n D_fresh| <= C'_k L_n^(1-epsilon)"
        ),
        "all_L_C": (
            "inf_E F'_L(E)/L >= c_k > 0"
        ),
        "consequence": (
            "Delta E_k=O(L^(-1-epsilon)); "
            "E_k(L_n) converges"
        ),
        "strong_epsilon_1": (
            "primitive O(L), LD_fresh O(1), "
            "DeltaF O(1/L), DeltaE O(1/L^2), tail O(1/L)"
        ),
        "epsilon": float(epsilon),
        "pass": bool(renewal == 0 and 0 < epsilon <= 1),
    }


# -----------------------------------------------------------------------------
# Upstream native-point convention check
# -----------------------------------------------------------------------------

def upstream_convention_check(
    *,
    d430: pd.DataFrame,
    d431: pd.DataFrame,
    d435: pd.DataFrame,
    d437: pd.DataFrame,
):
    keys = [
        "set", "shell_index", "X0", "X1",
        "root_index", "tube_coordinate",
    ]

    a = d430[keys+[
        "E_fixed", "LD_old", "LD_fresh", "LD_total"
    ]].rename(columns={"E_fixed":"E430"})

    b = d431[keys+[
        "E_fixed", "J_total", "S0_old_history"
    ]].rename(columns={"E_fixed":"E431"})

    c = d435[keys+[
        "E_fixed", "dQ_imag"
    ]].rename(columns={"E_fixed":"E435"})

    d = d437[keys+[
        "E_fixed", "forcing_imag"
    ]].rename(columns={"E_fixed":"E437"})

    m = (
        a.merge(b, on=keys, validate="one_to_one")
         .merge(c, on=keys, validate="one_to_one")
         .merge(d, on=keys, validate="one_to_one")
    )
    if not (
        len(m) == len(a) == len(b) == len(c) == len(d)
    ):
        raise RuntimeError("Native upstream point tables did not align one-to-one.")

    Eres = np.max(np.column_stack([
        np.abs(m["E430"]-m["E431"]),
        np.abs(m["E430"]-m["E435"]),
        np.abs(m["E430"]-m["E437"]),
    ]), axis=1)

    m["L0"] = np.log(m["X0"].astype(float))
    m["L1"] = np.log(m["X1"].astype(float))
    h = m["L1"]-m["L0"]

    low = lower_endpoint(
        m["E430"].to_numpy(float),
        m["L0"].to_numpy(float),
        h.to_numpy(float),
    )
    m["lower_endpoint"] = low

    # Full phase transfer from v435 minus explicit lower endpoint equals v430 D.
    m["LD_total_reconstructed"] = (
        m["L0"]*(
            m["dQ_imag"].astype(float)
            - m["lower_endpoint"]
        )
    )
    m["LD_total_convention_abs"] = np.abs(
        m["LD_total_reconstructed"]
        - m["LD_total"].astype(float)
    )

    # v431 real forcing is -Im of v437 complex forcing.
    m["J_sin_from_v437"] = -m["forcing_imag"].astype(float)
    m["J_cross_abs"] = np.abs(
        m["J_sin_from_v437"]
        - m["J_total"].astype(float)
    )

    m["S0_cross_abs"] = np.abs(
        m["S0_old_history"].astype(float)
        - m["LD_old"].astype(float)
    )

    m["fresh_identity_abs"] = np.abs(
        (
            m["LD_total"].astype(float)
            - m["LD_old"].astype(float)
        )
        - m["LD_fresh"].astype(float)
    )

    return m, {
        "max_energy_alignment": float(np.max(Eres)),
        "max_LD_total_convention_abs": float(
            m["LD_total_convention_abs"].max()
        ),
        "max_J_cross_abs": float(m["J_cross_abs"].max()),
        "max_S0_cross_abs": float(m["S0_cross_abs"].max()),
        "max_fresh_identity_abs": float(
            m["fresh_identity_abs"].max()
        ),
    }


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v430-points",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v430-summary",
        default="rot_rh_dyadic_transfer_old_fresh_carrier_v430_SUMMARY.json",
    )
    ap.add_argument(
        "--v431-points",
        default="rot_rh_old_history_dyadic_renewal_local_forcing_v431_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v431-summary",
        default="rot_rh_old_history_dyadic_renewal_local_forcing_v431_SUMMARY.json",
    )
    ap.add_argument(
        "--v435-points",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v435-summary",
        default="rot_rh_canonical_complex_riesz_characteristic_v435_SUMMARY.json",
    )
    ap.add_argument(
        "--v437-points",
        default="rot_rh_signed_dyadic_krein_forcing_bridge_v437_POINTS.csv.gz",
    )
    ap.add_argument(
        "--v437-summary",
        default="rot_rh_signed_dyadic_krein_forcing_bridge_v437_SUMMARY.json",
    )
    ap.add_argument(
        "--v424-summary",
        default="rot_rh_cesaro_mean_primitive_beta_v424_SUMMARY.json",
    )
    ap.add_argument(
        "--v71-module",
        default="rot_rh_v69_regularized_prime_colligation_local_fredholm_v71",
    )

    ap.add_argument("--epsilon", type=float, default=1.0)
    ap.add_argument(
        "--fixed-energy-grid-points",
        type=int,
        default=5,
        help="Fixed E samples across each observed finite root tube.",
    )
    ap.add_argument("--energy-chunk", type=int, default=8)
    ap.add_argument("--term-chunk", type=int, default=200000)
    ap.add_argument("--development-shells", type=int, default=1)
    ap.add_argument("--primitive-cap-safety", type=float, default=1.5)
    ap.add_argument("--fresh-cap-safety", type=float, default=2.0)
    ap.add_argument("--transfer-cap-safety", type=float, default=1.25)
    ap.add_argument("--minimum-slope-ratio", type=float, default=0.45)

    ap.add_argument("--maximum-native-energy-alignment", type=float, default=5e-12)
    ap.add_argument("--maximum-native-identity-absolute", type=float, default=5e-9)
    ap.add_argument("--maximum-renewal-relative", type=float, default=5e-10)

    ap.add_argument(
        "--prefix",
        default="rot_rh_fixed_E_tube_primitive_fresh_transversality_v439",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if not (0 < args.epsilon <= 1):
        raise ValueError("--epsilon must satisfy 0<epsilon<=1")
    if args.fixed_energy_grid_points < 3:
        raise ValueError("--fixed-energy-grid-points must be >=3")
    if args.development_shells < 1:
        raise ValueError("--development-shells must be >=1")

    started = time.time()

    s430 = load_json(args.v430_summary)
    s431 = load_json(args.v431_summary)
    s435 = load_json(args.v435_summary)
    s437 = load_json(args.v437_summary)
    s424 = load_json(args.v424_summary)

    ok430 = expected(
        s430,
        "EXACT_DYADIC_OLD_FRESH_TRANSFER_DECOMPOSITION_PASS_OLD_HISTORY_CARRIER",
    )
    ok431 = expected(
        s431,
        "EXACT_OLD_HISTORY_DYADIC_RENEWAL_LOCAL_FORCING_REDUCTION_PASS",
    )
    ok435 = expected(
        s435,
        "EXACT_CANONICAL_COMPLEX_RIESZ_SCALAR_CHARACTERISTIC_NORMALIZATION_PASS",
    )
    ok437 = expected(
        s437,
        "EXACT_V432_COMPLEX_FORCING_AS_SIGNED_DYADIC_KREIN_TRANSFER_PASS",
    )
    ok424 = expected(
        s424,
        "CESARO_MEAN_PRIMITIVE_BETA_PROSPECTIVE_O_L_PASS",
    )

    print("="*238)
    print("ROT-RH v439 — REPAIRED FIXED-E TUBE PRIMITIVE / FRESH / TRANSVERSALITY AUDIT")
    print("="*238)
    print("Xi / zeta numerical values / known zeros : NONE")
    print("RH assumed                                : NO")
    print("new root solves                           : NONE")
    print("larger cutoff                             : NONE")
    print("finite audit accepted as proof            : NO")
    print("="*238)

    print("[1] Upstream")
    print("v430 old/fresh decomposition             :", ok430, None if s430 is None else s430.get("verdict"))
    print("v431 fixed-E renewal theorem             :", ok431, None if s431 is None else s431.get("verdict"))
    print("v435 canonical scalar characteristic      :", ok435, None if s435 is None else s435.get("verdict"))
    print("v437 complex/signed Krein bridge          :", ok437, None if s437 is None else s437.get("verdict"))
    print("v424 branch primitive-beta finite evidence:", ok424, None if s424 is None else s424.get("verdict"))

    theorem = symbolic_checks(args.epsilon)
    print("\n[2] Exact theorem")
    print("symbolic theorem pass                     :", theorem.get("pass"))
    print("renewal telescoping residual              :", theorem.get("renewal_telescoping_residual"))
    print("all-L gate A                              :", theorem.get("all_L_A"))
    print("all-L gate B                              :", theorem.get("all_L_B"))
    print("all-L gate C                              :", theorem.get("all_L_C"))
    print("consequence                               :", theorem.get("consequence"))

    # ------------------------------------------------------------------
    # Native upstream convention repair.
    # ------------------------------------------------------------------
    d430 = pd.read_csv(args.v430_points)
    d431 = pd.read_csv(args.v431_points)
    d435 = pd.read_csv(args.v435_points)
    d437 = pd.read_csv(args.v437_points)

    native, native_diag = upstream_convention_check(
        d430=d430, d431=d431, d435=d435, d437=d437
    )

    native_pass = bool(
        native_diag["max_energy_alignment"]
        <= args.maximum_native_energy_alignment
        and native_diag["max_LD_total_convention_abs"]
        <= args.maximum_native_identity_absolute
        and native_diag["max_J_cross_abs"]
        <= args.maximum_native_identity_absolute
        and native_diag["max_S0_cross_abs"]
        <= args.maximum_native_identity_absolute
        and native_diag["max_fresh_identity_abs"]
        <= args.maximum_native_identity_absolute
    )

    print("\n[3] Repaired upstream convention check")
    print("maximum native energy alignment           :", f"{native_diag['max_energy_alignment']:.12e}")
    print("max |L(dQ-lower)-LD_total|               :", f"{native_diag['max_LD_total_convention_abs']:.12e}")
    print("max |-Im Jcomplex-J_v431|                :", f"{native_diag['max_J_cross_abs']:.12e}")
    print("max |S0_v431-LD_old_v430|                :", f"{native_diag['max_S0_cross_abs']:.12e}")
    print("max |(LD_total-LD_old)-LD_fresh|         :", f"{native_diag['max_fresh_identity_abs']:.12e}")
    print("native convention repair pass             :", native_pass)

    # ------------------------------------------------------------------
    # Build fixed finite tube samples.
    # ------------------------------------------------------------------
    shell_table = (
        d430[
            ["set","shell_index","X0","X1"]
        ]
        .drop_duplicates()
        .sort_values("shell_index")
        .reset_index(drop=True)
    )

    # Use observed min/max tube per root; fixed E points are held constant
    # through every shell.
    tube_rows = []
    for root_index, g in d430.groupby("root_index", sort=True):
        emin = float(g["E_fixed"].min())
        emax = float(g["E_fixed"].max())
        grid = np.linspace(
            emin, emax,
            int(args.fixed_energy_grid_points),
        )
        for j, E in enumerate(grid):
            tube_rows.append({
                "root_index": int(root_index),
                "fixed_E_index": int(j),
                "E_fixed_star": float(E),
                "tube_min_observed": emin,
                "tube_max_observed": emax,
            })

    tube_df = pd.DataFrame(tube_rows)
    Eall = tube_df["E_fixed_star"].to_numpy(float)
    nE = len(Eall)

    max_X = int(shell_table["X1"].max())
    base = importlib.import_module(args.v71_module)

    print("\n[4] Zero-free fixed-E tube arithmetic")
    print("fixed root modes                          :", tube_df["root_index"].nunique())
    print("fixed E points per root                   :", args.fixed_energy_grid_points)
    print("total frozen energies                     :", nE)
    print("maximum reused cutoff                    :", f"{max_X:,}")

    t0 = time.time()
    (
        primes, logs, exponents,
        lambda_w, lambda_cumsum,
        generator_w, base_weight,
    ) = build_cache(base, max_X)
    print("prime-power terms                        :", f"{len(logs):,}")
    print("cache build seconds                      :", f"{time.time()-t0:.3f}")

    cutoffs = sorted(
        set(shell_table["X0"].astype(int))
        | set(shell_table["X1"].astype(int))
    )

    evals = {}
    bar = tqdm(
        total=len(cutoffs),
        desc="fixed-E arithmetic cutoffs",
        unit="cutoff",
    )
    for X in cutoffs:
        evals[X] = evaluate_at_cutoff(
            base=base,
            logs=logs,
            lambda_cumsum=lambda_cumsum,
            generator_w=generator_w,
            base_weight=base_weight,
            X=X,
            E=Eall,
            energy_chunk=args.energy_chunk,
            term_chunk=args.term_chunk,
        )
        bar.update(1)
    bar.close()

    # ------------------------------------------------------------------
    # Per-shell exact quantities at SAME frozen E.
    # ------------------------------------------------------------------
    point_parts = []
    for _, sh in shell_table.iterrows():
        setname = str(sh["set"])
        shell_index = int(sh["shell_index"])
        X0 = int(sh["X0"])
        X1 = int(sh["X1"])

        q0 = evals[X0]
        q1 = evals[X1]
        L0 = q0["L"]
        L1 = q1["L"]
        h = L1-L0

        J = q1["H"]-q0["H"]

        S0 = h/(L0+h)*q0["H"]
        S1_same_E = h/(L0+2*h)*q1["H"]

        alpha = (L0+h)/(L0+2*h)
        beta = h/(L0+2*h)
        S1_rec = alpha*S0+beta*J

        renewal_abs = np.abs(S1_same_E-S1_rec)
        renewal_rel = renewal_abs/np.maximum(
            np.abs(S1_same_E), 1e-12
        )

        deltaF = q1["phase"]-q0["phase"]
        lower = lower_endpoint(Eall, L0, h)
        LD_total = L0*(deltaF-lower)
        LD_old = S0
        LD_fresh = LD_total-LD_old

        Fp0_over_L = q0["Fp"]/L0
        Fp1_over_L = q1["Fp"]/L1

        part = tube_df.copy()
        part["set"] = setname
        part["shell_index"] = shell_index
        part["X0"] = X0
        part["X1"] = X1
        part["L0"] = L0
        part["L1"] = L1
        part["h"] = h
        part["A0"] = q0["A"]
        part["A1"] = q1["A"]
        part["C0_X0"] = q0["C0"]
        part["C0_X1"] = q1["C0"]
        part["H0"] = q0["H"]
        part["H1"] = q1["H"]
        part["J_sin_fixed_E"] = J
        part["S0_LD_old"] = S0
        part["S1_same_fixed_E"] = S1_same_E
        part["S1_recurrence"] = S1_rec
        part["renewal_absolute_residual"] = renewal_abs
        part["renewal_relative_residual"] = renewal_rel
        part["deltaF_full"] = deltaF
        part["lower_endpoint"] = lower
        part["LD_total_centered"] = LD_total
        part["LD_old"] = LD_old
        part["LD_fresh"] = LD_fresh
        part["Fp_X0_over_L0"] = Fp0_over_L
        part["Fp_X1_over_L1"] = Fp1_over_L

        point_parts.append(part)

    points = pd.concat(point_parts, ignore_index=True)
    points = points.sort_values(
        ["root_index","fixed_E_index","shell_index"]
    ).reset_index(drop=True)

    max_renewal_rel = float(
        points["renewal_relative_residual"].max()
    )
    renewal_pass = bool(
        max_renewal_rel <= args.maximum_renewal_relative
    )

    print("\n[5] Correct fixed-E renewal")
    print("maximum renewal relative residual         :", f"{max_renewal_rel:.12e}")
    print("fixed-E renewal pass                      :", renewal_pass)

    # ------------------------------------------------------------------
    # Exact telescoping primitive.
    # ------------------------------------------------------------------
    primitive_rows = []
    max_telescoping_abs = 0.0

    for key, g in points.groupby(
        ["root_index","fixed_E_index"],
        sort=True,
    ):
        g = g.sort_values("shell_index").reset_index(drop=True)
        cumulative_J = 0.0

        T0 = (
            float(g.iloc[0]["L1"])
            * float(g.iloc[0]["S0_LD_old"])
        )

        for i, r in g.iterrows():
            L0 = float(r["L0"])
            L1 = float(r["L1"])
            h = float(r["h"])
            S0 = float(r["S0_LD_old"])
            J = float(r["J_sin_fixed_E"])

            T_direct = L1*S0
            T_pred_before = T0+h*cumulative_J
            tel_abs = abs(T_direct-T_pred_before)
            max_telescoping_abs = max(
                max_telescoping_abs, tel_abs
            )

            # primitive after shell i
            cumulative_J += J
            shell_count = i+1

            primitive_rows.append({
                "root_index": int(r["root_index"]),
                "fixed_E_index": int(r["fixed_E_index"]),
                "E_fixed_star": float(r["E_fixed_star"]),
                "set": str(r["set"]),
                "shell_index": int(r["shell_index"]),
                "X0": int(r["X0"]),
                "X1": int(r["X1"]),
                "L0": L0,
                "J_sin_fixed_E": J,
                "signed_primitive_after_shell": cumulative_J,
                "abs_primitive_after_shell": abs(cumulative_J),
                "abs_primitive_per_shell": (
                    abs(cumulative_J)/shell_count
                ),
                "abs_primitive_over_L": (
                    abs(cumulative_J)/L1
                ),
                "subquadratic_normalized": (
                    abs(cumulative_J)
                    / max(
                        L1**(2.0-args.epsilon),
                        EPS,
                    )
                ),
                "T_direct_before_shell": T_direct,
                "T_from_primitive_before_shell": T_pred_before,
                "telescoping_absolute_residual": tel_abs,
            })

    primitive = pd.DataFrame(primitive_rows)

    # Normalize telescoping residual by the natural T scale.
    Tscale = max(
        float(np.max(np.abs(primitive["T_direct_before_shell"]))),
        1.0,
    )
    telescoping_rel = max_telescoping_abs/Tscale

    print("\n[6] Signed primitive / telescoping identity")
    print("maximum telescoping absolute residual     :", f"{max_telescoping_abs:.12e}")
    print("maximum telescoping scale-relative        :", f"{telescoping_rel:.12e}")

    # ------------------------------------------------------------------
    # Finite evidence diagnostics, deliberately separate from exact verdict.
    # ------------------------------------------------------------------
    shell_indices = sorted(
        points["shell_index"].unique().tolist()
    )
    dev_indices = shell_indices[:args.development_shells]
    hold_indices = shell_indices[args.development_shells:]

    pdev = primitive[
        primitive["shell_index"].isin(dev_indices)
    ]
    phold = primitive[
        primitive["shell_index"].isin(hold_indices)
    ]
    qdev = points[
        points["shell_index"].isin(dev_indices)
    ]
    qhold = points[
        points["shell_index"].isin(hold_indices)
    ]

    dev_primitive = float(
        pdev["abs_primitive_per_shell"].max()
    )
    prim_cap = args.primitive_cap_safety*dev_primitive
    hold_primitive = (
        float(phold["abs_primitive_per_shell"].max())
        if len(phold) else float("nan")
    )
    prim_hold_pass = bool(
        len(phold) and hold_primitive <= prim_cap
    )

    dev_fresh = float(
        np.max(np.abs(qdev["LD_fresh"]))
    )
    fresh_cap = args.fresh_cap_safety*dev_fresh
    hold_fresh = (
        float(np.max(np.abs(qhold["LD_fresh"])))
        if len(qhold) else float("nan")
    )
    fresh_hold_pass = bool(
        len(qhold) and hold_fresh <= fresh_cap
    )

    # Full transfer strong class is |L DeltaF| bounded.
    qdev_LDelta = np.abs(
        qdev["L0"]*qdev["deltaF_full"]
    )
    qhold_LDelta = np.abs(
        qhold["L0"]*qhold["deltaF_full"]
    )
    dev_transfer = float(qdev_LDelta.max())
    transfer_cap = (
        args.transfer_cap_safety*dev_transfer
    )
    hold_transfer = (
        float(qhold_LDelta.max())
        if len(qhold) else float("nan")
    )
    transfer_hold_pass = bool(
        len(qhold)
        and hold_transfer <= transfer_cap
    )

    min_slope = float(
        min(
            points["Fp_X0_over_L0"].min(),
            points["Fp_X1_over_L1"].min(),
        )
    )
    nofold_finite = bool(
        np.all(points["Fp_X0_over_L0"] > 0)
        and np.all(points["Fp_X1_over_L1"] > 0)
    )
    trans_pass = bool(
        nofold_finite
        and min_slope >= args.minimum_slope_ratio
    )

    # Conditional finite root-tail envelope for epsilon=1 only.
    if abs(args.epsilon-1.0) < 1e-14 and trans_pass:
        Cphase = float(
            np.max(
                np.abs(
                    points["L0"]*points["deltaF_full"]
                )
            )
        )
        ctrans = min_slope
        Lmax = float(points["L1"].max())
        # Integral comparison:
        # sum_{m>=n} C/(c L_m^2)
        # <= C/(c h) * 1/(L_n-h), for L_n>h.
        conditional_tail_at_max = (
            Cphase/(ctrans*H_DYADIC)
            / max(Lmax-H_DYADIC, EPS)
        )
    else:
        Cphase = float("nan")
        conditional_tail_at_max = float("nan")

    print("\n[7] Finite strong epsilon=1 evidence")
    print("development max |primitive|/shell         :", f"{dev_primitive:.12e}")
    print("frozen primitive cap                     :", f"{prim_cap:.12e}")
    print("holdout max |primitive|/shell             :", f"{hold_primitive:.12e}")
    print("primitive holdout pass                    :", prim_hold_pass)
    print()
    print("development max |L D_fresh|              :", f"{dev_fresh:.12e}")
    print("frozen fresh cap                         :", f"{fresh_cap:.12e}")
    print("holdout max |L D_fresh|                  :", f"{hold_fresh:.12e}")
    print("fresh holdout pass                        :", fresh_hold_pass)
    print()
    print("development max |L DeltaF_full|          :", f"{dev_transfer:.12e}")
    print("frozen transfer cap                      :", f"{transfer_cap:.12e}")
    print("holdout max |L DeltaF_full|              :", f"{hold_transfer:.12e}")
    print("full transfer holdout pass                :", transfer_hold_pass)
    print()
    print("minimum sampled F'/L                     :", f"{min_slope:.12e}")
    print("finite no-fold sampled tube               :", nofold_finite)
    print("finite transversality pass                :", trans_pass)
    if math.isfinite(conditional_tail_at_max):
        print("conditional finite O(1/L) tail envelope @ max L:",
              f"{conditional_tail_at_max:.12e}")
        print("  (diagnostic only; assumes current constants persist all L)")

    finite_combined = bool(
        prim_hold_pass
        and fresh_hold_pass
        and transfer_hold_pass
        and trans_pass
    )

    exact_pass = bool(
        theorem.get("pass")
        and ok430 and ok431 and ok435 and ok437
        and native_pass
        and renewal_pass
        and telescoping_rel <= 5e-10
    )

    verdict = (
        "EXACT_REPAIRED_FIXED_E_PRIMITIVE_FRESH_TRANSVERSALITY_REDUCTION_PASS_ANALYTIC_ALL_L_BOUNDS_OPEN"
        if exact_pass
        else
        "REPAIRED_FIXED_E_PRIMITIVE_FRESH_TRANSVERSALITY_REDUCTION_INCOMPLETE"
    )

    next_theorem = (
        "PROVE_UNIFORM_ALL_L_FIXED_TUBE_SIGNED_PRIMITIVE_FRESH_BOUND_AND_TRANSVERSALITY"
    )

    print("\n" + "="*238)
    print("VERDICT                                   :", verdict)
    print("LOWER-ENDPOINT CONVENTION                 :", "REPAIRED" if native_pass else "FAIL")
    print("FIXED-E RENEWAL                           :", "PASS" if renewal_pass else "FAIL")
    print("SIGNED PRIMITIVE TELESCOPING              :", "PASS" if telescoping_rel <= 5e-10 else "FAIL")
    print("FINITE PRIMITIVE HOLDOUT                  :", prim_hold_pass)
    print("FINITE FRESH HOLDOUT                      :", fresh_hold_pass)
    print("FINITE FULL-TRANSFER HOLDOUT              :", transfer_hold_pass)
    print("FINITE TRANSVERSALITY                     :", trans_pass)
    print("FINITE COMBINED EVIDENCE                  :", finite_combined)
    print("FIXED-MODE CUTOFF INDEPENDENCE            : NOT YET PROVED")
    print("EXACT REMAINING ALL-L GATES               :")
    print("  A) uniform fixed-tube signed primitive subquadratic")
    print("  B) uniform fixed-tube fresh scaled remainder")
    print("  C) uniform eventual transversality + branch persistence")
    print("NEXT THEOREM                              :", next_theorem)
    print("="*238)

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------
    prefix = Path(args.prefix)
    native_out = Path(str(prefix)+"_NATIVE_CONVENTION.csv.gz")
    points_out = Path(str(prefix)+"_FIXED_E_POINTS.csv.gz")
    primitive_out = Path(str(prefix)+"_PRIMITIVE.csv")
    shell_out = Path(str(prefix)+"_SHELL_SUMMARY.csv")
    summary_out = Path(str(prefix)+"_SUMMARY.json")
    theorem_out = Path(str(prefix)+"_THEOREM.md")
    cert_out = Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")

    native.to_csv(native_out, index=False, compression="gzip")
    points.to_csv(points_out, index=False, compression="gzip")
    primitive.to_csv(primitive_out, index=False)

    shell_rows = []
    for shell_index, g in points.groupby("shell_index", sort=True):
        pg = primitive[primitive["shell_index"] == shell_index]
        shell_rows.append({
            "set": str(g.iloc[0]["set"]),
            "shell_index": int(shell_index),
            "X0": int(g.iloc[0]["X0"]),
            "X1": int(g.iloc[0]["X1"]),
            "max_abs_J_fixed_E": float(
                np.max(np.abs(g["J_sin_fixed_E"]))
            ),
            "max_abs_primitive_per_shell": float(
                pg["abs_primitive_per_shell"].max()
            ),
            "max_abs_LD_old": float(
                np.max(np.abs(g["LD_old"]))
            ),
            "max_abs_LD_fresh": float(
                np.max(np.abs(g["LD_fresh"]))
            ),
            "max_abs_L_DeltaF_full": float(
                np.max(np.abs(g["L0"]*g["deltaF_full"]))
            ),
            "minimum_Fp_over_L": float(
                min(
                    g["Fp_X0_over_L0"].min(),
                    g["Fp_X1_over_L1"].min(),
                )
            ),
            "maximum_renewal_relative_residual": float(
                g["renewal_relative_residual"].max()
            ),
        })
    shell_df = pd.DataFrame(shell_rows)
    shell_df.to_csv(shell_out, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_evaluated": False,
            "known_zero_ordinates_used": False,
            "RH_assumed": False,
            "new_root_solves": False,
            "larger_cutoff": False,
        },
        "upstream": {
            "v430_ok": ok430,
            "v431_ok": ok431,
            "v435_ok": ok435,
            "v437_ok": ok437,
            "v424_finite_evidence_ok": ok424,
        },
        "exact_theorem": theorem,
        "v438_repairs": {
            "lower_endpoint_convention_repaired": native_pass,
            "renewal_evaluated_at_same_fixed_E": True,
            "finite_diagnostics_separated_from_exact_verdict": True,
        },
        "native_convention": native_diag,
        "fixed_E_reconstruction": {
            "fixed_modes": int(tube_df["root_index"].nunique()),
            "fixed_E_grid_points_per_mode": int(args.fixed_energy_grid_points),
            "maximum_renewal_relative_residual": max_renewal_rel,
            "renewal_pass": renewal_pass,
            "maximum_primitive_telescoping_absolute_residual": max_telescoping_abs,
            "primitive_telescoping_relative": telescoping_rel,
        },
        "finite_evidence": {
            "development_max_abs_primitive_per_shell": dev_primitive,
            "primitive_cap": prim_cap,
            "holdout_max_abs_primitive_per_shell": hold_primitive,
            "primitive_holdout_pass": prim_hold_pass,
            "development_max_abs_LD_fresh": dev_fresh,
            "fresh_cap": fresh_cap,
            "holdout_max_abs_LD_fresh": hold_fresh,
            "fresh_holdout_pass": fresh_hold_pass,
            "development_max_abs_LDeltaF_full": dev_transfer,
            "transfer_cap": transfer_cap,
            "holdout_max_abs_LDeltaF_full": hold_transfer,
            "transfer_holdout_pass": transfer_hold_pass,
            "minimum_sampled_Fp_over_L": min_slope,
            "finite_nofold": nofold_finite,
            "transversality_pass": trans_pass,
            "conditional_tail_envelope_at_max_L": conditional_tail_at_max,
            "combined_pass": finite_combined,
            "proof_status": "FINITE_EVIDENCE_ONLY",
        },
        "exact_reduction_pass": exact_pass,
        "verdict": verdict,
        "fixed_mode_cutoff_independence_proved": False,
        "next_theorem": next_theorem,
        "runtime_seconds": time.time()-started,
    }
    summary_out.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_out.write_text(
        f"""# ROT-RH v439 — repaired fixed-E cutoff theorem

v438 failed two bookkeeping checks for reasons unrelated to the arithmetic:

1. `v430 LD_total` excludes the explicit lower endpoint

`lower=-log2*(1/L-1/(L+h))*2^(-1/2)sin(E log2)`.

Thus the correct relation is

`LD_total=L*(DeltaF-lower)`,

not `LD_total=L*DeltaF`.

2. The renewal theorem is pointwise in a single fixed `E`.  It cannot be
checked by following a label whose `E_fixed` changes between shells.

v439 evaluates the same frozen energies through every dyadic shell.

For fixed `E`,

`S_(L+h)=((L+h)/(L+2h))S_L+(h/(L+2h))J_L`

and equivalently

`L_(n+1)S_n=L_1 S_0+h sum_(j<n)J_j`.

If for some epsilon>0, uniformly on an eventual fixed-k tube,

`|sum_(j<n)J_j(E)|<=C_k L_n^(2-epsilon)`,

`|L_n D_fresh(L_n,E)|<=C'_k L_n^(1-epsilon)`,

and

`F'_L(E)>=c_k L`,

then

`Delta_h F=O(L^-epsilon)`

and the mean-value root identity gives

`Delta E_k=O(L^(-1-epsilon))`.

Therefore the fixed mode converges.

For epsilon=1 the root tail is `O(1/L)`.

This finite audit validates the exact identities and samples the hypotheses.
It does not prove their all-L uniform forms.
""",
        encoding="utf-8",
    )

    cert = {
        "schema": "ROT_RH_FIXED_MODE_CUTOFF_INDEPENDENCE_V439_CERTIFICATE",
        "exact_reduction_proved": exact_pass,
        "required_all_L_claims": {
            "fixed_tube": {
                "proved": False,
                "statement": (
                    "For each fixed mode k there is an eventual compact tube I_k "
                    "containing the ordered branch."
                ),
            },
            "signed_primitive": {
                "proved": False,
                "statement": (
                    "sup_(E in I_k)|sum_(j<n)J_j(E)| "
                    "<=C_k L_n^(2-epsilon), epsilon>0."
                ),
                "preferred_strong": "O_k(L_n)",
            },
            "fresh_remainder": {
                "proved": False,
                "statement": (
                    "sup_(E in I_k)|L_n D_fresh| "
                    "<=C'_k L_n^(1-epsilon)."
                ),
                "preferred_strong": "O_k(1)",
            },
            "transversality": {
                "proved": False,
                "statement": (
                    "inf_(E in I_k) F'_L(E)/L >= c_k>0 eventually."
                ),
            },
        },
        "consequence": (
            "These all-L claims imply fixed-mode cutoff independence; "
            "for epsilon=1 the cutoff tail is O_k(1/L)."
        ),
        "forbidden_as_proof": [
            "finite tube grid",
            "finite holdout cap",
            "finite regression",
            "known zero ordinates",
            "Xi fitting",
            "absolute PNT majorant that erases signed cancellation",
            "full v432 complex bounded-forcing assumption",
        ],
    }
    cert_out.write_text(
        json.dumps(cert, indent=2),
        encoding="utf-8",
    )

    print("Files written:")
    print(" ", native_out)
    print(" ", points_out)
    print(" ", primitive_out)
    print(" ", shell_out)
    print(" ", summary_out)
    print(" ", theorem_out)
    print(" ", cert_out)

    if args.strict and not exact_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
