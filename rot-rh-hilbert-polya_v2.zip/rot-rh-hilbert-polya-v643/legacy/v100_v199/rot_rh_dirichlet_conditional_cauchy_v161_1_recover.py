#!/usr/bin/env python3
"""
ROT-RH v161.1 — ZERO-COST RECOVERY / JSON-SERIALIZATION FIX

Use after v161 completed all arithmetic but crashed while writing SUMMARY.json
with:
    TypeError: Object of type bool is not JSON serializable

v161 writes SHELLS.csv, MODES.csv, and TAILS.csv before the crash, so this
script reconstructs the final diagnostics WITHOUT recomputing primes,
integrals, or cutoff shells.

NO Xi / zeta / known zeros.
NO arithmetic recomputation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def native(x):
    """Convert numpy/pandas scalar objects recursively to JSON-safe Python."""
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_dirichlet_conditional_cauchy_v161",
        help="Prefix used by the crashed v161 run.",
    )
    ap.add_argument(
        "--minimum-positive-q-fraction",
        type=float,
        default=0.70,
    )
    ap.add_argument(
        "--tail-envelope-ratio-gate",
        type=float,
        default=0.85,
    )
    ap.add_argument(
        "--dirichlet-bound-ratio-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--summary-out",
        default=None,
        help="Defaults to <prefix>_SUMMARY.json",
    )
    args = ap.parse_args()

    shells_path = Path(args.prefix + "_SHELLS.csv")
    modes_path = Path(args.prefix + "_MODES.csv")
    tails_path = Path(args.prefix + "_TAILS.csv")

    for p in (shells_path, modes_path, tails_path):
        if not p.exists():
            raise FileNotFoundError(
                f"Missing {p}. v161 must have reached the CSV-writing stage."
            )

    shells = pd.read_csv(shells_path)
    modes = pd.read_csv(modes_path)
    tails = pd.read_csv(tails_path)

    if len(shells) == 0 or len(modes) == 0 or len(tails) == 0:
        raise RuntimeError("One or more v161 CSV files are empty.")

    shells = shells.sort_values("shell").reset_index(drop=True)
    modes = modes.sort_values("k").reset_index(drop=True)
    tails = tails.sort_values("shell0").reset_index(drop=True)

    candidates = tails[tails["remaining_shells"] >= 3]
    if len(candidates) == 0:
        raise RuntimeError("No tail row with >=3 remaining shells.")
    latest = candidates.iloc[-1].to_dict()

    positive_q_fraction = float(np.mean(modes["log_decay_q"].to_numpy() > 0))
    median_q = float(np.median(modes["log_decay_q"].to_numpy(dtype=float)))
    median_log_r2 = float(
        np.median(modes["log_decay_R2"].to_numpy(dtype=float))
    )

    actual_ratio = float(latest["actual_envelope_ratio"])
    dirichlet_ratio = float(latest["dirichlet_bound_ratio"])

    decay_pass = bool(
        positive_q_fraction >= args.minimum_positive_q_fraction
    )
    actual_tail_pass = bool(
        np.isfinite(actual_ratio)
        and actual_ratio < args.tail_envelope_ratio_gate
    )
    dirichlet_tail_pass = bool(
        np.isfinite(dirichlet_ratio)
        and dirichlet_ratio < args.dirichlet_bound_ratio_gate
    )

    if decay_pass and actual_tail_pass and dirichlet_tail_pass:
        verdict = "DIRICHLET_CONDITIONAL_CAUCHY_MECHANISM_STRONGLY_SUPPORTED"
    elif decay_pass and actual_tail_pass:
        verdict = "CONDITIONAL_CAUCHY_SUPPORTED_DIRICHLET_BOUND_MIXED"
    else:
        verdict = "DIRICHLET_CONDITIONAL_CAUCHY_MECHANISM_UNRESOLVED"

    summary = {
        "version": "161.1-recovery",
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "recovered_from": {
            "shells_csv": str(shells_path),
            "modes_csv": str(modes_path),
            "tails_csv": str(tails_path),
        },
        "candidate_lemma": (
            "For each fixed mode k, z_j=a_j u_j. If a_j->0 with "
            "tail variation ->0 and unit-phase partial sums are uniformly "
            "bounded, then sum_j z_j converges by summation by parts."
        ),
        "shell_count": int(len(shells)),
        "mode_count": int(len(modes)),
        "positive_log_decay_q_fraction": positive_q_fraction,
        "median_log_decay_q": median_q,
        "median_log_decay_R2": median_log_r2,
        "latest_ge3_tail": native(latest),
        "gates": {
            "minimum_positive_q_fraction": args.minimum_positive_q_fraction,
            "tail_envelope_ratio": args.tail_envelope_ratio_gate,
            "dirichlet_bound_ratio": args.dirichlet_bound_ratio_gate,
        },
        "decay_pass": bool(decay_pass),
        "actual_tail_envelope_pass": bool(actual_tail_pass),
        "dirichlet_bound_contraction_pass": bool(dirichlet_tail_pass),
        "verdict": verdict,
        "proof_gap": (
            "Numerics do not prove the infinite-tail Dirichlet conditions. "
            "An analytic proof still needs amplitude decay with vanishing "
            "tail variation and a uniform bound on unit-phase partial sums."
        ),
    }

    out = (
        Path(args.summary_out)
        if args.summary_out
        else Path(args.prefix + "_SUMMARY.json")
    )
    out.write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print("=" * 150)
    print("ROT-RH v161.1 — ZERO-COST RECOVERY / CONDITIONAL CAUCHY SUMMARY")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"shell rows                         : {len(shells)}")
    print(f"mode rows                          : {len(modes)}")
    print(f"tail rows                          : {len(tails)}")
    print(f"summary written                    : {out}")
    print("=" * 150)

    print()
    print("Combined adjacent shell sequence")
    print("-" * 150)
    print(
        f"{'shell':>6} {'pair':>21} {'|Z|_1':>13} "
        f"{'ratio':>10} {'|Im|_1':>13} {'Im ratio':>10}"
    )
    for _, r in shells.iterrows():
        print(
            f"{int(r['shell']):6d} "
            f"{int(r['L']):>9d}->{int(r['M']):<9d} "
            f"{r['complex_l1']:13.6e} "
            f"{r['complex_ratio']:10.6f} "
            f"{r['imag_l1']:13.6e} "
            f"{r['imag_ratio']:10.6f}"
        )

    print()
    print("Modewise Dirichlet diagnostics — worst/interesting modes")
    print("-" * 150)

    show = pd.concat([
        modes.nsmallest(6, "log_decay_q"),
        modes.nlargest(6, "unit_phase_block_bound"),
    ]).drop_duplicates("k").sort_values("k")

    print(
        f"{'k':>4} {'a_last/a_first':>15} {'q_log':>10} "
        f"{'R2_log':>10} {'alpha_pow':>11} "
        f"{'phase B':>10} {'TV/a0':>10} {'actual/bound':>13}"
    )
    for _, r in show.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['amp_last_over_first']:15.6f} "
            f"{r['log_decay_q']:10.6f} "
            f"{r['log_decay_R2']:10.6f} "
            f"{r['power_alpha']:11.6f} "
            f"{r['unit_phase_block_bound']:10.4f} "
            f"{r['variation_over_first']:10.4f} "
            f"{r['actual_over_dirichlet_bound']:13.6f}"
        )

    print()
    print("Tail-set conditional-Cauchy diagnostics")
    print("-" * 150)
    print(
        f"{'L0':>10} {'shells':>7} {'actual envelope':>18} "
        f"{'ratio':>10} {'Dirichlet bound':>18} {'ratio':>10} "
        f"{'sum phase B':>13} {'amp TV':>13}"
    )
    for _, r in tails.iterrows():
        print(
            f"{int(r['L0']):10d} "
            f"{int(r['remaining_shells']):7d} "
            f"{r['aggregate_actual_complex_tail_envelope']:18.6e} "
            f"{r['actual_envelope_ratio']:10.6f} "
            f"{r['aggregate_dirichlet_abel_bound']:18.6e} "
            f"{r['dirichlet_bound_ratio']:10.6f} "
            f"{r['sum_unit_phase_block_bounds']:13.6e} "
            f"{r['sum_tail_amplitude_variation']:13.6e}"
        )

    print()
    print("=" * 150)
    print(f"positive log-decay q fraction       : {positive_q_fraction:.6f}")
    print(f"median log-decay q                  : {median_q:.9f}")
    print(f"median log-decay R2                 : {median_log_r2:.6f}")
    print(f"latest >=3-shell actual ratio       : {actual_ratio:.9f}")
    print(f"latest >=3-shell Dirichlet ratio    : {dirichlet_ratio:.9f}")
    print(f"amplitude-decay pass                : {decay_pass}")
    print(f"actual tail-envelope pass           : {actual_tail_pass}")
    print(f"Dirichlet-bound contraction pass    : {dirichlet_tail_pass}")
    print(f"VERDICT                             : {verdict}")
    print("=" * 150)


if __name__ == "__main__":
    main()
