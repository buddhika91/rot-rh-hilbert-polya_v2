#!/usr/bin/env python3
"""
ROT-RH v161 — DIRICHLET/ABEL CONDITIONAL CAUCHY AUDIT

Purpose
-------
v160 showed that adjacent FULL-complex shell amplitudes decrease, but only
slowly.  Absolute summability

    sum_j |z_{j,k}| < infinity

may therefore be stronger than necessary.

For each fixed spectral mode k, write the adjacent geometric cutoff increment

    z_{j,k}
      = Z_{L_j,L_{j+1}}(E_k^*)

      = a_{j,k} u_{j,k},

where

    a_{j,k} = |z_{j,k}| >= 0,
    |u_{j,k}| = 1.

A classical summation-by-parts/Dirichlet route says that convergence can
follow even when sum a_j diverges, provided roughly that

    a_{j,k} -> 0,
    the tail variation of a_{j,k} is controlled,
    partial sums of u_{j,k} remain bounded.

Indeed, for any finite block m..n, summation by parts gives a safe bound of
the form

    |sum_{j=m}^n a_j u_j|
      <= B_{m,n}
         [ a_m + sum_{j=m}^{n-1}|a_{j+1}-a_j| ],

where B_{m,n} bounds the corresponding unit-phase partial sums.

v161 tests this theorem-shaped mechanism on the frozen energy set already
used by v160, and extends the shell sequence to genuinely NEW cutoffs.

It does NOT claim a proof.  It asks whether the exact sufficient conditions
we would want to prove analytically are numerically plausible.

Default workflow
----------------
Existing v160 shells:
    256000 -> 362039 -> 512000 -> 724077
    -> 1024000 -> 1448155

New v161 shells:
    1448155 -> 2048000 -> 2896310

NO Xi / zeta / known-zero data are used.
NO root solves or phase builds are performed.

Outputs
-------
<prefix>_SHELLS.csv
<prefix>_MODES.csv
<prefix>_TAILS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def continuum_complex(E, L, M, xmin, xmax, nodes, weights):
    """
    Complex continuum cutoff difference, evaluated in u=log x:

      int [e^-x/M-e^-x/L] x^(-1/2+iE)/log x dx
      =
      int [e^-e^u/M-e^-e^u/L] e^(u/2) e^(iEu)/u du.
    """
    ulo = math.log(xmin)
    uhi = math.log(xmax)

    mid = 0.5 * (ulo + uhi)
    half = 0.5 * (uhi - ulo)

    u = mid + half * nodes
    x = np.exp(u)

    reg = np.exp(-x/M) - np.exp(-x/L)
    amp = reg * np.exp(0.5*u) / u

    return half * np.dot(weights, amp * np.exp(1j * E * u))


def linear_fit(X, Y):
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return coef, r2


def block_phase_bound(unit, start):
    """
    Maximum magnitude of ANY contiguous partial sum of unit phases
    within start..end.

    This finite-horizon quantity is the numerical proxy for the B in
    Dirichlet's test.
    """
    u = np.asarray(unit[start:], dtype=np.complex128)
    if not len(u):
        return 0.0

    cs = np.concatenate([[0.0+0.0j], np.cumsum(u)])
    mx = 0.0

    for i in range(len(cs)-1):
        vals = np.abs(cs[i+1:] - cs[i])
        if len(vals):
            mx = max(mx, float(np.max(vals)))

    return mx


def block_actual_envelope(z, start):
    """
    max_{start<=m<=n} |sum_{j=m}^n z_j|
    """
    zz = np.asarray(z[start:], dtype=np.complex128)
    if not len(zz):
        return 0.0

    cs = np.concatenate([[0.0+0.0j], np.cumsum(zz)])
    mx = 0.0

    for i in range(len(cs)-1):
        vals = np.abs(cs[i+1:] - cs[i])
        if len(vals):
            mx = max(mx, float(np.max(vals)))

    return mx


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v160-modes-csv",
        default="rot_rh_complex_shell_summability_v160_MODES.csv",
    )
    ap.add_argument(
        "--new-cutoffs",
        default="2048000,2896310",
        help=(
            "New cutoff endpoints appended after the final M in the v160 file. "
            "For default v160 data this adds 1448155->2048000->2896310."
        ),
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--continuum-gl-order", type=int, default=1024)
    ap.add_argument("--prime-chunk", type=int, default=65536)

    ap.add_argument(
        "--minimum-positive-q-fraction",
        type=float,
        default=0.70,
        help="Fraction of modes whose fitted log-decay exponent q is positive.",
    )
    ap.add_argument(
        "--tail-envelope-ratio-gate",
        type=float,
        default=0.85,
        help="Latest >=3-shell aggregate actual tail-envelope ratio gate.",
    )
    ap.add_argument(
        "--dirichlet-bound-ratio-gate",
        type=float,
        default=0.90,
        help="Latest >=3-shell aggregate Dirichlet-bound contraction gate.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_dirichlet_conditional_cauchy_v161",
    )

    args = ap.parse_args()

    old = pd.read_csv(args.v160_modes_csv)

    required = {
        "shell", "L", "M", "k", "E_frozen",
        "Z_real", "Z_imag", "Z_abs", "phase",
    }
    missing = required - set(old.columns)
    if missing:
        raise RuntimeError(
            f"v160 modes CSV is missing columns: {sorted(missing)}"
        )

    old = old.sort_values(["shell", "k"]).copy()

    shell_meta = (
        old[["shell", "L", "M"]]
        .drop_duplicates()
        .sort_values("shell")
    )

    last_shell = int(shell_meta["shell"].max())
    last_M = int(shell_meta.iloc[-1]["M"])

    new_ends = csv_ints(args.new_cutoffs)
    if not new_ends:
        raise RuntimeError("Provide at least one new cutoff endpoint.")
    if any(x <= last_M for x in new_ends):
        raise RuntimeError(
            f"All new cutoffs must exceed existing final cutoff {last_M}."
        )
    if any(new_ends[i+1] <= new_ends[i] for i in range(len(new_ends)-1)):
        raise RuntimeError("--new-cutoffs must be strictly increasing.")

    first_shell = old[old["shell"] == old["shell"].min()].sort_values("k")
    E = first_shell["E_frozen"].to_numpy(dtype=float)
    karr = first_shell["k"].to_numpy(dtype=int)

    n = len(E)

    # Verify frozen energies are genuinely identical throughout the v160 file.
    for shell in sorted(old["shell"].unique()):
        g = old[old["shell"] == shell].sort_values("k")
        if len(g) != n:
            raise RuntimeError(f"Shell {shell} has wrong mode count.")
        if not np.allclose(
            g["E_frozen"].to_numpy(dtype=float),
            E,
            rtol=0,
            atol=1e-12,
        ):
            raise RuntimeError(
                "v160 file does not use one frozen energy set."
            )

    new_pairs = []
    prev = last_M
    for M in new_ends:
        new_pairs.append((prev, M))
        prev = M

    xmax = int(math.ceil(args.tail_factor * max(new_ends)))

    print("=" * 150)
    print("ROT-RH v161 — DIRICHLET/ABEL CONDITIONAL CAUCHY AUDIT")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"existing v160 shells              : {last_shell}")
    print(f"existing final cutoff             : {last_M}")
    print(f"new shell pairs                   : {new_pairs}")
    print(f"frozen modes                      : 1..{n}")
    print(f"prime-power xmax                  : {xmax:,}")
    print(f"continuum GL order                : {args.continuum_gl_order}")
    print("=" * 150)

    print("[arithmetic] sieving prime powers for NEW shells ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    atom_u = np.log(atom_x)
    atom_base = atom_afac / np.sqrt(atom_x)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    nodes, weights = leggauss(args.continuum_gl_order)

    new_rows = []

    for offset, (L, M) in enumerate(new_pairs, start=1):
        shell = last_shell + offset
        print(f"[new shell {shell}] {L}->{M} ...", flush=True)

        reg = np.exp(-atom_x/M) - np.exp(-atom_x/L)
        aw = atom_base * reg

        dP = np.zeros(n, dtype=np.complex128)

        for i in range(0, len(atom_u), args.prime_chunk):
            u = atom_u[i:i+args.prime_chunk]
            w = aw[i:i+args.prime_chunk]
            dP += np.exp(1j*np.outer(E, u)) @ w

        dM = np.array([
            continuum_complex(
                float(Ek), L, M,
                2.0, float(xmax),
                nodes, weights
            )
            for Ek in E
        ], dtype=np.complex128)

        Z = (dM-dP)/math.pi

        for j in range(n):
            new_rows.append(dict(
                shell=shell,
                L=L,
                M=M,
                k=int(karr[j]),
                E_frozen=float(E[j]),
                Z_real=float(Z[j].real),
                Z_imag=float(Z[j].imag),
                Z_abs=float(abs(Z[j])),
                phase=float(np.angle(Z[j])),
            ))

        print(
            f"          |Z|_1={np.sum(np.abs(Z)):.6e}  "
            f"|Im|_1={np.sum(np.abs(Z.imag)):.6e}  "
            f"|Re|_1={np.sum(np.abs(Z.real)):.6e}"
        )

    all_df = pd.concat(
        [old[list(required)].copy(), pd.DataFrame(new_rows)],
        ignore_index=True,
    ).sort_values(["shell", "k"])

    # ------------------------------------------------------------------
    # shell-level summaries
    # ------------------------------------------------------------------
    shell_rows = []

    for shell in sorted(all_df["shell"].unique()):
        g = all_df[all_df["shell"] == shell].sort_values("k")

        Z = (
            g["Z_real"].to_numpy(dtype=float)
            + 1j*g["Z_imag"].to_numpy(dtype=float)
        )

        shell_rows.append(dict(
            shell=int(shell),
            L=int(g.iloc[0]["L"]),
            M=int(g.iloc[0]["M"]),
            ratio_M_over_L=float(g.iloc[0]["M"]/g.iloc[0]["L"]),
            complex_l1=float(np.sum(np.abs(Z))),
            imag_l1=float(np.sum(np.abs(Z.imag))),
            real_l1=float(np.sum(np.abs(Z.real))),
        ))

    for i, r in enumerate(shell_rows):
        if i == 0:
            r["complex_ratio"] = np.nan
            r["imag_ratio"] = np.nan
        else:
            r["complex_ratio"] = (
                r["complex_l1"]/shell_rows[i-1]["complex_l1"]
            )
            r["imag_ratio"] = (
                r["imag_l1"]/shell_rows[i-1]["imag_l1"]
            )

    # ------------------------------------------------------------------
    # per-mode Dirichlet/Abel diagnostics
    # ------------------------------------------------------------------
    mode_rows = []
    mode_series = {}

    for k in sorted(all_df["k"].unique()):
        g = all_df[all_df["k"] == k].sort_values("shell")

        Lleft = g["L"].to_numpy(dtype=float)
        Z = (
            g["Z_real"].to_numpy(dtype=float)
            + 1j*g["Z_imag"].to_numpy(dtype=float)
        )
        amp = np.abs(Z)

        # Unit phase, safely handle a zero.
        unit = np.ones_like(Z)
        nz = amp > 0
        unit[nz] = Z[nz]/amp[nz]

        phase = np.unwrap(np.angle(Z))

        # Candidate logarithmic decay:
        #   a_j ~ C / (log L_j)^q
        mask = amp > 0
        coef_log, r2_log = linear_fit(
            np.log(np.log(Lleft[mask])),
            np.log(amp[mask]),
        )
        q = float(-coef_log[1])

        # Compare with pure power as a descriptive diagnostic only.
        coef_pow, r2_pow = linear_fit(
            np.log(Lleft[mask]),
            np.log(amp[mask]),
        )
        alpha = float(-coef_pow[1])

        # Phase trend versus log L is a useful but non-required diagnostic.
        coef_phase, r2_phase = linear_fit(
            np.log(Lleft),
            phase,
        )
        omega_logL = float(coef_phase[1])

        amp_tv = float(np.sum(np.abs(np.diff(amp))))
        amp_drop = float(amp[-1]/max(amp[0], 1e-300))

        unit_block_bound = block_phase_bound(unit, 0)
        actual_block_env = block_actual_envelope(Z, 0)

        dirichlet_bound = unit_block_bound * (
            amp[0] + amp_tv
        )

        mode_rows.append(dict(
            k=int(k),
            E_frozen=float(g.iloc[0]["E_frozen"]),
            shells=len(g),
            amp_first=float(amp[0]),
            amp_last=float(amp[-1]),
            amp_last_over_first=amp_drop,
            amplitude_total_variation=amp_tv,
            variation_over_first=amp_tv/max(amp[0], 1e-300),
            log_decay_q=q,
            log_decay_R2=float(r2_log),
            power_alpha=alpha,
            power_R2=float(r2_pow),
            phase_omega_per_logL=omega_logL,
            phase_logL_R2=float(r2_phase),
            unit_phase_block_bound=unit_block_bound,
            actual_complex_block_envelope=actual_block_env,
            dirichlet_abel_bound=dirichlet_bound,
            actual_over_dirichlet_bound=(
                actual_block_env/max(dirichlet_bound, 1e-300)
            ),
        ))

        mode_series[int(k)] = dict(
            L=Lleft,
            Z=Z,
            amp=amp,
            unit=unit,
        )

    # ------------------------------------------------------------------
    # genuine finite-horizon tail envelopes, modewise then summed.
    # ------------------------------------------------------------------
    shells = sorted(all_df["shell"].unique())
    tail_rows = []

    for start_idx, shell0 in enumerate(shells):
        remaining = len(shells)-start_idx
        if remaining < 1:
            continue

        aggregate_actual = 0.0
        aggregate_dirichlet = 0.0
        aggregate_unit_B = 0.0
        aggregate_amp_start = 0.0
        aggregate_amp_variation = 0.0

        q_positive = 0

        for mrow in mode_rows:
            k = int(mrow["k"])
            s = mode_series[k]

            Z = s["Z"]
            amp = s["amp"]
            unit = s["unit"]

            actual = block_actual_envelope(Z, start_idx)
            B = block_phase_bound(unit, start_idx)

            if start_idx < len(amp)-1:
                variation = float(
                    np.sum(np.abs(np.diff(amp[start_idx:])))
                )
            else:
                variation = 0.0

            bound = B * (amp[start_idx] + variation)

            aggregate_actual += actual
            aggregate_dirichlet += bound
            aggregate_unit_B += B
            aggregate_amp_start += float(amp[start_idx])
            aggregate_amp_variation += variation

            if mrow["log_decay_q"] > 0:
                q_positive += 1

        row = dict(
            shell0=int(shell0),
            L0=int(shell_rows[start_idx]["L"]),
            remaining_shells=remaining,
            aggregate_actual_complex_tail_envelope=aggregate_actual,
            aggregate_dirichlet_abel_bound=aggregate_dirichlet,
            sum_unit_phase_block_bounds=aggregate_unit_B,
            sum_starting_amplitudes=aggregate_amp_start,
            sum_tail_amplitude_variation=aggregate_amp_variation,
            positive_q_fraction=q_positive/len(mode_rows),
        )

        if not tail_rows:
            row["actual_envelope_ratio"] = np.nan
            row["dirichlet_bound_ratio"] = np.nan
        else:
            prev = tail_rows[-1]
            row["actual_envelope_ratio"] = (
                aggregate_actual /
                max(prev["aggregate_actual_complex_tail_envelope"], 1e-300)
            )
            row["dirichlet_bound_ratio"] = (
                aggregate_dirichlet /
                max(prev["aggregate_dirichlet_abel_bound"], 1e-300)
            )

        tail_rows.append(row)

    # Latest tail with at least 3 observed shells.
    candidates = [r for r in tail_rows if r["remaining_shells"] >= 3]
    latest = candidates[-1]

    positive_q_fraction = float(
        np.mean([r["log_decay_q"] > 0 for r in mode_rows])
    )
    median_q = float(np.median([r["log_decay_q"] for r in mode_rows]))
    median_log_r2 = float(
        np.median([r["log_decay_R2"] for r in mode_rows])
    )

    actual_tail_pass = (
        np.isfinite(latest["actual_envelope_ratio"])
        and latest["actual_envelope_ratio"]
        < args.tail_envelope_ratio_gate
    )
    dirichlet_tail_pass = (
        np.isfinite(latest["dirichlet_bound_ratio"])
        and latest["dirichlet_bound_ratio"]
        < args.dirichlet_bound_ratio_gate
    )
    decay_pass = (
        positive_q_fraction >= args.minimum_positive_q_fraction
    )

    if decay_pass and actual_tail_pass and dirichlet_tail_pass:
        verdict = "DIRICHLET_CONDITIONAL_CAUCHY_MECHANISM_STRONGLY_SUPPORTED"
    elif decay_pass and actual_tail_pass:
        verdict = "CONDITIONAL_CAUCHY_SUPPORTED_DIRICHLET_BOUND_MIXED"
    else:
        verdict = "DIRICHLET_CONDITIONAL_CAUCHY_MECHANISM_UNRESOLVED"

    # ------------------------------------------------------------------
    # save
    # ------------------------------------------------------------------
    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )
    pd.DataFrame(mode_rows).to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    pd.DataFrame(tail_rows).to_csv(
        args.prefix + "_TAILS.csv", index=False
    )

    summary = dict(
        version=161,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        candidate_lemma=(
            "For each fixed mode k, z_j=a_j u_j. "
            "If a_j->0 with tail variation ->0 and unit-phase partial sums "
            "are uniformly bounded, then sum_j z_j converges by summation "
            "by parts. Finite N then gives finite-block complex Cauchy."
        ),
        shell_count=len(shells),
        new_pairs=new_pairs,
        mode_count=n,
        positive_log_decay_q_fraction=positive_q_fraction,
        median_log_decay_q=median_q,
        median_log_decay_R2=median_log_r2,
        latest_ge3_tail=latest,
        decay_pass=decay_pass,
        actual_tail_envelope_pass=actual_tail_pass,
        dirichlet_bound_contraction_pass=dirichlet_tail_pass,
        verdict=verdict,
        proof_gap=(
            "A script cannot prove the infinite-tail conditions. "
            "A proof would need analytic estimates showing, uniformly on "
            "the finite spectral block, (i) amplitude tends to zero with "
            "vanishing tail variation and (ii) the unit-phase partial sums "
            "are bounded independently of the number of regulator shells."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Combined adjacent shell sequence")
    print("-" * 150)
    print(
        f"{'shell':>6} {'pair':>21} {'|Z|_1':>13} "
        f"{'ratio':>10} {'|Im|_1':>13} {'Im ratio':>10}"
    )
    for r in shell_rows:
        print(
            f"{r['shell']:6d} "
            f"{r['L']:>9d}->{r['M']:<9d} "
            f"{r['complex_l1']:13.6e} "
            f"{r['complex_ratio']:10.6f} "
            f"{r['imag_l1']:13.6e} "
            f"{r['imag_ratio']:10.6f}"
        )

    print()
    print("Modewise Dirichlet diagnostics — worst/interesting modes")
    print("-" * 150)

    mdf = pd.DataFrame(mode_rows)
    show = pd.concat([
        mdf.nsmallest(6, "log_decay_q"),
        mdf.nlargest(6, "unit_phase_block_bound"),
    ]).drop_duplicates("k").sort_values("k")

    print(
        f"{'k':>4} {'a_last/a_first':>15} {'q_log':>10} "
        f"{'R2_log':>10} {'alpha_pow':>11} "
        f"{'phase B':>10} {'TV/a0':>10} {'actual/bound':>13}"
    )
    for _, r in show.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['amp_last_over_first']:15.6f} "
            f"{r['log_decay_q']:10.6f} "
            f"{r['log_decay_R2']:10.6f} "
            f"{r['power_alpha']:11.6f} "
            f"{r['unit_phase_block_bound']:10.4f} "
            f"{r['variation_over_first']:10.4f} "
            f"{r['actual_over_dirichlet_bound']:13.6f}"
        )

    print()
    print("Tail-set conditional-Cauchy diagnostics")
    print("-" * 150)
    print(
        f"{'L0':>10} {'shells':>7} {'actual envelope':>18} "
        f"{'ratio':>10} {'Dirichlet bound':>18} {'ratio':>10} "
        f"{'sum phase B':>13} {'amp TV':>13}"
    )
    for r in tail_rows:
        print(
            f"{r['L0']:10d} "
            f"{r['remaining_shells']:7d} "
            f"{r['aggregate_actual_complex_tail_envelope']:18.6e} "
            f"{r['actual_envelope_ratio']:10.6f} "
            f"{r['aggregate_dirichlet_abel_bound']:18.6e} "
            f"{r['dirichlet_bound_ratio']:10.6f} "
            f"{r['sum_unit_phase_block_bounds']:13.6e} "
            f"{r['sum_tail_amplitude_variation']:13.6e}"
        )

    print()
    print("=" * 150)
    print(f"positive log-decay q fraction       : {positive_q_fraction:.6f}")
    print(f"median log-decay q                  : {median_q:.9f}")
    print(f"median log-decay R2                 : {median_log_r2:.6f}")
    print(f"latest >=3-shell actual ratio       : {latest['actual_envelope_ratio']:.9f}")
    print(f"latest >=3-shell Dirichlet ratio    : {latest['dirichlet_bound_ratio']:.9f}")
    print(f"amplitude-decay pass                : {decay_pass}")
    print(f"actual tail-envelope pass           : {actual_tail_pass}")
    print(f"Dirichlet-bound contraction pass    : {dirichlet_tail_pass}")
    print(f"VERDICT                             : {verdict}")
    print("=" * 150)
    print("PROOF TARGET:")
    print("  For each fixed finite spectral block prove, on a geometric cutoff")
    print("  sequence, that z_{j,k}=a_{j,k}u_{j,k} satisfies:")
    print()
    print("      a_{j,k} -> 0,")
    print("      sum_{j>=J}|a_{j+1,k}-a_{j,k}| -> 0,")
    print("      sup_{J<=m<=n}|sum_{j=m}^n u_{j,k}| <= B_k < infinity.")
    print()
    print("  Summation by parts then gives the finite-block Cauchy lemma even")
    print("  when sum_j |z_{j,k}| diverges.")


if __name__ == "__main__":
    main()
