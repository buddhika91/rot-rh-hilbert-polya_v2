#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v112 — Staircase Primitive Mechanism / L-Scaling Audit
==============================================================

Consumes the already-written v111 cell CSV and determines WHY the primitive

    A_K = sum_{k< K} int_{E_k}^{E_{k+1}} (F_L(E)-k) dE

stays small.

Two competing mechanisms are tested:

  H1: cellwise 1/L shrinkage
      Qarea_{k,L} ~ c_k/L.

  H2: persistent oscillatory cancellation in k
      Qarea_{k,L} has a nonzero L->infinity limit but signed cumulative sums
      remain bounded because neighboring/correlated cell areas cancel.

This matters analytically:
  * H1 suggests a direct finite-L Abel/phase perturbation theorem.
  * H2 suggests a bounded-discrepancy / summation-by-parts theorem in the
    spectral index k.

No Xi, zeta, or known-zero data are used.
No roots or phases are recomputed.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v112"
BUILD = "2026-08-17-staircase-primitive-mechanism-l-scaling-v112"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fv(row, key):
    return float(row[key])


def iv(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def lag_corr(x, lag=1):
    x = np.asarray(x, float)
    if len(x) <= lag:
        return float("nan")
    a = x[:-lag]
    b = x[lag:]
    if np.std(a) == 0 or np.std(b) == 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def sign_change_fraction(x):
    x = np.asarray(x, float)
    s = np.sign(x)
    nz = s[s != 0]
    if len(nz) < 2:
        return 0.0
    return float(np.mean(nz[1:] != nz[:-1]))


def pair_cancellation_ratio(x):
    """
    0 = perfect pair cancellation; 1 = no cancellation.
    """
    x = np.asarray(x, float)
    n = len(x) // 2
    if n == 0:
        return float("nan")
    a = x[:2*n:2]
    b = x[1:2*n:2]
    num = np.sum(np.abs(a + b))
    den = np.sum(np.abs(a) + np.abs(b))
    return float(num / max(den, EPS))


def cumulative_stats(x):
    c = np.cumsum(np.asarray(x, float))
    return {
        "final": float(c[-1]) if len(c) else 0.0,
        "max_abs": float(np.max(np.abs(c))) if len(c) else 0.0,
        "rms": float(np.sqrt(np.mean(c*c))) if len(c) else 0.0,
    }


def linear_fit_in_invL(Ls, vals):
    """
    Fit vals(L)=A_inf + C/L by least squares.
    """
    Ls = np.asarray(Ls, float)
    vals = np.asarray(vals, float)
    X = np.column_stack([np.ones(len(Ls)), 1.0/Ls])
    beta, *_ = np.linalg.lstsq(X, vals, rcond=None)
    pred = X @ beta
    resid = vals - pred
    return float(beta[0]), float(beta[1]), float(np.linalg.norm(resid))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v111-prefix",
        default="rot_rh_exact_staircase_block_primitive_v111",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--k-min", type=int, default=48)
    ap.add_argument("--k-max", type=int, default=127)
    ap.add_argument(
        "--prefix",
        default="rot_rh_staircase_primitive_mechanism_v112",
    )
    args = ap.parse_args()

    Ls = [int(x.strip()) for x in args.L_list.split(",") if x.strip()]
    vp = Path(args.v111_prefix).expanduser().resolve()
    cells_path = Path(str(vp) + "_CELLS.csv")
    if not cells_path.exists():
        raise FileNotFoundError(f"Missing {cells_path}")

    raw = read_csv(cells_path)
    rows = [
        r for r in raw
        if iv(r, "L") in Ls
        and args.k_min <= iv(r, "cell_k") <= args.k_max
    ]

    byL = {}
    for L in Ls:
        rr = sorted(
            [r for r in rows if iv(r, "L") == L],
            key=lambda r: iv(r, "cell_k"),
        )
        byL[L] = rr

    common_k = sorted(
        set.intersection(
            *[
                {iv(r, "cell_k") for r in byL[L]}
                for L in Ls
            ]
        )
    )
    if not common_k:
        raise RuntimeError("No common cells across requested L values.")

    areas = {}
    widths = {}
    for L in Ls:
        mp = {iv(r, "cell_k"): r for r in byL[L]}
        areas[L] = np.asarray([fv(mp[k], "Q_area") for k in common_k], float)
        widths[L] = np.asarray([fv(mp[k], "width") for k in common_k], float)

    print("=" * 144)
    print("ROT-RH v112 — STAIRCASE PRIMITIVE MECHANISM / L-SCALING AUDIT")
    print("=" * 144)
    print("source v111 cells               :", cells_path)
    print("L ladder                        :", Ls)
    print("common cell range               :", f"{common_k[0]}..{common_k[-1]}")
    print("common cell count               :", len(common_k))
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 144)

    summary = []
    for L in Ls:
        x = areas[L]
        cs = cumulative_stats(x)
        row = {
            "L": L,
            "cell_count": len(x),
            "mean_area": float(np.mean(x)),
            "mean_abs_area": float(np.mean(np.abs(x))),
            "rms_area": float(np.sqrt(np.mean(x*x))),
            "max_abs_area": float(np.max(np.abs(x))),
            "sign_change_fraction": sign_change_fraction(x),
            "lag1_correlation": lag_corr(x, 1),
            "lag2_correlation": lag_corr(x, 2),
            "pair_cancellation_ratio": pair_cancellation_ratio(x),
            "cum_final": cs["final"],
            "cum_max_abs": cs["max_abs"],
            "cum_rms": cs["rms"],
            "mean_cell_width": float(np.mean(widths[L])),
            "max_cell_width": float(np.max(widths[L])),
        }
        summary.append(row)
        print(
            f"L={L:<6d}: mean|area|={row['mean_abs_area']:.3e} "
            f"max|area|={row['max_abs_area']:.3e} "
            f"cumMax={row['cum_max_abs']:.3e} "
            f"signFlip={row['sign_change_fraction']:.3f} "
            f"lag1={row['lag1_correlation']:+.3f} "
            f"pairCancel={row['pair_cancellation_ratio']:.3f}"
        )

    print("[1] Pairwise L-scaling", flush=True)
    pair_rows = []
    for L0, L1 in zip(Ls[:-1], Ls[1:]):
        x0 = areas[L0]
        x1 = areas[L1]

        # Best scalar x1 ~ alpha*x0.
        alpha = float(np.dot(x0, x1) / max(np.dot(x0, x0), EPS))
        residual = float(
            np.linalg.norm(x1 - alpha*x0) / max(np.linalg.norm(x1), EPS)
        )
        corr = float(np.corrcoef(x0, x1)[0, 1])

        # 1/L hypothesis predicts alpha=L0/L1.
        alpha_1L = L0 / L1
        residual_1L = float(
            np.linalg.norm(x1 - alpha_1L*x0)
            / max(np.linalg.norm(x1), EPS)
        )

        # Compare L*x directly.
        scaled_rel = float(
            np.linalg.norm(L1*x1 - L0*x0)
            / max(np.linalg.norm(L1*x1), EPS)
        )

        row = {
            "L_from": L0,
            "L_to": L1,
            "area_correlation": corr,
            "best_scale_alpha": alpha,
            "one_over_L_expected_alpha": alpha_1L,
            "best_scale_relative_residual": residual,
            "one_over_L_relative_residual": residual_1L,
            "L_times_area_relative_drift": scaled_rel,
        }
        pair_rows.append(row)
        print(
            f"  {L0}->{L1}: corr={corr:+.4f} "
            f"best alpha={alpha:.4f} vs 1/L={alpha_1L:.4f}; "
            f"res(best)={residual:.3e} res(1/L)={residual_1L:.3e}"
        )

    print("[2] Cellwise A_inf + C/L fits", flush=True)
    fit_rows = []
    Ainf = []
    Ccoef = []
    current = areas[Ls[-1]]
    for i, k in enumerate(common_k):
        vals = [areas[L][i] for L in Ls]
        ai, ci, resid = linear_fit_in_invL(Ls, vals)
        Ainf.append(ai)
        Ccoef.append(ci)
        fit_rows.append({
            "cell_k": k,
            "Ainf_fit": ai,
            "C_over_L_fit": ci,
            "fit_abs_residual_l2": resid,
            "area_Lmax": current[i],
            "Ainf_over_area_Lmax":
                abs(ai) / max(abs(current[i]), EPS),
        })

    Ainf = np.asarray(Ainf, float)
    Ccoef = np.asarray(Ccoef, float)

    Ainf_rel = float(
        np.linalg.norm(Ainf) / max(np.linalg.norm(current), EPS)
    )
    Ainf_cum = cumulative_stats(Ainf)
    current_cum = cumulative_stats(current)

    print(
        "  ||A_inf|| / ||area_Lmax||       :",
        f"{Ainf_rel:.6e}"
    )
    print(
        "  fitted A_inf cumulative max     :",
        f"{Ainf_cum['max_abs']:.6e}"
    )
    print(
        "  current-L cumulative max        :",
        f"{current_cum['max_abs']:.6e}"
    )

    # Test whether cancellation, not shrinkage, is the dominant mechanism.
    final_summary = [r for r in summary if r["L"] == Ls[-1]][0]
    latest_pair = pair_rows[-1]

    h1_cellwise_1L = (
        latest_pair["one_over_L_relative_residual"] < 0.25
        and Ainf_rel < 0.25
    )
    h2_persistent_cancellation = (
        final_summary["sign_change_fraction"] > 0.4
        and abs(final_summary["lag1_correlation"]) > 0.1
        and final_summary["cum_max_abs"]
            < 5.0 * final_summary["mean_abs_area"] * math.sqrt(len(common_k))
    )

    if h1_cellwise_1L and not h2_persistent_cancellation:
        mechanism = "CELLWISE_1_OVER_L_SHRINKAGE"
    elif h2_persistent_cancellation and not h1_cellwise_1L:
        mechanism = "PERSISTENT_INDEX_CANCELLATION"
    elif h1_cellwise_1L and h2_persistent_cancellation:
        mechanism = "MIXED_1_OVER_L_PLUS_INDEX_CANCELLATION"
    else:
        mechanism = "UNRESOLVED"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_SUMMARY.csv"), summary)
    write_csv(Path(str(prefix) + "_PAIR_SCALING.csv"), pair_rows)
    write_csv(Path(str(prefix) + "_CELL_FITS.csv"), fit_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V112_MECHANISM_DIAGNOSTIC_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "common_cell_count": len(common_k),
        "Ainf_norm_relative_to_current": Ainf_rel,
        "Ainf_cumulative_max": Ainf_cum["max_abs"],
        "current_cumulative_max": current_cum["max_abs"],
        "latest_pair": latest_pair,
        "final_summary": final_summary,
        "interpretation": (
            "If cellwise 1/L shrinkage fails but signed areas show stable "
            "anti-correlation/cancellation, the proof target should be a "
            "bounded partial-sum theorem for cell areas. If A_inf is near "
            "zero and L*area stabilizes, target a finite-L perturbation "
            "theorem instead."
        ),
    }
    vpout = Path(str(prefix) + "_VERDICT.json")
    vpout.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 144)
    print("FINAL v112 VERDICT")
    print("=" * 144)
    print("mechanism                        :", mechanism)
    print("Ainf norm/current norm           :", f"{Ainf_rel:.12e}")
    print("Ainf cumulative max              :", f"{Ainf_cum['max_abs']:.12e}")
    print("current cumulative max           :", f"{current_cum['max_abs']:.12e}")
    print("latest 1/L residual              :", f"{latest_pair['one_over_L_relative_residual']:.12e}")
    print("latest area correlation          :", f"{latest_pair['area_correlation']:.12e}")
    print("final sign-change fraction       :", f"{final_summary['sign_change_fraction']:.12e}")
    print("final lag-1 correlation          :", f"{final_summary['lag1_correlation']:.12e}")
    print("final pair-cancellation ratio    :", f"{final_summary['pair_cancellation_ratio']:.12e}")
    print("RH proof                         : FALSE")
    print("verdict file                     :", vpout)
    print("=" * 144)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
