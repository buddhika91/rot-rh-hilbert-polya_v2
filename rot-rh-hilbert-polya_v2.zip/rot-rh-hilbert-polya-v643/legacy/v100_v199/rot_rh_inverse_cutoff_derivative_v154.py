#!/usr/bin/env python3
"""
ROT-RH v154 — INVERSE-CUTOFF DERIVATIVE / INTEGRABILITY AUDIT

ZERO-COST postprocessor.
Uses v146 all-pairs results and v153 high-order Abel results.
No new prime sums, phase builds, root solves, Xi, zeta, or known zeros.

Core idea
---------
Use the natural regulator parameter

    a = 1/L.

For a finite spectral block define

    D_N(L,M)
      = sum_{k<=N} |lambda_k(L)-lambda_k(M)|.

If the trace-norm derivative obeys

    ||dK_a/da||_{1,N} <= C a^(-rho),       rho < 1,

then it is integrable at a=0 and

    D_N(L,M)
      <= C/(1-rho)
         |a_L^(1-rho) - a_M^(1-rho)|,

which proves finite-block cutoff independence.

For an interval L<M, the secant slopes

    S_def   = sum|delta_k(L,M)| / |a_L-a_M|,
    S_root  = sum|E_k(M)-E_k(L)| / |a_L-a_M|,
    S_trace = D_N(L,M) / |a_L-a_M|

are observable averages of the corresponding regulator derivatives.

v154 asks whether these slopes behave like

    S(a) ~ C a^(-rho)

with rho<1.

It also uses the highest-order v153 signed weighted-PNT discrepancy

    D0(L,M)

and evaluates

    S0 = |D0(L,M)| / |a_L-a_M|.

A nearly constant S0 is evidence that the zero-frequency centered kernel
is differentiable in the inverse-cutoff parameter.

Important
---------
This does NOT prove derivative integrability.  It identifies the exact
quantity that an analytic cutoff-removal theorem should bound:

    integral_0^a ||dK_s/ds||_1 ds < infinity.

Outputs
-------
<prefix>_PAIRS.csv
<prefix>_LOCAL_EXPONENTS.csv
<prefix>_FITS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


METRICS = [
    "kernel0",
    "defect",
    "root",
    "implicit",
    "trace",
]


def parse_pairs(s):
    out = []
    for item in s.split(","):
        item = item.strip()
        if not item:
            continue
        a, b = item.split(":")
        out.append((int(a), int(b)))
    return out


def fit_power(aeff, slope):
    """
    Fit slope = C * aeff^(-rho).
    log slope = log C - rho log aeff.
    """
    aeff = np.asarray(aeff, dtype=float)
    slope = np.asarray(slope, dtype=float)

    mask = (
        (aeff > 0)
        & (slope > 0)
        & np.isfinite(aeff)
        & np.isfinite(slope)
    )

    X = np.log(aeff[mask])
    Y = np.log(slope[mask])

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)

    logC = float(coef[0])
    rho = float(-coef[1])

    pred = A @ coef
    ss_res = float(np.sum((Y - pred)**2))
    ss_tot = float(np.sum((Y - np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return rho, math.exp(logC), r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--pairs-csv",
        default="rot_rh_all_pairs_local_cutoff_v146_PAIRS.csv",
    )
    ap.add_argument(
        "--abel-orders-csv",
        default="rot_rh_abel_gauss_convergence_v153_ORDERS.csv",
    )
    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument(
        "--abel-order",
        type=int,
        default=16,
    )
    ap.add_argument(
        "--rho-gate",
        type=float,
        default=1.0,
        help="Integrability requires rho < 1.",
    )
    ap.add_argument(
        "--late-rho-gate",
        type=float,
        default=0.95,
        help="Conservative gate for latest local exponent.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_inverse_cutoff_derivative_v154",
    )

    args = ap.parse_args()

    chosen_pairs = parse_pairs(args.pairs)

    pair_df = pd.read_csv(args.pairs_csv)
    abel_df = pd.read_csv(args.abel_orders_csv)

    # Highest-order certified Abel data.
    abel_df = abel_df[abel_df["order"] == args.abel_order].copy()

    rows = []

    for L, M in chosen_pairs:
        p = pair_df[
            (pair_df["L_a"] == L)
            & (pair_df["L_b"] == M)
        ]
        if len(p) != 1:
            raise RuntimeError(
                f"Expected exactly one v146 pair row for {L}->{M}, got {len(p)}"
            )
        p = p.iloc[0]

        aL = 1.0 / float(L)
        aM = 1.0 / float(M)
        da = abs(aL - aM)

        # geometric mean in the a variable = 1/sqrt(LM)
        aeff = math.sqrt(aL * aM)
        Leff = 1.0 / aeff

        arow = abel_df[
            (abel_df["L"] == L)
            & (abel_df["M"] == M)
        ]
        if len(arow) != 1:
            raise RuntimeError(
                f"Expected exactly one v153 q={args.abel_order} row "
                f"for {L}->{M}, got {len(arow)}"
            )
        arow = arow.iloc[0]

        kernel0 = abs(float(arow["D_direct"]))
        defect = float(p["sum_abs_defect_1_N"])
        root = float(p["sum_abs_shift_1_N"])
        implicit = float(p["sum_implicit_bound_1_N"])
        trace = float(p["trace_distance_1_N"])

        vals = dict(
            kernel0=kernel0,
            defect=defect,
            root=root,
            implicit=implicit,
            trace=trace,
        )

        row = dict(
            L=L,
            M=M,
            ratio_L=float(M/L),
            a_L=aL,
            a_M=aM,
            delta_a=da,
            a_eff=aeff,
            L_eff=Leff,
        )

        for key, value in vals.items():
            slope = value / da
            row[key] = value
            row[key + "_secant_slope"] = slope

            # Integrability diagnostic:
            # if slope ~ a^-rho, then a*slope ~ a^(1-rho) -> 0 iff rho<1.
            row[key + "_a_times_slope"] = aeff * slope

        rows.append(row)

    # ------------------------------------------------------------------
    # local rho between consecutive intervals
    # ------------------------------------------------------------------
    local_rows = []

    for i in range(1, len(rows)):
        prev = rows[i-1]
        cur = rows[i]

        lr = dict(
            previous_pair=f"{prev['L']}->{prev['M']}",
            current_pair=f"{cur['L']}->{cur['M']}",
            aeff_ratio=cur["a_eff"]/prev["a_eff"],
            Leff_ratio=cur["L_eff"]/prev["L_eff"],
        )

        for metric in METRICS:
            s0 = prev[metric + "_secant_slope"]
            s1 = cur[metric + "_secant_slope"]

            # s ~ a^-rho
            rho = (
                -math.log(s1/s0)
                / math.log(cur["a_eff"]/prev["a_eff"])
            )
            alpha = 1.0 - rho

            lr[metric + "_rho"] = rho
            lr[metric + "_alpha"] = alpha
            lr[metric + "_integrable"] = int(rho < args.rho_gate)

        local_rows.append(lr)

    # ------------------------------------------------------------------
    # global fits
    # ------------------------------------------------------------------
    fit_rows = []

    aeff = np.asarray([r["a_eff"] for r in rows], dtype=float)

    for metric in METRICS:
        slopes = np.asarray(
            [r[metric + "_secant_slope"] for r in rows],
            dtype=float,
        )
        rho, C, r2 = fit_power(aeff, slopes)

        fit_rows.append(dict(
            metric=metric,
            rho=rho,
            alpha=1.0-rho,
            C=C,
            R2=r2,
            integrable=int(rho < args.rho_gate),
        ))

    # ------------------------------------------------------------------
    # contraction of a*S — a direct necessary signature of integrability
    # for regularly varying slopes.
    # ------------------------------------------------------------------
    contraction = {}

    for metric in METRICS:
        arr = np.asarray(
            [r[metric + "_a_times_slope"] for r in rows],
            dtype=float,
        )
        contraction[metric] = dict(
            first=float(arr[0]),
            last=float(arr[-1]),
            last_over_first=float(arr[-1]/arr[0]),
            strictly_decreasing=bool(np.all(np.diff(arr) < 0)),
        )

    pair_out = pd.DataFrame(rows)
    local_out = pd.DataFrame(local_rows)
    fit_out = pd.DataFrame(fit_rows)

    pair_out.to_csv(args.prefix + "_PAIRS.csv", index=False)
    local_out.to_csv(args.prefix + "_LOCAL_EXPONENTS.csv", index=False)
    fit_out.to_csv(args.prefix + "_FITS.csv", index=False)

    latest = local_rows[-1]

    latest_rhos = {
        metric: float(latest[metric + "_rho"])
        for metric in METRICS
    }

    # Strong theorem-oriented evidence if:
    # - all global fitted rho < 1,
    # - all latest local rho < conservative late gate,
    # - a*S decreases for defect/root/implicit/trace,
    # - q16 kernel0 slope is essentially bounded (rho near 0).
    all_fit_integrable = all(
        r["rho"] < args.rho_gate for r in fit_rows
    )

    all_latest_integrable = all(
        latest_rhos[m] < args.late_rho_gate
        for m in ["defect", "root", "implicit", "trace"]
    )

    all_as_contract = all(
        contraction[m]["last_over_first"] < 1.0
        for m in ["defect", "root", "implicit", "trace"]
    )

    kernel_fit = next(r for r in fit_rows if r["metric"] == "kernel0")

    kernel_derivative_bounded = abs(kernel_fit["rho"]) < 0.05

    if (
        all_fit_integrable
        and all_latest_integrable
        and all_as_contract
        and kernel_derivative_bounded
    ):
        verdict = "INVERSE_CUTOFF_DERIVATIVE_INTEGRABILITY_STRONGLY_SUPPORTED"
    elif all_fit_integrable and all_as_contract:
        verdict = "DERIVATIVE_INTEGRABILITY_SUPPORTED_LATE_RATE_MIXED"
    else:
        verdict = "INVERSE_CUTOFF_DERIVATIVE_INTEGRABILITY_UNRESOLVED"

    summary = dict(
        version=154,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        regulator_parameter="a=1/L",
        criterion=(
            "If ||dK_a/da||_{1,N} <= C a^{-rho} with rho<1, "
            "then the finite-block derivative is integrable at a=0 "
            "and K_a is Cauchy in finite-rank trace norm."
        ),
        global_fits={
            r["metric"]: dict(
                rho=float(r["rho"]),
                alpha=float(r["alpha"]),
                C=float(r["C"]),
                R2=float(r["R2"]),
                integrable=bool(r["integrable"]),
            )
            for r in fit_rows
        },
        latest_local_rho=latest_rhos,
        a_times_slope_contraction=contraction,
        kernel0_high_order=args.abel_order,
        verdict=verdict,
        analytic_target=(
            "Prove an integrable regulator-derivative bound directly: "
            "sum_{k<=N}|d lambda_k(a)/da| <= C_N a^{-rho_N}, rho_N<1. "
            "Using implicit differentiation, "
            "dE_k/da = -(partial_a F_a)/(partial_E F_a), "
            "so it suffices to control the signed weighted-PNT derivative "
            "partial_a F_a on the finite spectral block together with the "
            "already observed nonvanishing E-derivative."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print("=" * 136)
    print("ROT-RH v154 — INVERSE-CUTOFF DERIVATIVE / INTEGRABILITY AUDIT")
    print("=" * 136)
    print("Xi / zeta / known zeros          : NONE")
    print(f"regulator parameter               : a=1/L")
    print(f"pairs                             : {chosen_pairs}")
    print(f"v153 Abel order                   : {args.abel_order}")
    print("=" * 136)

    print()
    print("Inverse-cutoff secant slopes")
    print("-" * 136)
    print(
        f"{'pair':>18} {'Delta a':>12} "
        f"{'S_kernel0':>13} {'S_def':>13} "
        f"{'S_root':>13} {'S_trace':>13} "
        f"{'a*S_trace':>13}"
    )

    for r in rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{r['delta_a']:12.5e} "
            f"{r['kernel0_secant_slope']:13.6e} "
            f"{r['defect_secant_slope']:13.6e} "
            f"{r['root_secant_slope']:13.6e} "
            f"{r['trace_secant_slope']:13.6e} "
            f"{r['trace_a_times_slope']:13.6e}"
        )

    print()
    print("Local derivative-growth exponents  S(a) ~ a^(-rho)")
    print("-" * 136)
    print(
        f"{'transition':>38} "
        f"{'rho kernel0':>12} {'rho defect':>12} "
        f"{'rho root':>12} {'rho trace':>12}"
    )

    for r in local_rows:
        tr = f"{r['previous_pair']} -> {r['current_pair']}"
        print(
            f"{tr:>38} "
            f"{r['kernel0_rho']:12.6f} "
            f"{r['defect_rho']:12.6f} "
            f"{r['root_rho']:12.6f} "
            f"{r['trace_rho']:12.6f}"
        )

    print()
    print("Global regulator-derivative fits")
    print("-" * 136)
    print(
        f"{'metric':>12} {'rho':>12} {'alpha=1-rho':>16} "
        f"{'R2':>10} {'integrable?':>13}"
    )

    for r in fit_rows:
        print(
            f"{r['metric']:>12} "
            f"{r['rho']:12.6f} "
            f"{r['alpha']:16.6f} "
            f"{r['R2']:10.6f} "
            f"{str(bool(r['integrable'])):>13}"
        )

    print()
    print("a * secant-slope contraction")
    print("-" * 136)
    for metric in METRICS:
        c = contraction[metric]
        print(
            f"{metric:>12}: "
            f"{c['first']:.6e} -> {c['last']:.6e}  "
            f"ratio={c['last_over_first']:.6f}  "
            f"strictly decreasing={c['strictly_decreasing']}"
        )

    print()
    print("=" * 136)
    print(f"latest defect rho                  : {latest_rhos['defect']:.9f}")
    print(f"latest root rho                    : {latest_rhos['root']:.9f}")
    print(f"latest trace rho                   : {latest_rhos['trace']:.9f}")
    print(f"kernel0 fitted rho                 : {kernel_fit['rho']:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 136)
    print("THEOREM TARGET:")
    print("  Prove integrability in a=1/L rather than a particular empirical")
    print("  cutoff power law:")
    print()
    print("      integral_0^a0 sum_{k<=N} |d lambda_k(a)/da| da < infinity.")
    print()
    print("  With the high-k uniform tail lemma, this yields full trace-norm")
    print("  cutoff independence.")


if __name__ == "__main__":
    main()
