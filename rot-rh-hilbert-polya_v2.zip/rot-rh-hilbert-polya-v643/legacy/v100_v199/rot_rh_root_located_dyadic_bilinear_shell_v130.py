#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v130 — Root-Located Dyadic Bilinear Shell / L->infinity Audit
====================================================================

PURPOSE
-------
v129 showed that the strong Mangoldt cancellation seen on the adaptive spectral
mesh is not reproduced by randomized dyadic-band-sign phases even when every
surrogate rebuilds its OWN crossing mesh.

v130 now changes direction.  It does NOT extend the k-staircase.  It attacks the
quantity that controls removal of the arithmetic regulator L.

For the PNT-finite-part counting phase

    F_L(E) = smooth(E) - [P_L(E)-M_L(E)+M_inf^AC(E)]/pi,

let E_k(L) be the first-later crossing

    F_L(E_k(L)) = k - 1/2.

For a dyadic transition L -> 2L define

    DeltaF_k(L) = F_{2L}(E_k(L)) - F_L(E_k(L)).

If a = E_k(L), b = E_k(2L), then exactly

    (b-a) D*_k(L) = -DeltaF_k(L),

where

    D*_k(L) = [F_{2L}(b)-F_{2L}(a)]/(b-a).

A theorem-facing sampled response majorant is

    R_k(L) = |DeltaF_k(L)| / m_k(L),

    m_k(L) = sampled min_{E between a,b} |F'_{2L}(E)|.

The desired analytic theorem would replace the sampled minimum by a proven
infimum and establish a summable future-valid bound, for example

    R_k(L) <= C_k / (log L)^q_k,       q_k > 1,

on all sufficiently large dyadic L.  Then sum_j |E_k(2L_j)-E_k(L_j)| converges
and E_k(L) is Cauchy on the dyadic ladder.

BILINEAR / PNT-ERROR DECOMPOSITION
----------------------------------
The L-dependent smooth and M_inf^AC pieces cancel between F_{2L} and F_L, so

    DeltaF = -(DeltaP - DeltaM)/pi.

For frozen root energy E, write the actual truncated prime-shell test function

    f_{E,L}(n)
      = 1_{n<=N_2} exp(-n/(2L)) sin(E log n)/(sqrt(n) log n)
        - 1_{n<=N_1} exp(-n/L) sin(E log n)/(sqrt(n) log n),

where N_1 and N_2 are the exact finite prime cutoffs used by the v102.1 phase.
Then

    DeltaP = sum_n Lambda(n) f(n).

With psi(n)=sum_{m<=n} Lambda(m) and E_PNT(n)=psi(n)-n, exact discrete Abel
summation gives

    DeltaP = S_main + S_error,

    S_main  = N f(N) + sum_{n=2}^{N-1} n [f(n)-f(n+1)],
    S_error = E_PNT(N)f(N)
              + sum_{n=2}^{N-1} E_PNT(n)[f(n)-f(n+1)].

Hence the exact centered shell is

    DeltaP - DeltaM = (S_main-DeltaM) + S_error.

v130 records the bilinear cosine between E_PNT(n) and Delta f(n), plus a
logarithmic arithmetic-scale decomposition of the signed interior transform.

SCIENTIFIC BOUNDARY
-------------------
* NO Xi evaluations.
* NO zeta evaluations.
* NO known Riemann-zero ordinates.
* A numerical PASS means only that the sampled dyadic data support the precise
  summability theorem target.  It is NOT an L->infinity proof and NOT RH.
* The sampled derivative floor is NOT an analytic infimum.

Outputs
-------
  <prefix>_POINTS.csv
  <prefix>_K_SUMMARY.csv
  <prefix>_L_SUMMARY.csv
  <prefix>_VERDICT.json

Build: 2026-08-18-root-located-dyadic-bilinear-shell-v130
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

VERSION = "v130"
BUILD = "2026-08-18-root-located-dyadic-bilinear-shell-v130"
EPS = 1.0e-300


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def rms(x) -> float:
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x * x))) if x.size else float("nan")


def safe_norm(x) -> float:
    x = np.asarray(x, float)
    return float(np.sqrt(np.dot(x, x)))


def corr_cos(x, y) -> float:
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    nx = safe_norm(x)
    ny = safe_norm(y)
    if nx <= EPS or ny <= EPS:
        return float("nan")
    return float(np.dot(x, y) / (nx * ny))


def relerr(a: float, b: float, floor: float = 1e-30) -> float:
    return float(abs(a - b) / max(abs(a), abs(b), floor))


def finite_or_none(x):
    x = float(x)
    return x if math.isfinite(x) else None


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [json_safe(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating, float)):
        x = float(obj)
        return x if math.isfinite(x) else None
    if isinstance(obj, (np.integer, int)):
        return int(obj)
    if isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    return obj


def fit_decay(L: np.ndarray, y: np.ndarray, fit_last: int) -> dict:
    """Fit y ~ C L^-alpha and y ~ C (log L)^-q on the late points."""
    L = np.asarray(L, float)
    y = np.asarray(y, float)
    good = np.isfinite(L) & np.isfinite(y) & (L > 1.0) & (y > 0.0)
    L = L[good]
    y = y[good]
    if len(L) < 3:
        return {
            "n_fit": int(len(L)),
            "alpha_power_L": float("nan"),
            "q_log_power": float("nan"),
            "r2_power_L": float("nan"),
            "r2_log_power": float("nan"),
        }

    n = min(int(fit_last), len(L))
    L = L[-n:]
    y = y[-n:]
    ly = np.log(y)

    def one_fit(x):
        p = np.polyfit(x, ly, 1)
        pred = p[0] * x + p[1]
        ssr = float(np.sum((ly - pred) ** 2))
        sst = float(np.sum((ly - np.mean(ly)) ** 2))
        r2 = 1.0 - ssr / sst if sst > 0 else 1.0
        return float(p[0]), float(p[1]), float(r2)

    slope_L, _, r2_L = one_fit(np.log(L))
    slope_log, _, r2_log = one_fit(np.log(np.log(L)))
    return {
        "n_fit": int(n),
        "alpha_power_L": float(-slope_L),
        "q_log_power": float(-slope_log),
        "r2_power_L": r2_L,
        "r2_log_power": r2_log,
    }


def late_monotone_decreasing(values: Sequence[float], steps: int) -> bool:
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return False
    n = min(len(x), int(steps) + 1)
    z = x[-n:]
    return bool(np.all(z[1:] < z[:-1]))


def suffix_max_envelope(values: Sequence[float]) -> np.ndarray:
    """Smallest non-increasing envelope supported by the observed tail."""
    x = np.asarray(values, float)
    out = np.empty_like(x)
    running = -np.inf
    for i in range(len(x) - 1, -1, -1):
        running = max(running, float(x[i]))
        out[i] = running
    return out


def consecutive_dyadic(Ls: Sequence[int]) -> None:
    if len(Ls) < 4:
        raise ValueError("Need at least four L values (three dyadic transitions).")
    for a, b in zip(Ls[:-1], Ls[1:]):
        if b != 2 * a:
            raise ValueError(
                f"L-list must be consecutive dyadic values; got {a} -> {b}."
            )


# ---------------------------------------------------------------------------
# Exact PNT / Abel shell geometry
# ---------------------------------------------------------------------------

def dense_mangoldt(base, Nmax: int) -> Tuple[np.ndarray, np.ndarray]:
    numbers, lambdas, _ = base.mangoldt_terms(int(Nmax))
    lam = np.zeros(int(Nmax) + 1, float)
    idx = np.asarray(numbers, int)
    np.add.at(lam, idx, np.asarray(lambdas, float))
    psi = np.cumsum(lam)
    return lam, psi


def shell_test_function(
    E: float,
    n: np.ndarray,
    L1: int,
    L2: int,
    N1: int,
    N2: int,
) -> np.ndarray:
    """Actual truncated prime-shell test function f(n), Lambda factored out."""
    n = np.asarray(n, float)
    logn = np.log(n)
    denom = np.sqrt(n) * logn
    phase = np.sin(float(E) * logn)
    w2 = np.exp(-n / float(L2)) * (n <= float(N2))
    w1 = np.exp(-n / float(L1)) * (n <= float(N1))
    return (w2 - w1) * phase / denom


def arithmetic_band_diagnostics(n: np.ndarray, contrib: np.ndarray) -> dict:
    """Signed bilinear contribution grouped by floor(log2 n)."""
    n = np.asarray(n, float)
    contrib = np.asarray(contrib, float)
    if len(n) == 0:
        return {
            "band_count": 0,
            "interior_signed": 0.0,
            "sum_abs_band_signed": 0.0,
            "cross_band_signed_ratio": float("nan"),
        }
    jb = np.floor(np.log2(n)).astype(int)
    sums = []
    for j in np.unique(jb):
        sums.append(float(np.sum(contrib[jb == j])))
    total = float(np.sum(contrib))
    den = float(np.sum(np.abs(sums)))
    return {
        "band_count": int(len(sums)),
        "interior_signed": total,
        "sum_abs_band_signed": den,
        "cross_band_signed_ratio": abs(total) / max(den, EPS),
    }


def abel_shell_geometry(
    base,
    phase1,
    phase2,
    psi: np.ndarray,
    E: float,
) -> dict:
    """
    Exact discrete Abel decomposition of the actual truncated prime shell,
    plus the exact finite-part centered shell after subtracting Delta counterterm.
    """
    N = int(phase2.nmax)
    if len(psi) != N + 1:
        raise ValueError("psi length does not match phase2.nmax")

    n_full = np.arange(2, N + 1, dtype=float)
    f = shell_test_function(
        E, n_full, int(phase1.L), int(phase2.L),
        int(phase1.nmax), int(phase2.nmax),
    )

    # f array is indexed by integer n=2..N; dA corresponds f(n)-f(n+1), n=2..N-1.
    fN = float(f[-1])
    dA = f[:-1] - f[1:]
    n_int = np.arange(2, N, dtype=float)

    psiN = float(psi[N])
    Eall = psi - np.arange(N + 1, dtype=float)

    main = float(N * fN + np.dot(n_int, dA))
    boundary = float(Eall[N] * fN)
    Eint = np.asarray(Eall[2:N], float)
    interior = float(np.dot(Eint, dA))
    error = boundary + interior
    abel_prime = main + error

    prime_delta = float(
        phase2.prime_phase(np.asarray([E]))[0]
        - phase1.prime_phase(np.asarray([E]))[0]
    )
    counter_delta = float(
        phase2.counter.phase(np.asarray([E]))[0]
        - phase1.counter.phase(np.asarray([E]))[0]
    )
    centered_direct = prime_delta - counter_delta
    smooth_discrete_residual = main - counter_delta
    centered_abel = smooth_discrete_residual + error

    cosine = corr_cos(Eint, dA)
    cs_bound = abs(boundary) + safe_norm(Eint) * safe_norm(dA)
    bands = arithmetic_band_diagnostics(n_int, Eint * dA)

    return {
        "Nmax": N,
        "prime_delta": prime_delta,
        "counter_delta": counter_delta,
        "centered_direct": centered_direct,
        "abel_main": main,
        "pnt_error_boundary": boundary,
        "pnt_error_interior": interior,
        "pnt_error_total": error,
        "smooth_discrete_minus_counter": smooth_discrete_residual,
        "abel_prime": abel_prime,
        "centered_abel": centered_abel,
        "prime_abel_abs_residual": abs(abel_prime - prime_delta),
        "prime_abel_rel_residual": relerr(abel_prime, prime_delta),
        "centered_abel_abs_residual": abs(centered_abel - centered_direct),
        "centered_abel_rel_residual": relerr(centered_abel, centered_direct),
        "pnt_error_cosine": cosine,
        "pnt_error_cosine_abs": abs(cosine) if math.isfinite(cosine) else float("nan"),
        "pnt_error_cs_bound": cs_bound,
        "pnt_error_cs_over_actual": cs_bound / max(abs(error), EPS),
        "pnt_error_E_norm": safe_norm(Eint),
        "pnt_error_dA_norm": safe_norm(dA),
        **{f"error_{k}": v for k, v in bands.items()},
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="ROT-RH v130 root-located dyadic bilinear shell / L->infinity audit"
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--L-list",
        default="2000,4000,8000,16000,32000,64000",
        help="Consecutive dyadic finite-part regulators.",
    )
    ap.add_argument(
        "--k-values",
        default="16,32,64,128,256",
        help="Fixed spectral labels to follow through the L ladder.",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--counter-qcheck", type=int, default=16384)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--derivative-samples", type=int, default=65)
    ap.add_argument("--fit-last", type=int, default=5)
    ap.add_argument("--late-monotone-steps", type=int, default=3)

    # Conservative numerical/theorem-precursor gates.  These are preregistered
    # numerical criteria, NOT theorem constants.
    ap.add_argument("--root-residual-tol", type=float, default=1e-8)
    ap.add_argument("--quadrature-tol", type=float, default=5e-6)
    ap.add_argument("--identity-rel-tol", type=float, default=1e-8)
    ap.add_argument("--secant-abs-tol", type=float, default=5e-8)
    ap.add_argument("--mvt-ratio-tol", type=float, default=1.01)
    ap.add_argument("--q-gate", type=float, default=1.10)
    ap.add_argument("--alpha-gate", type=float, default=0.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_root_located_dyadic_bilinear_shell_v130",
    )
    args = ap.parse_args()

    Ls = sorted(set(parse_ints(args.L_list)))
    ks = sorted(set(parse_ints(args.k_values)))
    consecutive_dyadic(Ls)
    if not ks or ks[0] < 1:
        raise ValueError("k-values must contain positive integers.")
    if args.derivative_samples < 3:
        raise ValueError("--derivative-samples must be >=3")
    if args.fit_last < 3:
        raise ValueError("--fit-last must be >=3")

    try:
        code_path = Path(__file__).resolve()
        code_sha = sha256_file(code_path)
    except Exception:
        code_path = None
        code_sha = None

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 170)
    print("ROT-RH v130 — ROOT-LOCATED DYADIC BILINEAR SHELL / L->INFINITY AUDIT")
    print("=" * 170)
    print("L ladder                        :", Ls)
    print("fixed k values                  :", ks)
    print("maximum support depth           :", max(ks))
    print("tail factor                     :", args.tail_factor)
    print("counter q / qcheck              :", args.counter_q, "/", args.counter_qcheck)
    print("derivative samples/segment      :", args.derivative_samples)
    print("late fit points                 :", args.fit_last)
    print("summability q gate              :", args.q_gate)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 170)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    # -----------------------------------------------------------------------
    # 1. Build every zero-free finite-part phase and ordered support.
    # -----------------------------------------------------------------------
    print("[1] Build zero-free finite-part phases and ordered supports", flush=True)
    phases = {}
    supports = {}
    max_depth = max(ks)
    for L in Ls:
        print(f"  L={L}: phase", flush=True)
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        phases[L] = phase
        print(
            f"    terms={len(phase.logs)} nmax={phase.nmax} support depth={max_depth}",
            flush=True,
        )
        support = v102.ordered_support(
            phase,
            depth=int(max_depth),
            scan_points=int(args.scan_points),
            qcheck=int(args.counter_qcheck),
        )
        supports[L] = support
        print(
            "    rootResMax=%.3e qphase=%.3e qder=%.3e Emin/Emax=[%.6f,%.6f]"
            % (
                float(np.max(support.residuals)),
                float(support.quadrature_phase_rel_l2),
                float(support.quadrature_deriv_rel_l2),
                float(support.roots[0]),
                float(support.roots[-1]),
            ),
            flush=True,
        )

    max_root_resid = max(float(np.max(supports[L].residuals)) for L in Ls)
    max_qphase = max(float(supports[L].quadrature_phase_rel_l2) for L in Ls)
    max_qder = max(float(supports[L].quadrature_deriv_rel_l2) for L in Ls)

    # -----------------------------------------------------------------------
    # 2. Root-located dyadic transitions + exact bilinear PNT decomposition.
    # -----------------------------------------------------------------------
    print("[2] Root-located L->2L shell response and exact Abel/PNT split", flush=True)
    point_rows: List[dict] = []

    for L1, L2 in zip(Ls[:-1], Ls[1:]):
        p1 = phases[L1]
        p2 = phases[L2]
        s1 = supports[L1]
        s2 = supports[L2]

        # One exact psi table per dyadic transition; reused for all selected k.
        print(f"  transition {L1}->{L2}: build psi through N={p2.nmax}", flush=True)
        _, psi = dense_mangoldt(base, int(p2.nmax))

        for k in ks:
            a = float(s1.roots[k - 1])
            b = float(s2.roots[k - 1])
            target = float(k) - 0.5
            root_step = b - a
            root_step_abs = abs(root_step)

            F1a = float(p1.F(np.asarray([a]))[0])
            F2a = float(p2.F(np.asarray([a]))[0])
            F2b = float(p2.F(np.asarray([b]))[0])
            deltaF = F2a - F1a

            if abs(root_step) > 1e-15:
                secant_D = (F2b - F2a) / root_step
                secant_step = -deltaF / secant_D if abs(secant_D) > EPS else float("nan")
            else:
                # Degenerate numerical coincidence: use derivative at a for diagnostics.
                secant_D = float(p2.Fprime(np.asarray([a]))[0])
                secant_step = -deltaF / secant_D if abs(secant_D) > EPS else float("nan")

            lo = min(a, b)
            hi = max(a, b)
            if hi - lo < 1e-14:
                egrid = np.asarray([a], float)
            else:
                egrid = np.linspace(lo, hi, int(args.derivative_samples))
            dvals = np.asarray(p2.Fprime(egrid), float)
            deriv_floor = float(np.min(np.abs(dvals)))
            deriv_sign_consistent = bool(np.all(dvals > 0.0) or np.all(dvals < 0.0))
            sampled_bound = abs(deltaF) / max(deriv_floor, EPS)
            actual_over_bound = root_step_abs / max(sampled_bound, EPS)

            # Exact finite-part shell identity: AC and smooth_count cancel in L.
            prime_delta = float(
                p2.prime_phase(np.asarray([a]))[0]
                - p1.prime_phase(np.asarray([a]))[0]
            )
            counter_delta = float(
                p2.counter.phase(np.asarray([a]))[0]
                - p1.counter.phase(np.asarray([a]))[0]
            )
            deltaF_from_centered = -(prime_delta - counter_delta) / math.pi
            fp_identity_rel = relerr(deltaF, deltaF_from_centered)

            ab = abel_shell_geometry(base, p1, p2, psi, a)

            secant_identity_abs = abs(root_step - secant_step) if math.isfinite(secant_step) else float("inf")
            secant_identity_rel = (
                secant_identity_abs / max(root_step_abs, 1e-15)
                if math.isfinite(secant_identity_abs)
                else float("inf")
            )
            secant_equation_abs = abs(root_step * secant_D + deltaF)

            row = {
                "L_low": int(L1),
                "L_high": int(L2),
                "L_geomean": math.sqrt(float(L1) * float(L2)),
                "k": int(k),
                "E_low": a,
                "E_high": b,
                "target": target,
                "root_step": root_step,
                "root_step_abs": root_step_abs,
                "F1_at_root": F1a,
                "F2_at_old_root": F2a,
                "F2_at_new_root": F2b,
                "deltaF_at_old_root": deltaF,
                "deltaF_from_centered_shell": deltaF_from_centered,
                "finite_part_shell_identity_rel": fp_identity_rel,
                "secant_Dstar": secant_D,
                "secant_predicted_step": secant_step,
                "secant_identity_abs": secant_identity_abs,
                "secant_identity_rel": secant_identity_rel,
                "secant_equation_abs": secant_equation_abs,
                "sampled_derivative_floor": deriv_floor,
                "sampled_derivative_sign_consistent": deriv_sign_consistent,
                "sampled_response_majorant": sampled_bound,
                "actual_over_sampled_response": actual_over_bound,
                **ab,
            }
            point_rows.append(row)

            print(
                "    k=%-4d E=%.6f->%.6f |dE|=%.3e R=%.3e act/R=%.4f "
                "cos=%.3e centered=%.3e AbelRel=%.2e"
                % (
                    k,
                    a,
                    b,
                    root_step_abs,
                    sampled_bound,
                    actual_over_bound,
                    ab["pnt_error_cosine_abs"],
                    ab["centered_direct"],
                    ab["centered_abel_rel_residual"],
                ),
                flush=True,
            )

    # -----------------------------------------------------------------------
    # 3. Fixed-k late decay fits.
    # -----------------------------------------------------------------------
    print("[3] Fixed-k dyadic decay fits", flush=True)
    k_rows: List[dict] = []
    for k in ks:
        rows = sorted(
            [r for r in point_rows if int(r["k"]) == int(k)],
            key=lambda r: int(r["L_low"]),
        )
        Llow = np.asarray([r["L_low"] for r in rows], float)
        response = np.asarray([r["sampled_response_majorant"] for r in rows], float)
        actual = np.asarray([r["root_step_abs"] for r in rows], float)
        forcing = np.asarray([abs(r["deltaF_at_old_root"]) for r in rows], float)
        cosine = np.asarray([r["pnt_error_cosine_abs"] for r in rows], float)

        envelope = suffix_max_envelope(response)
        fr = fit_decay(Llow, response, int(args.fit_last))
        fe = fit_decay(Llow, envelope, int(args.fit_last))
        fa = fit_decay(Llow, actual, int(args.fit_last))
        ff = fit_decay(Llow, forcing, int(args.fit_last))

        monotone = late_monotone_decreasing(response, int(args.late_monotone_steps))
        ratios = response[1:] / np.maximum(response[:-1], EPS)
        late_n = min(len(ratios), int(args.late_monotone_steps))
        late_max_ratio = float(np.max(ratios[-late_n:])) if late_n else float("nan")

        kr = {
            "k": int(k),
            "transitions": int(len(rows)),
            "response_first": float(response[0]),
            "response_last": float(response[-1]),
            "response_last_over_first": float(response[-1] / max(response[0], EPS)),
            "late_response_monotone_decreasing": monotone,
            "late_max_dyadic_response_ratio": late_max_ratio,
            "response_alpha_power_L": fr["alpha_power_L"],
            "response_q_log_power": fr["q_log_power"],
            "response_r2_power_L": fr["r2_power_L"],
            "response_r2_log_power": fr["r2_log_power"],
            "response_envelope_first": float(envelope[0]),
            "response_envelope_last": float(envelope[-1]),
            "response_envelope_last_over_first": float(envelope[-1] / max(envelope[0], EPS)),
            "envelope_alpha_power_L": fe["alpha_power_L"],
            "envelope_q_log_power": fe["q_log_power"],
            "envelope_r2_power_L": fe["r2_power_L"],
            "envelope_r2_log_power": fe["r2_log_power"],
            "actual_alpha_power_L": fa["alpha_power_L"],
            "actual_q_log_power": fa["q_log_power"],
            "forcing_alpha_power_L": ff["alpha_power_L"],
            "forcing_q_log_power": ff["q_log_power"],
            "max_actual_over_sampled_response": float(
                max(r["actual_over_sampled_response"] for r in rows)
            ),
            "min_sampled_derivative_floor": float(
                min(r["sampled_derivative_floor"] for r in rows)
            ),
            "all_sampled_derivative_sign_consistent": bool(
                all(r["sampled_derivative_sign_consistent"] for r in rows)
            ),
            "max_secant_identity_rel": float(max(r["secant_identity_rel"] for r in rows)),
            "max_finite_part_shell_identity_rel": float(
                max(r["finite_part_shell_identity_rel"] for r in rows)
            ),
            "max_prime_abel_rel_residual": float(
                max(r["prime_abel_rel_residual"] for r in rows)
            ),
            "max_centered_abel_rel_residual": float(
                max(r["centered_abel_rel_residual"] for r in rows)
            ),
            "median_abs_pnt_error_cosine": float(np.nanmedian(cosine)),
            "last_abs_pnt_error_cosine": float(cosine[-1]),
            "last_pnt_error_cs_over_actual": float(rows[-1]["pnt_error_cs_over_actual"]),
            "last_error_cross_band_signed_ratio": float(
                rows[-1]["error_cross_band_signed_ratio"]
            ),
        }
        kr["q_gate_pass"] = bool(
            math.isfinite(kr["envelope_q_log_power"])
            and kr["envelope_q_log_power"] >= float(args.q_gate)
        )
        kr["alpha_gate_pass"] = bool(
            math.isfinite(kr["envelope_alpha_power_L"])
            and kr["envelope_alpha_power_L"] > float(args.alpha_gate)
        )
        kr["envelope_contracts"] = bool(
            kr["response_envelope_last_over_first"] < 1.0
        )
        k_rows.append(kr)

        print(
            "  k=%-4d Rlast=%.3e ratio=%.3f qlog=%+.3f alpha=%+.3f "
            "mono=%s median|cos|=%.3e"
            % (
                k,
                kr["response_last"],
                kr["response_last_over_first"],
                kr["envelope_q_log_power"],
                kr["envelope_alpha_power_L"],
                str(monotone),
                kr["median_abs_pnt_error_cosine"],
            )
        )

    # -----------------------------------------------------------------------
    # 4. L-transition summaries.
    # -----------------------------------------------------------------------
    print("[4] Cross-k transition summaries", flush=True)
    L_rows: List[dict] = []
    for L1, L2 in zip(Ls[:-1], Ls[1:]):
        rows = [r for r in point_rows if r["L_low"] == L1]
        rr = np.asarray([r["sampled_response_majorant"] for r in rows], float)
        aa = np.asarray([r["root_step_abs"] for r in rows], float)
        cc = np.asarray([r["pnt_error_cosine_abs"] for r in rows], float)
        er = np.asarray([r["error_cross_band_signed_ratio"] for r in rows], float)
        lr = {
            "L_low": int(L1),
            "L_high": int(L2),
            "k_count": int(len(rows)),
            "response_max": float(np.max(rr)),
            "response_median": float(np.median(rr)),
            "actual_step_max": float(np.max(aa)),
            "actual_step_median": float(np.median(aa)),
            "median_abs_pnt_error_cosine": float(np.nanmedian(cc)),
            "max_abs_pnt_error_cosine": float(np.nanmax(cc)),
            "median_error_cross_band_signed_ratio": float(np.nanmedian(er)),
            "max_actual_over_sampled_response": float(
                max(r["actual_over_sampled_response"] for r in rows)
            ),
        }
        L_rows.append(lr)
        print(
            "  %d->%d: Rmax=%.3e Rmed=%.3e dEmax=%.3e med|cos|=%.3e"
            % (
                L1, L2, lr["response_max"], lr["response_median"],
                lr["actual_step_max"], lr["median_abs_pnt_error_cosine"]
            )
        )

    # -----------------------------------------------------------------------
    # 5. Conservative verdict.
    # -----------------------------------------------------------------------
    max_secant_rel = max(r["secant_identity_rel"] for r in point_rows)
    max_secant_eq_abs = max(r["secant_equation_abs"] for r in point_rows)
    max_fp_rel = max(r["finite_part_shell_identity_rel"] for r in point_rows)
    max_prime_abel_rel = max(r["prime_abel_rel_residual"] for r in point_rows)
    max_centered_abel_rel = max(r["centered_abel_rel_residual"] for r in point_rows)
    min_deriv_floor = min(r["sampled_derivative_floor"] for r in point_rows)
    all_deriv_sign = all(r["sampled_derivative_sign_consistent"] for r in point_rows)
    max_actual_over_bound = max(r["actual_over_sampled_response"] for r in point_rows)
    min_q = min(r["envelope_q_log_power"] for r in k_rows)
    min_alpha = min(r["envelope_alpha_power_L"] for r in k_rows)
    all_monotone = all(r["late_response_monotone_decreasing"] for r in k_rows)
    all_q = all(r["q_gate_pass"] for r in k_rows)
    all_alpha = all(r["alpha_gate_pass"] for r in k_rows)
    all_envelope_contracts = all(r["envelope_contracts"] for r in k_rows)

    numerical_gates = {
        "root_residual": max_root_resid <= float(args.root_residual_tol),
        "counterterm_quadrature_phase": max_qphase <= float(args.quadrature_tol),
        "counterterm_quadrature_derivative": max_qder <= float(args.quadrature_tol),
        "secant_root_equation_absolute": max_secant_eq_abs <= float(args.secant_abs_tol),
        "finite_part_shell_identity": max_fp_rel <= float(args.identity_rel_tol),
        "prime_abel_identity": max_prime_abel_rel <= float(args.identity_rel_tol),
        "centered_abel_identity": max_centered_abel_rel <= float(args.identity_rel_tol),
        "sampled_derivative_floor_positive": min_deriv_floor > 0.0,
        "sampled_derivative_sign_consistent": all_deriv_sign,
        "actual_root_step_below_sampled_response": (
            max_actual_over_bound <= float(args.mvt_ratio_tol)
        ),
    }
    scientific_gates = {
        "all_fixed_k_observed_envelope_contracts": all_envelope_contracts,
        "all_fixed_k_envelope_log_power_q_above_gate": all_q,
        "all_fixed_k_envelope_power_L_alpha_above_gate": all_alpha,
    }

    if not all(numerical_gates.values()):
        verdict = "FAIL_V130_NUMERICAL_IDENTITY_OR_SUPPORT_INVALID"
        mechanism = "NUMERICAL_OR_EXACT_IDENTITY_GATE_FAILED__DO_NOT_INTERPRET_DECAY"
    elif all(scientific_gates.values()):
        verdict = "PASS_V130_ROOT_LOCATED_DYADIC_SUMMABILITY_CANDIDATE"
        mechanism = (
            "ROOT_LOCATED_FINITE_PART_SHELL_RESPONSE_SHOWS_UNIFORM_SAMPLED_SUMMABLE_DECAY__"
            "ANALYTIC_BILINEAR_SHELL_BOUND_IS_NEXT_THEOREM_TARGET"
        )
    else:
        verdict = "NO_GO_V130_UNIFORM_SUMMABLE_DYADIC_DECAY_NOT_ESTABLISHED_NUMERICALLY"
        if not all_envelope_contracts:
            mechanism = "OBSERVED_ROOT_RESPONSE_ENVELOPE_DOES_NOT_CONTRACT_FOR_ALL_FIXED_K"
        elif not all_q:
            mechanism = "ENVELOPE_LOG_POWER_SUMMABILITY_EXPONENT_Q_NOT_ABOVE_GATE_FOR_ALL_FIXED_K"
        else:
            mechanism = "ENVELOPE_POWER_L_DECAY_CORROBORATION_FAILED_FOR_AT_LEAST_ONE_FIXED_K"

    point_path = Path(str(prefix) + "_POINTS.csv")
    k_path = Path(str(prefix) + "_K_SUMMARY.csv")
    L_path = Path(str(prefix) + "_L_SUMMARY.csv")
    verdict_path = Path(str(prefix) + "_VERDICT.json")
    write_csv(point_path, point_rows)
    write_csv(k_path, k_rows)
    write_csv(L_path, L_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "code_path": str(code_path) if code_path else None,
        "code_sha256": code_sha,
        "verdict": verdict,
        "mechanism": mechanism,
        "RH_proof": False,
        "L_to_infinity_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "parameters": {
            "L_list": Ls,
            "k_values": ks,
            "tail_factor": args.tail_factor,
            "counter_q": args.counter_q,
            "counter_qcheck": args.counter_qcheck,
            "scan_points": args.scan_points,
            "derivative_samples": args.derivative_samples,
            "fit_last": args.fit_last,
            "late_monotone_steps": args.late_monotone_steps,
            "q_gate": args.q_gate,
            "alpha_gate": args.alpha_gate,
            "secant_abs_tol": args.secant_abs_tol,
        },
        "numerical_gates": numerical_gates,
        "scientific_gates": scientific_gates,
        "global_metrics": {
            "max_root_residual": max_root_resid,
            "max_counterterm_qphase": max_qphase,
            "max_counterterm_qder": max_qder,
            "max_secant_identity_rel_diagnostic": max_secant_rel,
            "max_secant_equation_abs": max_secant_eq_abs,
            "max_finite_part_shell_identity_rel": max_fp_rel,
            "max_prime_abel_rel_residual": max_prime_abel_rel,
            "max_centered_abel_rel_residual": max_centered_abel_rel,
            "minimum_sampled_derivative_floor": min_deriv_floor,
            "maximum_actual_over_sampled_response": max_actual_over_bound,
            "minimum_fixed_k_response_q_log_power": min_q,
            "minimum_fixed_k_response_alpha_power_L": min_alpha,
            "all_fixed_k_late_response_monotone_diagnostic": all_monotone,
            "all_fixed_k_observed_envelope_contracts": all_envelope_contracts,
        },
        "k_summary": k_rows,
        "L_summary": L_rows,
        "theorem_target": (
            "For every fixed k, prove that for all sufficiently large dyadic L, "
            "|F_{2L}^FP(E_k(L))-F_L^FP(E_k(L))| / "
            "inf_{I_{k,L}} |(F_{2L}^FP)'| <= C_k/(log L)^(1+epsilon_k). "
            "Then E_k(L) is dyadic-Cauchy.  Combine fixed-k convergence with a "
            "uniform Weyl lower bound E_k(L) >= c k/log(k+1) to obtain trace-norm "
            "convergence of K_L=H_L^-2 by dominated convergence."
        ),
        "interpretation": (
            "v130 is a theorem-precursor audit.  A PASS says the sampled zero-free "
            "finite-part root response is consistent with a summable dyadic law on "
            "every selected fixed k and that the exact PNT/Abel decomposition is "
            "numerically valid.  It does NOT prove a future-valid derivative infimum, "
            "the bilinear PNT-error estimate, regulator independence, trace-norm "
            "convergence, the Fredholm-Xi identity, or RH."
        ),
        "outputs": {
            "points": str(point_path),
            "k_summary": str(k_path),
            "L_summary": str(L_path),
            "verdict": str(verdict_path),
        },
    }
    verdict_path.write_text(json.dumps(json_safe(packet), indent=2), encoding="utf-8")

    print("\n" + "=" * 170)
    print("FINAL v130 VERDICT")
    print("=" * 170)
    print("verdict                         :", verdict)
    print("mechanism                       :", mechanism)
    print("max root residual               :", f"{max_root_resid:.12e}")
    print("max counter qphase/qder         :", f"{max_qphase:.12e} / {max_qder:.12e}")
    print("max secant identity rel (diag)  :", f"{max_secant_rel:.12e}")
    print("max secant equation abs         :", f"{max_secant_eq_abs:.12e}")
    print("max finite-part identity rel    :", f"{max_fp_rel:.12e}")
    print("max prime Abel identity rel     :", f"{max_prime_abel_rel:.12e}")
    print("max centered Abel identity rel  :", f"{max_centered_abel_rel:.12e}")
    print("minimum derivative floor        :", f"{min_deriv_floor:.12e}")
    print("max actual / sampled response   :", f"{max_actual_over_bound:.12e}")
    print("minimum fitted q(log L)         :", f"{min_q:+.6f}")
    print("minimum fitted alpha(L)         :", f"{min_alpha:+.6f}")
    print("all fixed-k late monotone (diag):", all_monotone)
    print("all fixed-k envelopes contract  :", all_envelope_contracts)
    print("RH proof                        : FALSE")
    print("L->infinity proof               : FALSE")
    print("verdict file                    :", verdict_path)
    print("=" * 170)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
