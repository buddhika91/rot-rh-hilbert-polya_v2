#!/usr/bin/env python3
"""
ROT-RH v185 — MOVING-ROOT AMPLITUDE-SLOPE / SWITCH-BROADENING AUDIT

Purpose
-------
v184 established that switch 159 is broad but localized:
~99.6% of its dimensionless mixing mass lies inside |x|<=128, where

    x = Delta a * (tau-tau_s).

The naive width 1/Delta a fails because it assumes the two layer amplitudes
cross with derivative Delta a while holding E fixed.

Along the moving root E(tau), define the positive-gamma layer amplitude ratio

    L(tau)
      = Delta a * tau
        + log|Gamma(a2+i(E-gamma2))|
        - log|Gamma(a1+i(E-gamma1))|.

Then exactly

    dL/dtau
      = Delta a
        + E'(tau) *
          [ -Im psi(w2) + Im psi(w1) ].

Since Y=tau E and
    Y' = gamma_active + epsilon,
we have
    E' = (gamma_active + epsilon - E)/tau.

Define the moving-root broadening factor

    B = |Delta a| / |dL/dtau|.

If B >> 1, root motion nearly cancels the bare amplitude-crossing slope and
produces a broad switch in x.

v185 tests whether the observed intrinsic mixing widths track B.

Inputs
------
--points-csv : v183 root-reprojected POINTS.csv

No continuation is performed.

Outputs
-------
<prefix>_POINTS.csv
<prefix>_SWITCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return 0.0
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def loglog_fit(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]
    if len(x) < 3:
        return {"n": len(x), "slope": np.nan, "r2": np.nan}
    X = np.log(x)
    Y = np.log(y)
    p = np.polyfit(X, Y, 1)
    pred = p[0]*X+p[1]
    ssr = float(np.sum((Y-pred)**2))
    sst = float(np.sum((Y-np.mean(Y))**2))
    return {
        "n": len(x),
        "slope": float(p[0]),
        "r2": float(1-ssr/sst) if sst > 0 else np.nan,
    }


def cumulative_symmetric_profile(x, m, grid_n=4097):
    """
    Interpolate m(x) on a dense x grid and return X, K(X)
    where K(X)=int_{|x|<=X} m dx.
    """
    x = np.asarray(x, float)
    m = np.asarray(m, float)
    o = np.argsort(x)
    x = x[o]
    m = m[o]

    xmax = min(abs(float(x[0])), abs(float(x[-1])))
    if xmax <= 0:
        return np.array([0.0]), np.array([0.0])

    X = np.linspace(0.0, xmax, grid_n)
    vals = np.zeros_like(X)

    # Evaluate symmetric contribution m(+X)+m(-X).
    mpv = np.interp(X, x, m)
    mmv = np.interp(-X, x, m)
    f = mpv+mmv

    # cumulative trapezoid manually
    dx = np.diff(X)
    vals[1:] = np.cumsum(0.5*(f[1:]+f[:-1])*dx)

    return X, vals


def quantile_width(X, K, q):
    if len(K) == 0 or K[-1] <= 0:
        return np.nan
    target = q*K[-1]
    return float(np.interp(target, K, X))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--points-csv",
        default="rot_rh_global_cesaro_mix_scale_v183_POINTS.csv",
    )
    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument(
        "--saturation-boundary-gate",
        type=float,
        default=0.01,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_moving_root_broadening_v185",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps

    pts = pd.read_csv(args.points_csv)

    required = {
        "switch", "tau", "E", "tau_switch",
        "beta_left", "beta_right",
        "gamma_left", "gamma_right",
        "gamma_active", "epsilon",
        "epsilon_mix",
    }
    missing = required-set(pts.columns)
    if missing:
        raise RuntimeError(f"Missing columns: {sorted(missing)}")

    print("="*174)
    print("ROT-RH v185 — MOVING-ROOT AMPLITUDE-SLOPE / SWITCH-BROADENING AUDIT")
    print("="*174)
    print(f"points csv                        : {args.points_csv}")
    print(f"switches                          : {sorted(pts['switch'].astype(int).unique().tolist())}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*174)

    point_rows = []
    switch_rows = []

    for sw, g0 in pts.groupby("switch"):
        g = g0.copy().sort_values("tau").reset_index(drop=True)

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        g1 = float(g.iloc[0]["gamma_left"])
        g2 = float(g.iloc[0]["gamma_right"])
        ts = float(g.iloc[0]["tau_switch"])

        a1 = b1-0.5
        a2 = b2-0.5
        da_signed = a2-a1
        da = abs(da_signed)
        dg = abs(g2-g1)

        rows = []

        for _, r in g.iterrows():
            tau = float(r["tau"])
            E = float(r["E"])
            ga = float(r["gamma_active"])
            eps = float(r["epsilon"])

            # E' from Y'=gamma_active+epsilon and Y=tau E.
            Eprime = (ga+eps-E)/tau

            w1 = mp.mpc(
                mp.mpf(str(a1)),
                mp.mpf(str(E-g1))
            )
            w2 = mp.mpc(
                mp.mpf(str(a2)),
                mp.mpf(str(E-g2))
            )

            psi1 = mp.digamma(w1)
            psi2 = mp.digamma(w2)

            gamma_feedback = (
                -float(mp.im(psi2))
                + float(mp.im(psi1))
            )

            Lprime = da_signed + Eprime*gamma_feedback

            bare = da_signed
            feedback = Eprime*gamma_feedback

            B = (
                da/abs(Lprime)
                if Lprime != 0 else np.inf
            )

            # Direct log amplitude ratio, useful as an independent finite-difference check.
            L = (
                da_signed*tau
                + float(mp.re(mp.loggamma(w2)))
                - float(mp.re(mp.loggamma(w1)))
            )

            x = da_signed*(tau-ts)
            m = abs(float(r["epsilon_mix"]))/max(dg, 1e-300)

            rr = dict(r)
            rr.update({
                "a1": a1,
                "a2": a2,
                "delta_a_signed": da_signed,
                "delta_a": da,
                "delta_gamma": dg,
                "x_signed": x,
                "m_abs": m,
                "Eprime": Eprime,
                "gamma_feedback_factor": gamma_feedback,
                "Lprime_exact": Lprime,
                "Lprime_bare": bare,
                "Lprime_feedback": feedback,
                "broadening_B": B,
                "log_amp_ratio_L": L,
            })
            rows.append(rr)
            point_rows.append(rr)

        qdf = pd.DataFrame(rows).sort_values("tau")

        # finite-difference derivative of L, independent check
        tauv = qdf["tau"].to_numpy(float)
        Lv = qdf["log_amp_ratio_L"].to_numpy(float)
        if len(qdf) >= 3:
            Lfd = np.gradient(Lv, tauv)
        else:
            Lfd = np.full(len(qdf), np.nan)
        qdf["Lprime_fd"] = Lfd

        # locate nearest point to the nominal switch
        k = int(np.argmin(np.abs(tauv-ts)))
        center = qdf.iloc[k]

        # use a small local neighborhood around the switch for robust slope summaries
        lo = max(0, k-2)
        hi = min(len(qdf), k+3)
        loc = qdf.iloc[lo:hi]

        B_center = float(center["broadening_B"])
        B_med = float(np.nanmedian(loc["broadening_B"].to_numpy(float)))
        Lp_center = float(center["Lprime_exact"])
        Lp_fd_center = float(center["Lprime_fd"]) if np.isfinite(center["Lprime_fd"]) else np.nan

        # intrinsic mixing profile widths
        xabs_signed = qdf["x_signed"].to_numpy(float)
        m = qdf["m_abs"].to_numpy(float)

        X, K = cumulative_symmetric_profile(xabs_signed, m)
        Ksym = float(K[-1])

        X50 = quantile_width(X, K, 0.50)
        X75 = quantile_width(X, K, 0.75)
        X90 = quantile_width(X, K, 0.90)
        X99 = quantile_width(X, K, 0.99)

        # boundary amplitude as a saturation diagnostic
        mbound = max(float(m[0]), float(m[-1]))
        saturated = bool(mbound <= args.saturation_boundary_gate)

        switch_rows.append({
            "switch": int(sw),
            "tau_switch": ts,
            "delta_a": da,
            "delta_gamma": dg,
            "Lprime_center": Lp_center,
            "Lprime_fd_center": Lp_fd_center,
            "broadening_B_center": B_center,
            "broadening_B_local_median": B_med,
            "K_symmetric_available": Ksym,
            "X50": X50,
            "X75": X75,
            "X90": X90,
            "X99": X99,
            "boundary_m": mbound,
            "profile_saturated": saturated,
            "X50_over_B": (
                X50/B_med if B_med > 0 and np.isfinite(B_med) else np.nan
            ),
            "X90_over_B": (
                X90/B_med if B_med > 0 and np.isfinite(B_med) else np.nan
            ),
            "feedback_over_bare_center": (
                float(center["Lprime_feedback"])/da_signed
                if da_signed != 0 else np.nan
            ),
        })

        print(
            f"[switch {int(sw):4d}] "
            f"B={B_med:.3e} "
            f"X50={X50:.3e} X90={X90:.3e} "
            f"X50/B={X50/B_med if B_med>0 else np.nan:.3e} "
            f"feedback/bare={switch_rows[-1]['feedback_over_bare_center']:.3e} "
            f"saturated={saturated}"
        )

    outpts = pd.DataFrame(point_rows)
    swdf = pd.DataFrame(switch_rows).sort_values("tau_switch")

    # Fit widths against B only on saturated profiles.
    sat = swdf[
        swdf["profile_saturated"]
        & np.isfinite(swdf["broadening_B_local_median"])
        & np.isfinite(swdf["X50"])
        & (swdf["broadening_B_local_median"] > 0)
        & (swdf["X50"] > 0)
    ].copy()

    fit50 = loglog_fit(
        sat["broadening_B_local_median"],
        sat["X50"],
    )
    fit90 = loglog_fit(
        sat["broadening_B_local_median"],
        sat["X90"],
    )

    # Late-switch headline.
    late = swdf.iloc[-1]

    # If root-motion feedback cancels most of bare slope, B should be large.
    cancellation_fraction = abs(
        float(late["feedback_over_bare_center"])+1.0
    )

    broadening_detected = bool(
        float(late["broadening_B_local_median"]) >= 5.0
    )

    if broadening_detected:
        verdict = "MOVING_ROOT_BROADENING_DETECTED"
    else:
        verdict = "MOVING_ROOT_BROADENING_NOT_DETECTED"

    outpts.to_csv(args.prefix+"_POINTS.csv", index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv", index=False)

    summary = {
        "version": 185,
        "late_switch": int(late["switch"]),
        "late_broadening_B": float(late["broadening_B_local_median"]),
        "late_X50": float(late["X50"]),
        "late_X90": float(late["X90"]),
        "late_X50_over_B": float(late["X50_over_B"]),
        "late_X90_over_B": float(late["X90_over_B"]),
        "late_feedback_over_bare": float(late["feedback_over_bare_center"]),
        "fit_X50_vs_B": fit50,
        "fit_X90_vs_B": fit90,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*174)
    print(f"saturated profiles in width fit   : {len(sat)}")
    print(
        f"fit X50 ~ B^p                    : "
        f"p={fit50['slope']:.6f} R2={fit50['r2']:.6f}"
    )
    print(
        f"fit X90 ~ B^p                    : "
        f"p={fit90['slope']:.6f} R2={fit90['r2']:.6f}"
    )
    print(f"late switch                       : {int(late['switch'])}")
    print(f"late B                            : {float(late['broadening_B_local_median']):.6e}")
    print(f"late X50                          : {float(late['X50']):.6e}")
    print(f"late X90                          : {float(late['X90']):.6e}")
    print(f"late X50/B                        : {float(late['X50_over_B']):.6e}")
    print(f"late X90/B                        : {float(late['X90_over_B']):.6e}")
    print(f"late feedback / bare slope        : {float(late['feedback_over_bare_center']):.6e}")
    print(f"VERDICT                           : {verdict}")
    print("="*174)


if __name__ == "__main__":
    main()
