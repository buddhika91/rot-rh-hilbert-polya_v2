#!/usr/bin/env python3
"""
ROT-RH v158 — COMPLEX SIGNED PRIMITIVE / PHASE-ROTATION AUDIT

Purpose
-------
v157 showed a stable dimensionless y=x/M shell profile and a shrinking
SIGNED sine primitive at the old roots.

But the secular phase sees only the imaginary projection

    Im Z_{L,M}(E),

where the natural centered complex cutoff-difference primitive is

    Z_{L,M}(E)
      = [Delta M_c(E) - Delta P_c(E)] / pi,

with

    Delta P_c(E)
      = sum_{n=p^a}
          (1/a) n^(-1/2)
          [e^{-n/M}-e^{-n/L}] e^{i E log n},

    Delta M_c(E)
      = int_2^infty
          [e^{-x/M}-e^{-x/L}]
          x^(-1/2+iE)/log x dx.

Then

    Im Z_{L,M}(E_k(L))
      = F_M(E_k(L)) - (k-1/2),

up to the already-certified truncation/numerical error.

Why test the full complex primitive?
------------------------------------
A shrinking imaginary projection is weaker than a shrinking complex
amplitude. If |Z| remains large while Im Z happens to be small, changing
log M can rotate the phase and revive the secular defect.

v158 therefore tests:
  1. reconstruction of the v150 secular defect from Im Z;
  2. l1 contraction of sum_k |Z_k|;
  3. whether contraction is present in both Re and Im components;
  4. phase-projection reserve
         sum|Z_k| / sum|Im Z_k|;
  5. modewise magnitude contraction fractions;
  6. complex y=x/M shell profile stability;
  7. cumulative complex high-y tails.

A contracting full complex primitive would be substantially stronger
evidence than sine-only contraction.

NO Xi / zeta / known-zero data are used.
No phase builds and no root solves are performed.

Outputs
-------
<prefix>_MODES.csv
<prefix>_PAIR_SUMMARY.csv
<prefix>_SHELL_SUMMARY.csv
<prefix>_TAILS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss


def parse_pairs(s):
    out = []
    for item in s.split(","):
        item = item.strip()
        if not item:
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def parse_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def continuum_complex(E, L, M, xlo, xhi, nodes, weights):
    if not (xhi > xlo >= 2.0):
        return 0.0 + 0.0j

    ulo = math.log(xlo)
    uhi = math.log(xhi)

    mid = 0.5 * (ulo + uhi)
    half = 0.5 * (uhi - ulo)

    u = mid + half * nodes
    x = np.exp(u)

    reg = np.exp(-x/M) - np.exp(-x/L)
    density = reg * np.exp(0.5*u) / u

    phase = np.exp(1j * E * u)

    return half * np.dot(weights, density * phase)


def corr(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if len(a) < 2:
        return np.nan
    if np.allclose(a, a[0]) or np.allclose(b, b[0]):
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v150-roots-csv",
        default="rot_rh_cutoff_difference_kernel_v150_ROOTS.csv",
    )
    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--y-shell-edges",
        default="0,0.03125,0.0625,0.125,0.25,0.5,1,2,4,8,12,18",
    )
    ap.add_argument(
        "--continuum-gl-order",
        type=int,
        default=256,
    )
    ap.add_argument(
        "--identity-rms-gate",
        type=float,
        default=2e-7,
    )
    ap.add_argument(
        "--complex-contraction-gate",
        type=float,
        default=1.0,
    )
    ap.add_argument(
        "--mode-contraction-fraction-gate",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--outer-y-threshold",
        type=float,
        default=8.0,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_complex_signed_primitive_v158",
    )

    args = ap.parse_args()

    pairs = parse_pairs(args.pairs)
    yedges = parse_floats(args.y_shell_edges)

    if not yedges or yedges[0] != 0.0:
        raise RuntimeError("y-shell edges must start at 0.")
    if yedges[-1] < args.tail_factor:
        raise RuntimeError("Last y edge must cover tail-factor.")

    roots_df = pd.read_csv(args.v150_roots_csv)
    roots_df = roots_df[roots_df["k"] <= args.modes].copy()

    max_M = max(M for _, M in pairs)
    xmax = int(math.ceil(args.tail_factor * max_M))

    print("=" * 146)
    print("ROT-RH v158 — COMPLEX SIGNED PRIMITIVE / PHASE-ROTATION AUDIT")
    print("=" * 146)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"modes                             : 1..{args.modes}")
    print(f"prime-power xmax                  : {xmax:,}")
    print(f"y=x/M shell edges                 : {yedges}")
    print(f"continuum GL order                : {args.continuum_gl_order}")
    print("=" * 146)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    atom_u = np.log(atom_x)
    atom_base = atom_afac / np.sqrt(atom_x)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    nodes, weights = leggauss(args.continuum_gl_order)

    mode_rows = []
    pair_rows = []
    shell_rows = []
    tail_rows = []

    normalized_shell_profiles = []
    mode_magnitudes_by_pair = []

    nshell = len(yedges) - 1

    for pair_index, (L, M) in enumerate(pairs):
        print()
        print(f"[pair {L}->{M}] complex shell decomposition ...", flush=True)

        pr = roots_df[
            (roots_df["L"] == L) &
            (roots_df["M"] == M)
        ].sort_values("k").iloc[:args.modes]

        if len(pr) == 0:
            raise RuntimeError(f"No v150 root rows for {L}->{M}.")

        E = pr["E_old"].to_numpy(dtype=float)
        karr = pr["k"].to_numpy(dtype=int)
        actual = pr["actual_secular_defect"].to_numpy(dtype=float)

        reg = np.exp(-atom_x/M) - np.exp(-atom_x/L)
        aw = atom_base * reg

        C = np.zeros((len(E), nshell), dtype=np.complex128)

        for s in range(nshell):
            ylo, yhi = yedges[s], yedges[s+1]
            xlo = max(2.0, ylo*M)
            xhi = min(float(xmax), yhi*M)

            if xhi <= xlo:
                continue

            if s == nshell-1:
                mask = (atom_x >= xlo) & (atom_x <= xhi)
            else:
                mask = (atom_x >= xlo) & (atom_x < xhi)

            uu = atom_u[mask]
            ww = aw[mask]

            dP = np.zeros(len(E), dtype=np.complex128)

            if len(uu):
                chunk = 65536
                for i in range(0, len(uu), chunk):
                    uc = uu[i:i+chunk]
                    wc = ww[i:i+chunk]

                    # e^{i E u}
                    phase = np.exp(1j * np.outer(E, uc))
                    dP += phase @ wc

            dM = np.array([
                continuum_complex(
                    float(Ei), L, M, xlo, xhi, nodes, weights
                )
                for Ei in E
            ], dtype=np.complex128)

            C[:, s] = (dM - dP) / math.pi

        Z = np.sum(C, axis=1)

        imag_residual = actual - Z.imag
        rms = float(np.sqrt(np.mean(imag_residual**2)))
        max_res = float(np.max(np.abs(imag_residual)))

        mag = np.abs(Z)
        imag_abs = np.abs(Z.imag)
        real_abs = np.abs(Z.real)

        complex_l1 = float(np.sum(mag))
        imag_l1 = float(np.sum(imag_abs))
        real_l1 = float(np.sum(real_abs))

        projection_reserve = (
            complex_l1 / imag_l1 if imag_l1 > 0 else np.inf
        )

        # Complex shell total variation over modes.
        shell_l1 = np.sum(np.abs(C), axis=0)
        shell_profile = shell_l1 / max(float(np.sum(shell_l1)), 1e-300)
        normalized_shell_profiles.append(shell_profile)

        # cumulative complex high-y tails
        tails = np.zeros_like(C)
        running = np.zeros(len(E), dtype=np.complex128)
        for s in range(nshell-1, -1, -1):
            running += C[:, s]
            tails[:, s] = running

        outer_idx = next(
            (s for s in range(nshell) if yedges[s] >= args.outer_y_threshold),
            nshell
        )
        outer_complex_l1 = (
            float(np.sum(np.abs(tails[:, outer_idx])))
            if outer_idx < nshell else 0.0
        )

        for i, k in enumerate(karr):
            mode_rows.append(dict(
                L=L,
                M=M,
                k=int(k),
                E_old=float(E[i]),
                actual_secular_defect=float(actual[i]),
                Z_real=float(Z[i].real),
                Z_imag=float(Z[i].imag),
                Z_abs=float(abs(Z[i])),
                phase_angle=float(np.angle(Z[i])),
                imag_identity_residual=float(imag_residual[i]),
                projection_ratio=(
                    float(abs(Z[i]) / abs(Z[i].imag))
                    if abs(Z[i].imag) > 0 else np.inf
                ),
            ))

        for s in range(nshell):
            shell_rows.append(dict(
                L=L,
                M=M,
                shell=s+1,
                y_lo=yedges[s],
                y_hi=yedges[s+1],
                complex_shell_l1_over_modes=float(shell_l1[s]),
                complex_shell_profile_share=float(shell_profile[s]),
                signed_real_sum=float(np.sum(C[:, s].real)),
                signed_imag_sum=float(np.sum(C[:, s].imag)),
            ))

            tail_l1 = float(np.sum(np.abs(tails[:, s])))
            tail_rows.append(dict(
                L=L,
                M=M,
                from_shell=s+1,
                from_y=yedges[s],
                complex_tail_l1=tail_l1,
                tail_over_full_complex_l1=(
                    tail_l1 / complex_l1 if complex_l1 > 0 else np.nan
                ),
                tail_over_imag_l1=(
                    tail_l1 / imag_l1 if imag_l1 > 0 else np.nan
                ),
            ))

        pair_rows.append(dict(
            L=L,
            M=M,
            ratio_L=float(M/L),
            modes=len(E),
            complex_l1=complex_l1,
            real_l1=real_l1,
            imag_l1=imag_l1,
            actual_defect_l1=float(np.sum(np.abs(actual))),
            projection_reserve=projection_reserve,
            imag_identity_rms=rms,
            imag_identity_max=max_res,
            outer_y_threshold=args.outer_y_threshold,
            outer_complex_tail_l1=outer_complex_l1,
            outer_complex_tail_over_full=(
                outer_complex_l1 / complex_l1
                if complex_l1 > 0 else np.nan
            ),
        ))

        mode_magnitudes_by_pair.append(mag)

        print(
            f"[pair {L}->{M}] "
            f"|Z|_1={complex_l1:.6e}  "
            f"|Re Z|_1={real_l1:.6e}  "
            f"|Im Z|_1={imag_l1:.6e}  "
            f"reserve={projection_reserve:.2f}x  "
            f"id-rms={rms:.3e}  "
            f"outer/full={outer_complex_l1/max(complex_l1,1e-300):.3e}"
        )

    # Pair-to-pair ratios and mode contraction fractions.
    transition_rows = []

    for i, r in enumerate(pair_rows):
        if i == 0:
            r["complex_l1_ratio"] = np.nan
            r["real_l1_ratio"] = np.nan
            r["imag_l1_ratio"] = np.nan
            r["outer_complex_tail_ratio"] = np.nan
            continue

        prev = pair_rows[i-1]

        r["complex_l1_ratio"] = (
            r["complex_l1"] / max(prev["complex_l1"], 1e-300)
        )
        r["real_l1_ratio"] = (
            r["real_l1"] / max(prev["real_l1"], 1e-300)
        )
        r["imag_l1_ratio"] = (
            r["imag_l1"] / max(prev["imag_l1"], 1e-300)
        )
        r["outer_complex_tail_ratio"] = (
            r["outer_complex_tail_l1"] /
            max(prev["outer_complex_tail_l1"], 1e-300)
        )

        prev_mag = mode_magnitudes_by_pair[i-1]
        cur_mag = mode_magnitudes_by_pair[i]

        frac_contract = float(np.mean(cur_mag < prev_mag))

        prof_corr = corr(
            normalized_shell_profiles[i-1],
            normalized_shell_profiles[i]
        )
        prof_l1 = float(np.sum(np.abs(
            normalized_shell_profiles[i] -
            normalized_shell_profiles[i-1]
        )))

        transition_rows.append(dict(
            previous_pair=f"{pairs[i-1][0]}->{pairs[i-1][1]}",
            current_pair=f"{pairs[i][0]}->{pairs[i][1]}",
            complex_l1_ratio=r["complex_l1_ratio"],
            imag_l1_ratio=r["imag_l1_ratio"],
            real_l1_ratio=r["real_l1_ratio"],
            mode_magnitude_contraction_fraction=frac_contract,
            shell_profile_correlation=prof_corr,
            shell_profile_l1_distance=prof_l1,
        ))

    pd.DataFrame(mode_rows).to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    pd.DataFrame(pair_rows).to_csv(
        args.prefix + "_PAIR_SUMMARY.csv", index=False
    )
    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELL_SUMMARY.csv", index=False
    )
    pd.DataFrame(tail_rows).to_csv(
        args.prefix + "_TAILS.csv", index=False
    )

    identity_ok = all(
        r["imag_identity_rms"] <= args.identity_rms_gate
        for r in pair_rows
    )

    complex_contracts = all(
        pair_rows[i]["complex_l1_ratio"] < args.complex_contraction_gate
        for i in range(1, len(pair_rows))
    )

    imag_contracts = all(
        pair_rows[i]["imag_l1_ratio"] < 1.0
        for i in range(1, len(pair_rows))
    )

    enough_modes_contract = all(
        r["mode_magnitude_contraction_fraction"]
        >= args.mode_contraction_fraction_gate
        for r in transition_rows
    )

    profile_corrs = [
        r["shell_profile_correlation"]
        for r in transition_rows
        if np.isfinite(r["shell_profile_correlation"])
    ]
    mean_profile_corr = (
        float(np.mean(profile_corrs)) if profile_corrs else np.nan
    )

    if (
        identity_ok
        and complex_contracts
        and imag_contracts
        and enough_modes_contract
    ):
        verdict = "FULL_COMPLEX_PRIMITIVE_CONTRACTION_STRONGLY_SUPPORTED"
    elif identity_ok and imag_contracts and not complex_contracts:
        verdict = "SINE_PROJECTION_CONTRACTS_BUT_COMPLEX_AMPLITUDE_DOES_NOT"
    elif identity_ok:
        verdict = "COMPLEX_PRIMITIVE_CONVERGENCE_MIXED"
    else:
        verdict = "COMPLEX_PRIMITIVE_DECOMPOSITION_UNRESOLVED"

    summary = dict(
        version=158,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        complex_primitive=(
            "Z_LM(E)=[Delta M_c(E)-Delta P_c(E)]/pi, "
            "with Im Z equal to the secular cutoff defect."
        ),
        pair_results=pair_rows,
        transitions=transition_rows,
        identity_pass=identity_ok,
        complex_l1_contracts=complex_contracts,
        imag_l1_contracts=imag_contracts,
        mode_magnitude_contraction_pass=enough_modes_contract,
        mean_complex_shell_profile_correlation=mean_profile_corr,
        verdict=verdict,
        theorem_interpretation=(
            "If the full complex centered primitive contracts, cutoff "
            "convergence is not merely an accidental sine projection under "
            "phase rotation. The analytic target can then be strengthened to "
            "a complex weighted-PNT primitive bound on fixed spectral blocks."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    print()
    print("Complex primitive summaries")
    print("-" * 146)
    print(
        f"{'pair':>18} {'|Z|_1':>13} {'|Re|_1':>13} {'|Im|_1':>13} "
        f"{'reserve':>9} {'id RMS':>11} {'outer/full':>12} "
        f"{'|Z| ratio':>11} {'Im ratio':>10}"
    )

    for r in pair_rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{r['complex_l1']:13.6e} "
            f"{r['real_l1']:13.6e} "
            f"{r['imag_l1']:13.6e} "
            f"{r['projection_reserve']:9.3f} "
            f"{r['imag_identity_rms']:11.3e} "
            f"{r['outer_complex_tail_over_full']:12.6e} "
            f"{r['complex_l1_ratio']:11.6f} "
            f"{r['imag_l1_ratio']:10.6f}"
        )

    print()
    print("Transition diagnostics")
    print("-" * 146)
    print(
        f"{'transition':>39} {'|Z| ratio':>11} {'mode contract':>14} "
        f"{'profile corr':>13} {'profile L1':>12}"
    )

    for r in transition_rows:
        tr = f"{r['previous_pair']} -> {r['current_pair']}"
        print(
            f"{tr:>39} "
            f"{r['complex_l1_ratio']:11.6f} "
            f"{r['mode_magnitude_contraction_fraction']:14.3f} "
            f"{r['shell_profile_correlation']:13.6f} "
            f"{r['shell_profile_l1_distance']:12.6f}"
        )

    print()
    print("=" * 146)
    print(f"imaginary-part identity pass       : {identity_ok}")
    print(f"full complex l1 contracts          : {complex_contracts}")
    print(f"imaginary l1 contracts             : {imag_contracts}")
    print(f"modewise magnitude contraction pass: {enough_modes_contract}")
    print(f"mean complex shell-profile corr    : {mean_profile_corr:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 146)
    print("NEXT DECISION:")
    print("  FULL COMPLEX PASS -> formulate the cutoff lemma for the complex")
    print("  weighted-PNT primitive; phase rotation cannot revive a large hidden")
    print("  companion component.")
    print("  IMAG-ONLY PASS -> do not extrapolate the sine contraction; inspect")
    print("  complex phase rotation as a possible recurrence mechanism.")


if __name__ == "__main__":
    main()
