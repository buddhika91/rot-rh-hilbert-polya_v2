#!/usr/bin/env python3
"""
ROT-RH v152 — EVENT-EXACT ABEL IDENTITY / CRITICAL-SCALE AUDIT

Purpose
-------
Repair the numerical weakness exposed by v151 before making any analytic claim.

v151 used a sampled logarithmic grid for both

    Li_2(x) = ∫_2^x dt/log t

and the discontinuous prime-power remainder

    B(x) = J(x) - Li_2(x),

where

    J(x) = sum_{p^a <= x} 1/a.

That was adequate for a coarse absolute bound, but NOT adequate for validating
a signed discrepancy of size ~1e-7: the last v151 Abel residual was larger than
the direct discrepancy itself.

v152 improves this in three ways:

1. Li_2(x) is evaluated directly as

       Ei(log x) - Ei(log 2),

   instead of cumulative trapezoidal integration.

2. The Abel integral is evaluated on EVERY prime-power interval, where J(x)
   is exactly constant. Two-point Gauss-Legendre quadrature is used on each
   interval for B(x) g'(x). This resolves the jump structure rather than
   smearing it on an external grid.

3. The growth of B(x) is tested against BOTH:
       B_env(x) ~ C x^beta
   and the critical-log family
       B_env(x) ~ C sqrt(x) / (log x)^q.

The second comparison is essential.  A finite-range beta<1/2 can be mimicked
by a critical sqrt(x) scale divided by logarithms, so beta<1/2 on a finite
range must NOT automatically be interpreted as an asymptotic subcritical
power law.

For each cutoff pair L<M,

    g(x) = x^-1/2 [exp(-x/M)-exp(-x/L)]

and

    D(X) = sum_{p^a<=X} (1/a) g(p^a) - ∫_2^X g(x)/log x dx.

The event-resolved Abel identity is

    D(X) = g(X)B(X) - ∫_2^X B(x)g'(x) dx.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_PAIRS.csv
<prefix>_B_EVENTS.csv.gz
<prefix>_MODEL_FITS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.special import expi
except Exception as exc:
    raise RuntimeError("scipy.special.expi is required") from exc


SQRT3 = math.sqrt(3.0)


def parse_pairs(s):
    out = []
    for item in s.split(","):
        if not item.strip():
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def li2(x):
    x = np.asarray(x, dtype=np.float64)
    return expi(np.log(x)) - expi(math.log(2.0))


def gfun(x, L, M):
    x = np.asarray(x, dtype=np.float64)
    return x**(-0.5) * (np.exp(-x/M) - np.exp(-x/L))


def gprime(x, L, M):
    x = np.asarray(x, dtype=np.float64)
    a = np.exp(-x/M)
    b = np.exp(-x/L)
    return (
        -0.5 * x**(-1.5) * (a - b)
        + x**(-0.5) * (-a/M + b/L)
    )


def linear_fit(X, Y):
    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef
    resid = Y - pred
    ss_res = float(np.sum(resid**2))
    ss_tot = float(np.sum((Y - np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan
    rmse = math.sqrt(ss_res / len(Y))
    return coef, pred, r2, rmse


def fit_models(x, env, x_min, holdout_fraction):
    mask = (x >= x_min) & (env > 0) & np.isfinite(env)
    xx = x[mask]
    yy = env[mask]

    if len(xx) < 100:
        raise RuntimeError("Too few B-envelope points for model audit.")

    # Thin deterministically in log-index space so huge prime density at large x
    # does not completely dominate the regression.
    take = np.unique(
        np.linspace(0, len(xx)-1, min(20000, len(xx))).astype(int)
    )
    xx = xx[take]
    yy = yy[take]

    split = max(20, int((1.0 - holdout_fraction) * len(xx)))
    split = min(split, len(xx)-10)

    xtr, ytr = xx[:split], yy[:split]
    xte, yte = xx[split:], yy[split:]

    rows = []

    # --------------------------------------------------------------
    # Model 1: pure power C x^beta
    # --------------------------------------------------------------
    X = np.log(xtr)
    Y = np.log(ytr)
    coef, _, r2, rmse = linear_fit(X, Y)
    logC, beta = coef
    pred_test = np.exp(logC + beta*np.log(xte))
    test_log_rmse = float(
        np.sqrt(np.mean((np.log(yte)-np.log(pred_test))**2))
    )
    max_under = float(np.max(yte / pred_test))

    rows.append(dict(
        model="pure_power",
        parameter=float(beta),
        parameter_name="beta",
        logC=float(logC),
        train_r2=float(r2),
        train_log_rmse=float(rmse),
        holdout_log_rmse=test_log_rmse,
        holdout_max_actual_over_prediction=max_under,
        x_train_max=float(xtr[-1]),
        x_holdout_min=float(xte[0]),
        x_holdout_max=float(xte[-1]),
    ))

    # --------------------------------------------------------------
    # Model 2: critical log
    # env = C sqrt(x)/(log x)^q
    # log(env/sqrt x) = log C - q log log x
    # --------------------------------------------------------------
    X = np.log(np.log(xtr))
    Y = np.log(ytr / np.sqrt(xtr))
    coef, _, r2, rmse = linear_fit(X, Y)
    logC2, slope = coef
    q = -float(slope)

    pred_test2 = (
        np.exp(logC2)
        * np.sqrt(xte)
        / (np.log(xte)**q)
    )
    test_log_rmse2 = float(
        np.sqrt(np.mean((np.log(yte)-np.log(pred_test2))**2))
    )
    max_under2 = float(np.max(yte / pred_test2))

    rows.append(dict(
        model="critical_sqrt_log",
        parameter=float(q),
        parameter_name="q_in_sqrtx_over_log^q",
        logC=float(logC2),
        train_r2=float(r2),
        train_log_rmse=float(rmse),
        holdout_log_rmse=test_log_rmse2,
        holdout_max_actual_over_prediction=max_under2,
        x_train_max=float(xtr[-1]),
        x_holdout_min=float(xte[0]),
        x_holdout_max=float(xte[-1]),
    ))

    return rows


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--x-min-fit", type=float, default=1000.0)
    ap.add_argument("--holdout-fraction", type=float, default=0.25)
    ap.add_argument("--save-stride", type=int, default=128)

    ap.add_argument(
        "--relative-identity-gate",
        type=float,
        default=1e-3,
        help="Require |Ddirect-Dabel|/max(|Ddirect|,1e-30) below this.",
    )
    ap.add_argument(
        "--absolute-identity-gate",
        type=float,
        default=1e-10,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_event_exact_abel_v152",
    )

    args = ap.parse_args()

    if not (0.05 <= args.holdout_fraction <= 0.5):
        raise RuntimeError("--holdout-fraction should be between 0.05 and 0.5.")

    pairs = parse_pairs(args.pairs)
    xmax = int(math.ceil(args.tail_factor * max(M for _, M in pairs)))

    print("=" * 140)
    print("ROT-RH v152 — EVENT-EXACT ABEL IDENTITY / CRITICAL-SCALE AUDIT")
    print("=" * 140)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"xmax                              : {xmax:,}")
    print(f"x-min fit                         : {args.x_min_fit}")
    print(f"model holdout fraction            : {args.holdout_fraction}")
    print("=" * 140)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_w = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    J_after = np.cumsum(atom_w)
    J_before = J_after - atom_w

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    # ------------------------------------------------------------------
    # Event-exact B-envelope
    # ------------------------------------------------------------------
    Li_atom = li2(atom_x)
    B_after = J_after - Li_atom
    B_before = J_before - Li_atom

    event_abs = np.maximum(np.abs(B_after), np.abs(B_before))
    Benv = np.maximum.accumulate(event_abs)

    fit_rows = fit_models(
        atom_x,
        Benv,
        args.x_min_fit,
        args.holdout_fraction,
    )

    fit_df = pd.DataFrame(fit_rows)
    fit_df.to_csv(args.prefix + "_MODEL_FITS.csv", index=False)

    pure = next(r for r in fit_rows if r["model"] == "pure_power")
    crit = next(r for r in fit_rows if r["model"] == "critical_sqrt_log")

    # ------------------------------------------------------------------
    # Prime-power interval Gauss-Legendre nodes.
    # On [atom_i, atom_{i+1}), J(x)=J_after[i].
    # Add final interval to xmax when needed.
    # ------------------------------------------------------------------
    left = atom_x.copy()
    right = np.empty_like(left)
    right[:-1] = atom_x[1:]
    right[-1] = float(xmax)

    widths = right - left
    use = widths > 0.0

    left = left[use]
    right = right[use]
    widths = widths[use]
    J_level = J_after[use]

    mid = 0.5*(left + right)
    half = 0.5*widths

    node1 = mid - half/SQRT3
    node2 = mid + half/SQRT3

    # Li_2 is cutoff-independent: compute once.
    print("[quadrature] evaluating exact Li_2 at event nodes ...", flush=True)
    Li1 = li2(node1)
    Li2v = li2(node2)

    B1 = J_level - Li1
    B2 = J_level - Li2v

    pair_rows = []

    for L, M in pairs:
        print(f"[{L}->{M}] event-resolved Abel integral ...", flush=True)

        # Direct discrete term
        ga = gfun(atom_x, L, M)
        discrete = float(np.dot(atom_w, ga))

        # Smooth continuum term with event-partitioned 2-point GL.
        g1 = gfun(node1, L, M)
        g2 = gfun(node2, L, M)

        cont_integrand1 = g1 / np.log(node1)
        cont_integrand2 = g2 / np.log(node2)

        continuum = float(
            np.sum(half * (cont_integrand1 + cont_integrand2))
        )

        D_direct = discrete - continuum

        # Event-resolved Abel integral of B*g'
        gp1 = gprime(node1, L, M)
        gp2 = gprime(node2, L, M)

        signed_int = float(
            np.sum(half * (B1*gp1 + B2*gp2))
        )

        abs_int = float(
            np.sum(
                half * (
                    np.abs(B1*gp1)
                    + np.abs(B2*gp2)
                )
            )
        )

        gX = float(gfun(float(xmax), L, M))
        BX = float(J_after[-1] - li2(float(xmax)))

        boundary = gX * BX
        D_abel = boundary - signed_int
        abs_bound = abs(boundary) + abs_int

        residual = D_direct - D_abel
        rel = abs(residual) / max(abs(D_direct), 1e-30)

        cancellation = (
            abs_bound / abs(D_direct)
            if abs(D_direct) > 0 else np.inf
        )

        pair_rows.append(dict(
            L=L,
            M=M,
            ratio_L=float(M/L),
            xmax=xmax,
            discrete=discrete,
            continuum=continuum,
            D_direct=D_direct,
            boundary=boundary,
            signed_Bgprime_integral=signed_int,
            D_abel=D_abel,
            identity_residual=residual,
            abs_identity_residual=abs(residual),
            relative_identity_residual=rel,
            absolute_abel_bound=abs_bound,
            cancellation_factor=cancellation,
        ))

        print(
            f"[{L}->{M}] "
            f"Ddirect={D_direct:+.9e}  "
            f"Dabel={D_abel:+.9e}  "
            f"abs-id={abs(residual):.3e}  "
            f"rel-id={rel:.3e}  "
            f"abs-bound={abs_bound:.6e}  "
            f"cancel={cancellation:.1f}x"
        )

    # Ratios
    for i, r in enumerate(pair_rows):
        if i == 0:
            r["direct_abs_ratio"] = np.nan
            r["absolute_bound_ratio"] = np.nan
        else:
            r["direct_abs_ratio"] = (
                abs(r["D_direct"]) /
                max(abs(pair_rows[i-1]["D_direct"]), 1e-300)
            )
            r["absolute_bound_ratio"] = (
                r["absolute_abel_bound"] /
                max(pair_rows[i-1]["absolute_abel_bound"], 1e-300)
            )

    pd.DataFrame(pair_rows).to_csv(
        args.prefix + "_PAIRS.csv", index=False
    )

    # Save event envelope thin.
    stride = max(1, args.save_stride)
    take = np.arange(0, len(atom_x), stride, dtype=int)
    if take[-1] != len(atom_x)-1:
        take = np.concatenate([take, [len(atom_x)-1]])

    pd.DataFrame(dict(
        x=atom_x[take],
        J_before=J_before[take],
        J_after=J_after[take],
        Li2=Li_atom[take],
        B_before=B_before[take],
        B_after=B_after[take],
        event_abs_B=event_abs[take],
        running_abs_B_envelope=Benv[take],
        Benv_over_sqrtx=Benv[take]/np.sqrt(atom_x[take]),
        Benv_log_over_sqrtx=(
            Benv[take]*np.log(atom_x[take])/np.sqrt(atom_x[take])
        ),
    )).to_csv(
        args.prefix + "_B_EVENTS.csv.gz",
        index=False,
        compression="gzip",
    )

    abs_ok = all(
        r["abs_identity_residual"] <= args.absolute_identity_gate
        for r in pair_rows
    )
    rel_ok = all(
        r["relative_identity_residual"] <= args.relative_identity_gate
        for r in pair_rows
    )
    identity_ok = abs_ok and rel_ok

    # Model decision: compare prospective last-quarter log-RMSE.
    critical_better = (
        crit["holdout_log_rmse"] <= pure["holdout_log_rmse"]
    )

    # A pure beta below 1/2 is NOT accepted as asymptotic evidence when
    # critical-log is equally good/better prospectively.
    beta = pure["parameter"]
    q = crit["parameter"]

    if critical_better:
        growth_verdict = "CRITICAL_LOG_MODEL_AT_LEAST_AS_PLAUSIBLE_AS_SUBHALF_POWER"
    else:
        growth_verdict = "PURE_POWER_FITS_BETTER_ON_CURRENT_HOLDOUT_BUT_ASYMPTOTICS_UNRESOLVED"

    if identity_ok:
        verdict = "EVENT_EXACT_ABEL_IDENTITY_CERTIFIED_NUMERICALLY"
    else:
        verdict = "EVENT_EXACT_ABEL_IDENTITY_STILL_NUMERICALLY_UNRESOLVED"

    summary = dict(
        version=152,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        event_exact_design=dict(
            Li2="Ei(log x)-Ei(log 2)",
            B_jump_resolution="every prime-power interval",
            quadrature="two-point Gauss-Legendre per prime-power interval",
        ),
        identity_gates=dict(
            absolute=args.absolute_identity_gate,
            relative=args.relative_identity_gate,
        ),
        identity_pass=identity_ok,
        pair_results=pair_rows,
        growth_models=dict(
            pure_power=pure,
            critical_sqrt_log=crit,
            growth_verdict=growth_verdict,
        ),
        verdict=verdict,
        analytic_interpretation=(
            "Do not infer a global beta<1/2 merely from a finite-range power fit. "
            "If sqrt(x)/(log x)^q describes the held-out envelope comparably or better, "
            "the observed beta<1/2 can be an effective finite-range exponent rather "
            "than a genuinely subcritical asymptotic power."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print()
    print("Prospective B-envelope model comparison")
    print("-" * 140)
    print(
        f"{'model':>24} {'parameter':>12} {'train R2':>10} "
        f"{'holdout log RMSE':>18} {'max actual/pred':>17}"
    )
    for r in fit_rows:
        print(
            f"{r['model']:>24} "
            f"{r['parameter']:12.6f} "
            f"{r['train_r2']:10.6f} "
            f"{r['holdout_log_rmse']:18.6e} "
            f"{r['holdout_max_actual_over_prediction']:17.6f}"
        )

    print()
    print("Event-exact Abel summaries")
    print("-" * 140)
    print(
        f"{'pair':>18} {'|Ddirect|':>14} {'|Dabel|':>14} "
        f"{'abs id':>12} {'rel id':>12} {'abs Abel':>14} {'cancel':>11}"
    )
    for r in pair_rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{abs(r['D_direct']):14.6e} "
            f"{abs(r['D_abel']):14.6e} "
            f"{r['abs_identity_residual']:12.3e} "
            f"{r['relative_identity_residual']:12.3e} "
            f"{r['absolute_abel_bound']:14.6e} "
            f"{r['cancellation_factor']:11.1f}"
        )

    print()
    print("=" * 140)
    print(f"event-exact Abel identity pass     : {identity_ok}")
    print(f"pure-power beta                    : {beta:.9f}")
    print(f"critical-log q                     : {q:.9f}")
    print(f"growth-model verdict               : {growth_verdict}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 140)
    print("DECISION:")
    print("  Only after the event-exact identity is accurate relative to D itself")
    print("  should the PNT-remainder route be used analytically.")
    print("  A finite-range beta<1/2 is not by itself evidence of an asymptotic")
    print("  subcritical prime-counting remainder; compare it against the critical")
    print("  sqrt(x)/(log x)^q model first.")


if __name__ == "__main__":
    main()
