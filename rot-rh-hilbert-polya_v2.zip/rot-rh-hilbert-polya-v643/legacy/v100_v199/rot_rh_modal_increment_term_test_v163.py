#!/usr/bin/env python3
"""
ROT-RH v163 — MODAL OPERATOR-INCREMENT TERM TEST / CAUCHY NECESSITY AUDIT

ZERO-COST postprocessor.

Purpose
-------
v162 showed strong finite-net contraction of the moving-root Cauchy envelopes,
but the adjacent aggregate trace increments

    D_j = sum_{k<=N} |lambda_k(L_{j+1})-lambda_k(L_j)|

remain roughly O(5e-8) over the newly extended range.

For convergence of EACH fixed finite block, a necessary condition is that
every modal increment tends to zero:

    Delta lambda_{j,k}
      = lambda_k(L_{j+1}) - lambda_k(L_j)
      -> 0.

No amount of sign cancellation can rescue a scalar series if its terms do
not tend to zero.

v163 therefore performs the exact term test on the operator eigenvalue
increments coming from v162.

It measures, mode by mode:
  * Delta E and Delta lambda on every adjacent cutoff shell;
  * amplitude first/last ratios;
  * power fits |Delta lambda| ~ C L^{-alpha};
  * logarithmic fits |Delta lambda| ~ C/(log L)^q;
  * latest-local alpha;
  * sign flips;
  * whether the last increment is smaller than the first;
  * whether the latest 3-shell trend is decreasing.

At shell level it reports:
  * trace increment sum_k |Delta lambda|;
  * max and median modal |Delta lambda|;
  * fraction of modes contracting from the previous shell;
  * fraction with sign flips.

This is a NECESSARY-CONDITION audit for Lemma 1.
If a substantial set of modal increments fails to trend toward zero, the
current moving-root cutoff limit is not yet numerically supported strongly
enough to attempt an analytic Cauchy proof.

NO Xi / zeta / known-zero data are used.
NO phase builds, prime sums, or root solves are performed.

Outputs
-------
<prefix>_MODES.csv
<prefix>_SHELLS.csv
<prefix>_TOP_FAILURES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def fit_power(L, y):
    L = np.asarray(L, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (L > 0) & (y > 0) & np.isfinite(y)
    L = L[mask]
    y = y[mask]

    if len(L) < 2:
        return np.nan, np.nan, np.nan

    X = np.log(L)
    Y = np.log(y)

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    alpha = float(-coef[1])
    C = float(math.exp(coef[0]))

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, C, r2


def fit_log_decay(L, y):
    """
    |dλ| ~ C / (log L)^q
    """
    L = np.asarray(L, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (L > math.e) & (y > 0) & np.isfinite(y)
    L = L[mask]
    y = y[mask]

    if len(L) < 2:
        return np.nan, np.nan, np.nan

    X = np.log(np.log(L))
    Y = np.log(y)

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    q = float(-coef[1])
    C = float(math.exp(coef[0]))

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return q, C, r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--roots-npz",
        default="rot_rh_moving_root_phase_cauchy_v162_ROOTS.npz",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument(
        "--minimum-positive-alpha-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--minimum-latest-contracting-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--latest-max-ratio-gate",
        type=float,
        default=1.10,
        help=(
            "Gate for latest max-modal increment / previous max-modal increment."
        ),
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_modal_increment_term_test_v163",
    )

    args = ap.parse_args()

    z = np.load(args.roots_npz)
    Ls = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    if roots.ndim != 2:
        raise RuntimeError("Expected roots matrix with shape [cutoff, mode].")

    n = min(args.modes, roots.shape[1])
    roots = roots[:, :n]

    if len(Ls) < 5:
        raise RuntimeError("Need at least five cutoff points.")

    lam = roots**(-2)

    nshell = len(Ls)-1

    dE = roots[1:, :] - roots[:-1, :]
    dlam = lam[1:, :] - lam[:-1, :]

    abs_dE = np.abs(dE)
    abs_dlam = np.abs(dlam)

    shell_left = Ls[:-1].astype(float)

    print("=" * 148)
    print("ROT-RH v163 — MODAL OPERATOR-INCREMENT TERM TEST / CAUCHY NECESSITY AUDIT")
    print("=" * 148)
    print("Xi / zeta / known zeros          : NONE")
    print(f"cutoffs                           : {Ls.tolist()}")
    print(f"adjacent shells                   : {nshell}")
    print(f"modes                             : 1..{n}")
    print("=" * 148)

    mode_rows = []

    for k in range(n):
        y = abs_dlam[:, k]
        ye = abs_dE[:, k]

        alpha, Cpow, r2pow = fit_power(shell_left, y)
        qlog, Clog, r2log = fit_log_decay(shell_left, y)

        sign = np.sign(dlam[:, k])
        sign_flips = int(np.sum(sign[1:] != sign[:-1]))

        # Latest local exponent from final two shells.
        if y[-1] > 0 and y[-2] > 0 and shell_left[-1] > shell_left[-2]:
            latest_alpha = (
                -math.log(y[-1]/y[-2])
                / math.log(shell_left[-1]/shell_left[-2])
            )
        else:
            latest_alpha = np.nan

        if len(y) >= 3:
            latest3_decreasing = bool(
                y[-1] < y[-2] < y[-3]
            )
            latest3_ratio = float(
                y[-1]/max(y[-3], 1e-300)
            )
        else:
            latest3_decreasing = False
            latest3_ratio = np.nan

        # A simple finite-range term-test score:
        # <1 means the latest increment is below the first.
        last_over_first = float(y[-1]/max(y[0], 1e-300))

        mode_rows.append(dict(
            k=k+1,
            E_first=float(roots[0, k]),
            E_last=float(roots[-1, k]),
            abs_dE_first=float(ye[0]),
            abs_dE_last=float(ye[-1]),
            abs_dlambda_first=float(y[0]),
            abs_dlambda_last=float(y[-1]),
            last_over_first=last_over_first,
            power_alpha=alpha,
            power_R2=r2pow,
            log_q=qlog,
            log_R2=r2log,
            latest_local_alpha=latest_alpha,
            sign_flips=sign_flips,
            sign_flip_fraction=(
                sign_flips/max(nshell-1, 1)
            ),
            latest3_decreasing=latest3_decreasing,
            latest3_last_over_first=latest3_ratio,
            term_test_contracts=bool(last_over_first < 1.0),
        ))

    modes_df = pd.DataFrame(mode_rows)

    # ------------------------------------------------------------------
    # Shell-level anatomy
    # ------------------------------------------------------------------
    shell_rows = []

    for j in range(nshell):
        trace_inc = float(np.sum(abs_dlam[j]))
        root_inc = float(np.sum(abs_dE[j]))
        max_mode = float(np.max(abs_dlam[j]))
        median_mode = float(np.median(abs_dlam[j]))

        if j == 0:
            trace_ratio = np.nan
            max_mode_ratio = np.nan
            median_ratio = np.nan
            contract_fraction = np.nan
            flip_fraction = np.nan
        else:
            trace_ratio = (
                trace_inc /
                max(shell_rows[-1]["trace_increment"], 1e-300)
            )
            max_mode_ratio = (
                max_mode /
                max(shell_rows[-1]["max_modal_increment"], 1e-300)
            )
            median_ratio = (
                median_mode /
                max(shell_rows[-1]["median_modal_increment"], 1e-300)
            )
            contract_fraction = float(
                np.mean(abs_dlam[j] < abs_dlam[j-1])
            )
            flip_fraction = float(
                np.mean(
                    np.sign(dlam[j]) != np.sign(dlam[j-1])
                )
            )

        shell_rows.append(dict(
            shell=j+1,
            L=int(Ls[j]),
            M=int(Ls[j+1]),
            ratio_M_over_L=float(Ls[j+1]/Ls[j]),
            sum_abs_root_increment=root_inc,
            trace_increment=trace_inc,
            max_modal_increment=max_mode,
            median_modal_increment=median_mode,
            trace_ratio=trace_ratio,
            max_modal_ratio=max_mode_ratio,
            median_modal_ratio=median_ratio,
            modal_contraction_fraction=contract_fraction,
            sign_flip_fraction=flip_fraction,
        ))

    shells_df = pd.DataFrame(shell_rows)

    # ------------------------------------------------------------------
    # Identify the modes that most threaten the necessary term test.
    # ------------------------------------------------------------------
    failures_df = modes_df.sort_values(
        [
            "last_over_first",
            "latest_local_alpha",
        ],
        ascending=[False, True],
    ).head(min(16, n))

    positive_alpha_fraction = float(
        np.mean(modes_df["power_alpha"].to_numpy(dtype=float) > 0)
    )
    positive_latest_alpha_fraction = float(
        np.mean(
            modes_df["latest_local_alpha"].to_numpy(dtype=float) > 0
        )
    )
    contract_first_last_fraction = float(
        np.mean(modes_df["last_over_first"].to_numpy(dtype=float) < 1.0)
    )
    latest3_decreasing_fraction = float(
        np.mean(modes_df["latest3_decreasing"].to_numpy(dtype=bool))
    )

    latest_shell = shell_rows[-1]
    prev_shell = shell_rows[-2]

    latest_modal_contract_fraction = float(
        latest_shell["modal_contraction_fraction"]
    )

    max_modal_latest_ratio = float(
        latest_shell["max_modal_ratio"]
    )

    # Strict necessary-condition support:
    # We don't require every fit to be clean, but the latest shell must show
    # broad modal contraction and no growth of the worst modal amplitude.
    term_test_supported = bool(
        positive_alpha_fraction >= args.minimum_positive_alpha_fraction
        and
        latest_modal_contract_fraction
        >= args.minimum_latest_contracting_fraction
        and
        max_modal_latest_ratio <= args.latest_max_ratio_gate
    )

    if term_test_supported:
        verdict = "MODAL_INCREMENT_TERM_TEST_STRONGLY_SUPPORTED"
    else:
        verdict = "MODAL_INCREMENT_TERM_TEST_UNRESOLVED"

    modes_df.to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    shells_df.to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )
    failures_df.to_csv(
        args.prefix + "_TOP_FAILURES.csv", index=False
    )

    summary = dict(
        version=163,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoffs=Ls.tolist(),
        modes=n,
        necessary_condition=(
            "For each fixed k, adjacent geometric-cutoff increments "
            "Delta lambda_{j,k} must tend to zero if lambda_k(L_j) converges."
        ),
        fractions=dict(
            positive_power_alpha=positive_alpha_fraction,
            positive_latest_local_alpha=positive_latest_alpha_fraction,
            first_to_last_contracting=contract_first_last_fraction,
            latest3_strictly_decreasing=latest3_decreasing_fraction,
            latest_shell_modal_contraction=latest_modal_contract_fraction,
        ),
        latest_shell=dict(
            trace_increment=float(latest_shell["trace_increment"]),
            trace_ratio=float(latest_shell["trace_ratio"]),
            max_modal_increment=float(latest_shell["max_modal_increment"]),
            max_modal_ratio=float(latest_shell["max_modal_ratio"]),
            median_modal_increment=float(latest_shell["median_modal_increment"]),
            median_modal_ratio=float(latest_shell["median_modal_ratio"]),
            sign_flip_fraction=float(latest_shell["sign_flip_fraction"]),
        ),
        verdict=verdict,
        interpretation=(
            "A shrinking finite-net Cauchy envelope is not enough by itself. "
            "For a genuine infinite cutoff limit, every fixed modal increment "
            "must tend to zero. This script directly tests that necessary term "
            "condition on the moving-root operator eigenvalues."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o, np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Adjacent operator-increment shells")
    print("-" * 148)
    print(
        f"{'shell':>6} {'pair':>21} {'trace inc':>13} {'ratio':>9} "
        f"{'max mode':>13} {'ratio':>9} "
        f"{'median':>13} {'ratio':>9} "
        f"{'contract%':>10} {'flip%':>8}"
    )

    for r in shell_rows:
        print(
            f"{r['shell']:6d} "
            f"{r['L']:>9d}->{r['M']:<9d} "
            f"{r['trace_increment']:13.6e} "
            f"{r['trace_ratio']:9.6f} "
            f"{r['max_modal_increment']:13.6e} "
            f"{r['max_modal_ratio']:9.6f} "
            f"{r['median_modal_increment']:13.6e} "
            f"{r['median_modal_ratio']:9.6f} "
            f"{100*r['modal_contraction_fraction']:10.1f} "
            f"{100*r['sign_flip_fraction']:8.1f}"
        )

    print()
    print("Worst modal term-test cases")
    print("-" * 148)
    print(
        f"{'k':>4} {'|dlam| first':>14} {'|dlam| last':>14} "
        f"{'last/first':>12} {'alpha':>10} {'R2':>8} "
        f"{'latest alpha':>13} {'flips':>7} {'last3 dec':>10}"
    )

    for _, r in failures_df.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['abs_dlambda_first']:14.6e} "
            f"{r['abs_dlambda_last']:14.6e} "
            f"{r['last_over_first']:12.6f} "
            f"{r['power_alpha']:10.6f} "
            f"{r['power_R2']:8.4f} "
            f"{r['latest_local_alpha']:13.6f} "
            f"{int(r['sign_flips']):7d} "
            f"{str(bool(r['latest3_decreasing'])):>10}"
        )

    print()
    print("=" * 148)
    print(f"positive power-alpha fraction       : {positive_alpha_fraction:.6f}")
    print(f"positive latest-alpha fraction      : {positive_latest_alpha_fraction:.6f}")
    print(f"first->last contracting fraction    : {contract_first_last_fraction:.6f}")
    print(f"latest-3 decreasing fraction        : {latest3_decreasing_fraction:.6f}")
    print(f"latest modal contraction fraction   : {latest_modal_contract_fraction:.6f}")
    print(f"latest max-modal ratio              : {max_modal_latest_ratio:.9f}")
    print(f"latest trace ratio                  : {latest_shell['trace_ratio']:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 148)
    print("LEMMA-1 NECESSARY CONDITION:")
    print("  Before proving conditional cancellation, verify that for each fixed")
    print("  mode the adjacent eigenvalue increment actually tends to zero:")
    print()
    print("      |lambda_k(L_{j+1})-lambda_k(L_j)| -> 0.")
    print()
    print("  If this fails on persistent modes, finite-block cutoff independence")
    print("  itself is in doubt and no summation-by-parts argument can repair it.")


if __name__ == "__main__":
    main()
