#!/usr/bin/env python3
"""
ROT-RH v176 — HIGH-PRECISION LOCAL ROOT-MANIFOLD RECOVERY

Purpose
-------
v175.3 showed that the double-precision no-hopping continuation fails near
E~10 even though |S_E| is very large and no S=S_E=0 degeneracy is found.

That pattern is consistent with a floating-point residual/phase-evaluation
floor.  v176 recomputes ONLY the failed local intervals with mpmath arbitrary
precision.

For each branch:
  1. load the last v174 certified (tau,E);
  2. refine that root at the SAME tau in high precision;
  3. reconstruct the next intended v174 checkpoint;
  4. subdivide the interval geometrically;
  5. use the implicit predictor
         dE/dtau = -S_tau/S_E
     followed by HIGH-PRECISION NEWTON ONLY;
  6. every Newton correction must remain below a fixed fraction of pi/tau.

There is no Brent fallback and no root search that can silently reconnect to
another branch.

Interpretation
--------------
HIGH_PRECISION_BRANCH_RECOVERED
    The failed double-precision interval is crossed at high precision while
    every correction stays well below one local root spacing.  This strongly
    identifies the v174/v175 failure as numerical conditioning.

HIGH_PRECISION_BRANCH_NOT_RECOVERED
    Even arbitrary precision cannot continue the branch through the local
    interval under the no-hopping gate.  Then the obstruction is not merely
    double precision and deserves analytic study.

Outputs
-------
<prefix>_DETAIL.csv
<prefix>_BRANCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class MPZeroPhase:
    def __init__(self, beta, gamma):
        aa, gg = [], []

        for b, g in zip(beta, gamma):
            b = mp.mpf(str(b))
            g = mp.mpf(str(g))
            a = b - mp.mpf("0.5")

            # rho, conjugate, functional mirror, mirror conjugate
            aa += [a, a, -a, -a]
            gg += [g, -g, g, -g]

        self.a = aa
        self.gamma = gg

    def eval(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        logz = []
        ws = []

        for a, g in zip(self.a, self.gamma):
            w = a + 1j * (E - g)
            zlog = mp.loggamma(w) + a*tau + 1j*(E-g)*tau
            ws.append(w)
            logz.append(zlog)

        shift = max(mp.re(z) for z in logz)

        zs = [mp.exp(z-shift) for z in logz]

        total = mp.fsum(zs)
        S = mp.im(total)

        dE_terms = []
        dt_terms = []

        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE_terms.append(1j*(psi+tau)*z)
            dt_terms.append(w*z)

        SE = mp.im(mp.fsum(dE_terms))
        St = mp.im(mp.fsum(dt_terms))

        return S, SE, St, shift


def mp_newton(
    phase,
    E0,
    tau,
    tol,
    spacing_fraction,
    iterations,
):
    E = mp.mpf(E0)
    tau = mp.mpf(tau)

    spacing = mp.pi / tau
    total_corr = mp.mpf("0")
    max_step_ratio = mp.mpf("0")

    for it in range(iterations):
        S, SE, St, shift = phase.eval(E, tau)

        if abs(S) <= tol:
            return dict(
                ok=True,
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
                iterations=it,
                total_correction=total_corr,
                correction_over_spacing=abs(total_corr)/spacing,
                max_step_over_spacing=max_step_ratio,
            )

        if not mp.isfinite(SE) or abs(SE) == 0:
            return dict(
                ok=False,
                reason="SE_zero_or_nonfinite",
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
            )

        step = -S/SE
        ratio = abs(step)/spacing

        if ratio > spacing_fraction:
            return dict(
                ok=False,
                reason="projection_step_exceeds_spacing_gate",
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
                attempted_step=step,
                step_over_spacing=ratio,
            )

        E += step
        total_corr += step
        max_step_ratio = max(max_step_ratio, ratio)

    S, SE, *_ = phase.eval(E, tau)

    return dict(
        ok=bool(abs(S) <= tol),
        reason="newton_no_convergence",
        E=E,
        residual=abs(S),
        abs_SE=abs(SE),
        iterations=iterations,
        total_correction=total_corr,
        correction_over_spacing=abs(total_corr)/spacing,
        max_step_over_spacing=max_step_ratio,
    )


def continue_interval(
    phase,
    E0,
    t0,
    t1,
    pieces,
    tol,
    spacing_fraction,
    newton_iters,
):
    # Geometric tau subdivision.
    u0 = mp.log(mp.mpf(t0))
    u1 = mp.log(mp.mpf(t1))

    E = mp.mpf(E0)
    tau_prev = mp.mpf(t0)

    rows = []
    max_proj = mp.mpf("0")
    min_SE = mp.inf

    for j in range(pieces):
        frac = mp.mpf(j+1)/pieces
        tau_new = mp.exp(u0 + frac*(u1-u0))

        S0, SE0, St0, _ = phase.eval(E, tau_prev)
        min_SE = min(min_SE, abs(SE0))

        if abs(SE0) == 0:
            return dict(
                ok=False,
                reason="SE_zero_predictor",
                fail_piece=j,
                E=E,
                rows=rows,
                min_abs_SE=min_SE,
                max_projection_ratio=max_proj,
            )

        # Predictor in logarithmic time:
        # dE/du = -tau*S_tau/S_E.
        du = mp.log(tau_new/tau_prev)
        dEdu = -tau_prev*St0/SE0
        E_pred = E + dEdu*du

        proj = mp_newton(
            phase,
            E_pred,
            tau_new,
            tol,
            spacing_fraction,
            newton_iters,
        )

        if not proj["ok"]:
            return dict(
                ok=False,
                reason=proj.get("reason", "projection_failure"),
                fail_piece=j,
                tau_prev=tau_prev,
                tau_new=tau_new,
                E=E,
                E_pred=E_pred,
                projection=proj,
                rows=rows,
                min_abs_SE=min(min_SE, proj.get("abs_SE", mp.inf)),
                max_projection_ratio=max_proj,
            )

        E = proj["E"]
        tau_prev = tau_new
        min_SE = min(min_SE, proj["abs_SE"])
        max_proj = max(
            max_proj,
            proj.get("max_step_over_spacing", mp.mpf("0")),
            proj.get("correction_over_spacing", mp.mpf("0")),
        )

        rows.append(dict(
            piece=j,
            tau=float(tau_new),
            E=float(E),
            residual=float(proj["residual"]),
            abs_SE=float(proj["abs_SE"]),
            correction_over_spacing=float(
                proj.get("correction_over_spacing", 0)
            ),
            max_step_over_spacing=float(
                proj.get("max_step_over_spacing", 0)
            ),
        ))

    return dict(
        ok=True,
        E=E,
        rows=rows,
        min_abs_SE=min_SE,
        max_projection_ratio=max_proj,
    )


def next_checkpoint(global_grid, t0):
    idx = int(np.searchsorted(global_grid, t0, side="right"))
    rel_eps = 1e-12

    while idx < len(global_grid) and not (
        float(global_grid[idx]) > t0*(1.0+rel_eps)
    ):
        idx += 1

    if idx >= len(global_grid):
        return None

    return float(global_grid[idx])


def fmtmp(x, n=8):
    try:
        return mp.nstr(x, n)
    except Exception:
        return str(x)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--candidates-csv",
        default="rot_rh_bellotti_density_adversary_v171_mu4_cap1_CANDIDATES.csv",
    )
    ap.add_argument(
        "--v174-trajectories",
        default="rot_rh_no_hopping_ode_cert_v174_TRAJECTORIES.csv",
    )
    ap.add_argument(
        "--v174-branches",
        default="rot_rh_no_hopping_ode_cert_v174_BRANCHES.csv",
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)
    ap.add_argument("--checkpoints", type=int, default=1200)

    ap.add_argument("--dps", type=int, default=100)
    ap.add_argument(
        "--tol-exp",
        type=int,
        default=60,
        help="High-precision Newton tolerance is 10^(-tol-exp).",
    )
    ap.add_argument("--newton-iters", type=int, default=20)
    ap.add_argument(
        "--projection-spacing-fraction",
        type=float,
        default=0.10,
    )

    ap.add_argument(
        "--piece-levels",
        default="16,32,64,128,256,512,1024,2048",
        help="Comma-separated local subdivisions to try.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_high_precision_local_recovery_v176",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    spacing_fraction = mp.mpf(str(args.projection_spacing_fraction))

    cand = pd.read_csv(args.candidates_csv)
    tr = pd.read_csv(args.v174_trajectories)
    br = pd.read_csv(args.v174_branches)

    phase = MPZeroPhase(
        cand["beta"].to_numpy(float),
        cand["gamma"].to_numpy(float),
    )

    global_grid = np.geomspace(
        args.tau_min, args.tau_max, args.checkpoints
    )

    levels = [
        int(x.strip())
        for x in args.piece_levels.split(",")
        if x.strip()
    ]

    print("=" * 166)
    print("ROT-RH v176 — HIGH-PRECISION LOCAL ROOT-MANIFOLD RECOVERY")
    print("=" * 166)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"complex terms with symmetries     : {len(phase.a)}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"Newton residual tolerance         : 1e-{args.tol_exp}")
    print(f"projection gate                   : {args.projection_spacing_fraction} * pi/tau")
    print(f"piece levels                      : {levels}")
    print("=" * 166)

    branch_rows = []
    detail_rows = []

    for _, brow in br.sort_values("branch").iterrows():
        b = int(brow["branch"])
        gt = tr[tr["branch"] == b].sort_values("tau")

        last = gt.iloc[-1]
        t0f = float(last["tau"])
        E0f = float(last["E"])

        t1f = next_checkpoint(global_grid, t0f)
        if t1f is None:
            branch_rows.append(dict(
                branch=b,
                status="already_at_end",
                tau_start=t0f,
                E_start=E0f,
            ))
            continue

        t0 = mp.mpf(str(t0f))
        t1 = mp.mpf(str(t1f))
        E0 = mp.mpf(str(E0f))

        print()
        print(
            f"[branch {b}] tau={t0f:.12e}->{t1f:.12e}, "
            f"E_double={E0f:.12f}"
        )

        # First refine the saved double-precision root at exactly t0.
        seed_refine = mp_newton(
            phase,
            E0,
            t0,
            tol,
            spacing_fraction,
            args.newton_iters,
        )

        print(
            "  seed refine: "
            f"ok={seed_refine['ok']} "
            f"|S|={fmtmp(seed_refine.get('residual', mp.nan), 8)} "
            f"|SE|={fmtmp(seed_refine.get('abs_SE', mp.nan), 8)} "
            f"corr/sp={fmtmp(seed_refine.get('correction_over_spacing', mp.nan), 8)}"
        )

        if not seed_refine["ok"]:
            branch_rows.append(dict(
                branch=b,
                status="HIGH_PRECISION_SEED_NOT_A_ROOT",
                tau_start=t0f,
                tau_end=t1f,
                E_double=E0f,
                seed_reason=seed_refine.get("reason", ""),
                seed_residual=float(seed_refine.get("residual", mp.nan)),
                seed_abs_SE=float(seed_refine.get("abs_SE", mp.nan)),
            ))
            continue

        E_refined = seed_refine["E"]

        recovered = None
        final_attempt = None

        for pieces in levels:
            att = continue_interval(
                phase,
                E_refined,
                t0,
                t1,
                pieces,
                tol,
                spacing_fraction,
                args.newton_iters,
            )
            final_attempt = att

            print(
                f"  pieces={pieces:5d} "
                f"ok={att['ok']} "
                f"reason={att.get('reason','')} "
                f"min|SE|={fmtmp(att.get('min_abs_SE', mp.nan), 8)} "
                f"max proj/sp={fmtmp(att.get('max_projection_ratio', mp.nan), 8)}"
            )

            for r in att.get("rows", []):
                rr = dict(branch=b, pieces=pieces)
                rr.update(r)
                detail_rows.append(rr)

            if att["ok"]:
                recovered = (pieces, att)
                break

        if recovered is not None:
            pieces, att = recovered
            E1 = att["E"]

            # Final high-precision residual.
            S1, SE1, St1, _ = phase.eval(E1, t1)

            status = "HIGH_PRECISION_BRANCH_RECOVERED"

            branch_rows.append(dict(
                branch=b,
                status=status,
                tau_start=t0f,
                tau_end=t1f,
                E_double_seed=E0f,
                E_refined_start=float(E_refined),
                seed_shift=float(E_refined-E0),
                recovered_pieces=pieces,
                E_end=float(E1),
                endpoint_shift=float(E1-E_refined),
                final_residual=float(abs(S1)),
                final_abs_SE=float(abs(SE1)),
                min_abs_SE=float(att["min_abs_SE"]),
                max_projection_over_spacing=float(
                    att["max_projection_ratio"]
                ),
            ))

            print(
                f"  STATUS: {status}; "
                f"E={float(E_refined):.12f}->{float(E1):.12f}, "
                f"final |S|={fmtmp(abs(S1), 8)}"
            )

        else:
            status = "HIGH_PRECISION_BRANCH_NOT_RECOVERED"

            proj = final_attempt.get("projection", {}) if final_attempt else {}

            branch_rows.append(dict(
                branch=b,
                status=status,
                tau_start=t0f,
                tau_end=t1f,
                E_double_seed=E0f,
                E_refined_start=float(E_refined),
                seed_shift=float(E_refined-E0),
                failure_reason=(
                    "" if final_attempt is None
                    else final_attempt.get("reason", "")
                ),
                failure_piece=(
                    None if final_attempt is None
                    else final_attempt.get("fail_piece", None)
                ),
                failure_residual=float(
                    proj.get("residual", mp.nan)
                ),
                failure_abs_SE=float(
                    proj.get("abs_SE", mp.nan)
                ),
                min_abs_SE=float(
                    final_attempt.get("min_abs_SE", mp.nan)
                    if final_attempt else mp.nan
                ),
            ))

            print(f"  STATUS: {status}")

    branches = pd.DataFrame(branch_rows)

    statuses = branches["status"].tolist()

    if statuses and all(
        s == "HIGH_PRECISION_BRANCH_RECOVERED"
        for s in statuses
    ):
        overall = "DOUBLE_PRECISION_FAILURE_CONFIRMED_NUMERICAL"
    elif any(
        s == "HIGH_PRECISION_SEED_NOT_A_ROOT"
        for s in statuses
    ):
        overall = "DOUBLE_PRECISION_ROOT_VALUES_FAIL_HIGH_PRECISION_CHECK"
    else:
        overall = "HIGH_PRECISION_LOCAL_OBSTRUCTION_REMAINS"

    pd.DataFrame(detail_rows).to_csv(
        args.prefix + "_DETAIL.csv", index=False
    )
    branches.to_csv(
        args.prefix + "_BRANCHES.csv", index=False
    )

    summary = dict(
        version=176,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        mpmath_dps=args.dps,
        newton_tolerance=f"1e-{args.tol_exp}",
        branches=branch_rows,
        overall_verdict=overall,
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("=" * 166)
    print(f"OVERALL VERDICT: {overall}")
    print("=" * 166)

    if overall == "DOUBLE_PRECISION_FAILURE_CONFIRMED_NUMERICAL":
        print("CONSEQUENCE:")
        print("  The v174/v175 local failures were numerical-conditioning effects.")
        print("  The no-hopping root manifold crosses every failed interval in high")
        print("  precision.  The next step is a global high-precision continuation.")
    elif overall == "DOUBLE_PRECISION_ROOT_VALUES_FAIL_HIGH_PRECISION_CHECK":
        print("CONSEQUENCE:")
        print("  Some saved v174 points are not roots of the arbitrary-precision")
        print("  synthetic phase.  The double-precision trajectory became unreliable")
        print("  before the reported failure interval.")
    else:
        print("CONSEQUENCE:")
        print("  The obstruction survives arbitrary precision locally.  Inspect the")
        print("  first failing branch/piece; this is then a genuine feature of the")
        print("  synthetic implicit root equation, not merely a float64 residual floor.")


if __name__ == "__main__":
    main()
