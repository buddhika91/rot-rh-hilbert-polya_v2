#!/usr/bin/env python3
"""
ROT-RH v182.1 — ROOT-REPROJECTED EXACT SWITCH-ERROR DECOMPOSITION

Fix for v182
------------
v182 verified its algebraic identity to ~1e-67, but it reevaluated the phase
at float64 E values loaded from CSV.  At tau~1e8, a tiny rounded E error can
move the point noticeably in phase-cell coordinates.

v182.1 first reprojects every retained sample back onto S(E,tau)=0 at arbitrary
precision using Newton in

    Y = tau*E,

where neighboring root cells are separated by ~pi.

Only after this no-hopping reprojection does it evaluate the exact decomposition

    epsilon
      = epsilon_mix + epsilon_A + epsilon_digamma

with

    epsilon_mix      = tau*(G-gamma_active*R)/(tau*R+Q)
    epsilon_A        = -tau*A/(tau*R+Q)
    epsilon_digamma  = Q*(E-gamma_active)/(tau*R+Q).

This script performs NO continuation.

Inputs
------
--candidates-csv
--hull-csv
--samples-csv   comma-separated v181 *_SAMPLES.csv files

Useful speed control
--------------------
--stride N
    Keep every Nth sample within each switch, always preserving endpoints.
    The default command uses stride=4, which is enough for a fast diagnostic.

Outputs
-------
<prefix>_POINTS.csv
<prefix>_SWITCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapezoid(x, y):
    return float(np.trapezoid(np.asarray(y, float), np.asarray(x, float)))


class ExactPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b-mp.mpf("0.5")

            # rho, conjugate, functional mirror, mirror conjugate
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def raw(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws = []
        logs = []

        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        Z = mp.fsum(zs)
        S = mp.im(Z)
        R = mp.re(Z)

        G = mp.fsum(
            g*mp.re(z)
            for g, z in zip(self.g, zs)
        )
        A = mp.fsum(
            a*mp.im(z)
            for a, z in zip(self.a, zs)
        )
        Q = mp.im(mp.fsum(
            1j*mp.digamma(w)*z
            for w, z in zip(ws, zs)
        ))

        SE = tau*R + Q
        St = E*R-G+A

        return {
            "S": S,
            "R": R,
            "G": G,
            "A": A,
            "Q": Q,
            "SE": SE,
            "St": St,
        }

    def reproject_Y(
        self,
        E_seed,
        tau,
        tol,
        cell_fraction,
        iterations,
    ):
        tau = mp.mpf(tau)
        Y = tau*mp.mpf(E_seed)

        total = mp.mpf("0")
        max_step = mp.mpf("0")

        for it in range(iterations):
            E = Y/tau
            q = self.raw(E, tau)

            if abs(q["S"]) <= tol:
                return {
                    "ok": True,
                    "Y": Y,
                    "E": E,
                    "iterations": it,
                    "residual": abs(q["S"]),
                    "abs_SE": abs(q["SE"]),
                    "total_cell_shift": abs(total)/mp.pi,
                    "max_step_cell_shift": max_step,
                }

            SY = q["SE"]/tau
            if abs(SY) == 0 or not mp.isfinite(SY):
                return {
                    "ok": False,
                    "reason": "S_Y_zero_or_nonfinite",
                }

            step = -q["S"]/SY
            ratio = abs(step)/mp.pi

            if ratio > cell_fraction:
                return {
                    "ok": False,
                    "reason": "reprojection_exceeds_cell_gate",
                    "step_cell_shift": ratio,
                    "residual": abs(q["S"]),
                }

            Y += step
            total += step
            max_step = max(max_step, ratio)

        E = Y/tau
        q = self.raw(E, tau)

        return {
            "ok": bool(abs(q["S"]) <= tol),
            "reason": "newton_no_convergence",
            "Y": Y,
            "E": E,
            "iterations": iterations,
            "residual": abs(q["S"]),
            "abs_SE": abs(q["SE"]),
            "total_cell_shift": abs(total)/mp.pi,
            "max_step_cell_shift": max_step,
        }

    def decompose(self, E, tau, gamma_active):
        E = mp.mpf(E)
        tau = mp.mpf(tau)
        ga = mp.mpf(gamma_active)

        q = self.raw(E, tau)

        S = q["S"]
        R = q["R"]
        G = q["G"]
        A = q["A"]
        Q = q["Q"]
        D = q["SE"]
        St = q["St"]

        Yt = E - tau*St/D
        eps_direct = Yt-ga

        eps_mix = tau*(G-ga*R)/D
        eps_A = -tau*A/D
        eps_dig = Q*(E-ga)/D
        eps_sum = eps_mix+eps_A+eps_dig

        return {
            "S_abs": abs(S),
            "SE_abs": abs(D),
            "epsilon_direct": eps_direct,
            "epsilon_mix": eps_mix,
            "epsilon_A": eps_A,
            "epsilon_digamma": eps_dig,
            "epsilon_sum": eps_sum,
            "epsilon_identity_resid": abs(
                eps_direct-eps_sum
            ),
            "q_over_tauR": (
                abs(Q)/(tau*abs(R))
                if R != 0 else mp.inf
            ),
            "soft_gamma": (
                G/R if R != 0 else mp.nan
            ),
            "R": R,
            "G": G,
            "A": A,
            "Q": Q,
        }


def stride_group(g, stride):
    g = g.sort_values("tau").reset_index(drop=True)

    if stride <= 1 or len(g) <= 2:
        return g

    idx = list(range(0, len(g), stride))
    if (len(g)-1) not in idx:
        idx.append(len(g)-1)

    return g.iloc[sorted(set(idx))].reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument("--samples-csv", required=True)

    ap.add_argument("--dps", type=int, default=60)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=8)
    ap.add_argument(
        "--cell-fraction",
        type=float,
        default=0.10,
    )
    ap.add_argument(
        "--stride",
        type=int,
        default=4,
    )
    ap.add_argument(
        "--identity-gate",
        type=float,
        default=1e-25,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_root_reprojected_decomposition_v182_1",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    cell_fraction = mp.mpf(str(args.cell_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    frames = []
    for name in [
        x.strip()
        for x in args.samples_csv.split(",")
        if x.strip()
    ]:
        p = Path(name)
        if not p.exists():
            raise FileNotFoundError(name)
        d = pd.read_csv(p)
        d["source_file"] = p.name
        frames.append(d)

    samples = pd.concat(frames, ignore_index=True)

    if not {"switch", "tau", "E"}.issubset(samples.columns):
        raise RuntimeError(
            "Sample files must contain switch,tau,E."
        )

    samples = (
        samples
        .sort_values(["switch", "tau"])
        .drop_duplicates(["switch", "tau"], keep="last")
    )

    kept = []
    for sw, g in samples.groupby("switch"):
        kept.append(stride_group(g, args.stride))
    samples = pd.concat(kept, ignore_index=True)

    switches = sorted(
        samples["switch"].astype(int).unique().tolist()
    )

    print("="*176)
    print("ROT-RH v182.1 — ROOT-REPROJECTED EXACT SWITCH-ERROR DECOMPOSITION")
    print("="*176)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switches                          : {switches}")
    print(f"retained sample rows              : {len(samples)}")
    print(f"stride                            : {args.stride}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"root tolerance                    : 1e-{args.tol_exp}")
    print(f"reprojection cell gate            : {args.cell_fraction} * pi")
    print("="*176)

    phases = {}
    point_rows = []
    failures = 0

    for _, r in samples.iterrows():
        sw = int(r["switch"])
        j = sw-1

        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand,
            left["beta_active"],
            left["gamma_active"],
        )
        c2 = match_candidate(
            cand,
            right["beta_active"],
            right["gamma_active"],
        )

        b1 = float(c1["beta"])
        g1 = float(c1["gamma"])
        b2 = float(c2["beta"])
        g2 = float(c2["gamma"])

        key = (sw, b1, g1, b2, g2)
        if key not in phases:
            phases[key] = ExactPhase(
                b1, g1, b2, g2
            )
        phase = phases[key]

        tau = mp.mpf(str(float(r["tau"])))
        E_seed = mp.mpf(str(float(r["E"])))

        rep = phase.reproject_Y(
            E_seed,
            tau,
            tol,
            cell_fraction,
            args.newton_iters,
        )

        if not rep["ok"]:
            failures += 1
            continue

        E = rep["E"]
        ts = float(left["tau_end"])
        ga = g1 if float(tau) <= ts else g2

        dec = phase.decompose(
            E,
            tau,
            mp.mpf(str(ga)),
        )

        row = {
            "switch": sw,
            "tau": float(tau),
            "tau_switch": ts,
            "E_seed": float(E_seed),
            "E_refined": float(E),
            "gamma_active": ga,
            "gamma_left": g1,
            "gamma_right": g2,
            "source_file": r["source_file"],
            "reprojection_total_cell_shift": float(
                rep["total_cell_shift"]
            ),
            "reprojection_max_step_cell_shift": float(
                rep["max_step_cell_shift"]
            ),
            "reprojection_iterations": int(
                rep["iterations"]
            ),
        }

        for k, v in dec.items():
            try:
                row[k] = float(v)
            except Exception:
                row[k] = np.nan

        scale = max(abs(ga), 1.0)
        row["abs_epsilon_over_gamma"] = abs(
            row["epsilon_direct"]
        )/scale
        row["abs_mix_over_gamma"] = abs(
            row["epsilon_mix"]
        )/scale
        row["abs_A_over_gamma"] = abs(
            row["epsilon_A"]
        )/scale
        row["abs_digamma_over_gamma"] = abs(
            row["epsilon_digamma"]
        )/scale

        point_rows.append(row)

    pts = (
        pd.DataFrame(point_rows)
        .sort_values(["switch", "tau"])
        .reset_index(drop=True)
    )

    if len(pts) == 0:
        raise RuntimeError(
            "No points survived high-precision reprojection."
        )

    switch_rows = []

    for sw, g in pts.groupby("switch"):
        g = g.sort_values("tau")

        tau = g["tau"].to_numpy(float)
        active = g["gamma_active"].to_numpy(float)

        e = g["epsilon_direct"].to_numpy(float)
        em = g["epsilon_mix"].to_numpy(float)
        ea = g["epsilon_A"].to_numpy(float)
        ed = g["epsilon_digamma"].to_numpy(float)

        active_int = trapezoid(tau, active)
        denom = max(abs(active_int), 1e-300)

        abs_total = trapezoid(tau, np.abs(e))
        abs_mix = trapezoid(tau, np.abs(em))
        abs_A = trapezoid(tau, np.abs(ea))
        abs_dig = trapezoid(tau, np.abs(ed))

        comp = {
            "mix": abs_mix,
            "A": abs_A,
            "digamma": abs_dig,
        }
        dominant = max(comp, key=comp.get)

        rr = {
            "switch": int(sw),
            "samples": len(g),
            "absolute_total_over_active": abs_total/denom,
            "absolute_mix_over_active": abs_mix/denom,
            "absolute_A_over_active": abs_A/denom,
            "absolute_digamma_over_active": abs_dig/denom,
            "dominant_component": dominant,
            "max_q_over_tauR": float(
                g["q_over_tauR"]
                .replace([np.inf, -np.inf], np.nan)
                .max()
            ),
            "max_phase_residual": float(
                g["S_abs"].max()
            ),
            "max_identity_residual": float(
                g["epsilon_identity_resid"].max()
            ),
            "max_reprojection_cell_shift": float(
                g["reprojection_total_cell_shift"].max()
            ),
            "max_reprojection_step_cell_shift": float(
                g["reprojection_max_step_cell_shift"].max()
            ),
        }

        switch_rows.append(rr)

        print(
            f"[switch {int(sw):4d}] "
            f"|eps|/active={rr['absolute_total_over_active']:.3e} "
            f"mix={rr['absolute_mix_over_active']:.3e} "
            f"A={rr['absolute_A_over_active']:.3e} "
            f"dig={rr['absolute_digamma_over_active']:.3e} "
            f"dominant={dominant} "
            f"reproj={rr['max_reprojection_cell_shift']:.3e} cells"
        )

    swdf = pd.DataFrame(switch_rows)

    max_identity = float(
        pts["epsilon_identity_resid"].max()
    )
    identity_pass = bool(
        max_identity <= args.identity_gate
    )

    totals = {
        "mix": float(
            swdf["absolute_mix_over_active"].sum()
        ),
        "A": float(
            swdf["absolute_A_over_active"].sum()
        ),
        "digamma": float(
            swdf["absolute_digamma_over_active"].sum()
        ),
    }
    dominant_global = max(
        totals, key=totals.get
    )

    verdict = (
        "ROOT_REPROJECTED_DECOMPOSITION_VERIFIED"
        if failures == 0 and identity_pass
        else "ROOT_REPROJECTED_DECOMPOSITION_WARNING"
    )

    pts.to_csv(
        args.prefix+"_POINTS.csv",
        index=False,
    )
    swdf.to_csv(
        args.prefix+"_SWITCHES.csv",
        index=False,
    )

    summary = {
        "version": "182.1",
        "switches": switches,
        "retained_samples": len(samples),
        "reprojected_points": len(pts),
        "reprojection_failures": failures,
        "max_epsilon_identity_residual": max_identity,
        "identity_gate": args.identity_gate,
        "identity_pass": identity_pass,
        "aggregate_component_scores": totals,
        "dominant_global_component": dominant_global,
        "verdict": verdict,
    }

    Path(
        args.prefix+"_SUMMARY.json"
    ).write_text(
        json.dumps(
            native(summary),
            indent=2,
            allow_nan=True,
        ),
        encoding="utf-8",
    )

    print()
    print("="*176)
    print(f"reprojection failures              : {failures}")
    print(f"max epsilon identity residual      : {max_identity:.6e}")
    print(f"identity pass                      : {identity_pass}")
    print(f"aggregate mix score                : {totals['mix']:.6e}")
    print(f"aggregate A score                  : {totals['A']:.6e}")
    print(f"aggregate digamma score            : {totals['digamma']:.6e}")
    print(f"dominant analytic component        : {dominant_global}")
    print(f"VERDICT                            : {verdict}")
    print("="*176)


if __name__ == "__main__":
    main()
