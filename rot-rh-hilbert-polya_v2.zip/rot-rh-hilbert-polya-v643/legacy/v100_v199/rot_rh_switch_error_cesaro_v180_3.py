#!/usr/bin/env python3
"""
ROT-RH v180.3 — TARGETED LATE-SWITCH ERROR / CESARO AUDIT

Fixes v180.1 continuation failures by replacing the fixed switch grid with
adaptive log-tau subdivision.  It preserves the same theorem target:

    (tau E)' = gamma_active + epsilon.

For each sampled switch:
  * build the exact two-layer Gamma phase with conjugates + functional mirrors;
  * initialize one local root near gamma_left;
  * advance through a narrow switch window using RK4 in u=log(tau);
  * project with high-precision Newton ONLY;
  * recursively bisect any step that violates the projection/no-hopping gate;
  * compute epsilon on the accepted adaptive mesh and integrate it in tau.

No Xi / zeta / known zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class TwoLayerPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []
        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b - mp.mpf("0.5")
            # rho, conjugate, functional mirror, mirror conjugate
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def eval(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws, logs = [], []
        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w) + a*tau + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        S = mp.im(mp.fsum(zs))

        dE_terms = []
        dt_terms = []
        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE_terms.append(1j*(psi+tau)*z)
            dt_terms.append(w*z)

        SE = mp.im(mp.fsum(dE_terms))
        St = mp.im(mp.fsum(dt_terms))
        return S, SE, St

    def flow_u(self, E, u):
        tau = mp.exp(u)
        S, SE, St = self.eval(E, tau)
        if abs(SE) == 0 or not mp.isfinite(SE):
            raise ArithmeticError("S_E zero/nonfinite")
        return -tau*St/SE


def newton_project(phase, E0, tau, tol, frac, iters):
    E = mp.mpf(E0)
    tau = mp.mpf(tau)
    spacing = mp.pi/tau
    total = mp.mpf("0")
    max_ratio = mp.mpf("0")

    for _ in range(iters):
        S, SE, St = phase.eval(E, tau)

        if abs(S) <= tol:
            return {
                "ok": True,
                "E": E,
                "residual": abs(S),
                "abs_SE": abs(SE),
                "total_ratio": abs(total)/spacing,
                "max_step_ratio": max_ratio,
            }

        if abs(SE) == 0 or not mp.isfinite(SE):
            return {"ok": False, "reason": "SE_zero_or_nonfinite"}

        step = -S/SE
        ratio = abs(step)/spacing

        if ratio > frac:
            return {
                "ok": False,
                "reason": "projection_step_exceeds_gate",
                "step_ratio": ratio,
                "residual": abs(S),
                "abs_SE": abs(SE),
            }

        E += step
        total += step
        max_ratio = max(max_ratio, ratio)

    S, SE, St = phase.eval(E, tau)
    return {
        "ok": bool(abs(S) <= tol),
        "reason": "newton_no_convergence",
        "E": E,
        "residual": abs(S),
        "abs_SE": abs(SE),
        "total_ratio": abs(total)/spacing,
        "max_step_ratio": max_ratio,
    }


def nearest_initial_root(phase, tau, center, tol, frac, iters, cells):
    tau = mp.mpf(tau)
    center = mp.mpf(center)
    spacing = mp.pi/tau

    good = []
    for j in range(-cells, cells+1):
        seed = center + mp.mpf(j)*spacing/2
        p = newton_project(phase, seed, tau, tol, frac, iters)
        if p["ok"]:
            good.append(p)

    if not good:
        return {"ok": False, "reason": "no_initial_local_root"}

    good.sort(key=lambda r: abs(r["E"]-center))
    return good[0]


def rk4_predict(phase, E0, t0, t1):
    u0 = mp.log(t0)
    u1 = mp.log(t1)
    h = u1-u0

    k1 = phase.flow_u(E0, u0)
    k2 = phase.flow_u(E0+h*k1/2, u0+h/2)
    k3 = phase.flow_u(E0+h*k2/2, u0+h/2)
    k4 = phase.flow_u(E0+h*k3, u1)

    return E0 + h*(k1+2*k2+2*k3+k4)/6


def direct_step(phase, E0, t0, t1, tol, frac, iters):
    try:
        pred = rk4_predict(phase, E0, t0, t1)
    except Exception as exc:
        return {"ok": False, "reason": f"rk4:{exc}"}

    p = newton_project(phase, pred, t1, tol, frac, iters)
    if not p["ok"]:
        return {
            "ok": False,
            "reason": p.get("reason", "projection_failure"),
            "projection": p,
        }

    return {
        "ok": True,
        "E": p["E"],
        "projection": p,
    }


def adaptive_step(
    phase, E0, t0, t1, tol, frac, iters, max_depth, depth=0
):
    d = direct_step(phase, E0, t0, t1, tol, frac, iters)

    if d["ok"]:
        p = d["projection"]
        return {
            "ok": True,
            "E": d["E"],
            "leaves": [{
                "tau": float(t1),
                "E": float(d["E"]),
                "residual": float(p["residual"]),
                "abs_SE": float(p["abs_SE"]),
                "max_projection_over_spacing": float(
                    max(p["total_ratio"], p["max_step_ratio"])
                ),
                "depth": depth,
            }],
            "max_depth": depth,
        }

    if depth >= max_depth:
        return {
            "ok": False,
            "reason": "max_subdivision_depth_reached",
            "underlying_reason": d.get("reason", ""),
            "depth": depth,
            "tau_start": float(t0),
            "tau_end": float(t1),
        }

    tm = mp.exp((mp.log(t0)+mp.log(t1))/2)

    left = adaptive_step(
        phase, E0, t0, tm, tol, frac, iters, max_depth, depth+1
    )
    if not left["ok"]:
        return left

    right = adaptive_step(
        phase, left["E"], tm, t1, tol, frac, iters, max_depth, depth+1
    )
    if not right["ok"]:
        return right

    return {
        "ok": True,
        "E": right["E"],
        "leaves": left["leaves"] + right["leaves"],
        "max_depth": max(left["max_depth"], right["max_depth"]),
    }


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapz(x, y):
    return float(np.trapezoid(np.asarray(y, float), np.asarray(x, float)))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)

    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument("--tol-exp", type=int, default=30)
    ap.add_argument("--newton-iters", type=int, default=10)
    ap.add_argument("--projection-spacing-fraction", type=float, default=0.20)

    ap.add_argument("--switch-log-halfwidth", type=float, default=0.20)
    ap.add_argument(
        "--base-points",
        type=int,
        default=17,
        help="Coarse points per switch; adaptive refinement is added only where needed.",
    )
    ap.add_argument("--initial-search-cells", type=int, default=4)
    ap.add_argument("--sample-switches", type=int, default=8)
    ap.add_argument(
        "--switch-indices",
        default="",
        help="Optional comma-separated 1-based hull switch numbers, e.g. 114,136,159. Overrides --sample-switches.",
    )
    ap.add_argument("--max-subdivision-depth", type=int, default=14)
    ap.add_argument("--relative-error-gate", type=float, default=0.05)

    ap.add_argument(
        "--prefix",
        default="rot_rh_switch_error_adaptive_v180_2",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.projection_spacing_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = pd.read_csv(args.hull_csv).sort_values("tau_start").reset_index(drop=True)

    required_c = {"beta", "gamma"}
    required_h = {"tau_start", "tau_end", "gamma_active", "beta_active"}

    if not required_c.issubset(cand.columns):
        raise RuntimeError("Candidates CSV must contain beta,gamma.")
    if not required_h.issubset(hull.columns):
        raise RuntimeError(
            "Hull CSV must contain tau_start,tau_end,gamma_active,beta_active."
        )

    total_switches = len(hull)-1

    if args.switch_indices.strip():
        requested = []
        for tok in args.switch_indices.split(","):
            tok = tok.strip()
            if not tok:
                continue
            k = int(tok)
            if k < 1 or k > total_switches:
                raise ValueError(
                    f"switch index {k} outside valid 1..{total_switches}"
                )
            requested.append(k-1)  # internal 0-based
        switch_indices = sorted(set(requested))
    else:
        count = min(args.sample_switches, total_switches)
        switch_indices = sorted(set(
            int(round(x))
            for x in np.linspace(0, total_switches-1, count)
        ))

    print("="*172)
    print("ROT-RH v180.3 — TARGETED LATE-SWITCH ERROR / CESARO AUDIT")
    print("="*172)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"active hull segments              : {len(hull)}")
    print(f"sampled switches                  : {len(switch_indices)} / {total_switches}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"base points per switch            : {args.base_points}")
    print(f"max adaptive depth                : {args.max_subdivision_depth}")
    print(f"switch log halfwidth              : {args.switch_log_halfwidth}")
    print(f"projection gate                   : {args.projection_spacing_fraction} * pi/tau")
    print("="*172)

    switch_rows = []
    sample_rows = []

    total_signed = 0.0
    total_abs = 0.0
    total_active = 0.0
    failures = 0

    for ordinal, j in enumerate(switch_indices, start=1):
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        ts = float(left["tau_end"])
        c1 = match_candidate(cand, left["beta_active"], left["gamma_active"])
        c2 = match_candidate(cand, right["beta_active"], right["gamma_active"])

        b1 = float(c1["beta"]); g1 = float(c1["gamma"])
        b2 = float(c2["beta"]); g2 = float(c2["gamma"])

        phase = TwoLayerPhase(b1, g1, b2, g2)

        w = args.switch_log_halfwidth
        t0 = mp.mpf(str(ts*math.exp(-w)))
        t1 = mp.mpf(str(ts*math.exp(+w)))

        init = nearest_initial_root(
            phase, t0, mp.mpf(str(g1)),
            tol, frac, args.newton_iters, args.initial_search_cells
        )

        if not init["ok"]:
            failures += 1
            switch_rows.append({
                "switch": j+1,
                "status": "INITIAL_ROOT_UNRESOLVED",
                "tau_switch": ts,
                "gamma_left": g1,
                "gamma_right": g2,
            })
            print(
                f"[{ordinal:2d}/{len(switch_indices)} | hull {j+1:4d}] "
                f"tau={ts:.3e} g:{g1:.3e}->{g2:.3e} INIT FAIL"
            )
            continue

        # Start sample.
        E = init["E"]
        S0, SE0, St0 = phase.eval(E, t0)
        Eu0 = -t0*St0/SE0

        local = [{
            "tau": float(t0),
            "E": float(E),
            "residual": float(abs(S0)),
            "abs_SE": float(abs(SE0)),
            "E_u": float(Eu0),
            "max_projection_over_spacing": float(
                max(init["total_ratio"], init["max_step_ratio"])
            ),
            "depth": 0,
        }]

        base_grid = np.geomspace(float(t0), float(t1), args.base_points)
        ok = True
        max_depth_used = 0

        for k in range(1, len(base_grid)):
            ta = mp.mpf(str(base_grid[k-1]))
            tb = mp.mpf(str(base_grid[k]))

            adv = adaptive_step(
                phase, E, ta, tb,
                tol, frac, args.newton_iters,
                args.max_subdivision_depth
            )

            if not adv["ok"]:
                failures += 1
                ok = False
                switch_rows.append({
                    "switch": j+1,
                    "status": "SWITCH_CONTINUATION_UNRESOLVED",
                    "reason": adv.get("reason", ""),
                    "underlying_reason": adv.get("underlying_reason", ""),
                    "failure_tau_start": adv.get("tau_start", np.nan),
                    "failure_tau_end": adv.get("tau_end", np.nan),
                    "failure_depth": adv.get("depth", np.nan),
                    "tau_switch": ts,
                    "gamma_left": g1,
                    "gamma_right": g2,
                })
                print(
                    f"[{ordinal:2d}/{len(switch_indices)} | hull {j+1:4d}] "
                    f"tau={ts:.3e} g:{g1:.3e}->{g2:.3e} "
                    f"FAIL depth={adv.get('depth')}"
                )
                break

            E = adv["E"]
            max_depth_used = max(max_depth_used, adv["max_depth"])

            # Compute exact flow diagnostics at every accepted adaptive leaf.
            for leaf in adv["leaves"]:
                tt = mp.mpf(str(leaf["tau"]))
                EE = mp.mpf(str(leaf["E"]))
                S, SE, St = phase.eval(EE, tt)
                Eu = -tt*St/SE

                local.append({
                    "tau": float(tt),
                    "E": float(EE),
                    "residual": float(abs(S)),
                    "abs_SE": float(abs(SE)),
                    "E_u": float(Eu),
                    "max_projection_over_spacing": leaf[
                        "max_projection_over_spacing"
                    ],
                    "depth": int(leaf["depth"]),
                })

        if not ok:
            continue

        # Remove duplicate tau points, sorted.
        df = pd.DataFrame(local).sort_values("tau")
        df = df.drop_duplicates(subset=["tau"], keep="last")

        taus = df["tau"].to_numpy(float)
        Es = df["E"].to_numpy(float)
        Eus = df["E_u"].to_numpy(float)

        gact = np.where(taus <= ts, g1, g2)
        eps = Es + Eus - gact

        signed = trapz(taus, eps)
        absolute = trapz(taus, np.abs(eps))
        active = trapz(taus, gact)

        rel_signed = signed/max(abs(active), 1e-300)
        rel_abs = absolute/max(abs(active), 1e-300)

        max_eps = float(
            np.max(np.abs(eps)/np.maximum(np.abs(gact), 1.0))
        )
        max_proj = float(df["max_projection_over_spacing"].max())
        min_se = float(df["abs_SE"].min())

        total_signed += signed
        total_abs += absolute
        total_active += active

        switch_rows.append({
            "switch": j+1,
            "status": "PASS",
            "tau_switch": ts,
            "beta_left": b1,
            "gamma_left": g1,
            "beta_right": b2,
            "gamma_right": g2,
            "samples": len(df),
            "max_depth_used": max_depth_used,
            "E_start": float(Es[0]),
            "E_end": float(Es[-1]),
            "signed_epsilon_integral": signed,
            "absolute_epsilon_integral": absolute,
            "active_gamma_integral": active,
            "signed_error_over_active": rel_signed,
            "absolute_error_over_active": rel_abs,
            "max_abs_epsilon_over_gamma": max_eps,
            "min_abs_SE": min_se,
            "max_projection_over_spacing": max_proj,
        })

        for q in range(len(df)):
            sample_rows.append({
                "switch": j+1,
                "tau": float(taus[q]),
                "E": float(Es[q]),
                "E_u": float(Eus[q]),
                "gamma_active_local": float(gact[q]),
                "epsilon": float(eps[q]),
                "abs_epsilon_over_gamma": float(
                    abs(eps[q])/max(abs(gact[q]), 1.0)
                ),
                "abs_SE": float(df.iloc[q]["abs_SE"]),
                "projection_over_spacing": float(
                    df.iloc[q]["max_projection_over_spacing"]
                ),
                "depth": int(df.iloc[q]["depth"]),
            })

        print(
            f"[{ordinal:2d}/{len(switch_indices)} | hull {j+1:4d}] "
            f"tau={ts:.3e} g:{g1:.3e}->{g2:.3e} "
            f"|Int eps|/Int g={rel_abs:.3e} "
            f"max|eps|/g={max_eps:.3e} "
            f"depth={max_depth_used} proj={max_proj:.3e}"
        )

    rel_total_signed = (
        total_signed/max(abs(total_active), 1e-300)
        if total_active != 0 else np.inf
    )
    rel_total_abs = (
        total_abs/max(abs(total_active), 1e-300)
        if total_active != 0 else np.inf
    )

    if failures:
        verdict = "ADAPTIVE_SWITCH_CONTINUATION_UNRESOLVED"
    elif rel_total_abs <= args.relative_error_gate:
        verdict = "SWITCH_ERROR_CESARO_NEGLIGIBLE"
    else:
        verdict = "SWITCH_ERROR_NOT_NEGLIGIBLE"

    pd.DataFrame(switch_rows).to_csv(
        args.prefix+"_SWITCHES.csv", index=False
    )
    pd.DataFrame(sample_rows).to_csv(
        args.prefix+"_SAMPLES.csv", index=False
    )

    summary = {
        "version": "180.3",
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "sampled_switches": len(switch_indices),
        "completed_switches": sum(
            1 for r in switch_rows if r.get("status") == "PASS"
        ),
        "continuation_failures": failures,
        "total_signed_epsilon_integral": total_signed,
        "total_absolute_epsilon_integral": total_abs,
        "total_active_gamma_integral": total_active,
        "total_signed_error_over_active": rel_total_signed,
        "total_absolute_error_over_active": rel_total_abs,
        "relative_error_gate": args.relative_error_gate,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*172)
    print(f"switches completed                 : {summary['completed_switches']}/{len(switch_indices)}")
    print(f"continuation failures              : {failures}")
    print(f"total signed eps / active          : {rel_total_signed:.6e}")
    print(f"total absolute eps / active        : {rel_total_abs:.6e}")
    print(f"gate                               : {args.relative_error_gate:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*172)


if __name__ == "__main__":
    main()
