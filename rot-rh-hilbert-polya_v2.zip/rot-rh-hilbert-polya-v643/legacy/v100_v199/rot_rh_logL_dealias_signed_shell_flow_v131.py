#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v131 — Log-L De-aliasing / Signed Shell-Flow Audit
=========================================================

PURPOSE
-------
v130 established that the zero-free PNT-finite-part root-response identities
are numerically exact, but its deliberately strong sufficient condition

    sum_j |E_k(2L_j)-E_k(L_j)| < infinity

was not supported uniformly across fixed k.  In particular, some branches
showed large non-monotone DYADIC shell magnitudes despite extremely small
PNT-error/kernel bilinear cosines.

v131 tests the next mathematically legitimate possibility: the L-flow may be a
SIGNED OSCILLATORY scale flow whose amplitude decays, while exact dyadic
sampling aliases that oscillation.

Instead of only L -> 2L, build a fine logarithmic ladder

    L_j ~= L_0 * 2^(j/s),

where s = --steps-per-doubling (default 2).  Track fixed arithmetic roots

    F_L^FP(E_k(L)) = k - 1/2

and the signed increments

    dE_{k,j} = E_k(L_{j+1}) - E_k(L_j).

For every fine transition, the exact secant identity is checked:

    dE * D* = -[F_{L2}^FP(E_k(L1)) - F_{L1}^FP(E_k(L1))].

The exact discrete Abel/PNT split is also available:

    DeltaP = S_main + S_error,
    S_error = E_PNT(N) f(N) + sum E_PNT(n)[f(n)-f(n+1)].

OSCILLATORY MODEL
-----------------
The shell is concentrated near n ~ L, so the natural arithmetic log-scale
phase is approximately E log L.  For each fixed k, v131 preregisters the model

    dE_j ~= (log L_mid)^(-q)
             [c sin(E_ref log L_mid) + d cos(E_ref log L_mid)],

where E_ref is the median ZERO-FREE arithmetic root on the ladder and q is
chosen by a fixed grid scan.  The constant-amplitude q=0 model is the null.

On a geometric L ladder, if q>0 and the phase advance is non-zero modulo 2*pi,
a theorem of Dirichlet/summation-by-parts type can in principle yield signed
convergence even when absolute shell summability fails.  v131 is only a finite
numerical precursor to such a theorem.

DE-ALIAS DIAGNOSTICS
--------------------
For each fixed k, report:
  * fine-grid signed/absolute variation and net cancellation;
  * within-doubling cancellation: |coarse dyadic step| / sum |fine steps|;
  * dyadic and fine-grid phase advances E_ref log(r)/(2*pi);
  * nearest low-order rational to the dyadic phase advance;
  * best log-envelope exponent q in the fixed-frequency signed model;
  * R^2 and AIC improvement relative to q=0;
  * late-vs-early RMS amplitude ratio;
  * sign-change count;
  * exact secant, finite-part, and Abel/PNT identities.

SCIENTIFIC BOUNDARY
-------------------
* NO Xi evaluations.
* NO zeta evaluations.
* NO known zero ordinates.
* PASS means the selected finite zero-free branches are consistent with a
  decaying signed log-L oscillation after de-aliasing.  It is NOT a proof of
  L->infinity, regulator independence, Hilbert-Polya, or RH.
* The sampled derivative minimum is NOT an analytic infimum.

Outputs
-------
  <prefix>_POINTS.csv
  <prefix>_K_SUMMARY.csv
  <prefix>_DOUBLING_BLOCKS.csv
  <prefix>_VERDICT.json

Build: 2026-08-18-logL-dealias-signed-shell-flow-v131
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from fractions import Fraction
from pathlib import Path
from typing import List, Sequence, Tuple

import numpy as np
from scipy.special import erfc

VERSION = "v131"
BUILD = "2026-08-18-logL-dealias-signed-shell-flow-v131"
EPS = 1.0e-300


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path: Path, rows: Sequence[dict]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [json_safe(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating, float)):
        x = float(obj)
        return x if math.isfinite(x) else None
    if isinstance(obj, (np.integer, int)):
        return int(obj)
    if isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    return obj


def safe_norm(x) -> float:
    x = np.asarray(x, float)
    return float(np.sqrt(np.dot(x, x)))


def corr_cos(x, y) -> float:
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    nx, ny = safe_norm(x), safe_norm(y)
    if nx <= EPS or ny <= EPS:
        return float("nan")
    return float(np.dot(x, y) / (nx * ny))


def relerr(a: float, b: float, floor: float = 1e-30) -> float:
    return float(abs(a - b) / max(abs(a), abs(b), floor))


def sign_changes(x: Sequence[float], tol: float = 0.0) -> int:
    a = np.asarray(x, float)
    if tol > 0:
        a[np.abs(a) <= tol] = 0.0
    s = np.sign(a)
    s = s[s != 0]
    if len(s) < 2:
        return 0
    return int(np.sum(s[1:] != s[:-1]))


def geometric_L_ladder(L_start: int, L_end: int, steps_per_doubling: int) -> List[int]:
    if L_start < 8 or L_end <= L_start:
        raise ValueError("Require 8 <= L_start < L_end.")
    if steps_per_doubling < 2:
        raise ValueError("--steps-per-doubling must be >=2 for a de-alias audit.")
    n = int(math.floor(steps_per_doubling * math.log2(L_end / L_start) + 1e-12))
    vals = [int(round(L_start * 2.0 ** (j / steps_per_doubling))) for j in range(n + 1)]
    if vals[-1] < L_end:
        vals.append(int(L_end))
    # preserve order; rounding can in principle duplicate tiny L values
    out = []
    for L in vals:
        if not out or L > out[-1]:
            out.append(L)
    return out


def nearest_low_order_rational(x: float, max_den: int = 8) -> Tuple[int, int, float]:
    frac = float(x) % 1.0
    f = Fraction(frac).limit_denominator(int(max_den))
    err = abs(frac - f.numerator / f.denominator)
    return int(f.numerator), int(f.denominator), float(err)


def linear_fit_metrics(X: np.ndarray, y: np.ndarray) -> dict:
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    resid = y - pred
    sse = float(np.dot(resid, resid))
    sst = float(np.dot(y - np.mean(y), y - np.mean(y)))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0
    n = len(y)
    p = X.shape[1]
    # AIC up to a common additive constant.
    aic = n * math.log(max(sse / max(n, 1), EPS)) + 2.0 * p
    return {
        "beta": beta,
        "pred": pred,
        "sse": sse,
        "r2": float(r2),
        "aic": float(aic),
    }


def fit_logL_oscillator(Lmid: np.ndarray, dE: np.ndarray, Eref: float,
                        qmin: float, qmax: float, qpoints: int) -> dict:
    Lmid = np.asarray(Lmid, float)
    y = np.asarray(dE, float)
    phase = float(Eref) * np.log(Lmid)
    s = np.sin(phase)
    c = np.cos(phase)

    qgrid = np.linspace(float(qmin), float(qmax), int(qpoints))
    best = None
    null = None
    for q in qgrid:
        amp = np.log(Lmid) ** (-float(q))
        X = np.column_stack([amp * s, amp * c])
        fit = linear_fit_metrics(X, y)
        row = {
            "q": float(q),
            "r2": fit["r2"],
            "aic": fit["aic"],
            "sse": fit["sse"],
            "sin_coeff": float(fit["beta"][0]),
            "cos_coeff": float(fit["beta"][1]),
        }
        if abs(float(q)) <= 0.5 * (qgrid[1] - qgrid[0] if len(qgrid) > 1 else 1.0):
            null = row
        if best is None or row["sse"] < best["sse"]:
            best = row

    if null is None:
        amp = np.ones_like(Lmid)
        fit = linear_fit_metrics(np.column_stack([amp * s, amp * c]), y)
        null = {
            "q": 0.0,
            "r2": fit["r2"],
            "aic": fit["aic"],
            "sse": fit["sse"],
            "sin_coeff": float(fit["beta"][0]),
            "cos_coeff": float(fit["beta"][1]),
        }

    best = dict(best)
    best["amplitude_constant"] = float(math.hypot(best["sin_coeff"], best["cos_coeff"]))
    best["phase_offset"] = float(math.atan2(best["cos_coeff"], best["sin_coeff"]))
    best["delta_aic_vs_q0"] = float(null["aic"] - best["aic"])
    best["null_r2_q0"] = float(null["r2"])
    best["null_aic_q0"] = float(null["aic"])
    return best


# ---------------------------------------------------------------------------
# Exact-tail phase builder: same phase as v102.1, exact erfc tail majorant
# ---------------------------------------------------------------------------

def build_phase_exact_tail(v102, base, L: int, tail_factor: float, counter_q: int):
    nmax = max(8, int(math.ceil(float(tail_factor) * float(L))))
    numbers, lambdas, _ = base.mangoldt_terms(nmax)
    nums = numbers.astype(float)
    logs = np.log(nums)
    phase_w = lambdas / (logs * np.sqrt(nums)) * np.exp(-nums / float(L))

    N = float(nmax)
    # Exact integral: int_N^inf exp(-x/L) x^-1/2 dx
    tail_int = math.sqrt(math.pi * float(L)) * float(erfc(math.sqrt(N / float(L))))
    tail_lattice = math.exp(-(N + 1.0) / float(L)) / math.sqrt(N + 1.0)
    phase_tail = (tail_int + tail_lattice) / math.pi

    return v102.RenormalizedPhase(
        base=base,
        L=int(L),
        nmax=int(nmax),
        logs=np.asarray(logs, float),
        phase_w=np.asarray(phase_w, float),
        counter=v102.PNTCounterterm.build(int(L), int(counter_q)),
        prime_tail_abs_bound=float(phase_tail),
    )


# ---------------------------------------------------------------------------
# Exact PNT / Abel shell geometry
# ---------------------------------------------------------------------------

def dense_mangoldt(base, Nmax: int) -> Tuple[np.ndarray, np.ndarray]:
    numbers, lambdas, _ = base.mangoldt_terms(int(Nmax))
    lam = np.zeros(int(Nmax) + 1, float)
    np.add.at(lam, np.asarray(numbers, int), np.asarray(lambdas, float))
    return lam, np.cumsum(lam)


def shell_test_function(E: float, n: np.ndarray, L1: int, L2: int,
                        N1: int, N2: int) -> np.ndarray:
    n = np.asarray(n, float)
    logn = np.log(n)
    phase = np.sin(float(E) * logn)
    denom = np.sqrt(n) * logn
    w2 = np.exp(-n / float(L2)) * (n <= float(N2))
    w1 = np.exp(-n / float(L1)) * (n <= float(N1))
    return (w2 - w1) * phase / denom


def abel_shell_geometry(phase1, phase2, psi_all: np.ndarray, E: float) -> dict:
    N = int(phase2.nmax)
    psi = np.asarray(psi_all[:N + 1], float)
    n_full = np.arange(2, N + 1, dtype=float)
    f = shell_test_function(E, n_full, int(phase1.L), int(phase2.L),
                            int(phase1.nmax), int(phase2.nmax))
    fN = float(f[-1])
    dA = f[:-1] - f[1:]
    n_int = np.arange(2, N, dtype=float)

    Eall = psi - np.arange(N + 1, dtype=float)
    main = float(N * fN + np.dot(n_int, dA))
    boundary = float(Eall[N] * fN)
    Eint = np.asarray(Eall[2:N], float)
    interior = float(np.dot(Eint, dA))
    error = boundary + interior
    abel_prime = main + error

    prime_delta = float(phase2.prime_phase(np.asarray([E]))[0]
                        - phase1.prime_phase(np.asarray([E]))[0])
    counter_delta = float(phase2.counter.phase(np.asarray([E]))[0]
                          - phase1.counter.phase(np.asarray([E]))[0])
    centered_direct = prime_delta - counter_delta
    smooth_discrete_residual = main - counter_delta
    centered_abel = smooth_discrete_residual + error

    cosine = corr_cos(Eint, dA)
    cs_bound = abs(boundary) + safe_norm(Eint) * safe_norm(dA)
    return {
        "prime_delta": prime_delta,
        "counter_delta": counter_delta,
        "centered_direct": centered_direct,
        "abel_main": main,
        "pnt_error_boundary": boundary,
        "pnt_error_interior": interior,
        "pnt_error_total": error,
        "smooth_discrete_minus_counter": smooth_discrete_residual,
        "abel_prime": abel_prime,
        "centered_abel": centered_abel,
        "prime_abel_rel_residual": relerr(abel_prime, prime_delta),
        "centered_abel_rel_residual": relerr(centered_abel, centered_direct),
        "pnt_error_cosine": cosine,
        "pnt_error_cosine_abs": abs(cosine) if math.isfinite(cosine) else float("nan"),
        "pnt_error_cs_over_actual": cs_bound / max(abs(error), EPS),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="ROT-RH v131 log-L de-aliasing / signed shell-flow audit"
    )
    ap.add_argument("--v102-module", default="rot_rh_pnt_finite_part_full_pipeline_v102_1")
    ap.add_argument("--base-module", default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit")
    ap.add_argument("--L-start", type=int, default=4000)
    ap.add_argument("--L-end", type=int, default=128000)
    ap.add_argument("--steps-per-doubling", type=int, default=2)
    ap.add_argument("--k-values", default="32,64,128,256")
    ap.add_argument("--abel-k-values", default="32,64,128,256")
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--counter-qcheck", type=int, default=16384)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--derivative-samples", type=int, default=65)

    ap.add_argument("--fit-q-min", type=float, default=0.0)
    ap.add_argument("--fit-q-max", type=float, default=4.0)
    ap.add_argument("--fit-q-points", type=int, default=401)
    ap.add_argument("--conditional-q-gate", type=float, default=0.10)
    ap.add_argument("--osc-r2-gate", type=float, default=0.55)
    ap.add_argument("--delta-aic-gate", type=float, default=2.0)
    ap.add_argument("--late-rms-ratio-gate", type=float, default=0.90)
    ap.add_argument("--min-sign-changes", type=int, default=2)

    ap.add_argument("--root-residual-tol", type=float, default=1e-8)
    ap.add_argument("--quadrature-tol", type=float, default=5e-6)
    ap.add_argument("--identity-rel-tol", type=float, default=1e-8)
    ap.add_argument("--secant-abs-tol", type=float, default=5e-8)
    ap.add_argument("--mvt-ratio-tol", type=float, default=1.01)
    ap.add_argument("--prefix", default="rot_rh_logL_dealias_signed_shell_flow_v131")
    args = ap.parse_args()

    ks = sorted(set(parse_ints(args.k_values)))
    abel_ks = set(parse_ints(args.abel_k_values))
    if not ks or min(ks) < 1:
        raise ValueError("--k-values must contain positive integers")
    if not abel_ks.issubset(set(ks)):
        raise ValueError("--abel-k-values must be a subset of --k-values")
    if args.derivative_samples < 3:
        raise ValueError("--derivative-samples must be >=3")
    if args.fit_q_points < 3:
        raise ValueError("--fit-q-points must be >=3")

    Ls = geometric_L_ladder(args.L_start, args.L_end, args.steps_per_doubling)
    if len(Ls) < 7:
        raise ValueError("Need at least 7 L points for signed oscillation diagnostics")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    code_path = Path(__file__).resolve()
    code_sha = sha256_file(code_path)

    print("=" * 174)
    print("ROT-RH v131 — LOG-L DE-ALIASING / SIGNED SHELL-FLOW AUDIT")
    print("=" * 174)
    print("L ladder                        :", Ls)
    print("steps per doubling              :", args.steps_per_doubling)
    print("fixed k values                  :", ks)
    print("Abel/PNT k values               :", sorted(abel_ks))
    print("maximum support depth           :", max(ks))
    print("tail factor                     :", args.tail_factor)
    print("counter q / qcheck              :", args.counter_q, "/", args.counter_qcheck)
    print("signed model q grid             :", f"[{args.fit_q_min},{args.fit_q_max}] / {args.fit_q_points}")
    print("conditional q gate              :", args.conditional_q_gate)
    print("oscillator R2 gate              :", args.osc_r2_gate)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 174)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    # 1. Build phases/supports on the finer log-L mesh.
    print("[1] Build zero-free phases/supports on de-aliased log-L ladder", flush=True)
    phases, supports = {}, {}
    max_depth = max(ks)
    for L in Ls:
        phase = build_phase_exact_tail(v102, base, L, args.tail_factor, args.counter_q)
        phases[L] = phase
        support = v102.ordered_support(
            phase, depth=max_depth, scan_points=args.scan_points,
            qcheck=args.counter_qcheck,
        )
        supports[L] = support
        print(
            "  L=%-8d terms=%-8d nmax=%-9d rootRes=%.2e qphase=%.2e qder=%.2e Emax=%.6f"
            % (
                L, len(phase.logs), phase.nmax,
                float(np.max(support.residuals)),
                float(support.quadrature_phase_rel_l2),
                float(support.quadrature_deriv_rel_l2),
                float(support.roots[-1]),
            ), flush=True,
        )

    max_root_resid = max(float(np.max(supports[L].residuals)) for L in Ls)
    max_qphase = max(float(supports[L].quadrature_phase_rel_l2) for L in Ls)
    max_qder = max(float(supports[L].quadrature_deriv_rel_l2) for L in Ls)

    # Build psi once through the largest phase cutoff.
    maxN = max(int(phases[L].nmax) for L in Ls)
    print(f"[2] Build one dense psi table through N={maxN}", flush=True)
    _, psi_all = dense_mangoldt(base, maxN)

    # 2. Fine signed root flow + exact identities.
    print("[3] Fine log-L signed root response", flush=True)
    point_rows = []
    for j, (L1, L2) in enumerate(zip(Ls[:-1], Ls[1:])):
        p1, p2 = phases[L1], phases[L2]
        s1, s2 = supports[L1], supports[L2]
        ratio = float(L2) / float(L1)
        print(f"  transition {j+1:02d}/{len(Ls)-1}: {L1}->{L2} ratio={ratio:.8f}")

        for k in ks:
            a = float(s1.roots[k - 1])
            b = float(s2.roots[k - 1])
            dE = b - a
            F1a = float(p1.F(np.asarray([a]))[0])
            F2a = float(p2.F(np.asarray([a]))[0])
            F2b = float(p2.F(np.asarray([b]))[0])
            dF = F2a - F1a

            if abs(dE) > 1e-15:
                Dstar = (F2b - F2a) / dE
                secant_pred = -dF / Dstar if abs(Dstar) > EPS else float("nan")
            else:
                Dstar = float(p2.Fprime(np.asarray([a]))[0])
                secant_pred = -dF / Dstar if abs(Dstar) > EPS else float("nan")

            lo, hi = min(a, b), max(a, b)
            egrid = np.asarray([a], float) if hi - lo < 1e-14 else np.linspace(lo, hi, args.derivative_samples)
            dvals = np.asarray(p2.Fprime(egrid), float)
            deriv_floor = float(np.min(np.abs(dvals)))
            deriv_sign = bool(np.all(dvals > 0) or np.all(dvals < 0))
            response = abs(dF) / max(deriv_floor, EPS)
            actual_over_response = abs(dE) / max(response, EPS)

            prime_delta = float(p2.prime_phase(np.asarray([a]))[0] - p1.prime_phase(np.asarray([a]))[0])
            counter_delta = float(p2.counter.phase(np.asarray([a]))[0] - p1.counter.phase(np.asarray([a]))[0])
            dF_centered = -(prime_delta - counter_delta) / math.pi
            fp_rel = relerr(dF, dF_centered)

            if k in abel_ks:
                ab = abel_shell_geometry(p1, p2, psi_all, a)
            else:
                ab = {
                    "prime_delta": prime_delta,
                    "counter_delta": counter_delta,
                    "centered_direct": prime_delta - counter_delta,
                    "abel_main": float("nan"),
                    "pnt_error_boundary": float("nan"),
                    "pnt_error_interior": float("nan"),
                    "pnt_error_total": float("nan"),
                    "smooth_discrete_minus_counter": float("nan"),
                    "abel_prime": float("nan"),
                    "centered_abel": float("nan"),
                    "prime_abel_rel_residual": float("nan"),
                    "centered_abel_rel_residual": float("nan"),
                    "pnt_error_cosine": float("nan"),
                    "pnt_error_cosine_abs": float("nan"),
                    "pnt_error_cs_over_actual": float("nan"),
                }

            secant_abs = abs(dE * Dstar + dF)
            row = {
                "step_index": int(j),
                "L_low": int(L1),
                "L_high": int(L2),
                "L_mid_geometric": math.sqrt(float(L1) * float(L2)),
                "ratio": ratio,
                "k": int(k),
                "E_low": a,
                "E_high": b,
                "E_mid": 0.5 * (a + b),
                "root_step_signed": dE,
                "root_step_abs": abs(dE),
                "deltaF_at_old_root": dF,
                "deltaF_from_centered": dF_centered,
                "finite_part_identity_rel": fp_rel,
                "secant_Dstar": Dstar,
                "secant_predicted_step": secant_pred,
                "secant_equation_abs": secant_abs,
                "sampled_derivative_floor": deriv_floor,
                "sampled_derivative_sign_consistent": deriv_sign,
                "sampled_response_majorant": response,
                "actual_over_sampled_response": actual_over_response,
                "phase_advance_cycles_local": (0.5 * (a + b)) * math.log(ratio) / (2.0 * math.pi),
                **ab,
            }
            point_rows.append(row)
            cosv = ab["pnt_error_cosine_abs"]
            cos_text = "NA" if not math.isfinite(cosv) else f"{cosv:.2e}"
            print(
                "    k=%-4d dE=%+.3e R=%.3e act/R=%.4f phaseAdv=%.4f cyc |cos|=%s"
                % (k, dE, response, actual_over_response, row["phase_advance_cycles_local"] % 1.0, cos_text)
            )

    # 3. Per-k signed-flow / de-alias analysis.
    print("[4] Fixed-k de-alias / signed oscillatory fits", flush=True)
    k_rows = []
    block_rows = []

    for k in ks:
        rows = sorted([r for r in point_rows if int(r["k"]) == k], key=lambda r: int(r["step_index"]))
        dE = np.asarray([r["root_step_signed"] for r in rows], float)
        Lmid = np.asarray([r["L_mid_geometric"] for r in rows], float)
        roots = np.asarray([float(supports[L].roots[k - 1]) for L in Ls], float)
        Eref = float(np.median(roots))

        osc = fit_logL_oscillator(
            Lmid, dE, Eref,
            args.fit_q_min, args.fit_q_max, args.fit_q_points,
        )

        # Early/late signed-amplitude diagnostic (RMS of fine increments).
        half = max(2, len(dE) // 2)
        early_rms = float(np.sqrt(np.mean(dE[:half] ** 2)))
        late_rms = float(np.sqrt(np.mean(dE[-half:] ** 2)))
        late_over_early = late_rms / max(early_rms, EPS)

        abs_var = float(np.sum(np.abs(dE)))
        net = float(abs(np.sum(dE)))
        net_cancel_ratio = net / max(abs_var, EPS)
        nsign = sign_changes(dE)

        dyadic_cycles = Eref * math.log(2.0) / (2.0 * math.pi)
        fine_cycles = dyadic_cycles / float(args.steps_per_doubling)
        num, den, raterr = nearest_low_order_rational(dyadic_cycles, 8)
        fine_dist_integer = min(fine_cycles % 1.0, 1.0 - (fine_cycles % 1.0))

        # Sum fine increments inside each full-doubling block.  This must telescope
        # to the coarse root difference; the ratio measures hidden cancellation.
        block_cancels = []
        s = int(args.steps_per_doubling)
        for b0 in range(0, len(dE) - s + 1, s):
            chunk = dE[b0:b0 + s]
            signed = float(np.sum(chunk))
            av = float(np.sum(np.abs(chunk)))
            cr = abs(signed) / max(av, EPS)
            block_cancels.append(cr)
            block_rows.append({
                "k": int(k),
                "block_index": int(b0 // s),
                "L_start": int(rows[b0]["L_low"]),
                "L_end": int(rows[b0 + s - 1]["L_high"]),
                "fine_steps": int(s),
                "signed_root_change": signed,
                "absolute_variation": av,
                "within_doubling_cancellation_ratio": cr,
            })

        median_block_cancel = float(np.median(block_cancels)) if block_cancels else float("nan")
        min_block_cancel = float(np.min(block_cancels)) if block_cancels else float("nan")

        cosvals = np.asarray([r["pnt_error_cosine_abs"] for r in rows], float)
        finite_cos = cosvals[np.isfinite(cosvals)]
        median_cos = float(np.median(finite_cos)) if len(finite_cos) else float("nan")

        kr = {
            "k": int(k),
            "root_count": int(len(roots)),
            "transition_count": int(len(dE)),
            "E_ref": Eref,
            "E_first": float(roots[0]),
            "E_last": float(roots[-1]),
            "net_root_drift_signed": float(roots[-1] - roots[0]),
            "total_absolute_root_variation": abs_var,
            "net_over_absolute_variation": net_cancel_ratio,
            "sign_changes": int(nsign),
            "early_increment_rms": early_rms,
            "late_increment_rms": late_rms,
            "late_over_early_rms": late_over_early,
            "dyadic_phase_advance_cycles": dyadic_cycles,
            "dyadic_phase_fraction": dyadic_cycles % 1.0,
            "dyadic_nearest_rational_num": num,
            "dyadic_nearest_rational_den": den,
            "dyadic_nearest_rational_abs_error": raterr,
            "fine_phase_advance_cycles": fine_cycles,
            "fine_phase_fraction": fine_cycles % 1.0,
            "fine_phase_distance_to_integer_cycles": fine_dist_integer,
            "best_q_log_envelope": float(osc["q"]),
            "oscillator_r2": float(osc["r2"]),
            "oscillator_delta_aic_vs_q0": float(osc["delta_aic_vs_q0"]),
            "oscillator_amplitude_constant": float(osc["amplitude_constant"]),
            "oscillator_phase_offset": float(osc["phase_offset"]),
            "q0_r2": float(osc["null_r2_q0"]),
            "median_within_doubling_cancellation_ratio": median_block_cancel,
            "minimum_within_doubling_cancellation_ratio": min_block_cancel,
            "median_abs_pnt_error_cosine": median_cos,
            "max_actual_over_sampled_response": float(max(r["actual_over_sampled_response"] for r in rows)),
            "min_sampled_derivative_floor": float(min(r["sampled_derivative_floor"] for r in rows)),
            "all_derivative_sign_consistent": bool(all(r["sampled_derivative_sign_consistent"] for r in rows)),
            "max_finite_part_identity_rel": float(max(r["finite_part_identity_rel"] for r in rows)),
            "max_secant_equation_abs": float(max(r["secant_equation_abs"] for r in rows)),
        }

        kr["q_positive_gate"] = bool(kr["best_q_log_envelope"] >= args.conditional_q_gate)
        kr["oscillator_r2_gate"] = bool(kr["oscillator_r2"] >= args.osc_r2_gate)
        kr["delta_aic_gate"] = bool(kr["oscillator_delta_aic_vs_q0"] >= args.delta_aic_gate)
        kr["amplitude_decay_gate"] = bool(kr["late_over_early_rms"] <= args.late_rms_ratio_gate)
        kr["oscillatory_sign_gate"] = bool(kr["sign_changes"] >= args.min_sign_changes)
        # AIC is supportive, not mandatory: with short sequences the q scan can
        # improve amplitude decay without a large information-criterion margin.
        kr["conditional_signed_convergence_candidate"] = bool(
            kr["q_positive_gate"]
            and kr["oscillator_r2_gate"]
            and kr["amplitude_decay_gate"]
            and kr["oscillatory_sign_gate"]
            and kr["fine_phase_distance_to_integer_cycles"] > 1e-3
        )
        k_rows.append(kr)

        print(
            "  k=%-4d Eref=%.6f dyadicFrac=%.4f~%d/%d err=%.3g fineFrac=%.4f "
            "q=%+.3f R2=%.3f dAIC=%+.2f late/early=%.3f signs=%d blockCancelMed=%.3f candidate=%s"
            % (
                k, Eref, kr["dyadic_phase_fraction"], num, den, raterr,
                kr["fine_phase_fraction"], kr["best_q_log_envelope"],
                kr["oscillator_r2"], kr["oscillator_delta_aic_vs_q0"],
                kr["late_over_early_rms"], kr["sign_changes"],
                kr["median_within_doubling_cancellation_ratio"],
                str(kr["conditional_signed_convergence_candidate"]),
            )
        )

    # 4. Global identity/support gates.
    abel_rows = [r for r in point_rows if math.isfinite(float(r["prime_abel_rel_residual"]))]
    max_prime_abel = max((float(r["prime_abel_rel_residual"]) for r in abel_rows), default=0.0)
    max_centered_abel = max((float(r["centered_abel_rel_residual"]) for r in abel_rows), default=0.0)
    max_fp = max(float(r["finite_part_identity_rel"]) for r in point_rows)
    max_secant_abs = max(float(r["secant_equation_abs"]) for r in point_rows)
    min_deriv = min(float(r["sampled_derivative_floor"]) for r in point_rows)
    max_actual_R = max(float(r["actual_over_sampled_response"]) for r in point_rows)
    all_deriv_sign = all(bool(r["sampled_derivative_sign_consistent"]) for r in point_rows)

    numerical_gates = {
        "root_residual": max_root_resid <= args.root_residual_tol,
        "counterterm_quadrature_phase": max_qphase <= args.quadrature_tol,
        "counterterm_quadrature_derivative": max_qder <= args.quadrature_tol,
        "finite_part_identity": max_fp <= args.identity_rel_tol,
        "secant_equation_absolute": max_secant_abs <= args.secant_abs_tol,
        "prime_abel_identity": max_prime_abel <= args.identity_rel_tol,
        "centered_abel_identity": max_centered_abel <= args.identity_rel_tol,
        "sampled_derivative_floor_positive": min_deriv > 0.0,
        "sampled_derivative_sign_consistent": all_deriv_sign,
        "actual_root_step_below_sampled_response": max_actual_R <= args.mvt_ratio_tol,
    }

    candidate_count = sum(bool(r["conditional_signed_convergence_candidate"]) for r in k_rows)
    all_candidates = candidate_count == len(k_rows)
    majority_candidates = candidate_count >= max(1, math.ceil(0.75 * len(k_rows)))
    all_q_positive = all(bool(r["q_positive_gate"]) for r in k_rows)
    all_amplitude_decay = all(bool(r["amplitude_decay_gate"]) for r in k_rows)

    if not all(numerical_gates.values()):
        verdict = "FAIL_V131_NUMERICAL_IDENTITY_OR_SUPPORT_INVALID"
        mechanism = "NUMERICAL_OR_EXACT_IDENTITY_GATE_FAILED__DO_NOT_INTERPRET_SIGNED_FLOW"
    elif all_candidates:
        verdict = "PASS_V131_DEALIASED_SIGNED_LOG_L_CONVERGENCE_CANDIDATE"
        mechanism = (
            "FINE_LOG_L_FLOW_SUPPORTS_DECAYING_ARITHMETIC_OSCILLATION_ON_ALL_SELECTED_K__"
            "DIRICHLET_SUMMATION_BY_PARTS_BOUND_IS_NEXT_THEOREM_TARGET"
        )
    elif majority_candidates and all_q_positive:
        verdict = "MIXED_V131_SIGNED_OSCILLATORY_CONVERGENCE_SUPPORTED_ON_MOST_BRANCHES"
        mechanism = "DEALIASING_REVEALS_DECAYING_SIGNED_FLOW_BUT_UNIFORM_FIXED_K_CONTROL_REMAINS_OPEN"
    elif not all_amplitude_decay:
        verdict = "NO_GO_V131_DEALIASING_DOES_NOT_REVEAL_UNIFORM_DECAYING_SIGNED_AMPLITUDE"
        mechanism = "FINE_LOG_L_SAMPLING_RETains_NONDECAYING_BRANCH_AMPLITUDE"
    else:
        verdict = "NO_GO_V131_FIXED_FREQUENCY_SIGNED_MODEL_NOT_UNIFORMLY_SUPPORTED"
        mechanism = "SIGNED_FLOW_EXISTS_BUT_SIMPLE_E_LOG_L_DECAYING_OSCILLATOR_IS_INSUFFICIENT"

    point_path = Path(str(prefix) + "_POINTS.csv")
    k_path = Path(str(prefix) + "_K_SUMMARY.csv")
    block_path = Path(str(prefix) + "_DOUBLING_BLOCKS.csv")
    verdict_path = Path(str(prefix) + "_VERDICT.json")
    write_csv(point_path, point_rows)
    write_csv(k_path, k_rows)
    write_csv(block_path, block_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "code_sha256": code_sha,
        "verdict": verdict,
        "mechanism": mechanism,
        "RH_proof": False,
        "L_to_infinity_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "parameters": {
            "L_start": args.L_start,
            "L_end": args.L_end,
            "steps_per_doubling": args.steps_per_doubling,
            "L_list": Ls,
            "k_values": ks,
            "abel_k_values": sorted(abel_ks),
            "tail_factor": args.tail_factor,
            "counter_q": args.counter_q,
            "counter_qcheck": args.counter_qcheck,
            "fit_q_min": args.fit_q_min,
            "fit_q_max": args.fit_q_max,
            "fit_q_points": args.fit_q_points,
            "conditional_q_gate": args.conditional_q_gate,
            "osc_r2_gate": args.osc_r2_gate,
            "late_rms_ratio_gate": args.late_rms_ratio_gate,
        },
        "numerical_gates": numerical_gates,
        "scientific_summary": {
            "candidate_count": int(candidate_count),
            "selected_k_count": int(len(k_rows)),
            "all_conditional_signed_candidates": bool(all_candidates),
            "all_q_positive": bool(all_q_positive),
            "all_late_rms_decay": bool(all_amplitude_decay),
        },
        "global_metrics": {
            "max_root_residual": max_root_resid,
            "max_counterterm_qphase": max_qphase,
            "max_counterterm_qder": max_qder,
            "max_finite_part_identity_rel": max_fp,
            "max_secant_equation_abs": max_secant_abs,
            "max_prime_abel_rel_residual": max_prime_abel,
            "max_centered_abel_rel_residual": max_centered_abel,
            "minimum_sampled_derivative_floor": min_deriv,
            "maximum_actual_over_sampled_response": max_actual_R,
        },
        "k_summary": k_rows,
        "theorem_target_if_pass": (
            "For each fixed k, represent the root-located finite-part scale increment on a geometric L ladder as "
            "Delta E_{k,j}=A_k(j) exp(i omega_k j)+conjugate+r_{k,j}, with omega_k not 0 mod 2pi, "
            "A_k(j)->0 with controlled variation, and sum r_{k,j} convergent.  Abel/Dirichlet summation then gives "
            "signed Cauchy convergence of E_k(L_j) without requiring sum |Delta E_{k,j}|<infinity.  A later theorem "
            "must remove dependence on the chosen geometric ladder and prove regulator-independent convergence."
        ),
        "interpretation": (
            "v131 tests whether v130's non-monotone absolute dyadic shell response is caused by aliasing of a signed "
            "log-L oscillation.  It does not prove the oscillator ansatz, future amplitude decay, full continuous-L "
            "convergence, trace-norm convergence, the Fredholm-Xi identity, or RH."
        ),
        "outputs": {
            "points": str(point_path),
            "k_summary": str(k_path),
            "doubling_blocks": str(block_path),
            "verdict": str(verdict_path),
        },
    }
    verdict_path.write_text(json.dumps(json_safe(packet), indent=2), encoding="utf-8")

    print("\n" + "=" * 174)
    print("FINAL v131 VERDICT")
    print("=" * 174)
    print("verdict                         :", verdict)
    print("mechanism                       :", mechanism)
    print("conditional candidates          :", f"{candidate_count}/{len(k_rows)}")
    print("max root residual               :", f"{max_root_resid:.12e}")
    print("max counter qphase/qder         :", f"{max_qphase:.12e} / {max_qder:.12e}")
    print("max finite-part identity rel    :", f"{max_fp:.12e}")
    print("max secant equation abs         :", f"{max_secant_abs:.12e}")
    print("max prime Abel identity rel     :", f"{max_prime_abel:.12e}")
    print("max centered Abel identity rel  :", f"{max_centered_abel:.12e}")
    print("minimum derivative floor        :", f"{min_deriv:.12e}")
    print("max actual / sampled response   :", f"{max_actual_R:.12e}")
    print("RH proof                        : FALSE")
    print("L->infinity proof               : FALSE")
    print("verdict file                    :", verdict_path)
    print("=" * 174)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
