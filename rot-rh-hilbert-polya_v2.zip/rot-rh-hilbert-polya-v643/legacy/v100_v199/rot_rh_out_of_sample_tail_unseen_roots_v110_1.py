#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v110 — Out-of-Sample Arithmetic Tail vs Unseen Operator Roots
=====================================================================

RED-TEAM PURPOSE
----------------
The v102/v109 "full_em1" tail contains arithmetic continuum information.
Therefore comparing a 48-root prefix + that tail to the arithmetic resolvent
is not fully independent.

v110 breaks that loop.

For each finite L:
  1. build the zero-free finite-part phase;
  2. compute a DEEP selected spectrum, e.g. first 128 roots;
  3. at several shallower cutoffs N, construct the same arithmetic full_em1
     tail using ONLY endpoint E_N and the phase;
  4. predict the spectral block N<k<=M by

         Tail_pred(N->M) = T_full_em1(E_N) - T_full_em1(E_M);

  5. compare that prediction to the ACTUAL newly computed roots

         Tail_exact(N->M) = sum_{N<k<=M} E_k^(-2m).

This is a genuinely zero-free out-of-sample audit: roots beyond N are never
used in the tail formula at N.

It also tests block resolvents

    sum_{N<k<=M} 1/(E_k^2+a^2)

against the moment-series prediction from the arithmetic tail difference.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v110.1"
BUILD = "2026-08-17-out-of-sample-arithmetic-tail-unseen-roots-v110.1-json-fix"
EPS = 1e-30


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(x.real), "imag": float(x.imag)}
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    return x


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def exact_block_moments(roots, n0, n1, order):
    r = np.asarray(roots[n0:n1], float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def tail_components(v102, phase, base, E, order):
    W = v102.weyl_tail_moments(E, order)
    A = v102.arch_tail_moments(base, E, order)
    P = v102.prime_tail_moments(phase, E, order)
    C = v102.counterterm_tail_moments(phase.counter, E, order)
    AC = v102.pnt_ac_tail_moments(E, order)
    M = v102.midpoint_moments(E, order)
    B2 = v102.bernoulli_B2_moments(phase, E, order)

    if not np.all(np.isfinite(B2)):
        raise RuntimeError(f"Nonfinite B2 tail at E={E}")

    full = W + A + P + C + AC + M + B2
    return {
        "W": W,
        "A": A,
        "P": P,
        "C": C,
        "AC": AC,
        "M": M,
        "B2": B2,
        "full": full,
    }


def block_resolvent_exact(roots, n0, n1, a):
    r = np.asarray(roots[n0:n1], float)
    aa = complex(a)
    return complex(np.sum(1.0 / (r * r + aa * aa)))


def block_resolvent_from_moments(block_moments, a, order):
    b = np.asarray(block_moments, float)
    M = min(int(order), len(b))
    aa = complex(a)
    val = 0.0j
    p = 1.0 + 0.0j
    for q in range(M):
        val += p * float(b[q])
        p *= -(aa * aa)
    return val


def relerr(x, y):
    return abs(x - y) / max(abs(y), EPS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depths", default="48,64,96,128")
    ap.add_argument("--tail-moment-order", type=int, default=10)
    ap.add_argument("--report-moment-order", type=int, default=4)
    ap.add_argument("--a-probes", default="2,5,10")
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=384)
    ap.add_argument("--counter-qcheck", type=int, default=768)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument(
        "--prefix",
        default="rot_rh_out_of_sample_tail_unseen_roots_v110_1",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    depths = parse_ints(args.depths)
    aprobes = [complex(x, 0.0) for x in parse_floats(args.a_probes)]

    if len(depths) < 2 or not all(
        depths[i] < depths[i + 1] for i in range(len(depths) - 1)
    ):
        raise ValueError("depths must be strictly increasing, at least two.")

    max_depth = depths[-1]
    report_order = min(args.report_moment_order, args.tail_moment_order)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("=" * 158)
    print("ROT-RH v110.1 — OUT-OF-SAMPLE ARITHMETIC TAIL vs UNSEEN OPERATOR ROOTS")
    print("=" * 158)
    print("L ladder                        :", Ls)
    print("depth ladder                    :", depths)
    print("deep support                    :", max_depth)
    print("tail moment order               :", args.tail_moment_order)
    print("reported exact moment order     :", report_order)
    print("resolvent a probes              :", [a.real for a in aprobes])
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 158)

    block_rows = []
    moment_rows = []
    phase_rows = []

    for L in Ls:
        print(f"[L={L}] build phase and {max_depth} actual roots", flush=True)
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        support = v102.ordered_support(
            phase,
            depth=max_depth,
            scan_points=int(args.scan_points),
            qcheck=int(args.counter_qcheck),
        )
        roots = np.asarray(support.roots, float)

        print(
            f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
            f"maxres={np.max(support.residuals):.2e} "
            f"minF'roots={support.min_local_Fprime:+.3e} "
            f"qphase={support.quadrature_phase_rel_l2:.2e} "
            f"qder={support.quadrature_deriv_rel_l2:.2e}"
        )

        phase_rows.append({
            "L": L,
            "max_depth": max_depth,
            "E1": roots[0],
            "Emax": roots[-1],
            "max_root_residual": float(np.max(support.residuals)),
            "min_local_Fprime": support.min_local_Fprime,
            "qphase": support.quadrature_phase_rel_l2,
            "qder": support.quadrature_deriv_rel_l2,
        })

        tails = {}
        for N in depths:
            E = float(roots[N - 1])
            tails[N] = tail_components(
                v102, phase, base, E, args.tail_moment_order
            )

        print("  out-of-sample blocks:", flush=True)
        for N0, N1 in zip(depths[:-1], depths[1:]):
            exact = exact_block_moments(
                roots, N0, N1, args.tail_moment_order
            )
            pred = tails[N0]["full"] - tails[N1]["full"]

            # Also expose how much the simple continuum-only pieces predict.
            pred_noB2 = (
                tails[N0]["W"]
                + tails[N0]["A"]
                + tails[N0]["P"]
                + tails[N0]["C"]
                + tails[N0]["AC"]
                + tails[N0]["M"]
                - tails[N1]["W"]
                - tails[N1]["A"]
                - tails[N1]["P"]
                - tails[N1]["C"]
                - tails[N1]["AC"]
                - tails[N1]["M"]
            )

            moment_rel = float(
                np.linalg.norm(pred[:report_order] - exact[:report_order])
                / max(np.linalg.norm(exact[:report_order]), EPS)
            )
            s1_rel = relerr(pred[0], exact[0])
            s1_abs = abs(pred[0] - exact[0])
            s1_noB2_rel = relerr(pred_noB2[0], exact[0])

            row = {
                "L": L,
                "N_from": N0,
                "N_to": N1,
                "E_from": roots[N0 - 1],
                "E_to": roots[N1 - 1],
                "block_size": N1 - N0,
                "moment_rel_l2_first_reported": moment_rel,
                "S1_exact": exact[0],
                "S1_pred": pred[0],
                "S1_abs_error": s1_abs,
                "S1_relative_error": s1_rel,
                "S1_relative_error_noB2": s1_noB2_rel,
            }
            for m in range(1, report_order + 1):
                row[f"S{m}_exact"] = exact[m - 1]
                row[f"S{m}_pred"] = pred[m - 1]
                row[f"S{m}_relerr"] = relerr(pred[m - 1], exact[m - 1])

            # Independent block-resolvent test.
            for a in aprobes:
                rex = block_resolvent_exact(roots, N0, N1, a)
                rpr = block_resolvent_from_moments(
                    pred, a, args.tail_moment_order
                )
                rpr8 = block_resolvent_from_moments(
                    pred, a, max(1, args.tail_moment_order - 2)
                )
                row[f"R_a{a.real:g}_exact_real"] = rex.real
                row[f"R_a{a.real:g}_pred_real"] = rpr.real
                row[f"R_a{a.real:g}_relative_error"] = relerr(rpr, rex)
                row[f"R_a{a.real:g}_order_stability"] = relerr(rpr, rpr8)

            block_rows.append(row)

            for m in range(1, report_order + 1):
                moment_rows.append({
                    "L": L,
                    "N_from": N0,
                    "N_to": N1,
                    "m": m,
                    "exact": exact[m - 1],
                    "predicted": pred[m - 1],
                    "absolute_error": abs(pred[m - 1] - exact[m - 1]),
                    "relative_error": relerr(pred[m - 1], exact[m - 1]),
                })

            print(
                f"    {N0}->{N1}: "
                f"S1 rel={s1_rel:.3e} "
                f"mom{report_order} relL2={moment_rel:.3e} "
                f"R(a=2) rel={row['R_a2_relative_error']:.3e} "
                f"B2 gain={s1_noB2_rel/max(s1_rel,EPS):.2f}x"
            )

    # Summaries.
    finalL = Ls[-1]
    final_rows = [r for r in block_rows if r["L"] == finalL]
    max_s1_rel = max(r["S1_relative_error"] for r in final_rows)
    max_mom_rel = max(
        r["moment_rel_l2_first_reported"] for r in final_rows
    )
    max_r_rel = max(
        r[f"R_a{a.real:g}_relative_error"]
        for r in final_rows
        for a in aprobes
    )
    max_order_instability = max(
        r[f"R_a{a.real:g}_order_stability"]
        for r in final_rows
        for a in aprobes
    )

    gates = {
        "deep_roots_numerically_valid":
            all(r["max_root_residual"] < 1e-8 for r in phase_rows),
        "counterterm_quadrature_stable":
            all(
                r["qphase"] < 5e-6 and r["qder"] < 5e-6
                for r in phase_rows
            ),
        "unseen_block_S1_pred_below_1e4":
            max_s1_rel < 1e-4,
        "unseen_block_moments_below_1e3":
            max_mom_rel < 1e-3,
        "unseen_block_resolvent_below_1e4":
            max_r_rel < 1e-4,
        "block_resolvent_tail_order_stable":
            max_order_instability < 1e-8,
    }

    if all(gates.values()):
        verdict = (
            "PASS_V110_ARITHMETIC_TAIL_PREDICTS_UNSEEN_OPERATOR_ROOT_BLOCKS__"
            "TAIL_CIRCULARITY_RISK_SUBSTANTIALLY_REDUCED"
        )
    elif (
        gates["deep_roots_numerically_valid"]
        and gates["counterterm_quadrature_stable"]
    ):
        verdict = (
            "PARTIAL_V110_ARITHMETIC_TAIL_DOES_NOT_ACCURATELY_PREDICT_UNSEEN_BLOCKS"
        )
    else:
        verdict = "FAIL_V110_DEEP_SUPPORT_OR_QUADRATURE_INVALID"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)
    write_csv(Path(str(prefix) + "_MOMENTS.csv"), moment_rows)
    write_csv(Path(str(prefix) + "_PHASE.csv"), phase_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "gates": gates,
        "final_L": finalL,
        "final_max_unseen_block_S1_relative_error": max_s1_rel,
        "final_max_unseen_block_moment_relative_L2": max_mom_rel,
        "final_max_unseen_block_resolvent_relative_error": max_r_rel,
        "final_max_resolvent_order_instability": max_order_instability,
        "interpretation": (
            "The full_em1 arithmetic tail is tested against operator roots "
            "that were not used in the shallower cutoff prediction. Passing "
            "this audit makes the v105-v109 resolvent agreement materially "
            "less circular, but does not prove the infinite-tail theorem."
        ),
    }
    verdict_path = Path(str(prefix) + "_VERDICT.json")
    verdict_path.write_text(json.dumps(json_safe(packet), indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("FINAL v110 VERDICT")
    print("=" * 158)
    print("verdict                              :", verdict)
    print("final max unseen-block S1 rel error  :", f"{max_s1_rel:.12e}")
    print("final max moment rel-L2              :", f"{max_mom_rel:.12e}")
    print("final max block-resolvent rel error  :", f"{max_r_rel:.12e}")
    print("final max resolvent order instability:", f"{max_order_instability:.12e}")
    print("gates                                :", gates)
    print("Xi used                              : FALSE")
    print("zeta used                            : FALSE")
    print("known zeros used                     : FALSE")
    print("RH proof                             : FALSE")
    print("verdict file                         :", verdict_path)
    print("=" * 158)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
