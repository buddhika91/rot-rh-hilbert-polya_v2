#!/usr/bin/env python3
"""
ROT-RH v148 — ROLLING HELD-OUT ALL-MODE CAUCHY MODULUS AUDIT

ZERO-COST postprocessor.
No phase builds, root solving, prime sums, Xi, zeta, or known-zero data.

Why v148
--------
v147 found an attractive held-out exponent alpha=0.88, but its mode gate
allowed 90% coverage.  For an actual finite-N Cauchy theorem, every mode
1..N must be controlled.

v148 therefore performs rolling-origin validation:

  holdout H=362039:
      train on all pairs with L_b < 362039
      test all pairs with L_b = 362039

  holdout H=512000:
      train on all pairs with L_b < 512000
      test all pairs with L_b = 512000

For each alpha, fit per-mode constants only on the earlier training data:

    |delta_k(L,M)| <= C_k |L^(-alpha)-M^(-alpha)|.

The safety factor is frozen BEFORE each holdout test.

An alpha passes only if, on EVERY rolling holdout:
  * 100% of modes satisfy the defect bound,
  * 100% of modes satisfy the induced root-shift bound,
  * 100% of modes satisfy the induced lambda bound,
  * all aggregate pair defect/trace bounds pass.

The largest passing alpha is reported as the strongest empirically
cross-validated common cutoff modulus.

Outputs
-------
<prefix>_ALPHA_SCAN.csv
<prefix>_HOLDOUT_DETAIL.csv
<prefix>_FAILURES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def modulus(L, M, alpha):
    return abs(float(L) ** (-alpha) - float(M) ** (-alpha))


def ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.inf


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--modes-csv",
        default="rot_rh_all_pairs_local_cutoff_v146_MODES.csv",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument(
        "--holdout-L-list",
        default="362039,512000",
    )

    ap.add_argument("--alpha-min", type=float, default=0.05)
    ap.add_argument("--alpha-max", type=float, default=1.50)
    ap.add_argument("--alpha-points", type=int, default=291)

    ap.add_argument(
        "--safety-factor",
        type=float,
        default=1.25,
        help="Frozen multiplier on training-derived per-mode constants.",
    )
    ap.add_argument(
        "--require-all-modes",
        action="store_true",
        default=True,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_rolling_allmode_modulus_v148",
    )

    args = ap.parse_args()

    df = pd.read_csv(args.modes_csv)
    df = df[df["k"] <= args.modes].copy()

    holdouts = sorted(set(csv_ints(args.holdout_L_list)))
    alphas = np.linspace(args.alpha_min, args.alpha_max, args.alpha_points)

    print("=" * 132)
    print("ROT-RH v148 — ROLLING HELD-OUT ALL-MODE CAUCHY MODULUS AUDIT")
    print("=" * 132)
    print("Xi / zeta / known zeros          : NONE")
    print(f"modes                             : 1..{args.modes}")
    print(f"rolling holdouts                  : {holdouts}")
    print(f"alpha grid                        : {args.alpha_min}..{args.alpha_max} ({args.alpha_points})")
    print(f"FROZEN safety factor              : {args.safety_factor}")
    print("required mode coverage            : 100%")
    print("=" * 132)

    scan_rows = []
    all_details = []
    all_failures = []

    for alpha in alphas:
        alpha_pass = True
        worst_defect_ratio = 0.0
        worst_root_ratio = 0.0
        worst_lambda_ratio = 0.0
        worst_pair_defect_ratio = 0.0
        worst_pair_trace_ratio = 0.0
        min_mode_coverage = 1.0
        min_root_coverage = 1.0
        min_lambda_coverage = 1.0
        minimum_required_sf = 0.0

        alpha_details = []

        for H in holdouts:
            train = df[df["L_b"] < H].copy()
            test = df[df["L_b"] == H].copy()

            if train.empty or test.empty:
                alpha_pass = False
                continue

            ks = sorted(test["k"].unique())
            constants = {}

            for k in ks:
                gt = train[train["k"] == k]
                if gt.empty:
                    continue

                raw_vals = []
                for _, r in gt.iterrows():
                    mod = modulus(r["L_a"], r["L_b"], alpha)
                    if mod > 0:
                        raw_vals.append(float(r["abs_old_root_defect"]) / mod)

                if not raw_vals:
                    continue

                C_raw = max(raw_vals)
                C = args.safety_factor * C_raw

                m_floor = float(gt["min_abs_Fprime_segment"].min())
                Emin = float(min(gt["E_a"].min(), gt["E_b"].min()))

                constants[int(k)] = dict(
                    C_raw=C_raw,
                    C=C,
                    m_floor=m_floor,
                    Emin=Emin,
                    root_C=(C / m_floor if m_floor > 0 else np.inf),
                    lambda_C=(
                        2.0 * C / (m_floor * Emin**3)
                        if m_floor > 0 and Emin > 0 else np.inf
                    ),
                )

            mode_pass = []
            root_pass = []
            lambda_pass = []
            hold_rows = []

            for _, r in test.iterrows():
                k = int(r["k"])
                if k not in constants:
                    mode_pass.append(False)
                    root_pass.append(False)
                    lambda_pass.append(False)
                    continue

                c = constants[k]
                mod = modulus(r["L_a"], r["L_b"], alpha)

                db = c["C"] * mod
                rb = c["root_C"] * mod
                lb = c["lambda_C"] * mod

                da = float(r["abs_old_root_defect"])
                ra = float(r["abs_root_shift"])
                Ea = float(r["E_a"])
                Eb = float(r["E_b"])
                la = abs(Eb**(-2) - Ea**(-2))

                dr = ratio(da, db)
                rr = ratio(ra, rb)
                lr = ratio(la, lb)

                mode_pass.append(dr <= 1.0)
                root_pass.append(rr <= 1.0)
                lambda_pass.append(lr <= 1.0)

                worst_defect_ratio = max(worst_defect_ratio, dr)
                worst_root_ratio = max(worst_root_ratio, rr)
                worst_lambda_ratio = max(worst_lambda_ratio, lr)

                minimum_required_sf = max(
                    minimum_required_sf,
                    args.safety_factor * dr,
                    args.safety_factor * rr,
                    args.safety_factor * lr,
                )

                row = dict(
                    alpha=float(alpha),
                    holdout_L=H,
                    L_a=int(r["L_a"]),
                    L_b=int(r["L_b"]),
                    k=k,
                    defect_actual=da,
                    defect_bound=db,
                    defect_ratio=dr,
                    root_actual=ra,
                    root_bound=rb,
                    root_ratio=rr,
                    lambda_actual=la,
                    lambda_bound=lb,
                    lambda_ratio=lr,
                    defect_pass=int(dr <= 1.0),
                    root_pass=int(rr <= 1.0),
                    lambda_pass=int(lr <= 1.0),
                )
                hold_rows.append(row)

                if dr > 1.0 or rr > 1.0 or lr > 1.0:
                    all_failures.append(row.copy())

            mcov = float(np.mean(mode_pass)) if mode_pass else 0.0
            rcov = float(np.mean(root_pass)) if root_pass else 0.0
            lcov = float(np.mean(lambda_pass)) if lambda_pass else 0.0

            min_mode_coverage = min(min_mode_coverage, mcov)
            min_root_coverage = min(min_root_coverage, rcov)
            min_lambda_coverage = min(min_lambda_coverage, lcov)

            # Aggregate every held-out pair ending at H.
            held_pairs = sorted(set(
                (int(a), int(b))
                for a, b in zip(test["L_a"], test["L_b"])
            ))

            pair_pass = True

            for La, Lb in held_pairs:
                rows = [x for x in hold_rows if x["L_a"] == La and x["L_b"] == Lb]
                if not rows:
                    pair_pass = False
                    continue

                d_actual = sum(x["defect_actual"] for x in rows)
                d_bound = sum(x["defect_bound"] for x in rows)
                t_actual = sum(x["lambda_actual"] for x in rows)
                t_bound = sum(x["lambda_bound"] for x in rows)

                d_ratio = ratio(d_actual, d_bound)
                t_ratio = ratio(t_actual, t_bound)

                worst_pair_defect_ratio = max(worst_pair_defect_ratio, d_ratio)
                worst_pair_trace_ratio = max(worst_pair_trace_ratio, t_ratio)

                minimum_required_sf = max(
                    minimum_required_sf,
                    args.safety_factor * d_ratio,
                    args.safety_factor * t_ratio,
                )

                if d_ratio > 1.0 or t_ratio > 1.0:
                    pair_pass = False

            holdout_pass = (
                mcov == 1.0
                and rcov == 1.0
                and lcov == 1.0
                and pair_pass
            )

            if not holdout_pass:
                alpha_pass = False

            alpha_details.extend(hold_rows)

        scan_rows.append(dict(
            alpha=float(alpha),
            pass_all_holdouts=int(alpha_pass),
            min_defect_mode_coverage=min_mode_coverage,
            min_root_mode_coverage=min_root_coverage,
            min_lambda_mode_coverage=min_lambda_coverage,
            worst_defect_ratio=worst_defect_ratio,
            worst_root_ratio=worst_root_ratio,
            worst_lambda_ratio=worst_lambda_ratio,
            worst_pair_defect_ratio=worst_pair_defect_ratio,
            worst_pair_trace_ratio=worst_pair_trace_ratio,
            minimum_required_safety_factor=minimum_required_sf,
        ))

        if alpha_pass:
            all_details.extend(alpha_details)

    scan = pd.DataFrame(scan_rows)
    scan.to_csv(args.prefix + "_ALPHA_SCAN.csv", index=False)

    passed = scan[scan["pass_all_holdouts"] == 1]

    if not passed.empty:
        selected = passed.sort_values("alpha").iloc[-1]
        verdict = "ROLLING_ALL_MODE_POWER_MODULUS_SUPPORTED"
    else:
        selected = scan.sort_values(
            ["minimum_required_safety_factor", "alpha"],
            ascending=[True, False],
        ).iloc[0]
        verdict = "ROLLING_ALL_MODE_POWER_MODULUS_UNRESOLVED"

    alpha_star = float(selected["alpha"])

    # Recompute and save ONLY selected-alpha holdout details.
    selected_details = []
    selected_failures = []

    for H in holdouts:
        train = df[df["L_b"] < H].copy()
        test = df[df["L_b"] == H].copy()

        constants = {}
        for k in sorted(test["k"].unique()):
            gt = train[train["k"] == k]
            vals = []
            for _, r in gt.iterrows():
                mod = modulus(r["L_a"], r["L_b"], alpha_star)
                if mod > 0:
                    vals.append(float(r["abs_old_root_defect"]) / mod)

            if not vals:
                continue

            C_raw = max(vals)
            C = args.safety_factor * C_raw
            m_floor = float(gt["min_abs_Fprime_segment"].min())
            Emin = float(min(gt["E_a"].min(), gt["E_b"].min()))

            constants[int(k)] = dict(
                C_raw=C_raw,
                C=C,
                root_C=(C/m_floor if m_floor > 0 else np.inf),
                lambda_C=(
                    2*C/(m_floor*Emin**3)
                    if m_floor > 0 and Emin > 0 else np.inf
                ),
            )

        for _, r in test.iterrows():
            k = int(r["k"])
            if k not in constants:
                continue

            c = constants[k]
            mod = modulus(r["L_a"], r["L_b"], alpha_star)

            db = c["C"] * mod
            rb = c["root_C"] * mod
            lb = c["lambda_C"] * mod

            da = float(r["abs_old_root_defect"])
            ra = float(r["abs_root_shift"])
            Ea = float(r["E_a"])
            Eb = float(r["E_b"])
            la = abs(Eb**(-2)-Ea**(-2))

            row = dict(
                alpha=alpha_star,
                holdout_L=H,
                L_a=int(r["L_a"]),
                L_b=int(r["L_b"]),
                k=k,
                defect_ratio=ratio(da, db),
                root_ratio=ratio(ra, rb),
                lambda_ratio=ratio(la, lb),
            )
            selected_details.append(row)

            if (
                row["defect_ratio"] > 1.0
                or row["root_ratio"] > 1.0
                or row["lambda_ratio"] > 1.0
            ):
                selected_failures.append(row)

    pd.DataFrame(selected_details).to_csv(
        args.prefix + "_HOLDOUT_DETAIL.csv", index=False
    )
    pd.DataFrame(selected_failures).to_csv(
        args.prefix + "_FAILURES.csv", index=False
    )

    summary = dict(
        version=148,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        rolling_holdouts=holdouts,
        safety_factor=args.safety_factor,
        selected_alpha=alpha_star,
        selected_metrics={
            k: (float(v) if isinstance(v, (float, np.floating)) else int(v))
            for k, v in selected.to_dict().items()
        },
        selected_failure_count=len(selected_failures),
        verdict=verdict,
        interpretation=(
            "A passing alpha controls every tested mode, root shift, and lambda "
            "difference at every rolling held-out endpoint using constants fit only "
            "to earlier cutoff data."
        ),
        proof_gap=(
            "Cross-validation is still numerical evidence. The analytic theorem must "
            "derive a uniform modulus in L,M directly from the cutoff-difference kernel."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print()
    print("Selected rolling all-mode modulus")
    print("-" * 132)
    print(f"alpha                              : {alpha_star:.9f}")
    print(f"frozen safety factor               : {args.safety_factor:.6f}")
    print(f"minimum defect-mode coverage       : {selected['min_defect_mode_coverage']:.3f}")
    print(f"minimum root-mode coverage         : {selected['min_root_mode_coverage']:.3f}")
    print(f"minimum lambda-mode coverage       : {selected['min_lambda_mode_coverage']:.3f}")
    print(f"worst defect ratio                 : {selected['worst_defect_ratio']:.6f}")
    print(f"worst root ratio                   : {selected['worst_root_ratio']:.6f}")
    print(f"worst lambda ratio                 : {selected['worst_lambda_ratio']:.6f}")
    print(f"worst pair defect ratio            : {selected['worst_pair_defect_ratio']:.6f}")
    print(f"worst pair trace ratio             : {selected['worst_pair_trace_ratio']:.6f}")
    print(f"minimum required safety factor     : {selected['minimum_required_safety_factor']:.6f}")
    print(f"selected-alpha failures            : {len(selected_failures)}")
    if selected_failures:
        print("failing (holdout,k) pairs:")
        for r in selected_failures[:20]:
            print(
                f"  H={r['holdout_L']} k={r['k']:2d} "
                f"def={r['defect_ratio']:.3f} "
                f"root={r['root_ratio']:.3f} "
                f"lambda={r['lambda_ratio']:.3f}"
            )

    print()
    print("=" * 132)
    print(f"VERDICT                            : {verdict}")
    print("=" * 132)
    print("A full cutoff-independence theorem needs 100% mode control, so this")
    print("rolling all-mode result is the appropriate empirical modulus to carry")
    print("forward into the analytic cutoff-difference estimate.")


if __name__ == "__main__":
    main()
