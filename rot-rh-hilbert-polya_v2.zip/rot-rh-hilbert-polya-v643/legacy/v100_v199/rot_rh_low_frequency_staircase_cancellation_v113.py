#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v113 — Low-Frequency Staircase Cancellation Red-Team
=============================================================

Consumes v111_CELLS.csv only. No roots/phases are recomputed.

For
    q_k(L) = int_{E_k}^{E_{k+1}} [F_L(E)-k] dE,

v112 ruled out simple q_k ~ c_k/L scaling and did not find strong lag-1
anti-persistence. v113 tests the remaining possibility:

    bounded primitive comes from multi-cell / low-frequency cancellation.

Exact geometry:
    Phi_L(E)=int_0^E F_L(u)du,
    B_k = Phi_L(E_k)-k E_k + sum_{j=1}^k E_j,
then
    q_k = B_{k+1}-B_k.

So partial sums of q_k are exactly increments of the Legendre-like defect B.

Audits:
  * real cumulative max versus random permutations of the SAME signed q_k;
  * real cumulative max versus random signs with fixed |q_k|;
  * low-frequency FFT power versus permutation controls;
  * dyadic block-sum RMS versus permutation controls;
  * autocorrelation through configurable lag;
  * normalized cell-average discrepancy q_k/(E_{k+1}-E_k);
  * cumulative growth exponent across prefixes.

No Xi, zeta, or known-zero data.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v113"
BUILD = "2026-08-17-low-frequency-staircase-cancellation-red-team-v113"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row, key):
    return float(row[key])


def i(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    return float(np.max(np.abs(np.cumsum(np.asarray(x, float)))))


def cumulative_range(x):
    c = np.concatenate([[0.0], np.cumsum(np.asarray(x, float))])
    return float(np.max(c) - np.min(c))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def autocorr(x, lag):
    x = np.asarray(x, float)
    if lag <= 0 or len(x) <= lag:
        return float("nan")
    a = x[:-lag] - np.mean(x[:-lag])
    b = x[lag:] - np.mean(x[lag:])
    den = np.linalg.norm(a) * np.linalg.norm(b)
    if den <= EPS:
        return float("nan")
    return float(np.dot(a, b) / den)


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    # Remove DC only; the near-zero non-DC modes are the target.
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def dyadic_block_rms(x, block):
    x = np.asarray(x, float)
    b = int(block)
    n = len(x) // b
    if n < 1:
        return float("nan")
    y = x[:n*b].reshape(n, b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))


def growth_exponent(x, min_prefix=8):
    """
    Fit log(max_{m<=n}|sum_{k<=m}q_k|) = alpha log n + const.
    alpha~1/2 random walk; alpha~0 bounded.
    """
    x = np.asarray(x, float)
    c = np.abs(np.cumsum(x))
    running = np.maximum.accumulate(c)
    ns = np.arange(1, len(x)+1)
    mask = (ns >= int(min_prefix)) & (running > 0)
    if np.sum(mask) < 3:
        return float("nan")
    X = np.column_stack([np.ones(np.sum(mask)), np.log(ns[mask])])
    beta, *_ = np.linalg.lstsq(X, np.log(running[mask]), rcond=None)
    return float(beta[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v111-prefix",
        default="rot_rh_exact_staircase_block_primitive_v111",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--k-min", type=int, default=48)
    ap.add_argument("--k-max", type=int, default=127)
    ap.add_argument("--permutations", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument("--lowfreq-bins", type=int, default=4)
    ap.add_argument("--max-lag", type=int, default=20)
    ap.add_argument(
        "--prefix",
        default="rot_rh_low_frequency_staircase_cancellation_v113",
    )
    args = ap.parse_args()

    Ls = [int(x.strip()) for x in args.L_list.split(",") if x.strip()]
    src = Path(args.v111_prefix).expanduser().resolve()
    cells_path = Path(str(src) + "_CELLS.csv")
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rng = np.random.default_rng(args.seed)

    print("=" * 150)
    print("ROT-RH v113 — LOW-FREQUENCY STAIRCASE CANCELLATION RED-TEAM")
    print("=" * 150)
    print("source                          :", cells_path)
    print("L ladder                        :", Ls)
    print("cell range                      :", f"{args.k_min}..{args.k_max}")
    print("permutations                    :", args.permutations)
    print("low-frequency bins              :", args.lowfreq_bins)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 150)

    summary_rows = []
    lag_rows = []
    block_rows = []
    cell_rows = []

    for L in Ls:
        rr = sorted(
            [
                r for r in raw
                if i(r, "L") == L
                and args.k_min <= i(r, "cell_k") <= args.k_max
            ],
            key=lambda r: i(r, "cell_k"),
        )
        if not rr:
            raise RuntimeError(f"No rows for L={L}")

        ks = np.asarray([i(r, "cell_k") for r in rr], int)
        q = np.asarray([f(r, "Q_area") for r in rr], float)
        width = np.asarray([f(r, "width") for r in rr], float)
        qbar = q / width

        real_cmax = cumulative_max(q)
        real_crange = cumulative_range(q)
        real_lf = lowfreq_fraction(q, args.lowfreq_bins)
        real_alpha = growth_exponent(q)

        perm_cmax = np.empty(args.permutations, float)
        perm_crange = np.empty(args.permutations, float)
        perm_lf = np.empty(args.permutations, float)
        sign_cmax = np.empty(args.permutations, float)

        absq = np.abs(q)
        for t in range(args.permutations):
            qp = rng.permutation(q)
            perm_cmax[t] = cumulative_max(qp)
            perm_crange[t] = cumulative_range(qp)
            perm_lf[t] = lowfreq_fraction(qp, args.lowfreq_bins)

            qs = absq * rng.choice(np.array([-1.0, 1.0]), size=len(q))
            sign_cmax[t] = cumulative_max(qs)

        row = {
            "L": L,
            "cell_count": len(q),
            "q_mean": float(np.mean(q)),
            "q_mean_abs": float(np.mean(absq)),
            "q_rms": float(np.sqrt(np.mean(q*q))),
            "q_max_abs": float(np.max(absq)),
            "qbar_mean_abs": float(np.mean(np.abs(qbar))),
            "qbar_rms": float(np.sqrt(np.mean(qbar*qbar))),
            "qbar_max_abs": float(np.max(np.abs(qbar))),
            "real_cumulative_max": real_cmax,
            "real_cumulative_range": real_crange,
            "real_growth_exponent": real_alpha,
            "real_lowfreq_fraction": real_lf,
            "perm_cmax_mean": float(np.mean(perm_cmax)),
            "perm_cmax_median": float(np.median(perm_cmax)),
            "perm_cmax_p05": float(np.quantile(perm_cmax, 0.05)),
            "perm_cmax_p95": float(np.quantile(perm_cmax, 0.95)),
            "real_cmax_lower_tail_percentile":
                percentile_le(perm_cmax, real_cmax),
            "perm_crange_mean": float(np.mean(perm_crange)),
            "real_crange_lower_tail_percentile":
                percentile_le(perm_crange, real_crange),
            "sign_cmax_mean": float(np.mean(sign_cmax)),
            "real_vs_random_sign_lower_tail_percentile":
                percentile_le(sign_cmax, real_cmax),
            "perm_lowfreq_mean": float(np.mean(perm_lf)),
            "perm_lowfreq_p05": float(np.quantile(perm_lf, 0.05)),
            "real_lowfreq_lower_tail_percentile":
                percentile_le(perm_lf, real_lf),
        }
        summary_rows.append(row)

        print(
            f"L={L:<6d}: cumMax={real_cmax:.3e} "
            f"permMean={row['perm_cmax_mean']:.3e} "
            f"permPct={100*row['real_cmax_lower_tail_percentile']:.2f}% "
            f"lowF={real_lf:.3f} "
            f"lowFPct={100*row['real_lowfreq_lower_tail_percentile']:.2f}% "
            f"alpha={real_alpha:+.3f} "
            f"mean|q/width|={row['qbar_mean_abs']:.3e}"
        )

        # Autocorrelation spectrum.
        for lag in range(1, min(args.max_lag, len(q)-1) + 1):
            lag_rows.append(
                {
                    "L": L,
                    "lag": lag,
                    "autocorrelation": autocorr(q, lag),
                }
            )

        # Dyadic blocks and permutation controls.
        for b in [1, 2, 4, 8, 16, 32, 64]:
            if b > len(q):
                continue
            real_brms = dyadic_block_rms(q, b)
            ctrl = np.empty(args.permutations, float)
            for t in range(args.permutations):
                ctrl[t] = dyadic_block_rms(rng.permutation(q), b)
            block_rows.append(
                {
                    "L": L,
                    "block_size": b,
                    "real_block_sum_rms": real_brms,
                    "perm_mean": float(np.mean(ctrl)),
                    "perm_p05": float(np.quantile(ctrl, 0.05)),
                    "perm_p50": float(np.quantile(ctrl, 0.50)),
                    "perm_p95": float(np.quantile(ctrl, 0.95)),
                    "real_lower_tail_percentile":
                        percentile_le(ctrl, real_brms),
                    "suppression_ratio_real_over_perm_mean":
                        real_brms / max(float(np.mean(ctrl)), EPS),
                }
            )

        c = np.cumsum(q)
        for idx in range(len(q)):
            cell_rows.append(
                {
                    "L": L,
                    "cell_k": int(ks[idx]),
                    "Q_area": q[idx],
                    "width": width[idx],
                    "cell_average_Q": qbar[idx],
                    "cumulative_Q_area": c[idx],
                }
            )

    final = [r for r in summary_rows if r["L"] == Ls[-1]][0]
    final_blocks = [r for r in block_rows if r["L"] == Ls[-1]]

    # "Structured low-frequency cancellation" should show both unusually
    # small cumulative excursion and suppression on at least one multi-cell scale.
    multiscale = [
        r for r in final_blocks
        if r["block_size"] >= 8
        and r["real_lower_tail_percentile"] <= 0.10
    ]
    structured = (
        final["real_cmax_lower_tail_percentile"] <= 0.10
        and len(multiscale) >= 1
    )

    if structured:
        mechanism = "STRUCTURED_MULTI_CELL_CANCELLATION_SUPPORTED"
    else:
        mechanism = "NO_STRONG_STATISTICAL_EVIDENCE_FOR_BOUNDED_MULTI_CELL_CANCELLATION_YET"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_SUMMARY.csv"), summary_rows)
    write_csv(Path(str(prefix) + "_LAGS.csv"), lag_rows)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)
    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V113_RED_TEAM_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "final_L": Ls[-1],
        "final_summary": final,
        "final_multiscale_suppressed_blocks": multiscale,
        "interpretation": (
            "If cumulative excursion and low-frequency/block-sum power are "
            "significantly below permutation controls, bounded primitive is "
            "a structured spectral-index phenomenon. If not, 80 cells are "
            "insufficient evidence and the next test must extend depth."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 150)
    print("FINAL v113 VERDICT")
    print("=" * 150)
    print("mechanism                       :", mechanism)
    print("final cumulative max            :", f"{final['real_cumulative_max']:.12e}")
    print("perm cumulative max mean        :", f"{final['perm_cmax_mean']:.12e}")
    print("real cumulative lower percentile:", f"{100*final['real_cmax_lower_tail_percentile']:.4f}%")
    print("final low-frequency fraction    :", f"{final['real_lowfreq_fraction']:.12e}")
    print("low-frequency lower percentile  :", f"{100*final['real_lowfreq_lower_tail_percentile']:.4f}%")
    print("growth exponent alpha           :", f"{final['real_growth_exponent']:.12e}")
    print("mean |cell-average Q|           :", f"{final['qbar_mean_abs']:.12e}")
    print("multi-cell suppressed scales    :", [r["block_size"] for r in multiscale])
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 150)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
