#!/usr/bin/env python3
"""
ROT-RH v133 — LOW-MODE CUTOFF-FLOW FORENSICS (ZERO-COST POSTPROCESSOR)

Reads existing v132 ROOTS.npz and any v132 per-L cache files.
Performs NO root solving, NO prime sums, NO Xi/zeta/known-zero evaluation.

Purpose
-------
The v132.3 audit localized the 64k -> 128k trace-norm plateau to low modes,
especially k=2..16.  This script identifies the exact responsible modes and
tests whether their cutoff motion is oscillatory across the already-computed
half-doubling history.

For each mode k it reports:
  * previous and latest |Delta lambda_k|,
  * latest/previous ratio and local exponent,
  * signed-step reversal,
  * latest trace-norm contribution,
  * "plateau excess" relative to a user-selected expected contraction,
  * sign-change rate across all available cutoff intervals,
  * an envelope fit for |d lambda / d log2 L| ~ L^{-p}.

It also ranks the modes that account for the latest plateau.

Outputs
-------
<prefix>_MODES.csv
<prefix>_HISTORY.csv
<prefix>_TOP_MODES.csv
<prefix>_VERDICT.json
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import re
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def local_p(prev, latest):
    if prev <= 0 or latest <= 0:
        return np.nan
    return float(-math.log(latest / prev, 2.0))


def fit_envelope(Lmid, rate):
    Lmid = np.asarray(Lmid, float)
    rate = np.asarray(rate, float)
    m = np.isfinite(Lmid) & np.isfinite(rate) & (rate > 0) & (Lmid > 0)
    Lmid, rate = Lmid[m], rate[m]
    if len(Lmid) < 4:
        return np.nan, np.nan
    x = np.log(Lmid)
    y = np.log(rate)
    X = np.column_stack([np.ones(len(x)), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    sse = float(np.sum((y - pred) ** 2))
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0
    return float(-beta[1]), float(r2)


def extract_L_from_name(path: str):
    m = re.search(r"_CACHE_L(\d+)_D\d+\.npz$", Path(path).name)
    return int(m.group(1)) if m else None


def load_supports(roots_npz: str, cache_glob: str):
    """Return dict L -> lambda vector. Current ROOTS.npz takes precedence."""
    data = {}

    for p in sorted(glob.glob(cache_glob)):
        L = extract_L_from_name(p)
        if L is None:
            continue
        try:
            z = np.load(p)
            if "lambda_vals" in z:
                lam = np.asarray(z["lambda_vals"], float)
            elif "roots" in z:
                r = np.asarray(z["roots"], float)
                lam = 1.0 / r**2
            else:
                continue
            data[int(L)] = lam
        except Exception:
            pass

    z = np.load(roots_npz)
    Ls = np.asarray(z["L"], int)
    if "lambda_vals" in z:
        M = np.asarray(z["lambda_vals"], float)
    else:
        M = 1.0 / np.asarray(z["roots"], float) ** 2

    for i, L in enumerate(Ls):
        data[int(L)] = M[i].copy()

    return data


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz"
    )
    ap.add_argument(
        "--cache-glob",
        default="rot_rh_trace_norm_cutoff_removal_v132_CACHE_L*_D1408.npz"
    )
    ap.add_argument("--max-mode", type=int, default=64)
    ap.add_argument("--top-modes", type=int, default=16)
    ap.add_argument(
        "--expected-contraction",
        type=float,
        default=0.810,
        help="Reference contraction from the earlier stable-depth fit."
    )
    ap.add_argument(
        "--low-mode-end",
        type=int,
        default=16
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_low_mode_cutoff_flow_v133"
    )
    args = ap.parse_args()

    supports = load_supports(args.roots_npz, args.cache_glob)
    Ls = np.array(sorted(supports), dtype=int)
    if len(Ls) < 4:
        raise RuntimeError("Need at least four cutoff supports.")

    nmax = min(len(supports[int(Ls[0])]), args.max_mode)
    M = np.vstack([supports[int(L)][:nmax] for L in Ls])

    print("=" * 124)
    print("ROT-RH v133 — LOW-MODE CUTOFF-FLOW FORENSICS")
    print("=" * 124)
    print("Xi / zeta / known zeros          : NONE")
    print(f"available L supports              : {Ls.tolist()}")
    print(f"modes analyzed                    : 1..{nmax}")
    print(f"expected contraction reference    : {args.expected_contraction}")
    print("=" * 124)

    # Locate last three dyadic anchors if present.
    Llatest = int(Ls[-1])
    Lprev = Llatest // 2
    Lprev2 = Lprev // 2

    if Lprev not in supports or Lprev2 not in supports:
        raise RuntimeError(
            f"Need dyadic anchors {Lprev2}, {Lprev}, {Llatest} in available supports."
        )

    lam2 = supports[Lprev2][:nmax]
    lam1 = supports[Lprev][:nmax]
    lam0 = supports[Llatest][:nmax]

    dprev = lam1 - lam2
    dlast = lam0 - lam1
    aprev = np.abs(dprev)
    alast = np.abs(dlast)

    latest_total = float(np.sum(alast))
    prev_total = float(np.sum(aprev))

    # History using every available adjacent support.
    history_rows = []
    per_mode_hist = {k: [] for k in range(nmax)}

    for i in range(len(Ls) - 1):
        La, Lb = int(Ls[i]), int(Ls[i + 1])
        xa, xb = math.log2(La), math.log2(Lb)
        dx = xb - xa
        Lmid = math.sqrt(La * Lb)
        delta = M[i + 1] - M[i]

        for k in range(nmax):
            rate = abs(delta[k]) / dx if dx > 0 else np.nan
            row = dict(
                k=k + 1,
                L_a=La,
                L_b=Lb,
                ratio_L=Lb / La,
                delta_lambda=float(delta[k]),
                abs_delta_lambda=float(abs(delta[k])),
                delta_log2_L=dx,
                abs_rate_per_log2L=float(rate),
                L_mid=float(Lmid),
            )
            history_rows.append(row)
            per_mode_hist[k].append(row)

    mode_rows = []
    for k in range(nmax):
        hist = per_mode_hist[k]
        signs = np.array([np.sign(r["delta_lambda"]) for r in hist], float)
        nz = signs != 0
        signs_nz = signs[nz]
        if len(signs_nz) >= 2:
            sign_change_fraction = float(np.mean(signs_nz[1:] != signs_nz[:-1]))
            sign_changes = int(np.sum(signs_nz[1:] != signs_nz[:-1]))
        else:
            sign_change_fraction = np.nan
            sign_changes = 0

        Lmid = [r["L_mid"] for r in hist]
        rates = [r["abs_rate_per_log2L"] for r in hist]
        env_p, env_r2 = fit_envelope(Lmid, rates)

        ratio = float(alast[k] / aprev[k]) if aprev[k] > 0 else np.nan
        p_loc = local_p(float(aprev[k]), float(alast[k]))
        flip_latest = bool(np.sign(dprev[k]) != np.sign(dlast[k]) and dprev[k] != 0 and dlast[k] != 0)

        expected = args.expected_contraction * float(aprev[k])
        excess = float(alast[k] - expected)

        mode_rows.append(dict(
            k=k + 1,
            previous_abs_delta=float(aprev[k]),
            latest_abs_delta=float(alast[k]),
            latest_to_previous_ratio=ratio,
            latest_local_p=p_loc,
            previous_signed_delta=float(dprev[k]),
            latest_signed_delta=float(dlast[k]),
            latest_sign_flip=int(flip_latest),
            latest_fraction_of_trace=(float(alast[k]) / latest_total if latest_total > 0 else np.nan),
            expected_latest_at_reference_contraction=expected,
            plateau_excess=excess,
            plateau_excess_positive=max(excess, 0.0),
            all_history_sign_changes=sign_changes,
            all_history_sign_change_fraction=sign_change_fraction,
            envelope_p=env_p,
            envelope_r2=env_r2,
        ))

    # Ranking by latest trace contribution and by positive plateau excess.
    latest_rank = sorted(mode_rows, key=lambda r: r["latest_abs_delta"], reverse=True)
    excess_rank = sorted(mode_rows, key=lambda r: r["plateau_excess_positive"], reverse=True)

    top_rows = []
    cum = 0.0
    for rank, r in enumerate(latest_rank[:args.top_modes], 1):
        cum += r["latest_abs_delta"]
        top_rows.append(dict(
            ranking="latest_trace",
            rank=rank,
            k=r["k"],
            value=r["latest_abs_delta"],
            fraction_of_latest=r["latest_fraction_of_trace"],
            cumulative_fraction=(cum / latest_total if latest_total > 0 else np.nan),
            latest_ratio=r["latest_to_previous_ratio"],
            latest_local_p=r["latest_local_p"],
            latest_sign_flip=r["latest_sign_flip"],
            sign_change_fraction=r["all_history_sign_change_fraction"],
            envelope_p=r["envelope_p"],
            envelope_r2=r["envelope_r2"],
        ))

    pos_excess_total = float(sum(r["plateau_excess_positive"] for r in mode_rows))
    cum = 0.0
    for rank, r in enumerate(excess_rank[:args.top_modes], 1):
        cum += r["plateau_excess_positive"]
        top_rows.append(dict(
            ranking="plateau_excess",
            rank=rank,
            k=r["k"],
            value=r["plateau_excess_positive"],
            fraction_of_latest=(
                r["plateau_excess_positive"] / pos_excess_total
                if pos_excess_total > 0 else np.nan
            ),
            cumulative_fraction=(
                cum / pos_excess_total if pos_excess_total > 0 else np.nan
            ),
            latest_ratio=r["latest_to_previous_ratio"],
            latest_local_p=r["latest_local_p"],
            latest_sign_flip=r["latest_sign_flip"],
            sign_change_fraction=r["all_history_sign_change_fraction"],
            envelope_p=r["envelope_p"],
            envelope_r2=r["envelope_r2"],
        ))

    write_csv(Path(args.prefix + "_MODES.csv"), mode_rows)
    write_csv(Path(args.prefix + "_HISTORY.csv"), history_rows)
    write_csv(Path(args.prefix + "_TOP_MODES.csv"), top_rows)

    low_end = min(args.low_mode_end, nmax)
    low_fraction = float(np.sum(alast[:low_end]) / latest_total) if latest_total > 0 else np.nan
    low_excess = float(np.sum(np.maximum(alast[:low_end] - args.expected_contraction * aprev[:low_end], 0.0)))
    low_excess_fraction = low_excess / pos_excess_total if pos_excess_total > 0 else np.nan

    print()
    print("Top modes by latest trace-norm contribution")
    print("-" * 124)
    print(f"{'rank':>5} {'k':>4} {'latest':>14} {'share':>10} {'ratio':>10} {'p_local':>10} {'flip':>6} {'hist flips':>11} {'env p':>10}")
    for rank, r in enumerate(latest_rank[:args.top_modes], 1):
        print(
            f"{rank:5d} {r['k']:4d} "
            f"{r['latest_abs_delta']:14.6e} "
            f"{100*r['latest_fraction_of_trace']:9.3f}% "
            f"{r['latest_to_previous_ratio']:10.5f} "
            f"{r['latest_local_p']:10.5f} "
            f"{r['latest_sign_flip']:6d} "
            f"{r['all_history_sign_change_fraction']:11.3f} "
            f"{r['envelope_p']:10.5f}"
        )

    print()
    print("Top modes creating the plateau excess relative to contraction %.3f" % args.expected_contraction)
    print("-" * 124)
    print(f"{'rank':>5} {'k':>4} {'excess':>14} {'share excess':>14} {'ratio':>10} {'p_local':>10} {'flip':>6}")
    for rank, r in enumerate(excess_rank[:args.top_modes], 1):
        if r["plateau_excess_positive"] <= 0:
            break
        frac = r["plateau_excess_positive"] / pos_excess_total if pos_excess_total > 0 else np.nan
        print(
            f"{rank:5d} {r['k']:4d} "
            f"{r['plateau_excess_positive']:14.6e} "
            f"{100*frac:13.3f}% "
            f"{r['latest_to_previous_ratio']:10.5f} "
            f"{r['latest_local_p']:10.5f} "
            f"{r['latest_sign_flip']:6d}"
        )

    verdict = dict(
        version=133,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        supports=Ls.tolist(),
        latest_dyadic_interval=[Lprev, Llatest],
        previous_dyadic_interval=[Lprev2, Lprev],
        latest_trace_first_modes=latest_total,
        previous_trace_first_modes=prev_total,
        latest_ratio=latest_total / prev_total if prev_total > 0 else np.nan,
        expected_contraction=args.expected_contraction,
        low_mode_end=low_end,
        low_mode_fraction_of_latest_trace=low_fraction,
        positive_plateau_excess_total=pos_excess_total,
        low_mode_fraction_of_positive_plateau_excess=low_excess_fraction,
        top_latest_modes=[int(r["k"]) for r in latest_rank[:args.top_modes]],
        top_plateau_excess_modes=[
            int(r["k"]) for r in excess_rank[:args.top_modes]
            if r["plateau_excess_positive"] > 0
        ],
        diagnosis=(
            "If a small set of low modes carries most positive plateau excess and "
            "shows repeated signed reversals across the dense historical cutoff grid, "
            "the next target is low-mode oscillatory regulator/finite-part flow, not "
            "the high-k spectral tail."
        ),
    )

    Path(args.prefix + "_VERDICT.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )

    print()
    print("=" * 124)
    print(f"latest interval                    : {Lprev} -> {Llatest}")
    print(f"latest trace (modes 1..{nmax})       : {latest_total:.9e}")
    print(f"previous trace (modes 1..{nmax})     : {prev_total:.9e}")
    print(f"latest / previous                 : {latest_total/prev_total:.9f}")
    print(f"modes 1..{low_end} latest fraction    : {100*low_fraction:.3f}%")
    print(f"modes 1..{low_end} plateau-excess frac: {100*low_excess_fraction:.3f}%")
    print(f"top plateau-excess modes          : {[r['k'] for r in excess_rank[:8] if r['plateau_excess_positive'] > 0]}")
    print("=" * 124)


if __name__ == "__main__":
    main()
