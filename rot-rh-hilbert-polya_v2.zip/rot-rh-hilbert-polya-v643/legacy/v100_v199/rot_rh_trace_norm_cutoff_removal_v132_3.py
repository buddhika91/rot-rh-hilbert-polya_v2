#!/usr/bin/env python3
"""
ROT-RH v132.3 — FAST TRACE-NORM PLATEAU ANATOMY

Reads the dyadic ROOTS.npz from v132 and performs NO root solving,
NO prime sums, NO Xi/zeta/known-zero evaluation.

Purpose
-------
Diagnose why the dyadic trace distance

    B_N(L,2L) = sum_{k<=N} |E_k(2L)^(-2)-E_k(L)^(-2)|

stops contracting at the latest cutoff.

Outputs
-------
<prefix>_SHELLS.csv
<prefix>_MODE_BANDS.csv
<prefix>_DEPTH_RATIOS.csv
<prefix>_VERDICT.json

Key diagnostics
---------------
1. Which spectral k-bands dominate the latest trace norm?
2. Does the latest plateau persist at shallow depths?
3. Is it concentrated only in high-k modes?
4. Do individual modes reverse sign between successive dyadic steps?
5. What local cutoff exponent p is seen in each spectral band?
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def local_p(a, b):
    # If B(2L)/B(L)=r, then p=-log2(r)
    if a <= 0 or b <= 0:
        return np.nan
    return float(-math.log(b/a, 2.0))


def linfit(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y) & (y > 0)
    x, y = x[m], y[m]
    if len(x) < 3:
        return dict(p=np.nan, r2=np.nan)
    X = np.column_stack([np.ones(len(x)), np.log(x)])
    beta, *_ = np.linalg.lstsq(X, np.log(y), rcond=None)
    pred = X @ beta
    sse = float(np.sum((np.log(y)-pred)**2))
    sst = float(np.sum((np.log(y)-np.log(y).mean())**2))
    r2 = 1.0 - sse/sst if sst > 0 else 1.0
    return dict(p=float(-beta[1]), r2=float(r2))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz"
    )
    ap.add_argument(
        "--depths",
        default="64,128,256,512,768,1024,1408"
    )
    ap.add_argument(
        "--bands",
        default="1,16,32,64,128,256,512,768,1024,1408",
        help="Cumulative band endpoints. Bands become 1-a, a+1-b, ..."
    )
    ap.add_argument(
        "--plateau-ratio-gate",
        type=float,
        default=0.95
    )
    ap.add_argument(
        "--high-k-start",
        type=int,
        default=769,
        help="Modes >= this label are classified as high-k."
    )
    ap.add_argument(
        "--high-k-dominance-gate",
        type=float,
        default=0.50
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_trace_norm_cutoff_removal_v132_3"
    )
    args = ap.parse_args()

    z = np.load(args.roots_npz)
    L = np.asarray(z["L"], int)
    if "lambda_vals" in z:
        lam = np.asarray(z["lambda_vals"], float)
    else:
        roots = np.asarray(z["roots"], float)
        lam = 1.0 / roots**2

    if len(L) < 4:
        raise RuntimeError("Need at least 4 dyadic cutoffs.")
    ratiosL = L[1:] / L[:-1]
    if not np.allclose(ratiosL, 2.0, rtol=2e-4, atol=0):
        print("WARNING: L grid is not exactly dyadic:", L.tolist())

    maxN = lam.shape[1]
    depths = [d for d in sorted(set(csv_ints(args.depths))) if d <= maxN]
    ends = [d for d in sorted(set(csv_ints(args.bands))) if 1 <= d <= maxN]
    if not ends or ends[-1] != maxN:
        ends.append(maxN)

    dlam = lam[1:] - lam[:-1]          # signed modewise increments
    adlam = np.abs(dlam)

    print("="*118)
    print("ROT-RH v132.3 — FAST TRACE-NORM PLATEAU ANATOMY")
    print("="*118)
    print("Xi / zeta / known zeros          : NONE")
    print(f"L grid                            : {L.tolist()}")
    print(f"levels                            : {maxN}")
    print("="*118)

    # ------------------------------------------------------------------
    # Depth ratios
    # ------------------------------------------------------------------
    depth_rows = []
    print()
    print("Dyadic trace distances by depth")
    print("-"*118)
    for N in depths:
        Bs = np.sum(adlam[:, :N], axis=1)
        last_ratio = float(Bs[-1] / Bs[-2]) if Bs[-2] > 0 else np.nan
        prev_ratio = float(Bs[-2] / Bs[-3]) if Bs[-3] > 0 else np.nan
        p_last = local_p(Bs[-2], Bs[-1])
        p_prev = local_p(Bs[-3], Bs[-2])
        fit = linfit(L[:-1].astype(float), Bs)
        row = dict(
            depth=N,
            **{f"B_{int(L[i])}_{int(L[i+1])}": float(Bs[i]) for i in range(len(Bs))},
            previous_ratio=prev_ratio,
            latest_ratio=last_ratio,
            previous_local_p=p_prev,
            latest_local_p=p_last,
            all_range_p=fit["p"],
            all_range_r2=fit["r2"],
        )
        depth_rows.append(row)
        print(
            f"N={N:4d}  "
            f"Bprev={Bs[-2]:.6e}  Blast={Bs[-1]:.6e}  "
            f"ratio={last_ratio:.6f}  p_last={p_last:.6f}"
        )

    write_csv(Path(args.prefix+"_DEPTH_RATIOS.csv"), depth_rows)

    # ------------------------------------------------------------------
    # Disjoint spectral bands
    # ------------------------------------------------------------------
    band_rows = []
    start = 0
    latest_total = float(np.sum(adlam[-1]))
    previous_total = float(np.sum(adlam[-2]))

    print()
    print("Latest spectral-band anatomy")
    print("-"*118)
    print(f"{'band':>15} {'prev':>14} {'latest':>14} {'ratio':>10} {'p_local':>10} {'latest %':>10} {'sign flip %':>12}")

    for end in ends:
        if end <= start:
            continue
        sl = slice(start, end)
        B = np.sum(adlam[:, sl], axis=1)
        latest = float(B[-1])
        prev = float(B[-2])
        ratio = latest/prev if prev > 0 else np.nan
        p = local_p(prev, latest)

        prev_signed = dlam[-2, sl]
        last_signed = dlam[-1, sl]
        nz = (prev_signed != 0) & (last_signed != 0)
        flip = float(np.mean(np.sign(prev_signed[nz]) != np.sign(last_signed[nz]))) if np.any(nz) else np.nan

        fit = linfit(L[:-1].astype(float), B)

        row = dict(
            k_start=start+1,
            k_end=end,
            modes=end-start,
            previous_trace=prev,
            latest_trace=latest,
            latest_to_previous_ratio=ratio,
            latest_local_p=p,
            all_range_p=fit["p"],
            all_range_r2=fit["r2"],
            latest_fraction_of_total=(latest/latest_total if latest_total > 0 else np.nan),
            previous_fraction_of_total=(prev/previous_total if previous_total > 0 else np.nan),
            sign_flip_fraction=flip,
        )
        band_rows.append(row)

        print(
            f"{start+1:5d}-{end:<7d} "
            f"{prev:14.6e} {latest:14.6e} "
            f"{ratio:10.6f} {p:10.6f} "
            f"{100*row['latest_fraction_of_total']:9.3f}% "
            f"{100*flip:11.3f}%"
        )
        start = end

    write_csv(Path(args.prefix+"_MODE_BANDS.csv"), band_rows)

    # ------------------------------------------------------------------
    # Fixed-width shells for detailed localization
    # ------------------------------------------------------------------
    shell_rows = []
    width = 64
    for start in range(0, maxN, width):
        end = min(start+width, maxN)
        sl = slice(start, end)
        B = np.sum(adlam[:, sl], axis=1)
        prev = float(B[-2])
        latest = float(B[-1])

        prev_signed = dlam[-2, sl]
        last_signed = dlam[-1, sl]
        nz = (prev_signed != 0) & (last_signed != 0)
        flip = float(np.mean(np.sign(prev_signed[nz]) != np.sign(last_signed[nz]))) if np.any(nz) else np.nan

        shell_rows.append(dict(
            k_start=start+1,
            k_end=end,
            previous_trace=prev,
            latest_trace=latest,
            ratio=(latest/prev if prev > 0 else np.nan),
            latest_local_p=local_p(prev, latest),
            latest_fraction=(latest/latest_total if latest_total > 0 else np.nan),
            sign_flip_fraction=flip,
        ))
    write_csv(Path(args.prefix+"_SHELLS.csv"), shell_rows)

    # ------------------------------------------------------------------
    # Quantiles / concentration
    # ------------------------------------------------------------------
    latest_mode = adlam[-1]
    order = np.argsort(latest_mode)[::-1]
    cs = np.cumsum(latest_mode[order])
    def modes_for_fraction(frac):
        if latest_total <= 0:
            return 0
        return int(np.searchsorted(cs, frac*latest_total) + 1)

    n50 = modes_for_fraction(0.50)
    n80 = modes_for_fraction(0.80)
    n90 = modes_for_fraction(0.90)

    high_idx = max(0, args.high_k_start-1)
    high_fraction = float(np.sum(latest_mode[high_idx:]) / latest_total) if latest_total > 0 else np.nan

    shallow = depth_rows[0]
    deep = depth_rows[-1]
    plateau_at_shallow = bool(shallow["latest_ratio"] >= args.plateau_ratio_gate)
    plateau_at_deep = bool(deep["latest_ratio"] >= args.plateau_ratio_gate)
    high_k_dominates = bool(high_fraction >= args.high_k_dominance_gate)

    if plateau_at_deep and plateau_at_shallow:
        diagnosis = (
            "BROAD_OR_LOW_MODE_PLATEAU: the near-flat latest dyadic trace distance "
            "is already visible at shallow spectral depth. It is unlikely to be caused "
            "only by the unresolved high-k tail."
        )
    elif plateau_at_deep and high_k_dominates:
        diagnosis = (
            "HIGH_K_DRIVEN_PLATEAU: the latest plateau is concentrated in high modes; "
            "increase spectral-depth/tail control before judging cutoff convergence."
        )
    elif plateau_at_deep:
        diagnosis = (
            "MIXED_PLATEAU: the latest dyadic distance is near-flat but not cleanly "
            "localized to either shallow or high-k modes."
        )
    else:
        diagnosis = (
            "NO_STRONG_PLATEAU: the latest ratio is below the selected plateau gate."
        )

    verdict = dict(
        version="132.3",
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        L_grid=L.tolist(),
        latest_interval=[int(L[-2]), int(L[-1])],
        latest_trace_full=latest_total,
        previous_trace_full=previous_total,
        latest_ratio=float(latest_total/previous_total),
        latest_local_p=local_p(previous_total, latest_total),
        concentration=dict(
            modes_for_50_percent=n50,
            modes_for_80_percent=n80,
            modes_for_90_percent=n90,
            high_k_start=args.high_k_start,
            high_k_fraction=high_fraction,
        ),
        gates=dict(
            plateau_ratio_gate=args.plateau_ratio_gate,
            plateau_at_shallow_depth=plateau_at_shallow,
            plateau_at_full_depth=plateau_at_deep,
            high_k_dominates=high_k_dominates,
        ),
        diagnosis=diagnosis,
        interpretation=(
            "This is a diagnostic of the observed finite-depth cutoff flow. "
            "It is not a proof or disproof of trace-norm cutoff convergence."
        ),
    )
    Path(args.prefix+"_VERDICT.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )

    print()
    print("="*118)
    print(f"previous full trace distance      : {previous_total:.9e}")
    print(f"latest full trace distance        : {latest_total:.9e}")
    print(f"latest/previous                   : {latest_total/previous_total:.9f}")
    print(f"latest local exponent p           : {local_p(previous_total, latest_total):.9f}")
    print(f"modes carrying 50% / 80% / 90%   : {n50} / {n80} / {n90}")
    print(f"k >= {args.high_k_start} fraction              : {100*high_fraction:.3f}%")
    print(f"DIAGNOSIS                         : {diagnosis}")
    print("="*118)


if __name__ == "__main__":
    main()
