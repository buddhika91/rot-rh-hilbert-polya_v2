#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v128 — Weighted L2 / Cauchy-Schwarz PNT-Error Audit
===========================================================

PURPOSE
-------
v127 showed that a pointwise envelope for E(n)=psi(n)-n followed by triangle
inequality is catastrophically loose for the exact weighted PNT-error term

    S_err = E(N)A(N) + sum_{n=2}^{N-1} E(n) [A(n)-A(n+1)].

v128 asks the next standard analytic question:

    Can MEAN-SQUARE / L2 information about E(n) control this transform?

For any real alpha,

    |sum E(n) dA(n)|
      <= [sum E(n)^2 n^(-2 alpha)]^(1/2)
         [sum dA(n)^2 n^(+2 alpha)]^(1/2).

The script scans alpha, and also applies Cauchy-Schwarz locally on logarithmic
arithmetic bands. Localizing cannot make the bound invalid and may preserve
scale dependence that a single global norm loses.

It computes:
  * exact A(n), dA(n), E(n);
  * exact signed PNT-error transform;
  * global unweighted Cauchy-Schwarz bound;
  * optimized power-weighted Cauchy-Schwarz bound;
  * localized Cauchy-Schwarz bounds for several log2(n) partitions;
  * per-band correlation cosines between E(n) and dA(n);
  * the fraction of the actual signed error explained by bands whose
    E/dA cosine is unusually small.

Interpretation:
  If even the BEST weighted/localized L2 bound is orders of magnitude larger
  than the actual signed transform, then mean-square size information alone is
  structurally insufficient. A proof must control the BILINEAR CORRELATION
  between the PNT error and the oscillatory kernel derivative.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v128"
BUILD = "2026-08-18-weighted-l2-cauchy-schwarz-pnt-error-v128"
EPS = 1e-300


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def exact_kernel_unweighted(mid, h, nvals, L):
    nvals = np.asarray(nvals, float)
    logn = np.log(nvals)
    delta = 0.5 * h[:, None] * logn[None, :]
    phase = mid[:, None] * logn[None, :]
    pref = (
        2.0 * np.exp(-nvals / float(L))
        / (math.pi * np.sqrt(nvals) * logn * logn)
    )
    return (
        np.sin(phase)
        * (delta * np.cos(delta) - np.sin(delta))
        * pref[None, :]
    )


def safe_norm(x):
    return float(np.sqrt(np.dot(x, x)))


def corr_cos(x, y):
    nx = safe_norm(x)
    ny = safe_norm(y)
    if nx <= EPS or ny <= EPS:
        return float("nan")
    return float(np.dot(x, y) / (nx * ny))


def parse_schemes(text):
    # "0.5:0,0.25;1:0,0.5;2:0,1;4:0,2"
    out = []
    for chunk in str(text).split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        w, offs = chunk.split(":", 1)
        width = float(w.strip())
        for o in offs.split(","):
            o = o.strip()
            if o:
                out.append((width, float(o)))
    return out


def scheme_key(width, offset):
    return f"W{width:g}_O{offset:g}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v123-prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--k-start", type=int, default=1088)
    ap.add_argument("--k-end", type=int, default=1407)
    ap.add_argument("--integer-chunk", type=int, default=4096)
    ap.add_argument("--alpha-min", type=float, default=-2.0)
    ap.add_argument("--alpha-max", type=float, default=2.0)
    ap.add_argument("--alpha-points", type=int, default=161)
    ap.add_argument(
        "--schemes",
        default="0.5:0,0.25;1:0,0.5;2:0,1;4:0,2",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_weighted_l2_pnt_error_v128",
    )
    args = ap.parse_args()

    schemes = parse_schemes(args.schemes)
    if not schemes:
        raise ValueError("No localization schemes.")

    cells_path = Path(
        str(Path(args.v123_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rows = sorted(
        [
            r for r in raw
            if args.k_start <= int(float(r["k"])) <= args.k_end
        ],
        key=lambda r: int(float(r["k"])),
    )
    if len(rows) != args.k_end - args.k_start + 1:
        raise RuntimeError("Requested cell range incomplete.")

    lo = np.asarray([float(r["lo"]) for r in rows], float)
    hi = np.asarray([float(r["hi"]) for r in rows], float)
    h = hi - lo
    mid = 0.5 * (lo + hi)
    qprime_ref = np.asarray([float(r["q_prime"]) for r in rows], float)

    print("=" * 166)
    print("ROT-RH v128 — WEIGHTED L2 / CAUCHY-SCHWARZ PNT-ERROR AUDIT")
    print("=" * 166)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("L                               :", args.L)
    print("alpha range                     :",
          f"[{args.alpha_min},{args.alpha_max}] / {args.alpha_points}")
    print("localization schemes            :", len(schemes))
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 166)

    print("[1] Recover exact finite-range Lambda, psi, E=psi-n", flush=True)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    phase_w = np.asarray(phase.phase_w, float)
    logs = np.asarray(phase.logs, float)
    n_support = np.rint(np.exp(logs)).astype(int)
    lam = (
        phase_w * logs * np.sqrt(n_support.astype(float))
        * np.exp(n_support.astype(float) / float(args.L))
    )
    Nmax = int(np.max(n_support))

    lambda_integer = np.zeros(Nmax + 1, float)
    lambda_integer[n_support] = lam
    psi = np.cumsum(lambda_integer)
    Eall = psi - np.arange(Nmax + 1, dtype=float)

    print("  support terms                  :", len(n_support))
    print("  Nmax                           :", Nmax)
    print("  max |E(n)|                     :", f"{np.max(np.abs(Eall[2:])):.12e}")

    print("[2] Build full-prefix A(n)", flush=True)
    A = np.zeros(Nmax + 1, float)
    for s in range(2, Nmax + 1, int(args.integer_chunk)):
        e = min(Nmax + 1, s + int(args.integer_chunk))
        ns = np.arange(s, e, dtype=float)
        K = exact_kernel_unweighted(mid, h, ns, args.L)
        A[s:e] = np.sum(K, axis=0)
        if e == Nmax + 1 or (e - 2) % (16 * int(args.integer_chunk)) == 0:
            print(f"  integers through n={e-1}/{Nmax}", flush=True)

    direct = float(np.dot(lambda_integer[2:], A[2:]))
    stored = float(np.sum(qprime_ref))
    print("  direct Mangoldt sum            :", f"{direct:+.12e}")
    print("  stored q_prime prefix          :", f"{stored:+.12e}")
    print("  reconstruction abs diff        :", f"{abs(direct-stored):.12e}")

    n = np.arange(2, Nmax, dtype=float)
    E = Eall[2:Nmax]
    dA = A[2:Nmax] - A[3:Nmax + 1]
    boundary = float(Eall[Nmax] * A[Nmax])
    interior = float(np.dot(E, dA))
    error = boundary + interior

    print("[3] Exact PNT-error transform geometry")
    print("  boundary                       :", f"{boundary:+.12e}")
    print("  interior signed                :", f"{interior:+.12e}")
    print("  total PNT error                :", f"{error:+.12e}")
    print("  ||E||_2                        :", f"{safe_norm(E):.12e}")
    print("  ||dA||_2                       :", f"{safe_norm(dA):.12e}")
    print("  cosine(E,dA)                   :", f"{corr_cos(E,dA):+.12e}")

    global_cs = abs(boundary) + safe_norm(E) * safe_norm(dA)
    print("  unweighted CS bound            :", f"{global_cs:.12e}")
    print("  unweighted CS / |error|        :", f"{global_cs/max(abs(error),EPS):.12e}")

    print("[4] Power-weighted Cauchy-Schwarz scan")
    alphas = np.linspace(args.alpha_min, args.alpha_max, args.alpha_points)
    alpha_rows = []
    best = None

    logn = np.log(n)
    for alpha in alphas:
        # Work in log-space only for weights; the requested alpha range is safe.
        wa = np.exp(alpha * logn)
        norm_E = safe_norm(E / wa)
        norm_dA = safe_norm(dA * wa)
        bound = abs(boundary) + norm_E * norm_dA

        row = {
            "alpha": float(alpha),
            "weighted_E_norm": norm_E,
            "weighted_dA_norm": norm_dA,
            "cs_bound_with_boundary": bound,
            "bound_over_abs_error": bound / max(abs(error), EPS),
        }
        alpha_rows.append(row)
        if best is None or bound < best["cs_bound_with_boundary"]:
            best = row

    print("  best alpha                     :", f"{best['alpha']:+.6f}")
    print("  best weighted CS bound         :", f"{best['cs_bound_with_boundary']:.12e}")
    print("  best weighted CS / |error|     :", f"{best['bound_over_abs_error']:.12e}")

    print("[5] Logarithmically localized Cauchy-Schwarz")
    xlog2 = np.log2(n)
    scheme_rows = []
    group_rows = []

    for width, offset in schemes:
        name = scheme_key(width, offset)
        gid = np.floor((xlog2 - offset) / width + 1e-12).astype(int)
        ids = sorted(np.unique(gid).tolist())

        bound_sum = abs(boundary)
        abs_signed_sum = 0.0
        cos_abs_weighted_num = 0.0
        energy_weight = 0.0

        for g in ids:
            mask = (gid == g)
            Eg = E[mask]
            Dg = dA[mask]
            signed_g = float(np.dot(Eg, Dg))
            cs_g = safe_norm(Eg) * safe_norm(Dg)
            cg = corr_cos(Eg, Dg)

            bound_sum += cs_g
            abs_signed_sum += abs(signed_g)

            ew = safe_norm(Eg) * safe_norm(Dg)
            if np.isfinite(cg):
                cos_abs_weighted_num += abs(cg) * ew
                energy_weight += ew

            lower = offset + g * width
            upper = lower + width
            group_rows.append({
                "scheme": name,
                "width": width,
                "offset": offset,
                "group_id": int(g),
                "log2n_lo": lower,
                "log2n_hi": upper,
                "point_count": int(np.sum(mask)),
                "signed_error_contribution": signed_g,
                "cs_bound": cs_g,
                "signed_over_cs": abs(signed_g) / max(cs_g, EPS),
                "cosine_E_dA": cg,
            })

        row = {
            "scheme": name,
            "width": width,
            "offset": offset,
            "group_count": len(ids),
            "localized_cs_bound_with_boundary": bound_sum,
            "localized_bound_over_abs_error":
                bound_sum / max(abs(error), EPS),
            "sum_abs_group_signed_contributions": abs_signed_sum,
            "cross_group_signed_cancellation_ratio":
                abs(interior) / max(abs_signed_sum, EPS),
            "energy_weighted_mean_abs_cosine":
                cos_abs_weighted_num / max(energy_weight, EPS),
        }
        scheme_rows.append(row)

        print(
            f"  {name:<12s}: "
            f"groups={len(ids):<3d} "
            f"CS={bound_sum:.3e} "
            f"/err={row['localized_bound_over_abs_error']:.2e} "
            f"groupCancel={row['cross_group_signed_cancellation_ratio']:.3f} "
            f"<|cos|>={row['energy_weighted_mean_abs_cosine']:.3e}"
        )

    best_scheme = min(
        scheme_rows,
        key=lambda r: r["localized_cs_bound_with_boundary"]
    )

    print("[6] Correlation-strength summary")
    # Interior error orthogonality factor.
    interior_cs = safe_norm(E) * safe_norm(dA)
    interior_cos = abs(interior) / max(interior_cs, EPS)

    # How much theorem improvement is needed to get to final staircase scale?
    target_staircase = 0.02137105374871
    best_norm_bound = min(
        best["cs_bound_with_boundary"],
        best_scheme["localized_cs_bound_with_boundary"],
    )

    improvement_to_actual = best_norm_bound / max(abs(error), EPS)
    improvement_to_stair = best_norm_bound / target_staircase

    print("  |interior|/(||E||||dA||)      :", f"{interior_cos:.12e}")
    print("  best localized scheme          :", best_scheme["scheme"])
    print("  best localized CS              :",
          f"{best_scheme['localized_cs_bound_with_boundary']:.12e}")
    print("  best norm-only bound overall   :", f"{best_norm_bound:.12e}")
    print("  improvement needed -> |error|  :", f"{improvement_to_actual:.12e}x")
    print("  improvement needed -> C_B      :", f"{improvement_to_stair:.12e}x")

    # Conservative mechanism classification.
    if improvement_to_actual >= 100.0:
        mechanism = (
            "L2_MEAN_SQUARE_NORM_INFORMATION_IS_STRUCTURALLY_INSUFFICIENT__"
            "BILINEAR_E_TIMES_DELTA_A_CORRELATION_ESTIMATE_REQUIRED"
        )
    elif improvement_to_actual >= 10.0:
        mechanism = (
            "L2_ROUTE_HAS_SUBSTANTIAL_SLACK__CORRELATION_INPUT_STILL_REQUIRED"
        )
    else:
        mechanism = (
            "WEIGHTED_LOCALIZED_L2_ROUTE_REMAINS_PLAUSIBLE"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_ALPHA_SCAN.csv"), alpha_rows)
    write_csv(Path(str(prefix) + "_SCHEMES.csv"), scheme_rows)
    write_csv(Path(str(prefix) + "_GROUPS.csv"), group_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V128_WEIGHTED_L2_AUDIT_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "Nmax": Nmax,
        "direct_mangoldt_sum": direct,
        "pnt_error_boundary": boundary,
        "pnt_error_interior": interior,
        "pnt_error_total": error,
        "global_unweighted_cs_bound": global_cs,
        "global_unweighted_cs_over_error":
            global_cs / max(abs(error), EPS),
        "best_weighted_alpha_row": best,
        "best_localized_scheme_row": best_scheme,
        "interior_correlation_cosine_abs": interior_cos,
        "best_norm_only_bound": best_norm_bound,
        "best_norm_bound_over_actual_error": improvement_to_actual,
        "best_norm_bound_over_staircase_scale": improvement_to_stair,
        "interpretation": (
            "If the optimized/global or localized Cauchy-Schwarz estimates "
            "remain far above the signed PNT-error transform, then even "
            "mean-square control of psi(x)-x is not enough by itself. The "
            "missing theorem is a bilinear correlation estimate exploiting "
            "the relative phase between E(n)=psi(n)-n and the oscillatory "
            "kernel increment Delta A(n)."
        ),
    }

    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 166)
    print("FINAL v128 VERDICT")
    print("=" * 166)
    print("verdict                         : PASS_V128_WEIGHTED_L2_AUDIT_COMPLETE")
    print("mechanism                       :", mechanism)
    print("PNT error                       :", f"{error:+.12e}")
    print("unweighted CS / |error|         :",
          f"{global_cs/max(abs(error),EPS):.12e}")
    print("best weighted alpha             :", f"{best['alpha']:+.6f}")
    print("best weighted CS / |error|      :",
          f"{best['bound_over_abs_error']:.12e}")
    print("best localized scheme           :", best_scheme["scheme"])
    print("best localized CS / |error|     :",
          f"{best_scheme['localized_bound_over_abs_error']:.12e}")
    print("|cos(E,dA)|                     :", f"{interior_cos:.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 166)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
