#!/usr/bin/env python3
"""
ROT-RH v138 — PROSPECTIVE LOW-MODE CUTOFF CONTINUATION: 256k -> 512k

Purpose
-------
Test the next fixed-mode cutoff endpoint without rebuilding the full
1408-level operator.

Inputs
------
1. v132 ROOTS.npz, containing the full dyadic history through L=128000.
2. v137 ENDPOINT.npz, containing the low-mode endpoint at L=256000.

The script:
  * freezes a prospective prediction for the next low-mode contraction,
  * builds the zero-blind renormalized phase only at L=512000,
  * continues/refines the first N low modes,
  * compares 128k->256k against 256k->512k modewise and in bands,
  * reports whether the previously observed p~0.30 low-mode envelope survives.

No Xi, zeta, or known-zero data are used.

Mathematical quantity
---------------------
lambda_k(L) = E_k(L)^(-2)

For a mode set S,

    T_S(L,2L) = sum_{k in S} |lambda_k(2L)-lambda_k(L)|.

The prospective low-mode prediction is

    T_{1:16}(256k,512k) / T_{1:16}(128k,256k) ~= 0.812,

equivalent to p ~= 0.30.

Outputs
-------
<prefix>_MODES.csv
<prefix>_BANDS.csv
<prefix>_ENDPOINT.npz
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from scipy.optimize import brentq
except Exception:
    brentq = None


# ----------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------

def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return

    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty upstream phase-function output.")
    return float(a[0])


def local_p(prev_abs, new_abs):
    if prev_abs <= 0 or new_abs <= 0:
        return np.nan
    return float(-math.log(new_abs / prev_abs, 2.0))


def safe_ratio(a, b):
    return float(a / b) if np.isfinite(a) and np.isfinite(b) and b > 0 else np.nan


def refine_root(
    phase,
    x0,
    target,
    left,
    right,
    max_iter,
    tol,
    max_step,
):
    def g(x):
        return scalar_call(phase.F, x) - target

    def gp(x):
        return scalar_call(phase.Fprime, x)

    x = float(x0)
    left = float(left)
    right = float(right)

    # Safeguarded Newton.
    for _ in range(max_iter):
        fx = g(x)
        if abs(fx) <= tol:
            return x, abs(fx), "newton"

        d = gp(x)
        if not np.isfinite(d) or abs(d) < 1e-14:
            break

        step = float(np.clip(fx / d, -max_step, max_step))
        xn = x - step

        if not np.isfinite(xn) or not (left < xn < right):
            xn = 0.5 * (left + right)

        fn = g(xn)

        # F is expected to be locally increasing at the crossing.
        # Maintain the bracket conservatively when possible.
        if np.isfinite(fn):
            if fn < 0:
                left = max(left, xn)
            elif fn > 0:
                right = min(right, xn)

        if abs(xn - x) <= 1e-15 * max(1.0, abs(x)):
            x = xn
            break

        x = xn

    fx = g(x)
    if abs(fx) <= max(10.0 * tol, 1e-11):
        return x, abs(fx), "newton_loose"

    # Local Brent fallback.
    if brentq is not None:
        gl = g(left)
        gr = g(right)
        if np.isfinite(gl) and np.isfinite(gr) and gl * gr <= 0:
            xr = brentq(
                g,
                left,
                right,
                xtol=tol,
                rtol=1e-13,
                maxiter=100,
            )
            return float(xr), abs(g(xr)), "brentq"

    return x, abs(fx), "failed"


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
        help="Full v132 roots through L=128000.",
    )
    ap.add_argument(
        "--prev-endpoint-npz",
        default="rot_rh_low_mode_endpoint_v137_ENDPOINT.npz",
        help="v137 low-mode endpoint at L=256000.",
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--L-new", type=int, default=512000)
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=16)
    ap.add_argument("--root-tol", type=float, default=2e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument(
        "--bracket-fraction",
        type=float,
        default=0.45,
        help="Fraction of neighboring root spacing used for local brackets.",
    )

    ap.add_argument("--focus-modes", default="9,10,13,14")
    ap.add_argument("--bands", default="1,16,32")

    # Freeze the prospective prediction before looking at L_new.
    ap.add_argument(
        "--prediction-low-ratio",
        type=float,
        default=0.812,
        help="Frozen prospective prediction for modes 1..16.",
    )
    ap.add_argument(
        "--prediction-tolerance",
        type=float,
        default=0.10,
        help="Absolute allowed deviation from the frozen ratio for a prediction hit.",
    )

    ap.add_argument("--contraction-gate", type=float, default=0.95)
    ap.add_argument("--expansion-gate", type=float, default=1.05)

    ap.add_argument(
        "--prefix",
        default="rot_rh_low_mode_endpoint_v138",
    )

    args = ap.parse_args()

    focus = csv_ints(args.focus_modes)
    band_ends = sorted(set(csv_ints(args.bands)))

    # ------------------------------------------------------------------
    # Load 128k history from v132
    # ------------------------------------------------------------------
    z = np.load(args.base_roots_npz)
    Lbase = np.asarray(z["L"], dtype=int)
    Rbase = np.asarray(z["roots"], dtype=float)

    # ------------------------------------------------------------------
    # Load 256k endpoint from v137
    # ------------------------------------------------------------------
    e = np.load(args.prev_endpoint_npz)

    L_prev_arr = np.asarray(e["L_new"]).reshape(-1)
    if len(L_prev_arr) != 1:
        raise RuntimeError("prev endpoint NPZ has invalid L_new.")
    L_prev = int(L_prev_arr[0])

    rprev_ep = np.asarray(e["roots_new"], dtype=float)
    lam_prev_ep = (
        np.asarray(e["lambda_new"], dtype=float)
        if "lambda_new" in e
        else 1.0 / rprev_ep**2
    )

    if args.L_new != 2 * L_prev:
        print(
            f"WARNING: requested L_new={args.L_new} is not exactly "
            f"2 * previous endpoint {L_prev}."
        )

    L_prev2 = L_prev // 2
    hit = np.where(Lbase == L_prev2)[0]
    if not len(hit):
        raise RuntimeError(
            f"Need L={L_prev2} in base roots NPZ to compare the previous dyadic step."
        )
    i_prev2 = int(hit[0])

    n = min(
        args.modes,
        len(rprev_ep),
        Rbase.shape[1],
    )
    if n < 2:
        raise RuntimeError("Need at least two modes.")

    rprev2 = Rbase[i_prev2, :n].copy()
    rprev = rprev_ep[:n].copy()

    # Current endpoint spacings are available only through mode n.
    # For local bracketing of the last mode, use its left spacing as proxy.
    gaps = np.diff(rprev)

    print("=" * 126)
    print("ROT-RH v138 — PROSPECTIVE LOW-MODE CUTOFF CONTINUATION")
    print("=" * 126)
    print("Xi / zeta / known zeros          : NONE")
    print(f"previous dyadic interval          : {L_prev2} -> {L_prev}")
    print(f"new dyadic interval               : {L_prev} -> {args.L_new}")
    print(f"modes continued                   : 1..{n}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print(
        f"FROZEN prediction modes 1..16    : ratio ~= "
        f"{args.prediction_low_ratio:.6f} +/- {args.prediction_tolerance:.6f}"
    )
    print("=" * 126)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print(f"[L={args.L_new}] building RenormalizedPhase ...", flush=True)
    phase = v102.RenormalizedPhase.build(
        base,
        int(args.L_new),
        float(args.tail_factor),
        int(args.counter_q),
    )
    print("[phase] built; continuing low roots only ...", flush=True)

    # Linear extrapolation from 128k -> 256k for the new seed.
    seed = rprev + (rprev - rprev2)

    rnew = np.empty(n, dtype=float)
    residual = np.empty(n, dtype=float)
    methods = []

    for j in range(n):
        if j == 0:
            local_gap = gaps[0]
            left = max(
                1e-8,
                float(rprev[j] - args.bracket_fraction * local_gap),
            )
            right = float(
                rprev[j] + args.bracket_fraction * local_gap
            )
        elif j == n - 1:
            local_gap = gaps[-1]
            left = float(
                rprev[j] - args.bracket_fraction * local_gap
            )
            right = float(
                rprev[j] + args.bracket_fraction * local_gap
            )
        else:
            left_gap = rprev[j] - rprev[j - 1]
            right_gap = rprev[j + 1] - rprev[j]
            left = float(
                rprev[j] - args.bracket_fraction * left_gap
            )
            right = float(
                rprev[j] + args.bracket_fraction * right_gap
            )

        x0 = float(seed[j])
        if not (left < x0 < right):
            x0 = float(rprev[j])

        x, res, method = refine_root(
            phase=phase,
            x0=x0,
            target=(j + 1) - 0.5,
            left=left,
            right=right,
            max_iter=args.newton_iters,
            tol=args.root_tol,
            max_step=args.max_newton_step,
        )

        rnew[j] = x
        residual[j] = res
        methods.append(method)

        if j < min(16, n) or (j + 1) in focus:
            print(
                f"k={j+1:3d} "
                f"E_256={rprev[j]:.12f} "
                f"E_512={x:.12f} "
                f"dE={x-rprev[j]:+.3e} "
                f"res={res:.2e} "
                f"{method}"
            )

    if np.any(np.diff(rnew) <= 0):
        raise RuntimeError("New roots are not strictly ordered.")

    # ------------------------------------------------------------------
    # Trace quantities
    # ------------------------------------------------------------------
    lam_prev2 = 1.0 / rprev2**2
    lam_prev = lam_prev_ep[:n]
    lam_new = 1.0 / rnew**2

    dprev = lam_prev - lam_prev2
    dnew = lam_new - lam_prev

    aprev = np.abs(dprev)
    anew = np.abs(dnew)

    mode_rows = []

    for j in range(n):
        ratio = safe_ratio(anew[j], aprev[j])
        p = local_p(float(aprev[j]), float(anew[j]))

        flip = int(
            dprev[j] != 0
            and dnew[j] != 0
            and np.sign(dprev[j]) != np.sign(dnew[j])
        )

        mode_rows.append(
            dict(
                k=j + 1,
                E_prev2=float(rprev2[j]),
                E_prev=float(rprev[j]),
                E_new=float(rnew[j]),
                root_residual=float(residual[j]),
                method=methods[j],
                previous_abs_delta_lambda=float(aprev[j]),
                new_abs_delta_lambda=float(anew[j]),
                new_to_previous_ratio=ratio,
                new_local_p=p,
                previous_signed_delta_lambda=float(dprev[j]),
                new_signed_delta_lambda=float(dnew[j]),
                latest_sign_flip=flip,
            )
        )

    write_csv(Path(args.prefix + "_MODES.csv"), mode_rows)

    # ------------------------------------------------------------------
    # Band diagnostics
    # ------------------------------------------------------------------
    band_rows = []
    start = 0

    for end in band_ends:
        end = min(end, n)
        if end <= start:
            continue

        prev_T = float(np.sum(aprev[start:end]))
        new_T = float(np.sum(anew[start:end]))
        ratio = safe_ratio(new_T, prev_T)
        p = local_p(prev_T, new_T)

        band_rows.append(
            dict(
                k_start=start + 1,
                k_end=end,
                previous_trace=prev_T,
                new_trace=new_T,
                new_to_previous_ratio=ratio,
                new_local_p=p,
            )
        )
        start = end

    if start < n:
        prev_T = float(np.sum(aprev[start:n]))
        new_T = float(np.sum(anew[start:n]))
        band_rows.append(
            dict(
                k_start=start + 1,
                k_end=n,
                previous_trace=prev_T,
                new_trace=new_T,
                new_to_previous_ratio=safe_ratio(new_T, prev_T),
                new_local_p=local_p(prev_T, new_T),
            )
        )

    write_csv(Path(args.prefix + "_BANDS.csv"), band_rows)

    # ------------------------------------------------------------------
    # Primary aggregates
    # ------------------------------------------------------------------
    low_end = min(16, n)

    T_prev_low = float(np.sum(aprev[:low_end]))
    T_new_low = float(np.sum(anew[:low_end]))
    low_ratio = safe_ratio(T_new_low, T_prev_low)
    low_p = local_p(T_prev_low, T_new_low)

    T_prev_all = float(np.sum(aprev))
    T_new_all = float(np.sum(anew))
    all_ratio = safe_ratio(T_new_all, T_prev_all)
    all_p = local_p(T_prev_all, T_new_all)

    focus_idx = [k - 1 for k in focus if 1 <= k <= n]
    T_prev_focus = (
        float(np.sum(aprev[focus_idx]))
        if focus_idx else np.nan
    )
    T_new_focus = (
        float(np.sum(anew[focus_idx]))
        if focus_idx else np.nan
    )
    focus_ratio = safe_ratio(T_new_focus, T_prev_focus)
    focus_p = local_p(T_prev_focus, T_new_focus)

    prediction_error = abs(low_ratio - args.prediction_low_ratio)
    prediction_hit = bool(
        np.isfinite(low_ratio)
        and prediction_error <= args.prediction_tolerance
    )

    if low_ratio < args.contraction_gate:
        flow_diagnosis = "LOW_MODES_CONTRACT"
    elif low_ratio > args.expansion_gate:
        flow_diagnosis = "LOW_MODES_EXPAND"
    else:
        flow_diagnosis = "LOW_MODES_NEAR_PLATEAU"

    if prediction_hit and low_ratio < args.contraction_gate:
        main_verdict = "PROSPECTIVE_P030_ENVELOPE_SUPPORTED"
    elif low_ratio < args.contraction_gate:
        main_verdict = "CONTRACTION_SUPPORTED_BUT_P030_PREDICTION_MISSED"
    elif low_ratio <= args.expansion_gate:
        main_verdict = "FIXED_MODE_CONVERGENCE_STILL_UNRESOLVED"
    else:
        main_verdict = "LOW_MODE_CONVERGENCE_CHALLENGED"

    max_res = float(np.max(residual))
    failed = [
        j + 1 for j, method in enumerate(methods)
        if method == "failed"
    ]

    np.savez_compressed(
        args.prefix + "_ENDPOINT.npz",
        L_prev=np.array([L_prev], dtype=int),
        L_new=np.array([args.L_new], dtype=int),
        roots_prev=rprev,
        roots_new=rnew,
        lambda_prev=lam_prev,
        lambda_new=lam_new,
        residuals=residual,
    )

    summary = dict(
        version=138,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        inputs=dict(
            base_roots_npz=args.base_roots_npz,
            prev_endpoint_npz=args.prev_endpoint_npz,
        ),
        previous_interval=[L_prev2, L_prev],
        new_interval=[L_prev, args.L_new],
        modes=n,
        frozen_prediction=dict(
            low_modes="1..16",
            predicted_ratio=args.prediction_low_ratio,
            tolerance=args.prediction_tolerance,
            observed_ratio=low_ratio,
            absolute_error=prediction_error,
            hit=prediction_hit,
        ),
        trace_results=dict(
            low_1_16=dict(
                previous=T_prev_low,
                new=T_new_low,
                ratio=low_ratio,
                local_p=low_p,
            ),
            all_tested=dict(
                previous=T_prev_all,
                new=T_new_all,
                ratio=all_ratio,
                local_p=all_p,
            ),
            focus_modes=dict(
                modes=focus,
                previous=T_prev_focus,
                new=T_new_focus,
                ratio=focus_ratio,
                local_p=focus_p,
            ),
        ),
        numerical_quality=dict(
            max_root_residual=max_res,
            failed_modes=failed,
        ),
        flow_diagnosis=flow_diagnosis,
        verdict=main_verdict,
        proof_status=(
            "NUMERICAL FIXED-MODE EVIDENCE ONLY. "
            "Uniform compact phase convergence and an analytic uniform "
            "summable high-k majorant remain to be proved."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal report
    # ------------------------------------------------------------------
    print()
    print("Focus modes")
    print("-" * 126)
    print(
        f"{'k':>4} "
        f"{'prev |dlam|':>15} "
        f"{'new |dlam|':>15} "
        f"{'ratio':>10} "
        f"{'p_local':>10} "
        f"{'flip':>6}"
    )

    for k in focus:
        if 1 <= k <= n:
            r = mode_rows[k - 1]
            print(
                f"{k:4d} "
                f"{r['previous_abs_delta_lambda']:15.6e} "
                f"{r['new_abs_delta_lambda']:15.6e} "
                f"{r['new_to_previous_ratio']:10.6f} "
                f"{r['new_local_p']:10.6f} "
                f"{r['latest_sign_flip']:6d}"
            )

    print()
    print("Spectral bands")
    print("-" * 126)
    for r in band_rows:
        print(
            f"k={r['k_start']:>3d}-{r['k_end']:<3d}  "
            f"prev={r['previous_trace']:.6e}  "
            f"new={r['new_trace']:.6e}  "
            f"ratio={r['new_to_previous_ratio']:.6f}  "
            f"p={r['new_local_p']:.6f}"
        )

    print()
    print("=" * 126)
    print(f"max new root residual             : {max_res:.3e}")
    print(f"failed modes                      : {failed}")
    print()
    print(
        f"modes 1..16 trace ratio           : "
        f"{low_ratio:.9f}   p={low_p:.6f}"
    )
    print(
        f"modes 1..{n} trace ratio           : "
        f"{all_ratio:.9f}   p={all_p:.6f}"
    )
    print(
        f"focus {focus} trace ratio      : "
        f"{focus_ratio:.9f}   p={focus_p:.6f}"
    )
    print()
    print(
        f"frozen prediction                 : "
        f"{args.prediction_low_ratio:.6f} +/- {args.prediction_tolerance:.6f}"
    )
    print(
        f"prediction absolute error         : "
        f"{prediction_error:.6f}"
    )
    print(
        f"prediction hit                    : "
        f"{prediction_hit}"
    )
    print(f"FLOW DIAGNOSIS                    : {flow_diagnosis}")
    print(f"VERDICT                           : {main_verdict}")
    print("=" * 126)


if __name__ == "__main__":
    main()
