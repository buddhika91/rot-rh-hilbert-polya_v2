#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v127 — PNT-Remainder Theorem-Strength / Absolute-Bound Audit
===================================================================

PURPOSE
-------
v126 found an exact Abel split for the fresh v123 prime defect:

    S = S_main + S_error,

with, for the full 320-cell prefix,

    S       ~ +4.7e-3
    S_main  ~ +4.62e-1
    S_error ~ -4.57e-1.

So a large PNT-main / PNT-error cancellation remains essential.

v127 asks a theorem-level question:

    Could a STANDARD POINTWISE bound on E(x)=psi(x)-x,
    combined with triangle inequality, possibly control S_error?

For the full spectral prefix define

    A(n) = sum_k a_k(n),

where
    S_error =
      E(N) A(N)
      + sum_{n=2}^{N-1} E(n)[A(n)-A(n+1)].

If one only knows
    |E(n)| <= C n^beta,

then rigorously

    |S_error| <= C V_beta,

where

    V_beta =
      N^beta |A(N)|
      + sum_{n=2}^{N-1} n^beta |A(n)-A(n+1)|.

v127 computes:
  * exact A(n) on every integer n;
  * exact E(n)=psi(n)-n from the zero-free Mangoldt data;
  * exact signed and absolute PNT-error transforms;
  * V_beta for beta=1/2,...,1;
  * C_actual(beta)=max |E(n)|/n^beta on the finite range;
  * the resulting finite-range triangle bound C_actual V_beta;
  * the C that WOULD be required for that pointwise method to prove
    various target bounds;
  * arithmetic-scale cancellation of the signed error transform;
  * correlation of PNT-main and PNT-error cutoff trajectories.

This does NOT assume RH and does NOT evaluate Xi/zeta/zeros.

Interpretation:
  If even beta=1/2 with the observed finite-range C_actual gives an absolute
  bound orders of magnitude larger than the desired defect scale, then a
  pointwise PNT remainder theorem alone is structurally insufficient; a proof
  must preserve oscillatory cancellation in the weighted E(n) transform.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v127"
BUILD = "2026-08-18-pnt-remainder-theorem-strength-absolute-bound-v127"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def exact_kernel_unweighted(mid, h, nvals, L):
    """
    q_{k,n}=Lambda(n)*a_k(n), with Lambda factored out.
    """
    nvals = np.asarray(nvals, float)
    logn = np.log(nvals)
    delta = 0.5*h[:, None]*logn[None, :]
    phase = mid[:, None]*logn[None, :]
    pref = (
        2.0*np.exp(-nvals/float(L))
        / (math.pi*np.sqrt(nvals)*logn*logn)
    )
    return (
        np.sin(phase)
        * (delta*np.cos(delta)-np.sin(delta))
        * pref[None, :]
    )


def corr(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v123-prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--k-start", type=int, default=1088)
    ap.add_argument("--k-end", type=int, default=1407)
    ap.add_argument(
        "--beta-grid",
        default="0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.90,1.00",
    )
    ap.add_argument(
        "--target-bounds",
        default="0.005,0.02137105374871,0.1",
        help="Desired absolute bounds for |S_error| when reporting required C.",
    )
    ap.add_argument("--integer-chunk", type=int, default=4096)
    ap.add_argument(
        "--prefix",
        default="rot_rh_pnt_remainder_strength_v127",
    )
    args = ap.parse_args()

    betas = parse_floats(args.beta_grid)
    targets = parse_floats(args.target_bounds)

    cells_path = Path(
        str(Path(args.v123_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rows = sorted(
        [
            r for r in raw
            if args.k_start <= int(float(r["k"])) <= args.k_end
        ],
        key=lambda r: int(float(r["k"])),
    )
    if len(rows) != args.k_end-args.k_start+1:
        raise RuntimeError("Requested v123 cell range incomplete.")

    lo = np.asarray([float(r["lo"]) for r in rows], float)
    hi = np.asarray([float(r["hi"]) for r in rows], float)
    h = hi-lo
    mid = 0.5*(lo+hi)
    qprime_ref = np.asarray([float(r["q_prime"]) for r in rows], float)

    print("="*166)
    print("ROT-RH v127 — PNT-REMAINDER THEOREM-STRENGTH / ABSOLUTE-BOUND AUDIT")
    print("="*166)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("L                               :", args.L)
    print("beta grid                       :", betas)
    print("target bounds                   :", targets)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("="*166)

    print("[1] Recover exact finite-range Lambda and psi", flush=True)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    w = np.asarray(phase.phase_w, float)
    logs = np.asarray(phase.logs, float)
    n_support = np.rint(np.exp(logs)).astype(int)
    lam = (
        w*logs*np.sqrt(n_support.astype(float))
        * np.exp(n_support.astype(float)/float(args.L))
    )
    Nmax = int(np.max(n_support))

    lambda_integer = np.zeros(Nmax+1, float)
    lambda_integer[n_support] = lam
    psi = np.cumsum(lambda_integer)
    nall = np.arange(Nmax+1, dtype=float)
    E = psi-nall

    print("  support terms                  :", len(n_support))
    print("  Nmax                           :", Nmax)
    print("  max |psi(n)-n|                 :", f"{np.max(np.abs(E[2:])):.12e}")
    print("  E(Nmax)                        :", f"{E[Nmax]:+.12e}")

    print("[2] Build full-prefix A(n) on every integer", flush=True)
    A = np.zeros(Nmax+1, float)

    for s in range(2, Nmax+1, int(args.integer_chunk)):
        e = min(Nmax+1, s+int(args.integer_chunk))
        ns = np.arange(s, e, dtype=float)
        K = exact_kernel_unweighted(mid, h, ns, args.L)
        A[s:e] = np.sum(K, axis=0)

        if e == Nmax+1 or (e-2) % (16*int(args.integer_chunk)) == 0:
            print(f"  integers through n={e-1}/{Nmax}", flush=True)

    # Validate direct prime prefix.
    direct = float(np.dot(lambda_integer[2:], A[2:]))
    stored = float(np.sum(qprime_ref))
    print("  direct integer Mangoldt sum    :", f"{direct:+.12e}")
    print("  stored prime prefix sum        :", f"{stored:+.12e}")
    print("  reconstruction abs diff        :", f"{abs(direct-stored):.12e}")

    print("[3] Exact Abel main/error and signed-vs-absolute error transform")
    dA = A[2:Nmax] - A[3:Nmax+1]
    n = np.arange(2, Nmax, dtype=float)

    main_terms = n*dA
    error_terms = E[2:Nmax]*dA

    main_boundary = Nmax*A[Nmax]
    error_boundary = E[Nmax]*A[Nmax]

    main = float(main_boundary + np.sum(main_terms))
    error = float(error_boundary + np.sum(error_terms))
    signed = main+error

    main_l1 = float(abs(main_boundary)+np.sum(np.abs(main_terms)))
    error_l1 = float(abs(error_boundary)+np.sum(np.abs(error_terms)))

    print("  PNT main                       :", f"{main:+.12e}")
    print("  PNT error                      :", f"{error:+.12e}")
    print("  total                          :", f"{signed:+.12e}")
    print("  main absolute variation        :", f"{main_l1:.12e}")
    print("  error absolute variation       :", f"{error_l1:.12e}")
    print("  error signed/L1 ratio          :", f"{abs(error)/max(error_l1,EPS):.12e}")
    print("  total/(|main|+|error|)         :",
          f"{abs(signed)/max(abs(main)+abs(error),EPS):.12e}")

    print("[4] Pointwise-power envelope theorem audit")
    beta_rows = []
    for beta in betas:
        nb = n**beta
        V = float(
            (Nmax**beta)*abs(A[Nmax])
            + np.sum(nb*np.abs(dA))
        )
        Cactual = float(
            np.max(np.abs(E[2:]) /
                   (np.arange(2, Nmax+1, dtype=float)**beta))
        )
        triangle = Cactual*V

        row = {
            "beta": beta,
            "V_beta": V,
            "C_actual_finite_range": Cactual,
            "Cactual_times_Vbeta": triangle,
            "triangle_over_abs_actual_error":
                triangle/max(abs(error), EPS),
            "triangle_over_0p021371":
                triangle/0.02137105374871,
        }
        for target in targets:
            row[f"C_required_for_target_{target:g}"] = (
                target/max(V, EPS)
            )
            row[f"Cactual_over_Crequired_target_{target:g}"] = (
                Cactual /
                max(target/max(V, EPS), EPS)
            )
        beta_rows.append(row)

        print(
            f"  beta={beta:.2f}: "
            f"V={V:.3e} "
            f"Cactual={Cactual:.3e} "
            f"C*V={triangle:.3e} "
            f"/actualErr={triangle/max(abs(error),EPS):.2e}"
        )

    print("[5] Arithmetic-scale structure of the PNT-error transform")
    # Group signed error contributions by dyadic n. Boundary goes in final band.
    band_rows = []
    jmin = 1
    jmax = int(math.floor(math.log(Nmax, 2.0)))
    abs_band_sum = 0.0
    signed_band_sum = 0.0

    # c_n corresponds to n=2..Nmax-1.
    for j in range(jmin, jmax+1):
        a = max(2, 2**j)
        b = min(Nmax-1, 2**(j+1)-1)
        if a > b:
            continue
        sl0 = a-2
        sl1 = b-2+1
        val = float(np.sum(error_terms[sl0:sl1]))
        l1 = float(np.sum(np.abs(error_terms[sl0:sl1])))

        # Add boundary if Nmax belongs to this dyadic band.
        if 2**j <= Nmax < 2**(j+1):
            val += error_boundary
            l1 += abs(error_boundary)

        abs_band_sum += abs(val)
        signed_band_sum += val
        band_rows.append({
            "band_j": j,
            "n_lo": a,
            "n_hi": b,
            "signed_error_contribution": val,
            "absolute_term_variation": l1,
            "signed_over_l1": abs(val)/max(l1,EPS),
        })
        print(
            f"  2^{j:<2d}: "
            f"signed={val:+.3e} "
            f"L1={l1:.3e} "
            f"ratio={abs(val)/max(l1,EPS):.3e}"
        )

    cross_band_error_ratio = abs(error)/max(abs_band_sum, EPS)
    print("  sum |band signed error|        :", f"{abs_band_sum:.12e}")
    print("  final |error|                  :", f"{abs(error):.12e}")
    print("  cross-band error ratio         :", f"{cross_band_error_ratio:.12e}")

    print("[6] Main/error cutoff-trajectory anti-alignment")
    # Build cumulative exact direct, main, error at every arithmetic N.
    # Main(N)=2A(2)+sum_{3..N} A(n).
    direct_cum = np.cumsum(lambda_integer*A)
    main_cum = np.zeros(Nmax+1, float)
    if Nmax >= 2:
        main_cum[2] = 2.0*A[2]
    if Nmax >= 3:
        main_cum[3:] = 2.0*A[2] + np.cumsum(A[3:])
    error_cum = direct_cum-main_cum

    # Use log-spaced cutoff samples so the huge dense tail doesn't dominate.
    cuts = np.unique(
        np.clip(
            np.rint(np.geomspace(2, Nmax, 512)).astype(int),
            2, Nmax
        )
    )
    mc = main_cum[cuts]
    ec = error_cum[cuts]
    dc = direct_cum[cuts]

    anti_corr = corr(mc, -ec)
    trajectory_ratio = float(
        np.linalg.norm(dc) /
        max(np.linalg.norm(mc)+np.linalg.norm(ec), EPS)
    )

    print("  corr(main cutoff,-error cutoff):", f"{anti_corr:.12e}")
    print("  trajectory cancellation ratio  :", f"{trajectory_ratio:.12e}")

    cutoff_rows = [
        {
            "N": int(N),
            "direct": float(direct_cum[N]),
            "main": float(main_cum[N]),
            "error": float(error_cum[N]),
        }
        for N in cuts
    ]

    # Conservative classification.
    beta_half = min(beta_rows, key=lambda r: abs(r["beta"]-0.5))
    absolute_rh_like_fails = (
        beta_half["Cactual_times_Vbeta"] >
        10.0*max(abs(error), 0.02137105374871)
    )
    delicate_main_error = (
        abs(signed)/max(abs(main)+abs(error),EPS) <= 0.02
    )

    if absolute_rh_like_fails and delicate_main_error:
        mechanism = (
            "POINTWISE_PNT_REMAINDER_PLUS_TRIANGLE_INEQUALITY_IS_STRUCTURALLY_INSUFFICIENT__"
            "WEIGHTED_SIGNED_ERROR_CANCELLATION_REQUIRED"
        )
    elif delicate_main_error:
        mechanism = (
            "MAIN_ERROR_CANCELLATION_REQUIRED_BUT_POINTWISE_BOUND_SLACK_MODERATE"
        )
    else:
        mechanism = (
            "ABSOLUTE_PNT_REMAINDER_ROUTE_NOT_YET_RULED_OUT"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix)+"_BETA_AUDIT.csv"), beta_rows)
    write_csv(Path(str(prefix)+"_ERROR_BANDS.csv"), band_rows)
    write_csv(Path(str(prefix)+"_CUTOFF_TRAJECTORY.csv"), cutoff_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V127_PNT_REMAINDER_STRENGTH_AUDIT_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "Nmax": Nmax,
        "direct": direct,
        "pnt_main": main,
        "pnt_error": error,
        "pnt_main_l1_variation": main_l1,
        "pnt_error_l1_variation": error_l1,
        "pnt_error_signed_over_l1": abs(error)/max(error_l1,EPS),
        "main_error_cancellation_ratio":
            abs(signed)/max(abs(main)+abs(error),EPS),
        "beta_rows": beta_rows,
        "cross_band_error_ratio": cross_band_error_ratio,
        "cutoff_main_minus_error_correlation": anti_corr,
        "cutoff_trajectory_cancellation_ratio": trajectory_ratio,
        "interpretation": (
            "This audit does not assert an equivalence to RH. It tests whether "
            "a proof based only on a pointwise PNT remainder envelope and "
            "triangle inequality could retain the numerically observed "
            "cancellation. If the beta=1/2 absolute bound is already far too "
            "large, then even RH-quality pointwise size information would not "
            "by itself prove the desired weighted estimate; one needs signed "
            "oscillatory information about E(n)=psi(n)-n against Delta A(n)."
        ),
    }

    out = Path(str(prefix)+"_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n"+"="*166)
    print("FINAL v127 VERDICT")
    print("="*166)
    print("verdict                         : PASS_V127_PNT_REMAINDER_STRENGTH_AUDIT_COMPLETE")
    print("mechanism                       :", mechanism)
    print("PNT main                        :", f"{main:+.12e}")
    print("PNT error                       :", f"{error:+.12e}")
    print("main/error cancellation ratio   :",
          f"{abs(signed)/max(abs(main)+abs(error),EPS):.12e}")
    print("error signed/L1 ratio           :",
          f"{abs(error)/max(error_l1,EPS):.12e}")
    print("beta=0.5 absolute bound         :",
          f"{beta_half['Cactual_times_Vbeta']:.12e}")
    print("beta=0.5 bound / actual error   :",
          f"{beta_half['triangle_over_abs_actual_error']:.12e}")
    print("corr(main,-error) cutoff        :", f"{anti_corr:.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("="*166)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
