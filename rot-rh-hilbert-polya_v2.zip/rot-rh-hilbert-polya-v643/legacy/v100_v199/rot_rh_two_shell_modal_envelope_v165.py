#!/usr/bin/env python3
"""
ROT-RH v165 — TWO-SHELL MODAL ENVELOPE DECAY EXTENSION AUDIT

Purpose
-------
v164 showed that all previously problematic watch modes turned over at least
once, but shell-to-shell micromotion remains.  Strict monotone decay of every
adjacent increment is therefore too brittle a diagnostic.

For convergence of each fixed operator eigenvalue

    lambda_k(L_j) = E_k(L_j)^(-2),

the adjacent increments

    a_{j,k} = |lambda_k(L_{j+1}) - lambda_k(L_j)|

must tend to zero.  With oscillatory micromotion, a more robust necessary
finite-range diagnostic is contraction of a LOCAL ENVELOPE.

v165 appends two new sqrt(2)-spaced cutoffs and compares the latest two-shell
modal envelope with the preceding two-shell envelope:

    W_old(k) = max(a_{J-3,k}, a_{J-2,k})
    W_new(k) = max(a_{J-1,k}, a_{J,k})

and asks whether

    W_new(k) / W_old(k) < 1.

This directly tests whether the oscillatory amplitude envelope is shrinking,
rather than demanding monotonicity shell by shell.

Default extension
-----------------
Existing v164 endpoint:
    5,792,619

New cutoffs:
    8,192,000
   11,585,238

The script continues all first N moving roots, because phase construction is
the dominant cost, then reports:
  * root residuals and local transversality;
  * adjacent finite-block trace increments;
  * two-shell modal envelope ratios;
  * aggregate sum of modal envelopes;
  * unresolved-watch-mode envelope contraction;
  * updated power/local-alpha diagnostics.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_ROOTS.npz
<prefix>_SHELLS.csv
<prefix>_MODES.csv
<prefix>_WATCH.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
except Exception as exc:
    raise RuntimeError("scipy.optimize.brentq is required") from exc


def csv_ints(s):
    if s is None or not str(s).strip():
        return []
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)
    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass
    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def build_phase(v102, base, L, tail_factor, counter_q):
    with warnings.catch_warnings(record=True) as wrn:
        warnings.simplefilter("always")
        ph = v102.RenormalizedPhase.build(
            base,
            int(L),
            float(tail_factor),
            int(counter_q),
        )
    return ph, [str(w.message) for w in wrn]


def refine_root(
    phase,
    target,
    x0,
    newton_iters,
    tol,
    max_step,
    bracket_initial,
    bracket_max,
):
    x = float(x0)

    for _ in range(newton_iters):
        f = scalar_call(phase.F, x) - target
        if abs(f) <= tol:
            return x, abs(f), "newton"

        fp = scalar_call(phase.Fprime, x)
        if (not np.isfinite(fp)) or abs(fp) < 1e-12:
            break

        step = float(np.clip(-f/fp, -max_step, max_step))
        xn = x + step
        if not np.isfinite(xn) or xn <= 0:
            break
        x = xn

    def ff(xx):
        return scalar_call(phase.F, xx) - target

    radius = bracket_initial
    while radius <= bracket_max:
        a = max(1e-8, x0-radius)
        b = x0+radius
        fa = ff(a)
        fb = ff(b)
        if np.isfinite(fa) and np.isfinite(fb) and fa*fb <= 0:
            root = float(brentq(
                ff, a, b,
                xtol=tol,
                rtol=1e-13,
                maxiter=200,
            ))
            return root, abs(ff(root)), "brent"
        radius *= 1.6

    return x, abs(ff(x)), "failed"


def segment_min_derivative(phase, x1, x2, samples):
    xs = np.linspace(float(x1), float(x2), samples)
    vals = np.abs(vector_call(phase.Fprime, xs))
    return float(np.min(vals))


def fit_power(Lleft, y):
    Lleft = np.asarray(Lleft, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (Lleft > 0) & (y > 0) & np.isfinite(y)

    X = np.log(Lleft[mask])
    Y = np.log(y[mask])

    if len(X) < 2:
        return np.nan, np.nan

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    alpha = float(-coef[1])

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, r2


def latest_alpha(Lleft, y):
    if len(y) < 2 or y[-1] <= 0 or y[-2] <= 0:
        return np.nan
    return float(
        -math.log(y[-1]/y[-2])
        / math.log(Lleft[-1]/Lleft[-2])
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v164-roots-npz",
        default="rot_rh_persistent_modal_turnover_v164_ROOTS.npz",
    )
    ap.add_argument(
        "--v164-modes-csv",
        default="rot_rh_persistent_modal_turnover_v164_MODES.csv",
    )
    ap.add_argument(
        "--new-cutoffs",
        default="8192000,11585238",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--root-tol", type=float, default=1e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument("--bracket-initial", type=float, default=0.05)
    ap.add_argument("--bracket-max", type=float, default=1.0)
    ap.add_argument("--segment-samples", type=int, default=17)

    ap.add_argument("--root-residual-gate", type=float, default=1e-8)
    ap.add_argument("--transversality-gate", type=float, default=0.05)

    ap.add_argument(
        "--minimum-all-mode-envelope-contraction-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--minimum-watch-envelope-contraction-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--aggregate-envelope-ratio-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_two_shell_modal_envelope_v165",
    )

    args = ap.parse_args()

    z = np.load(args.v164_roots_npz)
    old_L = np.asarray(z["L"], dtype=int)
    old_roots = np.asarray(z["roots"], dtype=float)

    n = min(args.modes, old_roots.shape[1])
    old_roots = old_roots[:, :n]

    new_cutoffs = csv_ints(args.new_cutoffs)
    if len(new_cutoffs) != 2:
        raise RuntimeError(
            "v165 is designed for exactly two new cutoff endpoints."
        )
    if any(L <= old_L[-1] for L in new_cutoffs):
        raise RuntimeError(
            f"All new cutoffs must exceed existing endpoint {old_L[-1]}."
        )
    if new_cutoffs[1] <= new_cutoffs[0]:
        raise RuntimeError("--new-cutoffs must be strictly increasing.")

    m164 = pd.read_csv(args.v164_modes_csv)
    m164 = m164[m164["k"] <= n].copy()

    if "watch_mode" not in m164.columns:
        raise RuntimeError("v164 modes CSV must contain watch_mode.")

    # Focus on watch modes that had NOT sustained turnover, plus any watch mode
    # whose latest local alpha was nonpositive.
    unresolved = m164[
        m164["watch_mode"].astype(bool)
        & (
            (~m164["sustained_turnover"].astype(bool))
            | (m164["latest_local_alpha"] <= 0)
        )
    ]["k"].astype(int).tolist()

    all_watch = m164[
        m164["watch_mode"].astype(bool)
    ]["k"].astype(int).tolist()

    print("=" * 152)
    print("ROT-RH v165 — TWO-SHELL MODAL ENVELOPE DECAY EXTENSION AUDIT")
    print("=" * 152)
    print("Xi / zeta / known zeros          : NONE")
    print(f"existing endpoint                 : {old_L[-1]}")
    print(f"new cutoffs                       : {new_cutoffs}")
    print(f"modes                             : 1..{n}")
    print(f"all v164 watch modes              : {all_watch}")
    print(f"still unresolved watch modes      : {unresolved}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 152)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}

    def get_phase(L):
        if L not in phases:
            print(f"[L={L}] building RenormalizedPhase ...", flush=True)
            ph, wrn = build_phase(
                v102, base, L,
                args.tail_factor, args.counter_q
            )
            phases[L] = ph
            if wrn:
                print(f"[L={L}] {len(wrn)} warning(s)")
                for msg in wrn[:2]:
                    print(f"         warning: {msg}")
        return phases[L]

    targets = np.arange(1, n+1, dtype=float)-0.5

    all_L = old_L.tolist()
    roots_list = [old_roots[i].copy() for i in range(len(old_L))]

    prev_L = int(old_L[-1])
    prev_roots = old_roots[-1].copy()

    new_diag = []

    for L in new_cutoffs:
        print()
        print(f"[track {prev_L}->{L}] continuing {n} roots ...", flush=True)
        ph = get_phase(L)

        new_roots = np.empty(n, dtype=float)
        residuals = np.empty(n, dtype=float)
        methods = []

        for j in range(n):
            root, res, method = refine_root(
                ph,
                targets[j],
                prev_roots[j],
                args.newton_iters,
                args.root_tol,
                args.max_newton_step,
                args.bracket_initial,
                args.bracket_max,
            )
            new_roots[j] = root
            residuals[j] = res
            methods.append(method)

        mins = np.array([
            segment_min_derivative(
                ph,
                prev_roots[j],
                new_roots[j],
                args.segment_samples,
            )
            for j in range(n)
        ])

        old_lam = prev_roots**(-2)
        new_lam = new_roots**(-2)
        dlam = new_lam-old_lam

        row = dict(
            L=prev_L,
            M=L,
            max_root_residual=float(np.max(residuals)),
            min_segment_abs_Fprime=float(np.min(mins)),
            trace_increment=float(np.sum(np.abs(dlam))),
            max_modal_increment=float(np.max(np.abs(dlam))),
            median_modal_increment=float(np.median(np.abs(dlam))),
            newton_count=int(sum(m=="newton" for m in methods)),
            brent_count=int(sum(m=="brent" for m in methods)),
            failed_count=int(sum(m=="failed" for m in methods)),
        )
        new_diag.append(row)

        print(
            f"          max residual={row['max_root_residual']:.3e}  "
            f"min|F_E|={row['min_segment_abs_Fprime']:.6f}  "
            f"trace inc={row['trace_increment']:.6e}  "
            f"max mode={row['max_modal_increment']:.6e}"
        )

        all_L.append(L)
        roots_list.append(new_roots.copy())
        prev_L = L
        prev_roots = new_roots

    all_L = np.asarray(all_L, dtype=int)
    roots = np.vstack(roots_list)
    lam = roots**(-2)

    dlam = lam[1:]-lam[:-1]
    abs_dlam = np.abs(dlam)
    shell_left = all_L[:-1].astype(float)

    nshell = len(all_L)-1

    if nshell < 4:
        raise RuntimeError("Need at least four adjacent shells.")

    # The two old comparison shells are immediately before the two new shells.
    old_idx = [nshell-4, nshell-3]
    new_idx = [nshell-2, nshell-1]

    # ------------------------------------------------------------------
    # shell table
    # ------------------------------------------------------------------
    shell_rows = []

    for j in range(nshell):
        trace = float(np.sum(abs_dlam[j]))
        maxm = float(np.max(abs_dlam[j]))
        medm = float(np.median(abs_dlam[j]))

        if j == 0:
            tr_ratio = np.nan
            max_ratio = np.nan
            med_ratio = np.nan
            contract_frac = np.nan
            flip_frac = np.nan
        else:
            tr_ratio = trace/max(shell_rows[-1]["trace_increment"],1e-300)
            max_ratio = maxm/max(shell_rows[-1]["max_modal_increment"],1e-300)
            med_ratio = medm/max(shell_rows[-1]["median_modal_increment"],1e-300)
            contract_frac = float(np.mean(abs_dlam[j] < abs_dlam[j-1]))
            flip_frac = float(
                np.mean(np.sign(dlam[j]) != np.sign(dlam[j-1]))
            )

        shell_rows.append(dict(
            shell=j+1,
            L=int(all_L[j]),
            M=int(all_L[j+1]),
            trace_increment=trace,
            trace_ratio=tr_ratio,
            max_modal_increment=maxm,
            max_modal_ratio=max_ratio,
            median_modal_increment=medm,
            median_modal_ratio=med_ratio,
            modal_contraction_fraction=contract_frac,
            sign_flip_fraction=flip_frac,
            is_new_shell=bool(j in new_idx),
        ))

    # ------------------------------------------------------------------
    # modal two-shell envelope test
    # ------------------------------------------------------------------
    mode_rows = []

    for k in range(n):
        y = abs_dlam[:,k]

        old_env = float(np.max(y[old_idx]))
        new_env = float(np.max(y[new_idx]))
        env_ratio = new_env/max(old_env,1e-300)

        alpha, r2 = fit_power(shell_left, y)
        la = latest_alpha(shell_left, y)

        mode_rows.append(dict(
            k=k+1,
            old_two_shell_envelope=old_env,
            new_two_shell_envelope=new_env,
            envelope_ratio=env_ratio,
            envelope_contracts=bool(env_ratio < 1.0),
            power_alpha=alpha,
            power_R2=r2,
            latest_local_alpha=la,
            latest_increment=float(y[-1]),
            previous_increment=float(y[-2]),
            latest_shell_contracts=bool(y[-1] < y[-2]),
            watch_mode=bool((k+1) in all_watch),
            unresolved_watch_mode=bool((k+1) in unresolved),
        ))

    modes_df = pd.DataFrame(mode_rows)

    all_contract_fraction = float(
        np.mean(modes_df["envelope_contracts"].to_numpy(dtype=bool))
    )

    watch_df = modes_df[modes_df["watch_mode"]].copy()
    unresolved_df = modes_df[modes_df["unresolved_watch_mode"]].copy()

    watch_contract_fraction = (
        float(np.mean(watch_df["envelope_contracts"].to_numpy(dtype=bool)))
        if len(watch_df) else np.nan
    )

    unresolved_contract_fraction = (
        float(np.mean(
            unresolved_df["envelope_contracts"].to_numpy(dtype=bool)
        ))
        if len(unresolved_df) else np.nan
    )

    aggregate_old_env = float(np.sum(np.max(abs_dlam[old_idx,:],axis=0)))
    aggregate_new_env = float(np.sum(np.max(abs_dlam[new_idx,:],axis=0)))
    aggregate_env_ratio = aggregate_new_env/max(aggregate_old_env,1e-300)

    max_old_env = float(np.max(np.max(abs_dlam[old_idx,:],axis=0)))
    max_new_env = float(np.max(np.max(abs_dlam[new_idx,:],axis=0)))
    max_env_ratio = max_new_env/max(max_old_env,1e-300)

    residual_ok = all(
        r["max_root_residual"] <= args.root_residual_gate for r in new_diag
    )
    transverse_ok = all(
        r["min_segment_abs_Fprime"] >= args.transversality_gate
        for r in new_diag
    )

    envelope_pass = bool(
        all_contract_fraction
            >= args.minimum_all_mode_envelope_contraction_fraction
        and
        watch_contract_fraction
            >= args.minimum_watch_envelope_contraction_fraction
        and
        aggregate_env_ratio <= args.aggregate_envelope_ratio_gate
    )

    if residual_ok and transverse_ok and envelope_pass:
        verdict = "OSCILLATORY_MODAL_ENVELOPE_DECAY_STRONGLY_SUPPORTED"
    elif residual_ok and transverse_ok and aggregate_env_ratio < 1.0:
        verdict = "MODAL_ENVELOPE_DECAY_PARTIAL_MORE_RANGE_NEEDED"
    else:
        verdict = "MODAL_ENVELOPE_DECAY_UNRESOLVED"

    # ------------------------------------------------------------------
    # save
    # ------------------------------------------------------------------
    np.savez_compressed(
        args.prefix + "_ROOTS.npz",
        L=all_L,
        roots=roots,
        targets=targets,
    )

    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )
    modes_df.to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    watch_df.to_csv(
        args.prefix + "_WATCH.csv", index=False
    )

    summary = dict(
        version=165,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoffs=all_L.tolist(),
        modes=n,
        unresolved_watch_modes=unresolved,
        comparison_shell_indices=dict(
            old=[int(x+1) for x in old_idx],
            new=[int(x+1) for x in new_idx],
        ),
        fractions=dict(
            all_mode_envelope_contraction=all_contract_fraction,
            watch_mode_envelope_contraction=watch_contract_fraction,
            unresolved_watch_envelope_contraction=unresolved_contract_fraction,
        ),
        envelope_summary=dict(
            aggregate_old=aggregate_old_env,
            aggregate_new=aggregate_new_env,
            aggregate_ratio=aggregate_env_ratio,
            max_old=max_old_env,
            max_new=max_new_env,
            max_ratio=max_env_ratio,
        ),
        root_residual_pass=bool(residual_ok),
        transversality_pass=bool(transverse_ok),
        verdict=verdict,
        interpretation=(
            "With shell micromotion present, a shrinking local envelope of "
            "|Delta lambda_{j,k}| is stronger evidence for the necessary "
            "term condition than strict shell-by-shell monotonicity."
        ),
    )

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o,np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Extended adjacent operator increments")
    print("-"*152)
    print(
        f"{'shell':>6} {'pair':>22} {'trace inc':>13} {'ratio':>9} "
        f"{'max mode':>13} {'ratio':>9} "
        f"{'median':>13} {'contract%':>10} {'new?':>6}"
    )
    for r in shell_rows:
        print(
            f"{r['shell']:6d} "
            f"{r['L']:>10d}->{r['M']:<10d} "
            f"{r['trace_increment']:13.6e} "
            f"{r['trace_ratio']:9.6f} "
            f"{r['max_modal_increment']:13.6e} "
            f"{r['max_modal_ratio']:9.6f} "
            f"{r['median_modal_increment']:13.6e} "
            f"{100*r['modal_contraction_fraction']:10.1f} "
            f"{str(r['is_new_shell']):>6}"
        )

    print()
    print("Unresolved v164 watch modes — two-shell envelope test")
    print("-"*152)
    print(
        f"{'k':>4} {'old env':>14} {'new env':>14} {'ratio':>10} "
        f"{'alpha':>10} {'latest a':>10} {'latest dec':>11}"
    )
    for _,r in unresolved_df.sort_values(
        "envelope_ratio",ascending=False
    ).iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['old_two_shell_envelope']:14.6e} "
            f"{r['new_two_shell_envelope']:14.6e} "
            f"{r['envelope_ratio']:10.6f} "
            f"{r['power_alpha']:10.6f} "
            f"{r['latest_local_alpha']:10.6f} "
            f"{str(bool(r['latest_shell_contracts'])):>11}"
        )

    print()
    print("Worst all-mode envelope ratios")
    print("-"*152)
    worst = modes_df.sort_values(
        "envelope_ratio",ascending=False
    ).head(min(16,n))
    print(
        f"{'k':>4} {'old env':>14} {'new env':>14} {'ratio':>10} "
        f"{'watch':>7} {'unres':>7}"
    )
    for _,r in worst.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['old_two_shell_envelope']:14.6e} "
            f"{r['new_two_shell_envelope']:14.6e} "
            f"{r['envelope_ratio']:10.6f} "
            f"{str(bool(r['watch_mode'])):>7} "
            f"{str(bool(r['unresolved_watch_mode'])):>7}"
        )

    print()
    print("="*152)
    print(f"all-mode envelope contraction frac : {all_contract_fraction:.6f}")
    print(f"watch-mode envelope contraction frac: {watch_contract_fraction:.6f}")
    print(f"unresolved-watch contraction frac  : {unresolved_contract_fraction:.6f}")
    print(f"aggregate envelope old             : {aggregate_old_env:.6e}")
    print(f"aggregate envelope new             : {aggregate_new_env:.6e}")
    print(f"aggregate envelope ratio           : {aggregate_env_ratio:.9f}")
    print(f"max-modal envelope ratio           : {max_env_ratio:.9f}")
    print(f"root residual pass                 : {residual_ok}")
    print(f"transversality pass                : {transverse_ok}")
    print(f"VERDICT                            : {verdict}")
    print("="*152)
    print("DECISION:")
    print("  STRONG PASS -> modal micromotion has a shrinking envelope; this")
    print("                 supports returning to an analytic Lemma-1 bound.")
    print("  PARTIAL      -> one final extension may be justified.")
    print("  UNRESOLVED   -> persistent envelope growth remains and the current")
    print("                 cutoff-independence hypothesis needs re-examination.")


if __name__ == "__main__":
    main()
