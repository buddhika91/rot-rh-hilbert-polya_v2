#!/usr/bin/env python3
"""
ROT-RH v183 — GLOBAL CESARO MIXING-SCALE AUDIT

Purpose
-------
v182.1 showed that the exact switch error is overwhelmingly

    epsilon_mix = tau*(G-gamma_active*R)/(tau*R+Q).

The relevant asymptotic question is NOT merely whether epsilon_mix is a small
fraction of gamma inside a local switch window.  For Lemma 1 we need the
cumulative switch contribution to be small compared with the leading term
~ gamma*tau.

For a two-layer switch with

    Delta a     = |(beta2-1/2) - (beta1-1/2)| = |beta2-beta1|,
    Delta gamma = |gamma2-gamma1|,

the natural transition width in tau is O(1/Delta a), suggesting

    I_mix := int_switch |epsilon_mix| d tau
           = O(Delta gamma / Delta a),

and hence the global Cesaro contribution

    I_mix / (gamma_ref * tau_switch)
      = O( Delta gamma /
           (gamma_ref * tau_switch * Delta a) ).

v183 tests this scale on already-generated successful switch samples.
It performs NO root continuation.

Important:
Every retained CSV sample is first reprojected to S=0 in high precision using
Y=tau*E, so float64 CSV rounding cannot contaminate epsilon.

Outputs
-------
<prefix>_POINTS.csv
<prefix>_SWITCHES.csv
<prefix>_FIT.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def trapezoid(x, y):
    return float(np.trapezoid(np.asarray(y, float), np.asarray(x, float)))


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def stride_group(g, stride):
    g = g.sort_values("tau").reset_index(drop=True)
    if stride <= 1 or len(g) <= 2:
        return g
    idx = list(range(0, len(g), stride))
    if (len(g)-1) not in idx:
        idx.append(len(g)-1)
    return g.iloc[sorted(set(idx))].reset_index(drop=True)


class ExactPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b-mp.mpf("0.5")

            # rho, conjugate, 1-rho, mirror conjugate
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def raw(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws = []
        logs = []

        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        Z = mp.fsum(zs)
        S = mp.im(Z)
        R = mp.re(Z)

        G = mp.fsum(
            g*mp.re(z)
            for g, z in zip(self.g, zs)
        )
        A = mp.fsum(
            a*mp.im(z)
            for a, z in zip(self.a, zs)
        )
        Q = mp.im(mp.fsum(
            1j*mp.digamma(w)*z
            for w, z in zip(ws, zs)
        ))

        SE = tau*R + Q
        St = E*R-G+A

        return {
            "S": S,
            "R": R,
            "G": G,
            "A": A,
            "Q": Q,
            "SE": SE,
            "St": St,
        }

    def reproject_Y(self, E_seed, tau, tol, cell_fraction, iterations):
        tau = mp.mpf(tau)
        Y = tau*mp.mpf(E_seed)

        total = mp.mpf("0")
        max_step = mp.mpf("0")

        for it in range(iterations):
            E = Y/tau
            q = self.raw(E, tau)

            if abs(q["S"]) <= tol:
                return {
                    "ok": True,
                    "E": E,
                    "Y": Y,
                    "residual": abs(q["S"]),
                    "total_cell_shift": abs(total)/mp.pi,
                    "max_step_cell_shift": max_step,
                    "iterations": it,
                }

            SY = q["SE"]/tau
            if abs(SY) == 0 or not mp.isfinite(SY):
                return {"ok": False, "reason": "S_Y_zero_or_nonfinite"}

            step = -q["S"]/SY
            ratio = abs(step)/mp.pi

            if ratio > cell_fraction:
                return {
                    "ok": False,
                    "reason": "reprojection_exceeds_cell_gate",
                    "step_cell_shift": ratio,
                }

            Y += step
            total += step
            max_step = max(max_step, ratio)

        E = Y/tau
        q = self.raw(E, tau)

        return {
            "ok": bool(abs(q["S"]) <= tol),
            "reason": "newton_no_convergence",
            "E": E,
            "Y": Y,
            "residual": abs(q["S"]),
            "total_cell_shift": abs(total)/mp.pi,
            "max_step_cell_shift": max_step,
            "iterations": iterations,
        }

    def decompose(self, E, tau, gamma_active):
        E = mp.mpf(E)
        tau = mp.mpf(tau)
        ga = mp.mpf(gamma_active)

        q = self.raw(E, tau)

        R = q["R"]
        G = q["G"]
        A = q["A"]
        Q = q["Q"]
        D = q["SE"]

        Yt = E - tau*q["St"]/D
        eps = Yt-ga

        eps_mix = tau*(G-ga*R)/D
        eps_A = -tau*A/D
        eps_dig = Q*(E-ga)/D

        return {
            "S_abs": abs(q["S"]),
            "epsilon": eps,
            "epsilon_mix": eps_mix,
            "epsilon_A": eps_A,
            "epsilon_digamma": eps_dig,
            "epsilon_identity_resid": abs(
                eps-(eps_mix+eps_A+eps_dig)
            ),
            "q_over_tauR": (
                abs(Q)/(tau*abs(R))
                if R != 0 else mp.inf
            ),
            "soft_gamma": (
                G/R if R != 0 else mp.nan
            ),
        }


def weighted_log_fit(x, y):
    """
    Fit log y = intercept + slope log x.
    Returns n,slope,intercept,R2.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)

    ok = (
        np.isfinite(x) & np.isfinite(y)
        & (x > 0) & (y > 0)
    )
    x = x[ok]
    y = y[ok]

    if len(x) < 3:
        return {
            "n": len(x),
            "slope": np.nan,
            "intercept": np.nan,
            "r2": np.nan,
        }

    X = np.log(x)
    Y = np.log(y)

    p = np.polyfit(X, Y, 1)
    pred = p[0]*X+p[1]

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0-ss_res/ss_tot if ss_tot > 0 else np.nan

    return {
        "n": len(x),
        "slope": float(p[0]),
        "intercept": float(p[1]),
        "r2": float(r2),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--samples-csv",
        required=True,
        help="Comma-separated successful v180/v181 *_SAMPLES.csv files.",
    )

    ap.add_argument("--dps", type=int, default=60)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=8)
    ap.add_argument("--cell-fraction", type=float, default=0.10)
    ap.add_argument("--stride", type=int, default=4)

    ap.add_argument(
        "--prefix",
        default="rot_rh_global_cesaro_mix_scale_v183",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    cell_fraction = mp.mpf(str(args.cell_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    frames = []
    for name in [
        x.strip()
        for x in args.samples_csv.split(",")
        if x.strip()
    ]:
        p = Path(name)
        if not p.exists():
            raise FileNotFoundError(name)
        d = pd.read_csv(p)
        d["source_file"] = p.name
        frames.append(d)

    samples = pd.concat(frames, ignore_index=True)

    if not {"switch", "tau", "E"}.issubset(samples.columns):
        raise RuntimeError("Samples need switch,tau,E.")

    # Prefer latest file in duplicate points, then stride switch-by-switch.
    samples = (
        samples
        .sort_values(["switch", "tau"])
        .drop_duplicates(["switch", "tau"], keep="last")
    )

    kept = []
    for sw, g in samples.groupby("switch"):
        kept.append(stride_group(g, args.stride))
    samples = pd.concat(kept, ignore_index=True)

    switches = sorted(
        samples["switch"].astype(int).unique().tolist()
    )

    print("="*178)
    print("ROT-RH v183 — GLOBAL CESARO MIXING-SCALE AUDIT")
    print("="*178)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switches                          : {switches}")
    print(f"retained sample rows              : {len(samples)}")
    print(f"stride                            : {args.stride}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*178)

    phases = {}
    point_rows = []
    reproj_fail = 0

    for _, r in samples.iterrows():
        sw = int(r["switch"])
        j = sw-1

        if j < 0 or j+1 >= len(hull):
            continue

        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand,
            left["beta_active"],
            left["gamma_active"],
        )
        c2 = match_candidate(
            cand,
            right["beta_active"],
            right["gamma_active"],
        )

        b1 = float(c1["beta"])
        g1 = float(c1["gamma"])
        b2 = float(c2["beta"])
        g2 = float(c2["gamma"])

        key = (sw, b1, g1, b2, g2)
        if key not in phases:
            phases[key] = ExactPhase(b1, g1, b2, g2)
        phase = phases[key]

        tau = mp.mpf(str(float(r["tau"])))
        E_seed = mp.mpf(str(float(r["E"])))

        rep = phase.reproject_Y(
            E_seed, tau, tol,
            cell_fraction, args.newton_iters
        )

        if not rep["ok"]:
            reproj_fail += 1
            continue

        E = rep["E"]
        ts = float(left["tau_end"])
        ga = g1 if float(tau) <= ts else g2

        d = phase.decompose(
            E, tau, mp.mpf(str(ga))
        )

        row = {
            "switch": sw,
            "tau": float(tau),
            "E": float(E),
            "tau_switch": ts,
            "beta_left": b1,
            "beta_right": b2,
            "gamma_left": g1,
            "gamma_right": g2,
            "gamma_active": ga,
            "source_file": r["source_file"],
            "reprojection_cell_shift": float(
                rep["total_cell_shift"]
            ),
        }

        for k, v in d.items():
            try:
                row[k] = float(v)
            except Exception:
                row[k] = np.nan

        point_rows.append(row)

    pts = (
        pd.DataFrame(point_rows)
        .sort_values(["switch", "tau"])
        .reset_index(drop=True)
    )

    if len(pts) == 0:
        raise RuntimeError("No points survived reprojection.")

    switch_rows = []

    # Exact accumulated active integral from beginning of hull through each switch.
    tau_origin = float(hull.iloc[0]["tau_start"])

    def accumulated_active_to(t):
        acc = 0.0
        for _, seg in hull.iterrows():
            a = float(seg["tau_start"])
            b = float(seg["tau_end"])
            g = float(seg["gamma_active"])

            if t <= a:
                break

            upper = min(t, b)
            if upper > a:
                acc += g*(upper-a)

            if t <= b:
                break
        return acc

    for sw, g in pts.groupby("switch"):
        g = g.sort_values("tau")
        j = int(sw)-1

        left = hull.iloc[j]
        right = hull.iloc[j+1]

        tau = g["tau"].to_numpy(float)
        em = g["epsilon_mix"].to_numpy(float)
        e = g["epsilon"].to_numpy(float)
        active = g["gamma_active"].to_numpy(float)

        I_mix = trapezoid(tau, np.abs(em))
        I_total = trapezoid(tau, np.abs(e))
        I_active_window = trapezoid(tau, active)

        ts = float(left["tau_end"])

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        g1 = float(g.iloc[0]["gamma_left"])
        g2 = float(g.iloc[0]["gamma_right"])

        delta_a = abs(b2-b1)
        delta_g = abs(g2-g1)
        gamma_ref = 0.5*(abs(g1)+abs(g2))

        intrinsic_scale = (
            delta_g/delta_a
            if delta_a > 0 else np.inf
        )

        predicted_global_scale = (
            delta_g/(gamma_ref*ts*delta_a)
            if delta_a > 0 and gamma_ref > 0 and ts > 0
            else np.inf
        )

        active_accum = accumulated_active_to(ts)

        global_ratio_gamma_tau = (
            I_mix/(gamma_ref*ts)
            if gamma_ref > 0 and ts > 0 else np.inf
        )

        global_ratio_active_accum = (
            I_mix/active_accum
            if active_accum > 0 else np.inf
        )

        normalized_width_constant = (
            I_mix*delta_a/delta_g
            if delta_g > 0 else np.nan
        )

        local_ratio = (
            I_mix/max(abs(I_active_window), 1e-300)
        )

        rr = {
            "switch": int(sw),
            "samples": len(g),
            "tau_switch": ts,
            "beta_left": b1,
            "beta_right": b2,
            "gamma_left": g1,
            "gamma_right": g2,
            "delta_a": delta_a,
            "delta_gamma": delta_g,
            "gamma_ref": gamma_ref,
            "I_mix_abs": I_mix,
            "I_total_abs": I_total,
            "I_active_window": I_active_window,
            "local_mix_over_active_window": local_ratio,
            "intrinsic_scale_delta_gamma_over_delta_a": intrinsic_scale,
            "normalized_width_constant": normalized_width_constant,
            "predicted_global_scale": predicted_global_scale,
            "global_mix_over_gamma_tau": global_ratio_gamma_tau,
            "active_integral_accum_to_switch": active_accum,
            "global_mix_over_active_accum": global_ratio_active_accum,
            "max_q_over_tauR": float(
                g["q_over_tauR"]
                .replace([np.inf, -np.inf], np.nan)
                .max()
            ),
            "max_reprojection_cell_shift": float(
                g["reprojection_cell_shift"].max()
            ),
            "max_identity_residual": float(
                g["epsilon_identity_resid"].max()
            ),
        }

        switch_rows.append(rr)

        print(
            f"[switch {int(sw):4d}] "
            f"tau={ts:.3e} "
            f"dg={delta_g:.3e} da={delta_a:.3e} "
            f"I={I_mix:.3e} "
            f"I/(g*tau)={global_ratio_gamma_tau:.3e} "
            f"pred={predicted_global_scale:.3e} "
            f"K=I*da/dg={normalized_width_constant:.3e}"
        )

    swdf = (
        pd.DataFrame(switch_rows)
        .sort_values("tau_switch")
        .reset_index(drop=True)
    )

    fit_intrinsic = weighted_log_fit(
        swdf[
            "intrinsic_scale_delta_gamma_over_delta_a"
        ],
        swdf["I_mix_abs"],
    )

    fit_global = weighted_log_fit(
        swdf["predicted_global_scale"],
        swdf["global_mix_over_gamma_tau"],
    )

    fit_tau_decay = weighted_log_fit(
        swdf["tau_switch"],
        swdf["global_mix_over_gamma_tau"],
    )

    # Is global contribution declining from early to late sample?
    early = swdf.iloc[0]
    late = swdf.iloc[-1]
    late_over_early = (
        late["global_mix_over_gamma_tau"]
        / early["global_mix_over_gamma_tau"]
        if early["global_mix_over_gamma_tau"] > 0
        else np.inf
    )

    max_identity = float(
        swdf["max_identity_residual"].max()
    )

    fit_rows = [
        {"fit": "I_mix_vs_delta_gamma_over_delta_a", **fit_intrinsic},
        {"fit": "global_ratio_vs_predicted_global_scale", **fit_global},
        {"fit": "global_ratio_vs_tau_switch", **fit_tau_decay},
    ]

    # A deliberately conservative evidence verdict.
    scaling_supported = bool(
        len(swdf) >= 5
        and np.isfinite(fit_global["slope"])
        and 0.5 <= fit_global["slope"] <= 1.5
        and fit_global["r2"] >= 0.5
    )

    global_decay_supported = bool(
        len(swdf) >= 5
        and np.isfinite(fit_tau_decay["slope"])
        and fit_tau_decay["slope"] < 0
        and late_over_early < 1.0
    )

    if reproj_fail:
        verdict = "GLOBAL_CESARO_SCALE_REPROJECTION_WARNING"
    elif scaling_supported and global_decay_supported:
        verdict = "GLOBAL_CESARO_MIX_SCALE_STRONGLY_SUPPORTED"
    elif global_decay_supported:
        verdict = "GLOBAL_CESARO_MIX_DECAY_SUPPORTED_SCALING_INCOMPLETE"
    else:
        verdict = "GLOBAL_CESARO_MIX_SCALING_UNRESOLVED"

    pts.to_csv(
        args.prefix+"_POINTS.csv",
        index=False,
    )
    swdf.to_csv(
        args.prefix+"_SWITCHES.csv",
        index=False,
    )
    pd.DataFrame(fit_rows).to_csv(
        args.prefix+"_FIT.csv",
        index=False,
    )

    summary = {
        "version": 183,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "switches": swdf["switch"].astype(int).tolist(),
        "reprojection_failures": reproj_fail,
        "max_identity_residual": max_identity,
        "fit_intrinsic": fit_intrinsic,
        "fit_global": fit_global,
        "fit_tau_decay": fit_tau_decay,
        "late_over_early_global_ratio": float(late_over_early),
        "scaling_supported": scaling_supported,
        "global_decay_supported": global_decay_supported,
        "verdict": verdict,
    }

    Path(
        args.prefix+"_SUMMARY.json"
    ).write_text(
        json.dumps(
            native(summary),
            indent=2,
            allow_nan=True,
        ),
        encoding="utf-8",
    )

    print()
    print("="*178)
    print(f"reprojection failures              : {reproj_fail}")
    print(f"max identity residual              : {max_identity:.6e}")
    print(
        "fit I ~ (dg/da)^p                : "
        f"p={fit_intrinsic['slope']:.6f} "
        f"R2={fit_intrinsic['r2']:.6f}"
    )
    print(
        "fit global ~ predicted^p          : "
        f"p={fit_global['slope']:.6f} "
        f"R2={fit_global['r2']:.6f}"
    )
    print(
        "fit global ~ tau^p                : "
        f"p={fit_tau_decay['slope']:.6f} "
        f"R2={fit_tau_decay['r2']:.6f}"
    )
    print(f"late / early global ratio          : {late_over_early:.6e}")
    print(f"scaling supported                  : {scaling_supported}")
    print(f"global decay supported             : {global_decay_supported}")
    print(f"VERDICT                            : {verdict}")
    print("="*178)


if __name__ == "__main__":
    main()
