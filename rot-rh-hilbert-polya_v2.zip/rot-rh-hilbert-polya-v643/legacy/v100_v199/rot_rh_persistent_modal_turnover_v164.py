#!/usr/bin/env python3
"""
ROT-RH v164 — PERSISTENT MODAL TURNOVER EXTENSION AUDIT

Purpose
-------
v163 found that the necessary modal term test for Lemma 1 is still unresolved.
Several fixed modes have adjacent operator increments

    |Delta lambda_{j,k}|
      = |E_k(L_{j+1})^-2 - E_k(L_j)^-2|

that are larger at the end of the current range than at its beginning.

This does NOT disprove convergence after only five shells.  But before any
analytic Cauchy proof is attempted, the persistent modes must either:

  (A) turn over and begin decaying, or
  (B) continue growing/plateauing, which would seriously weaken the
      cutoff-independence hypothesis.

v164 extends the moving-root net beyond the v162 endpoint and directly
tracks the v163 failure modes.

Default extension
-----------------
Existing endpoint:
    2,896,310

New cutoffs:
    4,096,000
    5,792,619       (~sqrt(2) spacing)

The script still tracks ALL first N roots because phase construction is the
dominant cost and retaining the full finite block is useful.

Watch modes are selected automatically from v163:
  * last_over_first > 1, OR
  * latest_local_alpha < 0,
with optional manual additions.

For each new shell it reports:
  * root residuals and transversality;
  * adjacent trace distance;
  * every watch-mode |Delta lambda|;
  * whether that mode has turned over;
  * whether its latest two increments are decreasing;
  * updated local alpha;
  * updated first-to-last ratio;
  * all-mode necessary-condition fractions.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_ROOTS.npz
<prefix>_SHELLS.csv
<prefix>_MODES.csv
<prefix>_WATCH.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
except Exception as exc:
    raise RuntimeError("scipy.optimize.brentq is required") from exc


def csv_ints(s):
    if s is None or not str(s).strip():
        return []
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)
    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass

    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def build_phase(v102, base, L, tail_factor, counter_q):
    with warnings.catch_warnings(record=True) as wrn:
        warnings.simplefilter("always")
        ph = v102.RenormalizedPhase.build(
            base,
            int(L),
            float(tail_factor),
            int(counter_q),
        )
    return ph, [str(w.message) for w in wrn]


def refine_root(
    phase,
    target,
    x0,
    newton_iters,
    tol,
    max_step,
    bracket_initial,
    bracket_max,
):
    x = float(x0)

    for _ in range(newton_iters):
        f = scalar_call(phase.F, x) - target
        if abs(f) <= tol:
            return x, abs(f), "newton"

        fp = scalar_call(phase.Fprime, x)
        if (not np.isfinite(fp)) or abs(fp) < 1e-12:
            break

        step = float(np.clip(-f/fp, -max_step, max_step))
        xn = x + step

        if not np.isfinite(xn) or xn <= 0:
            break
        x = xn

    def ff(xx):
        return scalar_call(phase.F, xx) - target

    radius = bracket_initial
    while radius <= bracket_max:
        a = max(1e-8, x0-radius)
        b = x0+radius
        fa = ff(a)
        fb = ff(b)

        if np.isfinite(fa) and np.isfinite(fb) and fa*fb <= 0:
            root = float(brentq(
                ff, a, b,
                xtol=tol,
                rtol=1e-13,
                maxiter=200,
            ))
            return root, abs(ff(root)), "brent"

        radius *= 1.6

    return x, abs(ff(x)), "failed"


def segment_min_derivative(phase, x1, x2, samples):
    xs = np.linspace(float(x1), float(x2), samples)
    vals = np.abs(vector_call(phase.Fprime, xs))
    return float(np.min(vals))


def fit_power(Lleft, y):
    Lleft = np.asarray(Lleft, dtype=float)
    y = np.asarray(y, dtype=float)

    mask = (
        (Lleft > 0)
        & (y > 0)
        & np.isfinite(y)
    )
    X = np.log(Lleft[mask])
    Y = np.log(y[mask])

    if len(X) < 2:
        return np.nan, np.nan

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    alpha = float(-coef[1])
    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan
    return alpha, r2


def latest_alpha(Lleft, y):
    if len(y) < 2:
        return np.nan
    if y[-1] <= 0 or y[-2] <= 0:
        return np.nan
    return float(
        -math.log(y[-1]/y[-2])
        / math.log(Lleft[-1]/Lleft[-2])
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v162-roots-npz",
        default="rot_rh_moving_root_phase_cauchy_v162_ROOTS.npz",
    )
    ap.add_argument(
        "--v163-modes-csv",
        default="rot_rh_modal_increment_term_test_v163_MODES.csv",
    )

    ap.add_argument(
        "--new-cutoffs",
        default="4096000,5792619",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument(
        "--manual-watch-modes",
        default="",
    )
    ap.add_argument(
        "--max-auto-watch",
        type=int,
        default=16,
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--root-tol", type=float, default=1e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument("--bracket-initial", type=float, default=0.05)
    ap.add_argument("--bracket-max", type=float, default=1.0)
    ap.add_argument("--segment-samples", type=int, default=17)

    ap.add_argument("--root-residual-gate", type=float, default=1e-8)
    ap.add_argument("--transversality-gate", type=float, default=0.05)

    ap.add_argument(
        "--minimum-positive-alpha-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--minimum-latest-contracting-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--minimum-watch-turnover-fraction",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_persistent_modal_turnover_v164",
    )

    args = ap.parse_args()

    z = np.load(args.v162_roots_npz)
    old_L = np.asarray(z["L"], dtype=int)
    old_roots = np.asarray(z["roots"], dtype=float)

    n = min(args.modes, old_roots.shape[1])
    old_roots = old_roots[:, :n]

    new_cutoffs = csv_ints(args.new_cutoffs)
    if not new_cutoffs:
        raise RuntimeError("Provide at least one new cutoff.")
    if any(L <= old_L[-1] for L in new_cutoffs):
        raise RuntimeError(
            f"All new cutoffs must exceed existing endpoint {old_L[-1]}."
        )
    if any(new_cutoffs[i+1] <= new_cutoffs[i]
           for i in range(len(new_cutoffs)-1)):
        raise RuntimeError("--new-cutoffs must be strictly increasing.")

    # ------------------------------------------------------------------
    # select watch modes from v163
    # ------------------------------------------------------------------
    m163 = pd.read_csv(args.v163_modes_csv)
    m163 = m163[m163["k"] <= n].copy()

    bad = m163[
        (m163["last_over_first"] > 1.0)
        | (m163["latest_local_alpha"] < 0.0)
    ].copy()

    bad["severity"] = np.maximum(
        bad["last_over_first"].to_numpy(dtype=float),
        1.0
    ) + np.maximum(
        -bad["latest_local_alpha"].to_numpy(dtype=float),
        0.0
    )

    auto_watch = (
        bad.sort_values("severity", ascending=False)
        .head(args.max_auto_watch)["k"]
        .astype(int)
        .tolist()
    )

    manual = csv_ints(args.manual_watch_modes)
    watch_modes = sorted(set(auto_watch + manual))

    if not watch_modes:
        watch_modes = [int(k) for k in m163.nlargest(8, "last_over_first")["k"]]

    print("=" * 150)
    print("ROT-RH v164 — PERSISTENT MODAL TURNOVER EXTENSION AUDIT")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"existing cutoffs                  : {old_L.tolist()}")
    print(f"new cutoffs                       : {new_cutoffs}")
    print(f"modes                             : 1..{n}")
    print(f"watch modes                       : {watch_modes}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 150)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warnings_map = {}

    def get_phase(L):
        if L not in phases:
            print(f"[L={L}] building RenormalizedPhase ...", flush=True)
            ph, wrn = build_phase(
                v102, base, L,
                args.tail_factor, args.counter_q
            )
            phases[L] = ph
            warnings_map[L] = wrn
            if wrn:
                print(f"[L={L}] {len(wrn)} warning(s)")
                for msg in wrn[:2]:
                    print(f"         warning: {msg}")
        return phases[L]

    targets = np.arange(1, n+1, dtype=float)-0.5

    all_L = old_L.tolist()
    roots_list = [old_roots[i].copy() for i in range(len(old_L))]

    prev_L = int(old_L[-1])
    prev_roots = old_roots[-1].copy()

    new_shell_diag = []

    for L in new_cutoffs:
        print()
        print(f"[track {prev_L}->{L}] continuing {n} roots ...", flush=True)

        ph = get_phase(L)

        new_roots = np.empty(n, dtype=float)
        residuals = np.empty(n, dtype=float)
        methods = []

        for j in range(n):
            root, res, method = refine_root(
                phase=ph,
                target=targets[j],
                x0=prev_roots[j],
                newton_iters=args.newton_iters,
                tol=args.root_tol,
                max_step=args.max_newton_step,
                bracket_initial=args.bracket_initial,
                bracket_max=args.bracket_max,
            )
            new_roots[j] = root
            residuals[j] = res
            methods.append(method)

        min_derivs = np.array([
            segment_min_derivative(
                ph,
                prev_roots[j],
                new_roots[j],
                args.segment_samples,
            )
            for j in range(n)
        ])

        old_lam = prev_roots**(-2)
        new_lam = new_roots**(-2)
        dlam = new_lam-old_lam

        new_shell_diag.append(dict(
            L=prev_L,
            M=L,
            max_root_residual=float(np.max(residuals)),
            min_segment_abs_Fprime=float(np.min(min_derivs)),
            trace_increment=float(np.sum(np.abs(dlam))),
            max_modal_increment=float(np.max(np.abs(dlam))),
            median_modal_increment=float(np.median(np.abs(dlam))),
            newton_count=int(sum(m=="newton" for m in methods)),
            brent_count=int(sum(m=="brent" for m in methods)),
            failed_count=int(sum(m=="failed" for m in methods)),
        ))

        print(
            f"          max residual={np.max(residuals):.3e}  "
            f"min|F_E|={np.min(min_derivs):.6f}  "
            f"trace inc={np.sum(np.abs(dlam)):.6e}  "
            f"max mode={np.max(np.abs(dlam)):.6e}"
        )

        all_L.append(L)
        roots_list.append(new_roots.copy())

        prev_L = L
        prev_roots = new_roots

    all_L = np.asarray(all_L, dtype=int)
    roots = np.vstack(roots_list)
    lam = roots**(-2)

    dE = roots[1:]-roots[:-1]
    dlam = lam[1:]-lam[:-1]
    abs_dlam = np.abs(dlam)

    shell_left = all_L[:-1].astype(float)

    # ------------------------------------------------------------------
    # shell table over full extended net
    # ------------------------------------------------------------------
    shell_rows = []

    for j in range(len(all_L)-1):
        trace = float(np.sum(abs_dlam[j]))
        maxm = float(np.max(abs_dlam[j]))
        medm = float(np.median(abs_dlam[j]))

        if j == 0:
            tr_ratio = np.nan
            max_ratio = np.nan
            med_ratio = np.nan
            modal_contract = np.nan
            sign_flip = np.nan
        else:
            tr_ratio = trace / max(shell_rows[-1]["trace_increment"], 1e-300)
            max_ratio = maxm / max(shell_rows[-1]["max_modal_increment"], 1e-300)
            med_ratio = medm / max(shell_rows[-1]["median_modal_increment"], 1e-300)
            modal_contract = float(
                np.mean(abs_dlam[j] < abs_dlam[j-1])
            )
            sign_flip = float(
                np.mean(np.sign(dlam[j]) != np.sign(dlam[j-1]))
            )

        shell_rows.append(dict(
            shell=j+1,
            L=int(all_L[j]),
            M=int(all_L[j+1]),
            trace_increment=trace,
            trace_ratio=tr_ratio,
            max_modal_increment=maxm,
            max_modal_ratio=max_ratio,
            median_modal_increment=medm,
            median_modal_ratio=med_ratio,
            modal_contraction_fraction=modal_contract,
            sign_flip_fraction=sign_flip,
            is_new_shell=bool(j >= len(old_L)-1),
        ))

    # ------------------------------------------------------------------
    # modal updated term-test
    # ------------------------------------------------------------------
    mode_rows = []

    for k in range(n):
        y = abs_dlam[:, k]

        alpha, r2 = fit_power(shell_left, y)
        la = latest_alpha(shell_left, y)

        if len(y) >= 3:
            latest3_dec = bool(y[-1] < y[-2] < y[-3])
        else:
            latest3_dec = False

        # Turnover relative to the historical maximum:
        imax = int(np.argmax(y))
        turned_over = bool(
            imax < len(y)-1
            and y[-1] < y[imax]
        )

        # Stronger turnover: last two increments both below historical max
        # and latest one below previous one.
        sustained_turnover = bool(
            len(y) >= 3
            and imax <= len(y)-2
            and y[-1] < y[-2]
            and y[-2] < y[imax] + 1e-300
        )

        mode_rows.append(dict(
            k=k+1,
            abs_dlambda_first=float(y[0]),
            abs_dlambda_last=float(y[-1]),
            last_over_first=float(y[-1]/max(y[0], 1e-300)),
            historical_max=float(np.max(y)),
            historical_max_shell=imax+1,
            last_over_historical_max=float(
                y[-1]/max(np.max(y), 1e-300)
            ),
            power_alpha=alpha,
            power_R2=r2,
            latest_local_alpha=la,
            latest3_decreasing=latest3_dec,
            turned_over=turned_over,
            sustained_turnover=sustained_turnover,
            watch_mode=bool((k+1) in watch_modes),
        ))

    modes_df = pd.DataFrame(mode_rows)

    # ------------------------------------------------------------------
    # detailed watch table across shells
    # ------------------------------------------------------------------
    watch_rows = []

    for k in watch_modes:
        j = k-1
        y = abs_dlam[:, j]

        for s in range(len(y)):
            if s == 0:
                ratio = np.nan
                local_a = np.nan
            else:
                ratio = float(y[s]/max(y[s-1], 1e-300))
                local_a = float(
                    -math.log(max(y[s],1e-300)/max(y[s-1],1e-300))
                    / math.log(shell_left[s]/shell_left[s-1])
                )

            watch_rows.append(dict(
                k=k,
                shell=s+1,
                L=int(all_L[s]),
                M=int(all_L[s+1]),
                abs_dlambda=float(y[s]),
                ratio_vs_previous=ratio,
                local_alpha=local_a,
                sign=int(np.sign(dlam[s, j])),
                is_new_shell=bool(s >= len(old_L)-1),
            ))

    watch_df = pd.DataFrame(watch_rows)

    # ------------------------------------------------------------------
    # aggregate decision
    # ------------------------------------------------------------------
    positive_alpha_fraction = float(
        np.mean(modes_df["power_alpha"].to_numpy(dtype=float) > 0)
    )
    positive_latest_alpha_fraction = float(
        np.mean(modes_df["latest_local_alpha"].to_numpy(dtype=float) > 0)
    )

    latest_modal_contract_fraction = float(
        shell_rows[-1]["modal_contraction_fraction"]
    )

    watch_mask = modes_df["watch_mode"].to_numpy(dtype=bool)
    watch_turnover_fraction = float(
        np.mean(
            modes_df.loc[watch_mask, "turned_over"].to_numpy(dtype=bool)
        )
    ) if np.any(watch_mask) else np.nan

    watch_sustained_fraction = float(
        np.mean(
            modes_df.loc[watch_mask, "sustained_turnover"].to_numpy(dtype=bool)
        )
    ) if np.any(watch_mask) else np.nan

    residual_ok = all(
        r["max_root_residual"] <= args.root_residual_gate
        for r in new_shell_diag
    )
    transverse_ok = all(
        r["min_segment_abs_Fprime"] >= args.transversality_gate
        for r in new_shell_diag
    )

    necessary_condition_supported = bool(
        residual_ok
        and transverse_ok
        and positive_alpha_fraction
            >= args.minimum_positive_alpha_fraction
        and latest_modal_contract_fraction
            >= args.minimum_latest_contracting_fraction
        and watch_turnover_fraction
            >= args.minimum_watch_turnover_fraction
    )

    if necessary_condition_supported:
        verdict = "PERSISTENT_MODAL_TERM_TEST_NOW_STRONGLY_SUPPORTED"
    elif watch_turnover_fraction >= 0.50 and residual_ok and transverse_ok:
        verdict = "PERSISTENT_MODES_PARTIALLY_TURN_OVER_MORE_RANGE_NEEDED"
    else:
        verdict = "PERSISTENT_MODAL_TERM_TEST_STILL_UNRESOLVED"

    # ------------------------------------------------------------------
    # save
    # ------------------------------------------------------------------
    np.savez_compressed(
        args.prefix + "_ROOTS.npz",
        L=all_L,
        roots=roots,
        targets=targets,
    )

    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )
    modes_df.to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    watch_df.to_csv(
        args.prefix + "_WATCH.csv", index=False
    )

    summary = dict(
        version=164,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoffs=all_L.tolist(),
        modes=n,
        watch_modes=watch_modes,
        new_shell_diagnostics=new_shell_diag,
        fractions=dict(
            positive_power_alpha=positive_alpha_fraction,
            positive_latest_local_alpha=positive_latest_alpha_fraction,
            latest_shell_modal_contraction=latest_modal_contract_fraction,
            watch_modes_turned_over=watch_turnover_fraction,
            watch_modes_sustained_turnover=watch_sustained_fraction,
        ),
        root_residual_pass=bool(residual_ok),
        transversality_pass=bool(transverse_ok),
        verdict=verdict,
        interpretation=(
            "The modal increment term test is a necessary condition for "
            "finite-block cutoff convergence. Persistent problem modes must "
            "eventually show |Delta lambda_{j,k}| -> 0. v164 specifically "
            "tests whether the v163 failures turn over on two larger shells."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o, np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Extended operator-increment shells")
    print("-" * 150)
    print(
        f"{'shell':>6} {'pair':>21} {'trace inc':>13} {'ratio':>9} "
        f"{'max mode':>13} {'ratio':>9} "
        f"{'median':>13} {'contract%':>10} {'new?':>6}"
    )

    for r in shell_rows:
        print(
            f"{r['shell']:6d} "
            f"{r['L']:>9d}->{r['M']:<9d} "
            f"{r['trace_increment']:13.6e} "
            f"{r['trace_ratio']:9.6f} "
            f"{r['max_modal_increment']:13.6e} "
            f"{r['max_modal_ratio']:9.6f} "
            f"{r['median_modal_increment']:13.6e} "
            f"{100*r['modal_contraction_fraction']:10.1f} "
            f"{str(r['is_new_shell']):>6}"
        )

    print()
    print("Watch-mode turnover summary")
    print("-" * 150)
    print(
        f"{'k':>4} {'last/first':>12} {'last/max':>11} "
        f"{'alpha':>10} {'latest a':>10} "
        f"{'turn':>7} {'sustain':>9}"
    )

    for _, r in modes_df[modes_df["watch_mode"]].sort_values(
        "last_over_first", ascending=False
    ).iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['last_over_first']:12.6f} "
            f"{r['last_over_historical_max']:11.6f} "
            f"{r['power_alpha']:10.6f} "
            f"{r['latest_local_alpha']:10.6f} "
            f"{str(bool(r['turned_over'])):>7} "
            f"{str(bool(r['sustained_turnover'])):>9}"
        )

    print()
    print("Detailed new-shell watch modes")
    print("-" * 150)
    new_watch = watch_df[watch_df["is_new_shell"]].copy()
    print(
        f"{'k':>4} {'pair':>21} {'|dlam|':>14} "
        f"{'ratio':>10} {'local alpha':>13} {'sign':>6}"
    )

    for _, r in new_watch.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{int(r['L']):>9d}->{int(r['M']):<9d} "
            f"{r['abs_dlambda']:14.6e} "
            f"{r['ratio_vs_previous']:10.6f} "
            f"{r['local_alpha']:13.6f} "
            f"{int(r['sign']):6d}"
        )

    print()
    print("=" * 150)
    print(f"positive power-alpha fraction       : {positive_alpha_fraction:.6f}")
    print(f"positive latest-alpha fraction      : {positive_latest_alpha_fraction:.6f}")
    print(f"latest modal contraction fraction   : {latest_modal_contract_fraction:.6f}")
    print(f"watch-mode turnover fraction        : {watch_turnover_fraction:.6f}")
    print(f"watch sustained-turnover fraction   : {watch_sustained_fraction:.6f}")
    print(f"root residual pass                  : {residual_ok}")
    print(f"transversality pass                 : {transverse_ok}")
    print(f"VERDICT                             : {verdict}")
    print("=" * 150)
    print("DECISION:")
    print("  STRONG PASS -> the v163 failures were finite-range micromotion;")
    print("                 return to an analytic moving-root Cauchy bound.")
    print("  PARTIAL      -> extend only one or two more shells.")
    print("  UNRESOLVED   -> persistent fixed modes remain a serious obstacle to")
    print("                 Lemma 1 and must be understood before proof claims.")


if __name__ == "__main__":
    main()
