#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v107 — Low-Branch / Euler–Maclaurin Resolvent Decomposition
==================================================================

Purpose
-------
Decompose the zero-free fixed-L resolvent identity into the pieces that are
actually suggested by the half-integer quantization.

For the selected increasing branch beginning at the first later crossing

    F_L(E_1)=1/2,

write, for real a>1/2,

    g_a(E)=1/(E^2+a^2),
    h_L(x)=g_a(G_L(x)),   x>=1/2,

where G_L is the inverse of the selected monotone branch.

Euler–Maclaurin gives schematically

    sum_{k>=1} g_a(E_k)
      = int_{E1}^inf g_a(E) F'_L(E)dE
        + 1/2 g_a(E1)
        - B2/2! * h'_L(1/2)
        + higher remainder.

Since

    h'_L(1/2)=g'_a(E1)/F'_L(E1),

the explicit B2 contribution is

    B2_L(a)
      = E1 / [6 F'_L(E1) (E1^2+a^2)^2].

The full real-axis Cauchy transform of F'_L is also available directly from
the Gamma term and the finite-part Mangoldt/PNT terms. Therefore

    int_{E1}^inf = J_full,L - J_low,L,

with

    J_low,L = int_0^E1 F'_L(E)/(E^2+a^2)dE.

This audit asks:

  1. Is the discrete-vs-selected-branch correction accurately explained by
     the half-cell + B2 Euler–Maclaurin terms?
  2. Does the package
        -J_low + half-cell + B2
     explain the elementary rational term 1/(a^2-1/4) up to the expected
     finite-L smoothing discrepancy?
  3. Is the unexplained Euler–Maclaurin remainder small and stable with L?

No Xi, zeta evaluations, or known zero ordinates are used.

Important
---------
This is an audit of the *corrected* quantization-remainder decomposition.
The earlier naive statement
    R_L - int_0^inf F'_L/(E^2+a^2) -> 0
is false: the low branch and boundary terms are essential.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.special import digamma
from numpy.polynomial.legendre import leggauss

VERSION = "v107"
BUILD = "2026-08-17-low-branch-euler-maclaurin-resolvent-v107"
EPS = 1e-15


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def partial_moments(roots, order):
    r = np.asarray(roots, float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def operator_resolvent_prefix_tail(roots, completed_moments, a, order):
    r = np.asarray(roots, float)
    cm = np.asarray(completed_moments, float)
    M = min(int(order), len(cm))
    pm = partial_moments(r, M)
    tail = cm[:M] - pm

    a = float(a)
    prefix = float(np.sum(1.0 / (r * r + a * a)))

    tail_val = 0.0
    p = 1.0
    for q in range(M):
        tail_val += p * float(tail[q])
        p *= -(a * a)

    EN = float(r[-1])
    ratio = (a / EN) ** 2
    if ratio >= 1:
        raise ValueError("Need a<E_N.")
    rem = abs(float(tail[0])) * ratio ** M / (1.0 - ratio)
    return prefix + tail_val, rem


def low_branch_integral(phase, E1, a, q):
    """
    Gauss-Legendre integral of F'_L(E)/(E^2+a^2) on [0,E1].
    Fprime is evaluated vectorially, so the expensive prime sum is performed
    in large BLAS-like chunks rather than one quadrature callback at a time.
    """
    nodes, weights = leggauss(int(q))
    E = 0.5 * float(E1) * (nodes + 1.0)
    W = 0.5 * float(E1) * weights
    fp = np.asarray(phase.Fprime(E), float)
    val = float(np.sum(W * fp / (E * E + float(a) * float(a))))
    return val


def full_continuum_transform(phase, a):
    """
    Exact/analytic Cauchy transform of the components used in the finite-part
    phase, up to the exponentially tiny x>36L counterterm quadrature tail.

    F'_L = theta'/pi - P'_L/pi + M'_L/pi - AC'/pi.

    For real a>1/2:
      theta  -> [psi((1/2+a)/2)-log pi]/(4a)
      prime  -> -(1/2a) sum_{n<=18L} Lambda(n)e^-n/L n^-(a+1/2)
      M_L    -> +(1/2a) int_2^inf x^-(a+1/2)e^-x/L dx
      AC     -> -(1/2a) int_2^inf x^-(a+1/2) dx
    """
    a = float(a)
    sigma = 0.5 + a

    arch = (float(digamma(sigma / 2.0)) - math.log(math.pi)) / (4.0 * a)

    # phase_w*logs = Lambda(n)/sqrt(n) exp(-n/L)
    prime_coeff = phase.phase_w * phase.logs
    prime_dirichlet = float(
        np.sum(prime_coeff * np.exp(-a * phase.logs))
    )
    prime = -prime_dirichlet / (2.0 * a)

    L = float(phase.L)
    smooth_smoothed = quad(
        lambda x: x ** (-sigma) * math.exp(-x / L),
        2.0,
        np.inf,
        epsabs=1e-14,
        epsrel=1e-12,
        limit=300,
    )[0]
    counter = smooth_smoothed / (2.0 * a)

    smooth_unsmoothed = 2.0 ** (1.0 - sigma) / (sigma - 1.0)
    ac = -smooth_unsmoothed / (2.0 * a)

    return {
        "arch": arch,
        "prime": prime,
        "counter": counter,
        "ac": ac,
        "total": arch + prime + counter + ac,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--a-probes", default="2,3,4,5")
    ap.add_argument("--moment-order", type=int, default=10)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=384)
    ap.add_argument("--low-q", type=int, default=384)
    ap.add_argument("--low-qcheck", type=int, default=768)
    ap.add_argument(
        "--prefix",
        default="rot_rh_low_branch_em_resolvent_v107",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    aprobes = parse_floats(args.a_probes)

    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")
    if not archive.exists() or not manifest_path.exists():
        raise FileNotFoundError("v102.1 frozen files not found.")

    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    if got != man.get("sha256"):
        raise RuntimeError("v102.1 SHA mismatch.")

    data = np.load(archive, allow_pickle=False)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("=" * 152)
    print("ROT-RH v107 — LOW-BRANCH / EULER–MACLAURIN RESOLVENT DECOMPOSITION")
    print("=" * 152)
    print("v102.1 SHA verified             :", True)
    print("L ladder                        :", Ls)
    print("depth                           :", args.depth)
    print("a probes                        :", aprobes)
    print("low-branch quadrature           :", args.low_q)
    print("independent low-q check         :", args.low_qcheck)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 152)

    rows = []
    phase_cache = {}

    print("[1] Build finite-part phases and low-branch transforms", flush=True)
    for L in Ls:
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        phase_cache[L] = phase

        roots = np.asarray(data[f"roots_L{L}_d{args.depth}"], float)
        moments = np.asarray(
            data[f"mom_{args.method}_L{L}_d{args.depth}"], float
        )
        E1 = float(roots[0])
        Fp1 = float(phase.Fprime(np.asarray([E1]))[0])

        # Evaluate F' on the two independent low-branch quadratures once per
        # a probe. The denominator depends on a, so the vector F' work is
        # repeated by helper; this is intentional for a simple audit.
        for a in aprobes:
            Rop, Rrem = operator_resolvent_prefix_tail(
                roots, moments, a, args.moment_order
            )
            Jfull = full_continuum_transform(phase, a)

            Jlow = low_branch_integral(phase, E1, a, args.low_q)
            Jlow_check = low_branch_integral(
                phase, E1, a, args.low_qcheck
            )
            qerr = abs(Jlow - Jlow_check)
            Jlow_use = Jlow_check

            Jbranch = Jfull["total"] - Jlow_use

            h0 = 1.0 / (E1 * E1 + a * a)
            half = 0.5 * h0

            # -B2/2! h'(1/2), with h'=g'(E1)/F'(E1).
            B2 = E1 / (
                6.0 * Fp1 * (E1 * E1 + a * a) ** 2
            )

            sampling_exact = Rop - Jbranch
            sampling_em1 = half + B2
            em_remainder = sampling_exact - sampling_em1

            boundary_exact = Rop - Jfull["total"]
            boundary_em1 = -Jlow_use + half + B2
            rational = 1.0 / (a * a - 0.25)

            row = {
                "L": L,
                "a": a,
                "E1": E1,
                "Fprime_E1": Fp1,
                "operator_resolvent": Rop,
                "operator_tail_bound": Rrem,
                "Jfull": Jfull["total"],
                "Jfull_arch": Jfull["arch"],
                "Jfull_prime": Jfull["prime"],
                "Jfull_counter": Jfull["counter"],
                "Jfull_ac": Jfull["ac"],
                "Jlow": Jlow_use,
                "Jlow_q_abs_difference": qerr,
                "Jbranch": Jbranch,
                "half_cell": half,
                "B2": B2,
                "sampling_exact": sampling_exact,
                "sampling_EM1": sampling_em1,
                "EM_remainder": em_remainder,
                "EM_remainder_abs": abs(em_remainder),
                "boundary_exact": boundary_exact,
                "boundary_EM1": boundary_em1,
                "rational_target": rational,
                "boundary_exact_minus_rational":
                    boundary_exact - rational,
                "boundary_EM1_minus_rational":
                    boundary_em1 - rational,
            }
            rows.append(row)

        rr = [r for r in rows if r["L"] == L]
        print(
            f"  L={L:<6d}: E1={E1:.9f} F'(E1)={Fp1:+.6e} "
            f"max low-q diff={max(r['Jlow_q_abs_difference'] for r in rr):.2e} "
            f"max |EM rem|={max(r['EM_remainder_abs'] for r in rr):.3e}"
        )

    print("[2] Final-L decomposition by probe", flush=True)
    finalL = Ls[-1]
    final = [r for r in rows if r["L"] == finalL]
    for r in final:
        print(
            f"  a={r['a']:g}: "
            f"Rop={r['operator_resolvent']:.15e} "
            f"Jfull={r['Jfull']:+.15e} "
            f"-Jlow={-r['Jlow']:+.15e} "
            f"half={r['half_cell']:+.3e} "
            f"B2={r['B2']:+.3e} "
            f"EMrem={r['EM_remainder']:+.3e} "
            f"Bexact-rat={r['boundary_exact_minus_rational']:+.3e}"
        )

    print("[3] L-flow of the true EM remainder", flush=True)
    flow = []
    for a in aprobes:
        ar = [r for r in rows if r["a"] == a]
        for r0, r1 in zip(ar[:-1], ar[1:]):
            flow.append(
                {
                    "a": a,
                    "L_from": r0["L"],
                    "L_to": r1["L"],
                    "EM_remainder_from": r0["EM_remainder"],
                    "EM_remainder_to": r1["EM_remainder"],
                    "EM_remainder_abs_drift":
                        abs(r1["EM_remainder"] - r0["EM_remainder"]),
                    "boundary_exact_minus_rational_from":
                        r0["boundary_exact_minus_rational"],
                    "boundary_exact_minus_rational_to":
                        r1["boundary_exact_minus_rational"],
                }
            )
        last = flow[-1]
        print(
            f"  a={a:g}, latest {last['L_from']}->{last['L_to']}: "
            f"EMrem {last['EM_remainder_from']:+.3e} -> "
            f"{last['EM_remainder_to']:+.3e}, "
            f"drift={last['EM_remainder_abs_drift']:.3e}"
        )

    max_qerr = max(r["Jlow_q_abs_difference"] for r in final)
    max_emrem = max(r["EM_remainder_abs"] for r in final)
    max_boundary_rat = max(
        abs(r["boundary_exact_minus_rational"]) for r in final
    )

    gates = {
        "low_branch_quadrature_stable": max_qerr < 1e-9,
        "EM1_explains_sampling_to_1e4": max_emrem < 1e-4,
        "boundary_package_tracks_rational_to_1e4":
            max_boundary_rat < 1e-4,
    }
    verdict = (
        "PASS_V107_LOW_BRANCH_PLUS_EM_STRUCTURE_SUPPORTED__NEXT_BOUND_HIGHER_EM_REMAINDER"
        if all(gates.values())
        else "PARTIAL_V107_BOUNDARY_DECOMPOSITION_NEEDS_REFINEMENT"
    )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_DECOMPOSITION.csv"), rows)
    write_csv(Path(str(prefix) + "_L_FLOW.csv"), flow)
    Path(str(prefix) + "_VERDICT.json").write_text(
        json.dumps(
            {
                "version": VERSION,
                "build": BUILD,
                "verdict": verdict,
                "RH_proof": False,
                "Xi_used": False,
                "zeta_used": False,
                "known_zeros_used": False,
                "source_v102_sha256": got,
                "gates": gates,
                "final_max_low_q_difference": max_qerr,
                "final_max_EM_remainder_abs": max_emrem,
                "final_max_boundary_minus_rational_abs": max_boundary_rat,
                "theorem_target": (
                    "Prove the selected-branch Euler–Maclaurin formula with "
                    "uniform control of the higher remainder, and prove that "
                    "the low-branch plus boundary package converges to the "
                    "elementary rational contribution in the arithmetic "
                    "resolvent. Combined with absolute convergence of the "
                    "Gamma/Mangoldt Cauchy transforms, this yields the "
                    "resolvent convergence theorem."
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\n" + "=" * 152)
    print("FINAL v107 VERDICT")
    print("=" * 152)
    print("verdict                         :", verdict)
    print("final max low-q difference      :", f"{max_qerr:.12e}")
    print("final max |EM remainder|        :", f"{max_emrem:.12e}")
    print("final max |boundary-rational|   :", f"{max_boundary_rat:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("=" * 152)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
