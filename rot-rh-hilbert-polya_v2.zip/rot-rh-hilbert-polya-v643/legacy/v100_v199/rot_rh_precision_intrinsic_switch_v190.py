#!/usr/bin/env python3
"""
ROT-RH v190 — PRECISION-PRESERVING INTRINSIC-GRID SWITCH AUDIT

Purpose
-------
v189 exposed two problems with the later switch-159 interpretation:

1) float64 CSV serialization of E changes the reconstructed epsilon by ~1e6;
2) the old adaptive continuation mesh is extremely sparse in the intrinsic
   crossover coordinate x = Delta a * (tau-tau_s).

v190 reruns ONE requested switch from scratch and keeps the root in arbitrary
precision throughout.

Key design
----------
- continuation coordinate: Y = tau E
- no Brent / no global root reconnection
- Newton projection gate in Y cells
- sampling grid uniform in intrinsic x
- recursive subdivision only if a continuation step violates the Y-cell gate
- epsilon is evaluated directly at the in-memory mp root before any float cast
- high-precision values are written as decimal strings
- integration is compared on:
    fine grid,
    every 2nd point,
    every 4th point
  to expose quadrature under-resolution.

No Xi / zeta / known zeros are used.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


class TwoLayerPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b-mp.mpf("0.5")

            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def eval_E(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws = []
        logs = []

        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        Z = mp.fsum(zs)
        S = mp.im(Z)
        R = mp.re(Z)

        G = mp.fsum(
            g*mp.re(z)
            for g, z in zip(self.g, zs)
        )
        A = mp.fsum(
            a*mp.im(z)
            for a, z in zip(self.a, zs)
        )
        Q = mp.im(mp.fsum(
            1j*mp.digamma(w)*z
            for w, z in zip(ws, zs)
        ))

        SE = tau*R+Q
        St = E*R-G+A

        return {
            "S": S,
            "R": R,
            "G": G,
            "A": A,
            "Q": Q,
            "SE": SE,
            "St": St,
        }

    def eval_Y(self, Y, tau, gamma_active):
        tau = mp.mpf(tau)
        Y = mp.mpf(Y)
        ga = mp.mpf(gamma_active)

        E = Y/tau
        q = self.eval_E(E, tau)

        Yt = E-tau*q["St"]/q["SE"]
        eps = Yt-ga

        eps_mix = tau*(q["G"]-ga*q["R"])/q["SE"]
        eps_A = -tau*q["A"]/q["SE"]
        eps_dig = q["Q"]*(E-ga)/q["SE"]

        return {
            **q,
            "Y": Y,
            "E": E,
            "Yt": Yt,
            "epsilon": eps,
            "epsilon_mix": eps_mix,
            "epsilon_A": eps_A,
            "epsilon_digamma": eps_dig,
            "epsilon_identity_residual": abs(
                eps-(eps_mix+eps_A+eps_dig)
            ),
        }

    def flow_Y(self, Y, tau):
        tau = mp.mpf(tau)
        E = mp.mpf(Y)/tau
        q = self.eval_E(E, tau)
        return E-tau*q["St"]/q["SE"]


def newton_Y(
    phase, Y0, tau, tol, cell_fraction, iterations
):
    Y = mp.mpf(Y0)
    tau = mp.mpf(tau)
    total = mp.mpf("0")
    max_step = mp.mpf("0")

    for it in range(iterations):
        E = Y/tau
        q = phase.eval_E(E, tau)

        if abs(q["S"]) <= tol:
            return {
                "ok": True,
                "Y": Y,
                "E": E,
                "residual": abs(q["S"]),
                "iterations": it,
                "total_cell_shift": abs(total)/mp.pi,
                "max_step_cell_shift": max_step,
            }

        SY = q["SE"]/tau
        if SY == 0 or not mp.isfinite(SY):
            return {"ok": False, "reason": "SY_zero_or_nonfinite"}

        step = -q["S"]/SY
        ratio = abs(step)/mp.pi

        if ratio > cell_fraction:
            return {
                "ok": False,
                "reason": "projection_cell_gate",
                "step_cell_shift": ratio,
            }

        Y += step
        total += step
        max_step = max(max_step, ratio)

    E = Y/tau
    q = phase.eval_E(E, tau)

    return {
        "ok": bool(abs(q["S"]) <= tol),
        "reason": "newton_no_convergence",
        "Y": Y,
        "E": E,
        "residual": abs(q["S"]),
        "iterations": iterations,
        "total_cell_shift": abs(total)/mp.pi,
        "max_step_cell_shift": max_step,
    }


def nearest_initial_root(
    phase, tau, center_E, tol, cell_fraction, iterations, cells
):
    tau = mp.mpf(tau)
    centerY = tau*mp.mpf(center_E)
    good = []

    for j in range(-2*cells, 2*cells+1):
        seed = centerY + mp.mpf(j)*mp.pi/2
        p = newton_Y(
            phase, seed, tau, tol, cell_fraction, iterations
        )
        if p["ok"]:
            good.append(p)

    if not good:
        return {"ok": False, "reason": "no_initial_local_root"}

    good.sort(key=lambda r: abs(r["E"]-mp.mpf(center_E)))
    return good[0]


def rk4_predict_Y(phase, Y0, t0, t1):
    t0 = mp.mpf(t0)
    t1 = mp.mpf(t1)
    h = t1-t0

    k1 = phase.flow_Y(Y0, t0)
    k2 = phase.flow_Y(Y0+h*k1/2, t0+h/2)
    k3 = phase.flow_Y(Y0+h*k2/2, t0+h/2)
    k4 = phase.flow_Y(Y0+h*k3, t1)

    return Y0+h*(k1+2*k2+2*k3+k4)/6


def direct_step(
    phase, Y0, t0, t1, tol, cell_fraction, iterations
):
    try:
        pred = rk4_predict_Y(phase, Y0, t0, t1)
    except Exception as exc:
        return {"ok": False, "reason": f"rk4:{exc}"}

    p = newton_Y(
        phase, pred, t1, tol, cell_fraction, iterations
    )

    if not p["ok"]:
        return {
            "ok": False,
            "reason": p.get("reason", "projection_failure"),
        }

    return {
        "ok": True,
        "Y": p["Y"],
        "projection": p,
    }


def adaptive_step(
    phase, Y0, t0, t1,
    tol, cell_fraction, iterations,
    max_depth, depth=0,
):
    d = direct_step(
        phase, Y0, t0, t1, tol, cell_fraction, iterations
    )

    if d["ok"]:
        return {
            "ok": True,
            "Y": d["Y"],
            "max_depth": depth,
            "max_projection_cell_shift": max(
                d["projection"]["total_cell_shift"],
                d["projection"]["max_step_cell_shift"],
            ),
        }

    if depth >= max_depth:
        return {
            "ok": False,
            "reason": "max_subdivision_depth_reached",
            "underlying_reason": d.get("reason", ""),
            "tau_start": t0,
            "tau_end": t1,
            "depth": depth,
        }

    tm = (mp.mpf(t0)+mp.mpf(t1))/2

    left = adaptive_step(
        phase, Y0, t0, tm,
        tol, cell_fraction, iterations,
        max_depth, depth+1,
    )
    if not left["ok"]:
        return left

    right = adaptive_step(
        phase, left["Y"], tm, t1,
        tol, cell_fraction, iterations,
        max_depth, depth+1,
    )
    if not right["ok"]:
        return right

    return {
        "ok": True,
        "Y": right["Y"],
        "max_depth": max(left["max_depth"], right["max_depth"]),
        "max_projection_cell_shift": max(
            left["max_projection_cell_shift"],
            right["max_projection_cell_shift"],
        ),
    }


def mp_trapezoid(xs, ys):
    if len(xs) < 2:
        return mp.nan
    s = mp.mpf("0")
    for i in range(len(xs)-1):
        s += (xs[i+1]-xs[i])*(ys[i+1]+ys[i])/2
    return s


def subset_indices(n, stride):
    idx = list(range(0, n, stride))
    if n-1 not in idx:
        idx.append(n-1)
    return sorted(set(idx))


def integrate_rows(rows, stride):
    idx = subset_indices(len(rows), stride)

    t = [rows[i]["tau_mp"] for i in idx]
    e = [rows[i]["epsilon_mp"] for i in idx]
    em = [rows[i]["epsilon_mix_mp"] for i in idx]
    g = [rows[i]["gamma_active_mp"] for i in idx]

    active = mp_trapezoid(t, g)
    signed = mp_trapezoid(t, e)
    absolute = mp_trapezoid(t, [abs(v) for v in e])
    mix_abs = mp_trapezoid(t, [abs(v) for v in em])

    return {
        "points": len(idx),
        "signed_over_active": signed/active,
        "absolute_over_active": absolute/abs(active),
        "mix_absolute_over_active": mix_abs/abs(active),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument("--switch-index", type=int, default=159)

    ap.add_argument("--dps", type=int, default=60)
    ap.add_argument("--tol-exp", type=int, default=40)
    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--initial-search-cells", type=int, default=8)

    ap.add_argument(
        "--x-halfwidth",
        type=float,
        default=150.0,
        help="Audit x in [-x-halfwidth,+x-halfwidth].",
    )
    ap.add_argument(
        "--x-points",
        type=int,
        default=257,
        help="Uniform intrinsic-grid point count; should be odd.",
    )
    ap.add_argument("--max-subdivision-depth", type=int, default=18)

    ap.add_argument(
        "--prefix",
        default="rot_rh_precision_intrinsic_switch_v190",
    )

    args = ap.parse_args()

    if args.x_points < 9:
        raise ValueError("--x-points must be >=9")

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    j = args.switch_index-1
    left = hull.iloc[j]
    right = hull.iloc[j+1]

    c1 = match_candidate(
        cand, left["beta_active"], left["gamma_active"]
    )
    c2 = match_candidate(
        cand, right["beta_active"], right["gamma_active"]
    )

    b1 = mp.mpf(str(float(c1["beta"])))
    g1 = mp.mpf(str(float(c1["gamma"])))
    b2 = mp.mpf(str(float(c2["beta"])))
    g2 = mp.mpf(str(float(c2["gamma"])))

    ts = mp.mpf(str(float(left["tau_end"])))
    da = abs(b2-b1)

    phase = TwoLayerPhase(b1, g1, b2, g2)

    # Uniform x grid, exactly centered at x=0.
    xvals = [
        mp.mpf(str(v))
        for v in np.linspace(
            -args.x_halfwidth,
            +args.x_halfwidth,
            args.x_points,
        )
    ]
    taus = [ts+x/da for x in xvals]

    if min(taus) <= 0:
        raise ValueError("x window produces nonpositive tau.")

    print("="*182)
    print("ROT-RH v190 — PRECISION-PRESERVING INTRINSIC-GRID SWITCH AUDIT")
    print("="*182)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switch                            : {args.switch_index}")
    print(f"gamma                             : {mp.nstr(g1,12)} -> {mp.nstr(g2,12)}")
    print(f"delta a                           : {mp.nstr(da,12)}")
    print(f"tau switch                        : {mp.nstr(ts,15)}")
    print(f"x window                          : [{-args.x_halfwidth},{args.x_halfwidth}]")
    print(f"x points                          : {args.x_points}")
    print(f"dx                                : {2*args.x_halfwidth/(args.x_points-1):.6e}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*182)

    init = nearest_initial_root(
        phase,
        taus[0],
        g1,
        tol,
        frac,
        args.newton_iters,
        args.initial_search_cells,
    )
    if not init["ok"]:
        raise RuntimeError("Initial root unresolved.")

    Y = init["Y"]
    rows = []
    max_depth = 0
    max_proj = mp.mpf("0")

    for k, (x, tau) in enumerate(zip(xvals, taus)):
        if k > 0:
            adv = adaptive_step(
                phase,
                Y,
                taus[k-1],
                tau,
                tol,
                frac,
                args.newton_iters,
                args.max_subdivision_depth,
            )
            if not adv["ok"]:
                raise RuntimeError(
                    f"Continuation failed at grid {k}/{len(taus)-1}: {adv}"
                )

            Y = adv["Y"]
            max_depth = max(max_depth, adv["max_depth"])
            max_proj = max(
                max_proj, adv["max_projection_cell_shift"]
            )

        ga = g1 if tau <= ts else g2
        ev = phase.eval_Y(Y, tau, ga)

        rows.append({
            "x_mp": x,
            "tau_mp": tau,
            "Y_mp": Y,
            "E_mp": ev["E"],
            "gamma_active_mp": ga,
            "epsilon_mp": ev["epsilon"],
            "epsilon_mix_mp": ev["epsilon_mix"],
            "epsilon_A_mp": ev["epsilon_A"],
            "epsilon_digamma_mp": ev["epsilon_digamma"],
            "phase_residual_mp": abs(ev["S"]),
            "identity_residual_mp": ev["epsilon_identity_residual"],
            "abs_SE_mp": abs(ev["SE"]),
        })

        if (
            k == 0
            or k == len(taus)-1
            or k == len(taus)//2
            or (k+1) % max(1, len(taus)//8) == 0
        ):
            print(
                f"[{k+1:4d}/{len(taus)}] "
                f"x={float(x): .3f} "
                f"E={mp.nstr(ev['E'],12)} "
                f"|eps|/g={float(abs(ev['epsilon'])/abs(ga)):.3e}"
            )

    fine = integrate_rows(rows, 1)
    coarse2 = integrate_rows(rows, 2)
    coarse4 = integrate_rows(rows, 4)

    def rel_diff(a, b):
        aa = abs(mp.mpf(a))
        bb = abs(mp.mpf(b))
        return abs(aa-bb)/max(aa, mp.mpf("1e-100"))

    conv2 = rel_diff(
        fine["mix_absolute_over_active"],
        coarse2["mix_absolute_over_active"],
    )
    conv4 = rel_diff(
        fine["mix_absolute_over_active"],
        coarse4["mix_absolute_over_active"],
    )

    max_phase_resid = max(r["phase_residual_mp"] for r in rows)
    max_identity_resid = max(r["identity_residual_mp"] for r in rows)

    # Float64 sensitivity audit without reprojecting:
    sens = []
    for r in rows:
        Efloat = mp.mpf(str(float(r["E_mp"])))
        evf = phase.eval_Y(
            r["tau_mp"]*Efloat,
            r["tau_mp"],
            r["gamma_active_mp"],
        )
        sens.append(
            abs(evf["epsilon"]-r["epsilon_mp"])
            / max(abs(r["gamma_active_mp"]), mp.mpf("1"))
        )
    max_float_eps_sensitivity = max(sens)
    med_float_eps_sensitivity = sorted(sens)[len(sens)//2]

    # Persist high precision as strings.
    out_rows = []
    digits = max(args.dps-5, 30)

    for r in rows:
        out_rows.append({
            "x": mp.nstr(r["x_mp"], digits),
            "tau": mp.nstr(r["tau_mp"], digits),
            "Y": mp.nstr(r["Y_mp"], digits),
            "E": mp.nstr(r["E_mp"], digits),
            "gamma_active": mp.nstr(r["gamma_active_mp"], digits),
            "epsilon": mp.nstr(r["epsilon_mp"], digits),
            "epsilon_mix": mp.nstr(r["epsilon_mix_mp"], digits),
            "epsilon_A": mp.nstr(r["epsilon_A_mp"], digits),
            "epsilon_digamma": mp.nstr(r["epsilon_digamma_mp"], digits),
            "phase_residual": mp.nstr(r["phase_residual_mp"], digits),
            "identity_residual": mp.nstr(r["identity_residual_mp"], digits),
            "abs_SE": mp.nstr(r["abs_SE_mp"], digits),
        })

    pd.DataFrame(out_rows).to_csv(
        args.prefix+"_POINTS.csv", index=False
    )

    # Conservative verdict.
    quadrature_converged = bool(
        float(conv2) <= 0.02
        and float(conv4) <= 0.10
    )

    if not quadrature_converged:
        verdict = "INTRINSIC_GRID_QUADRATURE_UNRESOLVED"
    elif float(fine["absolute_over_active"]) < 1e-5:
        verdict = "ORIGINAL_TINY_CESARO_ERROR_CONFIRMED"
    elif float(fine["absolute_over_active"]) >= 1e-3:
        verdict = "PERCENT_LEVEL_CESARO_ERROR_CONFIRMED"
    else:
        verdict = "INTERMEDIATE_CESARO_ERROR_CONFIRMED"

    summary = {
        "version": 190,
        "switch": args.switch_index,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "x_halfwidth": args.x_halfwidth,
        "x_points": args.x_points,
        "fine": {
            k: float(v) if k != "points" else v
            for k, v in fine.items()
        },
        "stride2": {
            k: float(v) if k != "points" else v
            for k, v in coarse2.items()
        },
        "stride4": {
            k: float(v) if k != "points" else v
            for k, v in coarse4.items()
        },
        "relative_mix_difference_stride2": float(conv2),
        "relative_mix_difference_stride4": float(conv4),
        "max_phase_residual": float(max_phase_resid),
        "max_identity_residual": float(max_identity_resid),
        "max_subdivision_depth": max_depth,
        "max_projection_cell_shift": float(max_proj),
        "median_float64_epsilon_sensitivity_over_gamma": float(
            med_float_eps_sensitivity
        ),
        "max_float64_epsilon_sensitivity_over_gamma": float(
            max_float_eps_sensitivity
        ),
        "quadrature_converged": quadrature_converged,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*182)
    print(
        f"fine      |eps|/active             : "
        f"{float(fine['absolute_over_active']):.12e}"
    )
    print(
        f"fine      |mix|/active             : "
        f"{float(fine['mix_absolute_over_active']):.12e}"
    )
    print(
        f"stride-2  |mix|/active             : "
        f"{float(coarse2['mix_absolute_over_active']):.12e}"
    )
    print(
        f"stride-4  |mix|/active             : "
        f"{float(coarse4['mix_absolute_over_active']):.12e}"
    )
    print(
        f"stride-2 relative difference       : "
        f"{float(conv2):.6e}"
    )
    print(
        f"stride-4 relative difference       : "
        f"{float(conv4):.6e}"
    )
    print(f"max phase residual                 : {float(max_phase_resid):.6e}")
    print(f"max identity residual              : {float(max_identity_resid):.6e}")
    print(f"max subdivision depth              : {max_depth}")
    print(f"max projection cell shift          : {float(max_proj):.6e}")
    print(
        f"median float64 eps sensitivity/g   : "
        f"{float(med_float_eps_sensitivity):.6e}"
    )
    print(
        f"max float64 eps sensitivity/g      : "
        f"{float(max_float_eps_sensitivity):.6e}"
    )
    print(f"quadrature converged                : {quadrature_converged}")
    print(f"VERDICT                            : {verdict}")
    print("="*182)


if __name__ == "__main__":
    main()
