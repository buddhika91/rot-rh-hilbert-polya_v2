#!/usr/bin/env python3
"""
ROT-RH v187 — FUNCTIONAL-MIRROR GROUPED-ENVELOPE SLOPE AUDIT

Background
----------
v186.1 showed for switch 159 that the exact normalized mixing profile is
essentially identical to the active-oriented ENVELOPE model built from

    C_i = z(a_i,+gamma_i) + z(-a_i,+gamma_i),
    A_i = |C_i|,

where the second term is the functional-mirror contribution.

This explains why v185 failed: v185 differentiated only the single direct
Gamma envelope |Gamma(a_i+i(E-gamma_i))|, not the grouped amplitude |C_i|.

Along the moving root E(tau),

    z' = z * [ w + i E' (psi(w)+tau) ],

so exactly

    C_i' = sum_mirror z_m *
           [ w_m + i E'(psi(w_m)+tau) ],

and

    d/dtau log A_i = Re(C_i'/C_i).

Therefore the grouped relative-envelope slope is

    lambda = d/dtau log(A2/A1)
           = Re(C2'/C2) - Re(C1'/C1).

Define the intrinsic broadening

    B_group = Delta a / |lambda|.

If the active-oriented envelope is locally logistic,

    m(x) ~ 1/(1+exp(|x|/B_group)),
    x = Delta a (tau-tau_s),

then
    X50 / B = 0.881373...
    X90 / B = 2.634240...

This script compares the exact grouped-envelope derivative with those
observed width estimates.

No continuation is performed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


LOGISTIC_X50_OVER_B = 0.881373587019543
LOGISTIC_X90_OVER_B = -np.log(2.0**0.1 - 1.0)


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def cumulative_symmetric_width(x, m, q, grid_n=8193):
    x = np.asarray(x, float)
    m = np.asarray(m, float)
    ok = np.isfinite(x) & np.isfinite(m)
    x = x[ok]
    m = m[ok]

    if len(x) < 2:
        return np.nan, np.nan

    order = np.argsort(x)
    x = x[order]
    m = m[order]

    xmax = min(abs(float(x[0])), abs(float(x[-1])))
    if xmax <= 0:
        return np.nan, np.nan

    X = np.linspace(0.0, xmax, grid_n)
    f = np.interp(X, x, m) + np.interp(-X, x, m)

    K = np.zeros_like(X)
    dx = np.diff(X)
    K[1:] = np.cumsum(0.5*(f[1:]+f[:-1])*dx)

    if K[-1] <= 0:
        return np.nan, 0.0

    return float(np.interp(q*K[-1], K, X)), float(K[-1])


class GroupedEnvelope:
    def __init__(self, b1, g1, b2, g2):
        self.a1 = mp.mpf(str(b1)) - mp.mpf("0.5")
        self.a2 = mp.mpf(str(b2)) - mp.mpf("0.5")
        self.g1 = mp.mpf(str(g1))
        self.g2 = mp.mpf(str(g2))

    @staticmethod
    def logterm(a, g, E, tau):
        w = a + 1j*(E-g)
        return w, mp.loggamma(w) + a*tau + 1j*(E-g)*tau

    def evaluate(self, E, tau, gamma_active, epsilon):
        E = mp.mpf(str(E))
        tau = mp.mpf(str(tau))
        ga = mp.mpf(str(gamma_active))
        eps = mp.mpf(str(epsilon))

        # Y' = gamma_active + epsilon, Y=tau E
        Eprime = (ga + eps - E)/tau

        terms = []
        for layer, a, g in [
            (1, self.a1, self.g1),
            (1, -self.a1, self.g1),
            (2, self.a2, self.g2),
            (2, -self.a2, self.g2),
        ]:
            w, logz = self.logterm(a, g, E, tau)
            terms.append({
                "layer": layer,
                "a": a,
                "g": g,
                "w": w,
                "logz": logz,
            })

        shift = max(mp.re(t["logz"]) for t in terms)

        for t in terms:
            z = mp.exp(t["logz"]-shift)
            rate = t["w"] + 1j*Eprime*(mp.digamma(t["w"])+tau)
            t["z"] = z
            t["zp"] = z*rate

        C = {}
        Cp = {}
        for layer in (1,2):
            C[layer] = mp.fsum(
                t["z"] for t in terms if t["layer"] == layer
            )
            Cp[layer] = mp.fsum(
                t["zp"] for t in terms if t["layer"] == layer
            )

        A1 = abs(C[1])
        A2 = abs(C[2])

        h1 = mp.re(Cp[1]/C[1]) if C[1] != 0 else mp.nan
        h2 = mp.re(Cp[2]/C[2]) if C[2] != 0 else mp.nan

        lam = h2-h1
        da = abs(self.a2-self.a1)
        B = da/abs(lam) if lam != 0 else mp.inf

        log_ratio = mp.log(A2/A1) if A1 != 0 and A2 != 0 else mp.nan

        if abs(ga-self.g1) <= abs(ga-self.g2):
            q = A2/A1 if A1 != 0 else mp.inf
        else:
            q = A1/A2 if A2 != 0 else mp.inf

        m_env = q/(1+q) if mp.isfinite(q) else mp.mpf("1")

        return {
            "Eprime": Eprime,
            "A1": A1,
            "A2": A2,
            "log_A2_A1": log_ratio,
            "h1_group": h1,
            "h2_group": h2,
            "lambda_group": lam,
            "B_group": B,
            "m_env": m_env,
        }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--points-csv",
        default="rot_rh_global_cesaro_mix_scale_v183_POINTS.csv",
    )
    ap.add_argument("--switch-indices", default="159")
    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument(
        "--center-neighbors",
        type=int,
        default=2,
        help="Use +/- this many stored points around tau_s for robust B median.",
    )
    ap.add_argument(
        "--agreement-factor-gate",
        type=float,
        default=2.0,
        help="B_group and width-derived B must agree within this multiplicative factor.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_grouped_envelope_slope_v187",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps

    pts = pd.read_csv(args.points_csv)

    required = {
        "switch","tau","E","tau_switch",
        "beta_left","beta_right",
        "gamma_left","gamma_right",
        "gamma_active","epsilon",
    }
    missing = required-set(pts.columns)
    if missing:
        raise RuntimeError(f"Missing columns: {sorted(missing)}")

    switches = [
        int(x.strip()) for x in args.switch_indices.split(",") if x.strip()
    ]
    pts = pts[pts["switch"].astype(int).isin(switches)].copy()

    print("="*178)
    print("ROT-RH v187 — FUNCTIONAL-MIRROR GROUPED-ENVELOPE SLOPE AUDIT")
    print("="*178)
    print(f"switches                          : {switches}")
    print(f"rows                              : {len(pts)}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"logistic X50/B                    : {LOGISTIC_X50_OVER_B:.9f}")
    print(f"logistic X90/B                    : {LOGISTIC_X90_OVER_B:.9f}")
    print("="*178)

    rows = []
    summaries = []

    for sw, g in pts.groupby("switch"):
        g = g.sort_values("tau").reset_index(drop=True)

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        g1 = float(g.iloc[0]["gamma_left"])
        g2 = float(g.iloc[0]["gamma_right"])
        ts = float(g.iloc[0]["tau_switch"])
        da = abs(b2-b1)

        model = GroupedEnvelope(b1,g1,b2,g2)

        local = []
        for _, r in g.iterrows():
            out = model.evaluate(
                float(r["E"]),
                float(r["tau"]),
                float(r["gamma_active"]),
                float(r["epsilon"]),
            )

            rr = {
                "switch": int(sw),
                "tau": float(r["tau"]),
                "tau_switch": ts,
                "x": da*(float(r["tau"])-ts),
                "E": float(r["E"]),
            }
            for k,v in out.items():
                try:
                    rr[k] = float(v)
                except Exception:
                    rr[k] = np.nan

            rows.append(rr)
            local.append(rr)

        d = pd.DataFrame(local).sort_values("tau").reset_index(drop=True)

        # Independent finite-difference check of grouped log-envelope slope.
        tauv = d["tau"].to_numpy(float)
        Lv = d["log_A2_A1"].to_numpy(float)
        if len(d) >= 3:
            d["lambda_fd"] = np.gradient(Lv, tauv)
        else:
            d["lambda_fd"] = np.nan

        # Nearest stored point to nominal switch and robust local median.
        k = int(np.argmin(np.abs(tauv-ts)))
        lo = max(0, k-args.center_neighbors)
        hi = min(len(d), k+args.center_neighbors+1)
        center = d.iloc[lo:hi]

        Bvals = center["B_group"].replace(
            [np.inf,-np.inf],np.nan
        ).dropna().to_numpy(float)

        B_center_med = float(np.median(Bvals)) if len(Bvals) else np.nan
        lambda_center_med = float(
            np.median(center["lambda_group"].dropna().to_numpy(float))
        )

        lambda_fd_center = float(
            np.median(center["lambda_fd"].dropna().to_numpy(float))
        )

        # Envelope profile widths directly from same points.
        x = d["x"].to_numpy(float)
        m = d["m_env"].to_numpy(float)

        X50, Ksym = cumulative_symmetric_width(x,m,0.50)
        X90, _ = cumulative_symmetric_width(x,m,0.90)

        B_from_X50 = X50/LOGISTIC_X50_OVER_B
        B_from_X90 = X90/LOGISTIC_X90_OVER_B

        # compare grouped derivative B to observed profile width-derived B
        ratios = []
        for Bw in [B_from_X50,B_from_X90]:
            if np.isfinite(B_center_med) and B_center_med > 0 and np.isfinite(Bw) and Bw > 0:
                ratios.append(max(B_center_med/Bw, Bw/B_center_med))

        worst_factor = max(ratios) if ratios else np.inf

        supported = bool(
            np.isfinite(B_center_med)
            and B_center_med >= 5.0
            and worst_factor <= args.agreement_factor_gate
        )

        summaries.append({
            "switch": int(sw),
            "samples": len(d),
            "delta_a": da,
            "B_group_local_median": B_center_med,
            "lambda_group_local_median": lambda_center_med,
            "lambda_fd_local_median": lambda_fd_center,
            "lambda_exact_over_fd": (
                lambda_center_med/lambda_fd_center
                if lambda_fd_center != 0 and np.isfinite(lambda_fd_center)
                else np.nan
            ),
            "X50_envelope": X50,
            "X90_envelope": X90,
            "B_from_X50": B_from_X50,
            "B_from_X90": B_from_X90,
            "K_symmetric": Ksym,
            "worst_B_agreement_factor": worst_factor,
            "grouped_envelope_broadening_supported": supported,
        })

        print(
            f"[switch {int(sw):4d}] "
            f"Bgroup={B_center_med:.3e} "
            f"B50={B_from_X50:.3e} "
            f"B90={B_from_X90:.3e} "
            f"lambda={lambda_center_med:.3e} "
            f"lambdaFD={lambda_fd_center:.3e} "
            f"agree={worst_factor:.3e}"
        )

    out = pd.DataFrame(rows)
    swdf = pd.DataFrame(summaries)

    all_supported = bool(
        len(swdf) and swdf["grouped_envelope_broadening_supported"].all()
    )

    verdict = (
        "FUNCTIONAL_MIRROR_GROUPED_ENVELOPE_BROADENING_SUPPORTED"
        if all_supported
        else "FUNCTIONAL_MIRROR_GROUPED_ENVELOPE_BROADENING_UNRESOLVED"
    )

    out.to_csv(args.prefix+"_POINTS.csv",index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv",index=False)

    summary = {
        "version":187,
        "switches":switches,
        "all_supported":all_supported,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*178)
    for _,r in swdf.iterrows():
        print(f"switch {int(r['switch'])}")
        print(f"  grouped-envelope B              : {r['B_group_local_median']:.6e}")
        print(f"  B inferred from X50             : {r['B_from_X50']:.6e}")
        print(f"  B inferred from X90             : {r['B_from_X90']:.6e}")
        print(f"  exact grouped lambda            : {r['lambda_group_local_median']:.6e}")
        print(f"  finite-difference lambda        : {r['lambda_fd_local_median']:.6e}")
        print(f"  worst B agreement factor        : {r['worst_B_agreement_factor']:.6e}")
        print(f"  mechanism supported             : {bool(r['grouped_envelope_broadening_supported'])}")
    print(f"VERDICT                           : {verdict}")
    print("="*178)


if __name__ == "__main__":
    main()
