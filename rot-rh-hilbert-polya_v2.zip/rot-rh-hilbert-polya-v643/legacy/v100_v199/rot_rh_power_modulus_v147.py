#!/usr/bin/env python3
"""
ROT-RH v147 — HELD-OUT POWER-MODULUS CUTOFF-INDEPENDENCE AUDIT

ZERO-COST postprocessor.
No phase builds, no root solving, no prime sums, no Xi/zeta/known-zero data.

Purpose
-------
Turn the all-pairs v146 evidence into an explicit quantitative theorem target.

For fixed mode k, define the old-root defect

    delta_k(L,M) = F_M(E_k(L)) - (k - 1/2),   L < M.

A strong sufficient fixed-mode cutoff-independence statement is

    |delta_k(L,M)| <= C_k |L^(-alpha) - M^(-alpha)|        (1)

for some common alpha > 0 and all sufficiently large L,M.

With a local derivative floor

    |F'_M| >= m_k > 0

on the root segment, (1) gives

    |E_k(M)-E_k(L)|
      <= (C_k/m_k) |L^(-alpha)-M^(-alpha)|.                (2)

Since lambda_k(L)=E_k(L)^(-2),

    |lambda_k(M)-lambda_k(L)|
      <= 2 C_k /(m_k E_{k,min}^3)
         |L^(-alpha)-M^(-alpha)|.                          (3)

Summing k<=N yields an explicit finite-mode Cauchy modulus

    d_N(L,M) <= C_N |L^(-alpha)-M^(-alpha)|.               (4)

Scientific design
-----------------
The script deliberately HOLDS OUT every pair whose larger endpoint is
--holdout-L (default 512000).

It fits the constants C_k only on earlier pairs, then predicts/bounds ALL
held-out 512k defects/root shifts/trace distances.  This avoids simply
constructing a modulus after seeing every endpoint.

For each alpha on a grid it reports:
  * held-out mode coverage,
  * held-out pair aggregate coverage,
  * worst normalized violation,
  * finite-mode trace-modulus coverage,
  * required safety factor.

It then selects the LARGEST alpha whose held-out tests pass under the chosen
safety factor.  Larger alpha = stronger convergence rate.

Inputs
------
v146:
  <prefix>_MODES.csv
  <prefix>_PAIRS.csv

Outputs
-------
<prefix>_ALPHA_SCAN.csv
<prefix>_MODE_CONSTANTS.csv
<prefix>_HOLDOUT.csv
<prefix>_PAIR_PREDICTIONS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception as exc:
    raise RuntimeError("pandas is required for v147") from exc


def power_modulus(L, M, alpha):
    L = float(L)
    M = float(M)
    return abs(L ** (-alpha) - M ** (-alpha))


def safe_ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.nan


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--modes-csv",
        default="rot_rh_all_pairs_local_cutoff_v146_MODES.csv",
    )
    ap.add_argument(
        "--pairs-csv",
        default="rot_rh_all_pairs_local_cutoff_v146_PAIRS.csv",
    )
    ap.add_argument("--holdout-L", type=int, default=512000)
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument("--alpha-min", type=float, default=0.05)
    ap.add_argument("--alpha-max", type=float, default=2.00)
    ap.add_argument("--alpha-points", type=int, default=196)

    ap.add_argument(
        "--safety-factor",
        type=float,
        default=1.25,
        help="Multiply training-derived constants by this before holdout tests.",
    )
    ap.add_argument(
        "--mode-coverage-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--pair-coverage-gate",
        type=float,
        default=1.00,
    )
    ap.add_argument(
        "--trace-coverage-gate",
        type=float,
        default=1.00,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_power_modulus_v147",
    )

    args = ap.parse_args()

    modes_df = pd.read_csv(args.modes_csv)
    pairs_df = pd.read_csv(args.pairs_csv)

    modes_df = modes_df[modes_df["k"] <= args.modes].copy()

    train = modes_df[modes_df["L_b"] < args.holdout_L].copy()
    test = modes_df[modes_df["L_b"] == args.holdout_L].copy()

    if train.empty:
        raise RuntimeError("No training rows before holdout endpoint.")
    if test.empty:
        raise RuntimeError("No held-out rows at --holdout-L.")

    ks = sorted(train["k"].unique().tolist())
    if not ks:
        raise RuntimeError("No modes available.")

    # E_min and derivative-floor constants are derived ONLY from training.
    train_mode_meta = {}
    for k in ks:
        g = train[train["k"] == k]
        # Conservative energy floor from all old/new energies seen in training.
        Emin = float(min(g["E_a"].min(), g["E_b"].min()))
        m_floor = float(g["min_abs_Fprime_segment"].min())
        train_mode_meta[k] = dict(Emin=Emin, m_floor=m_floor)

    alphas = np.linspace(args.alpha_min, args.alpha_max, args.alpha_points)

    scan_rows = []
    constants_by_alpha = {}
    holdout_by_alpha = {}
    pair_predictions_by_alpha = {}

    print("=" * 132)
    print("ROT-RH v147 — HELD-OUT POWER-MODULUS CUTOFF-INDEPENDENCE AUDIT")
    print("=" * 132)
    print("Xi / zeta / known zeros          : NONE")
    print(f"training larger endpoints         : {sorted(train['L_b'].unique().tolist())}")
    print(f"held-out larger endpoint          : {args.holdout_L}")
    print(f"modes                             : 1..{max(ks)}")
    print(f"alpha grid                        : {args.alpha_min}..{args.alpha_max} ({args.alpha_points})")
    print(f"training constant safety factor   : {args.safety_factor}")
    print("=" * 132)

    for alpha in alphas:
        # --------------------------------------------------------------
        # Fit C_k on training only.
        # --------------------------------------------------------------
        mode_constants = {}
        for k in ks:
            g = train[train["k"] == k]
            vals = []

            for _, r in g.iterrows():
                mod = power_modulus(r["L_a"], r["L_b"], alpha)
                if mod <= 0:
                    continue
                vals.append(float(r["abs_old_root_defect"]) / mod)

            if not vals:
                continue

            Ck_raw = max(vals)
            Ck = args.safety_factor * Ck_raw

            meta = train_mode_meta[k]
            m_floor = meta["m_floor"]
            Emin = meta["Emin"]

            root_Ck = Ck / m_floor if m_floor > 0 else np.inf
            lambda_Ck = (
                2.0 * Ck / (m_floor * Emin**3)
                if m_floor > 0 and Emin > 0 else np.inf
            )

            mode_constants[k] = dict(
                Ck_raw=Ck_raw,
                Ck=Ck,
                m_floor=m_floor,
                Emin=Emin,
                root_Ck=root_Ck,
                lambda_Ck=lambda_Ck,
            )

        if len(mode_constants) != len(ks):
            continue

        constants_by_alpha[float(alpha)] = mode_constants

        # --------------------------------------------------------------
        # Held-out mode tests
        # --------------------------------------------------------------
        hold_rows = []
        mode_passes = []

        for _, r in test.iterrows():
            k = int(r["k"])
            if k not in mode_constants:
                continue

            c = mode_constants[k]
            mod = power_modulus(r["L_a"], r["L_b"], alpha)

            defect_bound = c["Ck"] * mod
            root_bound = c["root_Ck"] * mod
            lambda_bound = c["lambda_Ck"] * mod

            actual_defect = float(r["abs_old_root_defect"])
            actual_shift = float(r["abs_root_shift"])

            # Exact lambda difference from the endpoints.
            Ea = float(r["E_a"])
            Eb = float(r["E_b"])
            actual_lambda = abs(Eb**(-2) - Ea**(-2))

            defect_ratio = safe_ratio(actual_defect, defect_bound)
            shift_ratio = safe_ratio(actual_shift, root_bound)
            lambda_ratio = safe_ratio(actual_lambda, lambda_bound)

            passed = (
                np.isfinite(defect_ratio)
                and defect_ratio <= 1.0
            )
            mode_passes.append(passed)

            hold_rows.append(dict(
                alpha=float(alpha),
                L_a=int(r["L_a"]),
                L_b=int(r["L_b"]),
                k=k,
                modulus=mod,
                Ck_training_raw=c["Ck_raw"],
                Ck_with_safety=c["Ck"],
                defect_actual=actual_defect,
                defect_bound=defect_bound,
                defect_actual_over_bound=defect_ratio,
                root_shift_actual=actual_shift,
                root_shift_bound=root_bound,
                root_actual_over_bound=shift_ratio,
                lambda_actual=actual_lambda,
                lambda_bound=lambda_bound,
                lambda_actual_over_bound=lambda_ratio,
                pass_defect=int(passed),
            ))

        holdout_by_alpha[float(alpha)] = hold_rows

        mode_coverage = float(np.mean(mode_passes)) if mode_passes else 0.0
        worst_mode_ratio = max(
            (r["defect_actual_over_bound"] for r in hold_rows),
            default=np.inf,
        )

        # --------------------------------------------------------------
        # Held-out aggregate pair tests
        # --------------------------------------------------------------
        pair_rows = []

        held_pairs = sorted(
            set((int(a), int(b))
                for a, b in zip(test["L_a"], test["L_b"]))
        )

        pair_pass_flags = []
        trace_pass_flags = []

        for La, Lb in held_pairs:
            rows = [r for r in hold_rows if r["L_a"] == La and r["L_b"] == Lb]
            if not rows:
                continue

            actual_def = sum(r["defect_actual"] for r in rows)
            bound_def = sum(r["defect_bound"] for r in rows)

            actual_shift = sum(r["root_shift_actual"] for r in rows)
            bound_shift = sum(r["root_shift_bound"] for r in rows)

            actual_trace = sum(r["lambda_actual"] for r in rows)
            bound_trace = sum(r["lambda_bound"] for r in rows)

            dr = safe_ratio(actual_def, bound_def)
            sr = safe_ratio(actual_shift, bound_shift)
            tr = safe_ratio(actual_trace, bound_trace)

            pair_pass = np.isfinite(dr) and dr <= 1.0
            trace_pass = np.isfinite(tr) and tr <= 1.0

            pair_pass_flags.append(pair_pass)
            trace_pass_flags.append(trace_pass)

            pair_rows.append(dict(
                alpha=float(alpha),
                L_a=La,
                L_b=Lb,
                modulus=power_modulus(La, Lb, alpha),
                sum_defect_actual=actual_def,
                sum_defect_bound=bound_def,
                defect_actual_over_bound=dr,
                sum_root_shift_actual=actual_shift,
                sum_root_shift_bound=bound_shift,
                root_actual_over_bound=sr,
                trace_actual=actual_trace,
                trace_bound=bound_trace,
                trace_actual_over_bound=tr,
                pair_defect_pass=int(pair_pass),
                pair_trace_pass=int(trace_pass),
            ))

        pair_predictions_by_alpha[float(alpha)] = pair_rows

        pair_coverage = float(np.mean(pair_pass_flags)) if pair_pass_flags else 0.0
        trace_coverage = float(np.mean(trace_pass_flags)) if trace_pass_flags else 0.0

        worst_pair_ratio = max(
            (r["defect_actual_over_bound"] for r in pair_rows),
            default=np.inf,
        )
        worst_trace_ratio = max(
            (r["trace_actual_over_bound"] for r in pair_rows),
            default=np.inf,
        )

        # What safety factor would have been minimally required?
        # Since current bounds already include safety_factor,
        # required_sf = safety_factor * worst normalized ratio.
        required_sf_mode = args.safety_factor * worst_mode_ratio
        required_sf_pair = args.safety_factor * worst_pair_ratio
        required_sf_trace = args.safety_factor * worst_trace_ratio
        required_sf = max(required_sf_mode, required_sf_pair, required_sf_trace)

        passed_alpha = (
            mode_coverage >= args.mode_coverage_gate
            and pair_coverage >= args.pair_coverage_gate
            and trace_coverage >= args.trace_coverage_gate
        )

        # Finite-mode theorem constant:
        # d_N(L,M) <= C_N |L^-a-M^-a|
        C_N = sum(c["lambda_Ck"] for c in mode_constants.values())

        scan_rows.append(dict(
            alpha=float(alpha),
            mode_coverage=mode_coverage,
            pair_defect_coverage=pair_coverage,
            pair_trace_coverage=trace_coverage,
            worst_mode_defect_actual_over_bound=worst_mode_ratio,
            worst_pair_defect_actual_over_bound=worst_pair_ratio,
            worst_pair_trace_actual_over_bound=worst_trace_ratio,
            minimum_required_safety_factor=required_sf,
            finite_mode_trace_modulus_constant=C_N,
            passed=int(passed_alpha),
        ))

    if not scan_rows:
        raise RuntimeError("No valid alpha scan rows.")

    scan_df = pd.DataFrame(scan_rows)
    scan_df.to_csv(args.prefix + "_ALPHA_SCAN.csv", index=False)

    passed_df = scan_df[scan_df["passed"] == 1]

    if not passed_df.empty:
        # Strongest rate = largest alpha that survives held-out tests.
        selected_row = passed_df.sort_values("alpha").iloc[-1]
        verdict = "HELD_OUT_POWER_CAUCHY_MODULUS_SUPPORTED"
    else:
        # Best fallback = smallest required safety factor.
        selected_row = scan_df.sort_values(
            ["minimum_required_safety_factor", "alpha"],
            ascending=[True, False],
        ).iloc[0]
        verdict = "POWER_CAUCHY_MODULUS_RATE_UNRESOLVED"

    alpha_star = float(selected_row["alpha"])
    constants = constants_by_alpha[alpha_star]
    hold_rows = holdout_by_alpha[alpha_star]
    pair_rows = pair_predictions_by_alpha[alpha_star]

    # --------------------------------------------------------------
    # Save selected mode constants
    # --------------------------------------------------------------
    mode_rows = []
    for k in ks:
        c = constants[k]
        mode_rows.append(dict(
            alpha=alpha_star,
            k=k,
            Ck_defect_raw=c["Ck_raw"],
            Ck_defect_with_safety=c["Ck"],
            training_min_abs_Fprime=c["m_floor"],
            training_Emin=c["Emin"],
            root_modulus_constant=c["root_Ck"],
            lambda_modulus_constant=c["lambda_Ck"],
        ))

    pd.DataFrame(mode_rows).to_csv(
        args.prefix + "_MODE_CONSTANTS.csv", index=False
    )
    pd.DataFrame(hold_rows).to_csv(
        args.prefix + "_HOLDOUT.csv", index=False
    )
    pd.DataFrame(pair_rows).to_csv(
        args.prefix + "_PAIR_PREDICTIONS.csv", index=False
    )

    C_N = float(selected_row["finite_mode_trace_modulus_constant"])

    # Evaluate a few asymptotic examples using the selected empirical theorem.
    asymptotic_examples = []
    for L in [512000, 1000000, 2000000, 4000000, 8000000]:
        M = 2 * L
        mod = power_modulus(L, M, alpha_star)
        asymptotic_examples.append(dict(
            L=L,
            M=M,
            modulus=mod,
            predicted_trace_upper_bound=C_N * mod,
        ))

    summary = dict(
        version=147,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        scientific_design=dict(
            training_pairs="all v146 rows with L_b < holdout_L",
            holdout_pairs=f"all v146 rows with L_b = {args.holdout_L}",
            holdout_L=args.holdout_L,
        ),
        selected_modulus=dict(
            alpha=alpha_star,
            safety_factor=args.safety_factor,
            mode_coverage=float(selected_row["mode_coverage"]),
            pair_defect_coverage=float(selected_row["pair_defect_coverage"]),
            pair_trace_coverage=float(selected_row["pair_trace_coverage"]),
            worst_mode_ratio=float(selected_row["worst_mode_defect_actual_over_bound"]),
            worst_pair_defect_ratio=float(selected_row["worst_pair_defect_actual_over_bound"]),
            worst_pair_trace_ratio=float(selected_row["worst_pair_trace_actual_over_bound"]),
            minimum_required_safety_factor=float(selected_row["minimum_required_safety_factor"]),
            finite_mode_trace_modulus_constant=C_N,
        ),
        empirical_theorem_candidate=(
            f"For k<=N, |delta_k(L,M)| <= C_k |L^(-{alpha_star:.6g})-M^(-{alpha_star:.6g})|; "
            f"hence d_N(L,M) <= {C_N:.9e} |L^(-{alpha_star:.6g})-M^(-{alpha_star:.6g})|."
        ),
        asymptotic_examples=asymptotic_examples,
        verdict=verdict,
        proof_gap=(
            "The held-out numerical modulus is not a proof. "
            "To establish fixed-mode cutoff independence analytically, derive the same "
            "power modulus (or any modulus tending to zero) directly from the finite-part "
            "cutoff-difference kernel, uniformly for all sufficiently large L,M."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # terminal report
    # --------------------------------------------------------------
    print()
    print("Selected held-out cutoff modulus")
    print("-" * 132)
    print(f"alpha                              : {alpha_star:.9f}")
    print(f"safety factor                      : {args.safety_factor:.6f}")
    print(f"held-out mode coverage             : {selected_row['mode_coverage']:.3f}")
    print(f"held-out pair defect coverage      : {selected_row['pair_defect_coverage']:.3f}")
    print(f"held-out pair trace coverage       : {selected_row['pair_trace_coverage']:.3f}")
    print(f"worst held-out mode/bound ratio    : {selected_row['worst_mode_defect_actual_over_bound']:.6f}")
    print(f"worst pair defect/bound ratio      : {selected_row['worst_pair_defect_actual_over_bound']:.6f}")
    print(f"worst pair trace/bound ratio       : {selected_row['worst_pair_trace_actual_over_bound']:.6f}")
    print(f"minimum required safety factor     : {selected_row['minimum_required_safety_factor']:.6f}")
    print(f"finite-mode trace modulus C_N      : {C_N:.9e}")

    print()
    print("Held-out pair predictions")
    print("-" * 132)
    for r in pair_rows:
        print(
            f"{r['L_a']:>7d}->{r['L_b']:<7d}  "
            f"def={r['sum_defect_actual']:.6e} <= {r['sum_defect_bound']:.6e} "
            f"(x={r['defect_actual_over_bound']:.4f})  "
            f"trace={r['trace_actual']:.6e} <= {r['trace_bound']:.6e} "
            f"(x={r['trace_actual_over_bound']:.4f})"
        )

    print()
    print("Selected finite-mode asymptotic Cauchy bounds")
    print("-" * 132)
    for r in asymptotic_examples:
        print(
            f"{r['L']:>8d}->{r['M']:<8d}  "
            f"d_N <= {r['predicted_trace_upper_bound']:.6e}"
        )

    print()
    print("=" * 132)
    print(f"VERDICT                            : {verdict}")
    print("=" * 132)
    print("ANALYTIC TARGET:")
    print(
        f"  Prove |delta_k(L,M)| <= C_k |L^(-{alpha_star:.6g})-M^(-{alpha_star:.6g})|"
    )
    print("  from the cutoff-difference kernel itself. With the derivative floor,")
    print("  this gives a quantitative fixed-mode Cauchy theorem for arbitrary L,M.")


if __name__ == "__main__":
    main()
