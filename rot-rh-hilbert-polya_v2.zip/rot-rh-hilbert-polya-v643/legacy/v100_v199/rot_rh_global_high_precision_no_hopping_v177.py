#!/usr/bin/env python3
"""
ROT-RH v177 — GLOBAL HIGH-PRECISION NO-HOPPING ROOT-MANIFOLD AUDIT

Purpose
-------
v176 proved that the local v174/v175 failures were float64 conditioning
artifacts: every failed interval crossed cleanly at 100 digits.

v177 now performs the decisive global test on the same two-layer synthetic
adversary:

    tau = 100  ->  1e8

using:
  * mpmath arbitrary precision;
  * the exact synthetic 8-term phase used in v173/v176;
  * implicit-flow RK4 predictor in u = log(tau);
  * HIGH-PRECISION NEWTON ONLY corrector;
  * recursive interval subdivision if a projection is too large;
  * every Newton step constrained to a small fraction of pi/tau;
  * no Brent, no global root search, no reconnect-to-nearest-root fallback;
  * tracked branch-order checks.

This determines whether a genuinely continued simple root branch:
  A) remains bounded / converges near the first synthetic zero ordinate;
  B) undergoes a certified transition toward the second layer;
  C) escapes while preserving the no-hopping certificate.

Synthetic phase
---------------
For each candidate right-half zero rho=beta+i gamma, include:
  rho, conjugate, 1-rho mirror, and mirror conjugate.

With a=beta-1/2,

  Z = Gamma(a+i(E-gamma))
      exp[a*tau + i(E-gamma)*tau].

The scaled secular model is

  S(E,tau) = Im sum Z = 0.

A common positive exponential scale is removed numerically; zero locations
and the implicit root-flow ratio at S=0 are unchanged.

Certification
-------------
At each accepted endpoint:
  * Newton residual <= 10^-tol_exp;
  * every Newton step <= projection_spacing_fraction * pi/tau;
  * |S_E| remains above transversality gate;
  * no tracked branch crossing;
  * no branch ever uses a root-search fallback.

Outputs
-------
<prefix>_TRAJECTORIES.csv
<prefix>_BRANCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def fmtmp(x, n=10):
    try:
        return mp.nstr(x, n)
    except Exception:
        return str(x)


# ---------------------------------------------------------------------------
# high-precision phase
# ---------------------------------------------------------------------------

class MPZeroPhase:
    def __init__(self, beta, gamma):
        aa, gg = [], []

        for b, g in zip(beta, gamma):
            b = mp.mpf(str(b))
            g = mp.mpf(str(g))
            a = b - mp.mpf("0.5")

            # rho and conjugate
            aa += [a, a]
            gg += [g, -g]

            # functional-equation mirror 1-rho and its conjugate
            aa += [-a, -a]
            gg += [g, -g]

        self.a = aa
        self.gamma = gg

    def eval(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws = []
        logs = []

        for a, g in zip(self.a, self.gamma):
            w = a + 1j*(E-g)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )
            ws.append(w)

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        S = mp.im(mp.fsum(zs))

        dE_terms = []
        dt_terms = []

        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE_terms.append(1j*(psi+tau)*z)
            dt_terms.append(w*z)

        SE = mp.im(mp.fsum(dE_terms))
        St = mp.im(mp.fsum(dt_terms))

        return S, SE, St, shift

    def flow_u(self, E, u):
        """
        dE/du for u=log(tau):
            dE/du = -tau S_tau / S_E.
        """
        tau = mp.exp(u)
        S, SE, St, _ = self.eval(E, tau)

        if abs(SE) == 0 or not mp.isfinite(SE):
            raise ArithmeticError("S_E zero/nonfinite in flow.")

        return -tau*St/SE


# ---------------------------------------------------------------------------
# high precision root refinement / predictor-corrector
# ---------------------------------------------------------------------------

def mp_newton(
    phase,
    E0,
    tau,
    tol,
    spacing_fraction,
    iterations,
):
    E = mp.mpf(E0)
    tau = mp.mpf(tau)

    spacing = mp.pi/tau
    total = mp.mpf("0")
    max_step_ratio = mp.mpf("0")

    for it in range(iterations):
        S, SE, St, shift = phase.eval(E, tau)

        if abs(S) <= tol:
            return dict(
                ok=True,
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
                iterations=it,
                total_correction=total,
                correction_over_spacing=abs(total)/spacing,
                max_step_over_spacing=max_step_ratio,
            )

        if abs(SE) == 0 or not mp.isfinite(SE):
            return dict(
                ok=False,
                reason="SE_zero_or_nonfinite",
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
            )

        step = -S/SE
        ratio = abs(step)/spacing

        if ratio > spacing_fraction:
            return dict(
                ok=False,
                reason="projection_step_exceeds_spacing_gate",
                E=E,
                residual=abs(S),
                abs_SE=abs(SE),
                attempted_step=step,
                step_over_spacing=ratio,
            )

        E += step
        total += step
        max_step_ratio = max(max_step_ratio, ratio)

    S, SE, *_ = phase.eval(E, tau)

    return dict(
        ok=bool(abs(S) <= tol),
        reason="newton_no_convergence",
        E=E,
        residual=abs(S),
        abs_SE=abs(SE),
        iterations=iterations,
        total_correction=total,
        correction_over_spacing=abs(total)/spacing,
        max_step_over_spacing=max_step_ratio,
    )


def rk4_predict_u(phase, E0, u0, u1):
    E0 = mp.mpf(E0)
    u0 = mp.mpf(u0)
    u1 = mp.mpf(u1)

    h = u1-u0

    k1 = phase.flow_u(E0, u0)
    k2 = phase.flow_u(E0 + h*k1/2, u0+h/2)
    k3 = phase.flow_u(E0 + h*k2/2, u0+h/2)
    k4 = phase.flow_u(E0 + h*k3, u1)

    return E0 + h*(k1 + 2*k2 + 2*k3 + k4)/6


def attempt_step(
    phase,
    E0,
    tau0,
    tau1,
    tol,
    spacing_fraction,
    newton_iters,
):
    u0 = mp.log(mp.mpf(tau0))
    u1 = mp.log(mp.mpf(tau1))

    try:
        E_pred = rk4_predict_u(phase, E0, u0, u1)
    except Exception as exc:
        return dict(
            ok=False,
            reason="rk4_flow_failure",
            message=str(exc),
        )

    proj = mp_newton(
        phase,
        E_pred,
        tau1,
        tol,
        spacing_fraction,
        newton_iters,
    )

    if not proj["ok"]:
        return dict(
            ok=False,
            reason=proj.get("reason", "projection_failure"),
            E_pred=E_pred,
            projection=proj,
        )

    return dict(
        ok=True,
        E=proj["E"],
        E_pred=E_pred,
        projection=proj,
    )


def adaptive_advance(
    phase,
    E0,
    tau0,
    tau1,
    tol,
    spacing_fraction,
    newton_iters,
    max_depth,
    depth=0,
):
    """
    Advance [tau0,tau1].  If a certified direct RK4+Newton step fails,
    bisect in log(tau) recursively.

    Returns all accepted leaf endpoints so the trajectory remains auditable.
    """
    direct = attempt_step(
        phase,
        E0,
        tau0,
        tau1,
        tol,
        spacing_fraction,
        newton_iters,
    )

    if direct["ok"]:
        proj = direct["projection"]
        return dict(
            ok=True,
            E=direct["E"],
            leaves=[dict(
                tau_start=float(tau0),
                tau_end=float(tau1),
                E_end=direct["E"],
                E_pred=direct["E_pred"],
                depth=depth,
                residual=proj["residual"],
                abs_SE=proj["abs_SE"],
                correction_over_spacing=proj["correction_over_spacing"],
                max_step_over_spacing=proj["max_step_over_spacing"],
            )],
            max_depth_used=depth,
        )

    if depth >= max_depth:
        return dict(
            ok=False,
            reason="max_subdivision_depth_reached",
            underlying=direct,
            E=E0,
            tau_start=tau0,
            tau_end=tau1,
            depth=depth,
        )

    u0 = mp.log(mp.mpf(tau0))
    u1 = mp.log(mp.mpf(tau1))
    taum = mp.exp((u0+u1)/2)

    left = adaptive_advance(
        phase, E0, tau0, taum,
        tol, spacing_fraction, newton_iters,
        max_depth, depth+1,
    )
    if not left["ok"]:
        return left

    right = adaptive_advance(
        phase, left["E"], taum, tau1,
        tol, spacing_fraction, newton_iters,
        max_depth, depth+1,
    )
    if not right["ok"]:
        return right

    return dict(
        ok=True,
        E=right["E"],
        leaves=left["leaves"] + right["leaves"],
        max_depth_used=max(
            left["max_depth_used"],
            right["max_depth_used"],
        ),
    )


# ---------------------------------------------------------------------------
# optional active-hull diagnostics
# ---------------------------------------------------------------------------

def active_hull_at(hull, tau):
    if hull is None or len(hull) == 0:
        return np.nan, np.nan

    ends = hull["tau_end"].to_numpy(dtype=float)
    idx = int(np.searchsorted(ends, float(tau), side="left"))
    idx = min(max(idx, 0), len(hull)-1)

    r = hull.iloc[idx]
    return float(r["gamma_active"]), float(r["beta_active"])


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--candidates-csv",
        default="rot_rh_bellotti_density_adversary_v171_mu4_cap1_CANDIDATES.csv",
    )
    ap.add_argument(
        "--initial-trajectories",
        default="rot_rh_no_hopping_ode_cert_v174_TRAJECTORIES.csv",
        help="Used only for the tau=100 branch seeds.",
    )
    ap.add_argument(
        "--hull-csv",
        default="rot_rh_bellotti_density_adversary_v171_mu4_cap1_HULL.csv",
        help="Optional v171 hull for diagnostics only.",
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)
    ap.add_argument("--checkpoints", type=int, default=1600)
    ap.add_argument("--branches", type=int, default=8)

    ap.add_argument("--dps", type=int, default=100)
    ap.add_argument("--tol-exp", type=int, default=60)
    ap.add_argument("--newton-iters", type=int, default=20)
    ap.add_argument(
        "--projection-spacing-fraction",
        type=float,
        default=0.10,
    )
    ap.add_argument(
        "--max-subdivision-depth",
        type=int,
        default=14,
    )
    ap.add_argument(
        "--transversality-gate",
        type=float,
        default=1e-20,
    )

    ap.add_argument(
        "--bounded-E-gate",
        type=float,
        default=200.0,
    )
    ap.add_argument(
        "--convergence-tail-fraction",
        type=float,
        default=0.20,
    )
    ap.add_argument(
        "--convergence-relative-span-gate",
        type=float,
        default=1e-3,
        help="Tail span / max(1,|tail mean|) threshold for bounded convergence.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_global_high_precision_no_hopping_v177",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    spacing_fraction = mp.mpf(
        str(args.projection_spacing_fraction)
    )

    cand = pd.read_csv(args.candidates_csv)
    init = pd.read_csv(args.initial_trajectories)

    if not {"beta", "gamma"}.issubset(cand.columns):
        raise RuntimeError("Candidates CSV needs beta,gamma.")
    if not {"branch", "tau", "E"}.issubset(init.columns):
        raise RuntimeError(
            "Initial trajectories CSV needs branch,tau,E."
        )

    hull = None
    hp = Path(args.hull_csv)
    if hp.exists():
        hull = pd.read_csv(hp).sort_values("tau_start").reset_index(drop=True)

    phase = MPZeroPhase(
        cand["beta"].to_numpy(float),
        cand["gamma"].to_numpy(float),
    )

    # Extract earliest point per branch; v174 starts at tau=100.
    seeds = []
    for b in sorted(init["branch"].unique())[:args.branches]:
        g = init[init["branch"] == b].sort_values("tau")
        r = g.iloc[0]
        seeds.append(
            (int(b), float(r["tau"]), float(r["E"]))
        )

    if len(seeds) == 0:
        raise RuntimeError("No branch seeds found.")

    tau_grid = np.geomspace(
        args.tau_min,
        args.tau_max,
        args.checkpoints,
    )

    print("=" * 168)
    print("ROT-RH v177 — GLOBAL HIGH-PRECISION NO-HOPPING ROOT-MANIFOLD AUDIT")
    print("=" * 168)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"complex terms with symmetries     : {len(phase.a)}")
    print(f"branches                          : {len(seeds)}")
    print(f"tau window                        : [{args.tau_min:.6g}, {args.tau_max:.6g}]")
    print(f"global checkpoints                : {len(tau_grid)}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"Newton tolerance                  : 1e-{args.tol_exp}")
    print(f"projection gate                   : {args.projection_spacing_fraction} * pi/tau")
    print(f"max adaptive subdivision depth    : {args.max_subdivision_depth}")
    print("=" * 168)

    trajectory_rows = []
    branch_rows = []

    for b, tau_seed_f, E_seed_f in seeds:
        print()
        print(
            f"[branch {b}] seed tau={tau_seed_f:.12e}, "
            f"E={E_seed_f:.12f}"
        )

        tau0 = mp.mpf(str(args.tau_min))
        Eseed = mp.mpf(str(E_seed_f))

        # Refine seed at exact requested tau_min.
        seed_proj = mp_newton(
            phase,
            Eseed,
            tau0,
            tol,
            spacing_fraction,
            args.newton_iters,
        )

        if not seed_proj["ok"]:
            print(
                f"  seed refinement FAILED: "
                f"{seed_proj.get('reason','')}"
            )
            branch_rows.append(dict(
                branch=b,
                status="SEED_REFINEMENT_FAILED",
            ))
            continue

        E = seed_proj["E"]
        tau_prev = tau0

        S0, SE0, St0, _ = phase.eval(E, tau_prev)
        gact, bact = active_hull_at(hull, float(tau_prev))

        trajectory_rows.append(dict(
            branch=b,
            tau=float(tau_prev),
            E=float(E),
            residual=float(abs(S0)),
            abs_SE=float(abs(SE0)),
            projection_over_spacing=float(
                seed_proj.get("correction_over_spacing", 0)
            ),
            max_step_over_spacing=float(
                seed_proj.get("max_step_over_spacing", 0)
            ),
            subdivision_depth=0,
            gamma_active=gact,
            beta_active=bact,
        ))

        failed = False
        failure_reason = ""
        max_depth_used = 0
        max_proj_ratio = mp.mpf("0")
        min_abs_SE = abs(SE0)
        max_residual = abs(S0)
        accepted_leaves = 0

        # tau_grid[0] should be tau_min. Use remaining checkpoints.
        for gi in range(1, len(tau_grid)):
            tau_target = mp.mpf(str(float(tau_grid[gi])))

            adv = adaptive_advance(
                phase,
                E,
                tau_prev,
                tau_target,
                tol,
                spacing_fraction,
                args.newton_iters,
                args.max_subdivision_depth,
            )

            if not adv["ok"]:
                failed = True
                failure_reason = adv.get("reason", "")
                print(
                    f"  FAIL at checkpoint {gi}/{len(tau_grid)-1}, "
                    f"tau={float(tau_target):.6e}, "
                    f"reason={failure_reason}"
                )
                break

            for leaf in adv["leaves"]:
                accepted_leaves += 1
                max_depth_used = max(
                    max_depth_used,
                    int(leaf["depth"]),
                )
                max_proj_ratio = max(
                    max_proj_ratio,
                    leaf["correction_over_spacing"],
                    leaf["max_step_over_spacing"],
                )
                min_abs_SE = min(
                    min_abs_SE,
                    leaf["abs_SE"],
                )
                max_residual = max(
                    max_residual,
                    leaf["residual"],
                )

            E = adv["E"]
            tau_prev = tau_target

            S, SE, St, _ = phase.eval(E, tau_prev)
            min_abs_SE = min(min_abs_SE, abs(SE))
            max_residual = max(max_residual, abs(S))

            gact, bact = active_hull_at(
                hull, float(tau_prev)
            )

            trajectory_rows.append(dict(
                branch=b,
                tau=float(tau_prev),
                E=float(E),
                residual=float(abs(S)),
                abs_SE=float(abs(SE)),
                projection_over_spacing=float(
                    adv["leaves"][-1]["correction_over_spacing"]
                ),
                max_step_over_spacing=float(
                    adv["leaves"][-1]["max_step_over_spacing"]
                ),
                subdivision_depth=int(
                    adv["max_depth_used"]
                ),
                gamma_active=gact,
                beta_active=bact,
            ))

            if gi % max(1, len(tau_grid)//20) == 0:
                print(
                    f"  {gi:4d}/{len(tau_grid)-1} "
                    f"tau={float(tau_prev):.6e} "
                    f"E={float(E):.12f} "
                    f"depth={adv['max_depth_used']} "
                    f"proj/sp={float(max_proj_ratio):.3e}",
                    flush=True,
                )

        bt = pd.DataFrame(
            [r for r in trajectory_rows if r["branch"] == b]
        ).sort_values("tau")

        Evals = bt["E"].to_numpy(dtype=float)
        taus = bt["tau"].to_numpy(dtype=float)

        tail_n = max(
            3,
            int(args.convergence_tail_fraction*len(Evals))
        )
        tail = Evals[-tail_n:]
        tail_mean = float(np.mean(tail))
        tail_span = float(np.max(tail)-np.min(tail))
        tail_rel_span = tail_span/max(1.0, abs(tail_mean))

        bounded = bool(
            np.max(np.abs(Evals)) <= args.bounded_E_gate
        )
        converged_numerically = bool(
            bounded
            and tail_rel_span
                <= args.convergence_relative_span_gate
        )

        escaped = bool(not bounded)

        branch_rows.append(dict(
            branch=b,
            status=(
                "FAILED" if failed
                else (
                    "BOUNDED_CONVERGENT"
                    if converged_numerically
                    else (
                        "ESCAPED"
                        if escaped
                        else "BOUNDED_NOT_YET_CONVERGED"
                    )
                )
            ),
            failed=failed,
            failure_reason=failure_reason,
            points=int(len(bt)),
            accepted_leaf_steps=int(accepted_leaves),
            E_initial=float(Evals[0]),
            E_final=float(Evals[-1]),
            E_min=float(np.min(Evals)),
            E_max=float(np.max(Evals)),
            max_abs_E=float(np.max(np.abs(Evals))),
            endpoint_displacement=float(
                Evals[-1]-Evals[0]
            ),
            tail_mean=tail_mean,
            tail_span=tail_span,
            tail_relative_span=tail_rel_span,
            bounded=bounded,
            numerically_converged=converged_numerically,
            escaped=escaped,
            min_abs_SE=float(min_abs_SE),
            max_residual=float(max_residual),
            max_projection_over_spacing=float(max_proj_ratio),
            max_subdivision_depth_used=int(max_depth_used),
        ))

        print(
            f"  FINAL: E={Evals[-1]:.12f}, "
            f"bounded={bounded}, "
            f"tail rel span={tail_rel_span:.3e}, "
            f"min|SE|={float(min_abs_SE):.3e}, "
            f"max proj/sp={float(max_proj_ratio):.3e}"
        )

    tr = pd.DataFrame(trajectory_rows)
    branches = pd.DataFrame(branch_rows)

    # ---------------------------------------------------------------
    # global order certification at common checkpoints
    # ---------------------------------------------------------------
    order_violations = 0
    min_separation = np.inf

    if len(tr):
        common_counts = tr.groupby("tau")["branch"].nunique()
        full_taus = common_counts[
            common_counts == len(seeds)
        ].index.to_numpy(dtype=float)

        for tau in full_taus:
            g = tr[tr["tau"] == tau].sort_values("branch")
            ev = g["E"].to_numpy(dtype=float)
            dif = np.diff(ev)

            if len(dif):
                order_violations += int(
                    np.sum(dif <= 0)
                )
                min_separation = min(
                    min_separation,
                    float(np.min(np.abs(dif))),
                )

    order_pass = bool(order_violations == 0)

    all_completed = bool(
        len(branches) == len(seeds)
        and not np.any(
            branches["failed"].to_numpy(dtype=bool)
        )
    )
    all_bounded = bool(
        len(branches) == len(seeds)
        and np.all(
            branches["bounded"].to_numpy(dtype=bool)
        )
    )
    all_converged = bool(
        len(branches) == len(seeds)
        and np.all(
            branches["numerically_converged"].to_numpy(dtype=bool)
        )
    )
    any_escape = bool(
        len(branches)
        and np.any(
            branches["escaped"].to_numpy(dtype=bool)
        )
    )

    trans_pass = bool(
        len(branches)
        and np.all(
            branches["min_abs_SE"].to_numpy(dtype=float)
            >= args.transversality_gate
        )
    )

    projection_pass = bool(
        len(branches)
        and np.all(
            branches["max_projection_over_spacing"].to_numpy(dtype=float)
            <= args.projection_spacing_fraction + 1e-12
        )
    )

    if (
        all_completed
        and all_converged
        and order_pass
        and trans_pass
        and projection_pass
    ):
        verdict = "GLOBAL_HIGH_PRECISION_BOUNDED_CONVERGENCE_CERTIFIED"
    elif (
        all_completed
        and any_escape
        and order_pass
        and trans_pass
        and projection_pass
    ):
        verdict = "GLOBAL_HIGH_PRECISION_NO_HOPPING_ESCAPE_CERTIFIED"
    elif (
        all_completed
        and all_bounded
        and order_pass
        and trans_pass
        and projection_pass
    ):
        verdict = "GLOBAL_HIGH_PRECISION_BOUNDED_BUT_ASYMPTOTICS_UNRESOLVED"
    else:
        verdict = "GLOBAL_HIGH_PRECISION_CONTINUATION_UNRESOLVED"

    tr.to_csv(
        args.prefix+"_TRAJECTORIES.csv",
        index=False,
    )
    branches.to_csv(
        args.prefix+"_BRANCHES.csv",
        index=False,
    )

    summary = dict(
        version=177,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        scope=(
            "Global arbitrary-precision, Newton-only, no-root-search "
            "continuation of the two-layer synthetic adversarial phase."
        ),
        branches=branch_rows,
        all_completed=all_completed,
        all_bounded=all_bounded,
        all_numerically_converged=all_converged,
        any_escape=any_escape,
        transversality_pass=trans_pass,
        projection_gate_pass=projection_pass,
        tracked_order_violations=order_violations,
        tracked_order_pass=order_pass,
        minimum_tracked_separation=(
            None if not np.isfinite(min_separation)
            else min_separation
        ),
        verdict=verdict,
    )

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("Branch summary")
    print("-"*168)
    if len(branches):
        cols = [
            "branch", "E_initial", "E_final",
            "E_min", "E_max",
            "tail_relative_span",
            "min_abs_SE",
            "max_projection_over_spacing",
            "max_subdivision_depth_used",
            "status",
        ]
        print(branches[cols].to_string(index=False))

    print()
    print("="*168)
    print(f"all completed                      : {all_completed}")
    print(f"all bounded                        : {all_bounded}")
    print(f"all numerically converged          : {all_converged}")
    print(f"any escape                         : {any_escape}")
    print(f"transversality pass                : {trans_pass}")
    print(f"projection gate pass               : {projection_pass}")
    print(f"tracked order violations           : {order_violations}")
    print(f"tracked order pass                 : {order_pass}")
    print(f"minimum tracked separation         : {min_separation:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*168)

    if verdict == "GLOBAL_HIGH_PRECISION_BOUNDED_CONVERGENCE_CERTIFIED":
        print("CONSEQUENCE:")
        print("  The adversarial two-layer model does NOT defeat finite-branch")
        print("  convergence when the same root manifold is followed at sufficient")
        print("  precision without root-search reconnection.")
    elif verdict == "GLOBAL_HIGH_PRECISION_NO_HOPPING_ESCAPE_CERTIFIED":
        print("CONSEQUENCE:")
        print("  A genuine continuous synthetic branch escapes even under strict")
        print("  no-hopping certification. The generic adversarial obstruction is real.")
    elif verdict == "GLOBAL_HIGH_PRECISION_BOUNDED_BUT_ASYMPTOTICS_UNRESOLVED":
        print("CONSEQUENCE:")
        print("  The branches remain bounded through tau_max but the tail has not")
        print("  settled enough for a convergence claim. Extend tau, not precision.")
    else:
        print("ACTION:")
        print("  Inspect the first failed branch and maximum subdivision depth before")
        print("  drawing an asymptotic conclusion.")


if __name__ == "__main__":
    main()
