#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v104 FAST POST-FREEZE COMPLETION
=======================================

Loads an already-frozen v104 diagonal archive, verifies its SHA, and performs
only the post-freeze Xi moment/Taylor comparison plus a compact recap.

No operator, support, tail, or pre-Xi data are rebuilt.
"""

from __future__ import annotations
import argparse, csv, hashlib, json
from pathlib import Path
import numpy as np

EPS=1e-15

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def rel_l2(a,b):
    a=np.asarray(a,complex); b=np.asarray(b,complex)
    return float(np.linalg.norm(a-b)/max(np.linalg.norm(b),EPS))

def xi_complex(mp,z):
    zz=mp.mpc(z.real,z.imag)
    s=mp.mpf("0.5")+1j*zz
    return (mp.mpf("0.5")*s*(s-1)*mp.power(mp.pi,-s/2)
            *mp.gamma(s/2)*mp.zeta(s))

def xi_moments(mp,order):
    x0=xi_complex(mp,0j)
    vals=[]
    for m in range(1,order+1):
        print(f"[Xi moment] {m}/{order}",flush=True)
        d=mp.diff(
            lambda t: mp.log(xi_complex(mp,complex(float(t),0.0))/x0),
            mp.mpf("0"),2*m
        )
        vals.append(float(mp.re(-m*d/mp.factorial(2*m))))
    return np.asarray(vals,float)

def write_csv(path,rows):
    if not rows:
        Path(path).write_text("",encoding="utf-8"); return
    fields=list(rows[0].keys())
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--v104-prefix",default="rot_rh_diagonal_normal_family_v104")
    ap.add_argument("--post-moment-order",type=int,default=4)
    ap.add_argument("--xi-dps",type=int,default=60)
    ap.add_argument("--prefix",default="rot_rh_diagonal_normal_family_v104_postfreeze_fast")
    args=ap.parse_args()

    vp=Path(args.v104_prefix).expanduser().resolve()
    archive=Path(str(vp)+"_FROZEN_PRE_XI.npz")
    manifest=Path(str(vp)+"_FROZEN_MANIFEST.json")
    man=json.loads(manifest.read_text(encoding="utf-8"))
    got=sha256_file(archive)
    if got!=man.get("sha256"):
        raise RuntimeError(f"SHA mismatch: expected {man.get('sha256')}, got {got}")

    data=np.load(archive,allow_pickle=False)
    Ls=np.asarray(data["L_seq"],int)
    ds=np.asarray(data["depth_seq"],int)
    Ms=np.asarray(data["order_seq"],int)
    nstages=len(Ls)

    print("="*120)
    print("ROT-RH v104 FAST POST-FREEZE COMPLETION")
    print("="*120)
    print("SHA verified       :",True)
    print("SHA                :",got)
    print("diagonal L         :",Ls.tolist())
    print("diagonal N         :",ds.tolist())
    print("diagonal M         :",Ms.tolist())
    print("Xi moment order    :",args.post_moment_order)

    import mpmath as mp
    mp.mp.dps=args.xi_dps
    xim=xi_moments(mp,args.post_moment_order)

    rows=[]
    for j in range(nstages):
        mom=np.asarray(data[f"mom_stage{j}"],float)[:args.post_moment_order]
        row={
            "stage":j,
            "L":int(Ls[j]),
            "N":int(ds[j]),
            "M":int(Ms[j]),
            "moment_relative_l2":rel_l2(mom,xim),
            "S1_relative_error":abs(float(mom[0]-xim[0]))/abs(float(xim[0])),
        }
        rows.append(row)
        print(
            f"stage {j}: L={row['L']} N={row['N']} M={row['M']} "
            f"moment relL2={row['moment_relative_l2']:.12e} "
            f"S1 rel={row['S1_relative_error']:.12e}"
        )

    final=rows[-1]
    verdict=(
        "PASS_V104_POSTFREEZE_MOMENT_CLOSURE"
        if final["moment_relative_l2"]<1e-5
        else "PARTIAL_V104_POSTFREEZE_MOMENT_CLOSURE"
    )
    outp=Path(args.prefix).expanduser().resolve()
    write_csv(Path(str(outp)+"_POST_XI_MOMENTS.csv"),rows)
    Path(str(outp)+"_VERDICT.json").write_text(
        json.dumps({
            "verdict":verdict,
            "RH_proof":False,
            "source_freeze_sha256":got,
            "final":final,
            "Xi_moments":xim.tolist(),
        },indent=2),
        encoding="utf-8"
    )

    print("="*120)
    print("verdict            :",verdict)
    print("final moment relL2 :",f"{final['moment_relative_l2']:.12e}")
    print("final S1 rel error :",f"{final['S1_relative_error']:.12e}")
    print("RH proof           : FALSE")
    print("="*120)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
