#!/usr/bin/env python3
"""
ROT-RH v153 — GAUSS-ORDER CONVERGENCE / ABEL IDENTITY CERTIFICATION

Purpose
-------
v152 reduced the Abel-identity mismatch to a nearly constant relative
1.415e-3 across all cutoff pairs.  That pattern strongly suggests a
systematic low-order quadrature effect.

v153 certifies (or rejects) that interpretation by recomputing BOTH
independent representations at Gauss-Legendre orders

    q = 2, 4, 8, 16, 32   (configurable),

on every prime-power interval.

For L<M:

    g(x) = x^-1/2 (exp(-x/M)-exp(-x/L))

Direct weighted discrepancy:
    D_direct
      = sum_{p^a<=X} (1/a) g(p^a)
        - int_2^X g(x)/log(x) dx.

Abel representation:
    B(x) = J(x) - [Ei(log x)-Ei(log 2)]

    D_abel
      = g(X)B(X) - int_2^X B(x) g'(x) dx.

The two continuum integrals are evaluated independently at each GL order.

The script reports:
  * absolute and relative identity residual vs GL order;
  * convergence ratios under order doubling;
  * direct/Abel convergence to the highest-order result;
  * residual contributions localized into logarithmic x shells;
  * whether the v152 ~1.415e-3 mismatch disappears at higher order.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_ORDERS.csv
<prefix>_SHELLS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.special import expi
except Exception as exc:
    raise RuntimeError("scipy.special.expi is required") from exc

from numpy.polynomial.legendre import leggauss


def parse_pairs(s):
    out = []
    for item in s.split(","):
        item = item.strip()
        if not item:
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def parse_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def li2(x):
    x = np.asarray(x, dtype=np.float64)
    return expi(np.log(x)) - expi(math.log(2.0))


def gfun(x, L, M):
    x = np.asarray(x, dtype=np.float64)
    return x**(-0.5) * (np.exp(-x/M) - np.exp(-x/L))


def gprime(x, L, M):
    x = np.asarray(x, dtype=np.float64)
    a = np.exp(-x/M)
    b = np.exp(-x/L)
    return (
        -0.5 * x**(-1.5) * (a - b)
        + x**(-0.5) * (-a/M + b/L)
    )


def gl_integrals_for_pair(
    left,
    right,
    J_level,
    L,
    M,
    order,
    chunk_intervals,
    shell_edges,
):
    """
    Independent GL evaluation of:
      I_cont = int g/log x dx
      I_abel = int B g' dx

    Also accumulate shellwise integration-by-parts residual contribution
      shell_res = -I_cont_shell + I_abel_shell
    combined later with the discrete/boundary pieces globally.

    For diagnostic localization, the smooth shell residual measures the
    quadrature mismatch in the integral identity
      int B g' + int g/log x
    relative to its endpoint/J-jump counterpart.
    """
    nodes, weights = leggauss(order)

    total_cont = 0.0
    total_abel = 0.0

    shell_cont = np.zeros(len(shell_edges)-1, dtype=np.float64)
    shell_abel = np.zeros(len(shell_edges)-1, dtype=np.float64)

    nint = len(left)

    for start in range(0, nint, chunk_intervals):
        stop = min(nint, start + chunk_intervals)

        a = left[start:stop]
        b = right[start:stop]
        Jc = J_level[start:stop]

        mid = 0.5 * (a + b)
        half = 0.5 * (b - a)

        # Process Gauss nodes one node-index at a time to keep memory bounded.
        chunk_cont = np.zeros(stop-start, dtype=np.float64)
        chunk_abel = np.zeros(stop-start, dtype=np.float64)

        for t, wt in zip(nodes, weights):
            xx = mid + half * t

            gg = gfun(xx, L, M)
            cont = gg / np.log(xx)

            BB = Jc - li2(xx)
            aa = BB * gprime(xx, L, M)

            factor = half * wt
            chunk_cont += factor * cont
            chunk_abel += factor * aa

        total_cont += float(np.sum(chunk_cont))
        total_abel += float(np.sum(chunk_abel))

        # Assign each interval to shell by midpoint. Since intervals are tiny
        # compared with logarithmic shells, this is only a localization
        # diagnostic, not part of the certification.
        shell_idx = np.searchsorted(shell_edges, mid, side="right") - 1
        valid = (shell_idx >= 0) & (shell_idx < len(shell_cont))

        if np.any(valid):
            np.add.at(shell_cont, shell_idx[valid], chunk_cont[valid])
            np.add.at(shell_abel, shell_idx[valid], chunk_abel[valid])

    return total_cont, total_abel, shell_cont, shell_abel


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--orders",
        default="2,4,8,16,32",
    )
    ap.add_argument(
        "--chunk-intervals",
        type=int,
        default=32768,
    )
    ap.add_argument(
        "--shell-count",
        type=int,
        default=12,
    )

    ap.add_argument(
        "--relative-identity-gate",
        type=float,
        default=1e-6,
    )
    ap.add_argument(
        "--absolute-identity-gate",
        type=float,
        default=1e-12,
    )
    ap.add_argument(
        "--high-order-stability-gate",
        type=float,
        default=1e-4,
        help="Relative change between the last two GL orders.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_abel_gauss_convergence_v153",
    )

    args = ap.parse_args()

    pairs = parse_pairs(args.pairs)
    orders = parse_ints(args.orders)

    if len(orders) < 2:
        raise RuntimeError("Provide at least two Gauss orders.")
    if any(q < 2 for q in orders):
        raise RuntimeError("Gauss orders must be >=2.")

    orders = sorted(set(orders))
    xmax = int(math.ceil(args.tail_factor * max(M for _, M in pairs)))

    print("=" * 144)
    print("ROT-RH v153 — GAUSS-ORDER CONVERGENCE / ABEL IDENTITY CERTIFICATION")
    print("=" * 144)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"xmax                              : {xmax:,}")
    print(f"Gauss orders                      : {orders}")
    print(f"chunk intervals                   : {args.chunk_intervals}")
    print(f"logarithmic residual shells       : {args.shell_count}")
    print("=" * 144)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_w = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)

    J_after = np.cumsum(atom_w)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    # Prime-power intervals [atom_i, atom_{i+1}), plus final interval to xmax.
    left = atom_x.copy()
    right = np.empty_like(left)
    right[:-1] = atom_x[1:]
    right[-1] = float(xmax)

    widths = right - left
    use = widths > 0.0

    left = left[use]
    right = right[use]
    J_level = J_after[use]

    shell_edges = np.geomspace(2.0, float(xmax), args.shell_count + 1)
    shell_edges[0] = 2.0
    shell_edges[-1] = float(xmax) * (1.0 + 1e-15)

    order_rows = []
    shell_rows = []

    pair_order_results = {}

    for L, M in pairs:
        print()
        print(f"[pair {L}->{M}] exact discrete/boundary pieces ...", flush=True)

        discrete = float(np.dot(atom_w, gfun(atom_x, L, M)))

        gX = float(gfun(float(xmax), L, M))
        BX = float(J_after[-1] - li2(float(xmax)))
        boundary = gX * BX

        results = []

        for q in orders:
            print(f"  [q={q:>2d}] integrating ...", flush=True)

            continuum, abel_int, sh_cont, sh_abel = gl_integrals_for_pair(
                left=left,
                right=right,
                J_level=J_level,
                L=L,
                M=M,
                order=q,
                chunk_intervals=args.chunk_intervals,
                shell_edges=shell_edges,
            )

            D_direct = discrete - continuum
            D_abel = boundary - abel_int

            residual = D_direct - D_abel
            relres = abs(residual) / max(abs(D_direct), 1e-300)

            row = dict(
                L=L,
                M=M,
                order=q,
                discrete=discrete,
                continuum=continuum,
                boundary=boundary,
                abel_integral=abel_int,
                D_direct=D_direct,
                D_abel=D_abel,
                identity_residual=residual,
                abs_identity_residual=abs(residual),
                relative_identity_residual=relres,
            )

            results.append(row)
            order_rows.append(row.copy())

            # Local smooth quadrature discrepancy by x shell.
            for s in range(len(shell_edges)-1):
                shell_rows.append(dict(
                    L=L,
                    M=M,
                    order=q,
                    shell=s+1,
                    x_lo=float(shell_edges[s]),
                    x_hi=float(shell_edges[s+1]),
                    continuum_shell=float(sh_cont[s]),
                    abel_integral_shell=float(sh_abel[s]),
                    smooth_sum_shell=float(sh_cont[s] + sh_abel[s]),
                ))

            print(
                f"          Ddirect={D_direct:+.12e}  "
                f"Dabel={D_abel:+.12e}  "
                f"abs-id={abs(residual):.3e}  "
                f"rel-id={relres:.3e}"
            )

        # Add order-doubling diagnostics.
        for i, r in enumerate(results):
            if i == 0:
                r["residual_ratio_vs_prev_order"] = np.nan
                r["Ddirect_rel_change_vs_prev"] = np.nan
                r["Dabel_rel_change_vs_prev"] = np.nan
            else:
                prev = results[i-1]

                r["residual_ratio_vs_prev_order"] = (
                    r["abs_identity_residual"] /
                    prev["abs_identity_residual"]
                    if prev["abs_identity_residual"] > 0 else np.nan
                )

                r["Ddirect_rel_change_vs_prev"] = (
                    abs(r["D_direct"] - prev["D_direct"]) /
                    max(abs(r["D_direct"]), 1e-300)
                )
                r["Dabel_rel_change_vs_prev"] = (
                    abs(r["D_abel"] - prev["D_abel"]) /
                    max(abs(r["D_abel"]), 1e-300)
                )

        pair_order_results[(L, M)] = results

    # Rebuild order rows from annotated results.
    order_rows = []
    for key in pair_order_results:
        order_rows.extend(pair_order_results[key])

    pd.DataFrame(order_rows).to_csv(
        args.prefix + "_ORDERS.csv", index=False
    )
    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )

    # ------------------------------------------------------------------
    # certification
    # ------------------------------------------------------------------
    final_rows = [pair_order_results[p][-1] for p in pairs]
    penult_rows = [pair_order_results[p][-2] for p in pairs]

    identity_ok = all(
        r["abs_identity_residual"] <= args.absolute_identity_gate
        and r["relative_identity_residual"] <= args.relative_identity_gate
        for r in final_rows
    )

    stability_ok = all(
        abs(rf["D_direct"] - rp["D_direct"]) /
        max(abs(rf["D_direct"]), 1e-300)
        <= args.high_order_stability_gate
        and
        abs(rf["D_abel"] - rp["D_abel"]) /
        max(abs(rf["D_abel"]), 1e-300)
        <= args.high_order_stability_gate
        for rf, rp in zip(final_rows, penult_rows)
    )

    # Check whether the original q=2 ~1.415e-3 residual collapses.
    q2_rel = [
        pair_order_results[p][0]["relative_identity_residual"]
        for p in pairs
    ]
    qmax_rel = [r["relative_identity_residual"] for r in final_rows]

    collapse_factor = (
        max(q2_rel) / max(qmax_rel)
        if max(qmax_rel) > 0 else np.inf
    )

    if identity_ok and stability_ok:
        verdict = "ABEL_IDENTITY_NUMERICALLY_CERTIFIED_AT_HIGH_ORDER"
    elif stability_ok and max(qmax_rel) < max(q2_rel) / 10.0:
        verdict = "ABEL_IDENTITY_CONVERGING_BUT_CERTIFICATION_GATE_NOT_REACHED"
    else:
        verdict = "ABEL_IDENTITY_HIGH_ORDER_UNRESOLVED"

    summary = dict(
        version=153,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        orders=orders,
        gates=dict(
            relative_identity=args.relative_identity_gate,
            absolute_identity=args.absolute_identity_gate,
            high_order_stability=args.high_order_stability_gate,
        ),
        highest_order_pair_results=final_rows,
        identity_pass=identity_ok,
        high_order_stability_pass=stability_ok,
        q2_max_relative_residual=max(q2_rel),
        qmax_max_relative_residual=max(qmax_rel),
        residual_collapse_factor=collapse_factor,
        verdict=verdict,
        interpretation=(
            "If the q=2 residual collapses rapidly under Gauss-order doubling, "
            "the v152 mismatch was quadrature error. If a nonzero residual plateaus, "
            "re-examine endpoint/jump conventions in the Abel identity."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("Gauss-order convergence summary")
    print("-" * 144)
    print(
        f"{'pair':>18} {'q':>4} {'|Ddirect|':>15} {'|Dabel|':>15} "
        f"{'abs id':>12} {'rel id':>12} {'res ratio':>11} "
        f"{'Ddir drel':>11} {'Dabel drel':>11}"
    )

    for p in pairs:
        for r in pair_order_results[p]:
            print(
                f"{r['L']:>7d}->{r['M']:<7d} "
                f"{r['order']:4d} "
                f"{abs(r['D_direct']):15.8e} "
                f"{abs(r['D_abel']):15.8e} "
                f"{r['abs_identity_residual']:12.3e} "
                f"{r['relative_identity_residual']:12.3e} "
                f"{r['residual_ratio_vs_prev_order']:11.3e} "
                f"{r['Ddirect_rel_change_vs_prev']:11.3e} "
                f"{r['Dabel_rel_change_vs_prev']:11.3e}"
            )

    print()
    print("=" * 144)
    print(f"highest-order identity pass        : {identity_ok}")
    print(f"highest-order stability pass       : {stability_ok}")
    print(f"q=2 max relative residual          : {max(q2_rel):.9e}")
    print(f"q={orders[-1]} max relative residual         : {max(qmax_rel):.9e}")
    print(f"residual collapse factor           : {collapse_factor:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 144)
    print("NEXT DECISION:")
    print("  PASS -> Abel identity is numerically certified; stop debugging quadrature")
    print("          and attack the signed weighted-PNT integral analytically.")
    print("  PLATEAU -> endpoint/jump convention is wrong; derive the Stieltjes")
    print("             boundary terms exactly before proceeding.")


if __name__ == "__main__":
    main()
