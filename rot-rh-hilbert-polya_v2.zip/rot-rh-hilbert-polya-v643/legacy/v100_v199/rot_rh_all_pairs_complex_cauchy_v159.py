#!/usr/bin/env python3
"""
ROT-RH v159 — ALL-PAIRS COMPLEX PRIMITIVE CAUCHY-NET AUDIT

Purpose
-------
v158 showed contraction of the FULL complex centered cutoff primitive on
adjacent cutoff pairs.  v159 upgrades that to the full interlaced cutoff net.

For every pair L<M in the supplied cutoff net, and every frozen old root
E_k(L), compute

    Z_{L,M}(E)
      = [Delta M_c(E) - Delta P_c(E)] / pi,

where

    Delta P_c(E)
      = sum_{n=p^a}
          (1/a) n^(-1/2)
          [exp(-n/M)-exp(-n/L)]
          exp(i E log n),

and

    Delta M_c(E)
      = int_2^X
          [exp(-x/M)-exp(-x/L)]
          x^(-1/2+iE)/log x dx.

The secular cutoff defect is Im Z.

For each tail set L0, form genuine all-pairs Cauchy envelopes

    C_complex(L0)
      = max_{L0<=L<M} sum_{k<=N} |Z_{L,M}(E_k(L))|,

    C_imag(L0)
      = max_{L0<=L<M} sum_{k<=N} |Im Z_{L,M}(E_k(L))|.

Also compute per-mode complex diameters over the tail set.

This is stronger than adjacent-pair contraction and mirrors the spectral
all-pairs Cauchy-net audit v146.

NO Xi / zeta / known-zero data are used.
No phase builds and no root solves are performed.

Outputs
-------
<prefix>_MODES.csv
<prefix>_PAIRS.csv
<prefix>_TAIL_ENVELOPES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def continuum_complex(E, L, M, xmin, xmax, nodes, weights):
    """
    Integrate in u=log x:
       ∫ [e^-x/M-e^-x/L] x^-1/2 e^{iElogx}/logx dx
     = ∫ [..] e^{u/2} e^{iEu}/u du.
    """
    ulo = math.log(xmin)
    uhi = math.log(xmax)

    mid = 0.5 * (ulo + uhi)
    half = 0.5 * (uhi - ulo)

    u = mid + half * nodes
    x = np.exp(u)

    reg = np.exp(-x/M) - np.exp(-x/L)
    amp = reg * np.exp(0.5*u) / u

    return half * np.dot(weights, amp * np.exp(1j * E * u))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument(
        "--cutoffs",
        default="128000,181019,256000,362039,512000",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--continuum-gl-order",
        type=int,
        default=1024,
        help="Gauss-Legendre order for the smooth complex continuum integral.",
    )
    ap.add_argument(
        "--prime-chunk",
        type=int,
        default=65536,
    )

    ap.add_argument(
        "--tail-contraction-gate",
        type=float,
        default=0.98,
    )
    ap.add_argument(
        "--mode-diameter-contraction-gate",
        type=float,
        default=0.98,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_all_pairs_complex_cauchy_v159",
    )

    args = ap.parse_args()

    cutoffs = sorted(set(csv_ints(args.cutoffs)))
    if len(cutoffs) < 3:
        raise RuntimeError("Need at least 3 cutoffs.")

    z = np.load(args.cutoff_net_npz)
    Lnet = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    root_map = {}
    for L in cutoffs:
        hit = np.where(Lnet == L)[0]
        if not len(hit):
            raise RuntimeError(f"L={L} missing from cutoff net.")
        root_map[L] = roots[int(hit[0]), :args.modes].astype(float)

    n = min(args.modes, min(len(root_map[L]) for L in cutoffs))
    for L in cutoffs:
        root_map[L] = root_map[L][:n]

    pairs = list(itertools.combinations(cutoffs, 2))

    max_M = max(cutoffs)
    xmax = int(math.ceil(args.tail_factor * max_M))

    print("=" * 146)
    print("ROT-RH v159 — ALL-PAIRS COMPLEX PRIMITIVE CAUCHY-NET AUDIT")
    print("=" * 146)
    print("Xi / zeta / known zeros          : NONE")
    print(f"cutoff net                        : {cutoffs}")
    print(f"number of cutoff pairs            : {len(pairs)}")
    print(f"modes                             : 1..{n}")
    print(f"prime-power xmax                  : {xmax:,}")
    print(f"continuum GL order                : {args.continuum_gl_order}")
    print("=" * 146)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    atom_u = np.log(atom_x)
    atom_base = atom_afac / np.sqrt(atom_x)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    gl_nodes, gl_weights = leggauss(args.continuum_gl_order)

    mode_rows = []
    pair_rows = []

    pair_mode_Z = {}

    for L, M in pairs:
        print(f"[pair {L}->{M}] computing complex primitive ...", flush=True)

        E = root_map[L]

        reg = np.exp(-atom_x/M) - np.exp(-atom_x/L)
        aw = atom_base * reg

        dP = np.zeros(n, dtype=np.complex128)

        for i in range(0, len(atom_u), args.prime_chunk):
            u = atom_u[i:i+args.prime_chunk]
            w = aw[i:i+args.prime_chunk]
            dP += np.exp(1j * np.outer(E, u)) @ w

        dM = np.array([
            continuum_complex(
                float(Ek),
                L, M,
                2.0, float(xmax),
                gl_nodes, gl_weights
            )
            for Ek in E
        ], dtype=np.complex128)

        Z = (dM - dP) / math.pi
        pair_mode_Z[(L, M)] = Z

        complex_l1 = float(np.sum(np.abs(Z)))
        imag_l1 = float(np.sum(np.abs(Z.imag)))
        real_l1 = float(np.sum(np.abs(Z.real)))

        pair_rows.append(dict(
            L=L,
            M=M,
            ratio_M_over_L=float(M/L),
            complex_l1=complex_l1,
            imag_l1=imag_l1,
            real_l1=real_l1,
            projection_reserve=(
                complex_l1 / imag_l1 if imag_l1 > 0 else np.inf
            ),
            max_mode_abs_Z=float(np.max(np.abs(Z))),
            median_mode_abs_Z=float(np.median(np.abs(Z))),
        ))

        for j in range(n):
            mode_rows.append(dict(
                L=L,
                M=M,
                k=j+1,
                E_old=float(E[j]),
                Z_real=float(Z[j].real),
                Z_imag=float(Z[j].imag),
                Z_abs=float(abs(Z[j])),
                phase=float(np.angle(Z[j])),
            ))

        print(
            f"          |Z|_1={complex_l1:.6e}  "
            f"|Im Z|_1={imag_l1:.6e}  "
            f"|Re Z|_1={real_l1:.6e}  "
            f"reserve={complex_l1/max(imag_l1,1e-300):.2f}x"
        )

    # ------------------------------------------------------------------
    # Tail-set all-pairs envelopes.
    # ------------------------------------------------------------------
    tail_rows = []

    for idx, L0 in enumerate(cutoffs[:-1]):
        tail_cutoffs = [L for L in cutoffs if L >= L0]
        tail_pairs = [
            (L, M) for (L, M) in pairs
            if L >= L0 and M >= L0
        ]

        complex_vals = [
            float(np.sum(np.abs(pair_mode_Z[p])))
            for p in tail_pairs
        ]
        imag_vals = [
            float(np.sum(np.abs(pair_mode_Z[p].imag)))
            for p in tail_pairs
        ]

        Cc = max(complex_vals)
        Ci = max(imag_vals)

        # Per-mode pairwise diameter in complex primitive.
        mode_diam = np.zeros(n, dtype=float)
        mode_imag_diam = np.zeros(n, dtype=float)

        for k in range(n):
            mode_diam[k] = max(
                abs(pair_mode_Z[p][k]) for p in tail_pairs
            )
            mode_imag_diam[k] = max(
                abs(pair_mode_Z[p][k].imag) for p in tail_pairs
            )

        sum_mode_diam = float(np.sum(mode_diam))
        sum_mode_imag_diam = float(np.sum(mode_imag_diam))

        row = dict(
            L0=L0,
            points=len(tail_cutoffs),
            pairs=len(tail_pairs),
            worst_complex_l1=Cc,
            worst_imag_l1=Ci,
            sum_mode_complex_diameters=sum_mode_diam,
            sum_mode_imag_diameters=sum_mode_imag_diam,
            max_single_mode_complex_diameter=float(np.max(mode_diam)),
            max_single_mode_imag_diameter=float(np.max(mode_imag_diam)),
        )

        if not tail_rows:
            row["complex_envelope_ratio"] = np.nan
            row["imag_envelope_ratio"] = np.nan
            row["mode_diameter_ratio"] = np.nan
        else:
            prev = tail_rows[-1]
            row["complex_envelope_ratio"] = (
                Cc / prev["worst_complex_l1"]
            )
            row["imag_envelope_ratio"] = (
                Ci / prev["worst_imag_l1"]
            )
            row["mode_diameter_ratio"] = (
                sum_mode_diam /
                prev["sum_mode_complex_diameters"]
            )

        tail_rows.append(row)

    modes_df = pd.DataFrame(mode_rows)
    pairs_df = pd.DataFrame(pair_rows)
    tails_df = pd.DataFrame(tail_rows)

    modes_df.to_csv(args.prefix + "_MODES.csv", index=False)
    pairs_df.to_csv(args.prefix + "_PAIRS.csv", index=False)
    tails_df.to_csv(args.prefix + "_TAIL_ENVELOPES.csv", index=False)

    # latest >=3 point tail
    candidates = [r for r in tail_rows if r["points"] >= 3]
    latest = candidates[-1] if candidates else tail_rows[-1]

    complex_contracts = (
        np.isfinite(latest["complex_envelope_ratio"])
        and latest["complex_envelope_ratio"] < args.tail_contraction_gate
    )
    imag_contracts = (
        np.isfinite(latest["imag_envelope_ratio"])
        and latest["imag_envelope_ratio"] < args.tail_contraction_gate
    )
    diam_contracts = (
        np.isfinite(latest["mode_diameter_ratio"])
        and latest["mode_diameter_ratio"]
        < args.mode_diameter_contraction_gate
    )

    if complex_contracts and imag_contracts and diam_contracts:
        verdict = "ALL_PAIRS_COMPLEX_CAUCHY_NET_STRONGLY_SUPPORTED"
    elif complex_contracts and imag_contracts:
        verdict = "ALL_PAIRS_COMPLEX_ENVELOPE_CONTRACTS_MODE_DIAMETER_MIXED"
    elif imag_contracts and not complex_contracts:
        verdict = "IMAG_CAUCHY_NET_SUPPORTED_COMPLEX_NET_UNRESOLVED"
    else:
        verdict = "ALL_PAIRS_COMPLEX_CAUCHY_NET_UNRESOLVED"

    summary = dict(
        version=159,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoff_net=cutoffs,
        pair_count=len(pairs),
        modes=n,
        tail_envelopes=tail_rows,
        latest_ge3_tail=latest,
        verdict=verdict,
        theorem_target=(
            "For each fixed N, prove "
            "sup_{L,M>=L0} sum_{k<=N}|Z_{L,M}(E_k(L))| -> 0 "
            "as L0->infinity. Since |Im Z|<=|Z|, this implies the "
            "finite-block secular-defect Cauchy property without relying "
            "on phase projection."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("All-pairs complex primitive summaries")
    print("-" * 146)
    print(
        f"{'pair':>18} {'M/L':>9} {'|Z|_1':>13} "
        f"{'|Im|_1':>13} {'|Re|_1':>13} {'reserve':>10}"
    )
    for r in pair_rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{r['ratio_M_over_L']:9.4f} "
            f"{r['complex_l1']:13.6e} "
            f"{r['imag_l1']:13.6e} "
            f"{r['real_l1']:13.6e} "
            f"{r['projection_reserve']:10.3f}"
        )

    print()
    print("Tail-set all-pairs complex Cauchy envelopes")
    print("-" * 146)
    for r in tail_rows:
        print(
            f"L0={r['L0']:>7d} "
            f"points={r['points']} pairs={r['pairs']:2d}  "
            f"Ccomplex={r['worst_complex_l1']:.6e} "
            f"(r={r['complex_envelope_ratio']:.6f})  "
            f"Cimag={r['worst_imag_l1']:.6e} "
            f"(r={r['imag_envelope_ratio']:.6f})  "
            f"sum mode diam={r['sum_mode_complex_diameters']:.6e} "
            f"(r={r['mode_diameter_ratio']:.6f})"
        )

    print()
    print("=" * 146)
    print(f"latest >=3-point tail L0          : {latest['L0']}")
    print(f"latest complex envelope ratio      : {latest['complex_envelope_ratio']:.9f}")
    print(f"latest imaginary envelope ratio    : {latest['imag_envelope_ratio']:.9f}")
    print(f"latest mode-diameter ratio         : {latest['mode_diameter_ratio']:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 146)
    print("THEOREM TARGET:")
    print("  Prove the ALL-PAIRS complex primitive Cauchy statement")
    print()
    print("      sup_{L,M >= L0} sum_{k<=N}|Z_LM(E_k(L))| -> 0.")
    print()
    print("  This is stronger than the required imaginary secular-defect")
    print("  convergence and closes the phase-rotation recurrence loophole.")


if __name__ == "__main__":
    main()
