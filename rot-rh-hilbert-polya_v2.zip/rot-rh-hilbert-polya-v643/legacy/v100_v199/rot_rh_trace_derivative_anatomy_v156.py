#!/usr/bin/env python3
"""
ROT-RH v156 — TRACE-DERIVATIVE ANATOMY / SIGNED-PRIMITIVE AUDIT

ZERO-COST postprocessor.

Purpose
-------
v155 found a stable direct finite-block trace derivative

    T_N(a) = sum_{k<=N} |d lambda_k/da|

but between L=256k and 512k it behaved as if rho>1, so absolute derivative
integrability is not currently supported.

At the same time, the actual finite-block endpoint distance
D_N(256k,512k) is small and contracting.

v156 resolves that tension mode by mode.

For each mode k it compares:
  * d lambda_k/da at L=256k and 512k,
  * sign changes,
  * local growth exponent
        rho_k = log(|dλ/da|_512 / |dλ/da|_256) / log 2,
  * contribution to T_N growth,
  * actual endpoint difference λ_k(256k)-λ_k(512k),
  * trapezoidal primitive estimate
        ∫_{a512}^{a256} dλ_k/da da.

If the derivative endpoint samples badly overpredict the actual primitive,
or many modes change sign / exhibit large primitive mismatch, the correct
mechanism is oscillatory finite variation rather than absolute derivative
integrability.

Outputs
-------
<prefix>_MODES.csv
<prefix>_BANDS.csv
<prefix>_TOP_GROWTH.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v155-modes-csv",
        default="rot_rh_direct_inverse_cutoff_derivative_v155_MODES.csv",
    )
    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument("--L1", type=int, default=256000)
    ap.add_argument("--L2", type=int, default=512000)
    ap.add_argument("--eta", type=float, default=0.04)
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument(
        "--bands",
        default="1,2,4,8,16,32",
        help="Cumulative band endpoints: 1,2,4,8,16,32 -> 1;2;3-4;5-8;...",
    )
    ap.add_argument("--top", type=int, default=12)
    ap.add_argument(
        "--primitive-relative-gate",
        type=float,
        default=0.25,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_trace_derivative_anatomy_v156",
    )

    args = ap.parse_args()

    if not args.L1 < args.L2:
        raise RuntimeError("Require L1 < L2.")

    df = pd.read_csv(args.v155_modes_csv)

    # Use the requested eta, allowing tiny float roundoff.
    sub = df[
        (df["base_L"].isin([args.L1, args.L2]))
        & (np.isclose(df["eta"], args.eta, rtol=0, atol=1e-12))
        & (df["k"] <= args.modes)
    ].copy()

    d1 = sub[sub["base_L"] == args.L1].sort_values("k")
    d2 = sub[sub["base_L"] == args.L2].sort_values("k")

    if len(d1) != len(d2) or len(d1) == 0:
        raise RuntimeError(
            f"Could not find matching mode rows for L={args.L1},{args.L2}, eta={args.eta}."
        )

    n = min(args.modes, len(d1), len(d2))
    d1 = d1.iloc[:n].copy()
    d2 = d2.iloc[:n].copy()

    if not np.array_equal(d1["k"].to_numpy(), d2["k"].to_numpy()):
        raise RuntimeError("Mode indexing mismatch.")

    # Load exact endpoint roots/lambdas.
    z = np.load(args.cutoff_net_npz)
    Ls = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    def get_roots(L):
        hit = np.where(Ls == L)[0]
        if not len(hit):
            raise RuntimeError(f"L={L} missing from cutoff-net NPZ.")
        return roots[int(hit[0]), :n].astype(float)

    E1 = get_roots(args.L1)
    E2 = get_roots(args.L2)
    lam1 = E1**(-2)
    lam2 = E2**(-2)

    a1 = 1.0 / args.L1
    a2 = 1.0 / args.L2
    da = a1 - a2

    dl1 = d1["d_lambda_da"].to_numpy(dtype=float)
    dl2 = d2["d_lambda_da"].to_numpy(dtype=float)

    adl1 = np.abs(dl1)
    adl2 = np.abs(dl2)

    T1 = float(np.sum(adl1))
    T2 = float(np.sum(adl2))
    T_ratio = T2 / T1

    actual = lam1 - lam2
    actual_abs = np.abs(actual)

    # Integral from a2 to a1. Endpoint derivative values correspond to
    # a1 (L1) and a2 (L2).
    trap = 0.5 * (dl1 + dl2) * da
    trap_abs = np.abs(trap)

    # Absolute-variation trapezoid surrogate.
    absvar_trap = 0.5 * (adl1 + adl2) * da

    # Safe relative primitive mismatch.
    scale = np.maximum(actual_abs, 1e-300)
    primitive_rel = np.abs(trap - actual) / scale
    trap_over_actual = trap_abs / scale
    absvar_over_actual = absvar_trap / scale

    # local derivative exponent, since a halves exactly here:
    with np.errstate(divide="ignore", invalid="ignore"):
        rho = np.log(adl2 / adl1) / math.log(args.L2 / args.L1)

    sign_flip = np.sign(dl1) != np.sign(dl2)

    growth = adl2 - adl1
    positive_growth = np.maximum(growth, 0.0)
    total_positive_growth = float(np.sum(positive_growth))

    rows = []

    for j in range(n):
        rows.append(dict(
            k=int(d1.iloc[j]["k"]),
            E_L1=float(E1[j]),
            E_L2=float(E2[j]),
            lambda_L1=float(lam1[j]),
            lambda_L2=float(lam2[j]),
            d_lambda_da_L1=float(dl1[j]),
            d_lambda_da_L2=float(dl2[j]),
            abs_dlambda_L1=float(adl1[j]),
            abs_dlambda_L2=float(adl2[j]),
            rho_local=float(rho[j]) if np.isfinite(rho[j]) else np.nan,
            sign_flip=int(sign_flip[j]),
            contribution_share_T_L1=float(adl1[j]/T1) if T1 else np.nan,
            contribution_share_T_L2=float(adl2[j]/T2) if T2 else np.nan,
            abs_derivative_growth=float(growth[j]),
            positive_growth_share=(
                float(positive_growth[j]/total_positive_growth)
                if total_positive_growth > 0 else 0.0
            ),
            actual_lambda_change=float(actual[j]),
            abs_actual_lambda_change=float(actual_abs[j]),
            trapezoid_signed_primitive=float(trap[j]),
            abs_trapezoid_primitive=float(trap_abs[j]),
            primitive_relative_error=float(primitive_rel[j]),
            trapezoid_abs_over_actual=float(trap_over_actual[j]),
            absolute_variation_trapezoid=float(absvar_trap[j]),
            absvar_over_actual=float(absvar_over_actual[j]),
        ))

    out = pd.DataFrame(rows)

    # ------------------------------------------------------------------
    # Band anatomy
    # ------------------------------------------------------------------
    endpoints = sorted(set(csv_ints(args.bands)))
    endpoints = [x for x in endpoints if 1 <= x <= n]
    if not endpoints or endpoints[-1] != n:
        endpoints.append(n)

    band_rows = []
    lo = 1

    for hi in endpoints:
        if hi < lo:
            continue

        mask = (out["k"] >= lo) & (out["k"] <= hi)
        g = out[mask]

        bT1 = float(g["abs_dlambda_L1"].sum())
        bT2 = float(g["abs_dlambda_L2"].sum())
        bactual = float(g["abs_actual_lambda_change"].sum())
        btrap = float(g["abs_trapezoid_primitive"].sum())
        babsvar = float(g["absolute_variation_trapezoid"].sum())

        band_rows.append(dict(
            band=f"{lo}-{hi}",
            k_lo=lo,
            k_hi=hi,
            modes=len(g),
            T_L1=bT1,
            T_L2=bT2,
            T_ratio=(bT2/bT1 if bT1 > 0 else np.nan),
            share_T_L2=(bT2/T2 if T2 > 0 else np.nan),
            positive_growth=float(np.maximum(
                g["abs_dlambda_L2"].to_numpy()
                - g["abs_dlambda_L1"].to_numpy(), 0.0
            ).sum()),
            actual_trace_distance=bactual,
            trapezoid_abs_primitive_sum=btrap,
            absvar_trapezoid_sum=babsvar,
            trap_over_actual=(btrap/bactual if bactual > 0 else np.nan),
            absvar_over_actual=(babsvar/bactual if bactual > 0 else np.nan),
            sign_flip_fraction=float(g["sign_flip"].mean()),
            median_rho=float(g["rho_local"].median()),
            max_rho=float(g["rho_local"].max()),
        ))

        lo = hi + 1

    bands = pd.DataFrame(band_rows)

    # ------------------------------------------------------------------
    # top growth culprits
    # ------------------------------------------------------------------
    top = out.sort_values(
        ["positive_growth_share", "abs_derivative_growth"],
        ascending=False
    ).head(args.top).copy()

    # ------------------------------------------------------------------
    # aggregate primitive diagnostics
    # ------------------------------------------------------------------
    actual_trace = float(np.sum(actual_abs))
    signed_net_actual = float(np.sum(actual))
    signed_net_trap = float(np.sum(trap))
    sum_abs_trap = float(np.sum(trap_abs))
    absvar_total = float(np.sum(absvar_trap))

    good_primitive = primitive_rel <= args.primitive_relative_gate

    # A strong micromotion signature:
    # absolute derivative grows, but actual endpoint movement is substantially
    # below the simple absolute-variation trapezoid surrogate and/or many
    # modal primitives mismatch the endpoint.
    micromotion_score = (
        absvar_total / actual_trace
        if actual_trace > 0 else np.inf
    )

    if (
        T_ratio > 1.0
        and micromotion_score > 1.25
    ):
        verdict = "ABSOLUTE_DERIVATIVE_ROUTE_TOO_STRONG_MICROMOTION_CONFIRMED"
    elif T_ratio > 1.0:
        verdict = "ABSOLUTE_DERIVATIVE_GROWS_MICROMOTION_PARTIAL"
    else:
        verdict = "TRACE_DERIVATIVE_ANATOMY_CONTRACTING"

    out.to_csv(args.prefix + "_MODES.csv", index=False)
    bands.to_csv(args.prefix + "_BANDS.csv", index=False)
    top.to_csv(args.prefix + "_TOP_GROWTH.csv", index=False)

    summary = dict(
        version=156,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        endpoints=dict(
            L1=args.L1,
            L2=args.L2,
            eta=args.eta,
            a1=a1,
            a2=a2,
        ),
        aggregate=dict(
            T_L1=T1,
            T_L2=T2,
            T_ratio=T_ratio,
            actual_trace_distance=actual_trace,
            signed_net_lambda_change=signed_net_actual,
            signed_trapezoid_net_change=signed_net_trap,
            sum_abs_trapezoid_primitive=sum_abs_trap,
            absolute_variation_trapezoid=absvar_total,
            absolute_variation_over_actual_trace=micromotion_score,
            sign_flip_fraction=float(np.mean(sign_flip)),
            fraction_modes_primitive_within_gate=float(np.mean(good_primitive)),
            median_primitive_relative_error=float(np.median(primitive_rel)),
            max_primitive_relative_error=float(np.max(primitive_rel)),
        ),
        top_positive_growth_modes=[
            {
                "k": int(r["k"]),
                "positive_growth_share": float(r["positive_growth_share"]),
                "rho_local": (
                    float(r["rho_local"])
                    if np.isfinite(r["rho_local"]) else None
                ),
                "sign_flip": bool(r["sign_flip"]),
            }
            for _, r in top.iterrows()
        ],
        verdict=verdict,
        interpretation=(
            "Finite-block convergence does not require absolute integrability "
            "of sum|d lambda/da|. If T_N grows while the actual endpoint trace "
            "distance contracts, the cutoff flow has internal micromotion/"
            "turnover and the proof should target direct Cauchy differences "
            "or a signed primitive representation rather than total variation."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    print("=" * 136)
    print("ROT-RH v156 — TRACE-DERIVATIVE ANATOMY / SIGNED-PRIMITIVE AUDIT")
    print("=" * 136)
    print("Xi / zeta / known zeros          : NONE")
    print(f"endpoints                          : {args.L1}->{args.L2}")
    print(f"eta derivative source              : {args.eta}")
    print(f"modes                              : 1..{n}")
    print("=" * 136)

    print()
    print("Band anatomy")
    print("-" * 136)
    print(
        f"{'band':>9} {'T1':>13} {'T2':>13} {'T2/T1':>10} "
        f"{'share T2':>10} {'actual d':>13} {'absvar':>13} "
        f"{'var/actual':>11} {'flip%':>8} {'med rho':>10}"
    )
    for _, r in bands.iterrows():
        print(
            f"{r['band']:>9} "
            f"{r['T_L1']:13.6e} "
            f"{r['T_L2']:13.6e} "
            f"{r['T_ratio']:10.6f} "
            f"{r['share_T_L2']:10.4f} "
            f"{r['actual_trace_distance']:13.6e} "
            f"{r['absvar_trapezoid_sum']:13.6e} "
            f"{r['absvar_over_actual']:11.4f} "
            f"{100*r['sign_flip_fraction']:8.1f} "
            f"{r['median_rho']:10.4f}"
        )

    print()
    print("Top contributors to absolute-derivative growth")
    print("-" * 136)
    print(
        f"{'k':>4} {'|dl/da| L1':>14} {'|dl/da| L2':>14} "
        f"{'rho':>10} {'growth share':>13} {'flip':>7} "
        f"{'actual |dl|':>13} {'absvar/actual':>14}"
    )
    for _, r in top.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['abs_dlambda_L1']:14.6e} "
            f"{r['abs_dlambda_L2']:14.6e} "
            f"{r['rho_local']:10.4f} "
            f"{r['positive_growth_share']:13.4f} "
            f"{int(r['sign_flip']):7d} "
            f"{r['abs_actual_lambda_change']:13.6e} "
            f"{r['absvar_over_actual']:14.4f}"
        )

    print()
    print("=" * 136)
    print(f"T_N(L1)                            : {T1:.9e}")
    print(f"T_N(L2)                            : {T2:.9e}")
    print(f"T_N ratio                          : {T_ratio:.9f}")
    print(f"actual finite-block trace distance : {actual_trace:.9e}")
    print(f"abs-variation trapezoid surrogate  : {absvar_total:.9e}")
    print(f"abs variation / actual             : {micromotion_score:.9f}")
    print(f"sign-flip fraction                 : {np.mean(sign_flip):.3f}")
    print(f"primitive-within-gate fraction     : {np.mean(good_primitive):.3f}")
    print(f"median primitive relative error    : {np.median(primitive_rel):.6f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 136)
    print("NEXT THEOREM DECISION:")
    print("  If micromotion is confirmed, abandon absolute derivative integrability")
    print("  as the proof route. Return to the exact cutoff-difference primitive")
    print("  F_M-F_L / weighted-PNT representation, which can converge even when")
    print("  total variation in a is not integrable.")


if __name__ == "__main__":
    main()
