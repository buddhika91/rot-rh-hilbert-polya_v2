#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v104 — Diagonal Normal-Family / Moment Closure Audit
===========================================================

Tests the theorem-shaped sequence

    D_j(z) = D_{L_j,N_j,M_j}(z)

with L_j, N_j, M_j all increasing.

Each D_j is:
  * a finite product over real self-adjoint spectral levels;
  * multiplied by exp(polynomial tail), which has no zeros.

Therefore every D_j has only real zeros.

The RH route would be:

  (i)   prove {D_j} locally bounded on C (normal family);
  (ii)  prove all Taylor/log-trace coefficients converge to Xi's coefficients;
  (iii) every subsequential holomorphic limit then has the same Taylor series
        as Xi/Xi(0), hence equals it by the identity theorem;
  (iv)  therefore D_j -> Xi/Xi(0) locally uniformly;
  (v)   Hurwitz/Rouche excludes nonreal Xi zeros.

This script is a numerical audit of (i)-(iii), not a proof.

PRE-XI:
  * reconstruct diagonal complex determinants from the frozen v102.1 archive;
  * test local boundedness surrogates on nested compact rectangles;
  * test diagonal determinant convergence;
  * test diagonal completed-moment convergence;
  * freeze everything.

POST-XI:
  * compare the diagonal sequence to complex Xi;
  * compare low-order Taylor/log-trace moments to Xi.

No Xi/zero information selects the diagonal sequence or compact boxes.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

EPS = 1e-15
VERSION = "v104"
BUILD = "2026-08-17-diagonal-normal-family-moment-closure-v104"


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(x.real), "imag": float(x.imag)}
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    return x


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def partial_moments(roots, order):
    r = np.asarray(roots, float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def determinant_from_frozen(roots, completed_moments, zvals, order):
    roots = np.asarray(roots, float)
    cm = np.asarray(completed_moments, float)[:order]
    pm = partial_moments(roots, order)
    tail = cm - pm
    inv2 = 1.0 / (roots * roots)
    out = np.empty(len(zvals), complex)

    for i, z in enumerate(zvals):
        z = complex(z)
        raw = np.prod(1.0 - z * z * inv2)
        logtail = 0.0j
        for m, T in enumerate(tail, start=1):
            logtail -= float(T) * z ** (2 * m) / m
        out[i] = raw * np.exp(logtail)
    return out


def sym_rms(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    q = np.abs(a - b) / (1 + np.abs(a) + np.abs(b))
    return float(np.sqrt(np.mean(q * q)))


def sym_sup(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    q = np.abs(a - b) / (1 + np.abs(a) + np.abs(b))
    return float(np.max(q))


def rel_l2(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), EPS))


def xi_complex(mp, z):
    zz = mp.mpc(z.real, z.imag)
    s = mp.mpf("0.5") + 1j * zz
    return (
        mp.mpf("0.5")
        * s
        * (s - 1)
        * mp.power(mp.pi, -s / 2)
        * mp.gamma(s / 2)
        * mp.zeta(s)
    )


def xi_moments(mp, order):
    x0 = xi_complex(mp, 0j)
    vals = []
    for m in range(1, order + 1):
        print(f"[Xi moment] {m}/{order}", flush=True)
        d = mp.diff(
            lambda t: mp.log(xi_complex(mp, complex(float(t), 0.0)) / x0),
            mp.mpf("0"),
            2 * m,
        )
        vals.append(float(-m * d / mp.factorial(2 * m)))
    return np.asarray(vals, float)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument("--L-seq", default="4000,8000,16000")
    ap.add_argument("--depth-seq", default="24,32,48")
    ap.add_argument("--order-seq", default="6,8,10")
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--real-boxes", default="20,35,50")
    ap.add_argument("--real-step", type=float, default=0.5)
    ap.add_argument("--imag-max", type=float, default=0.49)
    ap.add_argument("--imag-levels", type=int, default=5)
    ap.add_argument("--post-moment-order", type=int, default=4)
    ap.add_argument("--xi-dps", type=int, default=60)
    ap.add_argument(
        "--prefix",
        default="rot_rh_diagonal_normal_family_v104",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_seq)
    ds = parse_ints(args.depth_seq)
    Ms = parse_ints(args.order_seq)
    boxes = parse_floats(args.real_boxes)

    if not (len(Ls) == len(ds) == len(Ms) and len(Ls) >= 2):
        raise ValueError("L-seq, depth-seq, order-seq must have equal length >=2")
    if not all(Ls[i] < Ls[i+1] for i in range(len(Ls)-1)):
        raise ValueError("L-seq must increase.")
    if not all(ds[i] < ds[i+1] for i in range(len(ds)-1)):
        raise ValueError("depth-seq must increase.")
    if not all(Ms[i] < Ms[i+1] for i in range(len(Ms)-1)):
        raise ValueError("order-seq must increase.")

    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")
    if not archive.exists() or not manifest_path.exists():
        raise FileNotFoundError("v102.1 frozen files not found.")

    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    if got != man.get("sha256"):
        raise RuntimeError("v102.1 frozen SHA mismatch.")

    data = np.load(archive, allow_pickle=False)

    # Common complex grid on largest preregistered box.
    xmax = max(boxes)
    xs = np.arange(0.0, xmax + 0.5 * args.real_step, args.real_step)
    ys = np.linspace(-args.imag_max, args.imag_max, int(args.imag_levels))
    zvals = np.asarray([complex(x, y) for y in ys for x in xs], complex)
    xlab = np.asarray([x for y in ys for x in xs], float)
    ylab = np.asarray([y for y in ys for x in xs], float)

    print("=" * 150)
    print("ROT-RH v104 — DIAGONAL NORMAL-FAMILY / MOMENT CLOSURE AUDIT")
    print("=" * 150)
    print("v102.1 SHA verified             :", True)
    print("diagonal L                      :", Ls)
    print("diagonal depth N                :", ds)
    print("diagonal tail order M           :", Ms)
    print("compact Re boxes                :", boxes)
    print("Im z range                      :", f"[-{args.imag_max},+{args.imag_max}]")
    print("Xi/zeta/zeros pre-freeze        : NONE")
    print("=" * 150)

    stages = []
    for j, (L, d, M) in enumerate(zip(Ls, ds, Ms)):
        rk = f"roots_L{L}_d{d}"
        mk = f"mom_{args.method}_L{L}_d{d}"
        if rk not in data or mk not in data:
            raise KeyError(f"Missing {rk} or {mk}")
        roots = np.asarray(data[rk], float)
        cm = np.asarray(data[mk], float)
        if M > len(cm):
            raise ValueError(f"Requested M={M}, frozen moments only {len(cm)}")
        if np.max(np.abs(zvals)) >= roots[-1]:
            raise ValueError(
                f"Box exceeds E_N at stage {j}: max|z|={np.max(np.abs(zvals))}, "
                f"E_N={roots[-1]}"
            )
        D = determinant_from_frozen(roots, cm, zvals, M)
        stages.append(
            {
                "j": j,
                "L": L,
                "depth": d,
                "order": M,
                "roots": roots,
                "moments": cm[:M],
                "D": D,
            }
        )
        print(
            f"[stage {j}] L={L:<6d} N={d:<3d} M={M:<2d} "
            f"E_N={roots[-1]:.6f} max|D|={np.max(np.abs(D)):.6e}"
        )

    # PRE-XI local boundedness and diagonal convergence on nested compacts.
    print("[1] PRE-XI nested-compact boundedness / diagonal convergence", flush=True)
    pre_rows = []
    for R in boxes:
        mask = xlab <= R + 1e-12
        maxmods = [float(np.max(np.abs(s["D"][mask]))) for s in stages]
        for j in range(len(stages)-1):
            a = stages[j]["D"][mask]
            b = stages[j+1]["D"][mask]
            pre_rows.append(
                {
                    "R": R,
                    "stage_from": j,
                    "stage_to": j+1,
                    "L_from": stages[j]["L"],
                    "L_to": stages[j+1]["L"],
                    "N_from": stages[j]["depth"],
                    "N_to": stages[j+1]["depth"],
                    "M_from": stages[j]["order"],
                    "M_to": stages[j+1]["order"],
                    "sym_rms": sym_rms(b, a),
                    "sym_sup": sym_sup(b, a),
                    "relative_l2": rel_l2(b, a),
                    "maxmod_from": maxmods[j],
                    "maxmod_to": maxmods[j+1],
                }
            )
        last = pre_rows[-1]
        print(
            f"  R={R:<5g} latest diagonal: RMS={last['sym_rms']:.3e} "
            f"SUP={last['sym_sup']:.3e} "
            f"max|D|={last['maxmod_to']:.3e}"
        )

    print("[2] PRE-XI completed-moment diagonal convergence", flush=True)
    moment_rows = []
    common_order = min(Ms)
    for j in range(len(stages)-1):
        a = stages[j]["moments"][:common_order]
        b = stages[j+1]["moments"][:common_order]
        row = {
            "stage_from": j,
            "stage_to": j+1,
            "common_order": common_order,
            "relative_l2": rel_l2(b, a),
            "S1_abs_difference": abs(float(b[0] - a[0])),
        }
        moment_rows.append(row)
        print(
            f"  {j}->{j+1}: relL2={row['relative_l2']:.3e} "
            f"|dS1|={row['S1_abs_difference']:.3e}"
        )

    # Freeze all diagonal objects.
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    freeze = Path(str(prefix) + "_FROZEN_PRE_XI.npz")
    fmanifest = Path(str(prefix) + "_FROZEN_MANIFEST.json")

    payload = {
        "zreal": np.real(zvals),
        "zimag": np.imag(zvals),
        "xlabels": xlab,
        "ylabels": ylab,
        "L_seq": np.asarray(Ls, int),
        "depth_seq": np.asarray(ds, int),
        "order_seq": np.asarray(Ms, int),
    }
    for s in stages:
        j = s["j"]
        payload[f"Dreal_stage{j}"] = np.real(s["D"])
        payload[f"Dimag_stage{j}"] = np.imag(s["D"])
        payload[f"mom_stage{j}"] = s["moments"]
        payload[f"roots_stage{j}"] = s["roots"]

    np.savez_compressed(freeze, **payload)
    fsha = sha256_file(freeze)

    latest_by_R = {}
    for R in boxes:
        latest_by_R[R] = [r for r in pre_rows if r["R"] == R][-1]

    pre_gates = {
        "latest_diagonal_R50_RMS_below_1e6":
            latest_by_R[max(boxes)]["sym_rms"] < 1e-6,
        "latest_diagonal_R50_SUP_below_1e5":
            latest_by_R[max(boxes)]["sym_sup"] < 1e-5,
        "latest_moment_diagonal_below_1e5":
            moment_rows[-1]["relative_l2"] < 1e-5,
        "boundedness_surrogate_finite":
            all(np.isfinite(r["maxmod_to"]) for r in pre_rows),
    }

    fman = {
        "version": VERSION,
        "build": BUILD,
        "parent_v102_sha256": got,
        "sha256": fsha,
        "diagonal": [
            {"L": L, "N": d, "M": M}
            for L, d, M in zip(Ls, ds, Ms)
        ],
        "boxes": boxes,
        "imag_max": args.imag_max,
        "firewall": {
            "Xi_used_pre_freeze": False,
            "zeta_used_pre_freeze": False,
            "known_zeros_used_pre_freeze": False,
        },
        "pre_gates": pre_gates,
    }
    fmanifest.write_text(json.dumps(json_safe(fman), indent=2), encoding="utf-8")

    print("[freeze] SHA256                  :", fsha)
    print("[freeze] Xi firewall CLOSED.")

    # POST-XI
    import mpmath as mp
    mp.mp.dps = int(args.xi_dps)

    print("[3] POST-XI complex diagonal identity", flush=True)
    xi0 = xi_complex(mp, 0j)
    xiv = np.empty(len(zvals), complex)
    for i, z in enumerate(zvals):
        q = xi_complex(mp, z) / xi0
        xiv[i] = complex(float(mp.re(q)), float(mp.im(q)))

    post_rows = []
    for R in boxes:
        mask = xlab <= R + 1e-12
        for s in stages:
            row = {
                "R": R,
                "stage": s["j"],
                "L": s["L"],
                "N": s["depth"],
                "M": s["order"],
                "sym_rms": sym_rms(s["D"][mask], xiv[mask]),
                "sym_sup": sym_sup(s["D"][mask], xiv[mask]),
                "relative_l2": rel_l2(s["D"][mask], xiv[mask]),
            }
            post_rows.append(row)
        last = [r for r in post_rows if r["R"] == R][-1]
        print(
            f"  R={R:<5g} final stage: RMS={last['sym_rms']:.3e} "
            f"SUP={last['sym_sup']:.3e}"
        )

    print("[4] POST-XI low-order moment/Taylor audit", flush=True)
    pm_order = min(int(args.post_moment_order), min(Ms))
    xim = xi_moments(mp, pm_order)
    post_moment_rows = []
    for s in stages:
        mom = s["moments"][:pm_order]
        row = {
            "stage": s["j"],
            "L": s["L"],
            "N": s["depth"],
            "M": s["order"],
            "relative_l2": rel_l2(mom, xim),
            "S1_relative_error":
                abs(float(mom[0] - xim[0])) / abs(float(xim[0])),
        }
        post_moment_rows.append(row)
        print(
            f"  stage={s['j']}: relL2={row['relative_l2']:.3e} "
            f"S1rel={row['S1_relative_error']:.3e}"
        )

    final_R = [r for r in post_rows if r["R"] == max(boxes)][-1]
    final_m = post_moment_rows[-1]
    post_gates = {
        "final_complex_R50_RMS_below_1e6": final_R["sym_rms"] < 1e-6,
        "final_complex_R50_SUP_below_1e5": final_R["sym_sup"] < 1e-5,
        "final_moment_error_below_1e5": final_m["relative_l2"] < 1e-5,
    }

    if all(pre_gates.values()) and all(post_gates.values()):
        verdict = (
            "PASS_V104_DIAGONAL_NORMAL_FAMILY_NUMERICS_SUPPORT_HURWITZ_ROUTE__"
            "NEXT_PROVE_UNIFORM_LOCAL_BOUNDS_AND_ALL_MOMENT_LIMITS"
        )
    elif all(pre_gates.values()):
        verdict = (
            "PARTIAL_V104_DIAGONAL_SEQUENCE_STABLE_PRE_XI_BUT_XI_LIMIT_NOT_CLOSE"
        )
    else:
        verdict = (
            "NO_GO_V104_DIAGONAL_LOCAL_UNIFORM_CONVERGENCE_NOT_SUPPORTED"
        )

    pre_csv = Path(str(prefix) + "_PRE_XI_COMPACTS.csv")
    moment_csv = Path(str(prefix) + "_PRE_XI_MOMENTS.csv")
    post_csv = Path(str(prefix) + "_POST_XI_COMPACTS.csv")
    post_m_csv = Path(str(prefix) + "_POST_XI_MOMENTS.csv")
    verdict_path = Path(str(prefix) + "_VERDICT.json")
    write_csv(pre_csv, pre_rows)
    write_csv(moment_csv, moment_rows)
    write_csv(post_csv, post_rows)
    write_csv(post_m_csv, post_moment_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "parent_v102_sha256": got,
        "freeze_sha256": fsha,
        "pre_gates": pre_gates,
        "post_gates": post_gates,
        "theorem_target": {
            "A": "prove local boundedness of diagonal entire family on every compact",
            "B": "prove convergence of every completed inverse trace moment to Xi coefficient",
            "C": "deduce local-uniform convergence by normal-family uniqueness/Vitali",
            "D": "apply Hurwitz/Rouche to exclude nonreal Xi zeros",
        },
    }
    verdict_path.write_text(json.dumps(json_safe(packet), indent=2), encoding="utf-8")

    print("\n" + "=" * 150)
    print("FINAL v104 DIAGONAL-CLOSURE VERDICT")
    print("=" * 150)
    print("verdict                         :", verdict)
    print("latest PRE-Xi Rmax RMS         :", f"{latest_by_R[max(boxes)]['sym_rms']:.12e}")
    print("latest PRE-Xi Rmax SUP         :", f"{latest_by_R[max(boxes)]['sym_sup']:.12e}")
    print("latest PRE-Xi moment rel L2    :", f"{moment_rows[-1]['relative_l2']:.12e}")
    print("final POST-Xi Rmax RMS         :", f"{final_R['sym_rms']:.12e}")
    print("final POST-Xi Rmax SUP         :", f"{final_R['sym_sup']:.12e}")
    print("final POST-Xi moment rel L2    :", f"{final_m['relative_l2']:.12e}")
    print("pre-gates                      :", pre_gates)
    print("post-gates                     :", post_gates)
    print("RH proof                       : FALSE")
    print("normal-family theorem          : OPEN")
    print("all-moment theorem             : OPEN")
    print("freeze SHA256                  :", fsha)
    print("verdict file                   :", verdict_path)
    print("=" * 150)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
