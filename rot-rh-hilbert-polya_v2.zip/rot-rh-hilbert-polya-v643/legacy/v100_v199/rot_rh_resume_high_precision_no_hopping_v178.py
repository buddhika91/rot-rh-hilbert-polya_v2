#!/usr/bin/env python3
"""
ROT-RH v178 — RESUME HIGH-PRECISION NO-HOPPING CONTINUATION

Purpose
-------
Resume directly from the last certified point in a prior v177 trajectory CSV.
This avoids repeating the expensive tau=100 -> current-tau continuation.

The phase and certification are the same as v177:
  * arbitrary precision mpmath
  * RK4 predictor in u=log(tau)
  * Newton-only projection
  * recursive log-time subdivision
  * no Brent / no root search / no reconnection
  * projection step bounded by fraction*pi/tau

Default use:
  resume branch 1 from rot_rh_global_hp_fast_v177_TRAJECTORIES.csv
  and continue to tau=1e8.

Outputs:
  <prefix>_TRAJECTORIES.csv
  <prefix>_SUMMARY.json
"""

from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class MPZeroPhase:
    def __init__(self, beta, gamma):
        self.a = []
        self.g = []
        for b, gg in zip(beta, gamma):
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b - mp.mpf("0.5")
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def eval(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)
        ws, logs = [], []
        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(mp.loggamma(w) + a*tau + 1j*(E-g)*tau)

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        S = mp.im(mp.fsum(zs))
        dE = []
        dt = []
        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE.append(1j*(psi+tau)*z)
            dt.append(w*z)
        SE = mp.im(mp.fsum(dE))
        St = mp.im(mp.fsum(dt))
        return S, SE, St, shift

    def flow_u(self, E, u):
        tau = mp.exp(u)
        S, SE, St, _ = self.eval(E, tau)
        if abs(SE) == 0 or not mp.isfinite(SE):
            raise ArithmeticError("S_E zero/nonfinite")
        return -tau*St/SE


def newton_project(phase, E0, tau, tol, frac, iters):
    E = mp.mpf(E0)
    tau = mp.mpf(tau)
    spacing = mp.pi/tau
    max_ratio = mp.mpf("0")
    total = mp.mpf("0")

    for _ in range(iters):
        S, SE, St, _ = phase.eval(E, tau)
        if abs(S) <= tol:
            return {
                "ok": True, "E": E, "residual": abs(S), "abs_SE": abs(SE),
                "max_ratio": max_ratio, "total_ratio": abs(total)/spacing
            }
        if abs(SE) == 0 or not mp.isfinite(SE):
            return {"ok": False, "reason": "SE_zero_or_nonfinite"}

        step = -S/SE
        ratio = abs(step)/spacing
        if ratio > frac:
            return {
                "ok": False,
                "reason": "projection_step_exceeds_gate",
                "step_ratio": ratio,
                "residual": abs(S),
                "abs_SE": abs(SE),
            }
        E += step
        total += step
        max_ratio = max(max_ratio, ratio)

    S, SE, *_ = phase.eval(E, tau)
    return {
        "ok": bool(abs(S) <= tol),
        "reason": "newton_no_convergence",
        "E": E,
        "residual": abs(S),
        "abs_SE": abs(SE),
        "max_ratio": max_ratio,
        "total_ratio": abs(total)/spacing,
    }


def rk4_predict(phase, E0, tau0, tau1):
    u0 = mp.log(tau0)
    u1 = mp.log(tau1)
    h = u1-u0
    k1 = phase.flow_u(E0, u0)
    k2 = phase.flow_u(E0+h*k1/2, u0+h/2)
    k3 = phase.flow_u(E0+h*k2/2, u0+h/2)
    k4 = phase.flow_u(E0+h*k3, u1)
    return E0 + h*(k1+2*k2+2*k3+k4)/6


def advance(phase, E0, t0, t1, tol, frac, iters, max_depth, depth=0):
    try:
        pred = rk4_predict(phase, E0, t0, t1)
    except Exception as exc:
        pred = None
        proj = {"ok": False, "reason": f"rk4:{exc}"}
    else:
        proj = newton_project(phase, pred, t1, tol, frac, iters)

    if proj.get("ok"):
        return {
            "ok": True,
            "E": proj["E"],
            "leaves": [{
                "tau_start": float(t0),
                "tau_end": float(t1),
                "E": float(proj["E"]),
                "residual": float(proj["residual"]),
                "abs_SE": float(proj["abs_SE"]),
                "max_projection_over_spacing": float(
                    max(proj["max_ratio"], proj["total_ratio"])
                ),
                "depth": depth,
            }],
            "max_depth": depth,
        }

    if depth >= max_depth:
        return {
            "ok": False,
            "reason": "max_subdivision_depth_reached",
            "underlying": proj,
            "tau_start": float(t0),
            "tau_end": float(t1),
            "E": E0,
            "depth": depth,
        }

    um = (mp.log(t0)+mp.log(t1))/2
    tm = mp.exp(um)

    left = advance(phase, E0, t0, tm, tol, frac, iters, max_depth, depth+1)
    if not left["ok"]:
        return left
    right = advance(phase, left["E"], tm, t1, tol, frac, iters, max_depth, depth+1)
    if not right["ok"]:
        return right

    return {
        "ok": True,
        "E": right["E"],
        "leaves": left["leaves"] + right["leaves"],
        "max_depth": max(left["max_depth"], right["max_depth"]),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--resume-trajectories", required=True)
    ap.add_argument("--branch", type=int, default=1)
    ap.add_argument("--tau-max", type=float, default=1e8)
    ap.add_argument("--checkpoints", type=int, default=120)
    ap.add_argument("--dps", type=int, default=70)
    ap.add_argument("--tol-exp", type=int, default=40)
    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--projection-spacing-fraction", type=float, default=0.20)
    ap.add_argument("--max-subdivision-depth", type=int, default=18)
    ap.add_argument("--bounded-E-gate", type=float, default=200.0)
    ap.add_argument("--prefix", default="rot_rh_resume_hp_v178")
    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.projection_spacing_fraction))

    cand = pd.read_csv(args.candidates_csv)
    old = pd.read_csv(args.resume_trajectories)
    old = old[old["branch"] == args.branch].sort_values("tau")
    if len(old) == 0:
        raise RuntimeError("Requested branch not found in resume trajectory.")

    last = old.iloc[-1]
    t0f = float(last["tau"])
    E0f = float(last["E"])

    phase = MPZeroPhase(
        cand["beta"].to_numpy(float),
        cand["gamma"].to_numpy(float),
    )

    t0 = mp.mpf(str(t0f))
    E0 = mp.mpf(str(E0f))

    # Re-refine resume seed at high precision.
    seed = newton_project(
        phase, E0, t0, tol, frac, args.newton_iters
    )
    if not seed["ok"]:
        raise RuntimeError(
            f"Resume seed failed high-precision refinement: {seed}"
        )

    E = seed["E"]
    tau_prev = t0

    grid = np.geomspace(t0f, args.tau_max, args.checkpoints)

    rows = [{
        "branch": args.branch,
        "tau": t0f,
        "E": float(E),
        "residual": float(seed["residual"]),
        "abs_SE": float(seed["abs_SE"]),
        "max_projection_over_spacing": float(
            max(seed["max_ratio"], seed["total_ratio"])
        ),
        "subdivision_depth": 0,
    }]

    max_depth_used = 0
    max_proj = float(rows[0]["max_projection_over_spacing"])
    min_se = float(seed["abs_SE"])
    failed = False
    fail_reason = ""

    print("="*150)
    print("ROT-RH v178 — RESUME HIGH-PRECISION NO-HOPPING CONTINUATION")
    print("="*150)
    print(f"branch                  : {args.branch}")
    print(f"resume tau              : {t0f:.12e}")
    print(f"resume E                : {float(E):.12f}")
    print(f"tau max                 : {args.tau_max:.6e}")
    print(f"checkpoints              : {args.checkpoints}")
    print(f"dps                      : {args.dps}")
    print(f"projection gate          : {args.projection_spacing_fraction} * pi/tau")
    print(f"max subdivision depth    : {args.max_subdivision_depth}")
    print("="*150)

    for i in range(1, len(grid)):
        target = mp.mpf(str(float(grid[i])))
        adv = advance(
            phase, E, tau_prev, target,
            tol, frac, args.newton_iters,
            args.max_subdivision_depth
        )
        if not adv["ok"]:
            failed = True
            fail_reason = adv["reason"]
            print(
                f"FAIL {i}/{len(grid)-1} tau={float(target):.6e} "
                f"reason={fail_reason} depth={adv.get('depth')}"
            )
            break

        E = adv["E"]
        tau_prev = target
        max_depth_used = max(max_depth_used, adv["max_depth"])

        leaf_last = adv["leaves"][-1]
        for leaf in adv["leaves"]:
            min_se = min(min_se, leaf["abs_SE"])
            max_proj = max(max_proj, leaf["max_projection_over_spacing"])

        S, SE, *_ = phase.eval(E, tau_prev)

        rows.append({
            "branch": args.branch,
            "tau": float(tau_prev),
            "E": float(E),
            "residual": float(abs(S)),
            "abs_SE": float(abs(SE)),
            "max_projection_over_spacing": float(
                leaf_last["max_projection_over_spacing"]
            ),
            "subdivision_depth": int(adv["max_depth"]),
        })

        if i % max(1, len(grid)//16) == 0:
            print(
                f"{i:4d}/{len(grid)-1} tau={float(tau_prev):.6e} "
                f"E={float(E):.12f} depth={adv['max_depth']} "
                f"maxproj={max_proj:.3e}"
            )

    df = pd.DataFrame(rows)
    Es = df["E"].to_numpy(float)

    bounded = bool(np.max(np.abs(Es)) <= args.bounded_E_gate)
    escaped = not bounded

    status = (
        "FAILED" if failed
        else ("ESCAPED" if escaped else "BOUNDED_THROUGH_TAU_MAX")
    )

    out = {
        "version": 178,
        "branch": args.branch,
        "resume_tau": t0f,
        "resume_E": E0f,
        "final_tau": float(df.iloc[-1]["tau"]),
        "final_E": float(df.iloc[-1]["E"]),
        "E_min": float(np.min(Es)),
        "E_max": float(np.max(Es)),
        "bounded": bounded,
        "escaped": escaped,
        "failed": failed,
        "failure_reason": fail_reason,
        "min_abs_SE": min_se,
        "max_projection_over_spacing": max_proj,
        "max_subdivision_depth_used": max_depth_used,
        "status": status,
    }

    df.to_csv(args.prefix+"_TRAJECTORIES.csv", index=False)
    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(out), indent=2),
        encoding="utf-8"
    )

    print()
    print("="*150)
    for k, v in out.items():
        print(f"{k:34s}: {v}")
    print("="*150)


if __name__ == "__main__":
    main()
