#!/usr/bin/env python3
"""
ROT-RH v181 — PHASE-CELL (Y=tau E) LATE-SWITCH CESARO AUDIT

Why this version
----------------
At large tau, neighboring roots in E are separated by ~pi/tau, so direct
E-coordinate continuation becomes extremely stiff.  Define instead

    Y(tau) = tau * E(tau).

Neighboring root cells are then separated by ~pi, independent of tau.

Along S(E,tau)=0,

    dE/dtau = -S_tau/S_E,

hence

    dY/dtau = E - tau*S_tau/S_E.

This is precisely

    dY/dtau = gamma_active + epsilon.

So Y is both the numerically natural no-hopping coordinate and the exact
coordinate for the Cesaro reduction we want to test.

Method
------
For selected late switches:
  * exact two-layer Gamma phase, with conjugates + functional mirrors;
  * initialize near the left active ordinate in Y=tau E;
  * RK4 continuation for Y(tau);
  * high-precision Newton correction in Y;
  * strict gate |Delta Y| < fraction*pi;
  * adaptive bisection only when needed;
  * integrate epsilon = dY/dtau - gamma_active.

No Xi / zeta / known zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class TwoLayerPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b - mp.mpf("0.5")

            # rho, conjugate, functional mirror, mirror conjugate
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def eval_E(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws, logs = [], []

        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        S = mp.im(mp.fsum(zs))

        dE_terms = []
        dt_terms = []

        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE_terms.append(1j*(psi+tau)*z)
            dt_terms.append(w*z)

        SE = mp.im(mp.fsum(dE_terms))
        St = mp.im(mp.fsum(dt_terms))

        return S, SE, St

    def eval_Y(self, Y, tau):
        tau = mp.mpf(tau)
        Y = mp.mpf(Y)
        E = Y/tau
        S, SE, St = self.eval_E(E, tau)

        # dS/dY = S_E / tau
        SY = SE/tau

        # exact dY/dtau along S=0
        Yt = E - tau*St/SE

        return S, SY, Yt, E, SE, St


def newton_Y(phase, Y0, tau, tol, cell_fraction, iterations):
    Y = mp.mpf(Y0)
    tau = mp.mpf(tau)

    total = mp.mpf("0")
    max_ratio = mp.mpf("0")

    for _ in range(iterations):
        S, SY, Yt, E, SE, St = phase.eval_Y(Y, tau)

        if abs(S) <= tol:
            return {
                "ok": True,
                "Y": Y,
                "E": E,
                "residual": abs(S),
                "abs_SE": abs(SE),
                "total_cell_ratio": abs(total)/mp.pi,
                "max_step_cell_ratio": max_ratio,
            }

        if abs(SY) == 0 or not mp.isfinite(SY):
            return {"ok": False, "reason": "S_Y_zero_or_nonfinite"}

        step = -S/SY
        ratio = abs(step)/mp.pi

        if ratio > cell_fraction:
            return {
                "ok": False,
                "reason": "Y_projection_step_exceeds_cell_gate",
                "step_cell_ratio": ratio,
                "residual": abs(S),
                "abs_SE": abs(SE),
            }

        Y += step
        total += step
        max_ratio = max(max_ratio, ratio)

    S, SY, Yt, E, SE, St = phase.eval_Y(Y, tau)

    return {
        "ok": bool(abs(S) <= tol),
        "reason": "newton_no_convergence",
        "Y": Y,
        "E": E,
        "residual": abs(S),
        "abs_SE": abs(SE),
        "total_cell_ratio": abs(total)/mp.pi,
        "max_step_cell_ratio": max_ratio,
    }


def nearest_initial_root_Y(
    phase, tau, center_E, tol, cell_fraction, iterations, search_cells
):
    tau = mp.mpf(tau)
    centerY = tau*mp.mpf(center_E)

    good = []

    # Half-cell seeds in Y; root spacing is O(pi).
    for j in range(-2*search_cells, 2*search_cells+1):
        seedY = centerY + mp.mpf(j)*mp.pi/2
        p = newton_Y(
            phase, seedY, tau, tol, cell_fraction, iterations
        )
        if p["ok"]:
            good.append(p)

    if not good:
        return {"ok": False, "reason": "no_initial_Y_root"}

    good.sort(key=lambda r: abs(r["E"]-mp.mpf(center_E)))
    return good[0]


def flow_Y(phase, Y, tau):
    S, SY, Yt, E, SE, St = phase.eval_Y(Y, tau)

    if not mp.isfinite(Yt):
        raise ArithmeticError("Y flow nonfinite")

    return Yt


def rk4_predict_Y(phase, Y0, t0, t1):
    t0 = mp.mpf(t0)
    t1 = mp.mpf(t1)
    h = t1-t0

    k1 = flow_Y(phase, Y0, t0)
    k2 = flow_Y(phase, Y0+h*k1/2, t0+h/2)
    k3 = flow_Y(phase, Y0+h*k2/2, t0+h/2)
    k4 = flow_Y(phase, Y0+h*k3, t1)

    return Y0 + h*(k1+2*k2+2*k3+k4)/6


def direct_step(
    phase, Y0, t0, t1, tol, cell_fraction, iterations
):
    try:
        pred = rk4_predict_Y(phase, Y0, t0, t1)
    except Exception as exc:
        return {
            "ok": False,
            "reason": f"rk4_failure:{exc}",
        }

    p = newton_Y(
        phase, pred, t1, tol, cell_fraction, iterations
    )

    if not p["ok"]:
        return {
            "ok": False,
            "reason": p.get("reason", "projection_failure"),
            "projection": p,
        }

    return {
        "ok": True,
        "Y": p["Y"],
        "projection": p,
    }


def adaptive_step(
    phase,
    Y0,
    t0,
    t1,
    tol,
    cell_fraction,
    iterations,
    max_depth,
    depth=0,
):
    d = direct_step(
        phase, Y0, t0, t1, tol, cell_fraction, iterations
    )

    if d["ok"]:
        p = d["projection"]
        return {
            "ok": True,
            "Y": d["Y"],
            "leaves": [{
                "tau": float(t1),
                "Y": float(d["Y"]),
                "E": float(p["E"]),
                "residual": float(p["residual"]),
                "abs_SE": float(p["abs_SE"]),
                "projection_cell_ratio": float(
                    max(
                        p["total_cell_ratio"],
                        p["max_step_cell_ratio"],
                    )
                ),
                "depth": depth,
            }],
            "max_depth": depth,
        }

    if depth >= max_depth:
        return {
            "ok": False,
            "reason": "max_subdivision_depth_reached",
            "underlying_reason": d.get("reason", ""),
            "tau_start": float(t0),
            "tau_end": float(t1),
            "depth": depth,
        }

    # Arithmetic midpoint is natural because Y ODE is integrated in tau.
    tm = (mp.mpf(t0)+mp.mpf(t1))/2

    left = adaptive_step(
        phase, Y0, t0, tm,
        tol, cell_fraction, iterations,
        max_depth, depth+1
    )
    if not left["ok"]:
        return left

    right = adaptive_step(
        phase, left["Y"], tm, t1,
        tol, cell_fraction, iterations,
        max_depth, depth+1
    )
    if not right["ok"]:
        return right

    return {
        "ok": True,
        "Y": right["Y"],
        "leaves": left["leaves"] + right["leaves"],
        "max_depth": max(left["max_depth"], right["max_depth"]),
    }


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)

    scale = max(abs(float(gamma)), 1.0)

    score = (
        np.abs(g-float(gamma))/scale
        + 1e-3*np.abs(b-float(beta))
    )

    return cand.iloc[int(np.argmin(score))]


def trapezoid(x, y):
    return float(
        np.trapezoid(
            np.asarray(y, float),
            np.asarray(x, float)
        )
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--switch-indices",
        default="136,159",
        help="Comma-separated 1-based hull switch numbers.",
    )

    ap.add_argument("--dps", type=int, default=55)
    ap.add_argument("--tol-exp", type=int, default=32)
    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument(
        "--cell-fraction",
        type=float,
        default=0.20,
        help="Every Newton correction in Y must be < fraction*pi.",
    )

    ap.add_argument(
        "--switch-log-halfwidth",
        type=float,
        default=0.08,
    )
    ap.add_argument(
        "--base-points",
        type=int,
        default=9,
    )
    ap.add_argument(
        "--initial-search-cells",
        type=int,
        default=6,
    )
    ap.add_argument(
        "--max-subdivision-depth",
        type=int,
        default=16,
    )
    ap.add_argument(
        "--relative-error-gate",
        type=float,
        default=0.05,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_phase_cell_late_switch_v181",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    cell_fraction = mp.mpf(str(args.cell_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    total_switches = len(hull)-1

    requested = []
    for tok in args.switch_indices.split(","):
        tok = tok.strip()
        if not tok:
            continue
        k = int(tok)
        if k < 1 or k > total_switches:
            raise ValueError(
                f"switch {k} outside valid 1..{total_switches}"
            )
        requested.append(k-1)

    indices = sorted(set(requested))

    print("="*170)
    print("ROT-RH v181 — PHASE-CELL (Y=tau E) LATE-SWITCH CESARO AUDIT")
    print("="*170)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"active hull segments              : {len(hull)}")
    print(f"switches                          : {[j+1 for j in indices]}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"base points                       : {args.base_points}")
    print(f"max adaptive depth                : {args.max_subdivision_depth}")
    print(f"switch log halfwidth              : {args.switch_log_halfwidth}")
    print(f"Y-cell Newton gate                : {args.cell_fraction} * pi")
    print("="*170)

    switch_rows = []
    sample_rows = []

    failures = 0
    total_signed = 0.0
    total_abs = 0.0
    total_active = 0.0

    for ordinal, j in enumerate(indices, start=1):
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        ts = float(left["tau_end"])

        c1 = match_candidate(
            cand,
            left["beta_active"],
            left["gamma_active"],
        )
        c2 = match_candidate(
            cand,
            right["beta_active"],
            right["gamma_active"],
        )

        b1 = float(c1["beta"])
        g1 = float(c1["gamma"])
        b2 = float(c2["beta"])
        g2 = float(c2["gamma"])

        phase = TwoLayerPhase(b1, g1, b2, g2)

        w = args.switch_log_halfwidth
        t0f = ts*math.exp(-w)
        t1f = ts*math.exp(+w)

        t0 = mp.mpf(str(t0f))
        t1 = mp.mpf(str(t1f))

        init = nearest_initial_root_Y(
            phase,
            t0,
            mp.mpf(str(g1)),
            tol,
            cell_fraction,
            args.newton_iters,
            args.initial_search_cells,
        )

        if not init["ok"]:
            failures += 1
            switch_rows.append({
                "switch": j+1,
                "status": "INITIAL_ROOT_UNRESOLVED",
                "tau_switch": ts,
                "gamma_left": g1,
                "gamma_right": g2,
            })
            print(
                f"[{ordinal}/{len(indices)} | hull {j+1}] "
                f"INIT FAIL"
            )
            continue

        Y = init["Y"]

        S0, SY0, Yt0, E0, SE0, St0 = phase.eval_Y(
            Y, t0
        )

        local = [{
            "tau": float(t0),
            "Y": float(Y),
            "E": float(E0),
            "Y_t": float(Yt0),
            "residual": float(abs(S0)),
            "abs_SE": float(abs(SE0)),
            "projection_cell_ratio": float(
                max(
                    init["total_cell_ratio"],
                    init["max_step_cell_ratio"],
                )
            ),
            "depth": 0,
        }]

        grid = np.geomspace(
            t0f, t1f, args.base_points
        )

        ok = True
        max_depth_used = 0

        for k in range(1, len(grid)):
            ta = mp.mpf(str(grid[k-1]))
            tb = mp.mpf(str(grid[k]))

            adv = adaptive_step(
                phase,
                Y,
                ta,
                tb,
                tol,
                cell_fraction,
                args.newton_iters,
                args.max_subdivision_depth,
            )

            if not adv["ok"]:
                failures += 1
                ok = False

                switch_rows.append({
                    "switch": j+1,
                    "status": "SWITCH_CONTINUATION_UNRESOLVED",
                    "tau_switch": ts,
                    "gamma_left": g1,
                    "gamma_right": g2,
                    "reason": adv.get("reason", ""),
                    "underlying_reason": adv.get(
                        "underlying_reason", ""
                    ),
                    "failure_tau_start": adv.get(
                        "tau_start", np.nan
                    ),
                    "failure_tau_end": adv.get(
                        "tau_end", np.nan
                    ),
                    "failure_depth": adv.get(
                        "depth", np.nan
                    ),
                })

                print(
                    f"[{ordinal}/{len(indices)} | hull {j+1}] "
                    f"tau={ts:.3e} g:{g1:.3e}->{g2:.3e} "
                    f"FAIL depth={adv.get('depth')}"
                )
                break

            Y = adv["Y"]
            max_depth_used = max(
                max_depth_used,
                adv["max_depth"],
            )

            for leaf in adv["leaves"]:
                tt = mp.mpf(str(leaf["tau"]))
                YY = mp.mpf(str(leaf["Y"]))

                S, SY, Yt, E, SE, St = phase.eval_Y(
                    YY, tt
                )

                local.append({
                    "tau": float(tt),
                    "Y": float(YY),
                    "E": float(E),
                    "Y_t": float(Yt),
                    "residual": float(abs(S)),
                    "abs_SE": float(abs(SE)),
                    "projection_cell_ratio": float(
                        leaf["projection_cell_ratio"]
                    ),
                    "depth": int(leaf["depth"]),
                })

        if not ok:
            continue

        df = (
            pd.DataFrame(local)
            .sort_values("tau")
            .drop_duplicates(
                subset=["tau"], keep="last"
            )
        )

        taus = df["tau"].to_numpy(float)
        Yts = df["Y_t"].to_numpy(float)

        gact = np.where(
            taus <= ts, g1, g2
        )

        eps = Yts-gact

        signed = trapezoid(taus, eps)
        absolute = trapezoid(
            taus, np.abs(eps)
        )
        active = trapezoid(taus, gact)

        rel_signed = signed/max(
            abs(active), 1e-300
        )
        rel_abs = absolute/max(
            abs(active), 1e-300
        )

        max_eps_rel = float(
            np.max(
                np.abs(eps)
                / np.maximum(np.abs(gact), 1.0)
            )
        )

        min_se = float(
            df["abs_SE"].min()
        )
        max_proj = float(
            df["projection_cell_ratio"].max()
        )

        total_signed += signed
        total_abs += absolute
        total_active += active

        switch_rows.append({
            "switch": j+1,
            "status": "PASS",
            "tau_switch": ts,
            "gamma_left": g1,
            "gamma_right": g2,
            "samples": len(df),
            "max_depth_used": max_depth_used,
            "E_start": float(df.iloc[0]["E"]),
            "E_end": float(df.iloc[-1]["E"]),
            "signed_epsilon_integral": signed,
            "absolute_epsilon_integral": absolute,
            "active_gamma_integral": active,
            "signed_error_over_active": rel_signed,
            "absolute_error_over_active": rel_abs,
            "max_abs_epsilon_over_gamma": max_eps_rel,
            "min_abs_SE": min_se,
            "max_projection_cell_ratio": max_proj,
        })

        for q in range(len(df)):
            sample_rows.append({
                "switch": j+1,
                "tau": float(taus[q]),
                "Y": float(df.iloc[q]["Y"]),
                "E": float(df.iloc[q]["E"]),
                "Y_t": float(Yts[q]),
                "gamma_active": float(gact[q]),
                "epsilon": float(eps[q]),
                "abs_epsilon_over_gamma": float(
                    abs(eps[q])
                    / max(abs(gact[q]), 1.0)
                ),
                "abs_SE": float(
                    df.iloc[q]["abs_SE"]
                ),
                "projection_cell_ratio": float(
                    df.iloc[q]["projection_cell_ratio"]
                ),
                "depth": int(
                    df.iloc[q]["depth"]
                ),
            })

        print(
            f"[{ordinal}/{len(indices)} | hull {j+1}] "
            f"tau={ts:.3e} "
            f"g:{g1:.3e}->{g2:.3e} "
            f"|Int eps|/Int g={rel_abs:.3e} "
            f"max|eps|/g={max_eps_rel:.3e} "
            f"depth={max_depth_used} "
            f"cellproj={max_proj:.3e}"
        )

    total_rel_signed = (
        total_signed/max(
            abs(total_active), 1e-300
        )
        if total_active != 0
        else np.inf
    )
    total_rel_abs = (
        total_abs/max(
            abs(total_active), 1e-300
        )
        if total_active != 0
        else np.inf
    )

    if failures:
        verdict = "PHASE_CELL_CONTINUATION_UNRESOLVED"
    elif total_rel_abs <= args.relative_error_gate:
        verdict = "LATE_SWITCH_CESARO_ERROR_NEGLIGIBLE"
    else:
        verdict = "LATE_SWITCH_CESARO_ERROR_NOT_NEGLIGIBLE"

    pd.DataFrame(switch_rows).to_csv(
        args.prefix+"_SWITCHES.csv",
        index=False,
    )
    pd.DataFrame(sample_rows).to_csv(
        args.prefix+"_SAMPLES.csv",
        index=False,
    )

    summary = {
        "version": 181,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "switches_requested": [j+1 for j in indices],
        "switches_completed": sum(
            1
            for r in switch_rows
            if r.get("status") == "PASS"
        ),
        "continuation_failures": failures,
        "total_signed_error_over_active": total_rel_signed,
        "total_absolute_error_over_active": total_rel_abs,
        "relative_error_gate": args.relative_error_gate,
        "verdict": verdict,
    }

    Path(
        args.prefix+"_SUMMARY.json"
    ).write_text(
        json.dumps(
            native(summary),
            indent=2,
            allow_nan=True,
        ),
        encoding="utf-8",
    )

    print()
    print("="*170)
    print(
        f"switches completed                 : "
        f"{summary['switches_completed']}/{len(indices)}"
    )
    print(
        f"continuation failures              : {failures}"
    )
    print(
        f"total signed eps / active          : "
        f"{total_rel_signed:.6e}"
    )
    print(
        f"total absolute eps / active        : "
        f"{total_rel_abs:.6e}"
    )
    print(
        f"gate                               : "
        f"{args.relative_error_gate:.6e}"
    )
    print(
        f"VERDICT                            : {verdict}"
    )
    print("="*170)


if __name__ == "__main__":
    main()
