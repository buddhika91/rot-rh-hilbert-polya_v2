#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v118 — Sharp Continuous-Primitive Bound from Stored Cell Integrals
=========================================================================

Consumes only the high-resolution cell CSVs already produced by v115/v116.

v117 bounded the within-cell primitive crudely by

    max |Q| * cell_width <= 1/2 * cell_width,

which gave C_A ~= 1.758.

But each CSV already stores
    q_k    = int_cell Q(E)dE,
    V_k    = int_cell |Q(E)|dE.

Let
    P_k = int max(Q,0)dE = (V_k+q_k)/2,
    M_k = int max(-Q,0)dE = (V_k-q_k)/2.

For any x inside the cell,

    int_{E_k}^x Q

cannot exceed P_k positively or M_k negatively. Hence the exact deterministic
cellwise bound

    sup_x |int_{E_k}^x Q|
      <= max(P_k,M_k)
      = (V_k+|q_k|)/2.

Therefore if the boundary defect increments satisfy

    max_n |sum_{k=N}^{n} q_k| <= C_B,

then a continuous primitive beginning at E_N obeys

    sup_E |A(E)| <= C_B + max_k (V_k+|q_k|)/2.

This script computes that sharper bound over k=48..767 and propagates it into
the inverse-moment and resolvent staircase tail estimates.

NO root recomputation.
NO phase recomputation.
NO Xi, zeta, or known-zero data.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np

VERSION = "v118"
BUILD = "2026-08-17-sharp-continuous-primitive-bound-v118"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row, key):
    return float(row[key])


def i(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k); seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v115-prefix",
        default="rot_rh_v114_high_resolution_validation_v115",
    )
    ap.add_argument(
        "--v116-prefix",
        default="rot_rh_long_scale_blind_staircase_v116",
    )
    ap.add_argument("--k-start", type=int, default=48)
    ap.add_argument("--k-end", type=int, default=767)
    ap.add_argument("--moment-order", type=int, default=4)
    ap.add_argument("--a-probes", default="2,5,10")
    ap.add_argument("--bound-starts", default="48,128,448,608")
    ap.add_argument(
        "--prefix",
        default="rot_rh_sharp_continuous_primitive_v118",
    )
    args = ap.parse_args()

    p115 = Path(args.v115_prefix).expanduser().resolve()
    p116 = Path(args.v116_prefix).expanduser().resolve()
    f115 = Path(str(p115) + "_CELLS.csv")
    f116 = Path(str(p116) + "_CELLS.csv")
    if not f115.exists(): raise FileNotFoundError(f115)
    if not f116.exists(): raise FileNotFoundError(f116)

    raw = read_csv(f115) + read_csv(f116)
    mp = {}
    for r in raw:
        k = i(r, "cell_k")
        if args.k_start <= k <= args.k_end:
            mp[k] = r

    ks = list(range(args.k_start, args.k_end + 1))
    missing = [k for k in ks if k not in mp]
    if missing:
        raise RuntimeError(f"Missing cells: {missing[:20]}")

    rows = [mp[k] for k in ks]
    q = np.asarray([f(r, "Q_area") for r in rows], float)
    V = np.asarray([f(r, "abs_Q_area") for r in rows], float)
    width = np.asarray([f(r, "width") for r in rows], float)
    maxQ = np.asarray([f(r, "max_abs_Q") for r in rows], float)
    lo = np.asarray([f(r, "lo") for r in rows], float)

    positive_mass = 0.5 * (V + q)
    negative_mass = 0.5 * (V - q)
    local_bound = 0.5 * (V + np.abs(q))
    old_local_bound = maxQ * width

    cum = np.concatenate([[0.0], np.cumsum(q)])
    C_B = float(np.max(np.abs(cum)))
    B_range = float(np.max(cum) - np.min(cum))

    C_local = float(np.max(local_bound))
    C_local_old = float(np.max(old_local_bound))
    C_A = C_B + C_local
    C_A_old = C_B + C_local_old

    print("=" * 150)
    print("ROT-RH v118 — SHARP CONTINUOUS-PRIMITIVE BOUND FROM STORED CELL INTEGRALS")
    print("=" * 150)
    print("assembled cells                 :", f"{args.k_start}..{args.k_end}")
    print("cell count                      :", len(q))
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 150)

    print("[1] Boundary and local primitive bounds")
    print("  boundary C_B=max|sum q|        :", f"{C_B:.12e}")
    print("  boundary range                 :", f"{B_range:.12e}")
    print("  old max |Q|*width              :", f"{C_local_old:.12e}")
    print("  sharp max (int|Q|+|intQ|)/2   :", f"{C_local:.12e}")
    print("  local-bound improvement        :", f"{C_local_old/max(C_local,EPS):.6f}x")
    print("  old continuous C_A             :", f"{C_A_old:.12e}")
    print("  sharp continuous C_A           :", f"{C_A:.12e}")
    print("  C_A improvement                :", f"{C_A_old/max(C_A,EPS):.6f}x")

    idx = int(np.argmax(local_bound))
    print("  worst local cell k             :", ks[idx])
    print("  worst local cell width         :", f"{width[idx]:.12e}")
    print("  worst cell int|Q|              :", f"{V[idx]:.12e}")
    print("  worst cell |int Q|             :", f"{abs(q[idx]):.12e}")
    print("  worst cell avg |Q|             :", f"{V[idx]/width[idx]:.12e}")

    print("[2] Distribution of within-cell variation")
    for pct in [50, 90, 95, 99, 100]:
        print(
            f"  local bound p{pct:<3d}              :",
            f"{np.percentile(local_bound,pct):.12e}"
        )
    print("  mean int|Q|/width               :", f"{np.mean(V/width):.12e}")
    print("  median int|Q|/width             :", f"{np.median(V/width):.12e}")

    starts = [int(x.strip()) for x in args.bound_starts.split(",") if x.strip()]
    aprobes = [float(x.strip()) for x in args.a_probes.split(",") if x.strip()]

    print("[3] Sharpened theorem-shaped tail bounds if C_A is uniform")
    bound_rows = []
    for k in starts:
        if k not in mp:
            continue
        E = f(mp[k], "lo")
        out = {
            "k_start": k,
            "E_k": E,
            "C_B_observed": C_B,
            "C_local_observed_bound": C_local,
            "C_A_observed_bound": C_A,
        }
        for m in range(1, args.moment_order+1):
            out[f"S{m}_staircase_bound"] = C_A*(2*m)*E**(-2*m-1)
        for a in aprobes:
            out[f"R_a{a:g}_staircase_bound"] = (
                C_A * 2.0*E/(E*E+a*a)**2
            )
        bound_rows.append(out)
        print(
            f"  k={k:<3d} E={E:9.3f}: "
            f"S1<={out['S1_staircase_bound']:.3e} "
            f"R(a=2)<={out.get('R_a2_staircase_bound',float('nan')):.3e}"
        )

    cell_rows = []
    running = 0.0
    for j, k in enumerate(ks):
        cell_rows.append({
            "cell_k": k,
            "lo": lo[j],
            "width": width[j],
            "Q_area": q[j],
            "abs_Q_area": V[j],
            "positive_Q_mass": positive_mass[j],
            "negative_Q_mass": negative_mass[j],
            "sharp_local_primitive_bound": local_bound[j],
            "old_local_bound_maxQ_width": old_local_bound[j],
            "boundary_primitive_before": running,
            "boundary_primitive_after": running + q[j],
        })
        running += q[j]

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_TAIL_BOUNDS.csv"), bound_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V118_SHARP_PRIMITIVE_BOUND_ASSEMBLED",
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "boundary_C_B": C_B,
        "boundary_range": B_range,
        "old_local_bound": C_local_old,
        "sharp_local_bound": C_local,
        "old_continuous_C_A": C_A_old,
        "sharp_continuous_C_A": C_A,
        "continuous_bound_improvement_factor": C_A_old/max(C_A,EPS),
        "theorem_statement": (
            "If the observed boundary partial-sum bound C_B and the cellwise "
            "total-variation bound sup_k (int|Q|+|intQ|)/2 extend uniformly "
            "along the diagonal sequence, then the continuous primitive of "
            "Q=F-N is uniformly bounded by C_A. The exact staircase tail "
            "correction is then bounded by C_A times |g'(E_N)| for inverse "
            "moments and sufficiently high-energy resolvents."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 150)
    print("FINAL v118 VERDICT")
    print("=" * 150)
    print("verdict                         : PASS_V118_SHARP_PRIMITIVE_BOUND_ASSEMBLED")
    print("boundary C_B                    :", f"{C_B:.12e}")
    print("sharp local bound               :", f"{C_local:.12e}")
    print("sharp continuous C_A            :", f"{C_A:.12e}")
    print("C_A improvement factor          :", f"{C_A_old/max(C_A,EPS):.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 150)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
