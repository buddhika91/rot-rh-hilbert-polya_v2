#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v123 — Preregistered Blind Prime Self-Cancellation Replication
=====================================================================

BACKGROUND
----------
v121 preregistered NO-GO falsified persistent prime–Gamma phase locking.
v122 then found, post-hoc on the already-fresh v121 cells k=768..1087:

  * Gamma defect RMS / prime defect RMS = 7.57e-3;
  * corr(q_total,q_prime) = 0.999983;
  * the ACTUAL ordering of q_prime had cumulative permutation p=5e-5
    and low-frequency permutation p below Monte-Carlo resolution;
  * block-sum suppression switched on around scale 4 and was strong at
    scales 16,32,64,80.

v123 freezes that replacement hypothesis BEFORE computing any cell k>=1088.

FRESH BLIND REGION
------------------
    k = 1088..1407       (320 unseen cells)

PREREGISTERED SCIENTIFIC GATES
------------------------------
Prime dominance:
    RMS(q_arch)/RMS(q_prime) <= 0.02
    corr(q_total,q_prime) >= 0.999

Prime self-cancellation:
    permutation cumulative lower-tail percentile <= 0.01
    permutation low-frequency lower-tail percentile <= 0.01

Mesoscopic scale replication:
    block-16 suppression ratio <= 0.70
    block-32 suppression ratio <= 0.60
    block-64 suppression ratio <= 0.60

Corroborating total staircase:
    total permutation cumulative percentile <= 0.01
    total permutation low-frequency percentile <= 0.01

Numerical gates:
    root residual < 1e-8
    counterterm qphase,qder < 5e-6
    cell integration qcheck < 1e-8
    arch component qcheck < 1e-8

NON-GATED
---------
* 80/160-cell subwindow statistics
* full boundary-defect growth from k=48 through 1407
* global growth factor relative to v122 k<=1087
* exact location of strongest block scale

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import digamma

VERSION = "v123"
BUILD = "2026-08-18-preregistered-blind-prime-self-cancellation-v123"
EPS = 1e-30


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def q_total_cell(phase, lo, hi, k, q):
    E, W = nodes(float(lo), float(hi), int(q))
    F = np.asarray(phase.F(E), float)
    Q = F - float(k)
    return {
        "q": float(np.sum(W * Q)),
        "max_abs_Q": float(np.max(np.abs(Q))),
        "abs_Q_integral": float(np.sum(W * np.abs(Q))),
    }


def arch_fprime(E):
    E = np.asarray(E, float)
    return (
        np.real(digamma(0.25 + 0.5j * E)) - math.log(math.pi)
    ) / (2.0 * math.pi)


def q_from_fprime(func, lo, hi, q):
    E, W = nodes(float(lo), float(hi), int(q))
    mid = 0.5 * (float(lo) + float(hi))
    fp = np.asarray(func(E), float)
    return float(-np.sum(W * (E - mid) * fp))


def prime_endpoint_functions(Evals, phase_w, logs, chunk_terms):
    """
    If the prime contribution to F is
        F_p(E)=-(1/pi) sum w_n sin(E log n),
    an antiderivative is
        A_p(E)=+(1/pi) sum w_n/log(n) cos(E log n).

    The adaptive trapezoid defect on [a,b] is then
        A_p(b)-A_p(a) - (b-a)/2 [F_p(a)+F_p(b)].
    """
    Evals = np.asarray(Evals, float)
    phase_w = np.asarray(phase_w, float)
    logs = np.asarray(logs, float)

    Fp = np.zeros(len(Evals), float)
    Anti = np.zeros(len(Evals), float)

    n = len(logs)
    for s in range(0, n, int(chunk_terms)):
        e = min(n, s + int(chunk_terms))
        lg = logs[s:e]
        ww = phase_w[s:e]
        ang = Evals[:, None] * lg[None, :]

        Fp += -np.sum(
            np.sin(ang) * ww[None, :], axis=1
        ) / math.pi
        Anti += np.sum(
            np.cos(ang) * (ww / lg)[None, :], axis=1
        ) / math.pi

    return Fp, Anti


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c) - np.min(c))


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def corr(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x*x)))


def permutation_metrics(x, nperm, rng, lowfreq_bins):
    x = np.asarray(x, float)
    real_c = cumulative_max(x)
    real_l = lowfreq_fraction(x, lowfreq_bins)

    pc = np.empty(int(nperm), float)
    pl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        y = rng.permutation(x)
        pc[t] = cumulative_max(y)
        pl[t] = lowfreq_fraction(y, lowfreq_bins)

    return {
        "real_cumulative_max": real_c,
        "real_cumulative_range": cumulative_range(x),
        "real_lowfreq_fraction": real_l,
        "perm_cumulative_mean": float(np.mean(pc)),
        "perm_cumulative_p05": float(np.quantile(pc, 0.05)),
        "perm_cumulative_median": float(np.median(pc)),
        "perm_lowfreq_mean": float(np.mean(pl)),
        "cumulative_lower_tail_percentile": percentile_le(pc, real_c),
        "lowfreq_lower_tail_percentile": percentile_le(pl, real_l),
    }


def block_sum_rms(x, block):
    x = np.asarray(x, float)
    b = int(block)
    n = len(x) // b
    if n < 1:
        return float("nan")
    y = x[:n*b].reshape(n, b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))


def block_control(x, block, nperm, rng):
    real = block_sum_rms(x, block)
    ctrl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        ctrl[t] = block_sum_rms(rng.permutation(x), block)
    mean = float(np.mean(ctrl))
    return {
        "block_size": int(block),
        "real_block_sum_rms": real,
        "perm_mean": mean,
        "perm_p05": float(np.quantile(ctrl, 0.05)),
        "lower_tail_percentile": percentile_le(ctrl, real),
        "suppression_ratio": real / max(mean, EPS),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v122-prefix",
        default="rot_rh_post_nogo_prime_self_cancellation_v122",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--blind-start", type=int, default=1088)
    ap.add_argument("--blind-end", type=int, default=1407)
    ap.add_argument("--max-depth", type=int, default=1408)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--counter-qcheck", type=int, default=16384)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--cell-q", type=int, default=64)
    ap.add_argument("--cell-qcheck", type=int, default=128)
    ap.add_argument("--arch-q", type=int, default=32)
    ap.add_argument("--arch-qcheck", type=int, default=64)
    ap.add_argument("--prime-chunk-terms", type=int, default=2048)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260818)
    ap.add_argument(
        "--prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    args = ap.parse_args()

    # Frozen scientific region.
    if args.blind_start != 1088 or args.blind_end != 1407:
        raise ValueError("v123 is frozen for blind cells 1088..1407.")
    if args.max_depth < 1408:
        raise ValueError("v123 requires max-depth >= 1408.")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    try:
        code_path = Path(__file__).resolve()
        code_sha = sha256_file(code_path)
    except Exception:
        code_path = None
        code_sha = None

    prereg = {
        "version": VERSION,
        "build": BUILD,
        "scientific_preregistration": True,
        "created_before_blind_support": True,
        "code_path": str(code_path) if code_path else None,
        "code_sha256": code_sha,
        "L": int(args.L),
        "prior_data_boundary": 1087,
        "fresh_blind_region": [1088, 1407],
        "hypothesis": (
            "After the finite-depth prime-Gamma crossover disappears, the "
            "adaptive prime trapezoid-defect sequence itself retains strongly "
            "suppressed cumulative and low-frequency power, with suppression "
            "emerging on mesoscopic block scales >=4."
        ),
        "scientific_gates": {
            "arch_over_prime_rms": "<=0.02",
            "corr_total_prime": ">=0.999",
            "prime_cumulative_perm_percentile": "<=0.01",
            "prime_lowfreq_perm_percentile": "<=0.01",
            "prime_block16_suppression_ratio": "<=0.70",
            "prime_block32_suppression_ratio": "<=0.60",
            "prime_block64_suppression_ratio": "<=0.60",
            "total_cumulative_perm_percentile": "<=0.01",
            "total_lowfreq_perm_percentile": "<=0.01",
        },
        "numerical_gates": {
            "root_residual": "<1e-8",
            "counterterm_qphase_qder": "<5e-6",
            "cell_qcheck": "<1e-8",
            "arch_qcheck": "<1e-8",
        },
        "non_gated": [
            "80/160-cell subwindow statistics",
            "global boundary-defect growth through k=1407",
            "growth factor relative to v122 k<=1087",
            "block scales other than 16,32,64",
        ],
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
    }

    prefreeze = Path(str(prefix) + "_PREFREEZE.json")
    prefreeze.write_text(json.dumps(prereg, indent=2), encoding="utf-8")
    prefreeze_sha = sha256_file(prefreeze)

    print("=" * 162)
    print("ROT-RH v123 — PREREGISTERED BLIND PRIME SELF-CANCELLATION REPLICATION")
    print("=" * 162)
    print("PREFREEZE SHA                   :", prefreeze_sha)
    print("L                               :", args.L)
    print("fresh blind cells               :", f"{args.blind_start}..{args.blind_end}")
    print("cell count                      :", args.blind_end-args.blind_start+1)
    print("counter q / qcheck              :", args.counter_q, "/", args.counter_qcheck)
    print("permutations                    :", args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 162)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("[1] Build fresh high-resolution zero-free support", flush=True)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    support = v102.ordered_support(
        phase,
        depth=int(args.max_depth),
        scan_points=int(args.scan_points),
        qcheck=int(args.counter_qcheck),
    )
    roots = np.asarray(support.roots, float)

    print(
        f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
        f"maxres={np.max(support.residuals):.3e} "
        f"qphase={support.quadrature_phase_rel_l2:.3e} "
        f"qder={support.quadrature_deriv_rel_l2:.3e}"
    )

    ks = list(range(args.blind_start, args.blind_end + 1))
    lo = np.asarray([roots[k-1] for k in ks], float)
    hi = np.asarray([roots[k] for k in ks], float)
    width = hi-lo
    endpoints = np.concatenate([[lo[0]], hi])

    print("[2] Compute 320 fresh total staircase defects", flush=True)
    qtotal = np.empty(len(ks), float)
    qdiff = np.empty(len(ks), float)
    maxQ = np.empty(len(ks), float)
    absQint = np.empty(len(ks), float)

    for j, k in enumerate(ks):
        r0 = q_total_cell(
            phase, lo[j], hi[j], k, args.cell_q
        )
        r1 = q_total_cell(
            phase, lo[j], hi[j], k, args.cell_qcheck
        )
        qtotal[j] = r1["q"]
        qdiff[j] = abs(r1["q"]-r0["q"])
        maxQ[j] = r1["max_abs_Q"]
        absQint[j] = r1["abs_Q_integral"]

        if (j+1) % 80 == 0:
            print(
                f"  through k={k}: "
                f"max|Q|={np.max(maxQ[j-79:j+1]):.6f} "
                f"max qdiff={np.max(qdiff[j-79:j+1]):.2e}"
            )

    print("[3] Exact prime defects + Gamma diagnostic", flush=True)
    phase_w = np.asarray(phase.phase_w, float)
    logs = np.asarray(phase.logs, float)

    Fp, Anti = prime_endpoint_functions(
        endpoints, phase_w, logs, args.prime_chunk_terms
    )
    qprime = (
        Anti[1:] - Anti[:-1]
        - 0.5*width*(Fp[:-1]+Fp[1:])
    )

    qarch0 = np.empty(len(ks), float)
    qarch = np.empty(len(ks), float)
    for j in range(len(ks)):
        qarch0[j] = q_from_fprime(
            arch_fprime, lo[j], hi[j], args.arch_q
        )
        qarch[j] = q_from_fprime(
            arch_fprime, lo[j], hi[j], args.arch_qcheck
        )

    arch_qcheck = float(np.max(np.abs(qarch-qarch0)))
    arch_over_prime = rms(qarch)/max(rms(qprime), EPS)
    corr_total_prime = corr(qtotal, qprime)
    rel_total_minus_prime = float(
        np.linalg.norm(qtotal-qprime) /
        max(np.linalg.norm(qtotal), EPS)
    )

    print("  arch/prime RMS                 :", f"{arch_over_prime:.12e}")
    print("  corr(total,prime)              :", f"{corr_total_prime:.12e}")
    print("  ||total-prime||/||total||      :", f"{rel_total_minus_prime:.12e}")
    print("  arch qcheck                    :", f"{arch_qcheck:.12e}")

    print("[4] Frozen prime self-cancellation tests", flush=True)
    rng = np.random.default_rng(args.seed)

    prime_perm = permutation_metrics(
        qprime, args.permutations, rng, args.lowfreq_bins
    )
    total_perm = permutation_metrics(
        qtotal, args.permutations, rng, args.lowfreq_bins
    )

    print(
        "  PRIME cumMax / permMean        :",
        f"{prime_perm['real_cumulative_max']:.6e} / "
        f"{prime_perm['perm_cumulative_mean']:.6e}"
    )
    print(
        "  PRIME cumulative percentile    :",
        f"{100*prime_perm['cumulative_lower_tail_percentile']:.6f}%"
    )
    print(
        "  PRIME lowF percentile          :",
        f"{100*prime_perm['lowfreq_lower_tail_percentile']:.6f}%"
    )
    print(
        "  TOTAL cumulative percentile    :",
        f"{100*total_perm['cumulative_lower_tail_percentile']:.6f}%"
    )
    print(
        "  TOTAL lowF percentile          :",
        f"{100*total_perm['lowfreq_lower_tail_percentile']:.6f}%"
    )

    print("[5] Frozen mesoscopic block-scale tests", flush=True)
    block_rows = []
    block_map = {}
    for b in [1,2,4,8,16,32,64,80,160]:
        if b > len(qprime):
            continue
        row = block_control(
            qprime, b, args.permutations, rng
        )
        block_rows.append(row)
        block_map[b] = row
        print(
            f"  block={b:<3d}: ratio={row['suppression_ratio']:.4f} "
            f"p={100*row['lower_tail_percentile']:.4f}%"
        )

    print("[6] Non-gated 80/160-cell diagnostics", flush=True)
    sub_rows = []
    for w in [80, 160]:
        idx = 0
        start = 0
        while start < len(qprime):
            end = min(len(qprime), start+w)
            if end-start != w:
                break
            pm = permutation_metrics(
                qprime[start:end],
                args.permutations,
                rng,
                args.lowfreq_bins,
            )
            tm = permutation_metrics(
                qtotal[start:end],
                args.permutations,
                rng,
                args.lowfreq_bins,
            )
            row = {
                "window_size": w,
                "window_index": idx+1,
                "k_start": ks[start],
                "k_end": ks[end-1],
                "prime_cumulative_percentile":
                    pm["cumulative_lower_tail_percentile"],
                "prime_lowfreq_percentile":
                    pm["lowfreq_lower_tail_percentile"],
                "total_cumulative_percentile":
                    tm["cumulative_lower_tail_percentile"],
                "total_lowfreq_percentile":
                    tm["lowfreq_lower_tail_percentile"],
            }
            sub_rows.append(row)
            print(
                f"  w={w:<3d} {ks[start]}-{ks[end-1]}: "
                f"primeCum={100*row['prime_cumulative_percentile']:.3f}% "
                f"primeLowF={100*row['prime_lowfreq_percentile']:.3f}%"
            )
            idx += 1
            start = end

    print("[7] Non-gated global boundary-defect extension", flush=True)
    v122_cells = Path(
        str(Path(args.v122_prefix).expanduser().resolve()) +
        "_MERGED_CELLS.csv"
    )
    global_rows = []
    growth_factor = None
    prev_cmax = None
    full_cmax = None

    if v122_cells.exists():
        old = read_csv(v122_cells)
        old = sorted(
            [r for r in old if int(float(r["k"])) <= 1087],
            key=lambda r: int(float(r["k"])),
        )
        old_q = np.asarray([float(r["q_total"]) for r in old], float)
        prev_cmax = cumulative_max(old_q)
        full_q = np.concatenate([old_q, qtotal])
        full_cmax = cumulative_max(full_q)
        growth_factor = full_cmax / max(prev_cmax, EPS)

        start_k = int(float(old[0]["k"]))
        for n in range(80, len(full_q)+1, 80):
            global_rows.append({
                "prefix_cells": n,
                "k_end": start_k+n-1,
                "total_cumulative_max": cumulative_max(full_q[:n]),
            })
        if global_rows[-1]["prefix_cells"] != len(full_q):
            global_rows.append({
                "prefix_cells": len(full_q),
                "k_end": args.blind_end,
                "total_cumulative_max": full_cmax,
            })

        print("  previous max through k=1087    :", f"{prev_cmax:.12e}")
        print("  new max through k=1407         :", f"{full_cmax:.12e}")
        print("  growth factor                  :", f"{growth_factor:.12e}")
    else:
        print("  v122 merged cells not found; skipped global extension.")

    gates = {
        "root_residual_below_1e8":
            bool(float(np.max(support.residuals)) < 1e-8),
        "counterterm_quadrature_stable":
            bool(
                support.quadrature_phase_rel_l2 < 5e-6
                and support.quadrature_deriv_rel_l2 < 5e-6
            ),
        "cell_qcheck_below_1e8":
            bool(float(np.max(qdiff)) < 1e-8),
        "arch_qcheck_below_1e8":
            bool(arch_qcheck < 1e-8),

        "arch_over_prime_rms_below_0p02":
            bool(arch_over_prime <= 0.02),
        "corr_total_prime_above_0p999":
            bool(corr_total_prime >= 0.999),

        "prime_cumulative_perm_pct_below_0p01":
            bool(prime_perm["cumulative_lower_tail_percentile"] <= 0.01),
        "prime_lowfreq_perm_pct_below_0p01":
            bool(prime_perm["lowfreq_lower_tail_percentile"] <= 0.01),

        "prime_block16_ratio_below_0p70":
            bool(block_map[16]["suppression_ratio"] <= 0.70),
        "prime_block32_ratio_below_0p60":
            bool(block_map[32]["suppression_ratio"] <= 0.60),
        "prime_block64_ratio_below_0p60":
            bool(block_map[64]["suppression_ratio"] <= 0.60),

        "total_cumulative_perm_pct_below_0p01":
            bool(total_perm["cumulative_lower_tail_percentile"] <= 0.01),
        "total_lowfreq_perm_pct_below_0p01":
            bool(total_perm["lowfreq_lower_tail_percentile"] <= 0.01),
    }

    numerical = [
        "root_residual_below_1e8",
        "counterterm_quadrature_stable",
        "cell_qcheck_below_1e8",
        "arch_qcheck_below_1e8",
    ]
    scientific = [k for k in gates if k not in numerical]

    if all(gates[k] for k in numerical) and all(
        gates[k] for k in scientific
    ):
        verdict = (
            "PASS_V123_PREREGISTERED_PRIME_SELF_CANCELLATION_REPLICATES_BLIND"
        )
    elif all(gates[k] for k in numerical):
        verdict = (
            "NO_GO_V123_PRIME_SELF_CANCELLATION_FAILS_FROZEN_BLIND_GATES"
        )
    else:
        verdict = "FAIL_V123_NUMERICAL_SUPPORT_INVALID"

    cell_rows = []
    for j, k in enumerate(ks):
        cell_rows.append({
            "k": k,
            "lo": lo[j],
            "hi": hi[j],
            "width": width[j],
            "q_total": qtotal[j],
            "q_prime": qprime[j],
            "q_arch": qarch[j],
            "q_nonprime": qtotal[j]-qprime[j],
            "max_abs_Q": maxQ[j],
            "abs_Q_integral": absQint[j],
            "cell_qcheck_absdiff": qdiff[j],
        })

    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)
    write_csv(Path(str(prefix) + "_SUBWINDOWS.csv"), sub_rows)
    if global_rows:
        write_csv(Path(str(prefix) + "_GLOBAL_PREFIX.csv"), global_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "prefreeze_sha256": prefreeze_sha,
        "fresh_region": [args.blind_start, args.blind_end],
        "gates": gates,
        "arch_over_prime_rms": arch_over_prime,
        "corr_total_prime": corr_total_prime,
        "total_minus_prime_rel_l2": rel_total_minus_prime,
        "prime_permutation_metrics": prime_perm,
        "total_permutation_metrics": total_perm,
        "block_rows": block_rows,
        "previous_global_cumulative_max": prev_cmax,
        "new_global_cumulative_max": full_cmax,
        "global_growth_factor_not_gated": growth_factor,
        "interpretation": (
            "A PASS is a fresh preregistered replication that the asymptotic "
            "candidate mechanism is internal ordering/self-cancellation of "
            "the prime adaptive trapezoid defects after Gamma becomes "
            "negligible. It does not prove uniformly bounded partial sums; "
            "global cumulative growth is intentionally reported but not gated."
        ),
    }

    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 162)
    print("FINAL v123 VERDICT")
    print("=" * 162)
    print("verdict                         :", verdict)
    print("PREFREEZE SHA                   :", prefreeze_sha)
    print("arch/prime RMS                  :", f"{arch_over_prime:.12e}")
    print("corr(total,prime)               :", f"{corr_total_prime:.12e}")
    print("prime cumulative percentile     :",
          f"{100*prime_perm['cumulative_lower_tail_percentile']:.6f}%")
    print("prime lowF percentile           :",
          f"{100*prime_perm['lowfreq_lower_tail_percentile']:.6f}%")
    print("block16/32/64 ratios            :",
          f"{block_map[16]['suppression_ratio']:.6f}, "
          f"{block_map[32]['suppression_ratio']:.6f}, "
          f"{block_map[64]['suppression_ratio']:.6f}")
    print("total cumulative percentile     :",
          f"{100*total_perm['cumulative_lower_tail_percentile']:.6f}%")
    print("total lowF percentile           :",
          f"{100*total_perm['lowfreq_lower_tail_percentile']:.6f}%")
    if full_cmax is not None:
        print("global cumulative max k<=1407   :", f"{full_cmax:.12e}")
        print("growth factor vs k<=1087        :", f"{growth_factor:.12e}")
    print("qphase                          :",
          f"{support.quadrature_phase_rel_l2:.12e}")
    print("qder                            :",
          f"{support.quadrature_deriv_rel_l2:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 162)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
