#!/usr/bin/env python3
"""
ROT-RH v186 — SIGNED REAL-WEIGHT / PHASE-MIXING AUDIT

Purpose
-------
v185 falsified the hypothesis that switch broadening is caused by a small
moving-root derivative of the *amplitude-envelope* ratio.

But v182.1 showed

    epsilon_mix
      = tau*(G-gamma_active*R)/(tau*R+Q)

and Q/(tau R) is tiny.  Hence

    epsilon_mix ~ G/R - gamma_active.

Crucially, R and G use SIGNED REAL PARTS of the Gamma-layer contributions,
not their absolute amplitudes.

For each physical positive-gamma layer i=1,2, group its direct and functional
mirror terms:

    C_i = z(a_i,+gamma_i) + z(-a_i,+gamma_i)

and define

    A_i   = |C_i|             envelope magnitude
    W_i   = Re C_i            signed real weight
    c_i   = W_i/A_i = cos(phi_i).

Then

    W_2/W_1
      = (A_2/A_1) * (c_2/c_1).

Thus broad mixing can persist even if A_2/A_1 crosses sharply, whenever one
of the cosine factors is small or oscillatory.

This script tests that mechanism using already root-reprojected v183 points.
No continuation is performed.

Main outputs
------------
- exact epsilon_mix / Delta gamma
- positive-layer pair approximation
- envelope ratio A2/A1
- real-weight ratio |W2/W1|
- phase amplification = |(W2/W1)/(A2/A1)| = |c2/c1|
- active-layer |cos(phi)| near-zero diagnostics
- negative-gamma contamination fraction
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def safe_ratio(a, b):
    if b == 0:
        return np.inf
    return a/b


def quantiles(a):
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    if len(a) == 0:
        return {k: np.nan for k in ["q50","q90","q99","max"]}
    return {
        "q50": float(np.quantile(a, 0.50)),
        "q90": float(np.quantile(a, 0.90)),
        "q99": float(np.quantile(a, 0.99)),
        "max": float(np.max(a)),
    }


class LayerPhase:
    def __init__(self, b1, g1, b2, g2):
        self.b1 = mp.mpf(str(b1))
        self.b2 = mp.mpf(str(b2))
        self.g1 = mp.mpf(str(g1))
        self.g2 = mp.mpf(str(g2))
        self.a1 = self.b1-mp.mpf("0.5")
        self.a2 = self.b2-mp.mpf("0.5")

    @staticmethod
    def one_term(a, g, E, tau):
        w = a + 1j*(E-g)
        logz = (
            mp.loggamma(w)
            + a*tau
            + 1j*(E-g)*tau
        )
        return w, logz

    def evaluate(self, E, tau, gamma_active):
        E = mp.mpf(str(E))
        tau = mp.mpf(str(tau))
        ga = mp.mpf(str(gamma_active))

        specs = [
            ("L1_pos_direct",  self.a1,  self.g1, 1),
            ("L1_neg_direct",  self.a1, -self.g1, 1),
            ("L1_pos_mirror", -self.a1,  self.g1, 1),
            ("L1_neg_mirror", -self.a1, -self.g1, 1),
            ("L2_pos_direct",  self.a2,  self.g2, 2),
            ("L2_neg_direct",  self.a2, -self.g2, 2),
            ("L2_pos_mirror", -self.a2,  self.g2, 2),
            ("L2_neg_mirror", -self.a2, -self.g2, 2),
        ]

        raw = []
        for name, a, g, layer in specs:
            w, logz = self.one_term(a, g, E, tau)
            raw.append((name, a, g, layer, w, logz))

        shift = max(mp.re(t[-1]) for t in raw)

        terms = []
        for name, a, g, layer, w, logz in raw:
            z = mp.exp(logz-shift)
            terms.append({
                "name": name,
                "a": a,
                "g": g,
                "layer": layer,
                "w": w,
                "z": z,
            })

        # Full exact quantities.
        R = mp.fsum(mp.re(t["z"]) for t in terms)
        G = mp.fsum(t["g"]*mp.re(t["z"]) for t in terms)

        Q = mp.im(mp.fsum(
            1j*mp.digamma(t["w"])*t["z"]
            for t in terms
        ))

        D = tau*R+Q
        eps_mix = tau*(G-ga*R)/D

        # Positive physical-gamma groups, direct + functional mirror.
        def group(layer, sign):
            zz = mp.fsum(
                t["z"]
                for t in terms
                if t["layer"] == layer
                and (1 if t["g"] > 0 else -1) == sign
            )
            return zz

        C1p = group(1, +1)
        C1n = group(1, -1)
        C2p = group(2, +1)
        C2n = group(2, -1)

        A1 = abs(C1p)
        A2 = abs(C2p)
        W1 = mp.re(C1p)
        W2 = mp.re(C2p)

        cos1 = W1/A1 if A1 != 0 else mp.nan
        cos2 = W2/A2 if A2 != 0 else mp.nan

        envelope_ratio = A2/A1 if A1 != 0 else mp.inf
        signed_weight_ratio = (
            abs(W2/W1) if W1 != 0 else mp.inf
        )
        phase_amplification = (
            signed_weight_ratio/envelope_ratio
            if envelope_ratio != 0 and mp.isfinite(envelope_ratio)
            else mp.inf
        )

        # Positive-pair-only soft gamma.
        Rp = W1+W2
        Gp = self.g1*W1+self.g2*W2
        soft_pair = Gp/Rp if Rp != 0 else mp.nan
        eps_pair = soft_pair-ga if Rp != 0 else mp.nan

        dg = abs(self.g2-self.g1)
        m_exact = abs(eps_mix)/dg if dg != 0 else mp.nan
        m_pair = abs(eps_pair)/dg if dg != 0 else mp.nan

        # How much do negative-gamma groups perturb the real denominator?
        Rneg = mp.re(C1n+C2n)
        Rpos = Rp
        neg_contam = (
            abs(Rneg)/max(abs(Rpos), mp.mpf("1e-100"))
        )

        # Exact positive-pair mixing fraction in real weights.
        if ga == self.g1:
            frac_other = (
                abs(W2/Rp) if Rp != 0 else mp.inf
            )
            active_cos = abs(cos1)
            other_cos = abs(cos2)
        else:
            frac_other = (
                abs(W1/Rp) if Rp != 0 else mp.inf
            )
            active_cos = abs(cos2)
            other_cos = abs(cos1)

        return {
            "epsilon_mix": eps_mix,
            "m_exact": m_exact,
            "m_pair": m_pair,
            "pair_fraction_other": frac_other,
            "pair_approx_error": abs(m_exact-m_pair),
            "A1": A1,
            "A2": A2,
            "W1": W1,
            "W2": W2,
            "cos1": cos1,
            "cos2": cos2,
            "active_abs_cos": active_cos,
            "other_abs_cos": other_cos,
            "envelope_ratio_A2_A1": envelope_ratio,
            "signed_weight_ratio_abs": signed_weight_ratio,
            "phase_amplification_abs": phase_amplification,
            "negative_gamma_contamination": neg_contam,
            "q_over_tauR": (
                abs(Q)/(tau*abs(R))
                if R != 0 else mp.inf
            ),
            "R_full": R,
            "R_pos": Rpos,
            "R_neg": Rneg,
        }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--points-csv",
        default="rot_rh_global_cesaro_mix_scale_v183_POINTS.csv",
    )
    ap.add_argument(
        "--switch-indices",
        default="159",
    )
    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument(
        "--phase-small-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--pair-error-gate",
        type=float,
        default=1e-4,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_signed_real_weight_phase_mix_v186",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps

    pts = pd.read_csv(args.points_csv)
    switches = [
        int(x.strip())
        for x in args.switch_indices.split(",")
        if x.strip()
    ]
    pts = pts[pts["switch"].astype(int).isin(switches)].copy()

    required = {
        "switch","tau","E","tau_switch",
        "beta_left","beta_right",
        "gamma_left","gamma_right",
        "gamma_active",
    }
    missing = required-set(pts.columns)
    if missing:
        raise RuntimeError(f"Missing columns: {sorted(missing)}")

    print("="*176)
    print("ROT-RH v186 — SIGNED REAL-WEIGHT / PHASE-MIXING AUDIT")
    print("="*176)
    print(f"switches                          : {switches}")
    print(f"sample rows                       : {len(pts)}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*176)

    rows = []
    summaries = []

    for sw, g in pts.groupby("switch"):
        g = g.sort_values("tau").reset_index(drop=True)

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        gg1 = float(g.iloc[0]["gamma_left"])
        gg2 = float(g.iloc[0]["gamma_right"])
        ts = float(g.iloc[0]["tau_switch"])

        phase = LayerPhase(b1, gg1, b2, gg2)
        da = abs(b2-b1)

        for _, r in g.iterrows():
            out = phase.evaluate(
                float(r["E"]),
                float(r["tau"]),
                float(r["gamma_active"]),
            )

            row = {
                "switch": int(sw),
                "tau": float(r["tau"]),
                "tau_switch": ts,
                "x": da*(float(r["tau"])-ts),
                "E": float(r["E"]),
                "gamma_active": float(r["gamma_active"]),
            }
            for k, v in out.items():
                try:
                    row[k] = float(v)
                except Exception:
                    row[k] = np.nan
            rows.append(row)

        sdf = pd.DataFrame([r for r in rows if r["switch"] == int(sw)])
        sdf = sdf.sort_values("tau")

        phase_amp = sdf["phase_amplification_abs"].to_numpy(float)
        active_cos = sdf["active_abs_cos"].to_numpy(float)
        env_ratio = sdf["envelope_ratio_A2_A1"].to_numpy(float)
        weight_ratio = sdf["signed_weight_ratio_abs"].to_numpy(float)
        pair_err = sdf["pair_approx_error"].to_numpy(float)
        neg = sdf["negative_gamma_contamination"].to_numpy(float)

        small_phase_frac = float(
            np.mean(active_cos < args.phase_small_gate)
        )

        q_phase = quantiles(phase_amp)
        q_weight = quantiles(weight_ratio)
        q_env = quantiles(env_ratio)

        max_pair_err = float(np.nanmax(pair_err))
        max_neg = float(np.nanmax(neg))

        # Correlation in log space between exact mixing and envelope vs signed weights.
        m = sdf["m_exact"].to_numpy(float)

        def logcorr(a, b):
            a = np.asarray(a, float)
            b = np.asarray(b, float)
            ok = (
                np.isfinite(a) & np.isfinite(b)
                & (a > 0) & (b > 0)
            )
            if np.sum(ok) < 4:
                return np.nan
            return float(np.corrcoef(
                np.log(a[ok]), np.log(b[ok])
            )[0,1])

        corr_env = logcorr(m, env_ratio)
        corr_weight = logcorr(m, weight_ratio)

        # Phase mechanism evidence:
        # pair reduction is accurate and signed weight ratio tracks mixing
        # substantially better than envelope ratio.
        phase_mechanism = bool(
            max_pair_err <= args.pair_error_gate
            and np.isfinite(corr_weight)
            and (
                (not np.isfinite(corr_env))
                or corr_weight >= corr_env + 0.15
            )
        )

        summaries.append({
            "switch": int(sw),
            "samples": len(sdf),
            "max_pair_approx_error": max_pair_err,
            "max_negative_gamma_contamination": max_neg,
            "active_cos_below_gate_fraction": small_phase_frac,
            "phase_amplification_q50": q_phase["q50"],
            "phase_amplification_q90": q_phase["q90"],
            "phase_amplification_q99": q_phase["q99"],
            "phase_amplification_max": q_phase["max"],
            "envelope_ratio_q50": q_env["q50"],
            "signed_weight_ratio_q50": q_weight["q50"],
            "corr_logmix_log_envelope_ratio": corr_env,
            "corr_logmix_log_signed_weight_ratio": corr_weight,
            "phase_mechanism_supported": phase_mechanism,
        })

        print(
            f"[switch {int(sw):4d}] "
            f"pairerr={max_pair_err:.3e} "
            f"neg={max_neg:.3e} "
            f"phaseAmp q50/q90/q99="
            f"{q_phase['q50']:.3e}/"
            f"{q_phase['q90']:.3e}/"
            f"{q_phase['q99']:.3e} "
            f"corr(m,env)={corr_env:.3f} "
            f"corr(m,W)={corr_weight:.3f} "
            f"small-active-cos={small_phase_frac:.3f}"
        )

    out = pd.DataFrame(rows)
    swdf = pd.DataFrame(summaries)

    supported = bool(
        len(swdf) > 0
        and swdf["phase_mechanism_supported"].all()
    )

    verdict = (
        "SIGNED_REAL_WEIGHT_PHASE_MIXING_SUPPORTED"
        if supported
        else "SIGNED_REAL_WEIGHT_PHASE_MIXING_UNRESOLVED"
    )

    out.to_csv(args.prefix+"_POINTS.csv", index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv", index=False)

    summary = {
        "version": 186,
        "switches": switches,
        "all_switches_phase_mechanism_supported": supported,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*176)
    for _, r in swdf.iterrows():
        print(f"switch {int(r['switch'])}")
        print(f"  max pair approximation error    : {r['max_pair_approx_error']:.6e}")
        print(f"  max negative-gamma contamination: {r['max_negative_gamma_contamination']:.6e}")
        print(f"  phase amplification q50         : {r['phase_amplification_q50']:.6e}")
        print(f"  phase amplification q90         : {r['phase_amplification_q90']:.6e}")
        print(f"  phase amplification q99         : {r['phase_amplification_q99']:.6e}")
        print(f"  corr mixing vs envelope ratio   : {r['corr_logmix_log_envelope_ratio']:.6f}")
        print(f"  corr mixing vs signed W ratio   : {r['corr_logmix_log_signed_weight_ratio']:.6f}")
        print(f"  small active cos fraction       : {r['active_cos_below_gate_fraction']:.6f}")
    print(f"VERDICT                           : {verdict}")
    print("="*176)


if __name__ == "__main__":
    main()
