#!/usr/bin/env python3
"""
ROT-RH v197 — LATE-SWITCH CRITICAL REFINEMENT + UNIVERSAL PROFILE COLLAPSE

Purpose
-------
v196 found
    K_114 ~ 0.961
    K_136 ~ 0.942
    K_159 ~ 0.953
but switches 114 and 136 were still marked PARTIAL because a few points in
the narrow x in [-1,0] boundary layer were not fully phase-resolved, and
switch 136 had poor coarse-x stride behavior.

v197:
  1. recomputes ONLY a dense critical layer for switches 114 and 136;
  2. uses several equivalent phase-window offsets and accepts only stable
     averages;
  3. merges those values into the existing v196 profiles;
  4. recomputes K_hom with stride checks;
  5. compares the intrinsic normalized profiles

         m_j(x) = <|epsilon_j|>_phase / Delta gamma_j

     against the frozen switch-159 v195 profile on their common x-range.

No Xi / zeta / known zeros are used.

Requires:
  rot_rh_transition_homogenization_v192.py
  rot_rh_phase_shifted_missing_points_v194.py
"""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def decimated(df, stride):
    d = df.sort_values("x").reset_index(drop=True)
    ids = list(range(0, len(d), stride))
    if len(d)-1 not in ids:
        ids.append(len(d)-1)
    return d.iloc[sorted(set(ids))].copy()


def add_intrinsic(df, dg):
    d = df.copy()
    d["epsilon_phase_avg"] = (
        d["mean_abs_epsilon_over_gamma"] * d["gamma_active"]
    )
    d["m_intrinsic"] = d["epsilon_phase_avg"] / dg
    return d


def K_from_profile(df, dg):
    d = add_intrinsic(df, dg).sort_values("x")
    return trapz(
        d["x"].to_numpy(float),
        d["m_intrinsic"].to_numpy(float),
    )


def pointwise_collapse(profiles, xlo=-8.0, xhi=0.0, n=257):
    """
    Interpolate log-safe intrinsic profiles to a common grid and compare
    ratios only where the switch-159 reference is materially nonzero.
    """
    xs = np.linspace(xlo, xhi, n)

    interp = {}
    for sw, d in profiles.items():
        dd = d.sort_values("x")
        x = dd["x"].to_numpy(float)
        m = dd["m_intrinsic"].to_numpy(float)
        interp[sw] = np.interp(xs, x, m)

    ref = interp[159]
    material = ref > 1e-10

    rows = []
    for sw in sorted(interp):
        if sw == 159:
            continue
        y = interp[sw]
        ok = material & (y > 0)
        if np.sum(ok) < 5:
            rows.append({
                "switch": sw,
                "material_points": int(np.sum(ok)),
                "log_rmse_vs_159": np.nan,
                "median_ratio_vs_159": np.nan,
                "q10_ratio_vs_159": np.nan,
                "q90_ratio_vs_159": np.nan,
            })
            continue

        lr = np.log(y[ok]) - np.log(ref[ok])
        ratio = y[ok]/ref[ok]

        rows.append({
            "switch": sw,
            "material_points": int(np.sum(ok)),
            "log_rmse_vs_159": float(np.sqrt(np.mean(lr*lr))),
            "median_ratio_vs_159": float(np.median(ratio)),
            "q10_ratio_vs_159": float(np.quantile(ratio, 0.10)),
            "q90_ratio_vs_159": float(np.quantile(ratio, 0.90)),
        })

    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--v196-profiles",
        default="rot_rh_late_switch_homogenized_mass_v196_PROFILES.csv",
    )
    ap.add_argument(
        "--v195-profile",
        default="rot_rh_homogenized_intrinsic_mass_v195_PROFILE.csv",
    )
    ap.add_argument(
        "--v192-module",
        default="rot_rh_transition_homogenization_v192",
    )
    ap.add_argument(
        "--v194-module",
        default="rot_rh_phase_shifted_missing_points_v194",
    )

    ap.add_argument("--switch-indices", default="114,136")

    ap.add_argument("--dps", type=int, default=55)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=14)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--search-cells", type=int, default=24)
    ap.add_argument("--branch-count", type=int, default=1)
    ap.add_argument("--phase-points", type=int, default=129)
    ap.add_argument("--max-subdivision-depth", type=int, default=18)

    ap.add_argument("--x-min", type=float, default=-1.25)
    ap.add_argument("--x-max", type=float, default=0.125)
    ap.add_argument("--x-step", type=float, default=0.125)

    ap.add_argument(
        "--phase-offsets",
        default="0.125,0.25,0.5,0.75",
    )
    ap.add_argument(
        "--success-offsets-needed",
        type=int,
        default=2,
    )
    ap.add_argument(
        "--offset-spread-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--phase-grid-gate",
        type=float,
        default=0.05,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_late_switch_critical_collapse_v197",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    mod192 = importlib.import_module(args.v192_module)
    mod194 = importlib.import_module(args.v194_module)

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )
    base196 = pd.read_csv(args.v196_profiles)
    p159 = pd.read_csv(args.v195_profile).copy()

    switches = [
        int(x.strip())
        for x in args.switch_indices.split(",")
        if x.strip()
    ]
    offsets = [
        float(x.strip())
        for x in args.phase_offsets.split(",")
        if x.strip()
    ]

    n = int(round((args.x_max-args.x_min)/args.x_step))
    xvals = [
        mp.mpf(str(args.x_min + k*args.x_step))
        for k in range(n+1)
    ]
    if float(xvals[-1]) < args.x_max-1e-12:
        xvals.append(mp.mpf(str(args.x_max)))

    print("="*188)
    print("ROT-RH v197 — LATE-SWITCH CRITICAL REFINEMENT + UNIVERSAL PROFILE COLLAPSE")
    print("="*188)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switches refined                  : {switches}")
    print(f"critical x window                 : [{args.x_min},{args.x_max}]")
    print(f"x step                            : {args.x_step}")
    print(f"phase points / cycle              : {args.phase_points}")
    print(f"phase offsets                     : {offsets}")
    print("="*188)

    refined_profiles = {}
    summaries = []
    unresolved_all = {}

    for sw in switches:
        j = sw-1
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand, left["beta_active"], left["gamma_active"]
        )
        c2 = match_candidate(
            cand, right["beta_active"], right["gamma_active"]
        )

        b1 = mp.mpf(str(float(c1["beta"])))
        g1 = mp.mpf(str(float(c1["gamma"])))
        b2 = mp.mpf(str(float(c2["beta"])))
        g2 = mp.mpf(str(float(c2["gamma"])))

        ts = mp.mpf(str(float(left["tau_end"])))
        da = abs(b2-b1)
        dg = abs(g2-g1)
        period = 2*mp.pi/dg

        phase = mod192.TwoLayerPhase(b1, g1, b2, g2)

        rows = []
        unresolved = []

        print()
        print(
            f"[switch {sw}] dg={float(dg):.6e} "
            f"da={float(da):.6e} tau={float(ts):.6e}"
        )

        for x in xvals:
            tau = ts+x/da
            ga = g1 if x < 0 else g2
            center = ga

            vals = []
            mixes = []
            pdiffs = []

            for off in offsets:
                rr = mod194.cycle_average_shifted(
                    mod192, phase, tau, center, ga,
                    period, args.phase_points,
                    tol, frac, args.newton_iters,
                    args.search_cells, args.branch_count,
                    args.max_subdivision_depth, off,
                )

                good = [r for r in rr if r.get("ok")]
                if not good:
                    continue

                r = good[0]
                v = float(r["mean_abs_epsilon_over_gamma"])
                vm = float(r["mean_abs_mix_over_gamma"])
                v2 = float(
                    r["phase_stride2_over_gamma"]
                    if "phase_stride2_over_gamma" in r
                    else r.get(
                        "mean_abs_epsilon_over_gamma_phase_stride2",
                        np.nan
                    )
                )
                pdiff = (
                    abs(v2-v)/max(abs(v),1e-300)
                    if np.isfinite(v2) else np.inf
                )

                vals.append(v)
                mixes.append(vm)
                pdiffs.append(pdiff)

                if len(vals) >= args.success_offsets_needed:
                    break

            if len(vals) < args.success_offsets_needed:
                unresolved.append(float(x))
                print(f"  x={float(x):7.3f} UNRESOLVED")
                continue

            mean = float(np.mean(vals))
            spread = float(
                (np.max(vals)-np.min(vals))/max(abs(mean),1e-300)
            )
            maxpd = float(max(pdiffs))

            accepted = bool(
                spread <= args.offset_spread_gate
                and maxpd <= args.phase_grid_gate
            )
            if not accepted:
                unresolved.append(float(x))

            rows.append({
                "switch": sw,
                "x": float(x),
                "tau": float(tau),
                "gamma_active": float(ga),
                "mean_abs_epsilon_over_gamma": mean,
                "mean_abs_mix_over_gamma": float(np.mean(mixes)),
                "successful_offsets": len(vals),
                "offset_relative_spread": spread,
                "max_phase_stride2_relative_difference": maxpd,
                "accepted": accepted,
            })

            print(
                f"  x={float(x):7.3f} r={mean:.6e} "
                f"spread={spread:.2e} phase={maxpd:.2e} "
                f"{'OK' if accepted else 'CHECK'}"
            )

        ref = pd.DataFrame(rows).sort_values("x")
        unresolved_all[str(sw)] = unresolved

        # Merge accepted refined points into complete v196 base profile.
        old = base196[base196["switch"].astype(int) == sw].copy()
        good_ref = ref[ref["accepted"]].copy()

        if len(good_ref):
            xmin = float(good_ref["x"].min())
            xmax = float(good_ref["x"].max())
            outside = old[
                (old["x"] < xmin-1e-12)
                | (old["x"] > xmax+1e-12)
            ].copy()

            merged = pd.concat(
                [outside, good_ref],
                ignore_index=True,
            ).sort_values("x").drop_duplicates("x", keep="last")
        else:
            merged = old.sort_values("x")

        dg_float = float(dg)
        merged = add_intrinsic(merged, dg_float)
        refined_profiles[sw] = merged

        K = K_from_profile(merged, dg_float)
        K2 = K_from_profile(decimated(merged, 2), dg_float)
        K4 = K_from_profile(decimated(merged, 4), dg_float)

        I = K*float(dg)/float(da)
        ggeom = float(mp.sqrt(g1*g2))
        R = I/(ggeom*float(ts))

        summaries.append({
            "switch": sw,
            "delta_gamma": dg_float,
            "delta_a": float(da),
            "tau_switch": float(ts),
            "K_hom": K,
            "K_hom_stride2": K2,
            "K_hom_stride4": K4,
            "K_stride2_relative_difference":
                abs(K2-K)/max(abs(K),1e-300),
            "K_stride4_relative_difference":
                abs(K4-K)/max(abs(K),1e-300),
            "I_hom": I,
            "I_over_gamma_geom_tau": R,
            "critical_unresolved_x": unresolved,
        })

        print(
            f"  => refined K={K:.8e} "
            f"K2={K2:.8e} K4={K4:.8e} "
            f"I/(g*tau)={R:.3e}"
        )

    # Frozen 159 profile.
    if "m_intrinsic" not in p159.columns:
        dg159 = float(
            json.loads(
                Path(
                    "rot_rh_homogenized_intrinsic_mass_v195_SUMMARY.json"
                ).read_text()
            )["delta_gamma"]
        )
        p159 = add_intrinsic(p159, dg159)

    refined_profiles[159] = p159.sort_values("x").copy()

    # Profile collapse.
    collapse = pointwise_collapse(
        refined_profiles,
        xlo=max(
            -8.0,
            max(float(d["x"].min()) for d in refined_profiles.values())
        ),
        xhi=min(
            0.0,
            min(float(d["x"].max()) for d in refined_profiles.values())
        ),
        n=257,
    )

    swdf = pd.DataFrame(summaries)

    # Add frozen K159 from its profile.
    K159 = trapz(
        p159["x"].to_numpy(float),
        p159["m_intrinsic"].to_numpy(float),
    )

    kvals = swdf["K_hom"].tolist() + [K159]
    Kmin = float(np.min(kvals))
    Kmax = float(np.max(kvals))
    Kratio = Kmax/max(Kmin,1e-300)
    Kmean = float(np.mean(kvals))
    Kcv = float(np.std(kvals, ddof=1)/Kmean)

    # Fit normalized accumulated correction vs tau on 114/136 plus frozen159.
    # Read 159 scale from v195 summary if available adjacent to profile.
    refsum_path = Path(args.v195_profile).with_name(
        Path(args.v195_profile).name.replace("_PROFILE.csv", "_SUMMARY.json")
    )

    decay_fit = {}
    if refsum_path.exists():
        s159 = json.loads(refsum_path.read_text(encoding="utf-8"))
        t = swdf["tau_switch"].tolist() + [float(s159["tau_switch"])]
        r = swdf["I_over_gamma_geom_tau"].tolist() + [
            float(s159["I_over_gamma_geom_tau"])
        ]
        lt = np.log(np.asarray(t,float))
        lr = np.log(np.asarray(r,float))
        coef = np.polyfit(lt,lr,1)
        pred = np.polyval(coef,lt)
        r2 = 1-np.sum((lr-pred)**2)/np.sum((lr-lr.mean())**2)
        decay_fit = {
            "R_vs_tau_power": float(coef[0]),
            "R_vs_tau_log_R2": float(r2),
        }

    # Conservative verdict.
    all_critical_resolved = all(
        len(v) == 0 for v in unresolved_all.values()
    )
    stride2_ok = bool(
        np.all(swdf["K_stride2_relative_difference"].to_numpy(float) <= 0.05)
    )
    collapse_ok = bool(
        len(collapse)
        and np.all(
            np.abs(collapse["median_ratio_vs_159"].to_numpy(float)-1.0) <= 0.20
        )
    )

    if all_critical_resolved and stride2_ok and Kratio <= 1.10 and collapse_ok:
        verdict = "LATE_SWITCH_UNIVERSAL_HOMOGENIZED_PROFILE_STRONGLY_SUPPORTED"
    elif Kratio <= 1.20:
        verdict = "LATE_SWITCH_UNIVERSAL_K_SUPPORTED_PROFILE_PARTIAL"
    else:
        verdict = "LATE_SWITCH_UNIVERSALITY_UNRESOLVED"

    all_profiles = pd.concat(
        [
            d.assign(switch=sw)
            for sw, d in refined_profiles.items()
        ],
        ignore_index=True,
    )

    all_profiles.to_csv(args.prefix+"_PROFILES.csv", index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv", index=False)
    collapse.to_csv(args.prefix+"_COLLAPSE.csv", index=False)

    summary = {
        "version": 197,
        "switches": [114,136,159],
        "K_values": kvals,
        "K_mean": Kmean,
        "K_cv": Kcv,
        "K_min": Kmin,
        "K_max": Kmax,
        "K_max_over_min": Kratio,
        "critical_unresolved": unresolved_all,
        "collapse": collapse.to_dict(orient="records"),
        **decay_fit,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*188)
    for _,r in swdf.iterrows():
        print(
            f"switch {int(r['switch']):3d} "
            f"K={r['K_hom']:.8e} "
            f"K2diff={r['K_stride2_relative_difference']:.3e} "
            f"K4diff={r['K_stride4_relative_difference']:.3e} "
            f"I/(g*tau)={r['I_over_gamma_geom_tau']:.3e}"
        )
    print(f"switch 159 frozen K               : {K159:.8e}")
    print(f"K mean / CV                       : {Kmean:.8e} / {Kcv:.6e}")
    print(f"K min / max / ratio               : {Kmin:.8e} / {Kmax:.8e} / {Kratio:.6e}")
    print()
    for _,r in collapse.iterrows():
        print(
            f"profile {int(r['switch'])} vs 159: "
            f"median ratio={r['median_ratio_vs_159']:.6e} "
            f"q10/q90={r['q10_ratio_vs_159']:.6e}/{r['q90_ratio_vs_159']:.6e} "
            f"logRMSE={r['log_rmse_vs_159']:.6e}"
        )
    if decay_fit:
        print(
            f"R ~ tau^p fit                     : "
            f"p={decay_fit['R_vs_tau_power']:.6f} "
            f"log-R2={decay_fit['R_vs_tau_log_R2']:.6f}"
        )
    print(f"VERDICT                            : {verdict}")
    print("="*188)


if __name__ == "__main__":
    main()
