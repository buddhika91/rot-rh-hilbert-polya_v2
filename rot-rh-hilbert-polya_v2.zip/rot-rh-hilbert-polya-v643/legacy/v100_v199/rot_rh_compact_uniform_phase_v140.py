#!/usr/bin/env python3
"""
ROT-RH v140 — COMPACT-UNIFORM FINITE-PART PHASE CONVERGENCE AUDIT

Purpose
-------
Attack the analytic cutoff-removal lemma directly:

    F_L^ren(E) -> F_infinity^ren(E)

uniformly on compact E-intervals, together with control of F'_L.

This script is ZERO-BLIND:
  * no Xi
  * no zeta
  * no known zero ordinates

It builds only a few renormalized phases (default 128k,256k,512k),
samples them on a common adaptive E-grid, and measures

    D_F(L,2L)  = sup_E |F_{2L}(E)  - F_L(E)|
    D_F'(L,2L) = sup_E |F'_{2L}(E) - F'_L(E)|.

It also checks:
  * positivity/transversality of F'_L on the compact interval,
  * finite-difference consistency of F' against sampled F,
  * bandwise localization of the phase discrepancy,
  * a root-displacement bound D_F / min(F') when min(F') > 0,
  * contraction of the compact-uniform differences from one dyadic step
    to the next.

Why this matters
----------------
If one proves:
  (1) F_L -> F_infinity locally uniformly,
  (2) the limiting crossings are simple,
  (3) a uniform summable Weyl majorant for E_k(L)^(-2),

then fixed-k roots converge and dominated convergence gives

    ||H_L^(-2) - H^(-2)||_1 -> 0.

This script numerically audits (1) and the transversality needed for (2).

Outputs
-------
<prefix>_PAIR_SUMMARY.csv
<prefix>_L_SUMMARY.csv
<prefix>_BANDS.csv
<prefix>_GRID.csv
<prefix>_SAMPLES.npz
<prefix>_VERDICT.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


# ----------------------------------------------------------------------
# utilities
# ----------------------------------------------------------------------

def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def csv_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def vector_call(fn, x):
    """
    Try vectorized upstream evaluation first; if unsupported, fall back
    to scalar evaluation. Returns float ndarray of same shape as x.
    """
    x = np.asarray(x, dtype=float)
    try:
        y = np.asarray(fn(x), dtype=float)
        if y.shape == x.shape:
            return y
        if y.size == x.size:
            return y.reshape(x.shape)
    except Exception:
        pass

    out = np.empty_like(x, dtype=float)
    flat = x.ravel()
    oflat = out.ravel()
    for i, xx in enumerate(flat):
        yy = fn(float(xx))
        a = np.asarray(yy, dtype=float).reshape(-1)
        if len(a) == 0:
            raise RuntimeError("Upstream phase function returned empty output.")
        oflat[i] = float(a[0])
    return out


def safe_ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.nan


def quantile_abs(x, q):
    x = np.asarray(x, float)
    x = np.abs(x[np.isfinite(x)])
    return float(np.quantile(x, q)) if len(x) else np.nan


def fd_derivative(x, y):
    """
    Second-order-ish numpy gradient on a nonuniform grid.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 3:
        return np.full_like(y, np.nan)
    return np.gradient(y, x, edge_order=2)


# ----------------------------------------------------------------------
# sampling / adaptation
# ----------------------------------------------------------------------

def evaluate_all(phases, Ls, grid):
    F = {}
    Fp = {}
    for L in Ls:
        phase = phases[L]
        F[L] = vector_call(phase.F, grid)
        Fp[L] = vector_call(phase.Fprime, grid)
    return F, Fp


def interval_scores(grid, F, Fp, Ls):
    """
    Cheap refinement score using current endpoint data only.

    For each interval [x_i,x_{i+1}], score possible hidden discrepancy by
    combining:
      * endpoint magnitude of adjacent-L delta F,
      * derivative-based variation allowance h * |delta F'|,
      * endpoint variation of delta F',
      * local curvature proxy for each F_L.

    This does not prove a bound; it is an adaptive numerical locator.
    """
    nint = len(grid) - 1
    score = np.zeros(nint, dtype=float)

    for a, b in zip(Ls[:-1], Ls[1:]):
        dF = F[b] - F[a]
        dFp = Fp[b] - Fp[a]

        h = np.diff(grid)
        endpoint_mag = np.maximum(np.abs(dF[:-1]), np.abs(dF[1:]))
        deriv_allow = 0.5 * h * np.maximum(np.abs(dFp[:-1]), np.abs(dFp[1:]))
        deriv_jump = np.abs(dFp[1:] - dFp[:-1])

        # normalize derivative jump to phase scale over the interval
        score = np.maximum(score, endpoint_mag + deriv_allow + 0.25 * h * deriv_jump)

    # Also refine where any individual F' changes rapidly.
    h = np.diff(grid)
    for L in Ls:
        fpjump = np.abs(Fp[L][1:] - Fp[L][:-1])
        score = np.maximum(score, 0.10 * h * fpjump)

    return score


def adaptive_grid(phases, Ls, Emin, Emax, grid_points, rounds, refine_intervals):
    grid = np.linspace(Emin, Emax, grid_points, dtype=float)
    F, Fp = evaluate_all(phases, Ls, grid)

    for r in range(rounds):
        score = interval_scores(grid, F, Fp, Ls)
        if len(score) == 0:
            break

        m = min(refine_intervals, len(score))
        idx = np.argpartition(score, -m)[-m:]
        mids = 0.5 * (grid[idx] + grid[idx + 1])

        new_grid = np.unique(np.concatenate([grid, mids]))
        if len(new_grid) == len(grid):
            break

        grid = new_grid
        F, Fp = evaluate_all(phases, Ls, grid)

        print(
            f"[adaptive] round {r+1}/{rounds}: "
            f"grid points={len(grid)}, "
            f"refined intervals={m}"
        )

    return grid, F, Fp


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--L-list",
        default="128000,256000,512000",
        help="Increasing cutoff list; dyadic values recommended.",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--E-min", type=float, default=0.0)
    ap.add_argument("--E-max", type=float, default=120.0)
    ap.add_argument("--grid-points", type=int, default=257)
    ap.add_argument("--adaptive-rounds", type=int, default=4)
    ap.add_argument("--refine-intervals", type=int, default=32)

    ap.add_argument(
        "--bands",
        default="0,20,40,60,80,100,120",
        help="Compact-E band boundaries.",
    )

    ap.add_argument(
        "--phase-contraction-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--derivative-contraction-gate",
        type=float,
        default=1.00,
    )
    ap.add_argument(
        "--min-Fprime-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--fd-rel-rms-gate",
        type=float,
        default=0.02,
        help="Finite-difference F' consistency relative RMS gate.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_compact_uniform_phase_v140",
    )

    args = ap.parse_args()

    Ls = sorted(set(csv_ints(args.L_list)))
    if len(Ls) < 3:
        raise RuntimeError("Use at least three cutoffs to test contraction.")

    if args.E_max <= args.E_min:
        raise RuntimeError("Require E-max > E-min.")

    bands = csv_floats(args.bands)
    bands = sorted(set(x for x in bands if args.E_min <= x <= args.E_max))
    if not bands or bands[0] > args.E_min:
        bands = [args.E_min] + bands
    if bands[-1] < args.E_max:
        bands.append(args.E_max)

    print("=" * 126)
    print("ROT-RH v140 — COMPACT-UNIFORM FINITE-PART PHASE CONVERGENCE AUDIT")
    print("=" * 126)
    print("Xi / zeta / known zeros          : NONE")
    print(f"L list                            : {Ls}")
    print(f"compact E interval                : [{args.E_min}, {args.E_max}]")
    print(f"initial grid points               : {args.grid_points}")
    print(f"adaptive rounds                   : {args.adaptive_rounds}")
    print(f"refine intervals / round          : {args.refine_intervals}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 126)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warning_messages = {}

    for L in Ls:
        print(f"[L={L}] building RenormalizedPhase ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phase = v102.RenormalizedPhase.build(
                base,
                int(L),
                float(args.tail_factor),
                int(args.counter_q),
            )
        phases[L] = phase
        warning_messages[L] = [str(w.message) for w in wrn]

        if warning_messages[L]:
            print(f"[L={L}] build completed with {len(warning_messages[L])} warning(s)")
            for msg in warning_messages[L][:3]:
                print(f"           warning: {msg}")
        else:
            print(f"[L={L}] build completed with no captured warnings")

    print("[sampling] building common adaptive compact-E grid ...", flush=True)
    grid, F, Fp = adaptive_grid(
        phases=phases,
        Ls=Ls,
        Emin=args.E_min,
        Emax=args.E_max,
        grid_points=args.grid_points,
        rounds=args.adaptive_rounds,
        refine_intervals=args.refine_intervals,
    )

    # ------------------------------------------------------------------
    # Per-L diagnostics
    # ------------------------------------------------------------------
    L_rows = []

    for L in Ls:
        fd = fd_derivative(grid, F[L])
        diff = fd - Fp[L]

        scale = max(
            float(np.sqrt(np.mean(Fp[L] ** 2))),
            np.finfo(float).tiny,
        )
        fd_rel_rms = float(np.sqrt(np.mean(diff ** 2)) / scale)
        fd_rel_max = float(np.max(np.abs(diff)) / max(np.max(np.abs(Fp[L])), np.finfo(float).tiny))

        min_fp = float(np.min(Fp[L]))
        min_abs_fp = float(np.min(np.abs(Fp[L])))
        frac_nonpos = float(np.mean(Fp[L] <= 0.0))

        L_rows.append(
            dict(
                L=L,
                grid_points=len(grid),
                F_min=float(np.min(F[L])),
                F_max=float(np.max(F[L])),
                Fprime_min=min_fp,
                Fprime_min_abs=min_abs_fp,
                Fprime_max=float(np.max(Fp[L])),
                Fprime_nonpositive_fraction=frac_nonpos,
                fd_vs_Fprime_rel_rms=fd_rel_rms,
                fd_vs_Fprime_rel_max=fd_rel_max,
                warnings=len(warning_messages[L]),
            )
        )

    write_csv(Path(args.prefix + "_L_SUMMARY.csv"), L_rows)

    # ------------------------------------------------------------------
    # Adjacent cutoff pair norms
    # ------------------------------------------------------------------
    pair_rows = []

    for a, b in zip(Ls[:-1], Ls[1:]):
        dF = F[b] - F[a]
        dFp = Fp[b] - Fp[a]

        iF = int(np.argmax(np.abs(dF)))
        iFp = int(np.argmax(np.abs(dFp)))

        D_F = float(np.max(np.abs(dF)))
        D_Fp = float(np.max(np.abs(dFp)))

        # A simple uniform transversality floor for the pair.
        pair_min_fp = float(min(np.min(Fp[a]), np.min(Fp[b])))
        root_shift_bound = (
            D_F / pair_min_fp
            if pair_min_fp > 0 else np.inf
        )

        pair_rows.append(
            dict(
                L_a=a,
                L_b=b,
                ratio_L=float(b / a),
                sup_abs_delta_F=D_F,
                E_at_sup_delta_F=float(grid[iF]),
                q95_abs_delta_F=quantile_abs(dF, 0.95),
                rms_delta_F=float(np.sqrt(np.mean(dF ** 2))),
                sup_abs_delta_Fprime=D_Fp,
                E_at_sup_delta_Fprime=float(grid[iFp]),
                q95_abs_delta_Fprime=quantile_abs(dFp, 0.95),
                rms_delta_Fprime=float(np.sqrt(np.mean(dFp ** 2))),
                pair_min_Fprime=pair_min_fp,
                uniform_root_shift_bound=(
                    float(root_shift_bound)
                    if np.isfinite(root_shift_bound) else np.inf
                ),
            )
        )

    # Add contraction ratios relative to previous pair.
    for i, r in enumerate(pair_rows):
        if i == 0:
            r["phase_contraction_ratio"] = np.nan
            r["derivative_contraction_ratio"] = np.nan
            r["phase_local_p"] = np.nan
            r["derivative_local_p"] = np.nan
        else:
            prev = pair_rows[i - 1]
            rp = safe_ratio(r["sup_abs_delta_F"], prev["sup_abs_delta_F"])
            rd = safe_ratio(r["sup_abs_delta_Fprime"], prev["sup_abs_delta_Fprime"])

            r["phase_contraction_ratio"] = rp
            r["derivative_contraction_ratio"] = rd
            r["phase_local_p"] = (
                -math.log(rp, 2.0)
                if np.isfinite(rp) and rp > 0 else np.nan
            )
            r["derivative_local_p"] = (
                -math.log(rd, 2.0)
                if np.isfinite(rd) and rd > 0 else np.nan
            )

    write_csv(Path(args.prefix + "_PAIR_SUMMARY.csv"), pair_rows)

    # ------------------------------------------------------------------
    # Bandwise discrepancy localization
    # ------------------------------------------------------------------
    band_rows = []

    for a, b in zip(Ls[:-1], Ls[1:]):
        dF = F[b] - F[a]
        dFp = Fp[b] - Fp[a]

        for lo, hi in zip(bands[:-1], bands[1:]):
            if hi == bands[-1]:
                m = (grid >= lo) & (grid <= hi)
            else:
                m = (grid >= lo) & (grid < hi)

            if not np.any(m):
                continue

            band_rows.append(
                dict(
                    L_a=a,
                    L_b=b,
                    E_lo=lo,
                    E_hi=hi,
                    points=int(np.sum(m)),
                    sup_abs_delta_F=float(np.max(np.abs(dF[m]))),
                    rms_delta_F=float(np.sqrt(np.mean(dF[m] ** 2))),
                    sup_abs_delta_Fprime=float(np.max(np.abs(dFp[m]))),
                    rms_delta_Fprime=float(np.sqrt(np.mean(dFp[m] ** 2))),
                    min_Fprime=float(min(np.min(Fp[a][m]), np.min(Fp[b][m]))),
                )
            )

    write_csv(Path(args.prefix + "_BANDS.csv"), band_rows)

    # ------------------------------------------------------------------
    # Grid output
    # ------------------------------------------------------------------
    grid_rows = []
    for i, E in enumerate(grid):
        row = {"E": float(E)}
        for L in Ls:
            row[f"F_{L}"] = float(F[L][i])
            row[f"Fp_{L}"] = float(Fp[L][i])
        for a, b in zip(Ls[:-1], Ls[1:]):
            row[f"dF_{a}_{b}"] = float(F[b][i] - F[a][i])
            row[f"dFp_{a}_{b}"] = float(Fp[b][i] - Fp[a][i])
        grid_rows.append(row)

    write_csv(Path(args.prefix + "_GRID.csv"), grid_rows)

    np.savez_compressed(
        args.prefix + "_SAMPLES.npz",
        L=np.asarray(Ls, dtype=int),
        E=grid,
        F=np.vstack([F[L] for L in Ls]),
        Fprime=np.vstack([Fp[L] for L in Ls]),
    )

    # ------------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------------
    latest_pair = pair_rows[-1]
    phase_ratio = latest_pair["phase_contraction_ratio"]
    deriv_ratio = latest_pair["derivative_contraction_ratio"]

    phase_contracts = bool(
        np.isfinite(phase_ratio)
        and phase_ratio < args.phase_contraction_gate
    )
    deriv_contracts = bool(
        np.isfinite(deriv_ratio)
        and deriv_ratio < args.derivative_contraction_gate
    )

    min_fp_all = min(r["Fprime_min"] for r in L_rows)
    transversality_ok = bool(min_fp_all > args.min_Fprime_gate)

    fd_ok = bool(
        max(r["fd_vs_Fprime_rel_rms"] for r in L_rows)
        < args.fd_rel_rms_gate
    )

    if phase_contracts and transversality_ok and fd_ok:
        if deriv_contracts:
            verdict = "COMPACT_UNIFORM_PHASE_CAUCHY_EVIDENCE_STRONG"
        else:
            verdict = "PHASE_CONTRACTS_DERIVATIVE_CONVERGENCE_UNRESOLVED"
    elif phase_contracts:
        verdict = "PHASE_CONTRACTS_BUT_NUMERICAL_OR_TRANSVERSALITY_GATE_FAILS"
    else:
        verdict = "COMPACT_UNIFORM_PHASE_CONVERGENCE_UNRESOLVED"

    summary = dict(
        version=140,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        theorem_target=(
            "F_L^ren -> F_infinity^ren locally uniformly; "
            "then fixed-k roots converge at simple crossings."
        ),
        parameters=dict(
            L_list=Ls,
            E_min=args.E_min,
            E_max=args.E_max,
            grid_points_initial=args.grid_points,
            grid_points_final=len(grid),
            adaptive_rounds=args.adaptive_rounds,
            refine_intervals=args.refine_intervals,
            tail_factor=args.tail_factor,
            counter_q=args.counter_q,
        ),
        latest_pair=latest_pair,
        gates=dict(
            phase_contraction_gate=args.phase_contraction_gate,
            derivative_contraction_gate=args.derivative_contraction_gate,
            min_Fprime_gate=args.min_Fprime_gate,
            fd_rel_rms_gate=args.fd_rel_rms_gate,
            phase_contracts=phase_contracts,
            derivative_contracts=deriv_contracts,
            transversality_ok=transversality_ok,
            finite_difference_consistency_ok=fd_ok,
        ),
        min_Fprime_all_cutoffs=float(min_fp_all),
        warnings_by_L=warning_messages,
        verdict=verdict,
        proof_status=(
            "NUMERICAL COMPACT-UNIFORM AUDIT ONLY. "
            "A proof still requires an analytic uniform remainder bound "
            "for the finite-part phase and a uniform high-k domination theorem."
        ),
    )

    Path(args.prefix + "_VERDICT.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal report
    # ------------------------------------------------------------------
    print()
    print("Adjacent-cutoff compact-uniform norms")
    print("-" * 126)
    print(
        f"{'pair':>21} "
        f"{'||dF||inf':>14} "
        f"{'||dFprime||inf':>17} "
        f"{'phase ratio':>12} "
        f"{'dprime ratio':>13} "
        f"{'root bound':>12}"
    )

    for r in pair_rows:
        pair = f"{r['L_a']}->{r['L_b']}"
        print(
            f"{pair:>21} "
            f"{r['sup_abs_delta_F']:14.6e} "
            f"{r['sup_abs_delta_Fprime']:17.6e} "
            f"{r['phase_contraction_ratio']:12.6f} "
            f"{r['derivative_contraction_ratio']:13.6f} "
            f"{r['uniform_root_shift_bound']:12.6e}"
        )

    print()
    print("Per-cutoff transversality / derivative consistency")
    print("-" * 126)
    for r in L_rows:
        print(
            f"L={r['L']:>7d}  "
            f"min F'={r['Fprime_min']:.6e}  "
            f"nonpositive={100*r['Fprime_nonpositive_fraction']:.3f}%  "
            f"FD/F' rel RMS={r['fd_vs_Fprime_rel_rms']:.3e}  "
            f"warnings={r['warnings']}"
        )

    print()
    print("=" * 126)
    print(f"latest phase contraction ratio    : {phase_ratio:.9f}")
    print(f"latest derivative contraction     : {deriv_ratio:.9f}")
    print(f"minimum F' over all samples       : {min_fp_all:.9e}")
    print(f"phase contraction gate            : {phase_contracts}")
    print(f"derivative contraction gate       : {deriv_contracts}")
    print(f"transversality gate               : {transversality_ok}")
    print(f"FD derivative consistency gate    : {fd_ok}")
    print(f"VERDICT                           : {verdict}")
    print("=" * 126)


if __name__ == "__main__":
    main()
