#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v125 — Cross-Scale Partition-Robustness / Alignment Red-Team
===================================================================

PURPOSE
-------
v124 found that the exact Mangoldt adaptive-trapezoid kernel on fresh
k=1088..1407 cells has enormous cancellation BETWEEN dyadic arithmetic scales:

    total prime cumulative max / sum(band cumulative maxima) ~= 2.64e-3,

and similarly tiny cancellation ratios in the first spectral-frequency bins.

But a dyadic split is arbitrary. v125 checks whether this phenomenon survives
different logarithmic partitions of n and whether the actual cross-scale
alignment is special relative to controls.

PARTITIONS
----------
Let x = log_2 n. For width W and offset O, assign a term to

    band = floor((x-O)/W),

i.e. logarithmic bands
    O+bW <= log_2 n < O+(b+1)W.

Default schemes:
    W=0.5 : O=0.00,0.25
    W=1.0 : O=0.00,0.25,0.50,0.75
    W=2.0 : O=0.00,0.50,1.00,1.50
    W=4.0 : O=0.00,1.00,2.00,3.00

EXACT KERNEL
------------
For omega=log n and coefficient w_n,

    q_{k,n}
      = (2 w_n/(pi omega))
        sin(omega m_k)
        [delta cos(delta)-sin(delta)],

    delta = omega h_k/2.

The kernel is reconstructed exactly against v123 q_prime.

CONTROLS
--------
For each partition:
  * random +/- sign flips of entire arithmetic-band sequences;
  * random independent circular shifts of each band sequence.

These preserve the internal shape/energy of each band while destroying the
observed cross-band alignment.

This is a post-hoc mechanism red-team, not a preregistered RH test.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v125"
BUILD = "2026-08-18-cross-scale-partition-robustness-alignment-v125"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p)-1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def parse_schemes(text):
    """
    Format:
        width:offset,offset; width:offset,...
    """
    schemes = []
    for chunk in str(text).split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        left, right = chunk.split(":", 1)
        width = float(left.strip())
        offsets = [float(x.strip()) for x in right.split(",") if x.strip()]
        for off in offsets:
            schemes.append((width, off))
    return schemes


def scheme_key(width, offset):
    return f"W{width:g}_O{offset:g}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v123-prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--k-start", type=int, default=1088)
    ap.add_argument("--k-end", type=int, default=1407)
    ap.add_argument("--term-chunk", type=int, default=2048)
    ap.add_argument("--controls", type=int, default=5000)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260818)
    ap.add_argument(
        "--schemes",
        default=(
            "0.5:0,0.25;"
            "1:0,0.25,0.5,0.75;"
            "2:0,0.5,1,1.5;"
            "4:0,1,2,3"
        ),
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_cross_scale_partition_robustness_v125",
    )
    args = ap.parse_args()

    schemes = parse_schemes(args.schemes)
    if not schemes:
        raise ValueError("No partition schemes.")

    cells_path = Path(
        str(Path(args.v123_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rows = sorted(
        [
            r for r in raw
            if args.k_start <= int(float(r["k"])) <= args.k_end
        ],
        key=lambda r: int(float(r["k"])),
    )
    if len(rows) != args.k_end - args.k_start + 1:
        raise RuntimeError("Requested v123 cell range incomplete.")

    lo = np.asarray([float(r["lo"]) for r in rows], float)
    hi = np.asarray([float(r["hi"]) for r in rows], float)
    h = hi-lo
    mid = 0.5*(lo+hi)
    qref = np.asarray([float(r["q_prime"]) for r in rows], float)

    print("="*164)
    print("ROT-RH v125 — CROSS-SCALE PARTITION-ROBUSTNESS / ALIGNMENT RED-TEAM")
    print("="*164)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("schemes                         :", len(schemes))
    print("controls/scheme                 :", args.controls)
    print("low-frequency bins              :", args.lowfreq_bins)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("="*164)

    print("[1] Build finite-L arithmetic coefficients", flush=True)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    w = np.asarray(phase.phase_w, float)
    omega = np.asarray(phase.logs, float)
    xlog2 = omega / math.log(2.0)

    print("  arithmetic terms              :", len(omega))

    # Pre-allocate per-scheme maps keyed by integer band index.
    group_maps = []
    term_group_ids = []
    for width, offset in schemes:
        gid = np.floor((xlog2-offset)/width + 1e-12).astype(int)
        ids = sorted(np.unique(gid).tolist())
        group_maps.append({g: np.zeros(len(rows), float) for g in ids})
        term_group_ids.append(gid)

    print("[2] Exact kernel accumulation for all partition schemes", flush=True)
    nterm = len(omega)
    for s in range(0, nterm, int(args.term_chunk)):
        e = min(nterm, s+int(args.term_chunk))
        om = omega[s:e]
        ww = w[s:e]

        delta = 0.5*h[:, None]*om[None, :]
        ph = mid[:, None]*om[None, :]
        kernel = (
            (2.0/math.pi)
            * np.sin(ph)
            * (delta*np.cos(delta)-np.sin(delta))
        )
        contrib = kernel*(ww/om)[None, :]

        for si in range(len(schemes)):
            gids = term_group_ids[si][s:e]
            gm = group_maps[si]
            for g in np.unique(gids):
                gm[int(g)] += np.sum(contrib[:, gids == g], axis=1)

        if e == nterm or e % (8*int(args.term_chunk)) == 0:
            print(f"  terms {e}/{nterm}", flush=True)

    # Verify every partition reconstructs the same qref.
    print("[3] Reconstruction checks")
    recon_rows = []
    for si, (width, offset) in enumerate(schemes):
        gm = group_maps[si]
        ids = sorted(gm)
        recon = np.sum(np.vstack([gm[g] for g in ids]), axis=0)
        rel = float(
            np.linalg.norm(recon-qref)/max(np.linalg.norm(qref), EPS)
        )
        mx = float(np.max(np.abs(recon-qref)))
        recon_rows.append({
            "scheme": scheme_key(width, offset),
            "width": width,
            "offset": offset,
            "group_count": len(ids),
            "reconstruction_rel_l2": rel,
            "reconstruction_max_abs": mx,
        })
        print(
            f"  {scheme_key(width,offset):<12s}: "
            f"groups={len(ids):<3d} relL2={rel:.3e} max={mx:.3e}"
        )

    rng = np.random.default_rng(args.seed)
    total_cmax = cumulative_max(qref)
    total_lowf = lowfreq_fraction(qref, args.lowfreq_bins)

    print("[4] Partition robustness + alignment controls")
    summary_rows = []
    group_rows = []
    freq_rows = []

    for si, (width, offset) in enumerate(schemes):
        name = scheme_key(width, offset)
        gm = group_maps[si]
        ids = sorted(gm)
        X = np.vstack([gm[g] for g in ids])  # groups x cells

        band_cmax = np.asarray([cumulative_max(x) for x in X], float)
        sum_cmax = float(np.sum(band_cmax))
        cross_ratio = total_cmax/max(sum_cmax, EPS)

        # Spectral-frequency cancellation ratio.
        F = np.fft.rfft(X - np.mean(X, axis=1, keepdims=True), axis=1)
        Ft = np.fft.rfft(qref - np.mean(qref))
        fbmax = min(args.lowfreq_bins, len(Ft)-1)
        freq_cancel = []
        for fb in range(1, fbmax+1):
            den = float(np.sum(np.abs(F[:, fb])))
            cr = float(abs(Ft[fb])/max(den, EPS))
            freq_cancel.append(cr)
            freq_rows.append({
                "scheme": name,
                "width": width,
                "offset": offset,
                "frequency_bin": fb,
                "cross_group_cancellation_ratio": cr,
            })

        # Random sign controls preserve each group's entire cell sequence.
        sign_c = np.empty(args.controls, float)
        sign_l = np.empty(args.controls, float)
        for t in range(args.controls):
            sgn = rng.choice(np.array([-1.0, 1.0]), size=len(ids))
            y = np.sum(X*sgn[:, None], axis=0)
            sign_c[t] = cumulative_max(y)
            sign_l[t] = lowfreq_fraction(y, args.lowfreq_bins)

        # Random independent circular shifts preserve each group's autocorrelation.
        shift_c = np.empty(args.controls, float)
        shift_l = np.empty(args.controls, float)
        ncell = X.shape[1]
        for t in range(args.controls):
            y = np.zeros(ncell, float)
            shifts = rng.integers(0, ncell, size=len(ids))
            for gi, sh in enumerate(shifts):
                y += np.roll(X[gi], int(sh))
            shift_c[t] = cumulative_max(y)
            shift_l[t] = lowfreq_fraction(y, args.lowfreq_bins)

        # Adjacent-pair cancellation diagnostic in arithmetic order.
        adjacent_ratios = []
        for gi in range(len(ids)-1):
            a = X[gi]
            b = X[gi+1]
            den = cumulative_max(a)+cumulative_max(b)
            adjacent_ratios.append(
                cumulative_max(a+b)/max(den, EPS)
            )

        # Leave-one-group-out amplification.
        loo_ratios = []
        for gi, g in enumerate(ids):
            loo = qref - X[gi]
            loo_ratio = cumulative_max(loo)/max(total_cmax, EPS)
            loo_ratios.append(loo_ratio)

            lower = offset + g*width
            upper = lower + width
            group_rows.append({
                "scheme": name,
                "width": width,
                "offset": offset,
                "group_id": int(g),
                "log2n_lo": lower,
                "log2n_hi": upper,
                "cell_rms": float(np.sqrt(np.mean(X[gi]**2))),
                "cumulative_max": float(band_cmax[gi]),
                "corr_with_total": float(np.corrcoef(X[gi], qref)[0,1]),
                "leave_one_out_over_total_cmax": loo_ratio,
            })

        row = {
            "scheme": name,
            "width": width,
            "offset": offset,
            "group_count": len(ids),
            "total_cumulative_max": total_cmax,
            "sum_group_cumulative_max": sum_cmax,
            "cross_group_cumulative_ratio": cross_ratio,
            "lowfreq_cross_ratio_mean": float(np.mean(freq_cancel)),
            "lowfreq_cross_ratio_max": float(np.max(freq_cancel)),
            "lowfreq_cross_ratio_min": float(np.min(freq_cancel)),
            "sign_control_cumulative_percentile":
                percentile_le(sign_c, total_cmax),
            "sign_control_lowfreq_percentile":
                percentile_le(sign_l, total_lowf),
            "shift_control_cumulative_percentile":
                percentile_le(shift_c, total_cmax),
            "shift_control_lowfreq_percentile":
                percentile_le(shift_l, total_lowf),
            "adjacent_pair_ratio_median":
                float(np.median(adjacent_ratios)) if adjacent_ratios else float("nan"),
            "adjacent_pair_ratio_min":
                float(np.min(adjacent_ratios)) if adjacent_ratios else float("nan"),
            "max_leave_one_out_amplification":
                float(np.max(loo_ratios)),
            "median_leave_one_out_amplification":
                float(np.median(loo_ratios)),
        }
        summary_rows.append(row)

        print(
            f"  {name:<12s}: "
            f"groups={len(ids):<3d} "
            f"cross={cross_ratio:.3e} "
            f"lowFmax={row['lowfreq_cross_ratio_max']:.3e} "
            f"signP={100*row['sign_control_cumulative_percentile']:.3f}% "
            f"shiftP={100*row['shift_control_cumulative_percentile']:.3f}% "
            f"adjMed={row['adjacent_pair_ratio_median']:.3f}"
        )

    max_cross = max(r["cross_group_cumulative_ratio"] for r in summary_rows)
    max_lowf = max(r["lowfreq_cross_ratio_max"] for r in summary_rows)
    max_sign_p = max(r["sign_control_cumulative_percentile"] for r in summary_rows)
    max_shift_p = max(r["shift_control_cumulative_percentile"] for r in summary_rows)

    # Robustness classification.
    if (
        max_cross <= 0.02
        and max_lowf <= 0.02
        and max_sign_p <= 0.05
        and max_shift_p <= 0.05
    ):
        mechanism = (
            "PARTITION_ROBUST_SPECIFIC_CROSS_SCALE_MANGOLDT_ALIGNMENT"
        )
    elif max_cross <= 0.05 and max_lowf <= 0.05:
        mechanism = (
            "CROSS_SCALE_CANCELLATION_ROBUST_BUT_ALIGNMENT_CONTROLS_MIXED"
        )
    else:
        mechanism = (
            "DYADIC_RESULT_IS_PARTITION_SENSITIVE__DO_NOT_ELEVATE_TO_THEOREM"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_SUMMARY.csv"), summary_rows)
    write_csv(Path(str(prefix) + "_GROUPS.csv"), group_rows)
    write_csv(Path(str(prefix) + "_FREQUENCIES.csv"), freq_rows)
    write_csv(Path(str(prefix) + "_RECONSTRUCTION.csv"), recon_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V125_PARTITION_ROBUSTNESS_AUDIT_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "scheme_count": len(schemes),
        "total_prime_cumulative_max": total_cmax,
        "max_cross_group_cumulative_ratio_across_schemes": max_cross,
        "max_lowfreq_cross_group_ratio_across_schemes": max_lowf,
        "max_sign_control_cumulative_percentile": max_sign_p,
        "max_shift_control_cumulative_percentile": max_shift_p,
        "summary": summary_rows,
        "interpretation": (
            "If cross-scale cancellation remains at the percent level or below "
            "for shifted/finer/coarser logarithmic partitions and the actual "
            "alignment beats sign/shift controls, the mechanism is not an "
            "artifact of the dyadic split. The next analytic route should use "
            "summation/Abel transforms that preserve the full Mangoldt scale "
            "coupling rather than independent dyadic absolute bounds."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "="*164)
    print("FINAL v125 VERDICT")
    print("="*164)
    print("verdict                         : PASS_V125_PARTITION_ROBUSTNESS_AUDIT_COMPLETE")
    print("mechanism                       :", mechanism)
    print("max cross-group ratio           :", f"{max_cross:.12e}")
    print("max low-frequency ratio         :", f"{max_lowf:.12e}")
    print("max sign-control cum percentile :", f"{100*max_sign_p:.6f}%")
    print("max shift-control cum percentile:", f"{100*max_shift_p:.6f}%")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("="*164)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
