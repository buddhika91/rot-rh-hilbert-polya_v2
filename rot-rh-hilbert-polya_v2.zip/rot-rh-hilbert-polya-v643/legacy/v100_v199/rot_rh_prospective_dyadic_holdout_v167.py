#!/usr/bin/env python3
"""
ROT-RH v167 — PROSPECTIVE DYADIC ENDPOINT HOLDOUT AUDIT

Purpose
-------
v166 found that the factor-2 endpoint increments

    D_j = ||lambda(2 L_j) - lambda(L_j)||_1

on the dyadic subsequence have a positive fitted decay exponent and high R^2,
but only four disjoint blocks were available.

v167 performs one prospective test:
  * fit the existing dyadic blocks only;
  * predict the NEXT dyadic block;
  * compute one new cutoff at 16,384,000;
  * test the genuinely new endpoint increment
        8,192,000 -> 16,384,000.

This is the cleanest numerical counterpart of a candidate Lemma-1 theorem on
the dyadic subsequence.

Default exact dyadic nodes
--------------------------
      512,000
    1,024,000
    2,048,000
    4,096,000
    8,192,000
   16,384,000   <-- NEW prospective holdout

The existing v165 trajectory already contains the first five nodes.  Only the
last phase/root continuation is new.

For the finite block N define

    lambda_k(L) = E_k(L)^(-2),

    D_j = sum_{k<=N}
            |lambda_k(2L_j)-lambda_k(L_j)|.

The prospective fit uses only the first four D_j values:

    D_j ~ C L_j^(-alpha),

and predicts the held-out fifth.

Also reported:
  * root residual / transversality on the new continuation;
  * held-out actual / predicted / safety-bound ratio;
  * updated all-five power fit;
  * modal dyadic increment contraction fractions;
  * dyadic tail envelopes over the finite observed sequence.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_ROOTS.npz
<prefix>_DYADIC.csv
<prefix>_MODES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
except Exception as exc:
    raise RuntimeError("scipy.optimize.brentq is required") from exc


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)
    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass
    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def build_phase(v102, base, L, tail_factor, counter_q):
    with warnings.catch_warnings(record=True) as wrn:
        warnings.simplefilter("always")
        ph = v102.RenormalizedPhase.build(
            base,
            int(L),
            float(tail_factor),
            int(counter_q),
        )
    return ph, [str(w.message) for w in wrn]


def refine_root(
    phase,
    target,
    x0,
    newton_iters,
    tol,
    max_step,
    bracket_initial,
    bracket_max,
):
    x = float(x0)

    for _ in range(newton_iters):
        f = scalar_call(phase.F, x) - target
        if abs(f) <= tol:
            return x, abs(f), "newton"

        fp = scalar_call(phase.Fprime, x)
        if (not np.isfinite(fp)) or abs(fp) < 1e-12:
            break

        step = float(np.clip(-f/fp, -max_step, max_step))
        xn = x + step
        if not np.isfinite(xn) or xn <= 0:
            break
        x = xn

    def ff(xx):
        return scalar_call(phase.F, xx) - target

    radius = bracket_initial
    while radius <= bracket_max:
        a = max(1e-8, x0-radius)
        b = x0+radius
        fa = ff(a)
        fb = ff(b)

        if np.isfinite(fa) and np.isfinite(fb) and fa*fb <= 0:
            root = float(brentq(
                ff, a, b,
                xtol=tol,
                rtol=1e-13,
                maxiter=200,
            ))
            return root, abs(ff(root)), "brent"

        radius *= 1.6

    return x, abs(ff(x)), "failed"


def segment_min_derivative(phase, x1, x2, samples):
    xs = np.linspace(float(x1), float(x2), samples)
    vals = np.abs(vector_call(phase.Fprime, xs))
    return float(np.min(vals))


def fit_power(L, y):
    L = np.asarray(L, dtype=float)
    y = np.asarray(y, dtype=float)

    mask = (L > 0) & (y > 0) & np.isfinite(y)
    X = np.log(L[mask])
    Y = np.log(y[mask])

    if len(X) < 2:
        return np.nan, np.nan, np.nan

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    logC = float(coef[0])
    alpha = float(-coef[1])

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, math.exp(logC), r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v165-roots-npz",
        default="rot_rh_two_shell_modal_envelope_v165_ROOTS.npz",
    )
    ap.add_argument(
        "--new-cutoff",
        type=int,
        default=16384000,
    )
    ap.add_argument(
        "--dyadic-cutoffs",
        default="512000,1024000,2048000,4096000,8192000,16384000",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--root-tol", type=float, default=1e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument("--bracket-initial", type=float, default=0.05)
    ap.add_argument("--bracket-max", type=float, default=1.0)
    ap.add_argument("--segment-samples", type=int, default=17)

    ap.add_argument("--root-residual-gate", type=float, default=1e-8)
    ap.add_argument("--transversality-gate", type=float, default=0.05)

    ap.add_argument(
        "--prediction-safety-factor",
        type=float,
        default=1.10,
    )
    ap.add_argument(
        "--heldout-over-bound-gate",
        type=float,
        default=1.0,
    )
    ap.add_argument(
        "--minimum-training-alpha",
        type=float,
        default=0.02,
    )
    ap.add_argument(
        "--minimum-training-r2",
        type=float,
        default=0.85,
    )
    ap.add_argument(
        "--minimum-modal-heldout-contraction-fraction",
        type=float,
        default=0.50,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_prospective_dyadic_holdout_v167",
    )

    args = ap.parse_args()

    dyadic = csv_ints(args.dyadic_cutoffs)
    if len(dyadic) != 6:
        raise RuntimeError(
            "Default theorem audit expects six exact dyadic nodes."
        )
    if any(dyadic[i+1] != 2*dyadic[i] for i in range(len(dyadic)-1)):
        raise RuntimeError("--dyadic-cutoffs must be exact factor-2 nodes.")
    if dyadic[-1] != args.new_cutoff:
        raise RuntimeError(
            "Final dyadic node must equal --new-cutoff."
        )

    z = np.load(args.v165_roots_npz)
    old_L = np.asarray(z["L"], dtype=int)
    old_roots = np.asarray(z["roots"], dtype=float)

    n = min(args.modes, old_roots.shape[1])
    old_roots = old_roots[:, :n]

    # Verify all training dyadic nodes exist.
    root_map = {}
    for L in dyadic[:-1]:
        hit = np.where(old_L == L)[0]
        if not len(hit):
            raise RuntimeError(
                f"Training dyadic node L={L} missing from v165 roots."
            )
        root_map[L] = old_roots[int(hit[0])].copy()

    if args.new_cutoff <= int(old_L[-1]):
        raise RuntimeError(
            f"New cutoff {args.new_cutoff} must exceed v165 endpoint {old_L[-1]}."
        )

    print("=" * 152)
    print("ROT-RH v167 — PROSPECTIVE DYADIC ENDPOINT HOLDOUT AUDIT")
    print("=" * 152)
    print("Xi / zeta / known zeros          : NONE")
    print(f"existing endpoint                 : {int(old_L[-1])}")
    print(f"new prospective cutoff            : {args.new_cutoff}")
    print(f"dyadic nodes                      : {dyadic}")
    print(f"modes                             : 1..{n}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 152)

    # --------------------------------------------------------------
    # Fit TRAINING dyadic endpoint increments BEFORE computing holdout.
    # --------------------------------------------------------------
    train_left = []
    train_D = []
    train_modal = []

    for L, M in zip(dyadic[:-2], dyadic[1:-1]):
        lamL = root_map[L]**(-2)
        lamM = root_map[M]**(-2)
        d = lamM-lamL

        train_left.append(L)
        train_D.append(float(np.sum(np.abs(d))))
        train_modal.append(np.abs(d))

    train_left = np.asarray(train_left, dtype=float)
    train_D = np.asarray(train_D, dtype=float)
    train_modal = np.vstack(train_modal)

    alpha_train, C_train, r2_train = fit_power(
        train_left, train_D
    )

    holdout_L = dyadic[-2]
    holdout_M = dyadic[-1]
    predicted = C_train*(holdout_L**(-alpha_train))
    safe_bound = args.prediction_safety_factor*predicted

    print()
    print("[prospective fit — frozen before holdout]")
    print(f"training D                       : {train_D.tolist()}")
    print(f"training alpha                   : {alpha_train:.9f}")
    print(f"training R2                      : {r2_train:.6f}")
    print(f"predicted D({holdout_L}->{holdout_M}) : {predicted:.6e}")
    print(f"safety bound                     : {safe_bound:.6e}")

    # --------------------------------------------------------------
    # One new phase build and continuation from current endpoint.
    # --------------------------------------------------------------
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print()
    print(
        f"[track {int(old_L[-1])}->{args.new_cutoff}] "
        f"continuing {n} roots ...",
        flush=True,
    )

    ph, wrn = build_phase(
        v102, base,
        args.new_cutoff,
        args.tail_factor,
        args.counter_q,
    )
    if wrn:
        print(f"[L={args.new_cutoff}] {len(wrn)} warning(s)")
        for msg in wrn[:2]:
            print(f"         warning: {msg}")

    targets = np.arange(1,n+1,dtype=float)-0.5
    prev_roots = old_roots[-1].copy()

    new_roots = np.empty(n,dtype=float)
    residuals = np.empty(n,dtype=float)
    methods = []

    for j in range(n):
        root,res,method = refine_root(
            ph,
            targets[j],
            prev_roots[j],
            args.newton_iters,
            args.root_tol,
            args.max_newton_step,
            args.bracket_initial,
            args.bracket_max,
        )
        new_roots[j] = root
        residuals[j] = res
        methods.append(method)

    mins = np.array([
        segment_min_derivative(
            ph,
            prev_roots[j],
            new_roots[j],
            args.segment_samples,
        )
        for j in range(n)
    ])

    print(
        f"          max residual={np.max(residuals):.3e}  "
        f"min|F_E|={np.min(mins):.6f}  "
        f"Newton={sum(m=='newton' for m in methods)}/{n}  "
        f"Brent={sum(m=='brent' for m in methods)}/{n}  "
        f"failed={sum(m=='failed' for m in methods)}"
    )

    root_map[args.new_cutoff] = new_roots.copy()

    # --------------------------------------------------------------
    # Evaluate heldout dyadic increment.
    # --------------------------------------------------------------
    lamL = root_map[holdout_L]**(-2)
    lamM = root_map[holdout_M]**(-2)
    d_hold = lamM-lamL
    abs_hold = np.abs(d_hold)

    actual = float(np.sum(abs_hold))
    actual_over_prediction = actual/max(predicted,1e-300)
    actual_over_bound = actual/max(safe_bound,1e-300)

    last_train_modal = train_modal[-1]
    modal_contract_fraction = float(
        np.mean(abs_hold < last_train_modal)
    )

    # Full five-block updated fit.
    full_left = np.concatenate([train_left,[holdout_L]])
    full_D = np.concatenate([train_D,[actual]])

    alpha_full,C_full,r2_full = fit_power(full_left,full_D)

    # Ratios.
    ratios = full_D[1:]/full_D[:-1]
    latest_ratio = float(ratios[-1])

    # Tail max envelope of the dyadic increments.
    tail_rows = []
    for j in range(len(full_D)):
        tail_max = float(np.max(full_D[j:]))
        if j == 0:
            ratio = np.nan
        else:
            ratio = tail_max/max(tail_rows[-1]["tail_max"],1e-300)

        tail_rows.append(dict(
            starting_block=j+1,
            L0=int(full_left[j]),
            blocks_remaining=int(len(full_D)-j),
            tail_max=tail_max,
            tail_max_ratio=ratio,
        ))

    # --------------------------------------------------------------
    # modewise dyadic data
    # --------------------------------------------------------------
    mode_rows = []

    all_modal = np.vstack([train_modal,abs_hold])

    for k in range(n):
        vals = all_modal[:,k]

        alpha_k,_,r2_k = fit_power(full_left,vals)
        latest_k_ratio = float(
            vals[-1]/max(vals[-2],1e-300)
        )

        mode_rows.append(dict(
            k=k+1,
            first_dyadic_increment=float(vals[0]),
            latest_dyadic_increment=float(vals[-1]),
            latest_over_first=float(
                vals[-1]/max(vals[0],1e-300)
            ),
            heldout_over_previous=latest_k_ratio,
            heldout_contracts=bool(vals[-1] < vals[-2]),
            power_alpha=alpha_k,
            power_R2=r2_k,
        ))

    modes_df = pd.DataFrame(mode_rows)

    positive_modal_alpha_fraction = float(
        np.mean(modes_df["power_alpha"].to_numpy(dtype=float)>0)
    )

    residual_ok = bool(np.max(residuals) <= args.root_residual_gate)
    transverse_ok = bool(np.min(mins) >= args.transversality_gate)

    training_ok = bool(
        alpha_train > args.minimum_training_alpha
        and r2_train >= args.minimum_training_r2
    )

    holdout_ok = bool(
        actual_over_bound <= args.heldout_over_bound_gate
    )

    modal_ok = bool(
        modal_contract_fraction
        >= args.minimum_modal_heldout_contraction_fraction
    )

    if residual_ok and transverse_ok and training_ok and holdout_ok and modal_ok:
        verdict = "PROSPECTIVE_DYADIC_ENDPOINT_DECAY_STRONGLY_SUPPORTED"
    elif residual_ok and transverse_ok and holdout_ok:
        verdict = "DYADIC_HOLDOUT_PASSES_MODEWISE_MIXED"
    else:
        verdict = "DYADIC_ENDPOINT_DECAY_UNRESOLVED"

    # --------------------------------------------------------------
    # save
    # --------------------------------------------------------------
    all_L = np.concatenate([old_L,[args.new_cutoff]])
    all_roots = np.vstack([old_roots,new_roots])

    np.savez_compressed(
        args.prefix+"_ROOTS.npz",
        L=all_L,
        roots=all_roots,
        targets=targets,
    )

    dyadic_rows = []
    for j,(L,M,D) in enumerate(zip(
        dyadic[:-1],dyadic[1:],full_D
    )):
        dyadic_rows.append(dict(
            block=j+1,
            L=L,
            M=M,
            D_l1=float(D),
            ratio_vs_previous=(
                np.nan if j==0
                else float(D/full_D[j-1])
            ),
            heldout=bool(j==len(full_D)-1),
        ))

    pd.DataFrame(dyadic_rows).to_csv(
        args.prefix+"_DYADIC.csv",index=False
    )
    modes_df.to_csv(
        args.prefix+"_MODES.csv",index=False
    )

    summary = dict(
        version=167,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        dyadic_nodes=dyadic,
        modes=n,
        training=dict(
            D=train_D.tolist(),
            alpha=alpha_train,
            R2=r2_train,
            C=C_train,
        ),
        prospective_holdout=dict(
            L=holdout_L,
            M=holdout_M,
            predicted=predicted,
            safety_factor=args.prediction_safety_factor,
            safety_bound=safe_bound,
            actual=actual,
            actual_over_prediction=actual_over_prediction,
            actual_over_bound=actual_over_bound,
            latest_ratio=latest_ratio,
            modal_contraction_fraction=modal_contract_fraction,
        ),
        updated_fit=dict(
            alpha=alpha_full,
            R2=r2_full,
            C=C_full,
            positive_modal_alpha_fraction=positive_modal_alpha_fraction,
        ),
        dyadic_tail_envelopes=tail_rows,
        root_residual_pass=residual_ok,
        transversality_pass=transverse_ok,
        training_model_pass=training_ok,
        holdout_pass=holdout_ok,
        modal_holdout_pass=modal_ok,
        verdict=verdict,
        theorem_target=(
            "Prove for fixed N on the dyadic sequence that "
            "||lambda(2L)-lambda(L)||_1 <= omega_N(L), "
            "with enough decay/telescoping control to make lambda(2^j L0) "
            "Cauchy. Then separately control intermediate cutoffs."
        ),
    )

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o,np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # terminal
    # --------------------------------------------------------------
    print()
    print("Dyadic endpoint increments")
    print("-"*152)
    print(
        f"{'block':>6} {'pair':>23} {'D_l1':>14} "
        f"{'ratio':>10} {'heldout':>9}"
    )
    for r in dyadic_rows:
        print(
            f"{r['block']:6d} "
            f"{r['L']:>10d}->{r['M']:<10d} "
            f"{r['D_l1']:14.6e} "
            f"{r['ratio_vs_previous']:10.6f} "
            f"{str(r['heldout']):>9}"
        )

    print()
    print("Prospective holdout")
    print("-"*152)
    print(f"training alpha                    : {alpha_train:.9f}")
    print(f"training R2                       : {r2_train:.6f}")
    print(f"predicted heldout D               : {predicted:.6e}")
    print(f"safety bound                      : {safe_bound:.6e}")
    print(f"actual heldout D                  : {actual:.6e}")
    print(f"actual / prediction               : {actual_over_prediction:.6f}")
    print(f"actual / safety bound             : {actual_over_bound:.6f}")
    print(f"heldout / previous dyadic D       : {latest_ratio:.6f}")
    print(f"modal heldout contraction fraction: {modal_contract_fraction:.6f}")

    print()
    print("Worst held-out modal ratios")
    print("-"*152)
    worst = modes_df.sort_values(
        "heldout_over_previous",ascending=False
    ).head(min(16,n))
    print(
        f"{'k':>4} {'previous':>14} {'heldout':>14} "
        f"{'ratio':>10} {'alpha':>10} {'R2':>8}"
    )

    for _,r in worst.iterrows():
        k=int(r["k"])
        prev=float(all_modal[-2,k-1])
        cur=float(all_modal[-1,k-1])
        print(
            f"{k:4d} "
            f"{prev:14.6e} "
            f"{cur:14.6e} "
            f"{r['heldout_over_previous']:10.6f} "
            f"{r['power_alpha']:10.6f} "
            f"{r['power_R2']:8.4f}"
        )

    print()
    print("="*152)
    print(f"updated dyadic alpha              : {alpha_full:.9f}")
    print(f"updated dyadic R2                 : {r2_full:.6f}")
    print(f"positive modal-alpha fraction     : {positive_modal_alpha_fraction:.6f}")
    print(f"root residual pass                : {residual_ok}")
    print(f"transversality pass               : {transverse_ok}")
    print(f"training model pass               : {training_ok}")
    print(f"prospective holdout pass          : {holdout_ok}")
    print(f"modal holdout pass                : {modal_ok}")
    print(f"VERDICT                           : {verdict}")
    print("="*152)
    print("PROOF DECISION:")
    print("  STRONG PASS -> stop extending cutoffs for Lemma 1 and formulate")
    print("                 a dyadic endpoint estimate analytically.")
    print("  MIXED       -> aggregate dyadic convergence remains plausible, but")
    print("                 mode micromotion needs to be handled in the proof.")
    print("  UNRESOLVED  -> the dyadic endpoint hypothesis itself needs revision.")


if __name__ == "__main__":
    main()
