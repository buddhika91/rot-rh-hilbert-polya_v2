#!/usr/bin/env python3
"""
ROT-RH v132.1 — FAST DEPTH-STABILITY / CUTOFF-DECAY POSTPROCESSOR

Reads the ROOTS.npz produced by v132. NO root solving, NO prime sums,
NO Xi, NO zeta, NO known zero data.

Main question:
Does the fitted cutoff-decay exponent of

    ||K_Lb - K_La||_{1,N}
      = sum_{k<=N} |E_k(L_b)^(-2) - E_k(L_a)^(-2)|

stabilize as N increases?

This separates two questions that v132 intentionally conflated:
  A) Is there robust finite-depth evidence of cutoff decay?  (testable now)
  B) Is the k->infinity tail rigorously certified?           (still open)

A positive, depth-stable exponent is strong numerical evidence for A,
but is NOT a proof of B.

Outputs:
  <prefix>_INTERVAL_DEPTH.csv
  <prefix>_BLOCK_DEPTH.csv
  <prefix>_DEPTH_FITS.csv
  <prefix>_VERDICT.json
"""

from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def write_csv(path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def linfit(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    x, y = x[m], y[m]
    if len(x) < 3 or np.ptp(x) == 0:
        return dict(slope=np.nan, intercept=np.nan, r2=np.nan)
    X = np.column_stack([np.ones(len(x)), x])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    yh = X @ b
    sse = float(np.sum((y-yh)**2))
    sst = float(np.sum((y-y.mean())**2))
    r2 = 1.0 - sse/sst if sst > 0 else 1.0
    return dict(slope=float(b[1]), intercept=float(b[0]), r2=float(r2))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz"
    )
    ap.add_argument(
        "--depths",
        default="128,256,512,768,1024,1408"
    )
    ap.add_argument(
        "--fit-last-blocks",
        type=int,
        default=3,
        help="Fit late asymptotic exponent using this many complete doubling blocks."
    )
    ap.add_argument(
        "--p-gate",
        type=float,
        default=0.05
    )
    ap.add_argument(
        "--r2-gate",
        type=float,
        default=0.85
    )
    ap.add_argument(
        "--late-depth-count",
        type=int,
        default=3
    )
    ap.add_argument(
        "--p-spread-gate",
        type=float,
        default=0.08,
        help="Max absolute spread of p across the latest depths."
    )
    ap.add_argument(
        "--last-shell-fraction-gate",
        type=float,
        default=0.01,
        help="Latest added spectral shell / full-N trace norm."
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_trace_norm_cutoff_removal_v132_1"
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    z = np.load(args.roots_npz)
    L = np.asarray(z["L"], int)
    if "lambda_vals" in z:
        lam = np.asarray(z["lambda_vals"], float)
    else:
        roots = np.asarray(z["roots"], float)
        lam = 1.0 / roots**2

    if lam.shape[0] != len(L):
        raise RuntimeError("L and lambda matrix dimensions disagree.")

    depths = sorted(set(csv_ints(args.depths)))
    depths = [d for d in depths if d <= lam.shape[1]]
    if not depths:
        raise RuntimeError("No requested depth is present in ROOTS.npz.")

    L0 = int(L[0])

    print("="*112)
    print("ROT-RH v132.1 — FAST DEPTH-STABILITY / CUTOFF-DECAY POSTPROCESSOR")
    print("="*112)
    print("Xi / zeta / known zeros          : NONE")
    print(f"input                             : {args.roots_npz}")
    print(f"L grid                            : {L.tolist()}")
    print(f"depths                            : {depths}")
    print(f"matrix                            : {lam.shape[0]} cutoffs x {lam.shape[1]} levels")
    print("="*112)

    interval_rows = []
    block_rows = []
    fit_rows = []

    # Consecutive intervals at every depth.
    interval_by_depth = {}
    for N in depths:
        rowsN = []
        for j in range(len(L)-1):
            dlam = np.abs(lam[j+1, :N] - lam[j, :N])
            T = float(np.sum(dlam))
            rowsN.append((j, int(L[j]), int(L[j+1]), T))
            interval_rows.append(dict(
                depth=N,
                interval_index=j,
                L_a=int(L[j]),
                L_b=int(L[j+1]),
                trace_partial=T,
            ))
        interval_by_depth[N] = rowsN

    # Aggregate complete factor-of-two blocks.
    blocks_by_depth = {}
    for N in depths:
        buckets = {}
        for j, La, Lb, T in interval_by_depth[N]:
            d = int(math.floor(math.log(La / L0, 2.0) + 1e-12))
            buckets.setdefault(d, []).append((La, Lb, T))

        rows = []
        for d in sorted(buckets):
            target_lo = L0 * (2**d)
            target_hi = L0 * (2**(d+1))
            rr = buckets[d]

            # A block is complete only if the intervals actually span to target_hi.
            observed_lo = min(x[0] for x in rr)
            observed_hi = max(x[1] for x in rr)
            complete = (observed_lo <= target_lo and observed_hi >= target_hi)

            B = float(sum(x[2] for x in rr))
            row = dict(
                depth=N,
                doubling_index=d,
                nominal_L_lo=target_lo,
                nominal_L_hi=target_hi,
                observed_L_lo=observed_lo,
                observed_L_hi=observed_hi,
                complete=int(complete),
                block_trace=B,
            )
            rows.append(row)
            block_rows.append(row)
        blocks_by_depth[N] = rows

    # Shell fraction: contribution from newly added levels between consecutive tested depths.
    shell_fraction_by_depth = {}
    prevN = None
    for N in depths:
        if prevN is None:
            shell_fraction_by_depth[N] = np.nan
            prevN = N
            continue

        fracs = []
        for j in range(len(L)-1):
            full = float(np.sum(np.abs(lam[j+1, :N] - lam[j, :N])))
            shell = float(np.sum(np.abs(lam[j+1, prevN:N] - lam[j, prevN:N])))
            if full > 0:
                fracs.append(shell/full)
        shell_fraction_by_depth[N] = float(np.max(fracs)) if fracs else np.nan
        prevN = N

    # Fit B(L) ~ L^{-p} independently at every depth.
    for N in depths:
        complete = [r for r in blocks_by_depth[N] if r["complete"] and r["block_trace"] > 0]
        if args.fit_last_blocks > 0:
            use = complete[-args.fit_last_blocks:]
        else:
            use = complete

        if len(use) >= 3:
            x = np.log(np.array([r["nominal_L_lo"] for r in use], float))
            y = np.log(np.array([r["block_trace"] for r in use], float))
            fit = linfit(x, y)
            p = -fit["slope"]
            r2 = fit["r2"]
        else:
            p, r2 = np.nan, np.nan

        ratios = []
        if len(complete) >= 2:
            vals = [r["block_trace"] for r in complete]
            ratios = [vals[i]/vals[i-1] for i in range(1, len(vals))]
        med_ratio = float(np.median(ratios[-2:])) if ratios else np.nan

        fit_rows.append(dict(
            depth=N,
            complete_blocks=len(complete),
            fit_blocks=len(use),
            p=float(p),
            r2=float(r2),
            median_last_block_ratio=med_ratio,
            max_new_shell_fraction=shell_fraction_by_depth[N],
        ))

    write_csv(Path(args.prefix+"_INTERVAL_DEPTH.csv"), interval_rows)
    write_csv(Path(args.prefix+"_BLOCK_DEPTH.csv"), block_rows)
    write_csv(Path(args.prefix+"_DEPTH_FITS.csv"), fit_rows)

    # Print compact table.
    print()
    print("Depth stability")
    print("-"*112)
    print(f"{'N':>6} {'p_late':>12} {'R^2':>12} {'late ratio':>14} {'new-shell frac':>16}")
    for r in fit_rows:
        ns = r["max_new_shell_fraction"]
        print(
            f"{r['depth']:6d} "
            f"{r['p']:12.6f} "
            f"{r['r2']:12.6f} "
            f"{r['median_last_block_ratio']:14.6f} "
            f"{ns:16.6e}"
        )

    late = fit_rows[-min(args.late_depth_count, len(fit_rows)):]
    late_p = np.array([r["p"] for r in late], float)
    late_r2 = np.array([r["r2"] for r in late], float)

    p_positive = bool(np.all(np.isfinite(late_p)) and np.min(late_p) > args.p_gate)
    r2_ok = bool(np.all(np.isfinite(late_r2)) and np.min(late_r2) >= args.r2_gate)
    p_spread = float(np.max(late_p)-np.min(late_p)) if np.all(np.isfinite(late_p)) else np.inf
    p_stable = bool(p_spread <= args.p_spread_gate)

    last = fit_rows[-1]
    last_shell_ok = (
        np.isfinite(last["max_new_shell_fraction"])
        and last["max_new_shell_fraction"] <= args.last_shell_fraction_gate
    )

    finite_depth_pass = bool(p_positive and r2_ok and p_stable and last_shell_ok)

    verdict = dict(
        version="132.1",
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        input=args.roots_npz,
        question_A_finite_depth_cutoff_decay=(
            "PASS" if finite_depth_pass else "FAIL_OR_UNRESOLVED"
        ),
        question_B_infinite_k_tail="OPEN",
        late_depths=[int(r["depth"]) for r in late],
        late_p=[float(x) for x in late_p],
        late_p_spread=p_spread,
        gates=dict(
            late_p_positive=p_positive,
            late_r2_ok=r2_ok,
            late_p_stable=p_stable,
            newest_spectral_shell_small=last_shell_ok,
        ),
        warning=(
            "This postprocessor deliberately does not claim an infinite-k tail bound. "
            "Its purpose is to determine whether the observed L-decay survives increasing "
            "spectral depth before spending more CPU on new cutoff supports."
        )
    )

    Path(args.prefix+"_VERDICT.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )

    print()
    print("="*112)
    print(f"late p values                     : {[round(x, 6) for x in late_p.tolist()]}")
    print(f"late p spread                     : {p_spread:.6g}")
    print(f"positive-p gate                   : {p_positive}")
    print(f"R^2 gate                          : {r2_ok}")
    print(f"depth-stability gate              : {p_stable}")
    print(f"newest spectral-shell gate        : {last_shell_ok}")
    print(f"FINITE-DEPTH CUTOFF DECAY         : {'PASS' if finite_depth_pass else 'FAIL_OR_UNRESOLVED'}")
    print("INFINITE-k TAIL                   : OPEN")
    print("="*112)

    if args.strict and not finite_depth_pass:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
