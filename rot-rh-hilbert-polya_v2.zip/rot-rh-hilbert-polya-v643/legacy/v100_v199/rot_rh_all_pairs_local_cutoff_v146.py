#!/usr/bin/env python3
"""
ROT-RH v146 — ALL-PAIRS ROOT-LOCAL CUTOFF-INDEPENDENCE AUDIT

Purpose
-------
Attack the fixed-mode half of FULL cutoff independence on an interlaced
cutoff net, not merely on adjacent or dyadic pairs.

Input:
  rot_rh_cutoff_independence_v143_ROOTS.npz

For every ordered cutoff pair L_a < L_b and every tracked mode k, define

    target_k = k - 1/2,

    delta_k(L_a,L_b)
      = F_{L_b}( E_k(L_a) ) - target_k.

Because

    F_{L_b}( E_k(L_b) ) = target_k,

the mean-value theorem gives

    |E_k(L_b)-E_k(L_a)|
      <= |delta_k(L_a,L_b)| /
         inf_{segment} |F'_{L_b}|,

provided F' does not vanish on the segment joining the roots.

This script:
  * builds each needed phase ONCE,
  * checks EVERY cutoff pair in the interlaced net,
  * checks EVERY mode 1..N,
  * directly evaluates F and F' (no interpolation),
  * computes actual finite-mode trace distances,
  * computes root-displacement and implicit-bound tail-set diameters,
  * asks whether the all-pairs tail envelopes shrink as L0 increases.

NO Xi / zeta / known-zero data are used.

This is still a numerical finite-mode audit, not an infinite theorem.

Outputs
-------
<prefix>_MODES.csv
<prefix>_PAIRS.csv
<prefix>_TAILS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path, rows):
    path = Path(path)
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty upstream phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)
    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass

    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def safe_ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.nan


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--focus-modes", default="9,10,13,14")

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument(
        "--segment-samples",
        type=int,
        default=13,
        help="F' samples on each segment joining the two roots.",
    )
    ap.add_argument(
        "--margin-fraction",
        type=float,
        default=0.10,
        help="Extend each root segment by this fraction of its length.",
    )
    ap.add_argument(
        "--minimum-margin",
        type=float,
        default=1e-6,
    )

    ap.add_argument(
        "--derivative-floor-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--root-residual-gate",
        type=float,
        default=5e-9,
    )
    ap.add_argument(
        "--tail-contraction-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--bound-slack",
        type=float,
        default=1.02,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_all_pairs_local_cutoff_v146",
    )

    args = ap.parse_args()

    focus = csv_ints(args.focus_modes)

    z = np.load(args.cutoff_net_npz)
    Ls = np.asarray(z["L"], dtype=int)
    roots_all = np.asarray(z["roots"], dtype=float)

    order = np.argsort(Ls)
    Ls = Ls[order]
    roots_all = roots_all[order]

    n = min(args.modes, roots_all.shape[1])
    roots = roots_all[:, :n].copy()
    lam = 1.0 / roots**2

    if len(Ls) < 4:
        raise RuntimeError("Need at least four cutoffs for a meaningful all-pairs tail audit.")
    if args.segment_samples < 3:
        raise RuntimeError("--segment-samples must be >= 3.")

    print("=" * 132)
    print("ROT-RH v146 — ALL-PAIRS ROOT-LOCAL CUTOFF-INDEPENDENCE AUDIT")
    print("=" * 132)
    print("Xi / zeta / known zeros          : NONE")
    print(f"cutoff net                        : {Ls.tolist()}")
    print(f"modes                             : 1..{n}")
    print(f"number of cutoff pairs            : {len(Ls)*(len(Ls)-1)//2}")
    print(f"segment samples                   : {args.segment_samples}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 132)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    # Only larger-endpoint phases are needed.
    phases = {}
    warning_messages = {}

    for L in Ls[1:]:
        L = int(L)
        print(f"[L={L}] building RenormalizedPhase ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phases[L] = v102.RenormalizedPhase.build(
                base,
                L,
                float(args.tail_factor),
                int(args.counter_q),
            )
        warning_messages[L] = [str(w.message) for w in wrn]

        if warning_messages[L]:
            print(f"[L={L}] built with {len(warning_messages[L])} warning(s)")
            for msg in warning_messages[L][:2]:
                print(f"           warning: {msg}")
        else:
            print(f"[L={L}] built with no captured warnings")

    mode_rows = []
    pair_rows = []

    focus_idx = [k - 1 for k in focus if 1 <= k <= n]
    low16 = min(16, n)

    # ------------------------------------------------------------------
    # All pairs
    # ------------------------------------------------------------------
    for ia in range(len(Ls) - 1):
        for ib in range(ia + 1, len(Ls)):
            La = int(Ls[ia])
            Lb = int(Ls[ib])
            phase = phases[Lb]

            abs_defects = []
            abs_shifts = []
            bounds = []
            mins = []
            sign_ok = []
            bound_ok = []
            residual_ok = []

            for j in range(n):
                k = j + 1
                target = k - 0.5
                Ea = float(roots[ia, j])
                Eb = float(roots[ib, j])
                shift = abs(Eb - Ea)

                Fa = scalar_call(phase.F, Ea)
                Fb = scalar_call(phase.F, Eb)

                defect = Fa - target
                root_res = Fb - target

                margin = max(
                    args.minimum_margin,
                    args.margin_fraction * max(shift, args.minimum_margin),
                )
                lo = min(Ea, Eb) - margin
                hi = max(Ea, Eb) + margin

                xs = np.linspace(lo, hi, args.segment_samples)
                fp = vector_call(phase.Fprime, xs)

                abs_fp = np.abs(fp)
                min_abs_fp = float(np.min(abs_fp))
                max_abs_fp = float(np.max(abs_fp))

                sign_stable = bool(np.all(fp > 0.0) or np.all(fp < 0.0))
                strong_transverse = bool(min_abs_fp >= args.derivative_floor_gate)

                bound = (
                    abs(defect) / min_abs_fp
                    if min_abs_fp > 0 else np.inf
                )

                bpass = bool(
                    np.isfinite(bound)
                    and shift <= args.bound_slack * bound
                )
                rpass = bool(abs(root_res) <= args.root_residual_gate)

                secant = abs(defect) / shift if shift > 0 else np.nan

                abs_defects.append(abs(defect))
                abs_shifts.append(shift)
                bounds.append(bound)
                mins.append(min_abs_fp)
                sign_ok.append(sign_stable and strong_transverse)
                bound_ok.append(bpass)
                residual_ok.append(rpass)

                mode_rows.append(dict(
                    L_a=La,
                    L_b=Lb,
                    ratio_L=float(Lb / La),
                    k=k,
                    E_a=Ea,
                    E_b=Eb,
                    abs_root_shift=shift,
                    F_b_at_Ea=Fa,
                    old_root_defect=defect,
                    abs_old_root_defect=abs(defect),
                    F_b_at_Eb=Fb,
                    new_root_residual=root_res,
                    min_abs_Fprime_segment=min_abs_fp,
                    max_abs_Fprime_segment=max_abs_fp,
                    derivative_sign_stable=int(sign_stable),
                    strong_transversality=int(strong_transverse),
                    implicit_upper_bound=bound,
                    shift_over_bound=(
                        shift / bound
                        if np.isfinite(bound) and bound > 0 else np.nan
                    ),
                    secant_abs_derivative=secant,
                    bound_pass=int(bpass),
                    root_residual_pass=int(rpass),
                ))

            abs_defects = np.asarray(abs_defects)
            abs_shifts = np.asarray(abs_shifts)
            bounds_arr = np.asarray(bounds)

            pair_rows.append(dict(
                L_a=La,
                L_b=Lb,
                ratio_L=float(Lb / La),
                log2_separation=float(math.log(Lb / La, 2.0)),
                sum_abs_defect_1_N=float(np.sum(abs_defects)),
                sum_abs_shift_1_N=float(np.sum(abs_shifts)),
                sum_implicit_bound_1_N=float(np.sum(bounds_arr)),
                trace_distance_1_N=float(np.sum(np.abs(lam[ib] - lam[ia]))),
                trace_distance_1_16=float(np.sum(np.abs(lam[ib, :low16] - lam[ia, :low16]))),
                focus_trace_distance=(
                    float(np.sum(np.abs(lam[ib, focus_idx] - lam[ia, focus_idx])))
                    if focus_idx else np.nan
                ),
                min_derivative_floor=float(np.min(mins)),
                local_transversality_fraction=float(np.mean(sign_ok)),
                bound_pass_fraction=float(np.mean(bound_ok)),
                root_residual_pass_fraction=float(np.mean(residual_ok)),
            ))

    write_csv(args.prefix + "_MODES.csv", mode_rows)
    write_csv(args.prefix + "_PAIRS.csv", pair_rows)

    # ------------------------------------------------------------------
    # Tail-set worst cases
    # ------------------------------------------------------------------
    tail_rows = []

    for start in range(len(Ls) - 1):
        L0 = int(Ls[start])
        eligible = [
            r for r in pair_rows
            if r["L_a"] >= L0 and r["L_b"] >= L0
        ]
        if not eligible:
            continue

        worst_def = max(eligible, key=lambda r: r["sum_abs_defect_1_N"])
        worst_shift = max(eligible, key=lambda r: r["sum_abs_shift_1_N"])
        worst_bound = max(eligible, key=lambda r: r["sum_implicit_bound_1_N"])
        worst_trace = max(eligible, key=lambda r: r["trace_distance_1_N"])
        worst_trace16 = max(eligible, key=lambda r: r["trace_distance_1_16"])

        # Per-mode tail diameters too.
        idxs = np.where(Ls >= L0)[0]
        per_mode_E_diam = np.max(roots[idxs], axis=0) - np.min(roots[idxs], axis=0)
        per_mode_lam_diam = np.max(lam[idxs], axis=0) - np.min(lam[idxs], axis=0)

        tail_rows.append(dict(
            L0=L0,
            cutoffs_in_tail=len(idxs),
            pairs_in_tail=len(eligible),

            worst_sum_abs_defect=float(worst_def["sum_abs_defect_1_N"]),
            defect_pair=f"{worst_def['L_a']}->{worst_def['L_b']}",

            worst_sum_abs_root_shift=float(worst_shift["sum_abs_shift_1_N"]),
            shift_pair=f"{worst_shift['L_a']}->{worst_shift['L_b']}",

            worst_sum_implicit_bound=float(worst_bound["sum_implicit_bound_1_N"]),
            bound_pair=f"{worst_bound['L_a']}->{worst_bound['L_b']}",

            trace_cauchy_diameter_1_N=float(worst_trace["trace_distance_1_N"]),
            trace_pair=f"{worst_trace['L_a']}->{worst_trace['L_b']}",

            trace_cauchy_diameter_1_16=float(worst_trace16["trace_distance_1_16"]),
            trace16_pair=f"{worst_trace16['L_a']}->{worst_trace16['L_b']}",

            sum_mode_E_diameters=float(np.sum(per_mode_E_diam)),
            max_mode_E_diameter=float(np.max(per_mode_E_diam)),
            sum_mode_lambda_diameters=float(np.sum(per_mode_lam_diam)),

            min_local_derivative_floor=float(
                min(r["min_derivative_floor"] for r in eligible)
            ),
            min_local_transversality_fraction=float(
                min(r["local_transversality_fraction"] for r in eligible)
            ),
            min_bound_pass_fraction=float(
                min(r["bound_pass_fraction"] for r in eligible)
            ),
            min_root_residual_pass_fraction=float(
                min(r["root_residual_pass_fraction"] for r in eligible)
            ),
        ))

    # Tail contraction ratios
    keys = [
        "worst_sum_abs_defect",
        "worst_sum_abs_root_shift",
        "worst_sum_implicit_bound",
        "trace_cauchy_diameter_1_N",
        "trace_cauchy_diameter_1_16",
        "sum_mode_E_diameters",
        "sum_mode_lambda_diameters",
    ]

    for i, r in enumerate(tail_rows):
        for key in keys:
            r[key + "_ratio"] = (
                safe_ratio(r[key], tail_rows[i-1][key])
                if i > 0 else np.nan
            )

    write_csv(args.prefix + "_TAILS.csv", tail_rows)

    # ------------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------------
    meaningful = [r for r in tail_rows if r["cutoffs_in_tail"] >= 3]

    if meaningful:
        latest = meaningful[-1]
        trace_contract = latest["trace_cauchy_diameter_1_N_ratio"] < args.tail_contraction_gate
        defect_contract = latest["worst_sum_abs_defect_ratio"] < args.tail_contraction_gate
        bound_contract = latest["worst_sum_implicit_bound_ratio"] < args.tail_contraction_gate

        quality_ok = (
            latest["min_local_transversality_fraction"] >= 0.95
            and latest["min_bound_pass_fraction"] >= 0.95
            and latest["min_root_residual_pass_fraction"] >= 0.95
            and latest["min_local_derivative_floor"] >= args.derivative_floor_gate
        )
    else:
        latest = None
        trace_contract = defect_contract = bound_contract = quality_ok = False

    if trace_contract and defect_contract and bound_contract and quality_ok:
        verdict = "ALL_PAIRS_FIXED_MODE_CUTOFF_INDEPENDENCE_STRONGLY_SUPPORTED"
    elif trace_contract and quality_ok:
        verdict = "ALL_PAIRS_ROOT_CAUCHY_SUPPORTED_DEFECT_ENVELOPE_MIXED"
    else:
        verdict = "ALL_PAIRS_FIXED_MODE_CUTOFF_INDEPENDENCE_UNRESOLVED"

    summary = dict(
        version=146,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoff_net=Ls.tolist(),
        modes=n,
        all_pairs=len(pair_rows),
        theorem_target=(
            "For every fixed N, sup_{L,M>=L0} sum_{k<=N} "
            "|lambda_k(L)-lambda_k(M)| -> 0, with local implicit-function "
            "control of every root pair."
        ),
        latest_meaningful_tail=latest,
        warnings_by_L=warning_messages,
        verdict=verdict,
        proof_status=(
            "NUMERICAL FINITE-MODE ALL-PAIRS AUDIT ONLY. "
            "Full cutoff independence still requires analytic all-k fixed-mode "
            "convergence plus the uniform summable high-k majorant."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Terminal report
    # ------------------------------------------------------------------
    print()
    print("All-pair summaries")
    print("-" * 132)
    print(
        f"{'pair':>18} {'sum|defect|':>14} {'sum|dE|':>14} "
        f"{'trace d32':>14} {'min|Fprime|':>14} "
        f"{'trans%':>8} {'bound%':>8}"
    )

    for r in pair_rows:
        pair = f"{r['L_a']}->{r['L_b']}"
        print(
            f"{pair:>18} "
            f"{r['sum_abs_defect_1_N']:14.6e} "
            f"{r['sum_abs_shift_1_N']:14.6e} "
            f"{r['trace_distance_1_N']:14.6e} "
            f"{r['min_derivative_floor']:14.6e} "
            f"{100*r['local_transversality_fraction']:8.1f} "
            f"{100*r['bound_pass_fraction']:8.1f}"
        )

    print()
    print("Tail-set all-pairs Cauchy envelopes")
    print("-" * 132)
    for r in tail_rows:
        print(
            f"L0={r['L0']:>7d} points={r['cutoffs_in_tail']} pairs={r['pairs_in_tail']:2d}  "
            f"def={r['worst_sum_abs_defect']:.6e} "
            f"(r={r['worst_sum_abs_defect_ratio']:.6f})  "
            f"|dE|={r['worst_sum_abs_root_shift']:.6e} "
            f"(r={r['worst_sum_abs_root_shift_ratio']:.6f})  "
            f"d32={r['trace_cauchy_diameter_1_N']:.6e} "
            f"(r={r['trace_cauchy_diameter_1_N_ratio']:.6f})"
        )

    print()
    print("=" * 132)
    if latest is not None:
        print(f"latest >=3-point tail L0          : {latest['L0']}")
        print(f"latest worst-defect ratio          : {latest['worst_sum_abs_defect_ratio']:.9f}")
        print(f"latest worst-root-shift ratio      : {latest['worst_sum_abs_root_shift_ratio']:.9f}")
        print(f"latest worst-implicit-bound ratio  : {latest['worst_sum_implicit_bound_ratio']:.9f}")
        print(f"latest trace-Cauchy ratio (1..N)   : {latest['trace_cauchy_diameter_1_N_ratio']:.9f}")
        print(f"latest minimum local |F'|          : {latest['min_local_derivative_floor']:.9e}")
        print(f"latest minimum transversality frac : {latest['min_local_transversality_fraction']:.3f}")
        print(f"latest minimum bound-pass frac     : {latest['min_bound_pass_fraction']:.3f}")
    print(f"VERDICT                             : {verdict}")
    print("=" * 132)
    print("If this passes strongly, the numerical finite-mode evidence covers arbitrary")
    print("pairs in the interlaced net. The remaining step is genuinely analytic:")
    print("prove the fixed-k old-root defect tends to zero uniformly over all large cutoffs.")


if __name__ == "__main__":
    main()
