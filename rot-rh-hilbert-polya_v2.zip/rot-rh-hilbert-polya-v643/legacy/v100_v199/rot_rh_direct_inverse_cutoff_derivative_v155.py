#!/usr/bin/env python3
"""
ROT-RH v155 — DIRECT INVERSE-CUTOFF DERIVATIVE / IMPLICIT TRACE AUDIT

Purpose
-------
Directly measure the regulator derivative in the natural coordinate

    a = 1/L

at frozen arithmetic roots, instead of inferring it from wide cutoff secants.

For each base cutoff L0 and each relative inverse-cutoff perturbation eta,

    a_- = a0 (1-eta),     a_+ = a0 (1+eta),

with corresponding cutoffs approximately

    L_- = 1/a_- > L0,     L_+ = 1/a_+ < L0.

At each frozen root E_k(L0), evaluate

    F_{a_-}(E_k), F_{a0}(E_k), F_{a_+}(E_k)

and use the exact nonuniform three-point derivative weights to estimate

    partial_a F_a(E_k)|_{a=a0}.

Then use direct F_E from the base phase:

    dE_k/da
      = - (partial_a F_a)/(partial_E F_a),

    d lambda_k/da
      = 2 (partial_a F_a) /
        [ E_k^3 (partial_E F_a) ],

for

    lambda_k = E_k^{-2}.

The finite-block trace derivative is

    T_N(a) = sum_{k<=N} |d lambda_k/da|.

If

    T_N(a) <= C a^{-rho},   rho < 1,

then T_N is integrable at a=0 and the finite spectral block is Cauchy.

v155 uses two or more eta values to test derivative stability before fitting rho.

NO Xi / zeta / known-zero data are used.
No new root solves are performed.

Outputs
-------
<prefix>_MODES.csv
<prefix>_BASES.csv
<prefix>_ETA_STABILITY.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def csv_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))

    a = np.asarray(y, dtype=float).reshape(-1)
    if not len(a):
        raise RuntimeError("Empty upstream phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)

    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass

    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def derivative_weights(xm, x0, xp):
    """
    Weights w such that for a quadratic interpolant through xm,x0,xp,

        f'(x0) = wm f(xm) + w0 f(x0) + wp f(xp).

    Solved from moment conditions to handle integer-rounded cutoff asymmetry.
    """
    dm = xm - x0
    dp = xp - x0

    A = np.array([
        [1.0, 1.0, 1.0],
        [dm, 0.0, dp],
        [dm*dm, 0.0, dp*dp],
    ], dtype=float)

    b = np.array([0.0, 1.0, 0.0], dtype=float)
    return np.linalg.solve(A, b)


def build_phase(v102, base, L, tail_factor, counter_q):
    with warnings.catch_warnings(record=True) as wrn:
        warnings.simplefilter("always")
        phase = v102.RenormalizedPhase.build(
            base,
            int(L),
            float(tail_factor),
            int(counter_q),
        )
    return phase, [str(w.message) for w in wrn]


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--base-L-list",
        default="256000,512000",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--eta-values",
        default="0.08,0.04",
        help="Relative perturbations in a=1/L. Smallest eta is final derivative.",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument(
        "--derivative-stability-gate",
        type=float,
        default=0.05,
        help="Relative change of aggregate trace derivative between last two eta values.",
    )
    ap.add_argument(
        "--mode-stability-gate",
        type=float,
        default=0.10,
        help="Per-mode relative derivative-change gate.",
    )
    ap.add_argument(
        "--mode-stability-fraction-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--transversality-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--rho-gate",
        type=float,
        default=1.0,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_direct_inverse_cutoff_derivative_v155",
    )

    args = ap.parse_args()

    base_Ls = sorted(set(csv_ints(args.base_L_list)))
    etas = sorted(set(csv_floats(args.eta_values)), reverse=True)

    if len(base_Ls) < 2:
        raise RuntimeError("Need at least two base cutoffs to estimate rho.")
    if len(etas) < 2:
        raise RuntimeError("Need at least two eta values for derivative stability.")
    if any(not (0 < e < 0.5) for e in etas):
        raise RuntimeError("eta values must lie in (0,0.5).")

    z = np.load(args.cutoff_net_npz)
    Lnet = np.asarray(z["L"], dtype=int)
    Rnet = np.asarray(z["roots"], dtype=float)

    root_map = {
        int(L): np.asarray(Rnet[i], dtype=float)
        for i, L in enumerate(Lnet)
    }

    for L in base_Ls:
        if L not in root_map:
            raise RuntimeError(f"Base cutoff L={L} not found in cutoff net.")

    n = min(args.modes, min(len(root_map[L]) for L in base_Ls))

    print("=" * 140)
    print("ROT-RH v155 — DIRECT INVERSE-CUTOFF DERIVATIVE / IMPLICIT TRACE AUDIT")
    print("=" * 140)
    print("Xi / zeta / known zeros          : NONE")
    print(f"base cutoffs                      : {base_Ls}")
    print(f"modes                             : 1..{n}")
    print(f"eta values in a=1/L               : {etas}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 140)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    mode_rows = []
    base_rows = []
    stability_rows = []
    warnings_all = {}

    # Cache phases by integer L because perturbations can theoretically coincide.
    phase_cache = {}

    def get_phase(L):
        L = int(L)
        if L not in phase_cache:
            print(f"[L={L}] building RenormalizedPhase ...", flush=True)
            ph, wrn = build_phase(
                v102, base, L,
                args.tail_factor, args.counter_q
            )
            phase_cache[L] = ph
            warnings_all[L] = wrn
            if wrn:
                print(f"[L={L}] built with {len(wrn)} warning(s)")
                for msg in wrn[:2]:
                    print(f"           warning: {msg}")
        return phase_cache[L]

    # Store aggregate derivative per base and eta.
    agg = {}

    for L0 in base_Ls:
        roots = np.asarray(root_map[L0][:n], dtype=float)
        a0 = 1.0 / float(L0)

        base_phase = get_phase(L0)
        F0 = vector_call(base_phase.F, roots)
        FE = vector_call(base_phase.Fprime, roots)

        targets = np.arange(1, n+1, dtype=float) - 0.5
        base_residual = F0 - targets

        if np.min(np.abs(FE)) < args.transversality_gate:
            print(
                f"WARNING L={L0}: min |F_E|={np.min(np.abs(FE)):.3e} "
                f"below gate."
            )

        agg[L0] = {}

        for eta in etas:
            # a_minus < a0 < a_plus.
            a_minus_target = a0 * (1.0 - eta)
            a_plus_target = a0 * (1.0 + eta)

            # Integer cutoffs nearest the requested a values.
            L_minus = int(round(1.0 / a_minus_target))
            L_plus = int(round(1.0 / a_plus_target))

            # Actual a after integer rounding.
            a_minus = 1.0 / float(L_minus)
            a_plus = 1.0 / float(L_plus)

            if not (a_minus < a0 < a_plus):
                raise RuntimeError(
                    f"Rounded perturbations do not bracket a0 for L={L0}, eta={eta}."
                )

            phase_minus = get_phase(L_minus)
            phase_plus = get_phase(L_plus)

            Fm = vector_call(phase_minus.F, roots)
            Fp = vector_call(phase_plus.F, roots)

            wm, w0, wp = derivative_weights(a_minus, a0, a_plus)
            dF_da = wm*Fm + w0*F0 + wp*Fp

            dE_da = -dF_da / FE
            dlambda_da = 2.0 * dF_da / (roots**3 * FE)

            sum_abs_dF = float(np.sum(np.abs(dF_da)))
            sum_abs_dE = float(np.sum(np.abs(dE_da)))
            trace_deriv = float(np.sum(np.abs(dlambda_da)))

            agg[L0][eta] = dict(
                L_minus=L_minus,
                L_plus=L_plus,
                a_minus=a_minus,
                a_plus=a_plus,
                weights=(wm, w0, wp),
                dF_da=dF_da,
                dE_da=dE_da,
                dlambda_da=dlambda_da,
                sum_abs_dF=sum_abs_dF,
                sum_abs_dE=sum_abs_dE,
                trace_deriv=trace_deriv,
            )

            for j in range(n):
                mode_rows.append(dict(
                    base_L=L0,
                    a0=a0,
                    eta=eta,
                    L_minus=L_minus,
                    L_plus=L_plus,
                    k=j+1,
                    E=float(roots[j]),
                    base_root_residual=float(base_residual[j]),
                    F_E=float(FE[j]),
                    abs_F_E=float(abs(FE[j])),
                    partial_a_F=float(dF_da[j]),
                    dE_da=float(dE_da[j]),
                    d_lambda_da=float(dlambda_da[j]),
                    abs_d_lambda_da=float(abs(dlambda_da[j])),
                ))

            base_rows.append(dict(
                base_L=L0,
                a0=a0,
                eta=eta,
                L_minus=L_minus,
                L_plus=L_plus,
                actual_eta_minus=(a0-a_minus)/a0,
                actual_eta_plus=(a_plus-a0)/a0,
                max_base_root_residual=float(np.max(np.abs(base_residual))),
                min_abs_F_E=float(np.min(np.abs(FE))),
                sum_abs_partial_a_F=sum_abs_dF,
                sum_abs_dE_da=sum_abs_dE,
                trace_derivative_N=trace_deriv,
                a_times_trace_derivative=a0*trace_deriv,
            ))

    # ------------------------------------------------------------------
    # eta stability
    # ------------------------------------------------------------------
    eta_final = min(etas)
    eta_prev = sorted(etas)[1]  # second-smallest

    for L0 in base_Ls:
        final = agg[L0][eta_final]
        prev = agg[L0][eta_prev]

        mode_den = np.maximum(np.abs(final["dlambda_da"]), 1e-300)
        mode_rel = np.abs(
            final["dlambda_da"] - prev["dlambda_da"]
        ) / mode_den

        trace_rel = (
            abs(final["trace_deriv"] - prev["trace_deriv"])
            / max(final["trace_deriv"], 1e-300)
        )
        dF_rel = (
            abs(final["sum_abs_dF"] - prev["sum_abs_dF"])
            / max(final["sum_abs_dF"], 1e-300)
        )

        stability_rows.append(dict(
            base_L=L0,
            eta_previous=eta_prev,
            eta_final=eta_final,
            trace_derivative_relative_change=trace_rel,
            sum_abs_partial_a_F_relative_change=dF_rel,
            median_mode_lambda_derivative_relative_change=float(np.median(mode_rel)),
            max_mode_lambda_derivative_relative_change=float(np.max(mode_rel)),
            fraction_modes_stable=float(
                np.mean(mode_rel <= args.mode_stability_gate)
            ),
        ))

    # ------------------------------------------------------------------
    # rho from FINAL eta direct derivatives
    # ------------------------------------------------------------------
    final_trace = np.array(
        [agg[L][eta_final]["trace_deriv"] for L in base_Ls],
        dtype=float,
    )
    final_dF = np.array(
        [agg[L][eta_final]["sum_abs_dF"] for L in base_Ls],
        dtype=float,
    )
    final_dE = np.array(
        [agg[L][eta_final]["sum_abs_dE"] for L in base_Ls],
        dtype=float,
    )
    avec = 1.0 / np.asarray(base_Ls, dtype=float)

    def fit_rho(values):
        X = np.log(avec)
        Y = np.log(values)
        A = np.vstack([np.ones_like(X), X]).T
        coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
        pred = A @ coef

        rho = float(-coef[1])
        logC = float(coef[0])

        ss_res = float(np.sum((Y-pred)**2))
        ss_tot = float(np.sum((Y-np.mean(Y))**2))
        r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

        return rho, math.exp(logC), r2

    rho_trace, C_trace, r2_trace = fit_rho(final_trace)
    rho_dF, C_dF, r2_dF = fit_rho(final_dF)
    rho_dE, C_dE, r2_dE = fit_rho(final_dE)

    # With exactly two base cutoffs, rho is simply the local exponent.
    local_rhos = []
    for i in range(1, len(base_Ls)):
        L1, L2 = base_Ls[i-1], base_Ls[i]
        a1, a2 = 1.0/L1, 1.0/L2

        S1 = agg[L1][eta_final]["trace_deriv"]
        S2 = agg[L2][eta_final]["trace_deriv"]

        rho = -math.log(S2/S1) / math.log(a2/a1)
        local_rhos.append(dict(
            L1=L1,
            L2=L2,
            rho_trace=float(rho),
            alpha_trace=float(1.0-rho),
            aS1=float(a1*S1),
            aS2=float(a2*S2),
            aS_ratio=float((a2*S2)/(a1*S1)),
        ))

    pd.DataFrame(mode_rows).to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    pd.DataFrame(base_rows).to_csv(
        args.prefix + "_BASES.csv", index=False
    )
    pd.DataFrame(stability_rows).to_csv(
        args.prefix + "_ETA_STABILITY.csv", index=False
    )

    # ------------------------------------------------------------------
    # verdict
    # ------------------------------------------------------------------
    derivative_stable = all(
        r["trace_derivative_relative_change"]
        <= args.derivative_stability_gate
        and r["fraction_modes_stable"]
        >= args.mode_stability_fraction_gate
        for r in stability_rows
    )

    transverse = all(
        r["min_abs_F_E"] >= args.transversality_gate
        for r in base_rows
    )

    integrable = (
        rho_trace < args.rho_gate
        and all(r["rho_trace"] < args.rho_gate for r in local_rhos)
        and all(r["aS_ratio"] < 1.0 for r in local_rhos)
    )

    if derivative_stable and transverse and integrable:
        verdict = "DIRECT_TRACE_DERIVATIVE_INTEGRABILITY_STRONGLY_SUPPORTED"
    elif transverse and integrable:
        verdict = "TRACE_DERIVATIVE_INTEGRABLE_BUT_ETA_STABILITY_MIXED"
    else:
        verdict = "DIRECT_TRACE_DERIVATIVE_INTEGRABILITY_UNRESOLVED"

    summary = dict(
        version=155,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        regulator_parameter="a=1/L",
        base_cutoffs=base_Ls,
        modes=n,
        eta_values=etas,
        final_eta=eta_final,
        fits=dict(
            trace=dict(rho=rho_trace, alpha=1-rho_trace, C=C_trace, R2=r2_trace),
            partial_a_F_l1=dict(rho=rho_dF, alpha=1-rho_dF, C=C_dF, R2=r2_dF),
            dE_da_l1=dict(rho=rho_dE, alpha=1-rho_dE, C=C_dE, R2=r2_dE),
        ),
        local_trace_rhos=local_rhos,
        eta_stability=stability_rows,
        derivative_stability_pass=derivative_stable,
        transversality_pass=transverse,
        integrability_pass=integrable,
        verdict=verdict,
        theorem_target=(
            "Prove directly that T_N(a)=sum_{k<=N}|d(E_k(a)^-2)/da| "
            "is integrable at a=0. Since "
            "d lambda_k/da = 2 partial_a F_a(E_k) / "
            "[E_k^3 partial_E F_a(E_k)], it suffices to bound the signed "
            "finite-part regulator derivative partial_a F_a on each fixed "
            "spectral block and retain a nonzero local partial_E F_a floor."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Direct derivative summaries")
    print("-" * 140)
    print(
        f"{'L':>9} {'eta':>8} {'L-':>9} {'L+':>9} "
        f"{'sum|Fa|':>14} {'sum|dE/da|':>14} "
        f"{'T_N(a)':>14} {'a*T_N':>14} {'min|F_E|':>12}"
    )

    for r in base_rows:
        print(
            f"{r['base_L']:9d} "
            f"{r['eta']:8.4f} "
            f"{r['L_minus']:9d} "
            f"{r['L_plus']:9d} "
            f"{r['sum_abs_partial_a_F']:14.6e} "
            f"{r['sum_abs_dE_da']:14.6e} "
            f"{r['trace_derivative_N']:14.6e} "
            f"{r['a_times_trace_derivative']:14.6e} "
            f"{r['min_abs_F_E']:12.6e}"
        )

    print()
    print("Eta-convergence checks")
    print("-" * 140)
    for r in stability_rows:
        print(
            f"L={r['base_L']:>7d}  "
            f"eta {r['eta_previous']:.4f}->{r['eta_final']:.4f}  "
            f"T_N rel change={r['trace_derivative_relative_change']:.3e}  "
            f"median mode={r['median_mode_lambda_derivative_relative_change']:.3e}  "
            f"max mode={r['max_mode_lambda_derivative_relative_change']:.3e}  "
            f"stable modes={r['fraction_modes_stable']:.3f}"
        )

    print()
    print("Direct derivative-growth fits  T(a) ~ C a^(-rho)")
    print("-" * 140)
    print(
        f"trace derivative rho              : {rho_trace:.9f}  "
        f"alpha={1-rho_trace:.9f}  R2={r2_trace:.6f}"
    )
    print(
        f"sum|partial_a F| rho              : {rho_dF:.9f}  "
        f"alpha={1-rho_dF:.9f}  R2={r2_dF:.6f}"
    )
    print(
        f"sum|dE/da| rho                    : {rho_dE:.9f}  "
        f"alpha={1-rho_dE:.9f}  R2={r2_dE:.6f}"
    )

    print()
    print("Local trace-derivative integrability")
    print("-" * 140)
    for r in local_rhos:
        print(
            f"{r['L1']:>7d}->{r['L2']:<7d}  "
            f"rho={r['rho_trace']:.9f}  "
            f"alpha={r['alpha_trace']:.9f}  "
            f"a*T ratio={r['aS_ratio']:.9f}"
        )

    print()
    print("=" * 140)
    print(f"derivative eta-stability pass      : {derivative_stable}")
    print(f"local transversality pass          : {transverse}")
    print(f"direct integrability pass          : {integrable}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 140)
    print("If this passes, the remaining proof problem is no longer empirical")
    print("cutoff fitting: derive an analytic integrable bound for the signed")
    print("regulator derivative partial_a F_a(E) uniformly on every fixed")
    print("spectral block, then combine it with the high-k tail lemma.")


if __name__ == "__main__":
    main()
