#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v111 — Exact Staircase Block Correction / Primitive Audit
=================================================================

This replaces the globally-invalid inverse-function Euler–Maclaurin picture
with an exact staircase identity.

Let
    N_L(E)=#{k:E_{k,L}<=E},
    Q_L(E)=F_L(E)-N_L(E).

For a held-out block N0<k<=N1 and any smooth g,

  sum_{k=N0+1}^{N1} g(E_k)
    = int_{E_N0}^{E_N1} g(E)F'_L(E)dE
      - 1/2 g(E_N0)
      + 1/2 g(E_N1)
      + int_{E_N0}^{E_N1} Q_L(E) g'(E)dE.

This identity is exact and requires:
  * no global inverse F_L^{-1};
  * no monotonicity between roots;
  * no Xi, zeta, or known-zero data.

v111 audits:
  1. the exact identity for inverse moments and resolvents;
  2. the true staircase correction int Q g';
  3. how well the old local B2 endpoint surrogate approximates that exact
     correction (empirical only; NOT used as a theorem);
  4. the first primitive A(E)=int Q, cell by cell.

If A(E) stays uniformly bounded, then integration by parts gives an extra
power of high-energy decay:

  |int Q(E) g'(E)dE|
    <= sup|A| * |g'(E_N0)|

for g(E)=E^-p on a high-energy tail (g''>0), up to the finite block endpoint
version. This is the monotonicity-free analogue of why Bernoulli corrections
can be small.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss

VERSION = "v111"
BUILD = "2026-08-17-exact-staircase-block-primitive-audit-v111"
EPS = 1e-30


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def relerr(x, y):
    return abs(x - y) / max(abs(y), EPS)


def nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def b2_tail_moment(phase, E, m):
    fp = float(phase.Fprime(np.asarray([float(E)]))[0])
    if fp <= 0:
        return float("nan")
    return float(m / (6.0 * float(E) ** (2 * m + 1) * fp))


def block_audit(phase, roots, N0, N1, q, moment_order, aprobes):
    """
    Integrate cellwise on [E_N0,E_N1].

    On the open cell (E_k,E_{k+1}), N_L(E)=k.
    Here k ranges N0,...,N1-1.
    """
    E0 = float(roots[N0 - 1])
    E1 = float(roots[N1 - 1])

    exact_mom = np.asarray(
        [
            float(np.sum(np.asarray(roots[N0:N1], float) ** (-2 * m)))
            for m in range(1, moment_order + 1)
        ],
        float,
    )
    exact_res = {
        a: complex(
            np.sum(
                1.0
                / (
                    np.asarray(roots[N0:N1], float) ** 2
                    + complex(a) ** 2
                )
            )
        )
        for a in aprobes
    }

    Jmom = np.zeros(moment_order, float)
    Qgpmom = np.zeros(moment_order, float)
    Jres = {a: 0.0j for a in aprobes}
    Qgpres = {a: 0.0j for a in aprobes}

    cell_rows = []
    cumQ = 0.0
    max_abs_cum_boundary = 0.0
    max_cell_width = 0.0
    max_abs_Q = 0.0
    sum_abs_cell_area = 0.0
    total_abs_Q_area = 0.0

    for k in range(N0, N1):
        lo = float(roots[k - 1])
        hi = float(roots[k])
        E, W = nodes(lo, hi, q)
        F = np.asarray(phase.F(E), float)
        Fp = np.asarray(phase.Fprime(E), float)
        Q = F - float(k)

        cell_area = float(np.sum(W * Q))
        cell_abs_area = float(np.sum(W * np.abs(Q)))
        cum_before = cumQ
        cumQ += cell_area

        max_abs_cum_boundary = max(
            max_abs_cum_boundary, abs(cum_before), abs(cumQ)
        )
        max_cell_width = max(max_cell_width, hi - lo)
        max_abs_Q = max(max_abs_Q, float(np.max(np.abs(Q))))
        sum_abs_cell_area += abs(cell_area)
        total_abs_Q_area += cell_abs_area

        for m in range(1, moment_order + 1):
            p = 2 * m
            g = E ** (-p)
            gp = -p * E ** (-p - 1)
            Jmom[m - 1] += float(np.sum(W * g * Fp))
            Qgpmom[m - 1] += float(np.sum(W * Q * gp))

        for a in aprobes:
            aa = complex(a)
            g = 1.0 / (E * E + aa * aa)
            gp = -2.0 * E / (E * E + aa * aa) ** 2
            Jres[a] += complex(np.sum(W * g * Fp))
            Qgpres[a] += complex(np.sum(W * Q * gp))

        cell_rows.append(
            {
                "cell_k": k,
                "lo": lo,
                "hi": hi,
                "width": hi - lo,
                "Q_area": cell_area,
                "abs_Q_area": cell_abs_area,
                "cum_Q_area_before": cum_before,
                "cum_Q_area_after": cumQ,
                "max_abs_Q_nodes": float(np.max(np.abs(Q))),
                "min_Fprime_nodes": float(np.min(Fp)),
                "max_Fprime_nodes": float(np.max(Fp)),
            }
        )

    # Exact identity prediction.
    midpoint_mom = np.asarray(
        [
            -0.5 * E0 ** (-2 * m) + 0.5 * E1 ** (-2 * m)
            for m in range(1, moment_order + 1)
        ],
        float,
    )
    pred_exact_mom = Jmom + midpoint_mom + Qgpmom
    pred_mid_mom = Jmom + midpoint_mom

    # Empirical local B2 surrogate only.
    b2_block = np.asarray(
        [
            b2_tail_moment(phase, E0, m) - b2_tail_moment(phase, E1, m)
            for m in range(1, moment_order + 1)
        ],
        float,
    )
    pred_b2_mom = pred_mid_mom + b2_block

    # If |Q|<=Qmax, a completely elementary within-cell primitive bound is:
    # sup|A| <= max boundary cumulative + Qmax * max cell width.
    primitive_bound = max_abs_cum_boundary + max_abs_Q * max_cell_width

    result = {
        "E0": E0,
        "E1": E1,
        "exact_mom": exact_mom,
        "Jmom": Jmom,
        "Qgpmom": Qgpmom,
        "midpoint_mom": midpoint_mom,
        "pred_exact_mom": pred_exact_mom,
        "pred_mid_mom": pred_mid_mom,
        "b2_block": b2_block,
        "pred_b2_mom": pred_b2_mom,
        "exact_res": exact_res,
        "Jres": Jres,
        "Qgpres": Qgpres,
        "cum_Q_area_end": cumQ,
        "max_abs_cum_Q_boundary": max_abs_cum_boundary,
        "primitive_bound": primitive_bound,
        "max_abs_Q": max_abs_Q,
        "max_cell_width": max_cell_width,
        "sum_abs_cell_Q_area": sum_abs_cell_area,
        "total_abs_Q_area": total_abs_Q_area,
        "cell_rows": cell_rows,
    }

    # Resolvent identities and midpoint-only predictions.
    result["res_rows"] = {}
    for a in aprobes:
        aa = complex(a)
        mid = (
            -0.5 / (E0 * E0 + aa * aa)
            + 0.5 / (E1 * E1 + aa * aa)
        )
        pred_mid = Jres[a] + mid
        pred_exact = pred_mid + Qgpres[a]
        result["res_rows"][a] = {
            "exact": exact_res[a],
            "J": Jres[a],
            "midpoint": mid,
            "Qgp": Qgpres[a],
            "pred_mid": pred_mid,
            "pred_exact": pred_exact,
        }

    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depths", default="48,64,96,128")
    ap.add_argument("--moment-order", type=int, default=4)
    ap.add_argument("--a-probes", default="2,5,10")
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=384)
    ap.add_argument("--counter-qcheck", type=int, default=768)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--cell-q", type=int, default=64)
    ap.add_argument("--cell-qcheck", type=int, default=128)
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_staircase_block_primitive_v111",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    depths = parse_ints(args.depths)
    aprobes = [complex(a, 0.0) for a in parse_floats(args.a_probes)]
    max_depth = depths[-1]

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("=" * 158)
    print("ROT-RH v111 — EXACT STAIRCASE BLOCK CORRECTION / PRIMITIVE AUDIT")
    print("=" * 158)
    print("L ladder                        :", Ls)
    print("depth ladder                    :", depths)
    print("moment order                    :", args.moment_order)
    print("resolvent probes                :", [a.real for a in aprobes])
    print("cell quadrature                 :", args.cell_q)
    print("independent cell-q check        :", args.cell_qcheck)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 158)

    block_rows = []
    cell_rows_all = []
    phase_rows = []

    for L in Ls:
        print(f"[L={L}] build {max_depth} roots and staircase blocks", flush=True)
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        support = v102.ordered_support(
            phase,
            depth=max_depth,
            scan_points=int(args.scan_points),
            qcheck=int(args.counter_qcheck),
        )
        roots = np.asarray(support.roots, float)

        phase_rows.append(
            {
                "L": L,
                "E1": roots[0],
                "Emax": roots[-1],
                "max_root_residual": float(np.max(support.residuals)),
                "min_local_Fprime": support.min_local_Fprime,
                "qphase": support.quadrature_phase_rel_l2,
                "qder": support.quadrature_deriv_rel_l2,
            }
        )

        print(
            f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
            f"maxres={np.max(support.residuals):.2e}"
        )

        for N0, N1 in zip(depths[:-1], depths[1:]):
            r = block_audit(
                phase, roots, N0, N1,
                args.cell_q, args.moment_order, aprobes
            )
            rc = block_audit(
                phase, roots, N0, N1,
                args.cell_qcheck, args.moment_order, aprobes
            )

            exact = rc["exact_mom"]
            identity_rel = float(
                np.linalg.norm(rc["pred_exact_mom"] - exact)
                / max(np.linalg.norm(exact), EPS)
            )
            mid_rel = float(
                np.linalg.norm(rc["pred_mid_mom"] - exact)
                / max(np.linalg.norm(exact), EPS)
            )
            b2_rel = float(
                np.linalg.norm(rc["pred_b2_mom"] - exact)
                / max(np.linalg.norm(exact), EPS)
            )
            qcorr_rel = float(
                np.linalg.norm(rc["Qgpmom"])
                / max(np.linalg.norm(exact), EPS)
            )
            qcheck_diff = float(
                np.linalg.norm(r["Qgpmom"] - rc["Qgpmom"])
                / max(np.linalg.norm(rc["Qgpmom"]), EPS)
            )

            row = {
                "L": L,
                "N_from": N0,
                "N_to": N1,
                "E_from": rc["E0"],
                "E_to": rc["E1"],
                "exact_identity_rel_L2": identity_rel,
                "midpoint_only_rel_L2": mid_rel,
                "B2_surrogate_rel_L2": b2_rel,
                "staircase_correction_rel_size": qcorr_rel,
                "staircase_qcheck_rel_difference": qcheck_diff,
                "cum_Q_area_end": rc["cum_Q_area_end"],
                "max_abs_cum_Q_boundary": rc["max_abs_cum_Q_boundary"],
                "primitive_bound": rc["primitive_bound"],
                "max_abs_Q": rc["max_abs_Q"],
                "max_cell_width": rc["max_cell_width"],
                "sum_abs_cell_Q_area": rc["sum_abs_cell_Q_area"],
                "total_abs_Q_area": rc["total_abs_Q_area"],
            }

            for m in range(1, args.moment_order + 1):
                p = 2 * m
                bound = (
                    rc["primitive_bound"]
                    * p
                    * rc["E0"] ** (-p - 1)
                )
                row[f"S{m}_exact"] = exact[m - 1]
                row[f"S{m}_Qgp"] = rc["Qgpmom"][m - 1]
                row[f"S{m}_mid_relerr"] = relerr(
                    rc["pred_mid_mom"][m - 1], exact[m - 1]
                )
                row[f"S{m}_B2_relerr"] = relerr(
                    rc["pred_b2_mom"][m - 1], exact[m - 1]
                )
                row[f"S{m}_exact_identity_relerr"] = relerr(
                    rc["pred_exact_mom"][m - 1], exact[m - 1]
                )
                row[f"S{m}_primitive_bound"] = bound
                row[f"S{m}_Qgp_over_primitive_bound"] = (
                    abs(rc["Qgpmom"][m - 1]) / max(bound, EPS)
                )

            for a in aprobes:
                rr = rc["res_rows"][a]
                row[f"R_a{a.real:g}_mid_relerr"] = relerr(
                    rr["pred_mid"], rr["exact"]
                )
                row[f"R_a{a.real:g}_exact_identity_relerr"] = relerr(
                    rr["pred_exact"], rr["exact"]
                )
                row[f"R_a{a.real:g}_Qgp_abs"] = abs(rr["Qgp"])

            block_rows.append(row)

            for cr in rc["cell_rows"]:
                cell_rows_all.append(
                    {
                        "L": L,
                        "N_from": N0,
                        "N_to": N1,
                        **cr,
                    }
                )

            print(
                f"  {N0}->{N1}: identity={identity_rel:.2e} "
                f"mid={mid_rel:.3e} B2={b2_rel:.3e} "
                f"|Q|max={rc['max_abs_Q']:.6f} "
                f"max|A_boundary|={rc['max_abs_cum_Q_boundary']:.3e}"
            )

    finalL = Ls[-1]
    final = [r for r in block_rows if r["L"] == finalL]

    max_identity = max(r["exact_identity_rel_L2"] for r in final)
    max_qcheck = max(r["staircase_qcheck_rel_difference"] for r in final)
    max_q = max(r["max_abs_Q"] for r in final)
    max_primitive = max(r["max_abs_cum_Q_boundary"] for r in final)
    max_b2 = max(r["B2_surrogate_rel_L2"] for r in final)
    max_mid = max(r["midpoint_only_rel_L2"] for r in final)

    gates = {
        "deep_roots_valid":
            all(r["max_root_residual"] < 1e-8 for r in phase_rows),
        "counterterm_quadrature_stable":
            all(r["qphase"] < 5e-6 and r["qder"] < 5e-6 for r in phase_rows),
        "exact_staircase_identity_closes":
            max_identity < 1e-8,
        "staircase_integral_qcheck_stable":
            max_qcheck < 1e-7,
        "half_cell_band_observed":
            max_q < 0.501,
        "primitive_boundary_stays_O1":
            max_primitive < 10.0,
    }

    verdict = (
        "PASS_V111_EXACT_STAIRCASE_BLOCK_IDENTITY_AND_BOUNDED_PRIMITIVE_SUPPORTED__"
        "NEXT_PROVE_UNIFORM_HALF_CELL_AND_PRIMITIVE_BOUNDS"
        if all(gates.values())
        else "PARTIAL_V111_STAIRCASE_PRIMITIVE_THEOREM_NOT_YET_SUPPORTED"
    )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)
    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows_all)
    write_csv(Path(str(prefix) + "_PHASE.csv"), phase_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "gates": gates,
        "final_L": finalL,
        "final_max_exact_identity_rel_L2": max_identity,
        "final_max_staircase_qcheck_rel_difference": max_qcheck,
        "final_max_abs_Q": max_q,
        "final_max_abs_cum_Q_boundary": max_primitive,
        "final_max_midpoint_only_rel_L2": max_mid,
        "final_max_B2_surrogate_rel_L2": max_b2,
        "theorem_target": (
            "Prove on every sufficiently high selected cell that "
            "|F_L(E)-N_L(E)|<=1/2 (or a uniform constant) and that the first "
            "primitive of this centered staircase discrepancy remains "
            "uniformly bounded. Then the exact staircase correction gains "
            "an extra inverse-energy power without requiring a global inverse "
            "or monotonicity."
        ),
    }
    vp = Path(str(prefix) + "_VERDICT.json")
    vp.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("FINAL v111 VERDICT")
    print("=" * 158)
    print("verdict                         :", verdict)
    print("final max exact identity relL2  :", f"{max_identity:.12e}")
    print("final max Q-integral qcheck     :", f"{max_qcheck:.12e}")
    print("final max |F-N|                 :", f"{max_q:.12e}")
    print("final max |cum integral Q|      :", f"{max_primitive:.12e}")
    print("final max midpoint-only relL2   :", f"{max_mid:.12e}")
    print("final max B2-surrogate relL2    :", f"{max_b2:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", vp)
    print("=" * 158)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
