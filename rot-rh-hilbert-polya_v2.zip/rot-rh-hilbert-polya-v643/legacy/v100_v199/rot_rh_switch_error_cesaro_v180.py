#!/usr/bin/env python3
"""
ROT-RH v180 — SWITCH ERROR / CESARO REDUCTION AUDIT

Goal
----
Attack the exact error term in the proposed infinite-switch reduction

    (tau E(tau))' = gamma_active(tau) + epsilon(tau).

If the accumulated error obeys

    (1/tau) * int epsilon(u) du = o(1)

(or is negligible relative to the active-ordinate Cesaro mean), then an
unbounded nondecreasing active ordinate forces E(tau) to diverge.

This script does NOT use Xi, zeta, or known zero ordinates.

Method
------
Input:
  * candidate synthetic zero layers CSV (beta,gamma)
  * active-hull CSV from v169/v171

For every adjacent active-hull pair:
  1. identify the left/right dominant synthetic layers;
  2. build the exact two-layer Gamma phase with conjugates + functional mirrors;
  3. resolve a local root branch through the switch at arbitrary precision;
  4. use Newton-only continuation with a strict fraction-of-root-spacing gate;
  5. compute along that branch

         epsilon = tau*E'(tau) + E(tau) - gamma_active(tau)
                 = -tau*S_tau/S_E + E - gamma_active;

  6. integrate epsilon across the switch window;
  7. compare its contribution with the active-gamma integral.

The script also computes the exact piecewise-active reduced solution

    E_red(tau) = [tau0*E0 + int_{tau0}^tau gamma_active(u) du] / tau

directly from the hull, so the switch-error budget can be compared with the
leading Cesaro term.

Interpretation
--------------
SWITCH_ERROR_CESARO_NEGLIGIBLE
    Local exact switch errors remain small enough that their accumulated
    contribution is negligible relative to the active-gamma integral on the
    audited hull. This supports the theorem-shaped reduction.

SWITCH_ERROR_NOT_NEGLIGIBLE
    Transition errors are too large to discard; the infinite-switch argument
    needs a sharper analytic treatment.

SWITCH_CONTINUATION_UNRESOLVED
    At least one switch cannot be followed under the no-hopping gate.

Outputs
-------
<prefix>_SWITCHES.csv
<prefix>_SAMPLES.csv
<prefix>_HULL_REDUCED.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def mpf(x):
    return mp.mpf(str(float(x)))


class TwoLayerPhase:
    """Exact two-layer synthetic Gamma phase with all four zeta symmetries."""

    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b - mp.mpf("0.5")

            # rho, conjugate, 1-rho, conjugate mirror
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def eval(self, E, tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws = []
        logs = []
        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        S = mp.im(mp.fsum(zs))

        dE_terms = []
        dt_terms = []
        for w, z in zip(ws, zs):
            psi = mp.digamma(w)
            dE_terms.append(1j*(psi+tau)*z)
            dt_terms.append(w*z)

        SE = mp.im(mp.fsum(dE_terms))
        St = mp.im(mp.fsum(dt_terms))
        return S, SE, St

    def flow_u(self, E, tau):
        S, SE, St = self.eval(E, tau)
        if abs(SE) == 0 or not mp.isfinite(SE):
            raise ArithmeticError("S_E zero/nonfinite")
        # u = log(tau)
        return -tau*St/SE


def newton_project(phase, E0, tau, tol, spacing_fraction, iterations):
    E = mp.mpf(E0)
    tau = mp.mpf(tau)
    spacing = mp.pi/tau
    max_ratio = mp.mpf("0")
    total = mp.mpf("0")

    for _ in range(iterations):
        S, SE, St = phase.eval(E, tau)

        if abs(S) <= tol:
            return {
                "ok": True,
                "E": E,
                "residual": abs(S),
                "abs_SE": abs(SE),
                "max_step_ratio": max_ratio,
                "total_ratio": abs(total)/spacing,
            }

        if abs(SE) == 0 or not mp.isfinite(SE):
            return {"ok": False, "reason": "SE_zero_or_nonfinite"}

        step = -S/SE
        ratio = abs(step)/spacing

        if ratio > spacing_fraction:
            return {
                "ok": False,
                "reason": "projection_step_exceeds_gate",
                "step_ratio": ratio,
                "residual": abs(S),
                "abs_SE": abs(SE),
            }

        E += step
        total += step
        max_ratio = max(max_ratio, ratio)

    S, SE, St = phase.eval(E, tau)
    return {
        "ok": bool(abs(S) <= tol),
        "reason": "newton_no_convergence",
        "E": E,
        "residual": abs(S),
        "abs_SE": abs(SE),
        "max_step_ratio": max_ratio,
        "total_ratio": abs(total)/spacing,
    }


def nearest_initial_root(
    phase,
    tau,
    center,
    tol,
    spacing_fraction,
    iterations,
    search_cells,
):
    """
    Find one initial local root near 'center'. This is used only once per
    independent switch window. It never acts as a continuation fallback.

    We seed Newton at half-cell offsets around center and choose the successful
    root closest to center.
    """
    tau = mp.mpf(tau)
    center = mp.mpf(center)
    spacing = mp.pi/tau

    roots = []
    half = int(search_cells)

    for j in range(-half, half+1):
        seed = center + mp.mpf(j)*spacing/2
        p = newton_project(
            phase, seed, tau, tol,
            spacing_fraction, iterations
        )
        if p["ok"]:
            roots.append(p)

    if not roots:
        return {"ok": False, "reason": "no_initial_local_root"}

    roots.sort(key=lambda r: abs(r["E"]-center))
    return roots[0]


def rk4_predict(phase, E0, tau0, tau1):
    u0 = mp.log(tau0)
    u1 = mp.log(tau1)
    h = u1-u0

    def f(E, u):
        t = mp.exp(u)
        return phase.flow_u(E, t)

    k1 = f(E0, u0)
    k2 = f(E0+h*k1/2, u0+h/2)
    k3 = f(E0+h*k2/2, u0+h/2)
    k4 = f(E0+h*k3, u1)

    return E0 + h*(k1+2*k2+2*k3+k4)/6


def continue_grid(
    phase,
    tau_grid,
    E0,
    tol,
    spacing_fraction,
    iterations,
):
    rows = []
    E = mp.mpf(E0)

    for i, tau in enumerate(tau_grid):
        tau = mp.mpf(tau)

        if i == 0:
            p = newton_project(
                phase, E, tau, tol, spacing_fraction, iterations
            )
        else:
            tprev = mp.mpf(tau_grid[i-1])
            try:
                pred = rk4_predict(phase, E, tprev, tau)
            except Exception as exc:
                return {
                    "ok": False,
                    "reason": f"rk4_failure:{exc}",
                    "rows": rows,
                }

            p = newton_project(
                phase, pred, tau, tol, spacing_fraction, iterations
            )

        if not p["ok"]:
            return {
                "ok": False,
                "reason": p.get("reason", "projection_failure"),
                "rows": rows,
                "failure_index": i,
                "failure_tau": float(tau),
            }

        E = p["E"]
        S, SE, St = phase.eval(E, tau)
        E_u = -tau*St/SE  # dE/du = tau dE/dtau

        rows.append({
            "tau": float(tau),
            "E": float(E),
            "residual": float(abs(S)),
            "abs_SE": float(abs(SE)),
            "E_u": float(E_u),
            "max_projection_over_spacing": float(
                max(p["max_step_ratio"], p["total_ratio"])
            ),
        })

    return {"ok": True, "E": E, "rows": rows}


def match_candidate(cand, beta, gamma):
    """Nearest candidate in (gamma,beta); gamma dominates the match."""
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)

    scale_g = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale_g + 1e-3*np.abs(b-float(beta))
    idx = int(np.argmin(score))
    return cand.iloc[idx]


def active_gamma_on_two_layer_switch(tau, tau_switch, g_left, g_right):
    return g_left if tau <= tau_switch else g_right


def trapz(x, y):
    return float(np.trapz(np.asarray(y, float), np.asarray(x, float)))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)

    ap.add_argument("--dps", type=int, default=70)
    ap.add_argument("--tol-exp", type=int, default=40)
    ap.add_argument("--newton-iters", type=int, default=14)
    ap.add_argument(
        "--projection-spacing-fraction",
        type=float,
        default=0.20,
    )

    ap.add_argument(
        "--switch-log-halfwidth",
        type=float,
        default=0.35,
        help="Audit tau in [tau_s*exp(-w), tau_s*exp(+w)].",
    )
    ap.add_argument(
        "--points-per-switch",
        type=int,
        default=257,
    )
    ap.add_argument(
        "--initial-search-cells",
        type=int,
        default=8,
    )
    ap.add_argument(
        "--max-switches",
        type=int,
        default=0,
        help="0 means all hull switches.",
    )

    ap.add_argument(
        "--relative-error-gate",
        type=float,
        default=0.05,
        help="Total |switch error integral| / total active-gamma integral.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_switch_error_cesaro_v180",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    spacing_fraction = mp.mpf(str(args.projection_spacing_fraction))

    cand = pd.read_csv(args.candidates_csv)
    hull = pd.read_csv(args.hull_csv)

    need_c = {"beta", "gamma"}
    if not need_c.issubset(cand.columns):
        raise RuntimeError(f"Candidates CSV must contain {sorted(need_c)}.")

    # Expected hull schema from v169/v171.
    required_h = {"tau_start", "tau_end", "gamma_active", "beta_active"}
    if not required_h.issubset(hull.columns):
        raise RuntimeError(
            "Hull CSV must contain tau_start,tau_end,gamma_active,beta_active."
        )

    hull = hull.sort_values("tau_start").reset_index(drop=True)

    nsw = max(0, len(hull)-1)
    if args.max_switches > 0:
        nsw = min(nsw, args.max_switches)

    print("="*170)
    print("ROT-RH v180 — SWITCH ERROR / CESARO REDUCTION AUDIT")
    print("="*170)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"active hull segments              : {len(hull)}")
    print(f"switches audited                  : {nsw}")
    print(f"mpmath dps                        : {args.dps}")
    print(f"points per switch                 : {args.points_per_switch}")
    print(f"switch log halfwidth              : {args.switch_log_halfwidth}")
    print(f"projection gate                   : {args.projection_spacing_fraction} * pi/tau")
    print("="*170)

    switch_rows = []
    sample_rows = []

    continuation_failures = 0
    total_abs_eps_integral = 0.0
    total_signed_eps_integral = 0.0
    total_active_integral = 0.0

    for j in range(nsw):
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        tau_s = float(left["tau_end"])
        g1 = float(left["gamma_active"])
        b1 = float(left["beta_active"])
        g2 = float(right["gamma_active"])
        b2 = float(right["beta_active"])

        c1 = match_candidate(cand, b1, g1)
        c2 = match_candidate(cand, b2, g2)

        b1 = float(c1["beta"]); g1 = float(c1["gamma"])
        b2 = float(c2["beta"]); g2 = float(c2["gamma"])

        phase = TwoLayerPhase(b1, g1, b2, g2)

        w = float(args.switch_log_halfwidth)
        t0 = tau_s*math.exp(-w)
        t1 = tau_s*math.exp(+w)

        tau_grid = np.geomspace(t0, t1, args.points_per_switch)

        # Start on the left-dominant branch near gamma_left.
        init = nearest_initial_root(
            phase,
            mpf(t0),
            mpf(g1),
            tol,
            spacing_fraction,
            args.newton_iters,
            args.initial_search_cells,
        )

        if not init["ok"]:
            continuation_failures += 1
            switch_rows.append({
                "switch": j+1,
                "tau_switch": tau_s,
                "gamma_left": g1,
                "gamma_right": g2,
                "status": "INITIAL_ROOT_UNRESOLVED",
            })
            print(
                f"[switch {j+1:4d}/{nsw}] tau={tau_s:.4e} "
                f"g:{g1:.4e}->{g2:.4e} INITIAL ROOT FAIL"
            )
            continue

        cont = continue_grid(
            phase,
            [mpf(t) for t in tau_grid],
            init["E"],
            tol,
            spacing_fraction,
            args.newton_iters,
        )

        if not cont["ok"]:
            continuation_failures += 1
            switch_rows.append({
                "switch": j+1,
                "tau_switch": tau_s,
                "gamma_left": g1,
                "gamma_right": g2,
                "status": "SWITCH_CONTINUATION_UNRESOLVED",
                "reason": cont.get("reason", ""),
                "failure_tau": cont.get("failure_tau", np.nan),
            })
            print(
                f"[switch {j+1:4d}/{nsw}] tau={tau_s:.4e} "
                f"g:{g1:.4e}->{g2:.4e} CONTINUATION FAIL"
            )
            continue

        rows = cont["rows"]

        taus = np.asarray([r["tau"] for r in rows], float)
        Es = np.asarray([r["E"] for r in rows], float)
        Eus = np.asarray([r["E_u"] for r in rows], float)

        # epsilon in d(tau E)/d tau:
        # d(tau E)/d tau = E + tau E' = E + dE/du.
        gact = np.where(taus <= tau_s, g1, g2)
        eps = Es + Eus - gact

        # Integrals in d tau, because the reduction is
        # tau E = const + integral gamma_active(tau) d tau + integral eps d tau.
        eps_signed = trapz(taus, eps)
        eps_abs = trapz(taus, np.abs(eps))
        active_int = trapz(taus, gact)

        rel_signed = eps_signed/max(abs(active_int), 1e-300)
        rel_abs = eps_abs/max(abs(active_int), 1e-300)

        total_signed_eps_integral += eps_signed
        total_abs_eps_integral += eps_abs
        total_active_integral += active_int

        max_eps_rel_gamma = float(
            np.max(np.abs(eps)/np.maximum(np.abs(gact), 1.0))
        )
        max_proj = max(r["max_projection_over_spacing"] for r in rows)
        min_se = min(r["abs_SE"] for r in rows)

        switch_rows.append({
            "switch": j+1,
            "tau_switch": tau_s,
            "beta_left": b1,
            "gamma_left": g1,
            "beta_right": b2,
            "gamma_right": g2,
            "E_start": float(Es[0]),
            "E_switch_nearest": float(
                Es[int(np.argmin(np.abs(taus-tau_s)))]
            ),
            "E_end": float(Es[-1]),
            "signed_epsilon_integral": eps_signed,
            "absolute_epsilon_integral": eps_abs,
            "active_gamma_integral": active_int,
            "signed_error_over_active": rel_signed,
            "absolute_error_over_active": rel_abs,
            "max_abs_epsilon_over_gamma": max_eps_rel_gamma,
            "min_abs_SE": min_se,
            "max_projection_over_spacing": max_proj,
            "status": "PASS",
        })

        for k, r in enumerate(rows):
            sample_rows.append({
                "switch": j+1,
                **r,
                "gamma_active_local": float(gact[k]),
                "epsilon": float(eps[k]),
                "abs_epsilon_over_gamma": float(
                    abs(eps[k])/max(abs(gact[k]), 1.0)
                ),
            })

        print(
            f"[switch {j+1:4d}/{nsw}] "
            f"tau={tau_s:.4e} "
            f"g:{g1:.4e}->{g2:.4e} "
            f"|Int eps|/Int g={rel_abs:.3e} "
            f"max|eps|/g={max_eps_rel_gamma:.3e} "
            f"proj={max_proj:.3e}"
        )

    # ------------------------------------------------------------------
    # Exact reduced hull solution / Cesaro active ordinate
    # ------------------------------------------------------------------
    reduced_rows = []
    if len(hull):
        tau0 = float(hull.iloc[0]["tau_start"])
        E0 = float(hull.iloc[0]["gamma_active"])
        accum = tau0*E0

        for _, seg in hull.iterrows():
            a = float(seg["tau_start"])
            b = float(seg["tau_end"])
            g = float(seg["gamma_active"])

            if b <= a:
                continue

            accum += g*(b-a)
            Ered = accum/b

            reduced_rows.append({
                "tau": b,
                "gamma_active": g,
                "E_reduced": Ered,
                "active_integral_accum": accum - tau0*E0,
            })

    total_rel_abs = (
        total_abs_eps_integral/max(abs(total_active_integral), 1e-300)
        if total_active_integral != 0 else np.inf
    )
    total_rel_signed = (
        total_signed_eps_integral/max(abs(total_active_integral), 1e-300)
        if total_active_integral != 0 else np.inf
    )

    if continuation_failures:
        verdict = "SWITCH_CONTINUATION_UNRESOLVED"
    elif total_rel_abs <= args.relative_error_gate:
        verdict = "SWITCH_ERROR_CESARO_NEGLIGIBLE"
    else:
        verdict = "SWITCH_ERROR_NOT_NEGLIGIBLE"

    sw = pd.DataFrame(switch_rows)
    sm = pd.DataFrame(sample_rows)
    red = pd.DataFrame(reduced_rows)

    sw.to_csv(args.prefix+"_SWITCHES.csv", index=False)
    sm.to_csv(args.prefix+"_SAMPLES.csv", index=False)
    red.to_csv(args.prefix+"_HULL_REDUCED.csv", index=False)

    summary = {
        "version": 180,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "switches_requested": nsw,
        "switches_completed": int(
            sum(1 for r in switch_rows if r.get("status") == "PASS")
        ),
        "continuation_failures": continuation_failures,
        "total_signed_epsilon_integral": total_signed_eps_integral,
        "total_absolute_epsilon_integral": total_abs_eps_integral,
        "total_active_gamma_integral": total_active_integral,
        "total_signed_error_over_active": total_rel_signed,
        "total_absolute_error_over_active": total_rel_abs,
        "relative_error_gate": args.relative_error_gate,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*170)
    print(f"switches completed                 : {summary['switches_completed']}/{nsw}")
    print(f"continuation failures              : {continuation_failures}")
    print(f"total signed eps / active          : {total_rel_signed:.6e}")
    print(f"total absolute eps / active        : {total_rel_abs:.6e}")
    print(f"gate                               : {args.relative_error_gate:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*170)

    if verdict == "SWITCH_ERROR_CESARO_NEGLIGIBLE":
        print("CONSEQUENCE:")
        print("  On the audited adversarial hull, exact local Gamma-phase transition")
        print("  errors are small relative to the leading active-ordinate integral.")
        print("  This supports the reduction (tau E)' = gamma_active + negligible error.")
    elif verdict == "SWITCH_ERROR_NOT_NEGLIGIBLE":
        print("CONSEQUENCE:")
        print("  Switch corrections are not negligible at the tested scale. The")
        print("  infinite-switch proposition needs a sharper transition estimate.")
    else:
        print("ACTION:")
        print("  Inspect the first unresolved switch before drawing a Cesaro conclusion.")


if __name__ == "__main__":
    main()
