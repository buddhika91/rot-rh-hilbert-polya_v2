#!/usr/bin/env python3
"""
ROT-RH v132 — TRACE-NORM CUTOFF REMOVAL / CAUCHY AUDIT

Purpose
-------
Attack the cutoff-removal theorem target directly for the canonical diagonal
fixed-cutoff operator

    H_L e_k = E_k(L) e_k,
    K_L     = H_L^{-2},

where the ordered zero-blind energies satisfy

    F_L^FP(E_k(L)) = k - 1/2.

For two cutoffs L_a < L_b, because all H_L are represented on the same
canonical ordered basis {e_k},

    ||K_Lb - K_La||_1
      = sum_{k>=1} | 1/E_k(L_b)^2 - 1/E_k(L_a)^2 |.

The theorem target is summability along a geometric cutoff sequence:

    sum_j ||K_{L_{j+1}} - K_{L_j}||_1 < infinity.

This script is deliberately harder than a signed-shell test:
absolute values are taken BEFORE summing over k, so cross-k cancellation
cannot fake trace-norm convergence.

NO Xi, zeta, or known-zero data are used anywhere.

Required upstream API
---------------------
The v102.1 module must expose:

    RenormalizedPhase.build(base, L, tail_factor, q)
    ordered_support(phase, depth=..., scan_points=..., qcheck=...)

and ordered_support(...) must return an object with at least:

    roots
    residuals
    quadrature_phase_rel_l2
    quadrature_deriv_rel_l2

This matches:
    rot_rh_pnt_finite_part_full_pipeline_v102_1.py

Main outputs
------------
<prefix>_L_SUPPORT.csv
<prefix>_INTERVALS.csv
<prefix>_DEPTH.csv
<prefix>_DOUBLING_BLOCKS.csv
<prefix>_DETERMINANT_BOUNDS.csv
<prefix>_ROOTS.npz
<prefix>_VERDICT.json

Interpretation
--------------
A numerical PASS here is NOT a proof of cutoff removal. It is evidence for
the precise theorem one would next need to prove analytically. The script
tries to falsify convergence through:

  * exact finite-depth trace norms,
  * root-residual uncertainty inflation,
  * depth saturation,
  * dyadic spectral-shell ratios,
  * conservative empirical k-tail extrapolation,
  * per-doubling cutoff variation,
  * power-law and log-power summability fits,
  * early/late stability,
  * determinant continuity bounds.

Author: ROT-RH program
Version: 132
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def finite(x) -> bool:
    return bool(np.isfinite(x))


def safe_float(x, default=float("nan")) -> float:
    try:
        y = float(x)
        return y if np.isfinite(y) else default
    except Exception:
        return default


def write_csv(path: Path, rows: List[dict]) -> None:
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def geometric_L_grid(L_start: int, L_end: int, steps_per_doubling: int) -> List[int]:
    if L_start <= 0 or L_end <= L_start:
        raise ValueError("Require 0 < L_start < L_end.")
    if steps_per_doubling < 1:
        raise ValueError("steps_per_doubling must be >= 1.")

    out = []
    j = 0
    while True:
        x = L_start * (2.0 ** (j / steps_per_doubling))
        L = int(round(x))
        if L > L_end:
            break
        if not out or L > out[-1]:
            out.append(L)
        j += 1

    if out[-1] != L_end:
        # Include endpoint if it is close to geometric ladder or explicitly requested.
        if L_end > out[-1]:
            out.append(int(L_end))
    return out


def linfit(x: np.ndarray, y: np.ndarray) -> dict:
    """OLS y = a + b x with R^2 and AIC (up to additive constant)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]
    y = y[m]
    n = len(x)
    if n < 3 or np.ptp(x) <= 0:
        return dict(n=n, intercept=np.nan, slope=np.nan, r2=np.nan, aic=np.nan)

    X = np.vstack([np.ones(n), x]).T
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    resid = y - pred
    sse = float(np.dot(resid, resid))
    sst = float(np.dot(y - np.mean(y), y - np.mean(y)))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0
    sigma2 = max(sse / n, np.finfo(float).tiny)
    aic = n * math.log(sigma2) + 2 * 2
    return dict(
        n=n,
        intercept=float(beta[0]),
        slope=float(beta[1]),
        r2=float(r2),
        aic=float(aic),
    )


def robust_median_ratio(vals: np.ndarray) -> float:
    vals = np.asarray(vals, float)
    vals = vals[np.isfinite(vals) & (vals > 0)]
    if len(vals) < 2:
        return float("nan")
    return float(np.median(vals[1:] / vals[:-1]))


# ---------------------------------------------------------------------------
# Upstream operator support
# ---------------------------------------------------------------------------

@dataclass
class LSupport:
    L: int
    roots: np.ndarray
    residuals: np.ndarray
    fprime: np.ndarray
    lambda_vals: np.ndarray
    lambda_err: np.ndarray
    min_abs_fprime: float
    max_abs_residual: float
    quad_phase_rel_l2: float
    quad_deriv_rel_l2: float
    elapsed_sec: float
    from_cache: bool


def cache_path(prefix: str, L: int, max_depth: int) -> Path:
    return Path(f"{prefix}_CACHE_L{L}_D{max_depth}.npz")


def load_cached_support(path: Path, L: int) -> LSupport | None:
    if not path.exists():
        return None
    try:
        z = np.load(path)
        roots = np.asarray(z["roots"], float)
        residuals = np.asarray(z["residuals"], float)
        fprime = np.asarray(z["fprime"], float)
        lam = np.asarray(z["lambda_vals"], float)
        lam_err = np.asarray(z["lambda_err"], float)
        return LSupport(
            L=L,
            roots=roots,
            residuals=residuals,
            fprime=fprime,
            lambda_vals=lam,
            lambda_err=lam_err,
            min_abs_fprime=safe_float(z["min_abs_fprime"]),
            max_abs_residual=safe_float(z["max_abs_residual"]),
            quad_phase_rel_l2=safe_float(z["quad_phase_rel_l2"]),
            quad_deriv_rel_l2=safe_float(z["quad_deriv_rel_l2"]),
            elapsed_sec=0.0,
            from_cache=True,
        )
    except Exception:
        return None


def save_cached_support(path: Path, s: LSupport) -> None:
    np.savez_compressed(
        path,
        roots=s.roots,
        residuals=s.residuals,
        fprime=s.fprime,
        lambda_vals=s.lambda_vals,
        lambda_err=s.lambda_err,
        min_abs_fprime=s.min_abs_fprime,
        max_abs_residual=s.max_abs_residual,
        quad_phase_rel_l2=s.quad_phase_rel_l2,
        quad_deriv_rel_l2=s.quad_deriv_rel_l2,
    )


def build_support(v102, base, args, L: int) -> LSupport:
    cp = cache_path(args.prefix, L, args.max_depth)
    if not args.no_cache:
        cached = load_cached_support(cp, L)
        if cached is not None and len(cached.roots) >= args.max_depth:
            print(f"[L={L:>8}] cache HIT ({len(cached.roots)} roots)")
            return cached

    t0 = time.time()
    print(f"[L={L:>8}] building RenormalizedPhase ...", flush=True)

    # Exact upstream v102.1 usage:
    phase = v102.RenormalizedPhase.build(
        base,
        int(L),
        float(args.tail_factor),
        int(args.counter_q),
    )

    support = v102.ordered_support(
        phase,
        depth=int(args.max_depth),
        scan_points=int(args.scan_points),
        qcheck=int(args.counter_qcheck),
    )

    roots = np.asarray(support.roots[:args.max_depth], dtype=float)
    residuals = np.asarray(support.residuals[:args.max_depth], dtype=float)

    if len(roots) != args.max_depth:
        raise RuntimeError(
            f"L={L}: expected {args.max_depth} ordered roots, got {len(roots)}."
        )
    if np.any(~np.isfinite(roots)) or np.any(roots <= 0):
        raise RuntimeError(f"L={L}: non-finite or non-positive roots found.")
    if np.any(np.diff(roots) <= 0):
        raise RuntimeError(f"L={L}: roots are not strictly increasing.")

    fprime = np.asarray(phase.Fprime(roots), dtype=float)
    abs_fp = np.abs(fprime)
    min_abs_fp = float(np.min(abs_fp))

    # Numerical root-location uncertainty proxy:
    #   |delta E| ~ |F(E)-(k-1/2)| / |F'(E)|.
    # Inflate by user-selected safety factor.
    tiny = np.finfo(float).tiny
    e_err = args.residual_safety * np.abs(residuals) / np.maximum(abs_fp, tiny)

    lam = 1.0 / (roots * roots)

    # First-order propagated uncertainty for lambda = E^{-2}:
    # |d lambda| <= 2 |dE| / E^3, inflated again by safety.
    lam_err = args.residual_safety * (2.0 * e_err / (roots ** 3))

    elapsed = time.time() - t0
    out = LSupport(
        L=int(L),
        roots=roots,
        residuals=residuals,
        fprime=fprime,
        lambda_vals=lam,
        lambda_err=lam_err,
        min_abs_fprime=min_abs_fp,
        max_abs_residual=float(np.max(np.abs(residuals))),
        quad_phase_rel_l2=safe_float(
            getattr(support, "quadrature_phase_rel_l2", np.nan)
        ),
        quad_deriv_rel_l2=safe_float(
            getattr(support, "quadrature_deriv_rel_l2", np.nan)
        ),
        elapsed_sec=float(elapsed),
        from_cache=False,
    )

    if not args.no_cache:
        save_cached_support(cp, out)

    print(
        f"[L={L:>8}] done: "
        f"E1={roots[0]:.12g}, E{len(roots)}={roots[-1]:.12g}, "
        f"max|res|={out.max_abs_residual:.3e}, "
        f"min|F'|={out.min_abs_fprime:.3e}, "
        f"time={elapsed:.1f}s"
    )
    return out


# ---------------------------------------------------------------------------
# Spectral-tail diagnostics in k
# ---------------------------------------------------------------------------

def dyadic_depth_shells(abs_delta_lambda: np.ndarray, depths: List[int]) -> List[dict]:
    rows = []
    prev = 0
    for d in depths:
        if d > len(abs_delta_lambda):
            continue
        shell = float(np.sum(abs_delta_lambda[prev:d]))
        total = float(np.sum(abs_delta_lambda[:d]))
        rows.append(
            dict(
                depth=d,
                shell_start=prev + 1,
                shell_end=d,
                shell_trace=shell,
                partial_trace=total,
                shell_fraction=(shell / total if total > 0 else np.nan),
            )
        )
        prev = d
    return rows


def geometric_k_tail_bound(
    abs_delta_lambda: np.ndarray,
    depths: List[int],
    ratio_gate: float,
) -> dict:
    """
    Conservative empirical tail extrapolation from depth shells.

    If the last two spectral-shell ratios are both < ratio_gate < 1,
    extrapolate the unresolved tail geometrically using the WORST of them.

    This is a numerical diagnostic, not a rigorous theorem.
    """
    shells = dyadic_depth_shells(abs_delta_lambda, depths)
    positive = [r for r in shells if r["shell_trace"] > 0]
    if len(positive) < 3:
        return dict(
            certified=False,
            reason="need >=3 positive depth shells",
            ratio=np.nan,
            tail=np.inf,
        )

    s = np.array([r["shell_trace"] for r in positive], float)
    ratios = s[1:] / s[:-1]
    last_ratios = ratios[-min(2, len(ratios)):]
    worst = float(np.max(last_ratios))

    if not np.isfinite(worst) or worst >= ratio_gate or worst >= 1.0:
        return dict(
            certified=False,
            reason=f"late spectral-shell ratio {worst:.6g} not below gate {ratio_gate}",
            ratio=worst,
            tail=np.inf,
        )

    last_shell = float(s[-1])
    # Future shells: s*r + s*r^2 + ...
    tail = last_shell * worst / max(1.0 - worst, np.finfo(float).eps)
    return dict(
        certified=True,
        reason="empirical geometric spectral-tail extrapolation",
        ratio=worst,
        tail=float(tail),
    )


def power_k_tail_fit(abs_delta_lambda: np.ndarray, windows: int = 4) -> dict:
    """
    Fit |Delta lambda_k| ~ C k^{-alpha} over several late windows.
    Return the most conservative valid alpha/tail among the windows.
    """
    y = np.asarray(abs_delta_lambda, float)
    N = len(y)
    candidates = []

    # progressively larger late fractions: 1/8, 1/6, 1/4, 1/3-ish
    fracs = np.linspace(0.12, 0.35, max(2, windows))
    k_all = np.arange(1, N + 1, dtype=float)

    for frac in fracs:
        start = max(8, int((1.0 - frac) * N))
        k = k_all[start:]
        yy = y[start:]
        m = (yy > 0) & np.isfinite(yy)
        if np.sum(m) < 16:
            continue
        fit = linfit(np.log(k[m]), np.log(yy[m]))
        alpha = -fit["slope"]
        C = math.exp(fit["intercept"]) if np.isfinite(fit["intercept"]) else np.inf

        if alpha > 1.0 and np.isfinite(C):
            # integral upper-style extrapolation for fitted power law
            tail = C * (N ** (1.0 - alpha)) / (alpha - 1.0)
        else:
            tail = np.inf

        candidates.append(
            dict(
                start_k=start + 1,
                alpha=float(alpha),
                C=float(C),
                r2=float(fit["r2"]),
                tail=float(tail),
            )
        )

    if not candidates:
        return dict(alpha=np.nan, r2=np.nan, tail=np.inf, start_k=-1)

    # Conservative: choose the largest finite tail; if any window says divergent,
    # regard the power-tail estimate as uncertified.
    if any(not np.isfinite(c["tail"]) for c in candidates):
        worst_alpha = min(c["alpha"] for c in candidates)
        best_r2 = min(c["r2"] for c in candidates)
        return dict(alpha=worst_alpha, r2=best_r2, tail=np.inf, start_k=-1)

    worst = max(candidates, key=lambda c: c["tail"])
    return worst


# ---------------------------------------------------------------------------
# Cutoff summability in L
# ---------------------------------------------------------------------------

def build_doubling_blocks(interval_rows: List[dict], L_start: int, steps: int) -> List[dict]:
    """
    Aggregate interval upper estimates into one total variation per exact
    factor-of-two block in L.
    """
    blocks: Dict[int, List[dict]] = {}
    for r in interval_rows:
        La = float(r["L_a"])
        if La <= 0:
            continue
        d = int(math.floor(math.log(La / L_start, 2.0) + 1e-12))
        blocks.setdefault(d, []).append(r)

    out = []
    for d in sorted(blocks):
        rr = blocks[d]
        expected_lo = L_start * (2.0 ** d)
        expected_hi = L_start * (2.0 ** (d + 1))

        # Only count intervals whose left endpoint is inside this doubling.
        vals = np.array([x["trace_upper"] for x in rr], float)
        finite_vals = vals[np.isfinite(vals)]

        block_upper = float(np.sum(finite_vals)) if len(finite_vals) == len(vals) else np.inf
        block_partial = float(np.sum([x["trace_partial"] for x in rr]))
        block_unc = float(np.sum([x["trace_uncertainty"] for x in rr]))

        out.append(
            dict(
                doubling_index=d,
                nominal_L_lo=float(expected_lo),
                nominal_L_hi=float(expected_hi),
                intervals=len(rr),
                block_trace_partial=block_partial,
                block_trace_uncertainty=block_unc,
                block_trace_upper=block_upper,
            )
        )
    return out


def summability_fits(block_rows: List[dict], fit_last_doublings: int) -> dict:
    valid = [
        r for r in block_rows
        if np.isfinite(r["block_trace_upper"]) and r["block_trace_upper"] > 0
    ]
    if len(valid) < 3:
        return dict(
            n=len(valid),
            power_p=np.nan, power_r2=np.nan, power_aic=np.nan,
            log_q=np.nan, log_r2=np.nan, log_aic=np.nan,
            median_block_ratio=np.nan,
        )

    if fit_last_doublings > 0:
        valid = valid[-fit_last_doublings:]

    d = np.array([r["doubling_index"] for r in valid], float)
    B = np.array([r["block_trace_upper"] for r in valid], float)

    # Since L ~ 2^d, B ~ L^{-p} means log B = const - p*d*log 2.
    pfit = linfit(d * math.log(2.0), np.log(B))
    p = -pfit["slope"]

    # B_d ~ (d+d0)^(-q). Offset by +1 to avoid log(0).
    qfit = linfit(np.log(d + 1.0), np.log(B))
    q = -qfit["slope"]

    return dict(
        n=len(valid),
        power_p=float(p),
        power_r2=float(pfit["r2"]),
        power_aic=float(pfit["aic"]),
        log_q=float(q),
        log_r2=float(qfit["r2"]),
        log_aic=float(qfit["aic"]),
        median_block_ratio=robust_median_ratio(B),
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
        help="Module exposing RenormalizedPhase and ordered_support.",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
        help="Zero-blind arithmetic base module passed into RenormalizedPhase.build.",
    )

    ap.add_argument("--L-start", type=int, default=4000)
    ap.add_argument("--L-end", type=int, default=128000)
    ap.add_argument("--steps-per-doubling", type=int, default=2)

    ap.add_argument(
        "--depths",
        default="128,256,512,768,1024,1408",
        help="Depths used to test saturation of the trace norm.",
    )
    ap.add_argument("--max-depth", type=int, default=1408)

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--counter-qcheck", type=int, default=16384)
    ap.add_argument("--scan-points", type=int, default=96)

    ap.add_argument(
        "--residual-safety",
        type=float,
        default=4.0,
        help="Inflation factor for root-residual -> eigenvalue uncertainty.",
    )
    ap.add_argument(
        "--spectral-shell-ratio-gate",
        type=float,
        default=0.90,
        help="Late k-shell ratios must be below this for geometric tail extrapolation.",
    )
    ap.add_argument(
        "--spectral-tail-windows",
        type=int,
        default=4,
        help="Number of late windows for power-law k-tail fits.",
    )

    ap.add_argument(
        "--fit-last-doublings",
        type=int,
        default=5,
        help="Number of latest factor-of-two L blocks used in summability fits.",
    )
    ap.add_argument(
        "--power-p-gate",
        type=float,
        default=0.05,
        help="Minimum fitted p for B(L) ~ L^{-p}.",
    )
    ap.add_argument(
        "--log-q-gate",
        type=float,
        default=1.10,
        help="Minimum fitted q for B_j ~ j^{-q}; mathematical threshold is q>1.",
    )
    ap.add_argument(
        "--fit-r2-gate",
        type=float,
        default=0.90,
        help="Minimum R^2 for an accepted asymptotic summability model.",
    )
    ap.add_argument(
        "--block-ratio-gate",
        type=float,
        default=0.95,
        help="Median late per-doubling variation ratio must be below this.",
    )
    ap.add_argument(
        "--depth-shell-fraction-gate",
        type=float,
        default=0.10,
        help="Last resolved k-shell must contribute less than this fraction.",
    )

    ap.add_argument(
        "--t-probes",
        default="1,5,10,20,40",
        help="t values for determinant continuity bounds.",
    )

    ap.add_argument("--prefix", default="rot_rh_trace_norm_cutoff_removal_v132")
    ap.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable per-L support cache.",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
        help="Return nonzero exit code unless all numerical gates pass.",
    )

    args = ap.parse_args()

    depths = sorted(set(csv_ints(args.depths)))
    if not depths:
        raise ValueError("--depths is empty.")
    if depths[-1] != args.max_depth:
        if depths[-1] > args.max_depth:
            raise ValueError("Largest --depths entry exceeds --max-depth.")
        depths.append(args.max_depth)

    t_probes = csv_floats(args.t_probes)
    Ls = geometric_L_grid(args.L_start, args.L_end, args.steps_per_doubling)

    print("=" * 118)
    print("ROT-RH v132 — TRACE-NORM CUTOFF REMOVAL / CAUCHY AUDIT")
    print("=" * 118)
    print("Xi / zeta / known zero data       : NONE")
    print("Operator                           : K_L = H_L^{-2}")
    print("Common basis                       : ordered canonical labels e_k")
    print("Theorem target                     : sum_j ||K_{L_{j+1}}-K_{L_j}||_1 < infinity")
    print(f"v102 module                        : {args.v102_module}")
    print(f"base module                        : {args.base_module}")
    print(f"L grid                             : {Ls}")
    print(f"depths                             : {depths}")
    print(f"max depth                          : {args.max_depth}")
    print(f"counter q / qcheck                 : {args.counter_q} / {args.counter_qcheck}")
    print(f"scan points                        : {args.scan_points}")
    print(f"residual safety                    : {args.residual_safety}")
    print("=" * 118)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    if not hasattr(v102, "RenormalizedPhase"):
        raise AttributeError(f"{args.v102_module} has no RenormalizedPhase")
    if not hasattr(v102, "ordered_support"):
        raise AttributeError(f"{args.v102_module} has no ordered_support")

    supports: List[LSupport] = []
    for L in Ls:
        supports.append(build_support(v102, base, args, L))

    # ------------------------------------------------------------------
    # Save root matrix
    # ------------------------------------------------------------------
    root_matrix = np.vstack([s.roots for s in supports])
    lambda_matrix = np.vstack([s.lambda_vals for s in supports])
    lambda_err_matrix = np.vstack([s.lambda_err for s in supports])

    np.savez_compressed(
        f"{args.prefix}_ROOTS.npz",
        L=np.array(Ls, dtype=int),
        roots=root_matrix,
        lambda_vals=lambda_matrix,
        lambda_err=lambda_err_matrix,
        depths=np.array(depths, dtype=int),
    )

    # ------------------------------------------------------------------
    # Per-L diagnostics
    # ------------------------------------------------------------------
    L_rows = []
    for s in supports:
        L_rows.append(
            dict(
                L=s.L,
                roots=len(s.roots),
                E1=float(s.roots[0]),
                Emax=float(s.roots[-1]),
                trace_K_partial=float(np.sum(s.lambda_vals)),
                min_abs_Fprime=s.min_abs_fprime,
                max_abs_root_residual=s.max_abs_residual,
                quadrature_phase_rel_l2=s.quad_phase_rel_l2,
                quadrature_deriv_rel_l2=s.quad_deriv_rel_l2,
                elapsed_sec=s.elapsed_sec,
                from_cache=int(s.from_cache),
            )
        )
    write_csv(Path(f"{args.prefix}_L_SUPPORT.csv"), L_rows)

    # ------------------------------------------------------------------
    # Consecutive-L trace norms
    # ------------------------------------------------------------------
    interval_rows = []
    depth_rows = []
    determinant_rows = []

    for j in range(len(supports) - 1):
        a = supports[j]
        b = supports[j + 1]

        dl = b.lambda_vals - a.lambda_vals
        adl = np.abs(dl)

        # Conservative numerical uncertainty inflation.
        unc_per_k = a.lambda_err + b.lambda_err
        trace_unc = float(np.sum(unc_per_k))
        trace_partial = float(np.sum(adl))

        # k-tail diagnostics
        geo_tail = geometric_k_tail_bound(
            adl,
            depths,
            ratio_gate=args.spectral_shell_ratio_gate,
        )
        pow_tail = power_k_tail_fit(
            adl,
            windows=args.spectral_tail_windows,
        )

        # We only call the unresolved tail finite if BOTH independent
        # extrapolations are finite. Use the larger of the two.
        if np.isfinite(geo_tail["tail"]) and np.isfinite(pow_tail["tail"]):
            spectral_tail = float(max(geo_tail["tail"], pow_tail["tail"]))
            spectral_tail_cert = True
        else:
            spectral_tail = np.inf
            spectral_tail_cert = False

        trace_upper = (
            trace_partial + trace_unc + spectral_tail
            if np.isfinite(spectral_tail)
            else np.inf
        )

        # depth saturation rows
        d_shells = dyadic_depth_shells(adl, depths)
        for r in d_shells:
            d = int(r["depth"])
            trace_unc_d = float(np.sum(unc_per_k[:d]))
            depth_rows.append(
                dict(
                    interval_index=j,
                    L_a=a.L,
                    L_b=b.L,
                    ratio_L=float(b.L / a.L),
                    depth=d,
                    trace_partial=float(np.sum(adl[:d])),
                    trace_uncertainty=trace_unc_d,
                    shell_start=r["shell_start"],
                    shell_end=r["shell_end"],
                    shell_trace=r["shell_trace"],
                    shell_fraction=r["shell_fraction"],
                )
            )

        last_shell_fraction = (
            float(d_shells[-1]["shell_fraction"]) if d_shells else np.nan
        )

        interval_rows.append(
            dict(
                interval_index=j,
                L_a=a.L,
                L_b=b.L,
                ratio_L=float(b.L / a.L),
                trace_partial=trace_partial,
                trace_uncertainty=trace_unc,
                spectral_tail_geometric=float(geo_tail["tail"]),
                spectral_tail_geometric_ratio=float(geo_tail["ratio"]),
                spectral_tail_power=float(pow_tail["tail"]),
                spectral_tail_power_alpha=float(pow_tail["alpha"]),
                spectral_tail_power_r2=float(pow_tail["r2"]),
                spectral_tail_used=spectral_tail,
                spectral_tail_certified=int(spectral_tail_cert),
                trace_upper=trace_upper,
                last_depth_shell_fraction=last_shell_fraction,
                max_abs_delta_lambda=float(np.max(adl)),
                median_abs_delta_lambda=float(np.median(adl)),
                max_abs_delta_E=float(np.max(np.abs(b.roots - a.roots))),
                median_abs_delta_E=float(np.median(np.abs(b.roots - a.roots))),
            )
        )

        # Determinant continuity implication:
        # |det(I - t^2 K_b) - det(I - t^2 K_a)|
        # <= t^2 ||K_b-K_a||_1 *
        #    exp(1 + t^2||K_a||_1 + t^2||K_b||_1)
        #
        # This can overflow at large t and is intentionally conservative.
        trKa = float(np.sum(a.lambda_vals))
        trKb = float(np.sum(b.lambda_vals))
        for t in t_probes:
            if np.isfinite(trace_upper):
                expo = 1.0 + t * t * (trKa + trKb)
                log_bound = math.log(max(t * t * trace_upper, np.finfo(float).tiny)) + expo
                det_bound = math.exp(log_bound) if log_bound < 700 else np.inf
            else:
                log_bound = np.inf
                det_bound = np.inf

            determinant_rows.append(
                dict(
                    interval_index=j,
                    L_a=a.L,
                    L_b=b.L,
                    t=t,
                    trace_Ka_partial=trKa,
                    trace_Kb_partial=trKb,
                    trace_distance_upper=trace_upper,
                    determinant_difference_bound=det_bound,
                    log_determinant_difference_bound=log_bound,
                )
            )

        print(
            f"[{a.L:>8}->{b.L:<8}] "
            f"T_D={trace_partial:.6e}  "
            f"unc={trace_unc:.2e}  "
            f"k-tail={'%.2e' % spectral_tail if np.isfinite(spectral_tail) else 'UNCERTIFIED':>11}  "
            f"upper={'%.6e' % trace_upper if np.isfinite(trace_upper) else 'INF':>12}  "
            f"last-shell={last_shell_fraction:.3e}"
        )

    write_csv(Path(f"{args.prefix}_INTERVALS.csv"), interval_rows)
    write_csv(Path(f"{args.prefix}_DEPTH.csv"), depth_rows)
    write_csv(Path(f"{args.prefix}_DETERMINANT_BOUNDS.csv"), determinant_rows)

    # ------------------------------------------------------------------
    # Aggregate by factor-of-two L blocks
    # ------------------------------------------------------------------
    blocks = build_doubling_blocks(
        interval_rows,
        L_start=args.L_start,
        steps=args.steps_per_doubling,
    )

    # Add block-to-block ratios.
    prev = None
    for r in blocks:
        cur = r["block_trace_upper"]
        r["ratio_to_previous"] = (
            cur / prev if prev is not None and np.isfinite(cur) and np.isfinite(prev) and prev > 0
            else np.nan
        )
        prev = cur

    write_csv(Path(f"{args.prefix}_DOUBLING_BLOCKS.csv"), blocks)
    fits = summability_fits(blocks, args.fit_last_doublings)

    # ------------------------------------------------------------------
    # Gates
    # ------------------------------------------------------------------
    finite_tail_intervals = all(
        bool(r["spectral_tail_certified"]) for r in interval_rows
    )

    late_interval_rows = interval_rows[-min(len(interval_rows), max(2, args.steps_per_doubling * 2)):]
    late_depth_ok = all(
        np.isfinite(r["last_depth_shell_fraction"])
        and r["last_depth_shell_fraction"] < args.depth_shell_fraction_gate
        for r in late_interval_rows
    )

    residuals_ok = all(
        np.isfinite(s.max_abs_residual) and s.max_abs_residual < 1e-7
        for s in supports
    )
    fprime_ok = all(
        np.isfinite(s.min_abs_fprime) and s.min_abs_fprime > 0
        for s in supports
    )

    power_model_ok = (
        np.isfinite(fits["power_p"])
        and fits["power_p"] > args.power_p_gate
        and np.isfinite(fits["power_r2"])
        and fits["power_r2"] >= args.fit_r2_gate
    )
    log_model_ok = (
        np.isfinite(fits["log_q"])
        and fits["log_q"] > args.log_q_gate
        and np.isfinite(fits["log_r2"])
        and fits["log_r2"] >= args.fit_r2_gate
    )

    model_ok = power_model_ok or log_model_ok

    block_ratio_ok = (
        np.isfinite(fits["median_block_ratio"])
        and fits["median_block_ratio"] < args.block_ratio_gate
    )

    # Strongest numerical verdict requires:
    #   numerical resolution + k-tail saturation + an L-summability model
    #   + direct contraction of per-doubling variation.
    numerical_pass = bool(
        finite_tail_intervals
        and late_depth_ok
        and residuals_ok
        and fprime_ok
        and model_ok
        and block_ratio_ok
    )

    verdict = {
        "version": 132,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "operator": "canonical diagonal K_L = H_L^{-2}",
        "theorem_target": "sum_j ||K_{L_{j+1}} - K_{L_j}||_1 < infinity",
        "parameters": {
            "v102_module": args.v102_module,
            "base_module": args.base_module,
            "L_grid": Ls,
            "depths": depths,
            "max_depth": args.max_depth,
            "tail_factor": args.tail_factor,
            "counter_q": args.counter_q,
            "counter_qcheck": args.counter_qcheck,
            "scan_points": args.scan_points,
            "residual_safety": args.residual_safety,
            "spectral_shell_ratio_gate": args.spectral_shell_ratio_gate,
            "depth_shell_fraction_gate": args.depth_shell_fraction_gate,
            "power_p_gate": args.power_p_gate,
            "log_q_gate": args.log_q_gate,
            "fit_r2_gate": args.fit_r2_gate,
            "block_ratio_gate": args.block_ratio_gate,
        },
        "summability_fits": fits,
        "gates": {
            "all_spectral_tails_certified_empirically": finite_tail_intervals,
            "late_depth_saturation": late_depth_ok,
            "root_residuals_ok": residuals_ok,
            "positive_Fprime_floor": fprime_ok,
            "power_model_ok": power_model_ok,
            "log_power_model_ok": log_model_ok,
            "some_summability_model_ok": model_ok,
            "doubling_block_contraction_ok": block_ratio_ok,
        },
        "numerical_verdict": "PASS" if numerical_pass else "FAIL_OR_UNRESOLVED",
        "proof_status": (
            "NOT A PROOF. PASS means the computed data support a trace-norm "
            "Cauchy theorem target. The k-tail extrapolation and persistence "
            "of the fitted L-asymptotic law still require analytic proof."
        ),
    }

    Path(f"{args.prefix}_VERDICT.json").write_text(
        json.dumps(verdict, indent=2),
        encoding="utf-8",
    )

    print()
    print("=" * 118)
    print("CUTOFF-REMOVAL SUMMARY")
    print("=" * 118)
    print(f"finite empirical k-tail estimates : {finite_tail_intervals}")
    print(f"late depth saturation             : {late_depth_ok}")
    print(f"root residual gate                : {residuals_ok}")
    print(f"positive F' floor                 : {fprime_ok}")
    print()
    print(
        "Per-doubling power fit           : "
        f"p={fits['power_p']:.6g}, R^2={fits['power_r2']:.6g}, AIC={fits['power_aic']:.6g}"
    )
    print(
        "Per-doubling log-power fit       : "
        f"q={fits['log_q']:.6g}, R^2={fits['log_r2']:.6g}, AIC={fits['log_aic']:.6g}"
    )
    print(
        "Median doubling-block ratio      : "
        f"{fits['median_block_ratio']:.6g}"
    )
    print(f"power summability model gate      : {power_model_ok}")
    print(f"log-power summability model gate  : {log_model_ok}")
    print(f"doubling-block contraction gate   : {block_ratio_ok}")
    print()
    print(f"NUMERICAL VERDICT                 : {'PASS' if numerical_pass else 'FAIL_OR_UNRESOLVED'}")
    print("PROOF VERDICT                     : OPEN")
    print("=" * 118)
    print()
    print("Files written:")
    for suffix in [
        "_L_SUPPORT.csv",
        "_INTERVALS.csv",
        "_DEPTH.csv",
        "_DOUBLING_BLOCKS.csv",
        "_DETERMINANT_BOUNDS.csv",
        "_ROOTS.npz",
        "_VERDICT.json",
    ]:
        print(f"  {args.prefix}{suffix}")

    if args.strict and not numerical_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
