#!/usr/bin/env python3
"""
ROT-RH v134 — BLIND LOW-MODE OSCILLATION / REGULATOR-FLOW PREDICTION AUDIT

ZERO-COST postprocessor: no root solving, no prime sums, no Xi, no zeta,
no known-zero data.

Scientific question
-------------------
The v133 audit found that the 64k -> 128k trace-norm plateau is dominated by
a handful of low modes (especially k=9,10,13,14).  Are these bursts consistent
with an oscillatory cutoff flow, or with non-decaying regulator contamination?

This script makes the test genuinely predictive:

  * TRAIN only on supports with L <= --train-max (default 64000).
  * HIDE the endpoint L=128000 during fitting.
  * Fit several models to lambda_k(L) = E_k(L)^(-2):

      C:   c
      P:   c + a L^{-p}
      UO:  c + a cos(w log_2 L) + b sin(w log_2 L)
      DO:  c + L^{-p}[a cos(w log_2 L) + b sin(w log_2 L)]

  * Predict the held-out lambda_k(128000).
  * Compare absolute prediction errors.
  * For DO, report p>0 or p~0 and the selected log-L frequency.

The endpoint is never used to choose p or w.

Because there are few support points, this remains a numerical diagnostic,
not proof of an asymptotic law.

Outputs
-------
<prefix>_MODES.csv
<prefix>_TOP.csv
<prefix>_VERDICT.json
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import re
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def extract_L(path):
    m = re.search(r"_CACHE_L(\d+)_D\d+\.npz$", Path(path).name)
    return int(m.group(1)) if m else None


def load_supports(roots_npz, cache_glob):
    data = {}
    for p in glob.glob(cache_glob):
        L = extract_L(p)
        if L is None:
            continue
        try:
            z = np.load(p)
            if "lambda_vals" in z:
                lam = np.asarray(z["lambda_vals"], float)
            else:
                lam = 1.0 / np.asarray(z["roots"], float) ** 2
            data[L] = lam
        except Exception:
            pass

    z = np.load(roots_npz)
    Ls = np.asarray(z["L"], int)
    if "lambda_vals" in z:
        M = np.asarray(z["lambda_vals"], float)
    else:
        M = 1.0 / np.asarray(z["roots"], float) ** 2
    for i, L in enumerate(Ls):
        data[int(L)] = M[i]
    return data


def fit_linear(X, y):
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    resid = y - pred
    sse = float(np.dot(resid, resid))
    return beta, sse


def aicc_from_sse(sse, n, k):
    sse = max(float(sse), np.finfo(float).tiny)
    aic = n * math.log(sse / n) + 2 * k
    if n <= k + 1:
        return np.inf
    return aic + (2 * k * (k + 1)) / (n - k - 1)


def centered_y(y):
    mu = float(np.mean(y))
    return y - mu, mu


def model_constant(x, y, xt):
    yc, mu = centered_y(y)
    c = float(np.mean(yc))
    pred_train = np.full_like(yc, c)
    sse = float(np.sum((yc - pred_train) ** 2))
    pred = mu + c
    return dict(pred=pred, sse=sse, aicc=aicc_from_sse(sse, len(y), 1),
                p=np.nan, omega=np.nan)


def model_power(x, y, xt, p_grid):
    yc, mu = centered_y(y)
    best = None
    for p in p_grid:
        f = np.exp(-p * x)
        X = np.column_stack([np.ones(len(x)), f])
        beta, sse = fit_linear(X, yc)
        aicc = aicc_from_sse(sse, len(y), 3)  # c,a,p
        if best is None or aicc < best["aicc"]:
            ft = math.exp(-p * xt)
            pred = mu + float(beta[0] + beta[1] * ft)
            best = dict(pred=pred, sse=sse, aicc=aicc, p=float(p),
                        omega=np.nan)
    return best


def model_undamped_osc(x, y, xt, w_grid):
    yc, mu = centered_y(y)
    best = None
    for w in w_grid:
        X = np.column_stack([
            np.ones(len(x)),
            np.cos(w * x),
            np.sin(w * x),
        ])
        beta, sse = fit_linear(X, yc)
        aicc = aicc_from_sse(sse, len(y), 4)  # c,a,b,w
        if best is None or aicc < best["aicc"]:
            row = np.array([1.0, math.cos(w * xt), math.sin(w * xt)])
            pred = mu + float(row @ beta)
            best = dict(pred=pred, sse=sse, aicc=aicc, p=0.0,
                        omega=float(w))
    return best


def model_damped_osc(x, y, xt, p_grid, w_grid):
    yc, mu = centered_y(y)
    best = None
    for p in p_grid:
        env = np.exp(-p * x)
        envt = math.exp(-p * xt)
        for w in w_grid:
            X = np.column_stack([
                np.ones(len(x)),
                env * np.cos(w * x),
                env * np.sin(w * x),
            ])
            beta, sse = fit_linear(X, yc)
            aicc = aicc_from_sse(sse, len(y), 5)  # c,a,b,p,w
            if best is None or aicc < best["aicc"]:
                row = np.array([
                    1.0,
                    envt * math.cos(w * xt),
                    envt * math.sin(w * xt),
                ])
                pred = mu + float(row @ beta)
                best = dict(pred=pred, sse=sse, aicc=aicc,
                            p=float(p), omega=float(w))
    return best


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--roots-npz",
                    default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz")
    ap.add_argument("--cache-glob",
                    default="rot_rh_trace_norm_cutoff_removal_v132_CACHE_L*_D1408.npz")
    ap.add_argument("--train-max", type=int, default=64000)
    ap.add_argument("--test-L", type=int, default=128000)
    ap.add_argument("--max-mode", type=int, default=64)
    ap.add_argument("--top-modes", type=int, default=20)

    ap.add_argument("--p-min", type=float, default=0.0)
    ap.add_argument("--p-max", type=float, default=0.8)
    ap.add_argument("--p-points", type=int, default=81)
    ap.add_argument("--omega-min", type=float, default=0.25,
                    help="Radians per unit log2(L).")
    ap.add_argument("--omega-max", type=float, default=6.0)
    ap.add_argument("--omega-points", type=int, default=181)

    ap.add_argument("--damped-p-gate", type=float, default=0.05)
    ap.add_argument("--prediction-win-factor", type=float, default=0.5,
                    help="Oscillatory prediction error must be < factor * power-model error.")
    ap.add_argument("--prefix", default="rot_rh_low_mode_blind_prediction_v134")
    args = ap.parse_args()

    supports = load_supports(args.roots_npz, args.cache_glob)
    Lall = np.array(sorted(supports), int)
    trainL = Lall[Lall <= args.train_max]
    if args.test_L not in supports:
        raise RuntimeError(f"test L={args.test_L} not found.")
    if len(trainL) < 7:
        raise RuntimeError("Need at least 7 training supports.")

    nmax = min(args.max_mode, min(len(supports[int(L)]) for L in trainL),
               len(supports[args.test_L]))

    # x measured in doublings relative to first training support.
    L0 = float(trainL[0])
    x = np.log2(trainL.astype(float) / L0)
    xt = math.log2(args.test_L / L0)

    Y = np.vstack([supports[int(L)][:nmax] for L in trainL])
    ytest = supports[args.test_L][:nmax]

    p_grid = np.linspace(args.p_min, args.p_max, args.p_points)
    w_grid = np.linspace(args.omega_min, args.omega_max, args.omega_points)

    print("=" * 126)
    print("ROT-RH v134 — BLIND LOW-MODE OSCILLATION / REGULATOR-FLOW PREDICTION AUDIT")
    print("=" * 126)
    print("Xi / zeta / known zeros          : NONE")
    print(f"training supports                 : {trainL.tolist()}")
    print(f"held-out test support             : {args.test_L}")
    print(f"modes                             : 1..{nmax}")
    print(f"p grid                            : {args.p_min}..{args.p_max} ({args.p_points})")
    print(f"omega grid                        : {args.omega_min}..{args.omega_max} ({args.omega_points})")
    print("=" * 126)

    rows = []
    for k in range(nmax):
        y = Y[:, k]
        yt = float(ytest[k])

        C = model_constant(x, y, xt)
        P = model_power(x, y, xt, p_grid)
        U = model_undamped_osc(x, y, xt, w_grid)
        D = model_damped_osc(x, y, xt, p_grid, w_grid)

        for m in (C, P, U, D):
            m["err"] = abs(m["pred"] - yt)

        osc_best_name, osc_best = min(
            [("UO", U), ("DO", D)],
            key=lambda z: z[1]["err"]
        )
        nonosc_best_name, nonosc_best = min(
            [("C", C), ("P", P)],
            key=lambda z: z[1]["err"]
        )

        # Normalize held-out error by actual last-step movement; this avoids
        # tiny absolute numbers hiding a poor extrapolation.
        prev = float(supports[args.train_max][k])
        actual_step = abs(yt - prev)
        scale = max(actual_step, np.finfo(float).tiny)

        if D["err"] < U["err"] and D["p"] >= args.damped_p_gate:
            damping_prediction = "DAMPED_OSC"
        elif U["err"] <= D["err"]:
            damping_prediction = "UNDAMPED_OSC"
        else:
            damping_prediction = "OSC_WITH_WEAK_DAMPING"

        osc_win = (
            osc_best["err"] <
            args.prediction_win_factor * max(nonosc_best["err"], np.finfo(float).tiny)
        )

        rows.append(dict(
            k=k+1,
            actual_lambda_128k=yt,
            actual_last_step=actual_step,

            const_pred=C["pred"],
            const_err=C["err"],
            const_err_over_step=C["err"]/scale,
            const_aicc=C["aicc"],

            power_pred=P["pred"],
            power_err=P["err"],
            power_err_over_step=P["err"]/scale,
            power_p=P["p"],
            power_aicc=P["aicc"],

            undamped_pred=U["pred"],
            undamped_err=U["err"],
            undamped_err_over_step=U["err"]/scale,
            undamped_omega=U["omega"],
            undamped_aicc=U["aicc"],

            damped_pred=D["pred"],
            damped_err=D["err"],
            damped_err_over_step=D["err"]/scale,
            damped_p=D["p"],
            damped_omega=D["omega"],
            damped_aicc=D["aicc"],

            best_osc_model=osc_best_name,
            best_osc_err=osc_best["err"],
            best_nonosc_model=nonosc_best_name,
            best_nonosc_err=nonosc_best["err"],
            osc_to_nonosc_error_ratio=(
                osc_best["err"] /
                max(nonosc_best["err"], np.finfo(float).tiny)
            ),
            oscillatory_prediction_win=int(osc_win),
            damping_class=damping_prediction,
        ))

    # Rank by actual contribution to the held-out 64k->128k low-mode trace.
    rows_rank = sorted(rows, key=lambda r: r["actual_last_step"], reverse=True)

    write_csv(Path(args.prefix + "_MODES.csv"), rows)

    top = rows_rank[:args.top_modes]
    write_csv(Path(args.prefix + "_TOP.csv"), top)

    print()
    print("Held-out 128k prediction, ranked by actual latest-step contribution")
    print("-" * 126)
    print(
        f"{'rank':>4} {'k':>3} {'step':>12} "
        f"{'P err/step':>11} {'UO err/step':>12} {'DO err/step':>12} "
        f"{'DO p':>8} {'DO w':>8} {'osc/non':>9} {'winner':>9}"
    )
    for rank, r in enumerate(top, 1):
        winner = "OSC" if r["oscillatory_prediction_win"] else "NONOSC"
        print(
            f"{rank:4d} {r['k']:3d} {r['actual_last_step']:12.4e} "
            f"{r['power_err_over_step']:11.4f} "
            f"{r['undamped_err_over_step']:12.4f} "
            f"{r['damped_err_over_step']:12.4f} "
            f"{r['damped_p']:8.3f} "
            f"{r['damped_omega']:8.3f} "
            f"{r['osc_to_nonosc_error_ratio']:9.3f} "
            f"{winner:>9}"
        )

    # Weighted aggregate over modes by actual held-out trace contribution.
    weights = np.array([r["actual_last_step"] for r in rows], float)
    wsum = float(np.sum(weights))
    if wsum > 0:
        osc_wins_weight = float(np.sum([
            r["actual_last_step"] for r in rows if r["oscillatory_prediction_win"]
        ]) / wsum)
        damped_positive_weight = float(np.sum([
            r["actual_last_step"] for r in rows
            if r["best_osc_model"] == "DO" and r["damped_p"] >= args.damped_p_gate
        ]) / wsum)
    else:
        osc_wins_weight = np.nan
        damped_positive_weight = np.nan

    # Focus specifically on v133's four dominant excess modes.
    focus_modes = [9, 10, 13, 14]
    focus = [r for r in rows if r["k"] in focus_modes]
    focus_osc_wins = sum(r["oscillatory_prediction_win"] for r in focus)
    focus_do_positive = sum(
        r["best_osc_model"] == "DO" and r["damped_p"] >= args.damped_p_gate
        for r in focus
    )

    verdict = dict(
        version=134,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        training_supports=trainL.tolist(),
        held_out_test_L=args.test_L,
        modes=nmax,
        weighted_fraction_of_latest_trace_where_oscillation_beats_nonosc_by_gate=osc_wins_weight,
        weighted_fraction_where_best_osc_model_is_damped_with_positive_p=damped_positive_weight,
        focus_modes=focus_modes,
        focus_oscillatory_prediction_wins=int(focus_osc_wins),
        focus_damped_positive_wins=int(focus_do_positive),
        interpretation=(
            "Strong evidence for oscillatory cutoff flow requires out-of-sample "
            "prediction success at L=128000, not merely a better in-sample fit. "
            "A positive fitted damping exponent is suggestive only if the damped "
            "oscillatory model also predicts the held-out endpoint well."
        ),
    )
    Path(args.prefix + "_VERDICT.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )

    print()
    print("=" * 126)
    print(
        "weighted latest-trace fraction with strong oscillatory prediction win : "
        f"{100*osc_wins_weight:.2f}%"
    )
    print(
        "weighted fraction best-fit by positively damped oscillation          : "
        f"{100*damped_positive_weight:.2f}%"
    )
    print(
        f"focus modes {focus_modes}: strong oscillatory wins                   : "
        f"{focus_osc_wins}/4"
    )
    print(
        f"focus modes {focus_modes}: positive-damped oscillatory wins          : "
        f"{focus_do_positive}/4"
    )
    print("=" * 126)


if __name__ == "__main__":
    main()
