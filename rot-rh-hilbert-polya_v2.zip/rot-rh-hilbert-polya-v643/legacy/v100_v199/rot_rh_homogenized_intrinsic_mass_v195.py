#!/usr/bin/env python3
"""
ROT-RH v195 — HOMOGENIZED INTRINSIC SWITCH-MASS AUDIT

Static post-processing only. No continuation, no mpmath root solving.

Reads:
  * v194 merged homogenized profile
  * v169 candidates + hull

Computes the theorem-shaped intrinsic switch mass

    K_hom = integral [ <|epsilon|>_phase / Delta gamma ] dx,

with x = Delta a (tau-tau_s).

Then

    I_hom = integral <|epsilon|> d tau
          = (Delta gamma / Delta a) K_hom.

Also reports the dimensionless late-switch scale

    R_switch = I_hom / (gamma_active * tau_s),

which is useful for judging whether the switch correction is negligible
relative to the accumulated active-layer scale.

No Xi / zeta / known zeros are used.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapz(x, y):
    x=np.asarray(x,float)
    y=np.asarray(y,float)
    o=np.argsort(x)
    return float(np.trapezoid(y[o],x[o]))


def integrate_profile(df, dg):
    d=df.sort_values("x")
    x=d["x"].to_numpy(float)
    ga=d["gamma_active"].to_numpy(float)
    r=d["mean_abs_epsilon_over_gamma"].to_numpy(float)

    eps = r*ga
    m = eps/dg

    return {
        "K_hom": trapz(x,m),
        "eps_x_area": trapz(x,eps),
        "x_min": float(np.min(x)),
        "x_max": float(np.max(x)),
        "points": len(d),
    }


def decimated(df, stride):
    d=df.sort_values("x").reset_index(drop=True)
    ids=list(range(0,len(d),stride))
    if len(d)-1 not in ids:
        ids.append(len(d)-1)
    return d.iloc[sorted(set(ids))].copy()


def main():
    ap=argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--merged-profile",required=True)
    ap.add_argument("--candidates-csv",required=True)
    ap.add_argument("--hull-csv",required=True)
    ap.add_argument("--switch-index",type=int,default=159)
    ap.add_argument(
        "--prefix",
        default="rot_rh_homogenized_intrinsic_mass_v195"
    )
    args=ap.parse_args()

    prof=pd.read_csv(args.merged_profile).sort_values("x").reset_index(drop=True)
    cand=pd.read_csv(args.candidates_csv)
    hull=pd.read_csv(args.hull_csv).sort_values("tau_start").reset_index(drop=True)

    required={"x","gamma_active","mean_abs_epsilon_over_gamma"}
    missing=required-set(prof.columns)
    if missing:
        raise RuntimeError(f"Missing profile columns: {sorted(missing)}")

    j=args.switch_index-1
    left=hull.iloc[j]
    right=hull.iloc[j+1]

    c1=match_candidate(cand,left["beta_active"],left["gamma_active"])
    c2=match_candidate(cand,right["beta_active"],right["gamma_active"])

    b1=float(c1["beta"])
    b2=float(c2["beta"])
    g1=float(c1["gamma"])
    g2=float(c2["gamma"])

    da=abs((b2-0.5)-(b1-0.5))
    dg=abs(g2-g1)
    ts=float(left["tau_end"])

    fine=integrate_profile(prof,dg)
    s2=integrate_profile(decimated(prof,2),dg)
    s4=integrate_profile(decimated(prof,4),dg)

    K=fine["K_hom"]
    I=K*dg/da

    # Active scale choices: left gamma, right gamma, and geometric mean.
    ggeom=(g1*g2)**0.5
    R_left=I/(g1*ts)
    R_right=I/(g2*ts)
    R_geom=I/(ggeom*ts)

    # Split intrinsic mass by side of nominal hull switch.
    neg=prof[prof["x"]<=0].copy()
    pos=prof[prof["x"]>=0].copy()
    Kneg=integrate_profile(neg,dg)["K_hom"] if len(neg)>=2 else np.nan
    Kpos=integrate_profile(pos,dg)["K_hom"] if len(pos)>=2 else np.nan

    # Compare with simple one-sided logistic benchmark:
    # integral_{-inf}^0 e^x/(1+e^x) dx = log 2.
    log2=float(np.log(2.0))

    out=prof.copy()
    out["epsilon_phase_avg"] = (
        out["mean_abs_epsilon_over_gamma"]*out["gamma_active"]
    )
    out["m_intrinsic"] = out["epsilon_phase_avg"]/dg
    out.to_csv(args.prefix+"_PROFILE.csv",index=False)

    summary={
        "version":195,
        "switch":args.switch_index,
        "beta_left":b1,
        "beta_right":b2,
        "gamma_left":g1,
        "gamma_right":g2,
        "delta_a":da,
        "delta_gamma":dg,
        "tau_switch":ts,
        "profile_x_min":fine["x_min"],
        "profile_x_max":fine["x_max"],
        "profile_points":fine["points"],
        "K_hom":K,
        "K_hom_stride2":s2["K_hom"],
        "K_hom_stride4":s4["K_hom"],
        "K_stride2_relative_difference":abs(s2["K_hom"]-K)/max(abs(K),1e-300),
        "K_stride4_relative_difference":abs(s4["K_hom"]-K)/max(abs(K),1e-300),
        "K_negative_x":Kneg,
        "K_positive_x":Kpos,
        "log2_benchmark":log2,
        "K_over_log2":K/log2,
        "I_hom_tau_integral":I,
        "I_over_gamma_left_tau":R_left,
        "I_over_gamma_right_tau":R_right,
        "I_over_gamma_geom_tau":R_geom,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print("="*176)
    print("ROT-RH v195 — HOMOGENIZED INTRINSIC SWITCH-MASS AUDIT")
    print("="*176)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switch                            : {args.switch_index}")
    print(f"delta gamma                       : {dg:.12e}")
    print(f"delta a                           : {da:.12e}")
    print(f"tau switch                        : {ts:.12e}")
    print(f"profile x range                   : [{fine['x_min']:.6f},{fine['x_max']:.6f}]")
    print(f"profile points                    : {fine['points']}")
    print("="*176)
    print(f"K_hom                             : {K:.12e}")
    print(f"K_hom stride-2                    : {s2['K_hom']:.12e}")
    print(f"K_hom stride-4                    : {s4['K_hom']:.12e}")
    print(f"K stride-2 relative difference    : {summary['K_stride2_relative_difference']:.6e}")
    print(f"K stride-4 relative difference    : {summary['K_stride4_relative_difference']:.6e}")
    print(f"K x<=0                            : {Kneg:.12e}")
    print(f"K x>=0                            : {Kpos:.12e}")
    print(f"log(2) benchmark                  : {log2:.12e}")
    print(f"K / log(2)                       : {K/log2:.6e}")
    print(f"I_hom = (dg/da) K                 : {I:.12e}")
    print(f"I / (gamma_left * tau_s)          : {R_left:.12e}")
    print(f"I / (gamma_right * tau_s)         : {R_right:.12e}")
    print(f"I / (sqrt(g1*g2) * tau_s)         : {R_geom:.12e}")
    print("="*176)


if __name__=="__main__":
    main()
