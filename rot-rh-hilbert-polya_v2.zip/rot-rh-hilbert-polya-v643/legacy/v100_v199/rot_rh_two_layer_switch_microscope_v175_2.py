#!/usr/bin/env python3
"""
ROT-RH v175.2 — TWO-LAYER SWITCH MICROSCOPE / NO-HOPPING RECOVERY

Purpose
-------
v174's independent implicit-ODE continuation did NOT reproduce the Brent-based
escape of v172/v173.  All branches approached E~10 and then failed.

v175 diagnoses the exact first failed interval for each branch and resolves it
locally with progressively finer logarithmic-time subdivision, Newton-only
projection, and direct searches for branch singularities S=S_E=0.

It answers:

  A) REGULAR_STIFF_SWITCH_RECOVERED
     The same continuous simple root crosses the switch after enough refinement.

  B) SIMPLE_BRANCH_TERMINATES_AT_DEGENERACY
     A nearby simultaneous S=0, S_E=0 event is found.  The earlier Brent
     continuation was not tracking one globally simple root branch through it.

  C) NO_HOPPING_ESCAPE_NOT_REPRODUCED
     No degeneracy is certified, but arbitrarily fine no-hopping continuation
     remains trapped/fails near the low-gamma branch.  The v172/v173 escape is
     therefore not independently certified.

NO Xi / zeta evaluations / known-zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.integrate import solve_ivp
    from scipy.optimize import root as scipy_root
    from scipy.special import loggamma, digamma
except Exception as exc:
    raise RuntimeError("v175 requires scipy.") from exc


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class SyntheticZeroPhase:
    def __init__(self, beta, gamma):
        beta = np.asarray(beta, float)
        gamma = np.asarray(gamma, float)
        ok = np.isfinite(beta) & np.isfinite(gamma) & (beta > 0.5) & (beta < 1) & (gamma > 0)
        beta = beta[ok]
        gamma = gamma[ok]

        aa, gg = [], []
        for b, g in zip(beta, gamma):
            a = b - 0.5
            # right-half zero + conjugate
            aa += [a, a]
            gg += [g, -g]
            # functional-equation mirror + conjugate
            aa += [-a, -a]
            gg += [g, -g]

        self.a = np.asarray(aa, float)
        self.gamma = np.asarray(gg, float)

    def eval(self, E, tau):
        """
        Return scaled S, S_E, S_tau, shift.

        A common positive scaling is removed.  At S=0 it does not alter zero
        locations or the implicit ratio -S_tau/S_E.

        NOTE:
        scipy.special.polygamma does not support complex arguments in some
        SciPy builds, and S_EE is not required anywhere in this audit.
        Therefore v175.1 deliberately uses only loggamma/digamma.
        """
        w = self.a + 1j * (E - self.gamma)
        lg = loggamma(w)
        logz = lg + self.a * tau + 1j * (E - self.gamma) * tau

        shift = float(np.max(np.real(logz)))
        z = np.exp(logz - shift)

        psi = digamma(w)

        total = np.sum(z)
        S = float(np.imag(total))

        # dE Z = i(psi+tau) Z
        q = psi + tau
        dE = np.sum(1j * q * z)
        SE = float(np.imag(dE))

        # dtau Z = w Z
        dt = np.sum(w * z)
        St = float(np.imag(dt))

        return S, SE, St, shift

    def rhs_u(self, u, E):
        tau = math.exp(float(u))
        S, SE, St, *_ = self.eval(float(E), tau)
        if not np.isfinite(SE) or abs(SE) < 1e-300:
            return np.nan
        return -tau * St / SE


def geometric_grid(t0, t1, n):
    return np.geomspace(t0, t1, n)


def newton_project(phase, E0, tau, residual_tol, spacing_fraction, iterations):
    E = float(E0)
    spacing = math.pi / max(tau, 1.0)
    total = 0.0
    max_step_ratio = 0.0

    for it in range(iterations):
        S, SE, St, _ = phase.eval(E, tau)
        if abs(S) <= residual_tol:
            return dict(
                ok=True, E=E, residual=abs(S), abs_SE=abs(SE),
                total_correction=total,
                correction_over_spacing=abs(total)/max(spacing, 1e-300),
                max_step_over_spacing=max_step_ratio,
                iterations=it,
            )
        if not np.isfinite(SE) or abs(SE) < 1e-18:
            return dict(ok=False, reason="SE_too_small", E=E, residual=abs(S), abs_SE=abs(SE))

        step = -S / SE
        ratio = abs(step) / max(spacing, 1e-300)
        max_step_ratio = max(max_step_ratio, ratio)
        if ratio > spacing_fraction:
            return dict(
                ok=False, reason="projection_step_exceeds_spacing_gate",
                E=E, residual=abs(S), abs_SE=abs(SE),
                attempted_step=step, step_over_spacing=ratio,
            )
        E += step
        total += step

    S, SE, *_ = phase.eval(E, tau)
    return dict(
        ok=abs(S) <= residual_tol,
        reason="newton_no_convergence",
        E=E, residual=abs(S), abs_SE=abs(SE),
        total_correction=total,
        correction_over_spacing=abs(total)/max(spacing, 1e-300),
        max_step_over_spacing=max_step_ratio,
    )


def integrate_interval(phase, E0, t0, t1, rtol, atol, max_du):
    u0, u1 = math.log(t0), math.log(t1)
    min_se = [np.inf]
    max_rhs = [0.0]

    def rhs(u, y):
        tau = math.exp(float(u))
        E = float(y[0])
        S, SE, St, *_ = phase.eval(E, tau)
        min_se[0] = min(min_se[0], abs(SE))
        if not np.isfinite(SE) or abs(SE) < 1e-18:
            return [np.nan]
        val = -tau * St / SE
        max_rhs[0] = max(max_rhs[0], abs(val))
        return [val]

    sol = solve_ivp(
        rhs, (u0, u1), [float(E0)], method="DOP853",
        rtol=rtol, atol=atol, max_step=max_du,
    )

    return dict(
        ok=bool(sol.success and np.isfinite(sol.y[0, -1])),
        message=str(sol.message),
        E_pred=float(sol.y[0, -1]),
        nfev=int(sol.nfev),
        min_abs_SE=float(min_se[0]),
        max_abs_rhs=float(max_rhs[0]),
    )


def continue_with_subdivision(
    phase, E0, t0, t1, pieces,
    rtol, atol, max_du,
    residual_tol, spacing_fraction, newton_iters,
):
    ts = geometric_grid(t0, t1, pieces + 1)
    E = float(E0)
    rows = []
    min_se = np.inf
    max_proj_ratio = 0.0

    for j in range(pieces):
        a, b = float(ts[j]), float(ts[j + 1])
        integ = integrate_interval(
            phase, E, a, b, rtol, atol,
            min(max_du, (math.log(b) - math.log(a)) / 4.0)
        )
        min_se = min(min_se, integ["min_abs_SE"])

        if not integ["ok"]:
            return dict(
                ok=False, reason="ode_failure", fail_piece=j,
                fail_tau_start=a, fail_tau_end=b, E=E,
                rows=rows, min_abs_SE=min_se,
                max_projection_ratio=max_proj_ratio,
                ode_message=integ["message"],
            )

        proj = newton_project(
            phase, integ["E_pred"], b,
            residual_tol, spacing_fraction, newton_iters
        )

        if not proj["ok"]:
            return dict(
                ok=False, reason=proj.get("reason", "projection_failure"),
                fail_piece=j, fail_tau_start=a, fail_tau_end=b,
                E=E, E_pred=integ["E_pred"],
                rows=rows, min_abs_SE=min(min_se, proj.get("abs_SE", np.inf)),
                max_projection_ratio=max_proj_ratio,
                projection=proj,
            )

        E = float(proj["E"])
        min_se = min(min_se, proj["abs_SE"])
        max_proj_ratio = max(
            max_proj_ratio,
            float(proj.get("max_step_over_spacing", 0.0)),
            float(proj.get("correction_over_spacing", 0.0)),
        )

        rows.append(dict(
            piece=j,
            tau_start=a,
            tau_end=b,
            E=E,
            residual=float(proj["residual"]),
            abs_SE=float(proj["abs_SE"]),
            projection_over_spacing=float(proj.get("correction_over_spacing", 0.0)),
            max_step_over_spacing=float(proj.get("max_step_over_spacing", 0.0)),
            ode_nfev=int(integ["nfev"]),
            ode_min_abs_SE=float(integ["min_abs_SE"]),
            ode_max_abs_rhs=float(integ["max_abs_rhs"]),
        ))

    return dict(
        ok=True, E=E, rows=rows, min_abs_SE=min_se,
        max_projection_ratio=max_proj_ratio,
    )


def degeneracy_scan(phase, E_center, t0, t1, E_radius, tau_points, E_points):
    """
    Coarse scan for small sqrt(S^2 + normalized SE^2), then solve S=SE=0
    in variables (E, u=log tau).

    We normalize SE by tau to make its scale roughly comparable to S.
    """
    us = np.linspace(math.log(t0), math.log(t1), tau_points)
    Es = np.linspace(E_center - E_radius, E_center + E_radius, E_points)

    best = None

    for u in us:
        tau = math.exp(float(u))
        for E in Es:
            S, SE, St, _ = phase.eval(float(E), tau)
            score = math.hypot(S, SE / max(tau, 1.0))
            if best is None or score < best[0]:
                best = (score, float(E), float(u), S, SE)

    _, E_seed, u_seed, *_ = best

    def fun(x):
        E, u = float(x[0]), float(x[1])
        tau = math.exp(u)
        S, SE, St, _ = phase.eval(E, tau)
        return np.array([S, SE / max(tau, 1.0)], float)

    sol = scipy_root(fun, np.array([E_seed, u_seed]), method="hybr")
    E_star, u_star = float(sol.x[0]), float(sol.x[1])
    tau_star = math.exp(u_star)
    S, SE, St, _ = phase.eval(E_star, tau_star)

    within = (
        t0 <= tau_star <= t1
        and E_center - E_radius <= E_star <= E_center + E_radius
    )

    return dict(
        solver_success=bool(sol.success),
        within_search_box=bool(within),
        E=E_star,
        tau=tau_star,
        S=float(S),
        SE=float(SE),
        abs_S=float(abs(S)),
        abs_SE=float(abs(SE)),
        residual_norm=float(np.linalg.norm(fun(sol.x))),
        seed_E=E_seed,
        seed_tau=math.exp(u_seed),
        coarse_score=float(best[0]),
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--candidates-csv",
        default="rot_rh_bellotti_density_adversary_v171_mu4_cap1_CANDIDATES.csv",
    )
    ap.add_argument(
        "--v174-trajectories",
        default="rot_rh_no_hopping_ode_cert_v174_TRAJECTORIES.csv",
    )
    ap.add_argument(
        "--v174-branches",
        default="rot_rh_no_hopping_ode_cert_v174_BRANCHES.csv",
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)
    ap.add_argument("--checkpoints", type=int, default=1200)

    ap.add_argument("--levels", type=int, default=10)
    ap.add_argument("--base-pieces", type=int, default=2)

    ap.add_argument("--rtol", type=float, default=1e-11)
    ap.add_argument("--atol", type=float, default=1e-13)
    ap.add_argument("--max-u-step", type=float, default=0.0025)

    ap.add_argument("--projection-residual-tol", type=float, default=1e-11)
    ap.add_argument("--projection-spacing-fraction", type=float, default=0.10)
    ap.add_argument("--newton-iters", type=int, default=10)

    ap.add_argument("--degeneracy-E-radius", type=float, default=0.25)
    ap.add_argument("--degeneracy-tau-points", type=int, default=81)
    ap.add_argument("--degeneracy-E-points", type=int, default=161)
    ap.add_argument("--degeneracy-S-gate", type=float, default=1e-8)
    ap.add_argument("--degeneracy-SE-gate", type=float, default=1e-6)

    ap.add_argument(
        "--prefix",
        default="rot_rh_two_layer_switch_microscope_v175",
    )
    args = ap.parse_args()

    cand = pd.read_csv(args.candidates_csv)
    tr = pd.read_csv(args.v174_trajectories)
    br = pd.read_csv(args.v174_branches)

    phase = SyntheticZeroPhase(
        cand["beta"].to_numpy(float),
        cand["gamma"].to_numpy(float),
    )

    global_grid = np.geomspace(args.tau_min, args.tau_max, args.checkpoints)

    print("=" * 166)
    print("ROT-RH v175.2 — TWO-LAYER SWITCH MICROSCOPE / NO-HOPPING RECOVERY")
    print("=" * 166)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"complex terms with symmetries     : {len(phase.a)}")
    print(f"refinement levels                 : {args.levels}")
    print(f"projection gate                   : {args.projection_spacing_fraction} * pi/tau")
    print("=" * 166)

    summaries = []
    detail_rows = []

    for _, brow in br.sort_values("branch").iterrows():
        b = int(brow["branch"])
        gt = tr[tr["branch"] == b].sort_values("tau")
        last = gt.iloc[-1]
        t0 = float(last["tau"])
        E0 = float(last["E"])

        # Reconstruct the next intended global checkpoint.
        idx = int(np.searchsorted(global_grid, t0, side="right"))
        if idx >= len(global_grid):
            summaries.append(dict(
                branch=b, status="already_at_end", tau_last=t0, E_last=E0
            ))
            continue

        t1 = float(global_grid[idx])

        failure_reason = str(brow.get("failure_reason", ""))

        print()
        print(
            f"[branch {b}] last certified tau={t0:.12e}, E={E0:.12f}; "
            f"failed interval -> {t1:.12e}; reason={failure_reason}"
        )

        recovered = None
        last_attempt = None

        for lev in range(args.levels):
            pieces = args.base_pieces * (2 ** lev)
            att = continue_with_subdivision(
                phase, E0, t0, t1, pieces,
                args.rtol, args.atol, args.max_u_step,
                args.projection_residual_tol,
                args.projection_spacing_fraction,
                args.newton_iters,
            )
            last_attempt = att

            print(
                f"  level={lev:2d} pieces={pieces:5d} "
                f"ok={att['ok']} "
                f"reason={att.get('reason','')} "
                f"min|SE|={att.get('min_abs_SE',np.nan):.3e} "
                f"max proj/sp={att.get('max_projection_ratio',np.nan):.3e}"
            )

            for r in att.get("rows", []):
                rr = dict(branch=b, level=lev, pieces=pieces)
                rr.update(r)
                detail_rows.append(rr)

            if att["ok"]:
                recovered = (lev, pieces, att)
                break

        # Search the original failed interval for an actual S=SE=0 event.
        deg = degeneracy_scan(
            phase,
            E0,
            t0,
            t1,
            args.degeneracy_E_radius,
            args.degeneracy_tau_points,
            args.degeneracy_E_points,
        )

        degeneracy_found = bool(
            deg["solver_success"]
            and deg["within_search_box"]
            and deg["abs_S"] <= args.degeneracy_S_gate
            and deg["abs_SE"] <= args.degeneracy_SE_gate
        )

        if recovered is not None:
            lev, pieces, att = recovered
            status = "REGULAR_STIFF_SWITCH_RECOVERED"
            E_end = float(att["E"])
        elif degeneracy_found:
            status = "SIMPLE_BRANCH_TERMINATES_AT_DEGENERACY"
            E_end = float(last_attempt.get("E", E0))
        else:
            status = "NO_HOPPING_ESCAPE_NOT_REPRODUCED"
            E_end = float(last_attempt.get("E", E0))

        summaries.append(dict(
            branch=b,
            original_failure_reason=failure_reason,
            tau_last_certified=t0,
            tau_failed_target=t1,
            E_last_certified=E0,
            status=status,
            recovered=bool(recovered is not None),
            recovered_level=(None if recovered is None else int(recovered[0])),
            recovered_pieces=(None if recovered is None else int(recovered[1])),
            E_after_recovery=E_end,
            degeneracy_found=degeneracy_found,
            degeneracy=deg,
        ))

        print(
            f"  degeneracy: success={deg['solver_success']} "
            f"within={deg['within_search_box']} "
            f"tau={deg['tau']:.12e} E={deg['E']:.12f} "
            f"|S|={deg['abs_S']:.3e} |SE|={deg['abs_SE']:.3e}"
        )
        print(f"  STATUS: {status}")

    statuses = [s["status"] for s in summaries]

    if statuses and all(s == "REGULAR_STIFF_SWITCH_RECOVERED" for s in statuses):
        overall = "ALL_BRANCHES_REGULAR_SWITCH_RECOVERED"
    elif any(s == "SIMPLE_BRANCH_TERMINATES_AT_DEGENERACY" for s in statuses):
        overall = "SYNTHETIC_BRANCH_DEGENERACY_FOUND"
    elif any(s == "NO_HOPPING_ESCAPE_NOT_REPRODUCED" for s in statuses):
        overall = "BRENT_ESCAPE_NOT_NO_HOPPING_CERTIFIED"
    else:
        overall = "SWITCH_MICROSCOPE_MIXED"

    pd.DataFrame(detail_rows).to_csv(
        args.prefix + "_DETAIL.csv", index=False
    )
    pd.DataFrame([
        {k: v for k, v in s.items() if k != "degeneracy"}
        for s in summaries
    ]).to_csv(
        args.prefix + "_BRANCHES.csv", index=False
    )

    out = dict(
        version="175.2",
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        scope=(
            "Local refinement of the first failed no-hopping ODE interval "
            "from v174, plus direct S=SE=0 search."
        ),
        branches=summaries,
        overall_verdict=overall,
    )
    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(native(out), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("=" * 166)
    print(f"OVERALL VERDICT: {overall}")
    print("=" * 166)

    if overall == "SYNTHETIC_BRANCH_DEGENERACY_FOUND":
        print("CONSEQUENCE:")
        print("  The globally simple-root assumption fails in the synthetic model.")
        print("  Brent continuation can reconnect onto another phase root after the")
        print("  degeneracy, so its large-E escape is not one certified simple branch.")
    elif overall == "BRENT_ESCAPE_NOT_NO_HOPPING_CERTIFIED":
        print("CONSEQUENCE:")
        print("  The large-E Brent trajectory remains uncertified as the same root.")
        print("  Do not use v172/v173 as evidence that a genuine simple branch escapes.")
    elif overall == "ALL_BRANCHES_REGULAR_SWITCH_RECOVERED":
        print("NEXT:")
        print("  Use the recovered microstep strategy globally. If it reproduces the")
        print("  large-E endpoint without branch degeneracy, the escape can then be")
        print("  certified independently.")


if __name__ == "__main__":
    main()
