#!/usr/bin/env python3
"""
ROT-RH v198 — UNIVERSAL EXPONENTIAL BOUNDARY-LAYER AUDIT

Purpose
-------
v197 found near-perfect late-switch profile collapse, but:
  * switch 136 still had two unresolved refined x-points (-0.75,-0.625);
  * K stride checks were based on row decimation of a nonuniform merged grid,
    which is not a clean convergence diagnostic.

v198 fixes both issues and tests the theorem-shaped universal majorant

    m_j(x) := <|epsilon_j|>_phase / Delta gamma_j
    m_j(x) <= C exp(x),    x < 0,

with negligible post-switch mass for x >= 0.

Because integral_{-infty}^0 exp(x) dx = 1, such a bound gives

    K_j^hom = integral m_j(x) dx <= C.

The script:
  1. resolves only the missing switch-136 points using phase-window shifts;
  2. recomputes K on controlled NESTED critical grids while keeping the
     same frozen tails in every comparison;
  3. fits log m = log C0 + p x on the pre-switch tail;
  4. measures the required majorant constant max[m/e^x];
  5. measures post-switch mass;
  6. reports late-switch K universality.

No Xi / zeta / known zeros are used.

Requires:
  rot_rh_transition_homogenization_v192.py
  rot_rh_phase_shifted_missing_points_v194.py
"""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def ensure_intrinsic(df, dg):
    d = df.copy()
    d["epsilon_phase_avg"] = (
        d["mean_abs_epsilon_over_gamma"].to_numpy(float)
        * d["gamma_active"].to_numpy(float)
    )
    d["m_intrinsic"] = d["epsilon_phase_avg"]/float(dg)
    return d


def K_of(df):
    d = df.sort_values("x")
    return trapz(
        d["x"].to_numpy(float),
        d["m_intrinsic"].to_numpy(float)
    )


def fixed_tail_nested_K(df, critical_min=-1.25, critical_max=0.0, step=0.125):
    """
    Clean quadrature test:
      - tails are IDENTICAL for fine/coarse comparisons;
      - only the uniform critical grid is nested:
            h, 2h, 4h.
    """
    d = df.sort_values("x").drop_duplicates("x", keep="last").copy()

    left = d[d["x"] < critical_min-1e-10].copy()
    right = d[d["x"] > critical_max+1e-10].copy()
    crit = d[
        (d["x"] >= critical_min-1e-10)
        & (d["x"] <= critical_max+1e-10)
    ].copy()

    # Map expected critical grid to nearest actual points.
    expected = np.arange(
        critical_min,
        critical_max + 0.5*step,
        step
    )

    rows = []
    missing = []
    for x0 in expected:
        if len(crit) == 0:
            missing.append(float(x0))
            continue
        j = int(np.argmin(np.abs(crit["x"].to_numpy(float)-x0)))
        row = crit.iloc[j]
        if abs(float(row["x"])-x0) > 1e-7:
            missing.append(float(x0))
        else:
            rows.append(row)

    if missing:
        return {
            "ok": False,
            "missing_grid": missing,
        }

    grid = pd.DataFrame(rows).sort_values("x").reset_index(drop=True)

    def merged_stride(stride):
        ids = list(range(0, len(grid), stride))
        if len(grid)-1 not in ids:
            ids.append(len(grid)-1)
        cg = grid.iloc[sorted(set(ids))].copy()

        return (
            pd.concat([left, cg, right], ignore_index=True)
            .sort_values("x")
            .drop_duplicates("x", keep="last")
        )

    f = merged_stride(1)
    c2 = merged_stride(2)
    c4 = merged_stride(4)

    K = K_of(f)
    K2 = K_of(c2)
    K4 = K_of(c4)

    return {
        "ok": True,
        "K_nested_fine": K,
        "K_nested_2h": K2,
        "K_nested_4h": K4,
        "K_2h_relative_difference": abs(K2-K)/max(abs(K),1e-300),
        "K_4h_relative_difference": abs(K4-K)/max(abs(K),1e-300),
        "critical_grid_points": len(grid),
    }


def exp_boundary_metrics(df, tail_min=-8.0, tail_max=-1.0):
    d = df.sort_values("x").copy()
    x = d["x"].to_numpy(float)
    m = d["m_intrinsic"].to_numpy(float)

    neg = (x < 0) & np.isfinite(m) & (m > 0)
    post = (x >= 0) & np.isfinite(m)

    # Required constant for m(x) <= C e^x on sampled pre-switch region.
    ratio = m[neg]/np.exp(x[neg])
    C_req = float(np.max(ratio)) if len(ratio) else np.nan
    C_med = float(np.median(ratio)) if len(ratio) else np.nan

    # Tail exponential fit.
    fit = (
        (x >= tail_min)
        & (x <= tail_max)
        & (m > 1e-14)
    )
    if np.sum(fit) >= 4:
        coef = np.polyfit(x[fit], np.log(m[fit]), 1)
        pred = np.polyval(coef, x[fit])
        y = np.log(m[fit])
        r2 = 1 - np.sum((y-pred)**2)/np.sum((y-y.mean())**2)
        p = float(coef[0])
        C0 = float(np.exp(coef[1]))
        r2 = float(r2)
    else:
        p = C0 = r2 = np.nan

    # One-sided mass split.
    dn = d[d["x"] <= 0].copy()
    dp = d[d["x"] >= 0].copy()
    Kneg = K_of(dn) if len(dn) >= 2 else np.nan
    Kpos = K_of(dp) if len(dp) >= 2 else np.nan

    max_post = float(np.max(m[post])) if np.any(post) else np.nan

    return {
        "exp_tail_slope_p": p,
        "exp_tail_prefactor_C0": C0,
        "exp_tail_log_R2": r2,
        "majorant_C_required": C_req,
        "majorant_ratio_median": C_med,
        "K_pre_switch": Kneg,
        "K_post_switch": Kpos,
        "max_post_switch_m": max_post,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--v197-profiles",
        default="rot_rh_late_switch_critical_collapse_v197_PROFILES.csv",
    )
    ap.add_argument(
        "--v192-module",
        default="rot_rh_transition_homogenization_v192",
    )
    ap.add_argument(
        "--v194-module",
        default="rot_rh_phase_shifted_missing_points_v194",
    )

    ap.add_argument(
        "--resolve-switch",
        type=int,
        default=136,
    )
    ap.add_argument(
        "--resolve-x-values",
        default="-0.75,-0.625",
    )
    ap.add_argument(
        "--phase-offsets",
        default="0,0.125,0.25,0.375,0.5,0.625,0.75,0.875",
    )

    ap.add_argument("--dps", type=int, default=55)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=14)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--search-cells", type=int, default=28)
    ap.add_argument("--branch-count", type=int, default=1)
    ap.add_argument("--phase-points", type=int, default=129)
    ap.add_argument("--max-subdivision-depth", type=int, default=20)

    ap.add_argument(
        "--success-offsets-needed",
        type=int,
        default=3,
    )
    ap.add_argument(
        "--offset-spread-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--phase-grid-gate",
        type=float,
        default=0.05,
    )

    ap.add_argument("--critical-min", type=float, default=-1.25)
    ap.add_argument("--critical-max", type=float, default=0.0)
    ap.add_argument("--critical-step", type=float, default=0.125)

    ap.add_argument(
        "--majorant-C-gate",
        type=float,
        default=1.5,
    )
    ap.add_argument(
        "--tail-slope-tolerance",
        type=float,
        default=0.15,
    )
    ap.add_argument(
        "--post-mass-gate",
        type=float,
        default=1e-6,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_universal_exponential_boundary_v198",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    mod192 = importlib.import_module(args.v192_module)
    mod194 = importlib.import_module(args.v194_module)

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )
    allprof = pd.read_csv(args.v197_profiles)

    offsets = [
        float(s.strip())
        for s in args.phase_offsets.split(",")
        if s.strip()
    ]
    xresolve = [
        mp.mpf(s.strip())
        for s in args.resolve_x_values.split(",")
        if s.strip()
    ]

    print("="*190)
    print("ROT-RH v198 — UNIVERSAL EXPONENTIAL BOUNDARY-LAYER AUDIT")
    print("="*190)
    print("Xi / zeta / known zeros          : NONE")
    print(f"resolve switch                    : {args.resolve_switch}")
    print(f"resolve x                         : {[float(x) for x in xresolve]}")
    print(f"phase points / cycle              : {args.phase_points}")
    print(f"nested critical grid              : [{args.critical_min},{args.critical_max}] h={args.critical_step}")
    print("="*190)

    # Geometry for all late switches.
    geom = {}
    for sw in [114,136,159]:
        j = sw-1
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand, left["beta_active"], left["gamma_active"]
        )
        c2 = match_candidate(
            cand, right["beta_active"], right["gamma_active"]
        )

        geom[sw] = {
            "b1": float(c1["beta"]),
            "b2": float(c2["beta"]),
            "g1": float(c1["gamma"]),
            "g2": float(c2["gamma"]),
            "tau": float(left["tau_end"]),
        }
        geom[sw]["da"] = abs(geom[sw]["b2"]-geom[sw]["b1"])
        geom[sw]["dg"] = abs(geom[sw]["g2"]-geom[sw]["g1"])

    # Resolve the two missing switch-136 points.
    sw = args.resolve_switch
    gg = geom[sw]

    phase = mod192.TwoLayerPhase(
        mp.mpf(str(gg["b1"])),
        mp.mpf(str(gg["g1"])),
        mp.mpf(str(gg["b2"])),
        mp.mpf(str(gg["g2"])),
    )
    ts = mp.mpf(str(gg["tau"]))
    da = mp.mpf(str(gg["da"]))
    dg = mp.mpf(str(gg["dg"]))
    g1 = mp.mpf(str(gg["g1"]))
    g2 = mp.mpf(str(gg["g2"]))
    period = 2*mp.pi/dg

    resolved_rows = []
    unresolved = []

    for x in xresolve:
        tau = ts+x/da
        ga = g1 if x < 0 else g2

        vals = []
        mixes = []
        pdiffs = []

        print(f"[resolve switch {sw}] x={float(x):.3f}")

        for off in offsets:
            rr = mod194.cycle_average_shifted(
                mod192, phase, tau, ga, ga, period,
                args.phase_points, tol, frac,
                args.newton_iters, args.search_cells,
                args.branch_count, args.max_subdivision_depth,
                off,
            )
            good = [r for r in rr if r.get("ok")]
            if not good:
                print(f"  offset={off:.3f} FAIL")
                continue

            r = good[0]
            v = float(r["mean_abs_epsilon_over_gamma"])
            vm = float(r["mean_abs_mix_over_gamma"])
            v2 = float(r["phase_stride2_over_gamma"])
            pdiff = abs(v2-v)/max(abs(v),1e-300)

            vals.append(v)
            mixes.append(vm)
            pdiffs.append(pdiff)

            print(
                f"  offset={off:.3f} r={v:.8e} "
                f"phaseDiff={pdiff:.3e}"
            )

        if len(vals) < args.success_offsets_needed:
            unresolved.append(float(x))
            continue

        mean = float(np.mean(vals))
        spread = float(
            (np.max(vals)-np.min(vals))/max(abs(mean),1e-300)
        )
        maxpd = float(max(pdiffs))

        accepted = bool(
            spread <= args.offset_spread_gate
            and maxpd <= args.phase_grid_gate
        )
        if not accepted:
            unresolved.append(float(x))

        resolved_rows.append({
            "switch": sw,
            "x": float(x),
            "tau": float(tau),
            "gamma_active": float(ga),
            "mean_abs_epsilon_over_gamma": mean,
            "mean_abs_mix_over_gamma": float(np.mean(mixes)),
            "successful_offsets": len(vals),
            "offset_relative_spread": spread,
            "max_phase_stride2_relative_difference": maxpd,
            "accepted": accepted,
        })

        print(
            f"  => mean={mean:.8e} offsets={len(vals)} "
            f"spread={spread:.3e} maxPhase={maxpd:.3e} "
            f"accepted={accepted}"
        )

    resolved = pd.DataFrame(resolved_rows)
    resolved.to_csv(args.prefix+"_RESOLVED.csv", index=False)

    # Rebuild profiles, inserting accepted resolved points.
    profiles = {}
    for sw in [114,136,159]:
        d = allprof[allprof["switch"].astype(int)==sw].copy()

        if sw == args.resolve_switch and len(resolved):
            good = resolved[resolved["accepted"]].copy()
            if len(good):
                for x0 in good["x"].tolist():
                    d = d[np.abs(d["x"].to_numpy(float)-x0) > 1e-9]
                d = pd.concat([d,good],ignore_index=True)

        d = (
            d.sort_values("x")
            .drop_duplicates("x",keep="last")
            .reset_index(drop=True)
        )
        d = ensure_intrinsic(d, geom[sw]["dg"])
        profiles[sw] = d

    # Diagnostics.
    summary_rows = []
    for sw in [114,136,159]:
        d = profiles[sw]
        K = K_of(d)

        nested = fixed_tail_nested_K(
            d,
            critical_min=args.critical_min,
            critical_max=args.critical_max,
            step=args.critical_step,
        )
        expm = exp_boundary_metrics(d)

        row = {
            "switch": sw,
            "K_hom": K,
            **nested,
            **expm,
        }
        summary_rows.append(row)

    swdf = pd.DataFrame(summary_rows)

    Kvals = swdf["K_hom"].to_numpy(float)
    Kmean = float(np.mean(Kvals))
    Kcv = float(np.std(Kvals,ddof=1)/Kmean)
    Kratio = float(np.max(Kvals)/np.min(Kvals))

    Cmax = float(swdf["majorant_C_required"].max())
    slopes = swdf["exp_tail_slope_p"].to_numpy(float)
    slope_maxerr = float(np.nanmax(np.abs(slopes-1.0)))
    postmax = float(swdf["K_post_switch"].max())

    nested_ok = bool(
        swdf["ok"].all()
        and np.all(
            swdf["K_2h_relative_difference"].to_numpy(float) <= 0.05
        )
        and np.all(
            swdf["K_4h_relative_difference"].to_numpy(float) <= 0.12
        )
    )

    majorant_ok = bool(Cmax <= args.majorant_C_gate)
    slope_ok = bool(slope_maxerr <= args.tail_slope_tolerance)
    post_ok = bool(postmax <= args.post_mass_gate)
    universal_K_ok = bool(Kratio <= 1.02)

    if (
        len(unresolved)==0
        and nested_ok
        and majorant_ok
        and slope_ok
        and post_ok
        and universal_K_ok
    ):
        verdict = "UNIVERSAL_EXPONENTIAL_BOUNDARY_LAYER_STRONGLY_SUPPORTED"
    elif majorant_ok and post_ok and universal_K_ok:
        verdict = "UNIVERSAL_EXPONENTIAL_BOUNDARY_LAYER_SUPPORTED_NUMERICAL_QUADRATURE_PARTIAL"
    else:
        verdict = "UNIVERSAL_EXPONENTIAL_BOUNDARY_LAYER_UNRESOLVED"

    allout = pd.concat(
        [d.assign(switch=sw) for sw,d in profiles.items()],
        ignore_index=True
    )
    allout.to_csv(args.prefix+"_PROFILES.csv", index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv", index=False)

    summary = {
        "version":198,
        "switches":[114,136,159],
        "unresolved_target_points":unresolved,
        "K_values":Kvals.tolist(),
        "K_mean":Kmean,
        "K_cv":Kcv,
        "K_max_over_min":Kratio,
        "max_required_exponential_majorant_C":Cmax,
        "max_tail_slope_error_from_1":slope_maxerr,
        "max_post_switch_K":postmax,
        "nested_quadrature_ok":nested_ok,
        "majorant_ok":majorant_ok,
        "tail_slope_ok":slope_ok,
        "post_switch_negligible":post_ok,
        "universal_K_ok":universal_K_ok,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8"
    )

    print()
    print("="*190)
    for _,r in swdf.iterrows():
        print(f"switch {int(r['switch'])}")
        print(f"  K_hom                           : {r['K_hom']:.9e}")
        if bool(r["ok"]):
            print(f"  K nested fine/2h/4h             : {r['K_nested_fine']:.9e} / {r['K_nested_2h']:.9e} / {r['K_nested_4h']:.9e}")
            print(f"  nested rel diff 2h/4h           : {r['K_2h_relative_difference']:.3e} / {r['K_4h_relative_difference']:.3e}")
        else:
            print(f"  nested grid missing             : {r.get('missing_grid', [])}")
        print(f"  tail exp slope p                : {r['exp_tail_slope_p']:.6f}")
        print(f"  tail exp log-R2                 : {r['exp_tail_log_R2']:.6f}")
        print(f"  required C for m<=C exp(x)      : {r['majorant_C_required']:.6f}")
        print(f"  K pre/post switch               : {r['K_pre_switch']:.9e} / {r['K_post_switch']:.9e}")
    print()
    print(f"K mean / CV                       : {Kmean:.9e} / {Kcv:.6e}")
    print(f"K max/min ratio                   : {Kratio:.6e}")
    print(f"max required exponential C        : {Cmax:.6e}")
    print(f"max |tail slope - 1|              : {slope_maxerr:.6e}")
    print(f"max post-switch K                 : {postmax:.6e}")
    print(f"unresolved target x               : {unresolved}")
    print(f"VERDICT                            : {verdict}")
    print("="*190)


if __name__ == "__main__":
    main()
