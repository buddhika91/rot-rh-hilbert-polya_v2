#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v103 — Complex-Plane Fredholm / Hurwitz Closure Audit
=============================================================

PURPOSE
-------
Use the already-frozen v102.1 finite-part operator family to test the stronger
statement needed for a Hurwitz/Laguerre-Polya route to RH:

    D_L(z) = det(I - z^2 H_L^{-2})
        -> Xi(z)/Xi(0)

locally uniformly for COMPLEX z.

Why this matters:
  * every finite-L H_L is self-adjoint;
  * therefore every exact D_L has only real zeros;
  * if D_L -> Xi/Xi(0) locally uniformly on C, then any nonreal Xi zero would
    force nearby nonreal zeros of D_L by Hurwitz, impossible.

This does NOT prove local uniform convergence.  It is a preregistered numerical
audit of exactly that theorem target.

FIREWALL
--------
The v102.1 archive was frozen before Xi.  This script:
  1. verifies the frozen SHA;
  2. reconstructs complex determinant approximants ONLY from frozen roots and
     frozen full_em1 moment completions;
  3. evaluates complex L-flow and moment-order stability;
  4. freezes all complex grids and determinant values again;
  5. only then imports mpmath and evaluates complex Xi.

No zero/Xi information is used to select radii, imaginary heights, L, depth,
tail order, or any construction parameter.

COMPLEX DOMAIN
--------------
For z = x + i y, off-critical zeta points correspond to

    s = 1/2 + i z = (1/2 - y) + i x.

Thus |Im z| <= 0.49 probes essentially the entire open critical strip
0.01 <= Re(s) <= 0.99.

The default audit uses:
    Re z in [0,50],
    Im z in {0, +/-0.10, +/-0.25, +/-0.49}.

Because the moment expansion is centered at z=0, all points must satisfy
|z| < E_N of the frozen prefix.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

VERSION = "v103"
BUILD = "2026-08-17-complex-fredholm-hurwitz-audit-v103"
EPS = 1e-15


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(x.real), "imag": float(x.imag)}
    if isinstance(x, complex):
        return {"real": float(x.real), "imag": float(x.imag)}
    return x


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def partial_moments(roots, order):
    r = np.asarray(roots, float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def complex_det_from_frozen(roots, completed_moments, zvals, order=None):
    """
    Frozen finite product times frozen Euler-Maclaurin tail:

      D_N(z) exp[-sum_m T_m z^(2m)/m],

    where T_m = S_m^completed - S_m^prefix.
    """
    r = np.asarray(roots, float)
    cm = np.asarray(completed_moments, float)
    if order is None:
        order = len(cm)
    order = min(int(order), len(cm))
    pm = partial_moments(r, order)
    tail = cm[:order] - pm

    out = np.empty(len(zvals), complex)
    inv2 = 1.0 / (r * r)

    for i, z in enumerate(zvals):
        z = complex(z)
        raw = np.prod(1.0 - z * z * inv2)
        lt = 0.0j
        for m, T in enumerate(tail, start=1):
            lt -= float(T) * (z ** (2 * m)) / m
        if not np.isfinite(lt.real) or not np.isfinite(lt.imag):
            raise RuntimeError(f"Nonfinite complex tail exponent at z={z}")
        if abs(lt.real) > 100:
            raise RuntimeError(
                f"Unphysical complex tail magnitude at z={z}: Re logtail={lt.real}"
            )
        out[i] = raw * np.exp(lt)
    return out


def sym_complex_rms(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    q = np.abs(a - b) / (1.0 + np.abs(a) + np.abs(b))
    return float(np.sqrt(np.mean(q * q)))


def sym_complex_sup(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    q = np.abs(a - b) / (1.0 + np.abs(a) + np.abs(b))
    return float(np.max(q))


def rel_l2(a, b):
    a = np.asarray(a, complex)
    b = np.asarray(b, complex)
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), EPS))


def xi_complex(mp, z):
    zz = mp.mpc(z.real, z.imag)
    s = mp.mpf("0.5") + 1j * zz
    return (
        mp.mpf("0.5")
        * s
        * (s - 1)
        * mp.power(mp.pi, -s / 2)
        * mp.gamma(s / 2)
        * mp.zeta(s)
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument("--L-list", default="2000,4000,8000,16000")
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--real-max", type=float, default=50.0)
    ap.add_argument("--real-step", type=float, default=0.5)
    ap.add_argument(
        "--imag-heights",
        default="0,0.10,-0.10,0.25,-0.25,0.49,-0.49",
    )
    ap.add_argument("--lower-order-drop", type=int, default=2)
    ap.add_argument("--xi-dps", type=int, default=60)
    ap.add_argument(
        "--prefix",
        default="rot_rh_complex_fredholm_hurwitz_v103",
    )
    args = ap.parse_args()

    Ls = [int(x) for x in args.L_list.split(",") if x.strip()]
    ys = parse_floats(args.imag_heights)
    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")

    if not archive.exists() or not manifest_path.exists():
        raise FileNotFoundError("v102.1 frozen archive/manifest not found.")

    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    expected = man.get("sha256")
    if got != expected:
        raise RuntimeError(
            f"v102.1 SHA mismatch: expected {expected}, got {got}"
        )

    data = np.load(archive, allow_pickle=False)
    d = int(args.depth)

    xs = np.arange(
        0.0,
        args.real_max + 0.5 * args.real_step,
        args.real_step,
    )
    zvals = np.asarray(
        [complex(float(x), float(y)) for y in ys for x in xs],
        complex,
    )
    ylabels = np.asarray([float(y) for y in ys for _ in xs], float)
    xlabels = np.asarray([float(x) for _ in ys for x in xs], float)

    # Ensure domain stays inside every frozen prefix radius.
    for L in Ls:
        roots = np.asarray(data[f"roots_L{L}_d{d}"], float)
        if np.max(np.abs(zvals)) >= roots[-1]:
            raise ValueError(
                f"Complex grid reaches |z|={np.max(np.abs(zvals)):.4f}, "
                f"but E_N(L={L})={roots[-1]:.4f}."
            )

    print("=" * 150)
    print("ROT-RH v103 — COMPLEX-PLANE FREDHOLM / HURWITZ CLOSURE AUDIT")
    print("=" * 150)
    print("v102.1 SHA verified             :", True)
    print("v102.1 SHA                      :", got)
    print("L ladder                        :", Ls)
    print("depth                           :", d)
    print("method                          :", args.method)
    print("Re z                            :", f"0..{args.real_max} step {args.real_step}")
    print("Im z                            :", ys)
    print("complex points                  :", len(zvals))
    print("Xi/zeta/zeros pre-freeze        : NONE")
    print("=" * 150)

    dets = {}
    order_rows = []
    domain_rows = []

    print("[1] Reconstruct frozen complex determinants", flush=True)
    for L in Ls:
        roots = np.asarray(data[f"roots_L{L}_d{d}"], float)
        key = f"mom_{args.method}_L{L}_d{d}"
        if key not in data:
            raise KeyError(f"Missing frozen moment key {key}")
        cm = np.asarray(data[key], float)
        full_order = len(cm)
        low_order = max(1, full_order - int(args.lower_order_drop))

        D = complex_det_from_frozen(
            roots, cm, zvals, order=full_order
        )
        Dlow = complex_det_from_frozen(
            roots, cm, zvals, order=low_order
        )
        dets[L] = D

        order_rows.append(
            {
                "L": L,
                "full_order": full_order,
                "lower_order": low_order,
                "complex_order_relative_l2": rel_l2(D, Dlow),
                "complex_order_symmetric_rms": sym_complex_rms(D, Dlow),
                "complex_order_symmetric_sup": sym_complex_sup(D, Dlow),
            }
        )
        print(
            f"  L={L:<7d} order {low_order}->{full_order}: "
            f"relL2={order_rows[-1]['complex_order_relative_l2']:.3e} "
            f"symRMS={order_rows[-1]['complex_order_symmetric_rms']:.3e}"
        )

    print("[2] PRE-XI complex local-uniform L-flow diagnostics", flush=True)
    flow_rows = []
    for L0, L1 in zip(Ls[:-1], Ls[1:]):
        a = dets[L0]
        b = dets[L1]
        row = {
            "L_from": L0,
            "L_to": L1,
            "complex_relative_l2": rel_l2(b, a),
            "complex_symmetric_rms": sym_complex_rms(b, a),
            "complex_symmetric_sup": sym_complex_sup(b, a),
        }
        flow_rows.append(row)
        print(
            f"  {L0}->{L1}: relL2={row['complex_relative_l2']:.3e} "
            f"symRMS={row['complex_symmetric_rms']:.3e} "
            f"symSUP={row['complex_symmetric_sup']:.3e}"
        )

    # Per-imaginary-height convergence; this detects an off-axis blow-up hidden
    # by averaging over the full box.
    print("[3] PRE-XI strip-by-strip convergence", flush=True)
    strip_rows = []
    nxs = len(xs)
    for y_index, y in enumerate(ys):
        sl = slice(y_index * nxs, (y_index + 1) * nxs)
        for L0, L1 in zip(Ls[:-1], Ls[1:]):
            a = dets[L0][sl]
            b = dets[L1][sl]
            strip_rows.append(
                {
                    "imag_z": y,
                    "L_from": L0,
                    "L_to": L1,
                    "symmetric_rms": sym_complex_rms(b, a),
                    "symmetric_sup": sym_complex_sup(b, a),
                }
            )
        last = strip_rows[-1]
        print(
            f"  Im z={y:+.2f}, latest {last['L_from']}->{last['L_to']}: "
            f"RMS={last['symmetric_rms']:.3e} "
            f"SUP={last['symmetric_sup']:.3e}"
        )

    # Freeze complex values BEFORE Xi.
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    freeze = Path(str(prefix) + "_FROZEN_PRE_XI.npz")
    fmanifest = Path(str(prefix) + "_FROZEN_MANIFEST.json")

    payload = {
        "xlabels": xlabels,
        "ylabels": ylabels,
        "zreal": np.real(zvals),
        "zimag": np.imag(zvals),
        "L_values": np.asarray(Ls, int),
    }
    for L in Ls:
        payload[f"Dreal_L{L}"] = np.real(dets[L])
        payload[f"Dimag_L{L}"] = np.imag(dets[L])

    np.savez_compressed(freeze, **payload)
    fsha = sha256_file(freeze)

    pre_gates = {
        "complex_tail_order_stable":
            max(r["complex_order_symmetric_rms"] for r in order_rows) < 1e-8,
        "latest_complex_Lflow_below_1e6":
            flow_rows[-1]["complex_symmetric_rms"] < 1e-6,
        "latest_complex_sup_below_1e5":
            flow_rows[-1]["complex_symmetric_sup"] < 1e-5,
    }

    fman = {
        "version": VERSION,
        "build": BUILD,
        "parent_v102_sha256": got,
        "sha256": fsha,
        "parameters": {
            "L_list": Ls,
            "depth": d,
            "method": args.method,
            "real_max": args.real_max,
            "real_step": args.real_step,
            "imag_heights": ys,
            "lower_order_drop": args.lower_order_drop,
        },
        "firewall": {
            "Xi_used_pre_freeze": False,
            "zeta_used_pre_freeze": False,
            "known_zeros_used_pre_freeze": False,
        },
        "pre_gates": pre_gates,
        "complex_Lflow": flow_rows,
        "strip_Lflow": strip_rows,
    }
    fmanifest.write_text(
        json.dumps(json_safe(fman), indent=2),
        encoding="utf-8",
    )

    print("[freeze] complex SHA256           :", fsha)
    print("[freeze] Xi firewall CLOSED.")

    # POST-FREEZE
    import mpmath as mp
    mp.mp.dps = int(args.xi_dps)

    print("[4] POST-FREEZE complex Xi evaluation", flush=True)
    xi0 = xi_complex(mp, 0j)
    xiv = np.empty(len(zvals), complex)
    for i, z in enumerate(zvals):
        q = xi_complex(mp, z) / xi0
        xiv[i] = complex(float(mp.re(q)), float(mp.im(q)))

    post_rows = []
    for L in Ls:
        D = dets[L]
        post_rows.append(
            {
                "L": L,
                "complex_Xi_symmetric_rms": sym_complex_rms(D, xiv),
                "complex_Xi_symmetric_sup": sym_complex_sup(D, xiv),
                "complex_Xi_relative_l2": rel_l2(D, xiv),
            }
        )
        r = post_rows[-1]
        print(
            f"  L={L:<7d}: Xi symRMS={r['complex_Xi_symmetric_rms']:.3e} "
            f"symSUP={r['complex_Xi_symmetric_sup']:.3e} "
            f"relL2={r['complex_Xi_relative_l2']:.3e}"
        )

    print("[5] POST-FREEZE off-axis strip identity audit", flush=True)
    post_strip_rows = []
    finalL = Ls[-1]
    finalD = dets[finalL]
    for y_index, y in enumerate(ys):
        sl = slice(y_index * nxs, (y_index + 1) * nxs)
        row = {
            "imag_z": y,
            "Re_s": 0.5 - y,
            "symmetric_rms": sym_complex_rms(finalD[sl], xiv[sl]),
            "symmetric_sup": sym_complex_sup(finalD[sl], xiv[sl]),
            "relative_l2": rel_l2(finalD[sl], xiv[sl]),
        }
        post_strip_rows.append(row)
        print(
            f"  Im z={y:+.2f} (Re s={0.5-y:.2f}): "
            f"RMS={row['symmetric_rms']:.3e} "
            f"SUP={row['symmetric_sup']:.3e}"
        )

    final = post_rows[-1]
    post_gates = {
        "complex_Xi_RMS_below_1e6":
            final["complex_Xi_symmetric_rms"] < 1e-6,
        "complex_Xi_SUP_below_1e5":
            final["complex_Xi_symmetric_sup"] < 1e-5,
        "all_offaxis_strips_below_1e5_RMS":
            all(r["symmetric_rms"] < 1e-5 for r in post_strip_rows),
    }

    if all(pre_gates.values()) and all(post_gates.values()):
        verdict = (
            "PASS_V103_COMPLEX_FREDHOLM_CLOSURE_NUMERICALLY_SURVIVES_OFF_AXIS__"
            "NEXT_PROVE_LOCAL_UNIFORM_CONVERGENCE_AND_EXACT_IDENTITY"
        )
    elif all(pre_gates.values()):
        verdict = (
            "PARTIAL_V103_COMPLEX_LFLOW_STABLE_BUT_OFF_AXIS_XI_IDENTITY_FAILS"
        )
    else:
        verdict = (
            "NO_GO_V103_COMPLEX_LOCAL_UNIFORM_CONVERGENCE_NOT_NUMERICALLY_SUPPORTED"
        )

    flow_csv = Path(str(prefix) + "_PRE_XI_COMPLEX_LFLOW.csv")
    strip_csv = Path(str(prefix) + "_PRE_XI_STRIPS.csv")
    order_csv = Path(str(prefix) + "_PRE_XI_ORDER.csv")
    post_csv = Path(str(prefix) + "_POST_XI_COMPLEX.csv")
    post_strip_csv = Path(str(prefix) + "_POST_XI_STRIPS.csv")
    verdict_path = Path(str(prefix) + "_VERDICT.json")

    write_csv(flow_csv, flow_rows)
    write_csv(strip_csv, strip_rows)
    write_csv(order_csv, order_rows)
    write_csv(post_csv, post_rows)
    write_csv(post_strip_csv, post_strip_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Hurwitz_theorem_applied_as_proof": False,
        "parent_v102_sha256": got,
        "freeze_sha256": fsha,
        "pre_gates": pre_gates,
        "post_gates": post_gates,
        "final_complex_Xi": final,
        "postfreeze_strips": post_strip_rows,
        "theorem_target": (
            "Prove exact finite-L determinants D_L have only real zeros and "
            "converge locally uniformly on C to Xi(z)/Xi(0). Then Hurwitz "
            "excludes nonreal Xi zeros."
        ),
    }
    verdict_path.write_text(
        json.dumps(json_safe(packet), indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 150)
    print("FINAL v103 COMPLEX-CLOSURE VERDICT")
    print("=" * 150)
    print("verdict                         :", verdict)
    print("latest PRE-Xi complex L RMS    :", f"{flow_rows[-1]['complex_symmetric_rms']:.12e}")
    print("latest PRE-Xi complex L SUP    :", f"{flow_rows[-1]['complex_symmetric_sup']:.12e}")
    print("final POST-Xi complex RMS      :", f"{final['complex_Xi_symmetric_rms']:.12e}")
    print("final POST-Xi complex SUP      :", f"{final['complex_Xi_symmetric_sup']:.12e}")
    print("final POST-Xi complex rel L2   :", f"{final['complex_Xi_relative_l2']:.12e}")
    print("pre-gates                      :", pre_gates)
    print("post-gates                     :", post_gates)
    print("RH proof                       : FALSE")
    print("exact local-uniform theorem    : OPEN")
    print("freeze SHA256                  :", fsha)
    print("verdict file                   :", verdict_path)
    print("=" * 150)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
