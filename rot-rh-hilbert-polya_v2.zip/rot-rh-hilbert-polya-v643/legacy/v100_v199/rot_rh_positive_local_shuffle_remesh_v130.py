#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v130 — Positive Local-Weight Shuffle / Adaptive-Remesh Red-Team
======================================================================

Preserves positivity, exact frequency support, and the exact multiset of
coefficient magnitudes inside narrow log2(n) windows. Randomly permutes which
nearby frequency gets which positive weight, then rebuilds each surrogate's
own crossing mesh.

POST-HOC RED-TEAM. NO Xi/zeta/known-zero evaluations.
"""

from __future__ import annotations
import argparse, copy, csv, dataclasses, importlib, json, math
from pathlib import Path
import numpy as np

VERSION = "v130"
BUILD = "2026-08-18-positive-local-weight-shuffle-adaptive-remesh-v130"
EPS = 1e-30

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8"); return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k); seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields); w.writeheader(); w.writerows(rows)

def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]

def cumulative_max(x):
    x=np.asarray(x,float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0

def lowfreq_fraction(x,bins):
    x=np.asarray(x,float); y=x-np.mean(x)
    z=np.fft.rfft(y); p=np.abs(z)**2
    if len(p)<=1 or np.sum(p[1:])<=EPS: return 0.0
    b=min(int(bins),len(p)-1)
    return float(np.sum(p[1:b+1])/np.sum(p[1:]))

def rms(x):
    x=np.asarray(x,float); return float(np.sqrt(np.mean(x*x)))

def corr(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    if np.std(a)<=EPS or np.std(b)<=EPS: return float("nan")
    return float(np.corrcoef(a,b)[0,1])

def percentile_le(samples,value):
    a=np.asarray(samples,float); return float(np.mean(a<=value))

def permutation_metrics(x,nperm,rng,lowfreq_bins):
    x=np.asarray(x,float)
    rc=cumulative_max(x); rl=lowfreq_fraction(x,lowfreq_bins)
    pc=np.empty(int(nperm)); pl=np.empty(int(nperm))
    for t in range(int(nperm)):
        y=rng.permutation(x)
        pc[t]=cumulative_max(y); pl[t]=lowfreq_fraction(y,lowfreq_bins)
    pm=float(np.mean(pc))
    return dict(cumulative_max=rc,lowfreq_fraction=rl,perm_cumulative_mean=pm,
                cum_over_perm_mean=rc/max(pm,EPS),
                cumulative_percentile=percentile_le(pc,rc),
                lowfreq_percentile=percentile_le(pl,rl))

def block_sum_rms(x,block):
    x=np.asarray(x,float); b=int(block); n=len(x)//b
    if n<1: return float("nan")
    y=x[:n*b].reshape(n,b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))

def block_ratio(x,block,nperm,rng):
    real=block_sum_rms(x,block); vals=np.empty(int(nperm))
    for t in range(int(nperm)):
        vals[t]=block_sum_rms(rng.permutation(x),block)
    m=float(np.mean(vals))
    return dict(ratio=real/max(m,EPS),percentile=percentile_le(vals,real))

def clone_with_phase_weights(phase,new_weights):
    new_weights=np.asarray(new_weights,float)
    if dataclasses.is_dataclass(phase):
        try: return dataclasses.replace(phase,phase_w=new_weights.copy())
        except Exception: pass
    q=copy.deepcopy(phase)
    try:
        setattr(q,"phase_w",new_weights.copy()); return q
    except Exception: pass
    try:
        object.__setattr__(q,"phase_w",new_weights.copy()); return q
    except Exception as exc:
        raise RuntimeError("Could not clone phase with replacement phase_w.") from exc

def prime_endpoint_functions(Evals,phase_w,logs,chunk_terms):
    Evals=np.asarray(Evals,float); phase_w=np.asarray(phase_w,float); logs=np.asarray(logs,float)
    Fp=np.zeros(len(Evals)); Anti=np.zeros(len(Evals))
    for s in range(0,len(logs),int(chunk_terms)):
        e=min(len(logs),s+int(chunk_terms))
        lg=logs[s:e]; ww=phase_w[s:e]; ang=Evals[:,None]*lg[None,:]
        Fp += -np.sum(np.sin(ang)*ww[None,:],axis=1)/math.pi
        Anti += np.sum(np.cos(ang)*(ww/lg)[None,:],axis=1)/math.pi
    return Fp,Anti

def prime_cell_defects(roots,k_start,k_end,phase_w,logs,chunk_terms):
    ks=list(range(k_start,k_end+1))
    lo=np.asarray([roots[k-1] for k in ks],float)
    hi=np.asarray([roots[k] for k in ks],float)
    h=hi-lo; endpoints=np.concatenate([[lo[0]],hi])
    Fp,Anti=prime_endpoint_functions(endpoints,phase_w,logs,chunk_terms)
    q=Anti[1:]-Anti[:-1]-0.5*h*(Fp[:-1]+Fp[1:])
    return q,lo,hi

def dyadic_cross_ratio(q_total,lo,hi,phase_w,logs,chunk_terms):
    mid=0.5*(lo+hi); h=hi-lo
    jb=np.floor(logs/math.log(2.0)+1e-12).astype(int)
    bands=sorted(np.unique(jb).tolist()); qb={j:np.zeros(len(lo)) for j in bands}
    for s in range(0,len(logs),int(chunk_terms)):
        e=min(len(logs),s+int(chunk_terms))
        om=logs[s:e]; ww=phase_w[s:e]; jbc=jb[s:e]
        delta=0.5*h[:,None]*om[None,:]; ph=mid[:,None]*om[None,:]
        kernel=(2.0/math.pi)*np.sin(ph)*(delta*np.cos(delta)-np.sin(delta))
        contrib=kernel*(ww/om)[None,:]
        for j in np.unique(jbc):
            m=(jbc==j); qb[int(j)] += np.sum(contrib[:,m],axis=1)
    recon=np.sum(np.vstack([qb[j] for j in bands]),axis=0)
    rel=float(np.linalg.norm(recon-q_total)/max(np.linalg.norm(q_total),EPS))
    denom=sum(cumulative_max(qb[j]) for j in bands)
    return cumulative_max(q_total)/max(denom,EPS),rel

def local_positive_shuffle(weights,xlog2,width,offset,rng):
    weights=np.asarray(weights,float)
    if np.any(weights<=0): raise RuntimeError("Expected strictly positive phase weights.")
    gid=np.floor((xlog2-offset)/width+1e-12).astype(int)
    out=weights.copy(); shuffled_bins=0; moved_terms=0
    for g in np.unique(gid):
        idx=np.flatnonzero(gid==g)
        if len(idx)<2: continue
        vals=out[idx].copy()
        perm=rng.permutation(len(idx))
        if np.array_equal(perm,np.arange(len(idx))):
            perm=np.roll(np.arange(len(idx)),1)
        out[idx]=vals[perm]
        shuffled_bins+=1
        moved_terms += int(np.sum(perm!=np.arange(len(idx))))
    return out,shuffled_bins,moved_terms

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--v102-module",default="rot_rh_pnt_finite_part_full_pipeline_v102_1")
    ap.add_argument("--base-module",default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit")
    ap.add_argument("--v123-prefix",default="rot_rh_blind_prime_self_cancellation_v123")
    ap.add_argument("--L",type=int,default=16000)
    ap.add_argument("--tail-factor",type=float,default=18.0)
    ap.add_argument("--counter-q",type=int,default=8192)
    ap.add_argument("--counter-qcheck",type=int,default=16384)
    ap.add_argument("--scan-points",type=int,default=96)
    ap.add_argument("--k-start",type=int,default=1088)
    ap.add_argument("--k-end",type=int,default=1407)
    ap.add_argument("--max-depth",type=int,default=1408)
    ap.add_argument("--local-widths",default="0.125,0.25,0.5")
    ap.add_argument("--surrogates-per-width",type=int,default=4)
    ap.add_argument("--permutations",type=int,default=2000)
    ap.add_argument("--lowfreq-bins",type=int,default=8)
    ap.add_argument("--prime-chunk-terms",type=int,default=2048)
    ap.add_argument("--seed",type=int,default=20260818)
    ap.add_argument("--prefix",default="rot_rh_positive_local_shuffle_remesh_v130")
    args=ap.parse_args()

    widths=parse_floats(args.local_widths)
    if args.max_depth<args.k_end+1: raise ValueError("max-depth too small.")

    cells_path=Path(str(Path(args.v123_prefix).expanduser().resolve())+"_CELLS.csv")
    if not cells_path.exists(): raise FileNotFoundError(cells_path)
    raw=read_csv(cells_path)
    rr=sorted([r for r in raw if args.k_start<=int(float(r["k"]))<=args.k_end],
              key=lambda r:int(float(r["k"])))
    if len(rr)!=args.k_end-args.k_start+1: raise RuntimeError("Real cell range incomplete.")
    qreal=np.asarray([float(r["q_prime"]) for r in rr])
    loreal=np.asarray([float(r["lo"]) for r in rr])
    hireal=np.asarray([float(r["hi"]) for r in rr])

    print("="*168)
    print("ROT-RH v130 — POSITIVE LOCAL-WEIGHT SHUFFLE / ADAPTIVE-REMESH RED-TEAM")
    print("="*168)
    print("real source                     :",cells_path)
    print("cells                           :",f"{args.k_start}..{args.k_end}")
    print("local log2 widths               :",widths)
    print("surrogates/width                :",args.surrogates_per_width)
    print("total surrogates                :",len(widths)*args.surrogates_per_width)
    print("permutations/sequence           :",args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("="*168)

    v102=importlib.import_module(args.v102_module)
    base=importlib.import_module(args.base_module)
    phase=v102.RenormalizedPhase.build(base,int(args.L),float(args.tail_factor),int(args.counter_q))
    w=np.asarray(phase.phase_w,float); logs=np.asarray(phase.logs,float)
    xlog2=logs/math.log(2.0)
    print("[1] Baseline phase")
    print("  arithmetic terms              :",len(logs))
    print("  min/max phase_w               :",f"{np.min(w):.6e} / {np.max(w):.6e}")
    print("  nonpositive weights           :",int(np.sum(w<=0)))
    if np.any(w<=0): raise RuntimeError("Positivity premise invalid.")

    rng=np.random.default_rng(args.seed)
    print("[2] Real reference")
    real_pm=permutation_metrics(qreal,args.permutations,rng,args.lowfreq_bins)
    real_b16=block_ratio(qreal,16,args.permutations,rng)
    real_b32=block_ratio(qreal,32,args.permutations,rng)
    real_b64=block_ratio(qreal,64,args.permutations,rng)
    real_cross,recon=dyadic_cross_ratio(qreal,loreal,hireal,w,logs,args.prime_chunk_terms)
    print("  cum/permMean                   :",f"{real_pm['cum_over_perm_mean']:.6f}")
    print("  cumulative percentile         :",f"{100*real_pm['cumulative_percentile']:.4f}%")
    print("  lowF percentile               :",f"{100*real_pm['lowfreq_percentile']:.4f}%")
    print("  block16/32/64                 :",f"{real_b16['ratio']:.4f}, {real_b32['ratio']:.4f}, {real_b64['ratio']:.4f}")
    print("  dyadic cross-scale ratio      :",f"{real_cross:.6e}")
    if recon>1e-8: raise RuntimeError("Real reconstruction failed.")

    probe_E=np.linspace(loreal[0],hireal[-1],9)
    Fbase=np.asarray(phase.F(probe_E),float)

    print("[3] Positive local-shuffle surrogates",flush=True)
    sur=[]; sid=0
    for width in widths:
        for rep in range(args.surrogates_per_width):
            sid+=1; offset=float(rng.uniform(0,width))
            ws,nb,nm=local_positive_shuffle(w,xlog2,width,offset,rng)
            dW=float(np.linalg.norm(ws-w)/max(np.linalg.norm(w),EPS))
            sphase=clone_with_phase_weights(phase,ws)
            dF=float(np.linalg.norm(np.asarray(sphase.F(probe_E),float)-Fbase))
            if nm==0 or dW<=1e-14 or dF<=1e-12: raise RuntimeError("Inactive surrogate.")
            print(f"  surrogate {sid}: W={width:g} O={offset:.4f} moved={nm} dWrel={dW:.3e} dF={dF:.3e}",flush=True)

            support=v102.ordered_support(sphase,depth=int(args.max_depth),
                                         scan_points=int(args.scan_points),
                                         qcheck=int(args.counter_qcheck))
            roots=np.asarray(support.roots,float)
            qs,lo,hi=prime_cell_defects(roots,args.k_start,args.k_end,ws,logs,args.prime_chunk_terms)
            pm=permutation_metrics(qs,args.permutations,rng,args.lowfreq_bins)
            b16=block_ratio(qs,16,args.permutations,rng)
            b32=block_ratio(qs,32,args.permutations,rng)
            b64=block_ratio(qs,64,args.permutations,rng)
            cross,crecon=dyadic_cross_ratio(qs,lo,hi,ws,logs,args.prime_chunk_terms)
            row=dict(surrogate=sid,width_log2=width,offset_log2=offset,
                     shuffled_bins=nb,moved_terms=nm,weight_rel_change=dW,
                     phase_probe_delta_l2=dF,root_min=float(roots[0]),
                     root_max=float(roots[-1]),root_max_residual=float(np.max(support.residuals)),
                     qphase=float(support.quadrature_phase_rel_l2),
                     qder=float(support.quadrature_deriv_rel_l2),
                     corr_qprime_with_real=corr(qs,qreal),
                     cum_over_perm_mean=pm["cum_over_perm_mean"],
                     cumulative_percentile=pm["cumulative_percentile"],
                     lowfreq_percentile=pm["lowfreq_percentile"],
                     block16_ratio=b16["ratio"],block32_ratio=b32["ratio"],
                     block64_ratio=b64["ratio"],dyadic_cross_scale_ratio=cross,
                     cross_reconstruction_rel_l2=crecon)
            sur.append(row)
            print(f"    roots=[{roots[0]:.3f},{roots[-1]:.3f}] res={row['root_max_residual']:.2e} "
                  f"corrReal={row['corr_qprime_with_real']:+.3f} cum/perm={row['cum_over_perm_mean']:.3f} "
                  f"pCum={100*row['cumulative_percentile']:.2f}% pLowF={100*row['lowfreq_percentile']:.2f}% "
                  f"cross={cross:.3e}")

    print("[4] Rankings")
    metrics=[("cum_over_perm_mean",real_pm["cum_over_perm_mean"]),
             ("cumulative_percentile",real_pm["cumulative_percentile"]),
             ("lowfreq_percentile",real_pm["lowfreq_percentile"]),
             ("block16_ratio",real_b16["ratio"]),("block32_ratio",real_b32["ratio"]),
             ("block64_ratio",real_b64["ratio"]),("dyadic_cross_scale_ratio",real_cross)]
    ranks=[]; overall={}
    for width in widths:
        ss=[r for r in sur if r["width_log2"]==width]
        print(f"  width {width:g}:")
        for key,rval in metrics:
            vals=np.asarray([r[key] for r in ss],float); frac=float(np.mean(vals<=rval))
            ranks.append(dict(scope=f"W{width:g}",metric=key,real_value=rval,
                              surrogate_count=len(vals),surrogate_mean=float(np.mean(vals)),
                              surrogate_median=float(np.median(vals)),surrogate_min=float(np.min(vals)),
                              surrogate_max=float(np.max(vals)),fraction_as_good_or_better=frac))
            print(f"    {key:<27s}: real={rval:.4e} med={np.median(vals):.4e} asGood={100*frac:.1f}%")
    print("  overall:")
    for key,rval in metrics:
        vals=np.asarray([r[key] for r in sur],float); frac=float(np.mean(vals<=rval))
        overall[key]=dict(real=rval,surrogate_median=float(np.median(vals)),
                          surrogate_min=float(np.min(vals)),fraction_as_good_or_better=frac)
        ranks.append(dict(scope="ALL",metric=key,real_value=rval,surrogate_count=len(vals),
                          surrogate_mean=float(np.mean(vals)),surrogate_median=float(np.median(vals)),
                          surrogate_min=float(np.min(vals)),surrogate_max=float(np.max(vals)),
                          fraction_as_good_or_better=frac))
        print(f"    {key:<27s}: real={rval:.4e} med={np.median(vals):.4e} min={np.min(vals):.4e} asGood={100*frac:.2f}%")

    qvalid=all(r["root_max_residual"]<1e-8 and r["cross_reconstruction_rel_l2"]<1e-8 for r in sur)
    cross_rank=overall["dyadic_cross_scale_ratio"]["fraction_as_good_or_better"]
    cum_rank=overall["cum_over_perm_mean"]["fraction_as_good_or_better"]
    b32_rank=overall["block32_ratio"]["fraction_as_good_or_better"]

    if not qvalid:
        verdict="FAIL_V130_SURROGATE_NUMERICAL_SUPPORT_INVALID"
        mech="SURROGATE_NUMERICS_INVALID__NO_SCIENTIFIC_INTERPRETATION"
    elif cross_rank<=0.10 and cum_rank<=0.10 and b32_rank<=0.10:
        verdict="PASS_V130_POSITIVE_LOCAL_SHUFFLE_REDTEAM_COMPLETE"
        mech="EXACT_POSITIVE_MANGOLDT_WEIGHT_FREQUENCY_PAIRING_REMAINS_SPECIAL_UNDER_LOCAL_SHUFFLE_REMESH_CONTROLS"
    elif cross_rank>=0.30 and cum_rank>=0.30:
        verdict="PASS_V130_POSITIVE_LOCAL_SHUFFLE_REDTEAM_COMPLETE"
        mech="LOCAL_POSITIVE_WEIGHT_SCRAMBLES_REPRODUCE_CANCELLATION__EXACT_ARITHMETIC_PAIRING_NOT_ESSENTIAL"
    else:
        verdict="PASS_V130_POSITIVE_LOCAL_SHUFFLE_REDTEAM_COMPLETE"
        mech="POSITIVE_LOCAL_SHUFFLE_CONTROL_MIXED__ARITHMETIC_SPECIALNESS_PARTIAL"

    prefix=Path(args.prefix).expanduser().resolve(); prefix.parent.mkdir(parents=True,exist_ok=True)
    write_csv(Path(str(prefix)+"_SURROGATES.csv"),sur)
    write_csv(Path(str(prefix)+"_RANKING.csv"),ranks)
    packet=dict(version=VERSION,build=BUILD,verdict=verdict,mechanism=mech,RH_proof=False,
                Xi_used=False,zeta_used=False,known_zeros_used=False,surrogate_count=len(sur),
                widths=widths,real_metrics={k:v for k,v in metrics},overall_ranking=overall)
    out=Path(str(prefix)+"_VERDICT.json"); out.write_text(json.dumps(packet,indent=2),encoding="utf-8")

    print("\n"+"="*168)
    print("FINAL v130 VERDICT")
    print("="*168)
    print("verdict                         :",verdict)
    print("mechanism                       :",mech)
    print("surrogate count                 :",len(sur))
    print("real cum/permMean               :",f"{real_pm['cum_over_perm_mean']:.12e}")
    print("real dyadic cross ratio         :",f"{real_cross:.12e}")
    print("surrogates as-good cumulative   :",f"{100*cum_rank:.6f}%")
    print("surrogates as-good block32      :",f"{100*b32_rank:.6f}%")
    print("surrogates as-good cross-scale  :",f"{100*cross_rank:.6f}%")
    print("RH proof                        : FALSE")
    print("verdict file                    :",out)
    print("="*168)

if __name__=="__main__":
    raise SystemExit(main())
