#!/usr/bin/env python3
"""
ROT-RH v145 — ARCHIMEDEAN / ARITHMETIC REMAINDER SEPARATION AUDIT

ZERO-COST postprocessor: reuses v144 sampled F_L(E).
No new prime sums, no root solving, no Xi, no zeta, no zero ordinates.

Decomposition
-------------
Using the standard Riemann-Siegel theta function

    theta(E) = Im log Gamma(1/4 + iE/2) - (E/2) log(pi),

define

    N_arch(E) = theta(E)/pi + 1,

and the residual arithmetic finite-part contribution

    R_L(E) = F_L^ren(E) - N_arch(E).

The high-k cutoff-independence theorem would become much easier if one can
prove a cutoff-uniform bound such as

    R_L(E) <= C0 + C1 log(E+e)                       (upper bound)

or, more strongly,

    |R_L(E)| <= C0 + C1 log(E+e).                    (two-sided bound)

Together with a standard Stirling upper bound for theta(E), this yields an
explicit cutoff-uniform counting bound, hence a uniform Weyl lower bound and
a summable trace-tail majorant.

This script numerically searches candidate C1 values and reports the smallest
sampled C0 required across the entire interlaced cutoff net.

Outputs
-------
<prefix>_CANDIDATES.csv
<prefix>_L_SUMMARY.csv
<prefix>_ENERGY_ENVELOPE.csv
<prefix>_SAMPLES.npz
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from scipy.special import loggamma
except Exception as exc:
    raise RuntimeError("scipy.special.loggamma is required for v145") from exc


def csv_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def write_csv(path, rows):
    path = Path(path)
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def theta_rs(t):
    t = np.asarray(t, dtype=float)
    z = 0.25 + 0.5j * t
    return np.imag(loggamma(z)) - 0.5 * t * math.log(math.pi)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--samples-npz",
        default="rot_rh_uniform_weyl_majorant_v144_SAMPLES.npz",
    )
    ap.add_argument(
        "--C1-values",
        default="0,0.05,0.10,0.15,0.20,0.25,0.30,0.40,0.50,0.75,1.00",
    )
    ap.add_argument("--selected-C1", type=float, default=0.25)
    ap.add_argument(
        "--E-growth-min",
        type=float,
        default=20.0,
        help="Start of high-energy growth diagnostics.",
    )
    ap.add_argument(
        "--C0-safety",
        type=float,
        default=0.25,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_arithmetic_remainder_v145",
    )

    args = ap.parse_args()

    z = np.load(args.samples_npz)
    Ls = np.asarray(z["L"], dtype=int)
    E = np.asarray(z["E"], dtype=float)
    F = np.asarray(z["F"], dtype=float)

    if F.shape != (len(Ls), len(E)):
        raise RuntimeError("Unexpected F matrix shape in v144 samples.")

    C1_values = sorted(set(csv_floats(args.C1_values) + [args.selected_C1]))

    theta = theta_rs(E)
    Narch = theta / math.pi + 1.0
    R = F - Narch[None, :]

    logw = np.log(E + math.e)

    high = E >= args.E_growth_min
    if not np.any(high):
        raise RuntimeError("No samples above --E-growth-min.")

    print("=" * 128)
    print("ROT-RH v145 — ARCHIMEDEAN / ARITHMETIC REMAINDER SEPARATION AUDIT")
    print("=" * 128)
    print("Xi / zeta / known zeros          : NONE")
    print(f"loaded cutoffs                    : {Ls.tolist()}")
    print(f"E range                           : [{E.min()}, {E.max()}]")
    print(f"sample points                     : {len(E)}")
    print(f"high-energy diagnostics begin     : {args.E_growth_min}")
    print(f"C1 candidates                     : {C1_values}")
    print("=" * 128)

    # ------------------------------------------------------------------
    # Candidate logarithmic envelopes
    # ------------------------------------------------------------------
    candidate_rows = []

    for C1 in C1_values:
        upper_q = R - C1 * logw[None, :]
        abs_q = np.abs(R) - C1 * logw[None, :]

        iu = np.unravel_index(np.argmax(upper_q), upper_q.shape)
        ia = np.unravel_index(np.argmax(abs_q), abs_q.shape)

        C0_upper_req = float(upper_q[iu])
        C0_abs_req = float(abs_q[ia])

        # Also high-energy-only requirements.
        upper_high = R[:, high] - C1 * logw[high][None, :]
        abs_high = np.abs(R[:, high]) - C1 * logw[high][None, :]

        ihu = np.unravel_index(np.argmax(upper_high), upper_high.shape)
        iha = np.unravel_index(np.argmax(abs_high), abs_high.shape)

        Ehigh = E[high]

        candidate_rows.append(dict(
            C1=C1,
            C0_upper_required=max(0.0, C0_upper_req),
            C0_upper_safe=max(0.0, C0_upper_req + args.C0_safety),
            upper_worst_L=int(Ls[iu[0]]),
            upper_worst_E=float(E[iu[1]]),
            upper_worst_R=float(R[iu]),
            C0_abs_required=max(0.0, C0_abs_req),
            C0_abs_safe=max(0.0, C0_abs_req + args.C0_safety),
            abs_worst_L=int(Ls[ia[0]]),
            abs_worst_E=float(E[ia[1]]),
            abs_worst_R=float(R[ia]),
            C0_upper_required_highE=max(0.0, float(upper_high[ihu])),
            upper_high_worst_L=int(Ls[ihu[0]]),
            upper_high_worst_E=float(Ehigh[ihu[1]]),
            C0_abs_required_highE=max(0.0, float(abs_high[iha])),
            abs_high_worst_L=int(Ls[iha[0]]),
            abs_high_worst_E=float(Ehigh[iha[1]]),
        ))

    write_csv(args.prefix + "_CANDIDATES.csv", candidate_rows)

    selected = min(candidate_rows, key=lambda r: abs(r["C1"] - args.selected_C1))
    C1 = float(selected["C1"])
    C0u = float(selected["C0_upper_safe"])
    C0a = float(selected["C0_abs_safe"])

    # ------------------------------------------------------------------
    # Per-cutoff residual stats
    # ------------------------------------------------------------------
    L_rows = []
    for i, L in enumerate(Ls):
        rr = R[i]
        ratio = np.abs(rr[high]) / logw[high]

        L_rows.append(dict(
            L=int(L),
            R_min=float(np.min(rr)),
            R_max=float(np.max(rr)),
            max_abs_R=float(np.max(np.abs(rr))),
            highE_max_abs_R_over_log=float(np.max(ratio)),
            highE_q95_abs_R_over_log=float(np.quantile(ratio, 0.95)),
            selected_upper_margin_min=float(
                np.min(C0u + C1 * logw - rr)
            ),
            selected_abs_margin_min=float(
                np.min(C0a + C1 * logw - np.abs(rr))
            ),
        ))

    write_csv(args.prefix + "_L_SUMMARY.csv", L_rows)

    # ------------------------------------------------------------------
    # Energy-wise cutoff envelope
    # ------------------------------------------------------------------
    env_rows = []
    Rmax = np.max(R, axis=0)
    Rmin = np.min(R, axis=0)
    Rabs = np.max(np.abs(R), axis=0)
    Rspread = Rmax - Rmin

    for j, EE in enumerate(E):
        env_rows.append(dict(
            E=float(EE),
            theta=float(theta[j]),
            N_arch=float(Narch[j]),
            R_max_across_L=float(Rmax[j]),
            R_min_across_L=float(Rmin[j]),
            R_abs_max_across_L=float(Rabs[j]),
            R_spread_across_L=float(Rspread[j]),
            absR_over_log=float(Rabs[j] / logw[j]),
            selected_upper_envelope=float(C0u + C1 * logw[j]),
            selected_abs_envelope=float(C0a + C1 * logw[j]),
        ))

    write_csv(args.prefix + "_ENERGY_ENVELOPE.csv", env_rows)

    # ------------------------------------------------------------------
    # Growth diagnostics
    # ------------------------------------------------------------------
    high_abs_ratio = Rabs[high] / logw[high]
    high_upper_ratio = np.maximum(Rmax[high], 0.0) / logw[high]

    max_high_abs_ratio = float(np.max(high_abs_ratio))
    max_high_upper_ratio = float(np.max(high_upper_ratio))

    # Check whether worst |R|/log is in the low end or high end of sampled E.
    Ehigh = E[high]
    i_abs_ratio = int(np.argmax(high_abs_ratio))
    i_upper_ratio = int(np.argmax(high_upper_ratio))

    # Split high-energy region into logarithmic quartiles by index to see trend.
    idx_high = np.where(high)[0]
    chunks = np.array_split(idx_high, 4)
    chunk_stats = []
    for q, inds in enumerate(chunks, start=1):
        if len(inds) == 0:
            continue
        vals = Rabs[inds] / logw[inds]
        chunk_stats.append(dict(
            quartile=q,
            E_lo=float(E[inds[0]]),
            E_hi=float(E[inds[-1]]),
            max_absR_over_log=float(np.max(vals)),
            median_absR_over_log=float(np.median(vals)),
        ))

    # Selected envelope checks
    upper_holds = bool(np.min(C0u + C1 * logw[None, :] - R) >= -1e-12)
    abs_holds = bool(np.min(C0a + C1 * logw[None, :] - np.abs(R)) >= -1e-12)

    # Cutoff spread diagnostic: how much R changes across L at fixed E.
    max_cutoff_spread = float(np.max(Rspread))
    high_cutoff_spread = float(np.max(Rspread[high]))
    E_at_max_spread = float(E[int(np.argmax(Rspread))])

    np.savez_compressed(
        args.prefix + "_SAMPLES.npz",
        L=Ls,
        E=E,
        F=F,
        theta=theta,
        N_arch=Narch,
        R=R,
        C1=np.array([C1]),
        C0_upper=np.array([C0u]),
        C0_abs=np.array([C0a]),
    )

    verdict = (
        "LOG_GROWTH_ARITHMETIC_REMAINDER_STRONGLY_SUPPORTED_ON_AUDITED_DOMAIN"
        if upper_holds and abs_holds
        else "ARITHMETIC_REMAINDER_LOG_ENVELOPE_UNRESOLVED"
    )

    summary = dict(
        version=145,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        decomposition=(
            "F_L(E) = theta(E)/pi + 1 + R_L(E)"
        ),
        selected_log_envelope=dict(
            C1=C1,
            upper_C0=C0u,
            absolute_C0=C0a,
            upper_holds_sampled=upper_holds,
            absolute_holds_sampled=abs_holds,
        ),
        high_energy_diagnostics=dict(
            E_min=args.E_growth_min,
            max_positive_R_over_log=max_high_upper_ratio,
            E_at_max_positive_R_over_log=float(Ehigh[i_upper_ratio]),
            max_abs_R_over_log=max_high_abs_ratio,
            E_at_max_abs_R_over_log=float(Ehigh[i_abs_ratio]),
            quartiles=chunk_stats,
        ),
        cutoff_uniformity=dict(
            max_R_spread_across_L=max_cutoff_spread,
            max_highE_R_spread_across_L=high_cutoff_spread,
            E_at_max_spread=E_at_max_spread,
        ),
        verdict=verdict,
        theorem_target=(
            "Prove R_L(E) <= C0 + C1 log(E+e) uniformly for L>=L0. "
            "Combine with a Stirling upper bound for theta(E) to obtain the "
            "global counting inequality used by v144."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Candidate arithmetic log envelopes")
    print("-" * 128)
    print(
        f"{'C1':>8} {'C0 upper':>14} {'C0 abs':>14} "
        f"{'upper worst E':>15} {'abs worst E':>15} "
        f"{'highE C0 upper':>16} {'highE C0 abs':>14}"
    )
    for r in candidate_rows:
        print(
            f"{r['C1']:8.3f} "
            f"{r['C0_upper_required']:14.6e} "
            f"{r['C0_abs_required']:14.6e} "
            f"{r['upper_worst_E']:15.6f} "
            f"{r['abs_worst_E']:15.6f} "
            f"{r['C0_upper_required_highE']:16.6e} "
            f"{r['C0_abs_required_highE']:14.6e}"
        )

    print()
    print("Selected arithmetic remainder envelope")
    print("-" * 128)
    print(f"R_L(E) <= C0 + C1 log(E+e)")
    print(f"C1                                 : {C1:.9f}")
    print(f"safe upper C0                      : {C0u:.9e}")
    print(f"|R_L(E)| safe C0                   : {C0a:.9e}")
    print(f"sampled upper envelope holds       : {upper_holds}")
    print(f"sampled two-sided envelope holds   : {abs_holds}")
    print()
    print(f"max high-E positive R/log          : {max_high_upper_ratio:.9e} at E={Ehigh[i_upper_ratio]:.6f}")
    print(f"max high-E |R|/log                 : {max_high_abs_ratio:.9e} at E={Ehigh[i_abs_ratio]:.6f}")
    print(f"max cutoff spread in R             : {max_cutoff_spread:.9e} at E={E_at_max_spread:.6f}")
    print(f"max high-E cutoff spread in R      : {high_cutoff_spread:.9e}")

    print()
    print("High-energy |R|/log trend")
    print("-" * 128)
    for r in chunk_stats:
        print(
            f"Q{r['quartile']} E={r['E_lo']:.3f}..{r['E_hi']:.3f}  "
            f"max={r['max_absR_over_log']:.6e}  "
            f"median={r['median_absR_over_log']:.6e}"
        )

    print()
    print("=" * 128)
    print(f"VERDICT                              : {verdict}")
    print("=" * 128)
    print("NEXT ANALYTIC LEMMA:")
    print("  Bound the arithmetic finite-part correction R_L(E) uniformly in cutoff")
    print("  by C0 + C1 log(E+e).  The Archimedean theta term can then be handled")
    print("  separately with explicit Stirling inequalities.")


if __name__ == "__main__":
    main()
