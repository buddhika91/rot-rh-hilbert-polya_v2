#!/usr/bin/env python3
"""
ROT-RH v162 — MOVING-ROOT PHASE CAUCHY EXTENSION AUDIT

Purpose
-------
v158-v161 deliberately tested a STRONGER full-complex cutoff primitive.
v161 shows that this stronger Dirichlet route is not supported: many complex
shell phases are nearly aligned and some modal complex amplitudes grow.

But the Hilbert-Pólya operator does NOT require full-complex convergence.
It requires convergence of the secular roots defined by the REAL phase

    F_L(E_k(L)) = k - 1/2.

Therefore v162 returns to the exact theorem-relevant object and extends the
moving-root cutoff net beyond L=512000.

Starting from already-certified roots at L=512000, it builds the zero-blind
renormalized arithmetic phase at

    724077, 1024000, 1448155, 2048000, 2896310

and tracks only the first N roots by safeguarded Newton continuation.
No global scans are required.

For every adjacent pair L<M it measures:
  * old-root secular defect
        delta_k(L,M) = F_M(E_k(L)) - (k-1/2),
  * actual root shift E_k(M)-E_k(L),
  * finite-block trace distance
        sum_{k<=N}|E_k(M)^-2-E_k(L)^-2|,
  * local transversality along the connecting root segment,
  * implicit-function bound.

It also evaluates ALL cutoff pairs in the extended moving-root net and forms
the actual finite-block Cauchy envelopes

    C_N(L0)
      = max_{L0<=L<M}
          sum_{k<=N}|lambda_k(L)-lambda_k(M)|.

This is the exact numerical counterpart of Lemma 1.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_ROOTS.npz
<prefix>_NEIGHBORS.csv
<prefix>_ALL_PAIRS.csv
<prefix>_TAIL_ENVELOPES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import itertools
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
except Exception as exc:
    raise RuntimeError("scipy.optimize.brentq is required") from exc


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty phase output.")
    return float(a[0])


def vector_call(fn, xs):
    xs = np.asarray(xs, dtype=float)
    try:
        y = np.asarray(fn(xs), dtype=float)
        if y.shape == xs.shape:
            return y
        if y.size == xs.size:
            return y.reshape(xs.shape)
    except Exception:
        pass

    out = np.empty_like(xs)
    for i, x in enumerate(xs):
        out[i] = scalar_call(fn, float(x))
    return out


def build_phase(v102, base, L, tail_factor, counter_q):
    with warnings.catch_warnings(record=True) as wrn:
        warnings.simplefilter("always")
        ph = v102.RenormalizedPhase.build(
            base,
            int(L),
            float(tail_factor),
            int(counter_q),
        )
    return ph, [str(w.message) for w in wrn]


def refine_root(
    phase,
    target,
    x0,
    newton_iters,
    tol,
    max_step,
    bracket_initial,
    bracket_max,
):
    """
    Safeguarded local continuation.

    First Newton from the previous-cutoff root. If that fails, search a local
    symmetric bracket around x0 and use Brent.
    """
    x = float(x0)

    for _ in range(newton_iters):
        f = scalar_call(phase.F, x) - target
        if abs(f) <= tol:
            return x, abs(f), "newton"

        fp = scalar_call(phase.Fprime, x)
        if (not np.isfinite(fp)) or abs(fp) < 1e-12:
            break

        step = -f/fp
        step = float(np.clip(step, -max_step, max_step))
        xn = x + step

        if not np.isfinite(xn) or xn <= 0:
            break

        x = xn

    # local bracket fallback
    radius = bracket_initial

    def ffun(xx):
        return scalar_call(phase.F, xx) - target

    while radius <= bracket_max:
        a = max(1e-8, x0-radius)
        b = x0+radius
        fa = ffun(a)
        fb = ffun(b)

        if np.isfinite(fa) and np.isfinite(fb) and fa*fb <= 0:
            root = float(brentq(
                ffun, a, b,
                xtol=tol,
                rtol=1e-13,
                maxiter=200,
            ))
            return root, abs(ffun(root)), "brent"

        radius *= 1.6

    # Final failure: report best Newton point, caller will fail gate.
    fres = abs(ffun(x))
    return x, fres, "failed"


def segment_min_derivative(phase, x1, x2, samples):
    xs = np.linspace(float(x1), float(x2), samples)
    vals = np.abs(vector_call(phase.Fprime, xs))
    return float(np.min(vals))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchor-roots-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument("--anchor-L", type=int, default=512000)
    ap.add_argument(
        "--new-cutoffs",
        default="724077,1024000,1448155,2048000,2896310",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--root-tol", type=float, default=1e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument("--bracket-initial", type=float, default=0.05)
    ap.add_argument("--bracket-max", type=float, default=1.0)

    ap.add_argument("--segment-samples", type=int, default=17)
    ap.add_argument("--root-residual-gate", type=float, default=1e-8)
    ap.add_argument("--transversality-gate", type=float, default=0.05)
    ap.add_argument("--implicit-slack", type=float, default=1.02)

    ap.add_argument(
        "--latest-tail-ratio-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_moving_root_phase_cauchy_v162",
    )

    args = ap.parse_args()

    new_cutoffs = csv_ints(args.new_cutoffs)
    if any(L <= args.anchor_L for L in new_cutoffs):
        raise RuntimeError("All --new-cutoffs must exceed anchor-L.")
    if any(new_cutoffs[i+1] <= new_cutoffs[i]
           for i in range(len(new_cutoffs)-1)):
        raise RuntimeError("--new-cutoffs must be strictly increasing.")

    cutoffs = [args.anchor_L] + new_cutoffs

    z = np.load(args.anchor_roots_npz)
    Lold = np.asarray(z["L"], dtype=int)
    Rold = np.asarray(z["roots"], dtype=float)

    hit = np.where(Lold == args.anchor_L)[0]
    if not len(hit):
        raise RuntimeError(
            f"anchor L={args.anchor_L} missing from {args.anchor_roots_npz}"
        )

    anchor_roots = Rold[int(hit[0]), :args.modes].astype(float)
    n = len(anchor_roots)

    targets = np.arange(1, n+1, dtype=float) - 0.5

    print("=" * 150)
    print("ROT-RH v162 — MOVING-ROOT PHASE CAUCHY EXTENSION AUDIT")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"anchor cutoff                     : {args.anchor_L}")
    print(f"new cutoffs                       : {new_cutoffs}")
    print(f"modes                             : 1..{n}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 150)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warnings_map = {}

    def get_phase(L):
        if L not in phases:
            print(f"[L={L}] building RenormalizedPhase ...", flush=True)
            ph, wrn = build_phase(
                v102, base, L,
                args.tail_factor, args.counter_q
            )
            phases[L] = ph
            warnings_map[L] = wrn
            if wrn:
                print(f"[L={L}] {len(wrn)} warning(s)")
                for msg in wrn[:2]:
                    print(f"         warning: {msg}")
        return phases[L]

    roots_map = {args.anchor_L: anchor_roots.copy()}
    methods_map = {}
    residuals_map = {}

    # Build anchor phase too, for all-pairs old-root defect evaluation.
    get_phase(args.anchor_L)

    # ------------------------------------------------------------------
    # sequential moving-root continuation
    # ------------------------------------------------------------------
    for Lprev, L in zip(cutoffs[:-1], cutoffs[1:]):
        print()
        print(f"[track {Lprev}->{L}] continuing {n} roots ...", flush=True)

        ph = get_phase(L)
        prev_roots = roots_map[Lprev]
        new_roots = np.empty(n, dtype=float)
        methods = []
        residuals = np.empty(n, dtype=float)

        for j in range(n):
            root, res, method = refine_root(
                phase=ph,
                target=targets[j],
                x0=prev_roots[j],
                newton_iters=args.newton_iters,
                tol=args.root_tol,
                max_step=args.max_newton_step,
                bracket_initial=args.bracket_initial,
                bracket_max=args.bracket_max,
            )
            new_roots[j] = root
            residuals[j] = res
            methods.append(method)

        roots_map[L] = new_roots
        methods_map[L] = methods
        residuals_map[L] = residuals

        print(
            f"          max root residual={np.max(residuals):.3e}  "
            f"Newton={sum(m=='newton' for m in methods)}/{n}  "
            f"Brent={sum(m=='brent' for m in methods)}/{n}  "
            f"failed={sum(m=='failed' for m in methods)}"
        )

    # ------------------------------------------------------------------
    # neighboring-pair theorem diagnostics
    # ------------------------------------------------------------------
    neighbor_rows = []

    for L, M in zip(cutoffs[:-1], cutoffs[1:]):
        phM = get_phase(M)
        eL = roots_map[L]
        eM = roots_map[M]

        defect = vector_call(phM.F, eL) - targets
        shift = eM-eL

        lamL = eL**(-2)
        lamM = eM**(-2)
        trace = float(np.sum(np.abs(lamM-lamL)))

        mins = np.array([
            segment_min_derivative(
                phM, eL[j], eM[j], args.segment_samples
            )
            for j in range(n)
        ])

        implicit = np.abs(defect)/np.maximum(mins, 1e-300)

        transverse = bool(np.all(mins >= args.transversality_gate))
        bound_pass = bool(np.all(
            np.abs(shift) <= args.implicit_slack*implicit + 1e-12
        ))

        neighbor_rows.append(dict(
            L=L,
            M=M,
            ratio_M_over_L=float(M/L),
            sum_abs_defect=float(np.sum(np.abs(defect))),
            sum_abs_root_shift=float(np.sum(np.abs(shift))),
            trace_distance=trace,
            min_segment_abs_Fprime=float(np.min(mins)),
            max_root_residual_M=float(
                np.max(residuals_map.get(M, np.array([0.0])))
            ),
            transverse=transverse,
            implicit_bound_pass=bound_pass,
            sum_implicit_bound=float(np.sum(implicit)),
            max_abs_shift=float(np.max(np.abs(shift))),
        ))

    # ratios
    for i, r in enumerate(neighbor_rows):
        if i == 0:
            r["defect_ratio"] = np.nan
            r["shift_ratio"] = np.nan
            r["trace_ratio"] = np.nan
        else:
            p = neighbor_rows[i-1]
            r["defect_ratio"] = (
                r["sum_abs_defect"]/p["sum_abs_defect"]
            )
            r["shift_ratio"] = (
                r["sum_abs_root_shift"]/p["sum_abs_root_shift"]
            )
            r["trace_ratio"] = (
                r["trace_distance"]/p["trace_distance"]
            )

    # ------------------------------------------------------------------
    # all-pairs moving-root Cauchy quantities
    # ------------------------------------------------------------------
    all_pair_rows = []

    for L, M in itertools.combinations(cutoffs, 2):
        phM = get_phase(M)

        eL = roots_map[L]
        eM = roots_map[M]

        defect = vector_call(phM.F, eL) - targets
        shift = eM-eL

        lamL = eL**(-2)
        lamM = eM**(-2)

        trace = float(np.sum(np.abs(lamM-lamL)))

        all_pair_rows.append(dict(
            L=L,
            M=M,
            ratio_M_over_L=float(M/L),
            sum_abs_defect=float(np.sum(np.abs(defect))),
            sum_abs_root_shift=float(np.sum(np.abs(shift))),
            trace_distance=trace,
            max_abs_root_shift=float(np.max(np.abs(shift))),
        ))

    # ------------------------------------------------------------------
    # true finite-net tail Cauchy envelopes
    # ------------------------------------------------------------------
    tail_rows = []

    for idx, L0 in enumerate(cutoffs[:-1]):
        tcut = cutoffs[idx:]
        pairs_tail = [
            r for r in all_pair_rows
            if r["L"] >= L0 and r["M"] >= L0
        ]

        row = dict(
            L0=L0,
            points=len(tcut),
            pairs=len(pairs_tail),
            worst_defect_l1=max(
                r["sum_abs_defect"] for r in pairs_tail
            ),
            worst_root_shift_l1=max(
                r["sum_abs_root_shift"] for r in pairs_tail
            ),
            worst_trace_distance=max(
                r["trace_distance"] for r in pairs_tail
            ),
            worst_max_mode_shift=max(
                r["max_abs_root_shift"] for r in pairs_tail
            ),
        )

        if not tail_rows:
            row["defect_envelope_ratio"] = np.nan
            row["root_envelope_ratio"] = np.nan
            row["trace_envelope_ratio"] = np.nan
        else:
            p = tail_rows[-1]
            row["defect_envelope_ratio"] = (
                row["worst_defect_l1"]/p["worst_defect_l1"]
            )
            row["root_envelope_ratio"] = (
                row["worst_root_shift_l1"]/p["worst_root_shift_l1"]
            )
            row["trace_envelope_ratio"] = (
                row["worst_trace_distance"]/p["worst_trace_distance"]
            )

        tail_rows.append(row)

    # ------------------------------------------------------------------
    # save roots
    # ------------------------------------------------------------------
    root_matrix = np.vstack([roots_map[L] for L in cutoffs])

    np.savez_compressed(
        args.prefix + "_ROOTS.npz",
        L=np.asarray(cutoffs, dtype=int),
        roots=root_matrix,
        targets=targets,
    )

    pd.DataFrame(neighbor_rows).to_csv(
        args.prefix + "_NEIGHBORS.csv", index=False
    )
    pd.DataFrame(all_pair_rows).to_csv(
        args.prefix + "_ALL_PAIRS.csv", index=False
    )
    pd.DataFrame(tail_rows).to_csv(
        args.prefix + "_TAIL_ENVELOPES.csv", index=False
    )

    # Latest tail with >=3 points.
    candidates = [r for r in tail_rows if r["points"] >= 3]
    latest = candidates[-1]

    all_residual_ok = all(
        r["max_root_residual_M"] <= args.root_residual_gate
        for r in neighbor_rows
    )
    all_transverse = all(r["transverse"] for r in neighbor_rows)
    all_implicit = all(r["implicit_bound_pass"] for r in neighbor_rows)

    tail_contracts = (
        np.isfinite(latest["trace_envelope_ratio"])
        and latest["trace_envelope_ratio"]
        < args.latest_tail_ratio_gate
        and latest["root_envelope_ratio"]
        < args.latest_tail_ratio_gate
        and latest["defect_envelope_ratio"]
        < args.latest_tail_ratio_gate
    )

    if (
        all_residual_ok and all_transverse and
        all_implicit and tail_contracts
    ):
        verdict = "EXTENDED_MOVING_ROOT_FINITE_BLOCK_CAUCHY_STRONGLY_SUPPORTED"
    elif all_residual_ok and all_transverse and all_implicit:
        verdict = "ROOT_TRACKING_CERTIFIED_BUT_TAIL_CAUCHY_NOT_CONTRACTING"
    else:
        verdict = "MOVING_ROOT_FINITE_BLOCK_LEMMA_UNRESOLVED"

    summary = dict(
        version=162,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoff_net=cutoffs,
        modes=n,
        neighbor_results=neighbor_rows,
        latest_ge3_tail=latest,
        root_residual_pass=all_residual_ok,
        transversality_pass=all_transverse,
        implicit_bound_pass=all_implicit,
        tail_cauchy_contraction_pass=bool(tail_contracts),
        verdict=verdict,
        theorem_target=(
            "For each fixed N, prove directly along the moving secular-root "
            "branches that sup_{L,M>=L0} sum_{k<=N}|lambda_k(L)-lambda_k(M)| "
            "tends to zero. Full-complex cutoff convergence is not required."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o, np.generic)
            else (_ for _ in ()).throw(
                TypeError(f"Object of type {type(o).__name__} is not JSON serializable")
            ),
        ),
        encoding="utf-8"
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Neighboring moving-root diagnostics")
    print("-" * 150)
    print(
        f"{'pair':>21} {'sum|def|':>13} {'ratio':>9} "
        f"{'sum|dE|':>13} {'ratio':>9} "
        f"{'trace':>13} {'ratio':>9} "
        f"{'min|F_E|':>11} {'impl':>7}"
    )

    for r in neighbor_rows:
        print(
            f"{r['L']:>9d}->{r['M']:<9d} "
            f"{r['sum_abs_defect']:13.6e} "
            f"{r['defect_ratio']:9.6f} "
            f"{r['sum_abs_root_shift']:13.6e} "
            f"{r['shift_ratio']:9.6f} "
            f"{r['trace_distance']:13.6e} "
            f"{r['trace_ratio']:9.6f} "
            f"{r['min_segment_abs_Fprime']:11.6f} "
            f"{str(r['implicit_bound_pass']):>7}"
        )

    print()
    print("Extended all-pairs finite-block Cauchy envelopes")
    print("-" * 150)
    print(
        f"{'L0':>10} {'points':>7} {'pairs':>6} "
        f"{'C_defect':>13} {'ratio':>9} "
        f"{'C_root':>13} {'ratio':>9} "
        f"{'C_trace':>13} {'ratio':>9}"
    )

    for r in tail_rows:
        print(
            f"{r['L0']:10d} "
            f"{r['points']:7d} "
            f"{r['pairs']:6d} "
            f"{r['worst_defect_l1']:13.6e} "
            f"{r['defect_envelope_ratio']:9.6f} "
            f"{r['worst_root_shift_l1']:13.6e} "
            f"{r['root_envelope_ratio']:9.6f} "
            f"{r['worst_trace_distance']:13.6e} "
            f"{r['trace_envelope_ratio']:9.6f}"
        )

    print()
    print("=" * 150)
    print(f"root residual pass                 : {all_residual_ok}")
    print(f"transversality pass                : {all_transverse}")
    print(f"implicit bound pass                : {all_implicit}")
    print(f"latest >=3-point defect ratio      : {latest['defect_envelope_ratio']:.9f}")
    print(f"latest >=3-point root ratio        : {latest['root_envelope_ratio']:.9f}")
    print(f"latest >=3-point trace ratio       : {latest['trace_envelope_ratio']:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 150)
    print("LEMMA-1 TARGET:")
    print("  This is the exact operator statement we need numerically:")
    print()
    print("      sup_{L,M>=L0} sum_{k<=N}|E_k(L)^-2-E_k(M)^-2| -> 0.")
    print()
    print("  If the extended moving-root net keeps contracting while the")
    print("  full-complex frozen-energy primitive does not, the proof must")
    print("  exploit the phase/root geometry rather than full-complex convergence.")


if __name__ == "__main__":
    main()
