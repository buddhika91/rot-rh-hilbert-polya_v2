#!/usr/bin/env python3
"""
ROT-RH v150 — CUTOFF-DIFFERENCE KERNEL / WEIGHTED-PNT DISCREPANCY AUDIT

Purpose
-------
Attack the analytic finite-block cutoff-independence lemma directly from the
exponential regulator, without fitting another cutoff exponent.

For the zero-blind prime-power phase

    P_L(E)
      = sum_{n=p^a}
          (1/a) n^(-1/2) exp(-n/L) sin(E log n),

the PNT continuum counterterm is

    M_L(E)
      = Im ∫_2^∞ exp(-x/L) x^(-1/2+iE) / log(x) dx.

For L < M,

    ΔP_{L,M}(E) = P_M(E)-P_L(E),
    ΔM_{L,M}(E) = M_M(E)-M_L(E),

and the finite-part secular defect should satisfy

    F_M(E)-F_L(E)
      = [ΔM_{L,M}(E)-ΔP_{L,M}(E)] / π.             (1)

At an old root E_k(L), F_L(E_k(L)) = k-1/2, so

    δ_k(L,M)
      = F_M(E_k(L))-(k-1/2)
      = [ΔM-ΔP]/π.                                  (2)

The key analytic object is therefore the centered signed measure in u=log x:

  discrete atoms:
      dμ(u_n)
        = (1/a) n^(-1/2)
          [exp(-n/M)-exp(-n/L)] δ_{log n},

  continuum density:
      dν(u)
        = [exp(-e^u/M)-exp(-e^u/L)]
          e^(u/2)/u du.

Let

    D(u) = μ([log 2,u]) - ν([log 2,u]).

Integration by parts gives the uniform bound

    |∫ exp(i E u) d(μ-ν)|
      <= |D(U)| + |E| ∫_{log 2}^U |D(u)| du          (3)

on a truncated interval, plus an explicit exponential tail majorant.

Thus a rigorous route to fixed-block cutoff independence is:

    |δ_k(L,M)|
      <= [ |D(U)| + E_* ∫|D|du + tail ] / π,

where E_* bounds the finite spectral block.

v150 computes this quantity for the interlaced neighboring cutoff pairs and
checks:
  1. the direct finite-part identity (1) at every tracked old root;
  2. the weighted-PNT cumulative discrepancy D(u);
  3. the integration-by-parts uniform defect bound;
  4. whether the discrepancy norm and bound contract with increasing cutoff.

NO Xi / zeta / known-zero data are used.

This is a theorem-oriented numerical audit.  The final proof would replace
the computed weighted discrepancy by an analytic PNT remainder estimate.

Outputs
-------
<prefix>_PAIRS.csv
<prefix>_ROOTS.csv
<prefix>_DISCREPANCY.csv.gz
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.integrate import cumulative_trapezoid
    from scipy.special import erfc
except Exception as exc:
    raise RuntimeError("scipy is required for v150") from exc


# ----------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------

def parse_pairs(s):
    out = []
    for item in s.split(","):
        item = item.strip()
        if not item:
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    arr = np.asarray(y, dtype=float).reshape(-1)
    if not len(arr):
        raise RuntimeError("Empty phase output.")
    return float(arr[0])


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    """
    Return sorted n=p^a and factor 1/a, because
        Λ(p^a)/log(p^a) = 1/a.
    """
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    a_parts = [np.ones(len(primes), dtype=np.float64)]

    root = int(math.isqrt(nmax))
    small = primes[primes <= root]

    extra_n = []
    extra_a = []

    for p in small.tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_a.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        a_parts.append(np.asarray(extra_a, dtype=np.float64))

    n = np.concatenate(n_parts)
    afac = np.concatenate(a_parts)

    order = np.argsort(n, kind="mergesort")
    return n[order], afac[order]


def tail_integer_majorant(x0, M):
    """
    Bound sum_{n>x0} n^{-1/2} exp(-n/M)
    by first omitted term + integral.
    """
    n0 = int(math.floor(x0)) + 1
    first = math.exp(-n0 / M) / math.sqrt(n0)

    # ∫_x0^∞ x^-1/2 exp(-x/M) dx
    # = sqrt(pi M) erfc(sqrt(x0/M))
    integ = math.sqrt(math.pi * M) * float(erfc(math.sqrt(x0 / M)))
    return first + integ


def tail_continuum_majorant(x0, M):
    """
    ∫_x0^∞ exp(-x/M) x^-1/2/log x dx
      <= 1/log(x0) * ∫ x^-1/2 exp(-x/M) dx.
    """
    return (
        math.sqrt(math.pi * M)
        * float(erfc(math.sqrt(x0 / M)))
        / math.log(x0)
    )


def oscillatory_discrete(E, u_atoms, weights, chunk=65536):
    total = 0.0
    for i in range(0, len(u_atoms), chunk):
        uu = u_atoms[i:i+chunk]
        ww = weights[i:i+chunk]
        total += float(np.dot(ww, np.sin(E * uu)))
    return total


def oscillatory_continuum(E, u_grid, density):
    return float(np.trapezoid(density * np.sin(E * u_grid), u_grid))


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument(
        "--u-grid-points",
        type=int,
        default=131073,
        help="Uniform log-x grid used for cumulative discrepancy and continuum integrals.",
    )
    ap.add_argument(
        "--discrepancy-save-stride",
        type=int,
        default=128,
        help="Save every Nth discrepancy-grid point to CSV.gz.",
    )
    ap.add_argument(
        "--identity-rms-gate",
        type=float,
        default=5e-4,
        help="Gate for direct finite-part identity RMS at tracked roots.",
    )
    ap.add_argument(
        "--contraction-gate",
        type=float,
        default=0.98,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_cutoff_difference_kernel_v150",
    )

    args = ap.parse_args()

    pairs = parse_pairs(args.pairs)

    z = np.load(args.cutoff_net_npz)
    Ls = np.asarray(z["L"], dtype=int)
    Rall = np.asarray(z["roots"], dtype=float)

    order = np.argsort(Ls)
    Ls = Ls[order]
    Rall = Rall[order]

    n_modes = min(args.modes, Rall.shape[1])

    root_map = {
        int(L): np.asarray(Rall[i, :n_modes], dtype=float)
        for i, L in enumerate(Ls)
    }

    needed = sorted(set([x for p in pairs for x in p]))
    for L in needed:
        if L not in root_map:
            raise RuntimeError(f"Cutoff {L} not present in root net.")

    max_M = max(M for _, M in pairs)
    xmax = int(math.ceil(args.tail_factor * max_M))

    print("=" * 136)
    print("ROT-RH v150 — CUTOFF-DIFFERENCE KERNEL / WEIGHTED-PNT DISCREPANCY AUDIT")
    print("=" * 136)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"modes                             : 1..{n_modes}")
    print(f"prime-power xmax                  : {xmax}")
    print(f"log-grid points                   : {args.u_grid_points}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 136)

    # ------------------------------------------------------------------
    # Exact prime-power atoms through xmax
    # ------------------------------------------------------------------
    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_u = np.log(atom_n.astype(np.float64))
    atom_base = atom_afac / np.sqrt(atom_n.astype(np.float64))

    print(
        f"[arithmetic] atoms={len(atom_n):,}; "
        f"primes/powers through {xmax:,}"
    )

    u0 = math.log(2.0)
    U = math.log(float(xmax))
    u_grid = np.linspace(u0, U, args.u_grid_points, dtype=float)
    x_grid = np.exp(u_grid)

    # Map atoms once to cumulative-grid indices.
    # histogram bins centered on grid intervals; for cumulative mass at grid[j],
    # searchsorted is exact enough and vectorized below with cumulative atom sums.
    # ------------------------------------------------------------------

    # Build only the larger-endpoint phases; old roots already satisfy old target.
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warnings_by_L = {}

    for M in sorted(set(M for _, M in pairs)):
        print(f"[L={M}] building RenormalizedPhase ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phases[M] = v102.RenormalizedPhase.build(
                base,
                int(M),
                float(args.tail_factor),
                int(args.counter_q),
            )
        warnings_by_L[M] = [str(w.message) for w in wrn]
        if warnings_by_L[M]:
            print(f"[L={M}] built with {len(warnings_by_L[M])} warning(s)")
            for msg in warnings_by_L[M][:2]:
                print(f"           warning: {msg}")

    pair_rows = []
    root_rows = []
    discrepancy_rows = []

    prev = None

    for pair_index, (L, M) in enumerate(pairs):
        print()
        print(f"[pair {L}->{M}] computing weighted discrepancy ...", flush=True)

        # Positive regulator difference for M>L.
        reg_atom = np.exp(-atom_n / float(M)) - np.exp(-atom_n / float(L))
        weights = atom_base * reg_atom

        # Continuum density in u:
        # dx = e^u du, x^-1/2 / log x -> e^(u/2)/u.
        reg_cont = np.exp(-x_grid / float(M)) - np.exp(-x_grid / float(L))
        density = reg_cont * np.exp(0.5 * u_grid) / u_grid

        # Exact cumulative discrete mass at every grid node.
        csum = np.cumsum(weights)
        idx = np.searchsorted(atom_u, u_grid, side="right") - 1
        disc_cum = np.zeros_like(u_grid)
        good = idx >= 0
        disc_cum[good] = csum[idx[good]]

        cont_cum = np.concatenate([
            np.array([0.0]),
            cumulative_trapezoid(density, u_grid)
        ])

        D = disc_cum - cont_cum

        D_end = float(D[-1])
        D_L1 = float(np.trapezoid(np.abs(D), u_grid))
        D_L2 = float(math.sqrt(np.trapezoid(D * D, u_grid)))
        D_sup = float(np.max(np.abs(D)))
        i_sup = int(np.argmax(np.abs(D)))
        E_at_Dsup_x = float(math.exp(u_grid[i_sup]))

        # Explicit truncation tail majorant.
        disc_tail = tail_integer_majorant(xmax, M)
        cont_tail = tail_continuum_majorant(xmax, M)
        centered_tail = disc_tail + cont_tail

        E_block_max = float(max(np.max(root_map[L]), np.max(root_map[M])))

        ibp_complex_bound = (
            abs(D_end)
            + E_block_max * D_L1
            + centered_tail
        )
        phase_uniform_bound = ibp_complex_bound / math.pi

        # Evaluate exact centered oscillatory difference at tracked old roots.
        defects = []
        predicted = []
        identities = []
        centered_abs = []

        for j, E in enumerate(root_map[L]):
            k = j + 1
            target = k - 0.5

            # Direct secular defect from the actual new phase.
            actual_defect = scalar_call(phases[M].F, E) - target

            dP = oscillatory_discrete(E, atom_u, weights)
            dM = oscillatory_continuum(E, u_grid, density)

            predicted_defect = (dM - dP) / math.pi
            identity_residual = actual_defect - predicted_defect

            centered = dP - dM

            defects.append(abs(actual_defect))
            predicted.append(abs(predicted_defect))
            identities.append(identity_residual)
            centered_abs.append(abs(centered))

            root_rows.append(dict(
                L=L,
                M=M,
                k=k,
                E_old=float(E),
                actual_secular_defect=float(actual_defect),
                deltaP_im=float(dP),
                deltaM_im=float(dM),
                centered_im=float(centered),
                predicted_secular_defect=float(predicted_defect),
                identity_residual=float(identity_residual),
                abs_identity_residual=float(abs(identity_residual)),
                uniform_phase_bound=float(phase_uniform_bound),
                actual_over_uniform_bound=(
                    float(abs(actual_defect) / phase_uniform_bound)
                    if phase_uniform_bound > 0 else np.nan
                ),
            ))

        identities = np.asarray(identities, dtype=float)
        identity_rms = float(math.sqrt(np.mean(identities**2)))
        identity_max = float(np.max(np.abs(identities)))

        sum_def = float(np.sum(defects))
        sum_pred = float(np.sum(predicted))

        # Save a thin discrepancy profile.
        stride = max(1, int(args.discrepancy_save_stride))
        take = np.arange(0, len(u_grid), stride, dtype=int)
        if take[-1] != len(u_grid) - 1:
            take = np.concatenate([take, [len(u_grid)-1]])

        for ii in take:
            discrepancy_rows.append(dict(
                L=L,
                M=M,
                u=float(u_grid[ii]),
                x=float(x_grid[ii]),
                discrete_cumulative=float(disc_cum[ii]),
                continuum_cumulative=float(cont_cum[ii]),
                discrepancy_D=float(D[ii]),
                abs_D=float(abs(D[ii])),
            ))

        row = dict(
            L=L,
            M=M,
            ratio_L=float(M / L),
            atoms=len(atom_n),
            xmax=xmax,
            E_block_max=E_block_max,

            discrete_total_mass=float(disc_cum[-1]),
            continuum_total_mass=float(cont_cum[-1]),
            D_end=D_end,
            D_sup=D_sup,
            x_at_D_sup=E_at_Dsup_x,
            D_L1=D_L1,
            D_L2=D_L2,

            discrete_tail_majorant=disc_tail,
            continuum_tail_majorant=cont_tail,
            centered_tail_majorant=centered_tail,

            ibp_complex_bound=ibp_complex_bound,
            uniform_phase_defect_bound=phase_uniform_bound,

            sum_actual_root_defect=sum_def,
            sum_predicted_root_defect=sum_pred,
            identity_rms=identity_rms,
            identity_max=identity_max,
        )

        if prev is None:
            for key in [
                "D_L1", "D_sup", "uniform_phase_defect_bound",
                "sum_actual_root_defect"
            ]:
                row[key + "_ratio"] = np.nan
        else:
            for key in [
                "D_L1", "D_sup", "uniform_phase_defect_bound",
                "sum_actual_root_defect"
            ]:
                den = prev[key]
                row[key + "_ratio"] = (
                    row[key] / den if den > 0 else np.nan
                )

        pair_rows.append(row)
        prev = row

        print(
            f"[pair {L}->{M}] "
            f"||D||_1={D_L1:.6e}, "
            f"||D||_inf={D_sup:.6e}, "
            f"phase-bound={phase_uniform_bound:.6e}, "
            f"sum|defect|={sum_def:.6e}, "
            f"identity-rms={identity_rms:.3e}"
        )

    pd.DataFrame(pair_rows).to_csv(
        args.prefix + "_PAIRS.csv", index=False
    )
    pd.DataFrame(root_rows).to_csv(
        args.prefix + "_ROOTS.csv", index=False
    )
    pd.DataFrame(discrepancy_rows).to_csv(
        args.prefix + "_DISCREPANCY.csv.gz",
        index=False,
        compression="gzip",
    )

    # ------------------------------------------------------------------
    # verdict
    # ------------------------------------------------------------------
    identity_ok = all(
        r["identity_rms"] <= args.identity_rms_gate
        for r in pair_rows
    )

    late = pair_rows[-2:] if len(pair_rows) >= 2 else pair_rows

    discrepancy_contracts = (
        len(late) >= 2
        and late[-1]["D_L1"] < args.contraction_gate * late[-2]["D_L1"]
    )
    defect_contracts = (
        len(late) >= 2
        and late[-1]["sum_actual_root_defect"]
        < args.contraction_gate * late[-2]["sum_actual_root_defect"]
    )
    bound_contracts = (
        len(late) >= 2
        and late[-1]["uniform_phase_defect_bound"]
        < args.contraction_gate * late[-2]["uniform_phase_defect_bound"]
    )

    if identity_ok and discrepancy_contracts and defect_contracts and bound_contracts:
        verdict = "WEIGHTED_PNT_DISCREPANCY_MECHANISM_STRONGLY_SUPPORTED"
    elif identity_ok and discrepancy_contracts and defect_contracts:
        verdict = "CUTOFF_DIFFERENCE_IDENTITY_SUPPORTED_BOUND_TOO_LOOSE_OR_MIXED"
    elif identity_ok:
        verdict = "FINITE_PART_DIFFERENCE_IDENTITY_SUPPORTED_DISCREPANCY_DECAY_UNRESOLVED"
    else:
        verdict = "CUTOFF_DIFFERENCE_DECOMPOSITION_UNRESOLVED"

    summary = dict(
        version=150,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        pairs=pairs,
        modes=n_modes,
        prime_power_xmax=xmax,
        weighted_measure_identity=(
            "delta_k(L,M) = [Delta M_im(E_k(L)) - "
            "Delta P_im(E_k(L))]/pi"
        ),
        integration_by_parts_bound=(
            "|Delta P-Delta M| <= |D(U)| + |E| int|D(u)|du + tail"
        ),
        pair_results=pair_rows,
        identity_gate=args.identity_rms_gate,
        identity_pass=identity_ok,
        verdict=verdict,
        analytic_target=(
            "Prove that the weighted PNT discrepancy norm "
            "|D(U)| + E_N int|D(u)|du + tail tends to zero uniformly "
            "for arbitrary L,M -> infinity. This directly yields the "
            "finite-block secular-defect Cauchy lemma without fitting a "
            "power law."
        ),
        proof_gap=(
            "The cumulative discrepancy and continuum integrals are evaluated "
            "numerically here. A proof must bound them analytically using an "
            "explicit PNT/Chebyshev remainder estimate under the exponential "
            "cutoff-difference weight."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("Cutoff-difference kernel summaries")
    print("-" * 136)
    print(
        f"{'pair':>18} {'||D||_1':>13} {'||D||inf':>13} "
        f"{'phase bound':>13} {'sum|def|':>13} {'id RMS':>11} "
        f"{'D1 ratio':>10} {'def ratio':>10}"
    )

    for r in pair_rows:
        pair = f"{r['L']}->{r['M']}"
        print(
            f"{pair:>18} "
            f"{r['D_L1']:13.6e} "
            f"{r['D_sup']:13.6e} "
            f"{r['uniform_phase_defect_bound']:13.6e} "
            f"{r['sum_actual_root_defect']:13.6e} "
            f"{r['identity_rms']:11.3e} "
            f"{r['D_L1_ratio']:10.6f} "
            f"{r['sum_actual_root_defect_ratio']:10.6f}"
        )

    print()
    print("=" * 136)
    print(f"finite-part identity pass          : {identity_ok}")
    if len(pair_rows) >= 2:
        print(f"latest discrepancy L1 ratio        : {pair_rows[-1]['D_L1_ratio']:.9f}")
        print(f"latest uniform-bound ratio         : {pair_rows[-1]['uniform_phase_defect_bound_ratio']:.9f}")
        print(f"latest summed-defect ratio         : {pair_rows[-1]['sum_actual_root_defect_ratio']:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 136)
    print("ANALYTIC TARGET:")
    print("  Bound the cumulative weighted prime-power minus continuum discrepancy D(u)")
    print("  under exp(-x/M)-exp(-x/L).  Integration by parts then gives the finite-block")
    print("  cutoff-independent secular-defect bound directly, with no empirical alpha.")


if __name__ == "__main__":
    main()
