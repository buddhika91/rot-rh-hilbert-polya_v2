#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v108 — Staircase Topology / Exact Resolvent Discrepancy Audit
====================================================================

v107 showed that Euler–Maclaurin via a global inverse G_L=F_L^{-1} is invalid:
the selected first-later-crossing spectrum does not necessarily lie on one
globally monotone branch.

v108 removes that assumption completely.

Define the exact selected-root staircase

    N_L(E) = #{k : E_{k,L} <= E}

and g_a(E)=1/(E^2+a^2).

For a finite prefix ending at E_N, integration by parts gives the exact identity

    sum_{k<=N} g_a(E_k) - int_0^E_N g_a(E) F'_L(E)dE

      = 1/2 g_a(E_N)
        + g_a(0) F_L(0)
        + int_0^E_N [F_L(E)-N_L(E)] g'_a(E)dE,

because F_L(E_N)=N-1/2.

This identity needs NO inverse F_L^{-1} and NO monotonicity.

The script simultaneously audits:
  * whether F'_L changes sign between selected roots;
  * negative variation and total variation cell by cell;
  * the staircase discrepancy Q_L(E)=F_L(E)-N_L(E);
  * the exact finite-prefix resolvent discrepancy identity;
  * how the full arithmetic rational contribution splits into
        finite-prefix staircase discrepancy + high-energy tail discrepancy.

No Xi, zeta evaluations, or known zeros are used.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad
from scipy.special import digamma

VERSION = "v108"
BUILD = "2026-08-17-staircase-topology-exact-resolvent-discrepancy-v108"
EPS = 1e-15


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def partial_moments(roots, order):
    r = np.asarray(roots, float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def operator_resolvent_prefix_tail(roots, completed_moments, a, order):
    r = np.asarray(roots, float)
    cm = np.asarray(completed_moments, float)
    M = min(int(order), len(cm))
    pm = partial_moments(r, M)
    tail = cm[:M] - pm

    a = float(a)
    prefix = float(np.sum(1.0 / (r * r + a * a)))
    tail_val = 0.0
    p = 1.0
    for q in range(M):
        tail_val += p * float(tail[q])
        p *= -(a * a)

    EN = float(r[-1])
    ratio = (a / EN) ** 2
    rem = abs(float(tail[0])) * ratio ** M / (1.0 - ratio)
    return prefix + tail_val, prefix, tail_val, rem


def full_continuum_transform(phase, a):
    a = float(a)
    sigma = 0.5 + a

    arch = (float(digamma(sigma / 2.0)) - math.log(math.pi)) / (4.0 * a)

    prime_coeff = phase.phase_w * phase.logs
    prime_dirichlet = float(np.sum(prime_coeff * np.exp(-a * phase.logs)))
    prime = -prime_dirichlet / (2.0 * a)

    L = float(phase.L)
    smooth_smoothed = quad(
        lambda x: x ** (-sigma) * math.exp(-x / L),
        2.0,
        np.inf,
        epsabs=1e-14,
        epsrel=1e-12,
        limit=300,
    )[0]
    counter = smooth_smoothed / (2.0 * a)

    smooth_unsmoothed = 2.0 ** (1.0 - sigma) / (sigma - 1.0)
    ac = -smooth_unsmoothed / (2.0 * a)

    return arch + prime + counter + ac


def interval_nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def audit_interval(phase, lo, hi, staircase_n, a_values, q):
    E, W = interval_nodes(lo, hi, q)
    F = np.asarray(phase.F(E), float)
    Fp = np.asarray(phase.Fprime(E), float)

    out = {
        "min_Fprime": float(np.min(Fp)),
        "max_Fprime": float(np.max(Fp)),
        "negative_variation": float(np.sum(W * np.maximum(-Fp, 0.0))),
        "positive_variation": float(np.sum(W * np.maximum(Fp, 0.0))),
        "total_variation": float(np.sum(W * np.abs(Fp))),
        "net_F_change": float(np.sum(W * Fp)),
        "negative_weight_fraction":
            float(np.sum(W[Fp < 0]) / np.sum(W)) if np.any(Fp < 0) else 0.0,
        "Q_max_abs": float(np.max(np.abs(F - float(staircase_n)))),
        "Q_min": float(np.min(F - float(staircase_n))),
        "Q_max": float(np.max(F - float(staircase_n))),
    }

    # Count signs on the quadrature nodes as a topology diagnostic.
    sg = np.sign(Fp)
    sg[np.abs(Fp) < 1e-12] = 0
    nz = sg[sg != 0]
    out["Fprime_sign_changes"] = int(
        np.sum(nz[1:] * nz[:-1] < 0)
    ) if len(nz) >= 2 else 0

    for a in a_values:
        aa = float(a)
        g = 1.0 / (E * E + aa * aa)
        gp = -2.0 * E / (E * E + aa * aa) ** 2
        out[f"J_a{a:g}"] = float(np.sum(W * g * Fp))
        out[f"Qgp_a{a:g}"] = float(
            np.sum(W * (F - float(staircase_n)) * gp)
        )

    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--a-probes", default="2,3,4,5")
    ap.add_argument("--moment-order", type=int, default=10)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=384)
    ap.add_argument("--cell-q", type=int, default=48)
    ap.add_argument("--cell-qcheck", type=int, default=96)
    ap.add_argument(
        "--prefix",
        default="rot_rh_staircase_topology_resolvent_v108",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    aprobes = parse_floats(args.a_probes)

    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")
    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    if got != man.get("sha256"):
        raise RuntimeError("v102.1 SHA mismatch.")

    data = np.load(archive, allow_pickle=False)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("=" * 154)
    print("ROT-RH v108 — STAIRCASE TOPOLOGY / EXACT RESOLVENT DISCREPANCY AUDIT")
    print("=" * 154)
    print("v102.1 SHA verified             :", True)
    print("L ladder                        :", Ls)
    print("depth                           :", args.depth)
    print("a probes                        :", aprobes)
    print("cell quadrature                 :", args.cell_q)
    print("independent cell-q check        :", args.cell_qcheck)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 154)

    cell_rows = []
    summary_rows = []
    resolvent_rows = []

    for L in Ls:
        print(f"[L={L}] build phase / audit topology", flush=True)
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        roots = np.asarray(data[f"roots_L{L}_d{args.depth}"], float)
        moments = np.asarray(
            data[f"mom_{args.method}_L{L}_d{args.depth}"], float
        )
        N = len(roots)
        EN = float(roots[-1])

        # F(0) is part of the exact staircase identity.
        F0 = float(phase.F(np.asarray([0.0]))[0])

        # Low interval [0,E1): staircase N(E)=0.
        intervals = [(0.0, float(roots[0]), 0, "low")]
        for j in range(N - 1):
            intervals.append(
                (float(roots[j]), float(roots[j + 1]), j + 1, "cell")
            )

        sums_q = {a: {"J": 0.0, "Qgp": 0.0} for a in aprobes}
        sums_qc = {a: {"J": 0.0, "Qgp": 0.0} for a in aprobes}
        total_neg = 0.0
        total_tv = 0.0
        max_qabs = 0.0
        min_fp = math.inf
        nonmono = 0
        sign_changes = 0

        for idx, (lo, hi, nst, kind) in enumerate(intervals):
            r = audit_interval(
                phase, lo, hi, nst, aprobes, args.cell_q
            )
            rc = audit_interval(
                phase, lo, hi, nst, aprobes, args.cell_qcheck
            )

            row = {
                "L": L,
                "interval_index": idx,
                "kind": kind,
                "lo": lo,
                "hi": hi,
                "staircase_N": nst,
                **r,
                "qcheck_min_Fprime": rc["min_Fprime"],
                "qcheck_negative_variation": rc["negative_variation"],
                "qcheck_Q_max_abs": rc["Q_max_abs"],
            }
            for a in aprobes:
                row[f"J_qcheck_a{a:g}"] = rc[f"J_a{a:g}"]
                row[f"Qgp_qcheck_a{a:g}"] = rc[f"Qgp_a{a:g}"]
                sums_q[a]["J"] += r[f"J_a{a:g}"]
                sums_q[a]["Qgp"] += r[f"Qgp_a{a:g}"]
                sums_qc[a]["J"] += rc[f"J_a{a:g}"]
                sums_qc[a]["Qgp"] += rc[f"Qgp_a{a:g}"]

            cell_rows.append(row)

            if kind == "cell":
                total_neg += rc["negative_variation"]
                total_tv += rc["total_variation"]
                max_qabs = max(max_qabs, rc["Q_max_abs"])
                min_fp = min(min_fp, rc["min_Fprime"])
                if rc["min_Fprime"] < 0:
                    nonmono += 1
                sign_changes += rc["Fprime_sign_changes"]

        summary_rows.append(
            {
                "L": L,
                "selected_cells": N - 1,
                "nonmonotone_cells": nonmono,
                "nonmonotone_fraction": nonmono / max(N - 1, 1),
                "selected_min_Fprime": min_fp,
                "selected_negative_variation": total_neg,
                "selected_total_variation": total_tv,
                "selected_excess_variation":
                    total_tv - float(N - 1),
                "selected_Fprime_sign_changes": sign_changes,
                "selected_max_abs_Q": max_qabs,
                "F0": F0,
            }
        )

        s = summary_rows[-1]
        print(
            f"  cells nonmonotone={s['nonmonotone_cells']}/{s['selected_cells']} "
            f"minF'={s['selected_min_Fprime']:+.3e} "
            f"negVar={s['selected_negative_variation']:.3e} "
            f"excessTV={s['selected_excess_variation']:.3e} "
            f"max|F-N|={s['selected_max_abs_Q']:.3e}"
        )

        # Exact prefix discrepancy identity and full-resolvent split.
        for a in aprobes:
            aa = float(a)
            Rfull, Rprefix, Rtail, Rrem = operator_resolvent_prefix_tail(
                roots, moments, aa, args.moment_order
            )
            Jprefix = sums_qc[a]["J"]
            Qgp = sums_qc[a]["Qgp"]

            gEN = 1.0 / (EN * EN + aa * aa)
            g0 = 1.0 / (aa * aa)

            lhs = Rprefix - Jprefix
            rhs = 0.5 * gEN + g0 * F0 + Qgp
            identity_resid = lhs - rhs

            Jfull = full_continuum_transform(phase, aa)
            Jtail = Jfull - Jprefix

            prefix_disc = lhs
            tail_disc = Rtail - Jtail
            boundary_full = Rfull - Jfull
            rational = 1.0 / (aa * aa - 0.25)

            resolvent_rows.append(
                {
                    "L": L,
                    "a": aa,
                    "F0": F0,
                    "Rfull": Rfull,
                    "Rprefix": Rprefix,
                    "Rtail": Rtail,
                    "Rtail_series_bound": Rrem,
                    "Jfull": Jfull,
                    "Jprefix": Jprefix,
                    "Jtail": Jtail,
                    "prefix_discrepancy": prefix_disc,
                    "staircase_rhs": rhs,
                    "staircase_identity_residual": identity_resid,
                    "staircase_Qgp": Qgp,
                    "endpoint_half_gEN": 0.5 * gEN,
                    "origin_g0F0": g0 * F0,
                    "tail_discrepancy": tail_disc,
                    "full_boundary": boundary_full,
                    "rational_target": rational,
                    "full_boundary_minus_rational":
                        boundary_full - rational,
                    "prefix_plus_tail_minus_full":
                        prefix_disc + tail_disc - boundary_full,
                }
            )

        rr = [r for r in resolvent_rows if r["L"] == L]
        print(
            f"  exact staircase max residual="
            f"{max(abs(r['staircase_identity_residual']) for r in rr):.3e}; "
            f"max |full boundary-rational|="
            f"{max(abs(r['full_boundary_minus_rational']) for r in rr):.3e}"
        )

    print("[final L] discrepancy decomposition", flush=True)
    finalL = Ls[-1]
    final = [r for r in resolvent_rows if r["L"] == finalL]
    for r in final:
        print(
            f"  a={r['a']:g}: "
            f"prefixDisc={r['prefix_discrepancy']:+.6e} "
            f"[g0F0={r['origin_g0F0']:+.6e}, "
            f"Qgp={r['staircase_Qgp']:+.6e}, "
            f"halfEN={r['endpoint_half_gEN']:+.2e}] "
            f"tailDisc={r['tail_discrepancy']:+.6e} "
            f"full={r['full_boundary']:+.6e} "
            f"rat={r['rational_target']:+.6e}"
        )

    final_summary = [r for r in summary_rows if r["L"] == finalL][0]
    max_identity = max(
        abs(r["staircase_identity_residual"]) for r in final
    )
    max_split = max(
        abs(r["prefix_plus_tail_minus_full"]) for r in final
    )
    max_brat = max(
        abs(r["full_boundary_minus_rational"]) for r in final
    )

    gates = {
        "staircase_identity_numeric_residual_below_1e8": max_identity < 1e-8,
        "prefix_tail_split_residual_below_1e8": max_split < 1e-8,
        "global_inverse_is_invalid":
            final_summary["nonmonotone_cells"] > 0,
        "full_boundary_tracks_rational_to_1e5": max_brat < 1e-5,
    }

    if (
        gates["staircase_identity_numeric_residual_below_1e8"]
        and gates["prefix_tail_split_residual_below_1e8"]
        and gates["global_inverse_is_invalid"]
    ):
        verdict = (
            "PASS_V108_STAIRCASE_FORMULATION_REPLACES_INVALID_GLOBAL_INVERSE__"
            "NEXT_PROVE_WEIGHTED_STAIRCASE_DISCREPANCY_LIMIT"
        )
    else:
        verdict = "PARTIAL_V108_STAIRCASE_AUDIT_NEEDS_REFINEMENT"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_SUMMARY.csv"), summary_rows)
    write_csv(Path(str(prefix) + "_RESOLVENT.csv"), resolvent_rows)
    Path(str(prefix) + "_VERDICT.json").write_text(
        json.dumps(
            {
                "version": VERSION,
                "build": BUILD,
                "verdict": verdict,
                "RH_proof": False,
                "Xi_used": False,
                "zeta_used": False,
                "known_zeros_used": False,
                "source_v102_sha256": got,
                "gates": gates,
                "final_summary": final_summary,
                "final_max_staircase_identity_residual": max_identity,
                "final_max_boundary_minus_rational": max_brat,
                "theorem_target": (
                    "Replace invalid global-inverse Euler–Maclaurin by the "
                    "exact staircase identity. Prove convergence of the "
                    "weighted discrepancy integral "
                    "int(F_L-N_L) g'_a plus endpoint/tail terms to the "
                    "elementary rational arithmetic contribution."
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\n" + "=" * 154)
    print("FINAL v108 VERDICT")
    print("=" * 154)
    print("verdict                         :", verdict)
    print("nonmonotone selected cells      :", final_summary["nonmonotone_cells"])
    print("selected min Fprime             :", f"{final_summary['selected_min_Fprime']:.12e}")
    print("selected negative variation     :", f"{final_summary['selected_negative_variation']:.12e}")
    print("selected max |F-N|              :", f"{final_summary['selected_max_abs_Q']:.12e}")
    print("max staircase identity residual :", f"{max_identity:.12e}")
    print("max |full boundary-rational|    :", f"{max_brat:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("=" * 154)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
