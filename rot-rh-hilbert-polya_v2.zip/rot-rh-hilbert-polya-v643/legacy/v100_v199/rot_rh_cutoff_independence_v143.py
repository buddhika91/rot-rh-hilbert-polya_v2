#!/usr/bin/env python3
"""
ROT-RH v143 — MULTISCALE CUTOFF-INDEPENDENCE / CAUCHY-NET AUDIT

Purpose
-------
Move beyond dyadic subsequence convergence and test genuine cutoff
independence numerically.

A limit K_L -> K should not depend on following only the dyadic sequence
L,2L,4L,... .  For a genuine Cauchy net, all sufficiently large cutoffs
must become mutually close.

This script therefore constructs a geometric interlaced cutoff mesh

    128k, sqrt(2)*128k, 256k, sqrt(2)*256k, 512k

by combining existing endpoints with two NEW non-dyadic low-mode solves.
It then measures, for lambda_k(L)=E_k(L)^(-2),

    d_N(L,M) = sum_{k<=N} |lambda_k(L)-lambda_k(M)|,

and the tail-set diameter

    C_N(L0) = max_{L,M >= L0} d_N(L,M).

If C_N(L0) shrinks as L0 increases, convergence is not merely a feature
of one chosen dyadic subsequence.

The script also evaluates the old-root secular defect under the new phase
at each inserted cutoff, giving a local implicit-function consistency check.

NO Xi / zeta / known-zero data are used.

Important mathematical limitation
---------------------------------
This is a numerical finite-mode Cauchy-net audit.  It cannot by itself prove
the infinite-dimensional statement.  Full trace-norm cutoff independence
still requires:
  (i) fixed-mode convergence for all k,
  (ii) a proven uniform summable high-k majorant.

Outputs
-------
<prefix>_ROOTS.csv
<prefix>_PAIRWISE.csv
<prefix>_TAIL_DIAMETERS.csv
<prefix>_INSERTED_LOCAL.csv
<prefix>_ROOTS.npz
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from scipy.optimize import brentq
except Exception:
    brentq = None


def write_csv(path, rows):
    path = Path(path)
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty upstream phase output.")
    return float(a[0])


def refine_root(phase, x0, target, left, right, max_iter, tol, max_step):
    def g(x):
        return scalar_call(phase.F, x) - target

    def gp(x):
        return scalar_call(phase.Fprime, x)

    x = float(x0)
    left = float(left)
    right = float(right)

    for _ in range(max_iter):
        fx = g(x)
        if abs(fx) <= tol:
            return x, abs(fx), "newton"

        d = gp(x)
        if not np.isfinite(d) or abs(d) < 1e-14:
            break

        step = float(np.clip(fx / d, -max_step, max_step))
        xn = x - step

        if not np.isfinite(xn) or not (left < xn < right):
            xn = 0.5 * (left + right)

        if abs(xn - x) <= 1e-15 * max(1.0, abs(x)):
            x = xn
            break
        x = xn

    fx = g(x)
    if abs(fx) <= max(10 * tol, 1e-11):
        return x, abs(fx), "newton_loose"

    if brentq is not None:
        gl, gr = g(left), g(right)
        if np.isfinite(gl) and np.isfinite(gr) and gl * gr <= 0:
            xr = brentq(g, left, right, xtol=tol, rtol=1e-13, maxiter=100)
            return float(xr), abs(g(xr)), "brentq"

    return x, abs(fx), "failed"


def load_endpoint(path):
    z = np.load(path)
    L = int(np.asarray(z["L_new"]).reshape(-1)[0])
    r = np.asarray(z["roots_new"], float)
    return L, r


def log_interp_roots(L, La, Lb, ra, rb):
    """Interpolate roots linearly in log L between two known endpoints."""
    t = (math.log(L) - math.log(La)) / (math.log(Lb) - math.log(La))
    return (1.0 - t) * ra + t * rb


def pair_distance(lam_a, lam_b):
    return float(np.sum(np.abs(lam_b - lam_a)))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--endpoint-256",
        default="rot_rh_low_mode_endpoint_v137_ENDPOINT.npz",
    )
    ap.add_argument(
        "--endpoint-512",
        default="rot_rh_low_mode_endpoint_v138_ENDPOINT.npz",
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--insert-L-list",
        default="181019,362039",
        help="Non-dyadic cutoffs inserted between 128k/256k and 256k/512k.",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--focus-modes", default="9,10,13,14")

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--newton-iters", type=int, default=16)
    ap.add_argument("--root-tol", type=float, default=2e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.20)
    ap.add_argument("--bracket-fraction", type=float, default=0.45)

    ap.add_argument(
        "--diameter-contraction-gate",
        type=float,
        default=0.90,
        help="Latest tail-set diameter ratio required for strong contraction.",
    )
    ap.add_argument(
        "--inserted-residual-gate",
        type=float,
        default=5e-9,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_cutoff_independence_v143",
    )

    args = ap.parse_args()

    insert_Ls = sorted(set(csv_ints(args.insert_L_list)))
    focus = csv_ints(args.focus_modes)

    # ------------------------------------------------------------------
    # Load known endpoints: 128k, 256k, 512k
    # ------------------------------------------------------------------
    z = np.load(args.base_roots_npz)
    Lbase = np.asarray(z["L"], int)
    Rbase = np.asarray(z["roots"], float)
    h = np.where(Lbase == 128000)[0]
    if not len(h):
        raise RuntimeError("Need L=128000 in base roots NPZ.")
    r128_full = np.asarray(Rbase[int(h[0])], float)

    L256, r256_full = load_endpoint(args.endpoint_256)
    L512, r512_full = load_endpoint(args.endpoint_512)

    if L256 != 256000 or L512 != 512000:
        raise RuntimeError("Endpoint files are not the expected 256k and 512k files.")

    n = min(args.modes, len(r128_full), len(r256_full), len(r512_full))
    if n < 2:
        raise RuntimeError("Need at least two modes.")

    known = {
        128000: r128_full[:n].copy(),
        256000: r256_full[:n].copy(),
        512000: r512_full[:n].copy(),
    }

    print("=" * 128)
    print("ROT-RH v143 — MULTISCALE CUTOFF-INDEPENDENCE / CAUCHY-NET AUDIT")
    print("=" * 128)
    print("Xi / zeta / known zeros          : NONE")
    print(f"known cutoffs                     : {sorted(known)}")
    print(f"inserted non-dyadic cutoffs       : {insert_Ls}")
    print(f"modes                             : 1..{n}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 128)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    inserted_local_rows = []
    warning_messages = {}

    # ------------------------------------------------------------------
    # Solve inserted cutoffs using bracketing endpoints.
    # ------------------------------------------------------------------
    for L in insert_Ls:
        if L in known:
            continue

        anchors = sorted(known)
        lower = [x for x in anchors if x < L]
        upper = [x for x in anchors if x > L]
        if not lower or not upper:
            raise RuntimeError(
                f"Inserted L={L} must lie between known endpoints in this v143 audit."
            )

        La = max(lower)
        Lb = min(upper)
        ra = known[La]
        rb = known[Lb]

        seed = log_interp_roots(L, La, Lb, ra, rb)

        print(f"[L={L}] building RenormalizedPhase; anchors {La},{Lb} ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phase = v102.RenormalizedPhase.build(
                base,
                int(L),
                float(args.tail_factor),
                int(args.counter_q),
            )
        warning_messages[L] = [str(w.message) for w in wrn]

        if warning_messages[L]:
            print(f"[L={L}] build warnings: {len(warning_messages[L])}")
            for msg in warning_messages[L][:2]:
                print(f"           warning: {msg}")

        rnew = np.empty(n, float)
        residuals = np.empty(n, float)
        methods = []

        # Build brackets from the two anchor root configurations.
        # Use the larger local neighboring spacing to avoid clipping a valid continuation.
        for j in range(n):
            if j == 0:
                gap_a = ra[1] - ra[0]
                gap_b = rb[1] - rb[0]
                gap = max(gap_a, gap_b)
                left = max(1e-8, seed[j] - args.bracket_fraction * gap)
                right = seed[j] + args.bracket_fraction * gap
            elif j == n - 1:
                gap_a = ra[-1] - ra[-2]
                gap_b = rb[-1] - rb[-2]
                gap = max(gap_a, gap_b)
                left = seed[j] - args.bracket_fraction * gap
                right = seed[j] + args.bracket_fraction * gap
            else:
                left_gap = max(ra[j]-ra[j-1], rb[j]-rb[j-1])
                right_gap = max(ra[j+1]-ra[j], rb[j+1]-rb[j])
                left = seed[j] - args.bracket_fraction * left_gap
                right = seed[j] + args.bracket_fraction * right_gap

            x, res, method = refine_root(
                phase=phase,
                x0=float(seed[j]),
                target=(j+1)-0.5,
                left=float(left),
                right=float(right),
                max_iter=args.newton_iters,
                tol=args.root_tol,
                max_step=args.max_newton_step,
            )

            rnew[j] = x
            residuals[j] = res
            methods.append(method)

            # Defect of log-interpolated seed under the actual inserted phase.
            seed_defect = scalar_call(phase.F, seed[j]) - ((j+1)-0.5)

            inserted_local_rows.append(dict(
                L=L,
                anchor_low=La,
                anchor_high=Lb,
                k=j+1,
                seed_E=float(seed[j]),
                solved_E=float(x),
                abs_seed_to_root=float(abs(x-seed[j])),
                seed_defect=float(seed_defect),
                abs_seed_defect=float(abs(seed_defect)),
                root_residual=float(res),
                method=method,
            ))

        if np.any(np.diff(rnew) <= 0):
            raise RuntimeError(f"Root ordering failed at inserted L={L}.")

        if np.max(residuals) > args.inserted_residual_gate:
            print(
                f"WARNING: inserted L={L} max residual "
                f"{np.max(residuals):.3e} exceeds gate."
            )

        known[L] = rnew

        print(
            f"[L={L}] solved 1..{n}; "
            f"max residual={np.max(residuals):.3e}; "
            f"max |seed-root|={np.max(np.abs(rnew-seed)):.3e}"
        )

    write_csv(args.prefix + "_INSERTED_LOCAL.csv", inserted_local_rows)

    # ------------------------------------------------------------------
    # Assemble ordered cutoff net
    # ------------------------------------------------------------------
    Ls = np.array(sorted(known), dtype=int)
    R = np.vstack([known[int(L)] for L in Ls])
    Lam = 1.0 / R**2

    root_rows = []
    for i, L in enumerate(Ls):
        for j in range(n):
            root_rows.append(dict(
                L=int(L),
                k=j+1,
                E=float(R[i,j]),
                lambda_k=float(Lam[i,j]),
            ))
    write_csv(args.prefix + "_ROOTS.csv", root_rows)

    np.savez_compressed(
        args.prefix + "_ROOTS.npz",
        L=Ls,
        roots=R,
        lambda_vals=Lam,
    )

    # ------------------------------------------------------------------
    # All pairwise distances
    # ------------------------------------------------------------------
    pair_rows = []
    D = np.zeros((len(Ls), len(Ls)), float)

    focus_idx = [k-1 for k in focus if 1 <= k <= n]
    low16 = min(16, n)

    for i in range(len(Ls)):
        for j in range(i+1, len(Ls)):
            d_all = pair_distance(Lam[i], Lam[j])
            d_16 = pair_distance(Lam[i,:low16], Lam[j,:low16])
            d_focus = (
                pair_distance(Lam[i,focus_idx], Lam[j,focus_idx])
                if focus_idx else np.nan
            )
            D[i,j] = D[j,i] = d_all

            pair_rows.append(dict(
                L_a=int(Ls[i]),
                L_b=int(Ls[j]),
                ratio_L=float(Ls[j]/Ls[i]),
                log2_separation=float(math.log(Ls[j]/Ls[i], 2.0)),
                trace_distance_1_16=d_16,
                trace_distance_1_N=d_all,
                focus_trace_distance=d_focus,
            ))

    write_csv(args.prefix + "_PAIRWISE.csv", pair_rows)

    # ------------------------------------------------------------------
    # Tail-set Cauchy diameters
    # C_N(L0) = max pairwise distance among all cutoffs >= L0.
    # ------------------------------------------------------------------
    diameter_rows = []

    for start in range(len(Ls)-1):
        sub = list(range(start, len(Ls)))
        if len(sub) < 2:
            continue

        max_all = -1.0
        max_16 = -1.0
        max_focus = -1.0
        pair_all = None
        pair_16 = None
        pair_focus = None

        for ii in range(len(sub)):
            for jj in range(ii+1, len(sub)):
                i, j = sub[ii], sub[jj]
                a, b = int(Ls[i]), int(Ls[j])

                da = pair_distance(Lam[i], Lam[j])
                d16 = pair_distance(Lam[i,:low16], Lam[j,:low16])
                df = (
                    pair_distance(Lam[i,focus_idx], Lam[j,focus_idx])
                    if focus_idx else np.nan
                )

                if da > max_all:
                    max_all, pair_all = da, (a,b)
                if d16 > max_16:
                    max_16, pair_16 = d16, (a,b)
                if np.isfinite(df) and df > max_focus:
                    max_focus, pair_focus = df, (a,b)

        diameter_rows.append(dict(
            L0=int(Ls[start]),
            cutoffs_in_tail=len(sub),
            diameter_1_16=max_16,
            diameter_1_N=max_all,
            focus_diameter=max_focus,
            pair_1_16=f"{pair_16[0]}->{pair_16[1]}" if pair_16 else "",
            pair_1_N=f"{pair_all[0]}->{pair_all[1]}" if pair_all else "",
            pair_focus=f"{pair_focus[0]}->{pair_focus[1]}" if pair_focus else "",
        ))

    # Ratios between successive tail-set diameters.
    for i, r in enumerate(diameter_rows):
        if i == 0:
            r["diameter_ratio_1_16"] = np.nan
            r["diameter_ratio_1_N"] = np.nan
            r["diameter_ratio_focus"] = np.nan
        else:
            prev = diameter_rows[i-1]
            r["diameter_ratio_1_16"] = (
                r["diameter_1_16"]/prev["diameter_1_16"]
                if prev["diameter_1_16"] > 0 else np.nan
            )
            r["diameter_ratio_1_N"] = (
                r["diameter_1_N"]/prev["diameter_1_N"]
                if prev["diameter_1_N"] > 0 else np.nan
            )
            r["diameter_ratio_focus"] = (
                r["focus_diameter"]/prev["focus_diameter"]
                if prev["focus_diameter"] > 0 else np.nan
            )

    write_csv(args.prefix + "_TAIL_DIAMETERS.csv", diameter_rows)

    # ------------------------------------------------------------------
    # Subsequence/path consistency
    # ------------------------------------------------------------------
    # Compare the dyadic triplet with the inserted sqrt(2)-shifted chain.
    def idxL(L):
        hit = np.where(Ls == L)[0]
        return int(hit[0]) if len(hit) else None

    dyadic = [128000,256000,512000]
    inserted_chain = [L for L in Ls if L not in dyadic]

    dyadic_step_sum = np.nan
    if all(idxL(L) is not None for L in dyadic):
        i0,i1,i2 = [idxL(L) for L in dyadic]
        dyadic_step_sum = (
            pair_distance(Lam[i0],Lam[i1]) +
            pair_distance(Lam[i1],Lam[i2])
        )

    inserted_neighbor_sum = 0.0
    for a,b in zip(Ls[:-1], Ls[1:]):
        ia,ib = idxL(int(a)),idxL(int(b))
        inserted_neighbor_sum += pair_distance(Lam[ia],Lam[ib])

    # Latest two meaningful tail-set ratios (if available).
    finite_diam = [r for r in diameter_rows if r["cutoffs_in_tail"] >= 2]
    latest_all_ratio = (
        finite_diam[-1]["diameter_ratio_1_N"]
        if len(finite_diam) >= 2 else np.nan
    )
    latest_16_ratio = (
        finite_diam[-1]["diameter_ratio_1_16"]
        if len(finite_diam) >= 2 else np.nan
    )

    # More robust: ratio from first 4+-point tail to next 3+-point tail if possible.
    contraction_candidates = [
        r for r in diameter_rows
        if r["cutoffs_in_tail"] >= 3
        and np.isfinite(r["diameter_ratio_1_N"])
    ]
    strong_contractions = [
        r["diameter_ratio_1_N"] < args.diameter_contraction_gate
        for r in contraction_candidates
    ]

    inserted_rows_latest = inserted_local_rows
    max_inserted_res = (
        max(r["root_residual"] for r in inserted_rows_latest)
        if inserted_rows_latest else 0.0
    )

    if contraction_candidates and all(strong_contractions) and max_inserted_res <= args.inserted_residual_gate:
        verdict = "FINITE_MODE_CAUCHY_NET_CUTOFF_INDEPENDENCE_STRONGLY_SUPPORTED"
    elif contraction_candidates and contraction_candidates[-1]["diameter_ratio_1_N"] < 1.0:
        verdict = "FINITE_MODE_CAUCHY_NET_SHRINKS_BUT_NOT_MONOTONE_STRONG"
    else:
        verdict = "FULL_CUTOFF_INDEPENDENCE_NUMERICALLY_UNRESOLVED"

    summary = dict(
        version=143,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        cutoff_net=Ls.tolist(),
        modes=n,
        focus_modes=focus,
        max_inserted_root_residual=max_inserted_res,
        dyadic_step_sum=dyadic_step_sum,
        interlaced_neighbor_step_sum=inserted_neighbor_sum,
        tail_diameters=diameter_rows,
        verdict=verdict,
        theorem_status=dict(
            finite_mode_arbitrary_cutoff_cauchy_net="NUMERICALLY_TESTED",
            fixed_mode_limit_all_k="OPEN_ANALYTICALLY",
            uniform_summable_high_k_majorant="OPEN_ANALYTICALLY",
            trace_norm_cutoff_independence="OPEN_ANALYTICALLY",
        ),
        exact_proof_route=(
            "For every epsilon>0 choose N so the proven uniform high-k tail is < epsilon/2; "
            "then choose L0 so max_{L,M>=L0} sum_{k<=N}|lambda_k(L)-lambda_k(M)| < epsilon/2. "
            "This implies ||K_L-K_M||_1<epsilon and hence trace-norm cutoff independence."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    # ------------------------------------------------------------------
    # Terminal
    # ------------------------------------------------------------------
    print()
    print("Pairwise neighboring cutoff distances")
    print("-" * 128)
    for a,b in zip(Ls[:-1], Ls[1:]):
        row = next(r for r in pair_rows if r["L_a"] == int(a) and r["L_b"] == int(b))
        print(
            f"{a:>7d}->{b:<7d}  "
            f"d_1:16={row['trace_distance_1_16']:.6e}  "
            f"d_1:{n}={row['trace_distance_1_N']:.6e}  "
            f"d_focus={row['focus_trace_distance']:.6e}"
        )

    print()
    print("Tail-set Cauchy diameters")
    print("-" * 128)
    for r in diameter_rows:
        print(
            f"L0={r['L0']:>7d}  points={r['cutoffs_in_tail']}  "
            f"C_1:16={r['diameter_1_16']:.6e}  "
            f"C_1:{n}={r['diameter_1_N']:.6e}  "
            f"C_focus={r['focus_diameter']:.6e}  "
            f"ratio_N={r['diameter_ratio_1_N']:.6f}"
        )

    print()
    print("=" * 128)
    print(f"cutoff net                         : {Ls.tolist()}")
    print(f"max inserted root residual         : {max_inserted_res:.3e}")
    print(f"dyadic two-step variation          : {dyadic_step_sum:.9e}")
    print(f"interlaced neighbor variation      : {inserted_neighbor_sum:.9e}")
    if contraction_candidates:
        print(
            f"latest >=3-point tail diameter ratio: "
            f"{contraction_candidates[-1]['diameter_ratio_1_N']:.9f}"
        )
    print(f"VERDICT                            : {verdict}")
    print("=" * 128)
    print("NOTE: A script cannot prove the infinite-cutoff theorem by finite sampling.")
    print("      A rigorous proof still needs the analytic high-k majorant and all-k fixed-mode convergence.")


if __name__ == "__main__":
    main()
