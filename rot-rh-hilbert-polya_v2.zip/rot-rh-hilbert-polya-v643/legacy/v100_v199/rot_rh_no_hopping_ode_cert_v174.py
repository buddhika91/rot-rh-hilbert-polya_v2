#!/usr/bin/env python3
"""
ROT-RH v174 — INDEPENDENT ODE / NO-ROOT-HOPPING CERTIFICATION

Purpose
-------
v172/v173 found synthetic root escape in the two-layer Bellotti-cap1
adversary, but the original continuation used many Brent corrections.

v174 independently follows the SAME implicit root manifold using the ODE

    dE/dtau = -S_tau/S_E,

written in logarithmic time u=log(tau):

    dE/du = -tau*S_tau/S_E.

It integrates with scipy.solve_ivp(DOP853), periodically projects back to
S(E,tau)=0 using NEWTON ONLY, and certifies that each projection correction
is a small fraction of the local phase-root spacing

    Delta_E ~ pi/tau.

If the escaping branch is reproduced while:
  * no Newton projection fails,
  * every projection correction << pi/tau,
  * S_E stays bounded away from zero,
  * endpoint agrees with v173,

then silent neighboring-root hopping is effectively ruled out in this
synthetic model.

NO Xi / zeta evaluation / known-zero ordinates are used.

Inputs
------
--candidates-csv
    v171 two-layer adversarial candidate file.

--reference-trajectories (optional)
    v173 trajectory CSV. Used only to compare endpoints, not to drive the ODE.

Outputs
-------
<prefix>_TRAJECTORIES.csv
<prefix>_BRANCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.integrate import solve_ivp
    from scipy.optimize import brentq
    from scipy.special import loggamma, digamma
except Exception as exc:
    raise RuntimeError("v174 requires scipy.") from exc


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


class SyntheticZeroPhase:
    def __init__(
        self,
        beta,
        gamma,
        include_conjugates=True,
        include_functional_mirror=True,
    ):
        beta = np.asarray(beta, dtype=float)
        gamma = np.asarray(gamma, dtype=float)

        ok = (
            np.isfinite(beta) & np.isfinite(gamma)
            & (beta > 0.5) & (beta < 1.0) & (gamma > 0)
        )
        beta = beta[ok]
        gamma = gamma[ok]

        aa = []
        gg = []

        for b, g in zip(beta, gamma):
            a = b-0.5

            aa.append(a);  gg.append(g)
            if include_conjugates:
                aa.append(a); gg.append(-g)

            if include_functional_mirror:
                am = -a
                aa.append(am); gg.append(g)
                if include_conjugates:
                    aa.append(am); gg.append(-g)

        self.a = np.asarray(aa, dtype=float)
        self.gamma = np.asarray(gg, dtype=float)

    def eval(self, E, tau):
        """
        Scaled phase and derivatives.

        At S=0, the common positive scaling drops out of -S_tau/S_E exactly.
        """
        w = self.a + 1j*(E-self.gamma)
        lg = loggamma(w)
        logz = lg + self.a*tau + 1j*(E-self.gamma)*tau

        shift = float(np.max(np.real(logz)))
        z = np.exp(logz-shift)

        S = float(np.imag(np.sum(z)))

        psi = digamma(w)

        dE = np.sum(1j*(psi+tau)*z)
        SE = float(np.imag(dE))

        dt = np.sum(w*z)
        St = float(np.imag(dt))

        return S, SE, St, shift


def find_initial_roots(phase, tau, E_min, E_max, grid_points):
    xs = np.linspace(E_min, E_max, grid_points)
    fs = np.array([phase.eval(float(x), tau)[0] for x in xs])

    roots = []

    for i in range(len(xs)-1):
        a, b = float(xs[i]), float(xs[i+1])
        fa, fb = float(fs[i]), float(fs[i+1])

        if not (np.isfinite(fa) and np.isfinite(fb)):
            continue

        if fa == 0.0:
            roots.append(a)
        elif fa*fb < 0:
            try:
                r = brentq(
                    lambda E: phase.eval(E, tau)[0],
                    a, b,
                    xtol=1e-14,
                    rtol=1e-14,
                    maxiter=100,
                )
                roots.append(float(r))
            except Exception:
                pass

    if not roots:
        raise RuntimeError("No initial roots found.")

    return np.asarray(sorted(set(np.round(roots, 13))), dtype=float)


def newton_project(
    phase,
    E0,
    tau,
    iterations,
    residual_tol,
    max_spacing_fraction,
):
    E = float(E0)
    spacing = math.pi/max(tau, 1.0)
    total_correction = 0.0

    for it in range(iterations):
        S, SE, St, shift = phase.eval(E, tau)

        if abs(S) <= residual_tol:
            return {
                "ok": True,
                "E": E,
                "residual": abs(S),
                "abs_SE": abs(SE),
                "iterations": it,
                "total_correction": total_correction,
                "correction_over_spacing": (
                    abs(total_correction)/max(spacing, 1e-300)
                ),
            }

        if not np.isfinite(SE) or abs(SE) < 1e-14:
            break

        step = -S/SE

        # Certification condition: never permit a Newton projection step
        # larger than the allowed fraction of a local root spacing.
        if abs(step) > max_spacing_fraction*spacing:
            return {
                "ok": False,
                "reason": "projection_step_exceeds_spacing_gate",
                "E": E,
                "residual": abs(S),
                "abs_SE": abs(SE),
                "iterations": it,
                "attempted_step": step,
                "spacing": spacing,
                "total_correction": total_correction,
                "correction_over_spacing": (
                    abs(total_correction)/max(spacing, 1e-300)
                ),
            }

        E += step
        total_correction += step

    S, SE, *_ = phase.eval(E, tau)

    return {
        "ok": bool(abs(S) <= residual_tol),
        "reason": "newton_no_convergence",
        "E": E,
        "residual": abs(S),
        "abs_SE": abs(SE),
        "iterations": iterations,
        "total_correction": total_correction,
        "correction_over_spacing": (
            abs(total_correction)/max(spacing, 1e-300)
        ),
    }


def integrate_chunk(
    phase,
    E0,
    tau0,
    tau1,
    rtol,
    atol,
    max_u_step,
):
    u0 = math.log(tau0)
    u1 = math.log(tau1)

    min_abs_SE = [np.inf]
    max_abs_rhs = [0.0]

    def rhs(u, y):
        tau = math.exp(float(u))
        E = float(y[0])

        S, SE, St, _ = phase.eval(E, tau)

        min_abs_SE[0] = min(min_abs_SE[0], abs(SE))

        if not np.isfinite(SE) or abs(SE) < 1e-14:
            return [np.nan]

        val = -tau*St/SE
        max_abs_rhs[0] = max(max_abs_rhs[0], abs(val))
        return [val]

    sol = solve_ivp(
        rhs,
        (u0, u1),
        [float(E0)],
        method="DOP853",
        rtol=rtol,
        atol=atol,
        max_step=max_u_step,
    )

    if not sol.success:
        return {
            "ok": False,
            "message": sol.message,
            "E_pred": float(sol.y[0, -1]),
            "nfev": int(sol.nfev),
            "min_abs_SE": float(min_abs_SE[0]),
            "max_abs_rhs": float(max_abs_rhs[0]),
        }

    return {
        "ok": True,
        "E_pred": float(sol.y[0, -1]),
        "nfev": int(sol.nfev),
        "min_abs_SE": float(min_abs_SE[0]),
        "max_abs_rhs": float(max_abs_rhs[0]),
    }


def build_checkpoints(tau_min, tau_max, count):
    return np.geomspace(tau_min, tau_max, count)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--candidates-csv",
        default="rot_rh_bellotti_density_adversary_v171_mu4_cap1_CANDIDATES.csv",
    )
    ap.add_argument(
        "--reference-trajectories",
        default="rot_rh_bellotti_cap1_mirror_full_phase_v173_TRAJECTORIES.csv",
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)

    ap.add_argument("--E-ref", type=float, default=20.0)
    ap.add_argument("--E-window", type=float, default=1.0)
    ap.add_argument("--branches", type=int, default=8)
    ap.add_argument("--initial-grid-points", type=int, default=4000)

    ap.add_argument("--checkpoints", type=int, default=1200)

    ap.add_argument("--rtol", type=float, default=1e-10)
    ap.add_argument("--atol", type=float, default=1e-12)
    ap.add_argument(
        "--max-u-step",
        type=float,
        default=0.01,
        help="Maximum solve_ivp step in u=log(tau).",
    )

    ap.add_argument("--newton-iters", type=int, default=8)
    ap.add_argument("--projection-residual-tol", type=float, default=1e-10)
    ap.add_argument(
        "--projection-spacing-fraction",
        type=float,
        default=0.20,
        help="Every Newton projection step must be <= this * pi/tau.",
    )

    ap.add_argument(
        "--endpoint-relative-gate",
        type=float,
        default=5e-4,
        help="Relative agreement gate with v173 endpoint.",
    )
    ap.add_argument(
        "--transversality-gate",
        type=float,
        default=1e-5,
    )
    ap.add_argument(
        "--escape-E-gate",
        type=float,
        default=200.0,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_no_hopping_ode_cert_v174",
    )

    args = ap.parse_args()

    cand = pd.read_csv(args.candidates_csv)

    if not {"beta", "gamma"}.issubset(cand.columns):
        raise RuntimeError("Candidates CSV needs beta,gamma.")

    phase = SyntheticZeroPhase(
        cand["beta"].to_numpy(dtype=float),
        cand["gamma"].to_numpy(dtype=float),
        include_conjugates=True,
        include_functional_mirror=True,
    )

    roots0 = find_initial_roots(
        phase,
        args.tau_min,
        args.E_ref-args.E_window,
        args.E_ref+args.E_window,
        args.initial_grid_points,
    )

    order = np.argsort(np.abs(roots0-args.E_ref))
    chosen = np.sort(
        roots0[order[:min(args.branches, len(roots0))]]
    )

    tau_grid = build_checkpoints(
        args.tau_min,
        args.tau_max,
        args.checkpoints,
    )

    ref_end = {}
    ref_path = Path(args.reference_trajectories)
    if ref_path.exists():
        ref = pd.read_csv(ref_path)
        if {"branch", "tau", "E"}.issubset(ref.columns):
            for b in sorted(ref["branch"].unique()):
                g = ref[ref["branch"] == b].sort_values("tau")
                ref_end[int(b)] = float(g.iloc[-1]["E"])

    print("=" * 164)
    print("ROT-RH v174 — INDEPENDENT ODE / NO-ROOT-HOPPING CERTIFICATION")
    print("=" * 164)
    print("Xi / zeta / known zeros          : NONE")
    print(f"synthetic candidate layers        : {len(cand)}")
    print(f"complex terms incl. symmetries    : {len(phase.a)}")
    print(f"tau window                        : [{args.tau_min:.6g}, {args.tau_max:.6g}]")
    print(f"log-time checkpoints              : {len(tau_grid)}")
    print(f"DOP853 rtol / atol                : {args.rtol} / {args.atol}")
    print(f"max u=log(tau) step               : {args.max_u_step}")
    print(f"projection spacing gate           : {args.projection_spacing_fraction} * pi/tau")
    print(f"initial roots found               : {len(roots0)}")
    print(f"tracking branches                 : {len(chosen)}")
    print("initial E                         : "
          + ", ".join(f"{x:.12f}" for x in chosen))
    print("=" * 164)

    traj_rows = []
    branch_rows = []

    for bi, Einit in enumerate(chosen, start=1):
        E = float(Einit)
        tau_prev = float(tau_grid[0])

        S0, SE0, St0, _ = phase.eval(E, tau_prev)

        traj_rows.append({
            "branch": bi,
            "tau": tau_prev,
            "E": E,
            "residual": abs(S0),
            "abs_SE": abs(SE0),
            "projection_correction": 0.0,
            "projection_over_spacing": 0.0,
            "ode_nfev": 0,
            "ode_min_abs_SE": abs(SE0),
            "status": "initial",
        })

        failed = False
        failure_reason = ""
        total_nfev = 0
        max_proj_ratio = 0.0
        max_proj_abs = 0.0
        min_SE = abs(SE0)
        min_ode_SE = abs(SE0)
        max_residual = abs(S0)

        for ti in range(1, len(tau_grid)):
            tau_new = float(tau_grid[ti])

            ode = integrate_chunk(
                phase,
                E,
                tau_prev,
                tau_new,
                args.rtol,
                args.atol,
                args.max_u_step,
            )

            total_nfev += int(ode["nfev"])
            min_ode_SE = min(
                min_ode_SE,
                float(ode["min_abs_SE"]),
            )

            if not ode["ok"]:
                failed = True
                failure_reason = "ode_failure:" + str(ode["message"])
                break

            proj = newton_project(
                phase,
                ode["E_pred"],
                tau_new,
                args.newton_iters,
                args.projection_residual_tol,
                args.projection_spacing_fraction,
            )

            if not proj["ok"]:
                failed = True
                failure_reason = str(proj.get("reason", "projection_failure"))
                break

            E = float(proj["E"])
            tau_prev = tau_new

            max_proj_ratio = max(
                max_proj_ratio,
                float(proj["correction_over_spacing"]),
            )
            max_proj_abs = max(
                max_proj_abs,
                abs(float(proj["total_correction"])),
            )
            min_SE = min(min_SE, float(proj["abs_SE"]))
            max_residual = max(
                max_residual,
                float(proj["residual"]),
            )

            traj_rows.append({
                "branch": bi,
                "tau": tau_new,
                "E": E,
                "residual": float(proj["residual"]),
                "abs_SE": float(proj["abs_SE"]),
                "projection_correction": float(proj["total_correction"]),
                "projection_over_spacing": float(proj["correction_over_spacing"]),
                "ode_nfev": int(ode["nfev"]),
                "ode_min_abs_SE": float(ode["min_abs_SE"]),
                "status": "projected",
            })

        g = pd.DataFrame(
            [r for r in traj_rows if r["branch"] == bi]
        ).sort_values("tau")

        Evals = g["E"].to_numpy(dtype=float)

        endpoint_ref = ref_end.get(bi, np.nan)
        endpoint_rel = (
            abs(Evals[-1]-endpoint_ref)/max(abs(endpoint_ref), 1.0)
            if np.isfinite(endpoint_ref) else np.nan
        )

        escaped = bool(np.max(np.abs(Evals)) > args.escape_E_gate)

        endpoint_pass = bool(
            (not np.isfinite(endpoint_rel))
            or endpoint_rel <= args.endpoint_relative_gate
        )

        trans_pass = bool(
            min(min_SE, min_ode_SE) >= args.transversality_gate
        )

        branch_pass = bool(
            not failed
            and endpoint_pass
            and trans_pass
            and max_proj_ratio <= args.projection_spacing_fraction + 1e-12
        )

        branch_rows.append({
            "branch": bi,
            "E_initial": float(Evals[0]),
            "E_final": float(Evals[-1]),
            "E_min": float(np.min(Evals)),
            "E_max": float(np.max(Evals)),
            "max_abs_E": float(np.max(np.abs(Evals))),
            "escaped": escaped,
            "failed": failed,
            "failure_reason": failure_reason,
            "points_completed": int(len(g)),
            "total_ode_nfev": int(total_nfev),
            "max_projection_over_spacing": float(max_proj_ratio),
            "max_projection_abs": float(max_proj_abs),
            "max_residual": float(max_residual),
            "min_abs_SE_projected": float(min_SE),
            "min_abs_SE_ode": float(min_ode_SE),
            "reference_endpoint": endpoint_ref,
            "endpoint_relative_error_vs_v173": endpoint_rel,
            "endpoint_agreement_pass": endpoint_pass,
            "transversality_pass": trans_pass,
            "no_hopping_cert_pass": branch_pass,
        })

        print(
            f"[branch {bi}] E={Evals[0]:.9f}->{Evals[-1]:.9f}  "
            f"escape={escaped}  fail={failed}  "
            f"max proj/spacing={max_proj_ratio:.3e}  "
            f"min|SE|={min(min_SE,min_ode_SE):.3e}  "
            f"endpoint rel={endpoint_rel:.3e}",
            flush=True,
        )

    traj = pd.DataFrame(traj_rows)
    branches = pd.DataFrame(branch_rows)

    all_cert = bool(
        len(branches) > 0
        and np.all(branches["no_hopping_cert_pass"].to_numpy(dtype=bool))
    )
    all_escape = bool(
        len(branches) > 0
        and np.all(branches["escaped"].to_numpy(dtype=bool))
    )

    # Preserve branch ordering at every common checkpoint reached by all.
    order_violations = 0
    minimum_tracked_separation = np.inf

    common_taus = sorted(set(traj["tau"]))
    for tau in common_taus:
        gg = traj[traj["tau"] == tau].sort_values("branch")
        if len(gg) != len(branches):
            continue

        ev = gg["E"].to_numpy(dtype=float)
        dif = np.diff(ev)

        if len(dif):
            order_violations += int(np.sum(dif <= 0))
            minimum_tracked_separation = min(
                minimum_tracked_separation,
                float(np.min(np.abs(dif))),
            )

    order_pass = bool(order_violations == 0)

    if all_cert and all_escape and order_pass:
        verdict = "SYNTHETIC_ESCAPE_NO_HOPPING_CERTIFIED"
    elif not order_pass:
        verdict = "TRACKED_BRANCH_ORDER_VIOLATION"
    elif not all_cert:
        verdict = "NO_HOPPING_CERTIFICATION_UNRESOLVED"
    else:
        verdict = "ODE_CONTINUATION_DOES_NOT_REPRODUCE_ESCAPE"

    traj.to_csv(
        args.prefix+"_TRAJECTORIES.csv",
        index=False,
    )
    branches.to_csv(
        args.prefix+"_BRANCHES.csv",
        index=False,
    )

    summary = {
        "version": 174,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "scope": (
            "Independent numerical certification of continuous root-manifold "
            "tracking in the synthetic v171 two-layer adversarial phase."
        ),
        "branches": branch_rows,
        "all_no_hopping_certified": all_cert,
        "all_escape": all_escape,
        "tracked_branch_order_violations": order_violations,
        "minimum_tracked_branch_separation": (
            None if not np.isfinite(minimum_tracked_separation)
            else minimum_tracked_separation
        ),
        "tracked_branch_order_pass": order_pass,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("=" * 164)
    print(f"all no-hopping certified          : {all_cert}")
    print(f"all branches escape               : {all_escape}")
    print(f"tracked order violations          : {order_violations}")
    print(f"tracked order pass                : {order_pass}")
    print(f"minimum tracked separation        : {minimum_tracked_separation:.6e}")
    print(f"VERDICT                           : {verdict}")
    print("=" * 164)

    if verdict == "SYNTHETIC_ESCAPE_NO_HOPPING_CERTIFIED":
        print("CONSEQUENCE:")
        print("  The two-layer synthetic escape is reproduced by an independent")
        print("  implicit-ODE continuation with Newton-only projections smaller")
        print("  than a controlled fraction of one local root spacing. Silent")
        print("  neighboring-root hopping is therefore ruled out numerically.")
    elif verdict == "NO_HOPPING_CERTIFICATION_UNRESOLVED":
        print("ACTION:")
        print("  Tighten the log-time checkpoints / max-u-step or inspect the first")
        print("  projection-spacing failure before drawing a topological conclusion.")


if __name__ == "__main__":
    main()
