#!/usr/bin/env python3
"""
ROT-RH v136 — DOMINATED-CONVERGENCE CUTOFF-REMOVAL AUDIT

ZERO-COST postprocessor.  No prime sums, root solving, Xi, zeta, or known-zero data.

Why this audit exists
---------------------
Absolute summability of successive dyadic trace distances,

    sum_j ||K_{2 L_j} - K_{L_j}||_1 < infinity,

is sufficient for trace-norm convergence but is stronger than necessary.

For the diagonal operators

    K_L e_k = lambda_k(L) e_k,     lambda_k(L)=E_k(L)^(-2),

a more natural route is dominated convergence:

  (A) fixed-mode convergence:
        lambda_k(L) -> lambda_k  for every fixed k;

  (B) a uniform summable majorant:
        lambda_k(L) <= a_k,  sum_k a_k < infinity,
        uniformly for all sufficiently large L.

Then

    ||K_L-K||_1 = sum_k |lambda_k(L)-lambda_k| -> 0.

A convenient majorant follows from a uniform Weyl-type lower bound

    E_k(L) >= c * k/log(k+1),

because then

    lambda_k(L) <= c^(-2) log(k+1)^2/k^2,

and the right-hand side is summable.

This script measures how plausible/stable that uniform domination is across
all already-computed cutoff supports.

Outputs
-------
<prefix>_WEYL_BY_L.csv
<prefix>_WEYL_BY_K.csv
<prefix>_TAIL_BOUNDS.csv
<prefix>_FIXED_MODES.csv
<prefix>_VERDICT.json
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import re
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def extract_L(path):
    m = re.search(r"_CACHE_L(\d+)_D\d+\.npz$", Path(path).name)
    return int(m.group(1)) if m else None


def load_supports(roots_npz, cache_glob):
    data = {}

    for p in glob.glob(cache_glob):
        L = extract_L(p)
        if L is None:
            continue
        try:
            z = np.load(p)
            if "roots" in z:
                data[L] = np.asarray(z["roots"], float)
        except Exception:
            pass

    z = np.load(roots_npz)
    Ls = np.asarray(z["L"], int)
    R = np.asarray(z["roots"], float)
    for i, L in enumerate(Ls):
        data[int(L)] = R[i].copy()

    return data


def log2_majorant_tail(N):
    """
    For x>=N>=1, log(x+1) <= log(2x), so
      sum_{k>N} log(k+1)^2/k^2
    is bounded conservatively by f(N+1)+integral_N^inf log(2x)^2/x^2 dx.

    integral_N^inf log(2x)^2/x^2 dx
      = [u^2 + 2u + 2]/N, u=log(2N).
    """
    N = max(int(N), 1)
    k = N + 1
    first = math.log(k + 1.0) ** 2 / (k * k)
    u = math.log(2.0 * N)
    integral = (u * u + 2.0 * u + 2.0) / N
    return first + integral


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--cache-glob",
        default="rot_rh_trace_norm_cutoff_removal_v132_CACHE_L*_D1408.npz",
    )
    ap.add_argument("--k-min", type=int, default=64)
    ap.add_argument("--safety-factor", type=float, default=0.80)
    ap.add_argument(
        "--tail-depths",
        default="64,128,256,512,768,1024,1408",
    )
    ap.add_argument(
        "--fixed-modes",
        default="1,2,4,5,9,10,13,14,16,32,64",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_dominated_convergence_cutoff_v136",
    )
    args = ap.parse_args()

    tail_depths = [
        int(x.strip()) for x in args.tail_depths.split(",") if x.strip()
    ]
    fixed_modes = [
        int(x.strip()) for x in args.fixed_modes.split(",") if x.strip()
    ]

    supports = load_supports(args.roots_npz, args.cache_glob)
    Ls = np.array(sorted(supports), int)
    Nmax = min(len(supports[int(L)]) for L in Ls)

    if args.k_min < 2 or args.k_min > Nmax:
        raise RuntimeError("--k-min must lie inside available spectral depth.")

    R = np.vstack([supports[int(L)][:Nmax] for L in Ls])
    lam = 1.0 / R**2

    k = np.arange(1, Nmax + 1, dtype=float)
    weyl_ratio = R * np.log(k + 1.0)[None, :] / k[None, :]

    tail_slice = slice(args.k_min - 1, Nmax)
    c_by_L = np.min(weyl_ratio[:, tail_slice], axis=1)
    c_emp = float(np.min(c_by_L))
    c_safe = args.safety_factor * c_emp

    print("=" * 120)
    print("ROT-RH v136 — DOMINATED-CONVERGENCE CUTOFF-REMOVAL AUDIT")
    print("=" * 120)
    print("Xi / zeta / known zeros          : NONE")
    print(f"available L supports              : {Ls.tolist()}")
    print(f"available spectral depth          : {Nmax}")
    print(f"Weyl lower-bound audit starts k   : {args.k_min}")
    print(f"empirical c                       : {c_emp:.9f}")
    print(f"safety-reduced c                  : {c_safe:.9f}")
    print("=" * 120)

    # Per-L Weyl constants
    rows_L = []
    for i, L in enumerate(Ls):
        idx = int(np.argmin(weyl_ratio[i, tail_slice])) + args.k_min - 1
        rows_L.append(dict(
            L=int(L),
            empirical_c=float(c_by_L[i]),
            minimizing_k=idx + 1,
            E_at_min=float(R[i, idx]),
            trace_partial=float(np.sum(lam[i])),
        ))
    write_csv(Path(args.prefix + "_WEYL_BY_L.csv"), rows_L)

    # Per-k worst across L
    rows_k = []
    worst_by_k = np.min(weyl_ratio, axis=0)
    max_lambda_by_k = np.max(lam, axis=0)

    for j in range(Nmax):
        maj = (math.log(j + 2.0) ** 2) / (
            max(c_safe, np.finfo(float).tiny) ** 2 * (j + 1.0) ** 2
        )
        rows_k.append(dict(
            k=j + 1,
            min_E_logk_over_k=float(worst_by_k[j]),
            max_lambda_across_L=float(max_lambda_by_k[j]),
            safe_majorant=float(maj),
            lambda_over_majorant=float(max_lambda_by_k[j] / maj),
        ))
    write_csv(Path(args.prefix + "_WEYL_BY_K.csv"), rows_k)

    # Tail bounds
    rows_tail = []
    for N in tail_depths:
        if N > Nmax:
            continue

        # Empirical unresolved mass inside available window N+1..Nmax.
        observed_tail_max = (
            float(np.max(np.sum(lam[:, N:], axis=1)))
            if N < Nmax else 0.0
        )

        analytic_majorant_inf = (
            log2_majorant_tail(N) /
            max(c_safe, np.finfo(float).tiny) ** 2
        )

        trace_max = float(np.max(np.sum(lam, axis=1)))
        rows_tail.append(dict(
            N=N,
            observed_tail_N_to_Nmax_max=observed_tail_max,
            analytic_majorant_N_to_infinity=analytic_majorant_inf,
            analytic_majorant_fraction_of_partial_trace=(
                analytic_majorant_inf / trace_max if trace_max > 0 else np.nan
            ),
        ))
    write_csv(Path(args.prefix + "_TAIL_BOUNDS.csv"), rows_tail)

    # Fixed-mode history and last-step behavior.
    rows_fixed = []
    for kk in fixed_modes:
        if kk < 1 or kk > Nmax:
            continue
        vals = lam[:, kk - 1]
        steps = np.diff(vals)

        last_abs = float(abs(steps[-1])) if len(steps) else np.nan
        prev_abs = float(abs(steps[-2])) if len(steps) >= 2 else np.nan
        last_ratio = (
            last_abs / prev_abs if np.isfinite(prev_abs) and prev_abs > 0 else np.nan
        )

        # Tail diameter of the last three and last five available supports.
        d3 = (
            float(np.max(vals[-3:]) - np.min(vals[-3:]))
            if len(vals) >= 3 else np.nan
        )
        d5 = (
            float(np.max(vals[-5:]) - np.min(vals[-5:]))
            if len(vals) >= 5 else np.nan
        )

        rows_fixed.append(dict(
            k=kk,
            lambda_first=float(vals[0]),
            lambda_last=float(vals[-1]),
            last_abs_step=last_abs,
            previous_abs_step=prev_abs,
            last_to_previous_step_ratio=last_ratio,
            last3_diameter=d3,
            last5_diameter=d5,
            last3_diameter_relative=(
                d3 / abs(vals[-1]) if vals[-1] != 0 else np.nan
            ),
        ))
    write_csv(Path(args.prefix + "_FIXED_MODES.csv"), rows_fixed)

    # Stability of c across cutoff.
    c_rel_spread = (
        float((np.max(c_by_L) - np.min(c_by_L)) / np.median(c_by_L))
        if np.median(c_by_L) > 0 else np.inf
    )

    majorant_holds_observed = bool(
        np.all(max_lambda_by_k[args.k_min - 1:] <= np.array([
            (math.log(j + 2.0) ** 2) /
            (max(c_safe, np.finfo(float).tiny) ** 2 * (j + 1.0) ** 2)
            for j in range(args.k_min - 1, Nmax)
        ]))
    )

    verdict = dict(
        version=136,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        mathematical_route=(
            "fixed-k convergence + uniform summable Weyl majorant "
            "=> trace-norm convergence by dominated convergence"
        ),
        available_L=Ls.tolist(),
        spectral_depth=Nmax,
        k_min=args.k_min,
        empirical_uniform_c=c_emp,
        safety_reduced_c=c_safe,
        relative_spread_of_c_across_cutoffs=c_rel_spread,
        observed_majorant_holds=majorant_holds_observed,
        proof_status=dict(
            uniform_Weyl_majorant="NUMERICALLY_SUPPORTED_ONLY",
            fixed_mode_convergence="OPEN",
            trace_norm_cutoff_removal="OPEN",
        ),
        next_theorem_targets=[
            "Prove E_k(L) >= c k/log(k+1) uniformly for L >= L0 and all sufficiently large k.",
            "Prove F_L^ren(E) converges uniformly on every compact E-interval.",
            "Use a nonvanishing F'_infty near each simple crossing to obtain E_k(L)->E_k.",
            "Apply dominated convergence to sum_k |E_k(L)^(-2)-E_k^(-2)|.",
        ],
    )

    Path(args.prefix + "_VERDICT.json").write_text(
        json.dumps(verdict, indent=2), encoding="utf-8"
    )

    print()
    print("Per-cutoff empirical Weyl constants")
    print("-" * 120)
    for r in rows_L:
        print(
            f"L={r['L']:>8d}  c={r['empirical_c']:.9f}  "
            f"min at k={r['minimizing_k']:4d}"
        )

    print()
    print("Selected tail majorants")
    print("-" * 120)
    for r in rows_tail:
        print(
            f"N={r['N']:4d}  "
            f"observed(N..{Nmax})={r['observed_tail_N_to_Nmax_max']:.3e}  "
            f"safe analytic infinity bound={r['analytic_majorant_N_to_infinity']:.3e}"
        )

    print()
    print("=" * 120)
    print(f"empirical uniform Weyl c          : {c_emp:.9f}")
    print(f"safe c                            : {c_safe:.9f}")
    print(f"relative c spread across L        : {c_rel_spread:.3e}")
    print(f"safe majorant holds on data       : {majorant_holds_observed}")
    print("FIXED-MODE CONVERGENCE             : OPEN")
    print("UNIFORM WEYL DOMINATION THEOREM    : OPEN")
    print("TRACE-NORM CUTOFF REMOVAL          : OPEN")
    print("=" * 120)


if __name__ == "__main__":
    main()
