#!/usr/bin/env python3
"""
ROT-RH v189 — SWITCH-159 FULL-MESH REPROJECTION / INTEGRATION RECONCILIATION

Purpose
-------
There is a serious numerical discrepancy that must be settled before further
analytic interpretation:

  v181 original in-memory result:
      |Int epsilon| / Int gamma ~ 4.9e-9

  later float-CSV reprojected / stride-4 analyses:
      percent-level mixing, K ~ 78.

v189 uses ONLY the original v181 switch-159 sample mesh and compares:

  A) original stored epsilon from v181 CSV (if present),
  B) exact high-precision reprojected epsilon on EVERY original mesh point,
  C) the same reprojected epsilon after stride-4 downsampling.

It also compares exact grouped-envelope L=log(A2/A1) geometry on the full mesh.

No continuation is performed.

Verdicts
--------
FULL_MESH_REPROJECTED_BROAD_MIXING_CONFIRMED
    The percent-level / broad profile survives full-mesh reprojection.

STRIDE_DOWNSAMPLING_ARTIFACT_DETECTED
    Full-mesh reprojection is small but stride-4 interpolation inflates it.

ORIGINAL_V181_EPSILON_MISMATCH
    Stored original epsilon and reprojected full-mesh epsilon disagree strongly;
    inspect root-coordinate sensitivity / v181 arithmetic.

RECONCILIATION_UNRESOLVED
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return np.nan
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


class ExactPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a1 = mp.mpf(str(b1))-mp.mpf("0.5")
        self.a2 = mp.mpf(str(b2))-mp.mpf("0.5")
        self.g1 = mp.mpf(str(g1))
        self.g2 = mp.mpf(str(g2))

        self.a = []
        self.g = []
        for a,gg in [(self.a1,self.g1),(self.a2,self.g2)]:
            self.a += [a,a,-a,-a]
            self.g += [gg,-gg,gg,-gg]

    def raw(self,E,tau):
        E = mp.mpf(E)
        tau = mp.mpf(tau)

        ws,logs = [],[]
        for a,g in zip(self.a,self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)+a*tau+1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        Z = mp.fsum(zs)
        S = mp.im(Z)
        R = mp.re(Z)
        G = mp.fsum(
            g*mp.re(z) for g,z in zip(self.g,zs)
        )
        A = mp.fsum(
            a*mp.im(z) for a,z in zip(self.a,zs)
        )
        Q = mp.im(mp.fsum(
            1j*mp.digamma(w)*z for w,z in zip(ws,zs)
        ))
        SE = tau*R+Q
        St = E*R-G+A

        return {
            "S":S,"R":R,"G":G,"A":A,"Q":Q,
            "SE":SE,"St":St,
            "shift":shift,
        }

    def reproject_Y(self,E_seed,tau,tol,cell_fraction,iters):
        tau = mp.mpf(tau)
        Y = tau*mp.mpf(E_seed)

        total = mp.mpf("0")
        maxstep = mp.mpf("0")

        for k in range(iters):
            E = Y/tau
            q = self.raw(E,tau)

            if abs(q["S"]) <= tol:
                return {
                    "ok":True,"E":E,"Y":Y,
                    "residual":abs(q["S"]),
                    "total_cell_shift":abs(total)/mp.pi,
                    "max_step_cell_shift":maxstep,
                    "iterations":k,
                }

            SY = q["SE"]/tau
            if SY == 0 or not mp.isfinite(SY):
                return {"ok":False,"reason":"SY_zero"}

            step = -q["S"]/SY
            ratio = abs(step)/mp.pi

            if ratio > cell_fraction:
                return {
                    "ok":False,
                    "reason":"cell_gate",
                    "step_cell_shift":ratio,
                }

            Y += step
            total += step
            maxstep = max(maxstep,ratio)

        E = Y/tau
        q = self.raw(E,tau)
        return {
            "ok":bool(abs(q["S"])<=tol),
            "reason":"newton_no_convergence",
            "E":E,"Y":Y,
            "residual":abs(q["S"]),
            "total_cell_shift":abs(total)/mp.pi,
            "max_step_cell_shift":maxstep,
            "iterations":iters,
        }

    def evaluate_root(self,E,tau,gamma_active):
        E = mp.mpf(E)
        tau = mp.mpf(tau)
        ga = mp.mpf(gamma_active)

        q = self.raw(E,tau)
        Yt = E-tau*q["St"]/q["SE"]
        eps = Yt-ga

        eps_mix = tau*(q["G"]-ga*q["R"])/q["SE"]
        eps_A = -tau*q["A"]/q["SE"]
        eps_dig = q["Q"]*(E-ga)/q["SE"]

        # grouped positive-gamma direct+mirror envelope
        def group(a,g):
            logs = []
            for aa in [a,-a]:
                w = aa+1j*(E-g)
                logs.append(
                    mp.loggamma(w)+aa*tau+1j*(E-g)*tau
                )
            sh = max(mp.re(z) for z in logs)
            # local grouping scale is irrelevant for ratio after log correction
            C = mp.fsum(mp.exp(z-sh) for z in logs)
            logA = sh+mp.log(abs(C))
            return logA

        logA1 = group(self.a1,self.g1)
        logA2 = group(self.a2,self.g2)
        L = logA2-logA1

        dg = abs(self.g2-self.g1)
        m_mix = abs(eps_mix)/dg if dg != 0 else mp.nan

        return {
            "Yt":Yt,
            "epsilon":eps,
            "epsilon_mix":eps_mix,
            "epsilon_A":eps_A,
            "epsilon_digamma":eps_dig,
            "identity_residual":abs(
                eps-(eps_mix+eps_A+eps_dig)
            ),
            "log_A2_A1":L,
            "m_mix":m_mix,
            "q_over_tauR":(
                abs(q["Q"])/(tau*abs(q["R"]))
                if q["R"] != 0 else mp.inf
            ),
        }


def integrate_summary(df, eps_col, gamma_col="gamma_active"):
    d = df.sort_values("tau")
    t = d["tau"].to_numpy(float)
    e = d[eps_col].to_numpy(float)
    g = d[gamma_col].to_numpy(float)

    signed = trapz(t,e)
    absolute = trapz(t,np.abs(e))
    active = trapz(t,g)

    return {
        "signed":signed,
        "absolute":absolute,
        "active":active,
        "signed_over_active":signed/max(abs(active),1e-300),
        "absolute_over_active":absolute/max(abs(active),1e-300),
    }


def stride_df(df,stride):
    d = df.sort_values("tau").reset_index(drop=True)
    if stride <= 1:
        return d
    idx = list(range(0,len(d),stride))
    if len(d)-1 not in idx:
        idx.append(len(d)-1)
    return d.iloc[sorted(set(idx))].reset_index(drop=True)


def zero_crossings(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    o=np.argsort(x); x=x[o]; y=y[o]
    out=[]
    for i in range(len(x)-1):
        if y[i]==0:
            out.append(float(x[i]))
        elif y[i]*y[i+1]<0:
            out.append(float(
                x[i]-y[i]*(x[i+1]-x[i])/(y[i+1]-y[i])
            ))
    return out


def main():
    ap=argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv",required=True)
    ap.add_argument("--hull-csv",required=True)
    ap.add_argument("--samples-csv",required=True)
    ap.add_argument("--switch-index",type=int,default=159)
    ap.add_argument("--dps",type=int,default=60)
    ap.add_argument("--tol-exp",type=int,default=35)
    ap.add_argument("--newton-iters",type=int,default=8)
    ap.add_argument("--cell-fraction",type=float,default=0.10)
    ap.add_argument("--comparison-stride",type=int,default=4)
    ap.add_argument(
        "--prefix",
        default="rot_rh_switch159_full_mesh_reconcile_v189"
    )
    args=ap.parse_args()

    mp.mp.dps=args.dps
    tol=mp.power(10,-args.tol_exp)
    frac=mp.mpf(str(args.cell_fraction))

    cand=pd.read_csv(args.candidates_csv)
    hull=(
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )
    samp=pd.read_csv(args.samples_csv)
    samp=samp[samp["switch"].astype(int)==args.switch_index].copy()
    samp=samp.sort_values("tau").drop_duplicates("tau").reset_index(drop=True)

    if len(samp)==0:
        raise RuntimeError("No requested switch rows in samples CSV.")

    j=args.switch_index-1
    left=hull.iloc[j]
    right=hull.iloc[j+1]

    c1=match_candidate(cand,left["beta_active"],left["gamma_active"])
    c2=match_candidate(cand,right["beta_active"],right["gamma_active"])

    b1=float(c1["beta"]); g1=float(c1["gamma"])
    b2=float(c2["beta"]); g2=float(c2["gamma"])
    ts=float(left["tau_end"])
    da=abs(b2-b1)

    phase=ExactPhase(b1,g1,b2,g2)

    print("="*180)
    print("ROT-RH v189 — SWITCH-159 FULL-MESH REPROJECTION / INTEGRATION RECONCILIATION")
    print("="*180)
    print(f"switch                            : {args.switch_index}")
    print(f"original mesh rows                : {len(samp)}")
    print(f"tau switch                        : {ts:.12e}")
    print(f"gamma                             : {g1:.9e} -> {g2:.9e}")
    print(f"delta a                           : {da:.9e}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*180)

    rows=[]
    failures=0

    for _,r in samp.iterrows():
        tau=float(r["tau"])
        Eseed=float(r["E"])

        rep=phase.reproject_Y(
            mp.mpf(str(Eseed)),
            mp.mpf(str(tau)),
            tol,frac,args.newton_iters
        )
        if not rep["ok"]:
            failures+=1
            continue

        ga=g1 if tau<=ts else g2
        ev=phase.evaluate_root(
            rep["E"],mp.mpf(str(tau)),mp.mpf(str(ga))
        )

        rr={
            "switch":args.switch_index,
            "tau":tau,
            "x":da*(tau-ts),
            "E_seed":Eseed,
            "E_refined":float(rep["E"]),
            "gamma_active":ga,
            "reprojection_cell_shift":float(rep["total_cell_shift"]),
            "reprojection_step_cell_shift":float(rep["max_step_cell_shift"]),
        }

        # Preserve original v181 diagnostics if present.
        for col in [
            "epsilon","gamma_active","gamma_active_local",
            "E_u","Y_t"
        ]:
            if col in r.index:
                try:
                    rr["orig_"+col]=float(r[col])
                except Exception:
                    pass

        for k,v in ev.items():
            try:
                rr["reproj_"+k]=float(v)
            except Exception:
                rr["reproj_"+k]=np.nan

        rows.append(rr)

    df=pd.DataFrame(rows).sort_values("tau").reset_index(drop=True)
    if len(df)<2:
        raise RuntimeError("Too few reprojected rows.")

    # Original epsilon column selection.
    orig_eps_col=None
    if "orig_epsilon" in df.columns:
        orig_eps_col="orig_epsilon"
    elif "orig_Y_t" in df.columns:
        df["orig_epsilon_from_Yt"] = (
            df["orig_Y_t"]-df["gamma_active"]
        )
        orig_eps_col="orig_epsilon_from_Yt"

    full=integrate_summary(df,"reproj_epsilon")
    full_mix=integrate_summary(df,"reproj_epsilon_mix")

    dstride=stride_df(df,args.comparison_stride)
    stride=integrate_summary(dstride,"reproj_epsilon")
    stride_mix=integrate_summary(dstride,"reproj_epsilon_mix")

    if orig_eps_col:
        orig=integrate_summary(df,orig_eps_col)
    else:
        orig=None

    # Intrinsic K on full mesh.
    x=df["x"].to_numpy(float)
    m=df["reproj_m_mix"].to_numpy(float)
    Kfull=trapz(x,m)

    # Exact grouped envelope crossings on full mesh.
    L=df["reproj_log_A2_A1"].to_numpy(float)
    crosses=zero_crossings(x,L)

    # Sampling density around critical interval.
    bands=[1,2,4,8,16,32,64,128]
    density={}
    for X in bands:
        density[X]=int(np.sum(np.abs(x)<=X))

    # Max gaps in x, globally and around |x|<=32.
    xs=np.sort(x)
    max_gap=float(np.max(np.diff(xs))) if len(xs)>=2 else np.nan
    xin=np.sort(x[np.abs(x)<=32])
    max_gap32=float(np.max(np.diff(xin))) if len(xin)>=2 else np.nan

    # Compare full vs stride inflation.
    inflation=(
        stride_mix["absolute_over_active"]
        / max(full_mix["absolute_over_active"],1e-300)
    )

    # Original-vs-reprojected discrepancy factor.
    if orig:
        orig_vs_reproj=(
            full["absolute_over_active"]
            / max(orig["absolute_over_active"],1e-300)
        )
    else:
        orig_vs_reproj=np.nan

    # Conservative verdict.
    if (
        full_mix["absolute_over_active"] < 1e-4
        and stride_mix["absolute_over_active"]
           > 10*full_mix["absolute_over_active"]
    ):
        verdict="STRIDE_DOWNSAMPLING_ARTIFACT_DETECTED"
    elif (
        full_mix["absolute_over_active"] >= 1e-3
        and abs(inflation-1) <= 0.25
    ):
        verdict="FULL_MESH_REPROJECTED_BROAD_MIXING_CONFIRMED"
    elif orig and (
        max(orig_vs_reproj,1/max(orig_vs_reproj,1e-300)) >= 100
    ):
        verdict="ORIGINAL_V181_EPSILON_MISMATCH"
    else:
        verdict="RECONCILIATION_UNRESOLVED"

    df.to_csv(args.prefix+"_POINTS.csv",index=False)

    summary={
        "version":189,
        "switch":args.switch_index,
        "original_mesh_rows":len(samp),
        "reprojected_rows":len(df),
        "reprojection_failures":failures,
        "original_integral":orig,
        "reprojected_full_integral":full,
        "reprojected_full_mix_integral":full_mix,
        "reprojected_stride_integral":stride,
        "reprojected_stride_mix_integral":stride_mix,
        "stride_over_full_mix_ratio":inflation,
        "original_over_reprojected_factor":orig_vs_reproj,
        "K_full_intrinsic":Kfull,
        "grouped_envelope_crossings_x":crosses,
        "points_in_abs_x_bands":density,
        "max_x_gap":max_gap,
        "max_x_gap_abs32":max_gap32,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*180)
    print(f"reprojection failures              : {failures}")
    if orig:
        print(
            f"ORIGINAL full |eps|/active        : "
            f"{orig['absolute_over_active']:.12e}"
        )
    else:
        print("ORIGINAL full |eps|/active        : unavailable")
    print(
        f"REPROJECTED full |eps|/active     : "
        f"{full['absolute_over_active']:.12e}"
    )
    print(
        f"REPROJECTED full |mix|/active     : "
        f"{full_mix['absolute_over_active']:.12e}"
    )
    print(
        f"REPROJECTED stride-{args.comparison_stride} |mix|/active: "
        f"{stride_mix['absolute_over_active']:.12e}"
    )
    print(
        f"stride/full mix ratio             : "
        f"{inflation:.6e}"
    )
    if orig:
        print(
            f"reprojected/original |eps| ratio  : "
            f"{orig_vs_reproj:.6e}"
        )
    print(f"intrinsic K full mesh              : {Kfull:.12e}")
    print(f"grouped envelope crossings x       : {crosses}")
    print(f"points |x|<=1,2,4,8,16,32,64,128  : {[density[X] for X in bands]}")
    print(f"max x gap                          : {max_gap:.6e}")
    print(f"max x gap within |x|<=32           : {max_gap32:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*180)


if __name__=="__main__":
    main()
