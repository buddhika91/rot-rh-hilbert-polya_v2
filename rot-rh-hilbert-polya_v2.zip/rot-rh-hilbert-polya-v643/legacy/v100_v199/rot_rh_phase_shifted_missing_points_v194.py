#!/usr/bin/env python3
"""
ROT-RH v194 — PHASE-SHIFTED RESOLUTION OF THE TWO MISSING CRITICAL POINTS

Targets only the unresolved v193 points:
    x = -0.875, -0.25

For a frozen slow coordinate x, the fast-phase average over one full period
should not depend on where the one-period integration window starts.
Numerically, however, some window placements can hit a difficult projection
region.  v194 retries the same one-period average with several phase offsets.

For each x:
  * try multiple offsets f in [0,1), using
        [tau0-T/2+f*T, tau0+T/2+f*T]
  * retain successful one-period averages;
  * compare their <|epsilon|>/gamma values;
  * require phase-offset invariance;
  * merge resolved values into the v193 critical profile and v192 baseline.

No Xi / zeta / known zeros are used.
"""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def mp_trapezoid(xs, ys):
    if len(xs) < 2:
        return mp.nan
    s = mp.mpf("0")
    for i in range(len(xs)-1):
        s += (xs[i+1]-xs[i])*(ys[i+1]+ys[i])/2
    return s


def profile_integral(df):
    d = df.sort_values("x")
    x = d["x"].to_numpy(float)
    g = d["gamma_active"].to_numpy(float)
    r = d["mean_abs_epsilon_over_gamma"].to_numpy(float)
    num = float(np.trapezoid(r*g, x))
    den = float(np.trapezoid(g, x))
    return num/max(abs(den), 1e-300)


def cycle_average_shifted(
    mod, phase, tau0, center_E, ga, period, phase_points,
    tol, frac, iters, search_cells, branch_count, max_depth,
    offset_fraction
):
    off = mp.mpf(str(offset_fraction))
    tstart = tau0 - period/2 + off*period
    tend = tstart + period

    roots = mod.local_roots(
        phase, tstart, center_E, tol, frac, iters,
        search_cells, branch_count
    )

    results = []

    for branch_id, r0 in enumerate(roots):
        Y = r0["Y"]
        ts = [
            tstart + (tend-tstart)*mp.mpf(k)/(phase_points-1)
            for k in range(phase_points)
        ]

        rows = []
        ok = True
        md = 0
        mpj = mp.mpf("0")

        for k, t in enumerate(ts):
            if k > 0:
                adv = mod.advance(
                    phase, Y, ts[k-1], t,
                    tol, frac, iters, max_depth
                )
                if not adv["ok"]:
                    ok = False
                    break
                Y = adv["Y"]
                md = max(md, adv["max_depth"])
                mpj = max(mpj, adv["max_proj"])

            ev = phase.eval_Y(Y, t, ga)
            rows.append((t, ev))

        if not ok or len(rows) != phase_points:
            results.append({
                "branch": branch_id,
                "ok": False,
            })
            continue

        tv = [z[0] for z in rows]
        eps = [abs(z[1]["epsilon"]) for z in rows]
        mix = [abs(z[1]["epsilon_mix"]) for z in rows]
        ident = [z[1]["identity_resid"] for z in rows]

        mean_eps = mp_trapezoid(tv, eps)/(tend-tstart)
        mean_mix = mp_trapezoid(tv, mix)/(tend-tstart)

        ids2 = list(range(0, len(tv), 2))
        if len(tv)-1 not in ids2:
            ids2.append(len(tv)-1)

        tv2 = [tv[i] for i in ids2]
        eps2 = [eps[i] for i in ids2]
        mean_eps2 = mp_trapezoid(tv2, eps2)/(tend-tstart)

        results.append({
            "branch": branch_id,
            "ok": True,
            "mean_abs_epsilon_over_gamma": mean_eps/abs(ga),
            "mean_abs_mix_over_gamma": mean_mix/abs(ga),
            "phase_stride2_over_gamma": mean_eps2/abs(ga),
            "max_identity_resid": max(ident),
            "max_depth": md,
            "max_proj": mpj,
        })

    return results


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--baseline-profile",
        default="rot_rh_transition_homogenization_v192_PROFILE.csv",
    )
    ap.add_argument(
        "--critical-profile",
        default="rot_rh_critical_layer_homogenization_v193_CRITICAL_PROFILE.csv",
    )
    ap.add_argument(
        "--v192-module",
        default="rot_rh_transition_homogenization_v192",
    )
    ap.add_argument("--switch-index", type=int, default=159)

    ap.add_argument(
        "--x-values",
        default="-0.875,-0.25",
    )
    ap.add_argument(
        "--phase-offsets",
        default="0,0.125,0.25,0.375,0.5,0.625,0.75,0.875",
    )

    ap.add_argument("--dps", type=int, default=55)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=14)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--search-cells", type=int, default=24)
    ap.add_argument("--branch-count", type=int, default=1)
    ap.add_argument("--phase-points", type=int, default=129)
    ap.add_argument("--max-subdivision-depth", type=int, default=18)

    ap.add_argument(
        "--offset-spread-gate",
        type=float,
        default=0.05,
        help="Successful phase-window averages must agree within this relative spread.",
    )
    ap.add_argument(
        "--phase-grid-gate",
        type=float,
        default=0.05,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_phase_shifted_missing_points_v194",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    mod = importlib.import_module(args.v192_module)

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )
    base = pd.read_csv(args.baseline_profile)
    critical = pd.read_csv(args.critical_profile)

    j = args.switch_index-1
    left = hull.iloc[j]
    right = hull.iloc[j+1]

    c1 = mod.match_candidate(
        cand, left["beta_active"], left["gamma_active"]
    )
    c2 = mod.match_candidate(
        cand, right["beta_active"], right["gamma_active"]
    )

    b1 = mp.mpf(str(float(c1["beta"])))
    g1 = mp.mpf(str(float(c1["gamma"])))
    b2 = mp.mpf(str(float(c2["beta"])))
    g2 = mp.mpf(str(float(c2["gamma"])))

    ts = mp.mpf(str(float(left["tau_end"])))
    da = abs(b2-b1)
    dg = abs(g2-g1)
    period = 2*mp.pi/dg

    phase = mod.TwoLayerPhase(b1, g1, b2, g2)

    xs = [
        mp.mpf(x.strip())
        for x in args.x_values.split(",")
        if x.strip()
    ]
    offsets = [
        float(x.strip())
        for x in args.phase_offsets.split(",")
        if x.strip()
    ]

    print("="*188)
    print("ROT-RH v194 — PHASE-SHIFTED MISSING-POINT RESOLUTION")
    print("="*188)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switch                            : {args.switch_index}")
    print(f"x targets                         : {[float(x) for x in xs]}")
    print(f"phase offsets                     : {offsets}")
    print(f"phase points / cycle              : {args.phase_points}")
    print(f"max subdivision depth             : {args.max_subdivision_depth}")
    print("="*188)

    all_rows = []
    resolved_rows = []
    unresolved = []

    for x in xs:
        tau = ts+x/da
        ga = g1 if x < 0 else g2
        center = ga

        vals = []

        for off in offsets:
            rr = cycle_average_shifted(
                mod, phase, tau, center, ga, period,
                args.phase_points, tol, frac,
                args.newton_iters, args.search_cells,
                args.branch_count, args.max_subdivision_depth,
                off
            )

            good = [r for r in rr if r.get("ok")]

            if not good:
                all_rows.append({
                    "x": float(x),
                    "offset": off,
                    "ok": False,
                })
                print(
                    f"x={float(x):7.3f} offset={off:5.3f} FAIL"
                )
                continue

            r = good[0]
            v = float(r["mean_abs_epsilon_over_gamma"])
            vmix = float(r["mean_abs_mix_over_gamma"])
            v2 = float(r["phase_stride2_over_gamma"])
            pdiff = abs(v2-v)/max(abs(v), 1e-300)

            vals.append(v)

            all_rows.append({
                "x": float(x),
                "offset": off,
                "ok": True,
                "mean_abs_epsilon_over_gamma": v,
                "mean_abs_mix_over_gamma": vmix,
                "phase_stride2_relative_difference": pdiff,
                "max_identity_resid": float(r["max_identity_resid"]),
                "max_depth": int(r["max_depth"]),
                "max_projection": float(r["max_proj"]),
            })

            print(
                f"x={float(x):7.3f} "
                f"offset={off:5.3f} "
                f"<|eps|>/g={v:.8e} "
                f"phaseDiff={pdiff:.3e}"
            )

        good_df = pd.DataFrame([
            r for r in all_rows
            if r["x"] == float(x) and r.get("ok")
        ])

        if len(good_df) == 0:
            unresolved.append(float(x))
            continue

        arr = good_df["mean_abs_epsilon_over_gamma"].to_numpy(float)
        mean = float(np.mean(arr))
        spread = (
            float((np.max(arr)-np.min(arr))/max(abs(mean),1e-300))
            if len(arr) > 1 else 0.0
        )
        max_phase_diff = float(
            good_df["phase_stride2_relative_difference"].max()
        )

        accepted = bool(
            spread <= args.offset_spread_gate
            and max_phase_diff <= args.phase_grid_gate
        )

        if not accepted:
            unresolved.append(float(x))

        resolved_rows.append({
            "x": float(x),
            "tau": float(tau),
            "gamma_active": float(ga),
            "branches_completed": 1,
            "successful_phase_offsets": len(good_df),
            "mean_abs_epsilon_over_gamma": mean,
            "mean_abs_mix_over_gamma": float(
                good_df["mean_abs_mix_over_gamma"].mean()
            ),
            "phase_offset_relative_spread": spread,
            "phase_stride2_relative_difference": max_phase_diff,
            "accepted": accepted,
        })

        print(
            f"  => x={float(x):7.3f} "
            f"mean={mean:.8e} "
            f"offsetSpread={spread:.3e} "
            f"maxPhaseDiff={max_phase_diff:.3e} "
            f"accepted={accepted}"
        )

    attempts = pd.DataFrame(all_rows)
    resolved = pd.DataFrame(resolved_rows)

    attempts.to_csv(args.prefix+"_ATTEMPTS.csv", index=False)
    resolved.to_csv(args.prefix+"_RESOLVED.csv", index=False)

    accepted = resolved[resolved["accepted"]].copy()

    # Merge: baseline tails + v193 critical profile + v194 accepted missing points.
    if len(accepted):
        critical2 = pd.concat(
            [critical, accepted],
            ignore_index=True,
        ).sort_values("x").drop_duplicates("x", keep="last")

        xmin = float(critical2["x"].min())
        xmax = float(critical2["x"].max())

        outside = base[
            (base["x"] < xmin-1e-12)
            | (base["x"] > xmax+1e-12)
        ].copy()

        merged = pd.concat(
            [outside, critical2],
            ignore_index=True,
        ).sort_values("x").drop_duplicates("x", keep="last")

        merged.to_csv(args.prefix+"_MERGED_PROFILE.csv", index=False)
        merged_ratio = profile_integral(merged)
    else:
        merged = None
        merged_ratio = np.nan

    all_resolved = len(unresolved) == 0

    if all_resolved:
        verdict = "MISSING_CRITICAL_POINTS_RESOLVED"
    elif len(accepted):
        verdict = "MISSING_CRITICAL_POINTS_PARTIALLY_RESOLVED"
    else:
        verdict = "MISSING_CRITICAL_POINTS_UNRESOLVED"

    summary = {
        "version": 194,
        "switch": args.switch_index,
        "x_targets": [float(x) for x in xs],
        "phase_offsets": offsets,
        "accepted_points": (
            accepted["x"].tolist() if len(accepted) else []
        ),
        "unresolved_points": unresolved,
        "merged_homogenized_absolute_epsilon_over_active": merged_ratio,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*188)
    if np.isfinite(merged_ratio):
        print(
            f"merged homogenized |eps| / active : "
            f"{merged_ratio:.12e}"
        )
    print(f"accepted x                         : {summary['accepted_points']}")
    print(f"unresolved x                       : {unresolved}")
    print(f"VERDICT                            : {verdict}")
    print("="*188)


if __name__ == "__main__":
    main()
