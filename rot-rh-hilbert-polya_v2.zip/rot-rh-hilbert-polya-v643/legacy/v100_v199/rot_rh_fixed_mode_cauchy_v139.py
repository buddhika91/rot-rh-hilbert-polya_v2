#!/usr/bin/env python3
"""
ROT-RH v139 — FIXED-MODE CAUCHY-DIAMETER AUDIT

Zero-cost postprocessor:
  * no root solving
  * no prime sums
  * no Xi / zeta / known-zero data

Merges:
  - v132 full roots through L=128000
  - v137 endpoint at L=256000
  - v138 endpoint at L=512000

For lambda_k(L)=E_k(L)^(-2), tests fixed-mode convergence using:
  1. successive dyadic increments,
  2. equal-width sliding Cauchy diameters,
  3. aggregate low-mode Cauchy diameters,
  4. fraction of modes whose latest increment contracted.

A shrinking sliding diameter is more appropriate than forcing a single
power-law exponent when the cutoff flow is oscillatory.

Outputs:
  <prefix>_MODES.csv
  <prefix>_WINDOWS.csv
  <prefix>_INCREMENTS.csv
  <prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def local_p(prev, new):
    if prev <= 0 or new <= 0:
        return np.nan
    return float(-math.log(new / prev, 2.0))


def load_endpoint(path):
    z = np.load(path)
    L = int(np.asarray(z["L_new"]).reshape(-1)[0])
    if "lambda_new" in z:
        lam = np.asarray(z["lambda_new"], float)
    else:
        lam = 1.0 / np.asarray(z["roots_new"], float) ** 2
    return L, lam


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--endpoint-256",
        default="rot_rh_low_mode_endpoint_v137_ENDPOINT.npz",
    )
    ap.add_argument(
        "--endpoint-512",
        default="rot_rh_low_mode_endpoint_v138_ENDPOINT.npz",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--low-mode-end", type=int, default=16)
    ap.add_argument("--focus-modes", default="9,10,13,14")
    ap.add_argument("--window", type=int, default=3)
    ap.add_argument("--diameter-ratio-gate", type=float, default=0.90)
    ap.add_argument("--latest-increment-ratio-gate", type=float, default=0.95)
    ap.add_argument(
        "--prefix",
        default="rot_rh_fixed_mode_cauchy_v139",
    )
    args = ap.parse_args()

    focus = [int(x.strip()) for x in args.focus_modes.split(",") if x.strip()]

    z = np.load(args.base_roots_npz)
    Lbase = np.asarray(z["L"], int)
    if "lambda_vals" in z:
        Mbase = np.asarray(z["lambda_vals"], float)
    else:
        Mbase = 1.0 / np.asarray(z["roots"], float) ** 2

    L256, lam256 = load_endpoint(args.endpoint_256)
    L512, lam512 = load_endpoint(args.endpoint_512)

    n = min(args.modes, Mbase.shape[1], len(lam256), len(lam512))
    low = min(args.low_mode_end, n)

    # Use the clean dyadic history from 32000 onward.
    wanted = [32000, 64000, 128000]
    rows = []
    for L in wanted:
        hit = np.where(Lbase == L)[0]
        if not len(hit):
            raise RuntimeError(f"Missing L={L} in base roots NPZ.")
        rows.append(Mbase[int(hit[0]), :n])

    Ls = np.array(wanted + [L256, L512], int)
    M = np.vstack(rows + [lam256[:n], lam512[:n]])

    order = np.argsort(Ls)
    Ls = Ls[order]
    M = M[order]

    print("=" * 122)
    print("ROT-RH v139 — FIXED-MODE CAUCHY-DIAMETER AUDIT")
    print("=" * 122)
    print("Xi / zeta / known zeros          : NONE")
    print(f"dyadic L history                  : {Ls.tolist()}")
    print(f"modes                             : 1..{n}")
    print(f"low-mode block                    : 1..{low}")
    print(f"sliding window                    : {args.window} endpoints")
    print("=" * 122)

    # Successive increments
    d = np.diff(M, axis=0)
    ad = np.abs(d)

    increment_rows = []
    for i in range(len(Ls) - 1):
        increment_rows.append(dict(
            L_a=int(Ls[i]),
            L_b=int(Ls[i+1]),
            trace_1_16=float(np.sum(ad[i, :low])),
            trace_1_N=float(np.sum(ad[i, :])),
            focus_trace=float(np.sum(ad[i, [k-1 for k in focus if 1 <= k <= n]])),
        ))
    write_csv(Path(args.prefix + "_INCREMENTS.csv"), increment_rows)

    # Per-mode latest contraction and sliding diameters
    mode_rows = []
    for k in range(n):
        vals = M[:, k]
        inc = ad[:, k]
        latest_ratio = (
            float(inc[-1] / inc[-2]) if inc[-2] > 0 else np.nan
        )

        if len(vals) >= 2 * args.window - 1:
            old_win = vals[-(2 * args.window - 1):-(args.window - 1)]
            new_win = vals[-args.window:]
        else:
            old_win = vals[:args.window]
            new_win = vals[-args.window:]

        old_diam = float(np.max(old_win) - np.min(old_win))
        new_diam = float(np.max(new_win) - np.min(new_win))
        diam_ratio = (
            new_diam / old_diam if old_diam > 0 else np.nan
        )

        mode_rows.append(dict(
            k=k+1,
            latest_abs_increment=float(inc[-1]),
            previous_abs_increment=float(inc[-2]),
            latest_increment_ratio=latest_ratio,
            latest_local_p=local_p(float(inc[-2]), float(inc[-1])),
            old_window_diameter=old_diam,
            new_window_diameter=new_diam,
            diameter_ratio=diam_ratio,
            latest_sign_flip=int(
                d[-1, k] != 0 and d[-2, k] != 0
                and np.sign(d[-1, k]) != np.sign(d[-2, k])
            ),
        ))
    write_csv(Path(args.prefix + "_MODES.csv"), mode_rows)

    # Sliding aggregate Cauchy diameters:
    # sum over modes of range(lambda_k) inside an equal-width L window.
    window_rows = []
    w = args.window
    for start in range(0, len(Ls) - w + 1):
        sl = M[start:start+w, :]
        diam = np.max(sl, axis=0) - np.min(sl, axis=0)
        window_rows.append(dict(
            window_start_L=int(Ls[start]),
            window_end_L=int(Ls[start+w-1]),
            endpoints=w,
            diameter_1_16=float(np.sum(diam[:low])),
            diameter_1_N=float(np.sum(diam)),
            focus_diameter=float(np.sum(diam[[k-1 for k in focus if 1 <= k <= n]])),
        ))
    write_csv(Path(args.prefix + "_WINDOWS.csv"), window_rows)

    old = window_rows[-2]
    new = window_rows[-1]

    low_diam_ratio = (
        new["diameter_1_16"] / old["diameter_1_16"]
        if old["diameter_1_16"] > 0 else np.nan
    )
    all_diam_ratio = (
        new["diameter_1_N"] / old["diameter_1_N"]
        if old["diameter_1_N"] > 0 else np.nan
    )
    focus_diam_ratio = (
        new["focus_diameter"] / old["focus_diameter"]
        if old["focus_diameter"] > 0 else np.nan
    )

    low_modes = mode_rows[:low]
    frac_latest_contract = float(np.mean([
        np.isfinite(r["latest_increment_ratio"])
        and r["latest_increment_ratio"] < args.latest_increment_ratio_gate
        for r in low_modes
    ]))
    frac_diam_contract = float(np.mean([
        np.isfinite(r["diameter_ratio"])
        and r["diameter_ratio"] < args.diameter_ratio_gate
        for r in low_modes
    ]))

    if (
        low_diam_ratio < args.diameter_ratio_gate
        and frac_latest_contract >= 0.75
    ):
        verdict = "FIXED_MODE_CAUCHY_EVIDENCE_STRENGTHENED"
    elif low_diam_ratio < 1.0:
        verdict = "TAIL_DIAMETER_SHRINKS_BUT_NOT_YET_STRONG"
    else:
        verdict = "FIXED_MODE_CAUCHY_STILL_UNRESOLVED"

    summary = dict(
        version=139,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        L_history=Ls.tolist(),
        modes=n,
        low_mode_end=low,
        window=w,
        latest_increment_ratios=dict(
            low_1_16=(
                increment_rows[-1]["trace_1_16"]
                / increment_rows[-2]["trace_1_16"]
            ),
            all_tested=(
                increment_rows[-1]["trace_1_N"]
                / increment_rows[-2]["trace_1_N"]
            ),
            focus=(
                increment_rows[-1]["focus_trace"]
                / increment_rows[-2]["focus_trace"]
            ),
        ),
        sliding_diameter_ratios=dict(
            low_1_16=low_diam_ratio,
            all_tested=all_diam_ratio,
            focus=focus_diam_ratio,
        ),
        fractions=dict(
            low_modes_latest_increment_contracting=frac_latest_contract,
            low_modes_sliding_diameter_contracting=frac_diam_contract,
        ),
        verdict=verdict,
        proof_status="NUMERICAL ONLY — fixed-k convergence still requires analytic proof.",
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("Dyadic low-mode trace increments")
    print("-" * 122)
    for r in increment_rows:
        print(
            f"{r['L_a']:>7d}->{r['L_b']:<7d}  "
            f"T_1:16={r['trace_1_16']:.6e}  "
            f"T_1:{n}={r['trace_1_N']:.6e}  "
            f"T_focus={r['focus_trace']:.6e}"
        )

    print()
    print("Sliding Cauchy diameters")
    print("-" * 122)
    for r in window_rows:
        print(
            f"{r['window_start_L']:>7d}->{r['window_end_L']:<7d}  "
            f"D_1:16={r['diameter_1_16']:.6e}  "
            f"D_1:{n}={r['diameter_1_N']:.6e}  "
            f"D_focus={r['focus_diameter']:.6e}"
        )

    print()
    print("=" * 122)
    print(f"latest increment ratio, modes 1..16      : {summary['latest_increment_ratios']['low_1_16']:.9f}")
    print(f"latest increment ratio, modes 1..{n}      : {summary['latest_increment_ratios']['all_tested']:.9f}")
    print(f"latest increment ratio, focus            : {summary['latest_increment_ratios']['focus']:.9f}")
    print()
    print(f"latest sliding-diameter ratio, 1..16     : {low_diam_ratio:.9f}")
    print(f"latest sliding-diameter ratio, 1..{n}     : {all_diam_ratio:.9f}")
    print(f"latest sliding-diameter ratio, focus     : {focus_diam_ratio:.9f}")
    print()
    print(f"fraction low modes with latest contraction: {frac_latest_contract:.3f}")
    print(f"fraction low modes with diameter shrink  : {frac_diam_contract:.3f}")
    print(f"VERDICT                                  : {verdict}")
    print("=" * 122)


if __name__ == "__main__":
    main()
