#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v124 — Exact Mangoldt Kernel / Dyadic Arithmetic-Scale Decomposition
============================================================================

PURPOSE
-------
v123 preregistered PASS established on fresh cells k=1088..1407 that

    q_total ~= q_prime

and that the ordering of q_prime has strongly suppressed cumulative and
low-frequency power, with mesoscopic block suppression at scales 16--64.

v124 is theorem-facing. It asks whether prime self-cancellation is:

  A) already present INSIDE dyadic arithmetic bands n in [2^j,2^(j+1)), or
  B) produced mainly by cancellation BETWEEN different arithmetic scales.

EXACT PRIME CELL KERNEL
-----------------------
For a single arithmetic frequency omega=log n with phase coefficient w_n,

    F_n(E) = -(w_n/pi) sin(omega E).

On spectral cell [E_k,E_{k+1}], define

    m_k     = (E_k+E_{k+1})/2,
    h_k     = E_{k+1}-E_k,
    delta   = omega h_k / 2.

Its adaptive trapezoid defect is EXACTLY

    q_{k,n}
      = (2 w_n/(pi omega))
        sin(omega m_k)
        [delta cos(delta) - sin(delta)].

Thus

    q_k^prime = sum_n q_{k,n}.

No quadrature is used for the kernel decomposition.

AUDITS
------
* exact reconstruction against v123 q_prime;
* dyadic n-band sequences;
* cumulative max / low-frequency power per band;
* permutation controls within each band (post-hoc);
* leave-one-band-out sensitivity;
* cross-band cumulative cancellation ratio;
* first low-frequency DFT bins resolved by arithmetic band.

This is a post-hoc analytic-mechanism audit, not a new preregistered test.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v124"
BUILD = "2026-08-18-exact-mangoldt-kernel-dyadic-scale-v124"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c) - np.min(c))


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p)-1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def corr(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x*x)))


def permutation_metrics(x, nperm, rng, lowfreq_bins):
    x = np.asarray(x, float)
    real_c = cumulative_max(x)
    real_l = lowfreq_fraction(x, lowfreq_bins)

    pc = np.empty(int(nperm), float)
    pl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        y = rng.permutation(x)
        pc[t] = cumulative_max(y)
        pl[t] = lowfreq_fraction(y, lowfreq_bins)

    return {
        "real_cumulative_max": real_c,
        "real_lowfreq_fraction": real_l,
        "perm_cumulative_mean": float(np.mean(pc)),
        "cumulative_lower_tail_percentile": percentile_le(pc, real_c),
        "lowfreq_lower_tail_percentile": percentile_le(pl, real_l),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v123-prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--k-start", type=int, default=1088)
    ap.add_argument("--k-end", type=int, default=1407)
    ap.add_argument("--term-chunk", type=int, default=2048)
    ap.add_argument("--permutations", type=int, default=5000)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260818)
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_mangoldt_kernel_bands_v124",
    )
    args = ap.parse_args()

    cells_path = Path(
        str(Path(args.v123_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rows = sorted(
        [
            r for r in raw
            if args.k_start <= int(float(r["k"])) <= args.k_end
        ],
        key=lambda r: int(float(r["k"])),
    )
    if len(rows) != args.k_end - args.k_start + 1:
        raise RuntimeError("Requested v123 cell range is incomplete.")

    ks = np.asarray([int(float(r["k"])) for r in rows], int)
    lo = np.asarray([float(r["lo"]) for r in rows], float)
    hi = np.asarray([float(r["hi"]) for r in rows], float)
    h = hi - lo
    mid = 0.5 * (lo + hi)
    qprime_ref = np.asarray([float(r["q_prime"]) for r in rows], float)

    print("=" * 158)
    print("ROT-RH v124 — EXACT MANGOLDT KERNEL / DYADIC ARITHMETIC-SCALE DECOMPOSITION")
    print("=" * 158)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("cell count                      :", len(rows))
    print("L                               :", args.L)
    print("permutations/band               :", args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 158)

    print("[1] Build finite-L arithmetic coefficients", flush=True)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )

    w = np.asarray(phase.phase_w, float)
    omega = np.asarray(phase.logs, float)
    if len(w) != len(omega):
        raise RuntimeError("phase_w/logs length mismatch.")

    # Dyadic index j means n in [2^j,2^(j+1)).
    # Since omega=log n, j=floor(log n/log 2).
    jband = np.floor(omega / math.log(2.0) + 1e-12).astype(int)
    bands = sorted(np.unique(jband).tolist())

    print("  arithmetic terms              :", len(omega))
    print("  dyadic bands                  :", len(bands))
    print("  band exponents                :", bands)

    qbands = {j: np.zeros(len(rows), float) for j in bands}

    print("[2] Exact kernel accumulation by dyadic n-band", flush=True)
    nterm = len(omega)
    for s in range(0, nterm, int(args.term_chunk)):
        e = min(nterm, s + int(args.term_chunk))
        om = omega[s:e]
        ww = w[s:e]
        jb = jband[s:e]

        # shape: cells x terms
        delta = 0.5 * h[:, None] * om[None, :]
        phase_mid = mid[:, None] * om[None, :]

        kernel = (
            (2.0 / math.pi)
            * np.sin(phase_mid)
            * (delta * np.cos(delta) - np.sin(delta))
        )
        contrib = kernel * (ww / om)[None, :]

        for j in np.unique(jb):
            mask = (jb == j)
            qbands[int(j)] += np.sum(contrib[:, mask], axis=1)

        if e == nterm or e % (8 * int(args.term_chunk)) == 0:
            print(f"  terms {e}/{nterm}", flush=True)

    qrecon = np.sum(np.vstack([qbands[j] for j in bands]), axis=0)
    recon_rel = float(
        np.linalg.norm(qrecon - qprime_ref)
        / max(np.linalg.norm(qprime_ref), EPS)
    )
    recon_max = float(np.max(np.abs(qrecon - qprime_ref)))

    print("[3] Exact reconstruction")
    print("  prime reconstruction relL2     :", f"{recon_rel:.12e}")
    print("  prime reconstruction max abs   :", f"{recon_max:.12e}")
    print("  corr(reconstructed,reference)   :", f"{corr(qrecon,qprime_ref):.12e}")

    rng = np.random.default_rng(args.seed)

    print("[4] Bandwise self-cancellation diagnostics")
    band_rows = []
    band_energy_sq_total = sum(
        float(np.dot(qbands[j], qbands[j])) for j in bands
    )
    special_energy_sq = 0.0

    total_cmax = cumulative_max(qprime_ref)
    sum_band_cmax = 0.0

    for j in bands:
        x = qbands[j]
        pm = permutation_metrics(
            x, args.permutations, rng, args.lowfreq_bins
        )
        cmax = pm["real_cumulative_max"]
        sum_band_cmax += cmax

        e2 = float(np.dot(x, x))
        self_special = (
            pm["cumulative_lower_tail_percentile"] <= 0.05
            and pm["lowfreq_lower_tail_percentile"] <= 0.05
        )
        if self_special:
            special_energy_sq += e2

        nlo = 2 ** j
        nhi = 2 ** (j + 1)
        loo = qprime_ref - x

        row = {
            "band_j": j,
            "n_lo": nlo,
            "n_hi_exclusive": nhi,
            "term_count": int(np.sum(jband == j)),
            "cell_rms": rms(x),
            "cell_l2_fraction_of_band_sum":
                e2 / max(band_energy_sq_total, EPS),
            "corr_with_total_prime": corr(x, qprime_ref),
            "cumulative_max": cmax,
            "lowfreq_fraction": pm["real_lowfreq_fraction"],
            "perm_cumulative_mean": pm["perm_cumulative_mean"],
            "cumulative_lower_tail_percentile":
                pm["cumulative_lower_tail_percentile"],
            "lowfreq_lower_tail_percentile":
                pm["lowfreq_lower_tail_percentile"],
            "self_cancellation_special_5pct": bool(self_special),
            "leave_one_out_cumulative_max": cumulative_max(loo),
            "leave_one_out_over_total_cmax":
                cumulative_max(loo) / max(total_cmax, EPS),
        }
        band_rows.append(row)

        print(
            f"  2^{j:<2d}..2^{j+1:<2d}: "
            f"terms={row['term_count']:<5d} "
            f"rms={row['cell_rms']:.3e} "
            f"corr={row['corr_with_total_prime']:+.3f} "
            f"cum={cmax:.3e} "
            f"pCum={100*row['cumulative_lower_tail_percentile']:.2f}% "
            f"pLowF={100*row['lowfreq_lower_tail_percentile']:.2f}%"
        )

    cross_band_ratio = (
        total_cmax / max(sum_band_cmax, EPS)
    )
    special_energy_fraction = (
        special_energy_sq / max(band_energy_sq_total, EPS)
    )

    print("[5] Cross-band cancellation")
    print("  total prime cumulative max     :", f"{total_cmax:.12e}")
    print("  sum individual band cumMax     :", f"{sum_band_cmax:.12e}")
    print("  cross-band cumulative ratio    :", f"{cross_band_ratio:.12e}")
    print("  energy fraction in bands with")
    print("    both permutation p<=5%       :", f"{special_energy_fraction:.12e}")

    print("[6] First low-frequency DFT bins resolved by arithmetic scale")
    # Remove each band's own mean; DC is not part of this analysis.
    Bfft = {
        j: np.fft.rfft(qbands[j] - np.mean(qbands[j]))
        for j in bands
    }
    Tfft = np.fft.rfft(qprime_ref - np.mean(qprime_ref))

    freq_rows = []
    maxbin = min(args.lowfreq_bins, len(Tfft)-1)

    for fb in range(1, maxbin+1):
        total_amp = abs(Tfft[fb])
        sum_amp = sum(abs(Bfft[j][fb]) for j in bands)
        band_cancel_ratio = total_amp / max(sum_amp, EPS)

        # Rank bands by amplitude in this spectral-frequency bin.
        ranked = sorted(
            bands,
            key=lambda j: abs(Bfft[j][fb]),
            reverse=True,
        )
        top = ranked[:5]

        row = {
            "frequency_bin": fb,
            "total_prime_amplitude": float(total_amp),
            "sum_band_amplitudes": float(sum_amp),
            "cross_band_cancellation_ratio": float(band_cancel_ratio),
            "top_band_1": int(top[0]) if len(top) > 0 else None,
            "top_band_1_amp": float(abs(Bfft[top[0]][fb])) if len(top) > 0 else None,
            "top_band_2": int(top[1]) if len(top) > 1 else None,
            "top_band_2_amp": float(abs(Bfft[top[1]][fb])) if len(top) > 1 else None,
            "top_band_3": int(top[2]) if len(top) > 2 else None,
            "top_band_3_amp": float(abs(Bfft[top[2]][fb])) if len(top) > 2 else None,
        }
        freq_rows.append(row)

        top_txt = ", ".join(
            f"2^{j}[{abs(Bfft[j][fb]):.2e}]"
            for j in top[:3]
        )
        print(
            f"  bin {fb:>2d}: "
            f"crossBandCancel={band_cancel_ratio:.3e} "
            f"top={top_txt}"
        )

    # Conservative mechanism description, not a proof verdict.
    if special_energy_fraction >= 0.50 and cross_band_ratio >= 0.25:
        mechanism = "BANDWISE_PRIME_SELF_CANCELLATION_DOMINATES"
    elif cross_band_ratio <= 0.15:
        mechanism = "CROSS_BAND_ARITHMETIC_SCALE_CANCELLATION_IS_ESSENTIAL"
    else:
        mechanism = "MIXED_BANDWISE_AND_CROSS_BAND_PRIME_CANCELLATION"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_BANDS.csv"), band_rows)
    write_csv(Path(str(prefix) + "_FREQUENCIES.csv"), freq_rows)

    cell_rows = []
    for idx, k in enumerate(ks):
        row = {
            "k": int(k),
            "q_prime_reference": qprime_ref[idx],
            "q_prime_reconstructed": qrecon[idx],
            "reconstruction_error": qrecon[idx] - qprime_ref[idx],
        }
        for j in bands:
            row[f"q_band_2pow{j}"] = qbands[j][idx]
        cell_rows.append(row)
    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V124_EXACT_MANGOLDT_KERNEL_DECOMPOSITION_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "prime_reconstruction_rel_l2": recon_rel,
        "prime_reconstruction_max_abs": recon_max,
        "total_prime_cumulative_max": total_cmax,
        "sum_band_cumulative_max": sum_band_cmax,
        "cross_band_cumulative_ratio": cross_band_ratio,
        "special_band_energy_fraction": special_energy_fraction,
        "band_rows": band_rows,
        "frequency_rows": freq_rows,
        "interpretation": (
            "If most prime energy lies in dyadic bands whose own ordering is "
            "already permutation-anomalous, the analytic target can be reduced "
            "to uniform exponential-sum bounds band by band. If instead the "
            "total cumulative defect is small mainly because different dyadic "
            "bands cancel each other, the theorem must preserve cross-scale "
            "Mangoldt structure and cannot bound bands independently."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("FINAL v124 VERDICT")
    print("=" * 158)
    print("verdict                         : PASS_V124_EXACT_MANGOLDT_KERNEL_DECOMPOSITION_COMPLETE")
    print("mechanism                       :", mechanism)
    print("prime reconstruction relL2      :", f"{recon_rel:.12e}")
    print("cross-band cumulative ratio     :", f"{cross_band_ratio:.12e}")
    print("special-band energy fraction    :", f"{special_energy_fraction:.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 158)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
