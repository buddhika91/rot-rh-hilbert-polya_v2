#!/usr/bin/env python3
"""
ROT-RH v144 — UNIFORM WEYL MAJORANT / TRACE-TAIL CERTIFICATE AUDIT

Goal
----
Attack the high-k analytic half of cutoff independence.

We seek ONE cutoff-independent counting bound of the form

    F_L(E) <= A + B * E * log(E + e)                      (1)

for all sufficiently large cutoffs L and all E >= 0.

At a spectral crossing

    F_L(E_k(L)) = k - 1/2,

(1) implies, for sufficiently large k,

    E_k(L) >= c * k / log(k + e),       c = 1/(2B),       (2)

by a simple two-case argument:
  * if E_k >= k, (2) is automatic once log(k+e) >= c;
  * if E_k < k, then log(E_k+e) <= log(k+e), and
        k-1/2-A <= B E_k log(k+e).
    Once k-1/2-A >= k/2, (2) follows.

Then

    lambda_k(L) = E_k(L)^(-2)
      <= c^(-2) * log(k+e)^2 / k^2,                       (3)

and the right-hand side is summable.

This script:
  * builds F_L for an interlaced cutoff net,
  * searches/test multiple candidate B values,
  * computes the smallest sampled A required by each B,
  * adds an explicit safety margin,
  * derives c and k0,
  * checks the resulting spectral lower bound against available roots,
  * prints conservative infinite trace-tail bounds from (3).

NO Xi, zeta, or known-zero data are used.

IMPORTANT
---------
This is a theorem-target / numerical certificate audit, NOT an infinite proof.
To make the result rigorous, one must analytically prove (1) for all
E >= 0 and all L >= L0 (or prove an equivalent asymptotic remainder bound).

Outputs
-------
<prefix>_B_CANDIDATES.csv
<prefix>_L_SUMMARY.csv
<prefix>_MAXIMA.csv
<prefix>_ROOT_CHECK.csv
<prefix>_TAIL_BOUNDS.csv
<prefix>_SAMPLES.npz
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


# ----------------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------------

def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def csv_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def write_csv(path, rows):
    path = Path(path)
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def vector_call(fn, x):
    x = np.asarray(x, dtype=float)

    try:
        y = np.asarray(fn(x), dtype=float)
        if y.shape == x.shape:
            return y
        if y.size == x.size:
            return y.reshape(x.shape)
    except Exception:
        pass

    out = np.empty_like(x)
    for i, xx in enumerate(x):
        try:
            yy = fn(float(xx))
        except Exception:
            yy = fn(np.array([float(xx)], dtype=float))
        a = np.asarray(yy, dtype=float).reshape(-1)
        if len(a) == 0:
            raise RuntimeError("Empty upstream phase output.")
        out[i] = float(a[0])
    return out


def hfun(E):
    E = np.asarray(E, dtype=float)
    return E * np.log(E + math.e)


def build_initial_grid(Emax, linear_end, linear_points, log_points):
    if Emax <= 0:
        raise RuntimeError("Emax must be positive.")

    le = min(float(linear_end), float(Emax))

    g1 = np.linspace(0.0, le, max(3, int(linear_points)))

    if Emax > le:
        lo = max(le, 1e-6)
        g2 = np.geomspace(lo, float(Emax), max(3, int(log_points)))
        grid = np.unique(np.concatenate([g1, g2]))
    else:
        grid = np.unique(g1)

    return grid


def evaluate_phases(phases, Ls, grid):
    F = {}
    for L in Ls:
        F[L] = vector_call(phases[L].F, grid)
    return F


def adaptive_refine(phases, Ls, grid, B_values, rounds, refine_intervals):
    F = evaluate_phases(phases, Ls, grid)

    for r in range(rounds):
        # Score intervals by how close they come to producing a larger
        # required A = sup(F - B h), across all B and L.
        h = hfun(grid)
        score = np.zeros(len(grid) - 1, dtype=float)

        for B in B_values:
            for L in Ls:
                q = F[L] - B * h
                local = np.maximum(q[:-1], q[1:])
                jump = np.abs(q[1:] - q[:-1])
                # Favor intervals with high current q and/or large local variation.
                score = np.maximum(score, local + 0.5 * jump)

        if len(score) == 0:
            break

        m = min(int(refine_intervals), len(score))
        idx = np.argpartition(score, -m)[-m:]
        mids = 0.5 * (grid[idx] + grid[idx + 1])

        new_grid = np.unique(np.concatenate([grid, mids]))
        if len(new_grid) == len(grid):
            break

        grid = new_grid
        F = evaluate_phases(phases, Ls, grid)

        print(
            f"[adaptive] round {r+1}/{rounds}: "
            f"grid points={len(grid)}, refined={m}"
        )

    return grid, F


def derive_k0(A, B):
    """
    If F <= A + B E log(E+e), then c=1/(2B).

    Need:
      k - 1/2 - A >= k/2   => k >= 2A + 1
    and
      log(k+e) >= c
    for the E>=k case to imply E >= c k/log(k+e).
    """
    c = 1.0 / (2.0 * B)
    kA = max(1, int(math.ceil(2.0 * A + 1.0)))
    klog = max(1, int(math.ceil(math.exp(c) - math.e)))
    return c, max(kA, klog), kA, klog


def tail_bound(N, c):
    """
    Conservative bound for
      sum_{k>N} c^{-2} log(k+e)^2/k^2.

    For k>=3, k+e <= 2k, hence log(k+e) <= log(2k).
    Use first omitted term plus integral:
      int_N^inf log(2x)^2 / x^2 dx
       = [u^2 + 2u + 2]/N, u=log(2N).
    """
    N = max(int(N), 3)
    k = N + 1
    first = math.log(2.0 * k) ** 2 / (k * k)
    u = math.log(2.0 * N)
    integ = (u * u + 2.0 * u + 2.0) / N
    return (first + integ) / (c * c)


def load_root_sets(base_roots_npz, cutoff_net_npz, max_modes):
    sets = {}

    if base_roots_npz:
        p = Path(base_roots_npz)
        if p.exists():
            z = np.load(p)
            Ls = np.asarray(z["L"], int)
            R = np.asarray(z["roots"], float)
            for i, L in enumerate(Ls):
                sets[int(L)] = np.asarray(R[i, :max_modes], float)

    if cutoff_net_npz:
        p = Path(cutoff_net_npz)
        if p.exists():
            z = np.load(p)
            Ls = np.asarray(z["L"], int)
            R = np.asarray(z["roots"], float)
            for i, L in enumerate(Ls):
                # Let v143 override same-L roots for its supported depth.
                sets[int(L)] = np.asarray(R[i, :max_modes], float)

    return sets


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--L-list",
        default="128000,181019,256000,362039,512000",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--E-max", type=float, default=2400.0)
    ap.add_argument("--linear-end", type=float, default=160.0)
    ap.add_argument("--linear-points", type=int, default=161)
    ap.add_argument("--log-points", type=int, default=193)
    ap.add_argument("--adaptive-rounds", type=int, default=3)
    ap.add_argument("--refine-intervals", type=int, default=32)

    ap.add_argument(
        "--B-values",
        default="0.17,0.18,0.20,0.22,0.25,0.30,0.40,0.50",
        help="Candidate coefficients in F <= A + B E log(E+e).",
    )
    ap.add_argument(
        "--selected-B",
        type=float,
        default=0.25,
        help="The candidate B used for the explicit Weyl/tail certificate.",
    )
    ap.add_argument(
        "--A-safety",
        type=float,
        default=0.25,
        help="Additive numerical safety margin above sampled required A.",
    )

    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument("--root-check-max-modes", type=int, default=1408)

    ap.add_argument(
        "--tail-depths",
        default="64,128,256,512,1024,1408,2048,4096,8192",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_uniform_weyl_majorant_v144",
    )

    args = ap.parse_args()

    Ls = sorted(set(csv_ints(args.L_list)))
    B_values = sorted(set(csv_floats(args.B_values) + [args.selected_B]))
    tail_depths = csv_ints(args.tail_depths)

    if not Ls:
        raise RuntimeError("Empty L list.")
    if args.selected_B <= 0:
        raise RuntimeError("--selected-B must be positive.")

    print("=" * 132)
    print("ROT-RH v144 — UNIFORM WEYL MAJORANT / TRACE-TAIL CERTIFICATE AUDIT")
    print("=" * 132)
    print("Xi / zeta / known zeros          : NONE")
    print(f"cutoff net                        : {Ls}")
    print(f"E audit range                     : [0, {args.E_max}]")
    print(f"B candidates                      : {B_values}")
    print(f"selected B                        : {args.selected_B}")
    print(f"A safety margin                   : {args.A_safety}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 132)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warning_messages = {}

    for L in Ls:
        print(f"[L={L}] building RenormalizedPhase ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phases[L] = v102.RenormalizedPhase.build(
                base,
                int(L),
                float(args.tail_factor),
                int(args.counter_q),
            )
        warning_messages[L] = [str(w.message) for w in wrn]

        if warning_messages[L]:
            print(f"[L={L}] built with {len(warning_messages[L])} warning(s)")
            for msg in warning_messages[L][:2]:
                print(f"           warning: {msg}")
        else:
            print(f"[L={L}] built with no captured warnings")

    grid = build_initial_grid(
        Emax=args.E_max,
        linear_end=args.linear_end,
        linear_points=args.linear_points,
        log_points=args.log_points,
    )

    print(f"[sampling] initial grid points={len(grid)}", flush=True)

    grid, F = adaptive_refine(
        phases=phases,
        Ls=Ls,
        grid=grid,
        B_values=B_values,
        rounds=args.adaptive_rounds,
        refine_intervals=args.refine_intervals,
    )

    h = hfun(grid)

    # ------------------------------------------------------------------
    # Candidate B table
    # ------------------------------------------------------------------
    candidate_rows = []
    maxima_rows = []

    for B in B_values:
        global_A_req = -np.inf
        global_L = None
        global_E = None
        global_F = None

        by_L = {}

        for L in Ls:
            q = F[L] - B * h
            i = int(np.argmax(q))
            Areq = float(q[i])
            by_L[L] = Areq

            maxima_rows.append(dict(
                B=B,
                L=L,
                required_A=Areq,
                E_at_required_A=float(grid[i]),
                F_at_required_A=float(F[L][i]),
                h_at_required_A=float(h[i]),
            ))

            if Areq > global_A_req:
                global_A_req = Areq
                global_L = L
                global_E = float(grid[i])
                global_F = float(F[L][i])

        A_safe = max(0.0, global_A_req + args.A_safety)
        c, k0, kA, klog = derive_k0(A_safe, B)

        candidate_rows.append(dict(
            B=B,
            sampled_required_A=global_A_req,
            safe_A=A_safe,
            worst_L=global_L,
            worst_E=global_E,
            worst_F=global_F,
            derived_c= c,
            derived_k0=k0,
            k0_from_A=kA,
            k0_from_log_case=klog,
            empirical_A_spread=(
                max(by_L.values()) - min(by_L.values())
            ),
        ))

    write_csv(args.prefix + "_B_CANDIDATES.csv", candidate_rows)
    write_csv(args.prefix + "_MAXIMA.csv", maxima_rows)

    selected = min(
        candidate_rows,
        key=lambda r: abs(r["B"] - args.selected_B),
    )

    B = float(selected["B"])
    A = float(selected["safe_A"])
    c = float(selected["derived_c"])
    k0 = int(selected["derived_k0"])

    # ------------------------------------------------------------------
    # Per-L margins for the selected theorem candidate
    # ------------------------------------------------------------------
    L_rows = []

    for L in Ls:
        margin = A + B * h - F[L]
        i = int(np.argmin(margin))
        L_rows.append(dict(
            L=L,
            min_sampled_margin=float(margin[i]),
            E_at_min_margin=float(grid[i]),
            max_F=float(np.max(F[L])),
            min_F=float(np.min(F[L])),
            warnings=len(warning_messages[L]),
        ))

    write_csv(args.prefix + "_L_SUMMARY.csv", L_rows)

    sampled_bound_holds = bool(
        min(r["min_sampled_margin"] for r in L_rows) >= -1e-12
    )

    # ------------------------------------------------------------------
    # Check derived spectral lower bound against available roots
    # ------------------------------------------------------------------
    root_sets = load_root_sets(
        args.base_roots_npz,
        args.cutoff_net_npz,
        args.root_check_max_modes,
    )

    root_rows = []
    checked = 0
    failed = 0
    min_ratio = np.inf

    for L in sorted(root_sets):
        rr = root_sets[L]

        for j, E in enumerate(rr):
            k = j + 1
            if k < k0:
                continue

            lower = c * k / math.log(k + math.e)
            ratio = float(E / lower)

            checked += 1
            min_ratio = min(min_ratio, ratio)
            ok = E + 1e-12 >= lower
            failed += int(not ok)

            root_rows.append(dict(
                L=L,
                k=k,
                E=float(E),
                theorem_lower_bound=float(lower),
                E_over_lower_bound=ratio,
                pass_bound=int(ok),
            ))

    write_csv(args.prefix + "_ROOT_CHECK.csv", root_rows)

    # ------------------------------------------------------------------
    # Summable trace-tail majorant
    # ------------------------------------------------------------------
    tail_rows = []
    for N in tail_depths:
        tb = tail_bound(N, c)
        tail_rows.append(dict(
            N=N,
            c=c,
            upper_bound_sum_k_gt_N_lambda=tb,
            pairwise_trace_tail_bound=2.0 * tb,
        ))

    write_csv(args.prefix + "_TAIL_BOUNDS.csv", tail_rows)

    # Save sampled F
    np.savez_compressed(
        args.prefix + "_SAMPLES.npz",
        L=np.asarray(Ls, dtype=int),
        E=grid,
        F=np.vstack([F[L] for L in Ls]),
        B=np.array([B]),
        A=np.array([A]),
        c=np.array([c]),
        k0=np.array([k0], dtype=int),
    )

    # ------------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------------
    root_check_ok = bool(checked > 0 and failed == 0)

    if sampled_bound_holds and root_check_ok:
        verdict = "UNIFORM_WEYL_MAJORANT_STRONGLY_SUPPORTED_ON_AUDITED_DOMAIN"
    elif sampled_bound_holds:
        verdict = "COUNTING_BOUND_SUPPORTED_ROOT_THEOREM_CHECK_INCOMPLETE"
    else:
        verdict = "UNIFORM_WEYL_MAJORANT_CANDIDATE_FAILS_ON_SAMPLED_DOMAIN"

    summary = dict(
        version=144,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        candidate_theorem=dict(
            inequality=f"F_L(E) <= {A:.17g} + {B:.17g} E log(E+e)",
            audited_L=Ls,
            audited_E=[0.0, args.E_max],
            sampled_bound_holds=sampled_bound_holds,
            derived_spectral_bound=(
                f"E_k(L) >= {c:.17g} k/log(k+e) for k >= {k0}, "
                "provided the counting inequality is proved globally."
            ),
            c=c,
            k0=k0,
        ),
        root_check=dict(
            checked=checked,
            failed=failed,
            minimum_E_over_lower_bound=(
                float(min_ratio) if np.isfinite(min_ratio) else None
            ),
        ),
        warnings_by_L=warning_messages,
        verdict=verdict,
        proof_gap=(
            "The sampled inequality must be replaced by an analytic proof uniform "
            "in L and E. Once that is done, the displayed spectral bound and "
            "summable trace-tail majorant follow elementarily."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Terminal report
    # ------------------------------------------------------------------
    print()
    print("Candidate counting bounds")
    print("-" * 132)
    print(
        f"{'B':>8} {'A_required':>14} {'A_safe':>14} "
        f"{'worst L':>10} {'worst E':>12} {'c=1/(2B)':>12} {'k0':>8}"
    )
    for r in candidate_rows:
        print(
            f"{r['B']:8.4f} "
            f"{r['sampled_required_A']:14.6e} "
            f"{r['safe_A']:14.6e} "
            f"{r['worst_L']:10d} "
            f"{r['worst_E']:12.6f} "
            f"{r['derived_c']:12.6f} "
            f"{r['derived_k0']:8d}"
        )

    print()
    print("Selected uniform counting candidate")
    print("-" * 132)
    print(f"F_L(E) <= A + B E log(E+e)")
    print(f"A                                 : {A:.12e}")
    print(f"B                                 : {B:.12e}")
    print(f"minimum sampled margin            : {min(r['min_sampled_margin'] for r in L_rows):.6e}")
    print(f"derived c                         : {c:.12e}")
    print(f"derived k0                        : {k0}")
    print(f"root checks performed             : {checked}")
    print(f"root check failures               : {failed}")
    if checked:
        print(f"minimum E / theorem lower bound   : {min_ratio:.9f}")

    print()
    print("Conservative pairwise trace-tail bounds")
    print("-" * 132)
    for r in tail_rows:
        print(
            f"N={r['N']:>6d}  "
            f"single-tail <= {r['upper_bound_sum_k_gt_N_lambda']:.6e}  "
            f"pairwise tail <= {r['pairwise_trace_tail_bound']:.6e}"
        )

    print()
    print("=" * 132)
    print(f"SAMPLED COUNTING BOUND             : {sampled_bound_holds}")
    print(f"DERIVED ROOT BOUND ON AVAILABLE DATA: {root_check_ok}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 132)
    print("THEOREM GAP:")
    print("  Prove the selected F_L(E) upper bound analytically for all sufficiently")
    print("  large L and all E. Then the Weyl lower bound and summable trace-tail")
    print("  estimate printed above become rigorous consequences.")


if __name__ == "__main__":
    main()
