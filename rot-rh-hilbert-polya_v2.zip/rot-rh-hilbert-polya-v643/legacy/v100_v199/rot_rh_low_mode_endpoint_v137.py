#!/usr/bin/env python3
"""
ROT-RH v137 — FAST LOW-MODE ENDPOINT CONTINUATION TO A NEW CUTOFF

Purpose
-------
Attack the remaining fixed-mode convergence question without rebuilding
the full 1408-level operator.

Given an existing v132 ROOTS.npz containing L_prev roots (default 128000):

  1. Build the zero-blind renormalized phase at L_new (default 256000).
  2. Continue/refine only the first N low modes (default 32).
  3. Compare the new mode motion with the previous dyadic motions.
  4. Report whether the troublesome low-mode trace is contracting,
     flat, or expanding.
  5. Save the new low-mode endpoint for subsequent postprocessing.

No Xi, zeta, or known-zero data are used.

This is a fixed-mode convergence diagnostic, not a proof.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from scipy.optimize import brentq
except Exception:
    brentq = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Empty phase-function output.")
    return float(a[0])


def local_p(prev_abs, new_abs):
    if prev_abs <= 0 or new_abs <= 0:
        return np.nan
    return float(-math.log(new_abs / prev_abs, 2.0))


def refine_root(phase, x0, target, left, right, max_iter, tol, max_step):
    def g(x):
        return scalar_call(phase.F, x) - target

    def gp(x):
        return scalar_call(phase.Fprime, x)

    x = float(x0)

    for _ in range(max_iter):
        fx = g(x)
        if abs(fx) <= tol:
            return x, abs(fx), "newton"

        d = gp(x)
        if not np.isfinite(d) or abs(d) < 1e-14:
            break

        step = float(np.clip(fx / d, -max_step, max_step))
        xn = x - step
        if not np.isfinite(xn) or not (left < xn < right):
            xn = 0.5 * (left + right)

        fn = g(xn)
        if np.isfinite(fn):
            if fn < 0:
                left = max(left, xn)
            elif fn > 0:
                right = min(right, xn)

        if abs(xn - x) <= 1e-15 * max(1.0, abs(x)):
            x = xn
            break
        x = xn

    fx = g(x)
    if abs(fx) <= max(10 * tol, 1e-11):
        return x, abs(fx), "newton_loose"

    if brentq is not None:
        gl = g(left)
        gr = g(right)
        if np.isfinite(gl) and np.isfinite(gr) and gl * gr <= 0:
            xr = brentq(g, left, right, xtol=tol, rtol=1e-13, maxiter=100)
            return float(xr), abs(g(xr)), "brentq"

    return x, abs(fx), "failed"


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    ap.add_argument("--roots-npz", default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz")
    ap.add_argument("--v102-module", default="rot_rh_pnt_finite_part_full_pipeline_v102_1")
    ap.add_argument("--base-module", default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit")

    ap.add_argument("--L-new", type=int, default=256000)
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--newton-iters", type=int, default=14)
    ap.add_argument("--root-tol", type=float, default=2e-10)
    ap.add_argument("--max-newton-step", type=float, default=0.15)

    ap.add_argument("--focus-modes", default="9,10,13,14")
    ap.add_argument("--low-mode-end", type=int, default=16)

    ap.add_argument("--contraction-gate", type=float, default=0.95)
    ap.add_argument("--expansion-gate", type=float, default=1.05)
    ap.add_argument("--prefix", default="rot_rh_low_mode_endpoint_v137")

    args = ap.parse_args()
    focus = [int(x.strip()) for x in args.focus_modes.split(",") if x.strip()]

    z = np.load(args.roots_npz)
    Ls = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    L_prev = int(np.max(Ls))
    if args.L_new <= L_prev:
        raise RuntimeError("--L-new must exceed the largest cutoff in ROOTS.npz.")

    L_prev2 = L_prev // 2
    L_prev4 = L_prev // 4

    def idx_of(L):
        hit = np.where(Ls == L)[0]
        return int(hit[0]) if len(hit) else None

    i1 = idx_of(L_prev)
    i2 = idx_of(L_prev2)
    i4 = idx_of(L_prev4)
    if i1 is None or i2 is None or i4 is None:
        raise RuntimeError(f"Need dyadic history {L_prev4}, {L_prev2}, {L_prev} in ROOTS.npz.")

    n = min(args.modes, roots.shape[1] - 1)
    r4 = roots[i4, :n].copy()
    r2 = roots[i2, :n].copy()
    r1 = roots[i1, :n].copy()
    r1_full = roots[i1]

    print("=" * 122)
    print("ROT-RH v137 — FAST LOW-MODE ENDPOINT CONTINUATION")
    print("=" * 122)
    print("Xi / zeta / known zeros          : NONE")
    print(f"historical dyadic anchors         : {L_prev4}, {L_prev2}, {L_prev}")
    print(f"new cutoff                        : {args.L_new}")
    print(f"modes continued                   : 1..{n}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 122)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print(f"[L={args.L_new}] building RenormalizedPhase ...", flush=True)
    phase = v102.RenormalizedPhase.build(base, int(args.L_new), float(args.tail_factor), int(args.counter_q))
    print("[phase] built; continuing low roots ...", flush=True)

    rnew = np.empty(n, dtype=float)
    residual = np.empty(n, dtype=float)
    methods = []

    seed = r1 + (r1 - r2)

    for j in range(n):
        if j == 0:
            right_gap = float(r1_full[1] - r1_full[0])
            left = max(1e-8, float(r1_full[0] - 0.48 * right_gap))
        else:
            left = 0.5 * float(r1_full[j - 1] + r1_full[j])
        right = 0.5 * float(r1_full[j] + r1_full[j + 1])

        x0 = float(seed[j])
        if not (left < x0 < right):
            x0 = float(r1[j])

        x, res, method = refine_root(
            phase, x0, (j + 1) - 0.5, left, right,
            args.newton_iters, args.root_tol, args.max_newton_step
        )

        rnew[j] = x
        residual[j] = res
        methods.append(method)

        if j < min(16, n) or (j + 1) in focus:
            print(
                f"k={j+1:3d} E_prev={r1[j]:.12f} E_new={x:.12f} "
                f"dE={x-r1[j]:+.3e} res={res:.2e} {method}"
            )

    if np.any(np.diff(rnew) <= 0):
        raise RuntimeError("New roots are not strictly ordered.")

    lam4 = 1.0 / r4**2
    lam2 = 1.0 / r2**2
    lam1 = 1.0 / r1**2
    lamnew = 1.0 / rnew**2

    d_old = lam2 - lam4
    d_prev = lam1 - lam2
    d_new = lamnew - lam1

    a_old = np.abs(d_old)
    a_prev = np.abs(d_prev)
    a_new = np.abs(d_new)

    rows = []
    for j in range(n):
        ratio = float(a_new[j] / a_prev[j]) if a_prev[j] > 0 else np.nan
        p = local_p(float(a_prev[j]), float(a_new[j]))
        flip = int(d_prev[j] != 0 and d_new[j] != 0 and np.sign(d_prev[j]) != np.sign(d_new[j]))
        rows.append(dict(
            k=j + 1,
            E_Lquarter=float(r4[j]),
            E_Lhalf=float(r2[j]),
            E_Lprev=float(r1[j]),
            E_Lnew=float(rnew[j]),
            root_residual=float(residual[j]),
            method=methods[j],
            old_abs_delta_lambda=float(a_old[j]),
            previous_abs_delta_lambda=float(a_prev[j]),
            new_abs_delta_lambda=float(a_new[j]),
            new_to_previous_ratio=ratio,
            new_local_p=p,
            previous_signed_delta_lambda=float(d_prev[j]),
            new_signed_delta_lambda=float(d_new[j]),
            latest_sign_flip=flip,
        ))

    write_csv(Path(args.prefix + "_MODES.csv"), rows)

    np.savez_compressed(
        args.prefix + "_ENDPOINT.npz",
        L_new=np.array([args.L_new], dtype=int),
        roots_new=rnew,
        lambda_new=lamnew,
        residuals=residual,
        L_prev=np.array([L_prev], dtype=int),
        roots_prev=r1,
        lambda_prev=lam1,
    )

    low = min(args.low_mode_end, n)
    T_old_low = float(np.sum(a_old[:low]))
    T_prev_low = float(np.sum(a_prev[:low]))
    T_new_low = float(np.sum(a_new[:low]))

    T_old_all = float(np.sum(a_old))
    T_prev_all = float(np.sum(a_prev))
    T_new_all = float(np.sum(a_new))

    low_ratio = T_new_low / T_prev_low if T_prev_low > 0 else np.nan
    all_ratio = T_new_all / T_prev_all if T_prev_all > 0 else np.nan

    focus_idx = [k - 1 for k in focus if 1 <= k <= n]
    T_prev_focus = float(np.sum(a_prev[focus_idx])) if focus_idx else np.nan
    T_new_focus = float(np.sum(a_new[focus_idx])) if focus_idx else np.nan
    focus_ratio = T_new_focus / T_prev_focus if focus_idx and T_prev_focus > 0 else np.nan

    if low_ratio < args.contraction_gate:
        diagnosis = "LOW_MODES_CONTRACT_AT_NEW_ENDPOINT"
    elif low_ratio > args.expansion_gate:
        diagnosis = "LOW_MODES_EXPAND_AT_NEW_ENDPOINT"
    else:
        diagnosis = "LOW_MODES_REMAIN_NEAR_PLATEAU"

    max_res = float(np.max(residual))
    failed = [i + 1 for i, m in enumerate(methods) if m == "failed"]

    summary = dict(
        version=137,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        historical_cutoffs=[L_prev4, L_prev2, L_prev],
        new_cutoff=args.L_new,
        modes=n,
        low_mode_end=low,
        focus_modes=focus,
        max_root_residual=max_res,
        failed_modes=failed,
        trace_history=dict(
            low_modes=dict(
                old=T_old_low, previous=T_prev_low, new=T_new_low,
                new_to_previous=low_ratio,
                new_local_p=local_p(T_prev_low, T_new_low),
            ),
            all_tested_modes=dict(
                old=T_old_all, previous=T_prev_all, new=T_new_all,
                new_to_previous=all_ratio,
                new_local_p=local_p(T_prev_all, T_new_all),
            ),
            focus_modes=dict(
                previous=T_prev_focus, new=T_new_focus,
                new_to_previous=focus_ratio,
                new_local_p=local_p(T_prev_focus, T_new_focus),
            ),
        ),
        diagnosis=diagnosis,
    )

    Path(args.prefix + "_SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print()
    print("Latest individual focus modes")
    print("-" * 122)
    print(f"{'k':>4} {'prev |dlam|':>15} {'new |dlam|':>15} {'ratio':>10} {'p_local':>10} {'flip':>6}")
    for k in focus:
        if 1 <= k <= n:
            r = rows[k - 1]
            print(
                f"{k:4d} {r['previous_abs_delta_lambda']:15.6e} "
                f"{r['new_abs_delta_lambda']:15.6e} "
                f"{r['new_to_previous_ratio']:10.6f} "
                f"{r['new_local_p']:10.6f} "
                f"{r['latest_sign_flip']:6d}"
            )

    print()
    print("=" * 122)
    print(f"max new root residual             : {max_res:.3e}")
    print(f"failed modes                      : {failed}")
    print(f"modes 1..{low} trace ratio            : {low_ratio:.9f}   p={local_p(T_prev_low, T_new_low):.6f}")
    print(f"modes 1..{n} trace ratio            : {all_ratio:.9f}   p={local_p(T_prev_all, T_new_all):.6f}")
    print(f"focus {focus} trace ratio       : {focus_ratio:.9f}   p={local_p(T_prev_focus, T_new_focus):.6f}")
    print(f"DIAGNOSIS                         : {diagnosis}")
    print("=" * 122)


if __name__ == "__main__":
    main()
