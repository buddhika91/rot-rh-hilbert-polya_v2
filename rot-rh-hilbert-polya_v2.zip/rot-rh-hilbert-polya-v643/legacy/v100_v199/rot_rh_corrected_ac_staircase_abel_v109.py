#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v109 — Corrected AC Residue / Staircase vs Abel Decomposition
====================================================================

Corrects two issues exposed by v108:

1) Staircase integration by parts must use F_L(0+), not the literal branch-cut
   value returned at E=0 by scipy's E1 branch convention.

2) The Cauchy transform of the analytic-continuation add-back contains an
   extra residue term.

Let
    A(E)=Im E1((-1/2-iE) log 2).

Then
    A'(E)
      = -sqrt(2) [E sin(wE)+(1/2) cos(wE)]/(E^2+1/4),
      w=log 2.

Therefore, for real a>1/2,

  int_0^inf [-A'(E)/pi]/(E^2+a^2) dE

    = 1/(a^2-1/4)
      - 2^(-a-1/2)/[a(a-1/2)].

The second term is exactly the Cauchy transform of the unsmoothed PNT
continuum subtraction; the first term is the missing elementary rational
piece.

Hence the corrected finite-L continuum transform is

    Jcorr_L
      = rational
        + arch
        + smoothed prime
        + smoothed PNT continuum
        - unsmoothed PNT continuum.

This script decomposes, with NO Xi/zeta/known-zero evaluations,

    Rop_L - Rarith
      = (Rop_L - Jcorr_L)
        + (Jcorr_L - Rarith)

into

    staircase/quantization discrepancy
      + Abel-smoothing discrepancy.

It also verifies the exact finite-prefix staircase identity using F(0+).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad
from scipy.special import digamma

VERSION = "v109"
BUILD = "2026-08-17-corrected-ac-residue-staircase-abel-v109"
EPS = 1e-15


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def partial_moments(roots, order):
    r = np.asarray(roots, float)
    return np.asarray(
        [float(np.sum(r ** (-2 * m))) for m in range(1, order + 1)],
        float,
    )


def operator_resolvent_prefix_tail(roots, completed_moments, a, order):
    r = np.asarray(roots, float)
    cm = np.asarray(completed_moments, float)
    M = min(int(order), len(cm))
    pm = partial_moments(r, M)
    tail = cm[:M] - pm

    a = float(a)
    prefix = float(np.sum(1.0 / (r * r + a * a)))

    tail_val = 0.0
    p = 1.0
    for q in range(M):
        tail_val += p * float(tail[q])
        p *= -(a * a)

    EN = float(r[-1])
    ratio = (a / EN) ** 2
    if ratio >= 1:
        raise ValueError("Need a<E_N.")
    rem = abs(float(tail[0])) * ratio ** M / (1.0 - ratio)
    return prefix + tail_val, prefix, tail_val, rem


def dirichlet_tail_bound(N, sigma):
    N = float(N)
    sigma = float(sigma)
    q = sigma - 1.0
    integ = N ** (1.0 - sigma) * (
        math.log(N) / q + 1.0 / (q * q)
    )
    endpoint = math.log(N + 1.0) * (N + 1.0) ** (-sigma)
    return float(integ + endpoint)


def arithmetic_resolvent_unsmoothed(a, nums, lam, logs, nmax):
    a = float(a)
    sigma = 0.5 + a

    dsum = float(np.sum(lam * np.exp(-sigma * logs)))
    dunc = dirichlet_tail_bound(nmax, sigma)

    rational = 1.0 / (a * a - 0.25)
    arch = (float(digamma(sigma / 2.0)) - math.log(math.pi)) / (4.0 * a)
    prime = -dsum / (2.0 * a)
    rhs = rational + arch + prime
    unc = dunc / (2.0 * a)
    return {
        "total": rhs,
        "rational": rational,
        "arch": arch,
        "prime": prime,
        "uncertainty": unc,
    }


def corrected_finiteL_continuum(phase, a):
    """
    Correct Cauchy transform of the actual finite-part phase derivative.

    F'_L = theta'/pi - P'_L/pi + M'_L/pi - AC'/pi.

    The AC term has the exact transform

      ACcorr = rational - unsmoothed_continuum/(2a).

    Thus the corrected full transform contains the rational term explicitly.
    """
    a = float(a)
    sigma = 0.5 + a

    rational = 1.0 / (a * a - 0.25)
    arch = (float(digamma(sigma / 2.0)) - math.log(math.pi)) / (4.0 * a)

    # phase_w*logs = Lambda(n)/sqrt(n) exp(-n/L)
    prime_coeff = phase.phase_w * phase.logs
    smoothed_prime_sum = float(
        np.sum(prime_coeff * np.exp(-a * phase.logs))
    )
    prime = -smoothed_prime_sum / (2.0 * a)

    L = float(phase.L)
    smoothed_cont = quad(
        lambda x: x ** (-sigma) * math.exp(-x / L),
        2.0,
        np.inf,
        epsabs=1e-14,
        epsrel=1e-12,
        limit=300,
    )[0]
    counter = smoothed_cont / (2.0 * a)

    unsmoothed_cont = 2.0 ** (1.0 - sigma) / (sigma - 1.0)
    ac_continuum_piece = -unsmoothed_cont / (2.0 * a)

    # Exact AC transform = rational + ac_continuum_piece.
    ac_exact = rational + ac_continuum_piece

    total = arch + prime + counter + ac_exact
    return {
        "total": total,
        "rational": rational,
        "arch": arch,
        "prime": prime,
        "counter": counter,
        "ac_continuum_piece": ac_continuum_piece,
        "ac_exact": ac_exact,
    }


def interval_nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def prefix_continuum_and_staircase(phase, roots, a, q):
    """
    Compute on [0,E_N]:
      Jprefix = int g F'
      Qgp     = int (F-N) g'
    cellwise with exact selected-root staircase N(E).

    Avoid evaluating the E1 branch cut at E=0: Gauss nodes are interior.
    """
    roots = np.asarray(roots, float)
    a = float(a)

    intervals = [(0.0, float(roots[0]), 0)]
    for j in range(len(roots) - 1):
        intervals.append(
            (float(roots[j]), float(roots[j + 1]), j + 1)
        )

    J = 0.0
    Qgp = 0.0
    maxQ = 0.0
    minFp = math.inf
    negvar = 0.0

    for lo, hi, nst in intervals:
        E, W = interval_nodes(lo, hi, q)
        F = np.asarray(phase.F(E), float)
        Fp = np.asarray(phase.Fprime(E), float)

        g = 1.0 / (E * E + a * a)
        gp = -2.0 * E / (E * E + a * a) ** 2

        J += float(np.sum(W * g * Fp))
        Qgp += float(np.sum(W * (F - float(nst)) * gp))

        if nst > 0:
            maxQ = max(maxQ, float(np.max(np.abs(F - float(nst)))))
            minFp = min(minFp, float(np.min(Fp)))
            negvar += float(np.sum(W * np.maximum(-Fp, 0.0)))

    return {
        "Jprefix": J,
        "Qgp": Qgp,
        "maxQ": maxQ,
        "minFp": minFp,
        "negative_variation": negvar,
    }


def right_limit_F0(phase, eps_list):
    vals = []
    for e in eps_list:
        vals.append(float(phase.F(np.asarray([float(e)]))[0]))
    return vals


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--a-probes", default="2,3,4,5")
    ap.add_argument("--moment-order", type=int, default=10)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=384)
    ap.add_argument("--cell-q", type=int, default=96)
    ap.add_argument("--cell-qcheck", type=int, default=192)
    ap.add_argument("--dirichlet-nmax", type=int, default=2000000)
    ap.add_argument(
        "--prefix",
        default="rot_rh_corrected_ac_staircase_abel_v109",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    aprobes = parse_floats(args.a_probes)

    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")
    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    if got != man.get("sha256"):
        raise RuntimeError("v102.1 SHA mismatch.")

    data = np.load(archive, allow_pickle=False)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("=" * 154)
    print("ROT-RH v109 — CORRECTED AC RESIDUE / STAIRCASE vs ABEL DECOMPOSITION")
    print("=" * 154)
    print("v102.1 SHA verified             :", True)
    print("L ladder                        :", Ls)
    print("depth                           :", args.depth)
    print("a probes                        :", aprobes)
    print("cell quadrature                 :", args.cell_q)
    print("independent cell-q check        :", args.cell_qcheck)
    print("Dirichlet nmax                  :", args.dirichlet_nmax)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 154)

    print("[1] Build unsmoothed absolutely convergent arithmetic target", flush=True)
    numbers, lambdas, _ = base.mangoldt_terms(int(args.dirichlet_nmax))
    nums = numbers.astype(float)
    lam = np.asarray(lambdas, float)
    logs = np.log(nums)

    arith = {
        a: arithmetic_resolvent_unsmoothed(
            a, nums, lam, logs, args.dirichlet_nmax
        )
        for a in aprobes
    }

    rows = []
    phase_info = []

    for L in Ls:
        print(f"[L={L}] finite-L corrected continuum + staircase", flush=True)
        phase = v102.RenormalizedPhase.build(
            base, int(L), float(args.tail_factor), int(args.counter_q)
        )
        roots = np.asarray(data[f"roots_L{L}_d{args.depth}"], float)
        moments = np.asarray(
            data[f"mom_{args.method}_L{L}_d{args.depth}"], float
        )

        f0vals = right_limit_F0(
            phase, [1e-3, 3e-4, 1e-4, 3e-5, 1e-5]
        )
        F0plus = float(f0vals[-1])

        phase_info.append({
            "L": L,
            "F0_eps1e3": f0vals[0],
            "F0_eps3e4": f0vals[1],
            "F0_eps1e4": f0vals[2],
            "F0_eps3e5": f0vals[3],
            "F0_eps1e5": f0vals[4],
        })

        EN = float(roots[-1])
        for a in aprobes:
            Rop, Rprefix, Rtail, Rtail_bound = operator_resolvent_prefix_tail(
                roots, moments, a, args.moment_order
            )

            Jcorr = corrected_finiteL_continuum(phase, a)
            Rat = arith[a]

            pq = prefix_continuum_and_staircase(
                phase, roots, a, args.cell_q
            )
            pqc = prefix_continuum_and_staircase(
                phase, roots, a, args.cell_qcheck
            )

            Jprefix = pqc["Jprefix"]
            Qgp = pqc["Qgp"]
            qdiff = max(
                abs(pq["Jprefix"] - pqc["Jprefix"]),
                abs(pq["Qgp"] - pqc["Qgp"]),
            )

            gEN = 1.0 / (EN * EN + a * a)
            g0 = 1.0 / (a * a)

            prefix_disc = Rprefix - Jprefix
            staircase_rhs = (
                0.5 * gEN
                + g0 * F0plus
                + Qgp
            )
            staircase_resid = prefix_disc - staircase_rhs

            Jtail_corr = Jcorr["total"] - Jprefix
            tail_disc = Rtail - Jtail_corr

            sampling_disc = Rop - Jcorr["total"]
            abel_disc = Jcorr["total"] - Rat["total"]
            total_disc = Rop - Rat["total"]
            closure = total_disc - (sampling_disc + abel_disc)

            rows.append({
                "L": L,
                "a": a,
                "E_N": EN,
                "F0plus": F0plus,
                "Rop": Rop,
                "Rprefix": Rprefix,
                "Rtail": Rtail,
                "Rtail_series_bound": Rtail_bound,
                "Jcorr": Jcorr["total"],
                "Jcorr_rational": Jcorr["rational"],
                "Jcorr_arch": Jcorr["arch"],
                "Jcorr_prime": Jcorr["prime"],
                "Jcorr_counter": Jcorr["counter"],
                "Jcorr_ac_cont_piece": Jcorr["ac_continuum_piece"],
                "Jcorr_ac_exact": Jcorr["ac_exact"],
                "Rarith": Rat["total"],
                "Rarith_uncertainty": Rat["uncertainty"],
                "Jprefix": Jprefix,
                "Jtail_corr": Jtail_corr,
                "Qgp": Qgp,
                "prefix_discrepancy": prefix_disc,
                "staircase_rhs": staircase_rhs,
                "staircase_identity_residual": staircase_resid,
                "tail_discrepancy": tail_disc,
                "sampling_discrepancy": sampling_disc,
                "abel_smoothing_discrepancy": abel_disc,
                "total_operator_minus_arithmetic": total_disc,
                "decomposition_closure": closure,
                "cell_qcheck_difference": qdiff,
                "selected_max_abs_Q": pqc["maxQ"],
                "selected_min_Fprime": pqc["minFp"],
                "selected_negative_variation": pqc["negative_variation"],
            })

        rr = [r for r in rows if r["L"] == L]
        print(
            f"  F(0+)~{F0plus:+.3e}; "
            f"max staircase resid={max(abs(r['staircase_identity_residual']) for r in rr):.3e}; "
            f"max |sampling|={max(abs(r['sampling_discrepancy']) for r in rr):.3e}; "
            f"max |Abel|={max(abs(r['abel_smoothing_discrepancy']) for r in rr):.3e}"
        )

    print("[2] Final-L exact decomposition", flush=True)
    finalL = Ls[-1]
    final = [r for r in rows if r["L"] == finalL]
    for r in final:
        print(
            f"  a={r['a']:g}: "
            f"Rop-Rarith={r['total_operator_minus_arithmetic']:+.3e} = "
            f"sampling {r['sampling_discrepancy']:+.3e} + "
            f"Abel {r['abel_smoothing_discrepancy']:+.3e}; "
            f"prefixDisc={r['prefix_discrepancy']:+.3e}, "
            f"tailDisc={r['tail_discrepancy']:+.3e}, "
            f"stairRes={r['staircase_identity_residual']:+.2e}"
        )

    print("[3] L-flow of staircase and Abel pieces", flush=True)
    flow = []
    for a in aprobes:
        ar = [r for r in rows if r["a"] == a]
        for r0, r1 in zip(ar[:-1], ar[1:]):
            flow.append({
                "a": a,
                "L_from": r0["L"],
                "L_to": r1["L"],
                "sampling_from": r0["sampling_discrepancy"],
                "sampling_to": r1["sampling_discrepancy"],
                "sampling_abs_drift":
                    abs(r1["sampling_discrepancy"] - r0["sampling_discrepancy"]),
                "abel_from": r0["abel_smoothing_discrepancy"],
                "abel_to": r1["abel_smoothing_discrepancy"],
                "abel_abs_drift":
                    abs(r1["abel_smoothing_discrepancy"] - r0["abel_smoothing_discrepancy"]),
                "total_from": r0["total_operator_minus_arithmetic"],
                "total_to": r1["total_operator_minus_arithmetic"],
            })
        last = flow[-1]
        print(
            f"  a={a:g}: sampling {last['sampling_from']:+.3e} -> "
            f"{last['sampling_to']:+.3e}; "
            f"Abel {last['abel_from']:+.3e} -> {last['abel_to']:+.3e}"
        )

    max_stair = max(abs(r["staircase_identity_residual"]) for r in final)
    max_closure = max(abs(r["decomposition_closure"]) for r in final)
    max_qdiff = max(r["cell_qcheck_difference"] for r in final)
    max_sampling = max(abs(r["sampling_discrepancy"]) for r in final)
    max_abel = max(abs(r["abel_smoothing_discrepancy"]) for r in final)
    max_total = max(abs(r["total_operator_minus_arithmetic"]) for r in final)

    gates = {
        "F0_right_limit_near_zero":
            max(abs(x["F0_eps1e5"]) for x in phase_info) < 1e-3,
        "staircase_identity_closes":
            max_stair < 1e-8,
        "cell_quadrature_stable":
            max_qdiff < 1e-8,
        "sampling_plus_abel_decomposition_exact":
            max_closure < 1e-12,
        "corrected_total_matches_zero_free_arithmetic":
            max_total < 1e-7,
    }

    if all(gates.values()):
        verdict = (
            "PASS_V109_CORRECTED_AC_RESIDUE_DECOMPOSES_RESOLVENT__"
            "NEXT_PROVE_SAMPLING_AND_ABEL_TERMS_VANISH"
        )
    else:
        verdict = "PARTIAL_V109_CORRECTED_RESOLVENT_DECOMPOSITION_NEEDS_REFINEMENT"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_DECOMPOSITION.csv"), rows)
    write_csv(Path(str(prefix) + "_L_FLOW.csv"), flow)
    write_csv(Path(str(prefix) + "_F0_RIGHT_LIMIT.csv"), phase_info)
    Path(str(prefix) + "_VERDICT.json").write_text(
        json.dumps(
            {
                "version": VERSION,
                "build": BUILD,
                "verdict": verdict,
                "RH_proof": False,
                "Xi_used": False,
                "zeta_used": False,
                "known_zeros_used": False,
                "source_v102_sha256": got,
                "gates": gates,
                "final_max_staircase_identity_residual": max_stair,
                "final_max_sampling_discrepancy": max_sampling,
                "final_max_abel_smoothing_discrepancy": max_abel,
                "final_max_total_operator_minus_arithmetic": max_total,
                "theorem_target": (
                    "Prove separately that the exact staircase/quantization "
                    "discrepancy R_L-Jcorr_L tends to zero and that the Abel "
                    "smoothing discrepancy Jcorr_L-Rarith tends to zero on "
                    "an open interval a>1/2. The second term is accessible by "
                    "absolute convergence; the first is the remaining "
                    "spectral-staircase theorem."
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\n" + "=" * 154)
    print("FINAL v109 VERDICT")
    print("=" * 154)
    print("verdict                         :", verdict)
    print("max staircase identity residual :", f"{max_stair:.12e}")
    print("max cell-q difference           :", f"{max_qdiff:.12e}")
    print("max |sampling discrepancy|      :", f"{max_sampling:.12e}")
    print("max |Abel discrepancy|          :", f"{max_abel:.12e}")
    print("max |operator-arithmetic|       :", f"{max_total:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("=" * 154)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
