#!/usr/bin/env python3
"""
ROT-RH v160 — PROSPECTIVE COMPLEX SHELL SUMMABILITY AUDIT

Purpose
-------
v159 showed strong all-pairs contraction on the finite interlaced cutoff net.
But finite tail envelopes alone do not prove a Cauchy limit.

For a geometric cutoff sequence

    L_{j+1} = r L_j,     r ~ sqrt(2),

a sufficient route is absolute summability of the ADJACENT complex cutoff
increments on each fixed finite spectral block:

    A_j(E-set)
      = sum_{k<=N} |Z_{L_j,L_{j+1}}(E_k)|,

    sum_j A_j < infinity.

If

    A_j <= C L_j^{-alpha},    alpha > 0,

then the geometric series is summable and for arbitrary later shell endpoints

    sum_{m>=j} A_m -> 0.

Scientific design
-----------------
To avoid any root-solving or moving-energy ambiguity, v160 FREEZES the energy
set once, by default at the L=512000 roots from v143, and evaluates every
cutoff shell on exactly those same energies.

It then extends several new sqrt(2)-spaced shells beyond 512000.

This directly tests the complex arithmetic primitive as a function of the
regulator, independent of root micromotion.

The script:
  1. builds one prime-power table through the largest requested cutoff;
  2. computes complex adjacent-shell amplitudes A_j;
  3. fits alpha on EARLY shells only;
  4. prospectively predicts the final --holdout-shells shells;
  5. reports local alpha_j and modewise contraction;
  6. computes the geometric-tail estimate A_j/(1-r^{-alpha}) when alpha>0;
  7. checks telescoping:
         Z_{L0,Lm}(E) = sum_j Z_{Lj,Lj+1}(E)
     on the same frozen energy set.

NO Xi / zeta / known-zero data are used.
No phase builds and no root solves are performed.

Outputs
-------
<prefix>_SHELLS.csv
<prefix>_MODES.csv
<prefix>_HOLDOUT.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def continuum_complex(E, L, M, xmin, xmax, nodes, weights):
    ulo = math.log(xmin)
    uhi = math.log(xmax)

    mid = 0.5 * (ulo + uhi)
    half = 0.5 * (uhi - ulo)

    u = mid + half * nodes
    x = np.exp(u)

    reg = np.exp(-x/M) - np.exp(-x/L)
    amp = reg * np.exp(0.5*u) / u

    return half * np.dot(weights, amp * np.exp(1j * E * u))


def fit_power(Lleft, A):
    Lleft = np.asarray(Lleft, dtype=float)
    A = np.asarray(A, dtype=float)

    mask = (Lleft > 0) & (A > 0) & np.isfinite(A)
    X = np.log(Lleft[mask])
    Y = np.log(A[mask])

    if len(X) < 2:
        return np.nan, np.nan, np.nan

    M = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(M, Y, rcond=None)
    pred = M @ coef

    logC = float(coef[0])
    alpha = float(-coef[1])

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, math.exp(logC), r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--cutoff-net-npz",
        default="rot_rh_cutoff_independence_v143_ROOTS.npz",
    )
    ap.add_argument(
        "--anchor-L",
        type=int,
        default=512000,
        help="Freeze E_k at this cutoff.",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--shell-cutoffs",
        default="256000,362039,512000,724077,1024000,1448155",
        help="Increasing geometric-like cutoff sequence.",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--continuum-gl-order", type=int, default=1024)
    ap.add_argument("--prime-chunk", type=int, default=65536)

    ap.add_argument(
        "--holdout-shells",
        type=int,
        default=2,
        help="Final adjacent shells excluded from the power fit.",
    )
    ap.add_argument(
        "--prediction-safety-factor",
        type=float,
        default=1.10,
    )
    ap.add_argument(
        "--holdout-ratio-gate",
        type=float,
        default=1.0,
    )
    ap.add_argument(
        "--minimum-alpha-gate",
        type=float,
        default=0.01,
    )
    ap.add_argument(
        "--mode-contraction-fraction-gate",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--telescoping-relative-gate",
        type=float,
        default=1e-8,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_complex_shell_summability_v160",
    )

    args = ap.parse_args()

    cutoffs = csv_ints(args.shell_cutoffs)
    if len(cutoffs) < 5:
        raise RuntimeError("Need at least 5 cutoff points.")
    if any(cutoffs[i+1] <= cutoffs[i] for i in range(len(cutoffs)-1)):
        raise RuntimeError("--shell-cutoffs must be strictly increasing.")

    nshell = len(cutoffs)-1
    if not (1 <= args.holdout_shells <= nshell-2):
        raise RuntimeError(
            "--holdout-shells must leave at least two training shells."
        )

    z = np.load(args.cutoff_net_npz)
    Lnet = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    hit = np.where(Lnet == args.anchor_L)[0]
    if not len(hit):
        raise RuntimeError(
            f"anchor L={args.anchor_L} not found in cutoff net."
        )

    E = roots[int(hit[0]), :args.modes].astype(float)
    n = len(E)

    max_M = max(cutoffs)
    xmax = int(math.ceil(args.tail_factor * max_M))

    print("=" * 148)
    print("ROT-RH v160 — PROSPECTIVE COMPLEX SHELL SUMMABILITY AUDIT")
    print("=" * 148)
    print("Xi / zeta / known zeros          : NONE")
    print(f"frozen energy anchor              : L={args.anchor_L}")
    print(f"modes                             : 1..{n}")
    print(f"shell cutoffs                     : {cutoffs}")
    print(f"adjacent shells                   : {nshell}")
    print(f"held-out final shells             : {args.holdout_shells}")
    print(f"prime-power xmax                  : {xmax:,}")
    print(f"continuum GL order                : {args.continuum_gl_order}")
    print("=" * 148)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    atom_u = np.log(atom_x)
    atom_base = atom_afac / np.sqrt(atom_x)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    nodes, weights = leggauss(args.continuum_gl_order)

    shell_Z = []
    shell_rows = []
    mode_rows = []

    for j, (L, M) in enumerate(zip(cutoffs[:-1], cutoffs[1:])):
        print(f"[shell {j+1}/{nshell}] {L}->{M} ...", flush=True)

        reg = np.exp(-atom_x/M) - np.exp(-atom_x/L)
        aw = atom_base * reg

        dP = np.zeros(n, dtype=np.complex128)

        for i in range(0, len(atom_u), args.prime_chunk):
            u = atom_u[i:i+args.prime_chunk]
            w = aw[i:i+args.prime_chunk]
            dP += np.exp(1j*np.outer(E, u)) @ w

        dM = np.array([
            continuum_complex(
                float(Ek), L, M,
                2.0, float(xmax),
                nodes, weights
            )
            for Ek in E
        ], dtype=np.complex128)

        Z = (dM-dP)/math.pi
        shell_Z.append(Z)

        A = float(np.sum(np.abs(Z)))
        Aim = float(np.sum(np.abs(Z.imag)))
        Are = float(np.sum(np.abs(Z.real)))

        row = dict(
            shell=j+1,
            L=L,
            M=M,
            ratio_M_over_L=float(M/L),
            L_geometric_mean=math.sqrt(L*M),
            complex_l1=A,
            imag_l1=Aim,
            real_l1=Are,
            projection_reserve=A/max(Aim, 1e-300),
        )

        if j == 0:
            row["complex_ratio"] = np.nan
            row["local_alpha"] = np.nan
            row["mode_magnitude_contraction_fraction"] = np.nan
        else:
            prevA = shell_rows[-1]["complex_l1"]
            ratio = A/prevA

            # use actual left-cutoff ratio
            rL = L / shell_rows[-1]["L"]
            alpha_local = (
                -math.log(ratio)/math.log(rL)
                if ratio > 0 and rL > 1 else np.nan
            )

            prevZ = shell_Z[-2]
            frac = float(np.mean(np.abs(Z) < np.abs(prevZ)))

            row["complex_ratio"] = ratio
            row["local_alpha"] = alpha_local
            row["mode_magnitude_contraction_fraction"] = frac

        shell_rows.append(row)

        for k in range(n):
            mode_rows.append(dict(
                shell=j+1,
                L=L,
                M=M,
                k=k+1,
                E_frozen=float(E[k]),
                Z_real=float(Z[k].real),
                Z_imag=float(Z[k].imag),
                Z_abs=float(abs(Z[k])),
                phase=float(np.angle(Z[k])),
            ))

        print(
            f"          |Z|_1={A:.6e}  "
            f"|Im|_1={Aim:.6e}  "
            f"ratio={row['complex_ratio']:.6f}  "
            f"local alpha={row['local_alpha']:.6f}"
        )

    # ------------------------------------------------------------------
    # training / prospective holdout fit
    # ------------------------------------------------------------------
    ntrain = nshell - args.holdout_shells

    train = shell_rows[:ntrain]
    hold = shell_rows[ntrain:]

    Ltrain = [r["L"] for r in train]
    Atrain = [r["complex_l1"] for r in train]

    alpha, C, r2 = fit_power(Ltrain, Atrain)

    holdout_rows = []
    holdout_passes = []

    for r in hold:
        pred = C*(float(r["L"])**(-alpha))
        bound = args.prediction_safety_factor * pred
        ratio = r["complex_l1"]/max(bound, 1e-300)
        passed = ratio <= args.holdout_ratio_gate

        holdout_rows.append(dict(
            shell=r["shell"],
            L=r["L"],
            M=r["M"],
            actual_complex_l1=r["complex_l1"],
            predicted_complex_l1=pred,
            safety_bound=bound,
            actual_over_bound=ratio,
            passed=int(passed),
        ))
        holdout_passes.append(passed)

    # ------------------------------------------------------------------
    # telescoping identity on frozen energies
    # ------------------------------------------------------------------
    Zsum = np.sum(np.stack(shell_Z, axis=0), axis=0)

    L0 = cutoffs[0]
    Mend = cutoffs[-1]

    reg = np.exp(-atom_x/Mend) - np.exp(-atom_x/L0)
    aw = atom_base * reg

    dP_long = np.zeros(n, dtype=np.complex128)
    for i in range(0, len(atom_u), args.prime_chunk):
        u = atom_u[i:i+args.prime_chunk]
        w = aw[i:i+args.prime_chunk]
        dP_long += np.exp(1j*np.outer(E, u)) @ w

    dM_long = np.array([
        continuum_complex(
            float(Ek), L0, Mend,
            2.0, float(xmax),
            nodes, weights
        )
        for Ek in E
    ], dtype=np.complex128)

    Zlong = (dM_long-dP_long)/math.pi

    telescoping_abs = float(np.sum(np.abs(Zsum-Zlong)))
    telescoping_rel = (
        telescoping_abs /
        max(float(np.sum(np.abs(Zlong))), 1e-300)
    )

    # ------------------------------------------------------------------
    # summability diagnostics
    # ------------------------------------------------------------------
    if alpha > 0:
        # Representative geometric ratio from median shell ratio in L.
        cutoff_ratios = np.array(
            [cutoffs[i+1]/cutoffs[i] for i in range(nshell)],
            dtype=float
        )
        rgeom = float(np.exp(np.mean(np.log(cutoff_ratios))))
        q = rgeom**(-alpha)

        if q < 1:
            last_A = shell_rows[-1]["complex_l1"]
            geometric_tail_after_last = (
                last_A*q/(1.0-q)
            )
        else:
            geometric_tail_after_last = np.inf
    else:
        rgeom = float(np.nan)
        q = float(np.nan)
        geometric_tail_after_last = np.inf

    # Modewise prospective contraction on heldout transitions.
    holdout_mode_ok = all(
        (
            np.isnan(r["mode_magnitude_contraction_fraction"])
            or r["mode_magnitude_contraction_fraction"]
            >= args.mode_contraction_fraction_gate
        )
        for r in hold
    )

    holdout_fit_ok = all(holdout_passes)
    alpha_ok = np.isfinite(alpha) and alpha > args.minimum_alpha_gate
    telescope_ok = telescoping_rel <= args.telescoping_relative_gate

    if alpha_ok and holdout_fit_ok and holdout_mode_ok and telescope_ok:
        verdict = "PROSPECTIVE_COMPLEX_SHELL_SUMMABILITY_STRONGLY_SUPPORTED"
    elif alpha_ok and holdout_fit_ok and telescope_ok:
        verdict = "COMPLEX_SHELL_DECAY_SUPPORTED_MODEWISE_MIXED"
    else:
        verdict = "COMPLEX_SHELL_SUMMABILITY_UNRESOLVED"

    pd.DataFrame(shell_rows).to_csv(
        args.prefix + "_SHELLS.csv", index=False
    )
    pd.DataFrame(mode_rows).to_csv(
        args.prefix + "_MODES.csv", index=False
    )
    pd.DataFrame(holdout_rows).to_csv(
        args.prefix + "_HOLDOUT.csv", index=False
    )

    summary = dict(
        version=160,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        frozen_anchor_L=args.anchor_L,
        shell_cutoffs=cutoffs,
        training_shells=ntrain,
        holdout_shells=args.holdout_shells,
        power_fit=dict(
            alpha=alpha,
            C=C,
            R2=r2,
            minimum_alpha_gate=args.minimum_alpha_gate,
        ),
        prospective_holdout=holdout_rows,
        representative_geometric_ratio=rgeom,
        fitted_shell_ratio=q,
        extrapolated_geometric_tail_after_last=geometric_tail_after_last,
        telescoping=dict(
            absolute_error=telescoping_abs,
            relative_error=telescoping_rel,
            pass_gate=telescope_ok,
        ),
        verdict=verdict,
        theorem_target=(
            "For a geometric regulator sequence L_j, prove "
            "A_j=sup_{E in fixed compact/block}|Z_{L_j,L_{j+1}}(E)| "
            "is summable. Then arbitrary long-span cutoff differences telescope "
            "and the complex primitive is Cauchy."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    print()
    print("Adjacent complex shell sequence on frozen energies")
    print("-" * 148)
    print(
        f"{'shell':>6} {'pair':>19} {'|Z|_1':>13} "
        f"{'ratio':>10} {'local alpha':>13} "
        f"{'mode contract':>14}"
    )

    for r in shell_rows:
        print(
            f"{r['shell']:6d} "
            f"{r['L']:>8d}->{r['M']:<8d} "
            f"{r['complex_l1']:13.6e} "
            f"{r['complex_ratio']:10.6f} "
            f"{r['local_alpha']:13.6f} "
            f"{r['mode_magnitude_contraction_fraction']:14.3f}"
        )

    print()
    print("Prospective held-out shell predictions")
    print("-" * 148)
    for r in holdout_rows:
        print(
            f"shell={r['shell']:2d} "
            f"{r['L']:>8d}->{r['M']:<8d}  "
            f"actual={r['actual_complex_l1']:.6e}  "
            f"pred={r['predicted_complex_l1']:.6e}  "
            f"safe={r['safety_bound']:.6e}  "
            f"actual/safe={r['actual_over_bound']:.6f}  "
            f"pass={bool(r['passed'])}"
        )

    print()
    print("=" * 148)
    print(f"training alpha                      : {alpha:.9f}")
    print(f"training R2                         : {r2:.6f}")
    print(f"representative shell ratio          : {rgeom:.9f}")
    print(f"fitted amplitude ratio              : {q:.9f}")
    print(f"geometric tail after final shell    : {geometric_tail_after_last:.6e}")
    print(f"telescoping relative residual       : {telescoping_rel:.9e}")
    print(f"positive-alpha pass                 : {alpha_ok}")
    print(f"prospective holdout pass             : {holdout_fit_ok}")
    print(f"held-out mode-contraction pass       : {holdout_mode_ok}")
    print(f"VERDICT                              : {verdict}")
    print("=" * 148)
    print("THEOREM TARGET:")
    print("  Prove summability of adjacent geometric cutoff shells:")
    print()
    print("      sum_j sup_{E in block}|Z_{L_j,L_{j+1}}(E)| < infinity.")
    print()
    print("  Telescoping then gives the arbitrary-pair complex Cauchy limit.")


if __name__ == "__main__":
    main()
