#!/usr/bin/env python3
"""
ROT-RH v193 — CRITICAL-LAYER HOMOGENIZATION REFINEMENT + PROFILE MERGE

Purpose
-------
v192 showed:
  * phase averaging is stable in the material region;
  * neighboring root branches agree to ~1e-6 relative;
  * the remaining uncertainty is slow-x quadrature near x in [-2,0];
  * x=-0.875 and x=-0.25 were unresolved.

v193 recomputes ONLY the critical layer on a dense x-grid, using the v192
homogenization engine, automatically retries difficult points, and merges
the refined profile into the existing v192 PROFILE.csv.

No Xi / zeta / known zeros are used.

Requires rot_rh_transition_homogenization_v192.py in the same directory.
"""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def profile_integral(df):
    d = df.sort_values("x")
    x = d["x"].to_numpy(float)
    g = d["gamma_active"].to_numpy(float)
    r = d["mean_abs_epsilon_over_gamma"].to_numpy(float)
    num = float(np.trapezoid(r*g, x))
    den = float(np.trapezoid(g, x))
    return num/max(abs(den), 1e-300)


def decimate_target_merge(base, target, stride):
    ids = list(range(0, len(target), stride))
    if len(target)-1 not in ids:
        ids.append(len(target)-1)
    t = target.iloc[sorted(set(ids))].copy()

    xmin = float(target["x"].min())
    xmax = float(target["x"].max())

    outside = base[
        (base["x"] < xmin-1e-12) | (base["x"] > xmax+1e-12)
    ].copy()

    merged = pd.concat([outside, t], ignore_index=True)
    return (
        merged
        .sort_values("x")
        .drop_duplicates("x", keep="last")
        .reset_index(drop=True)
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--baseline-profile",
        default="rot_rh_transition_homogenization_v192_PROFILE.csv",
    )
    ap.add_argument(
        "--v192-module",
        default="rot_rh_transition_homogenization_v192",
    )
    ap.add_argument("--switch-index", type=int, default=159)

    ap.add_argument("--dps", type=int, default=55)
    ap.add_argument("--tol-exp", type=int, default=35)
    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--search-cells", type=int, default=12)
    ap.add_argument("--branch-count", type=int, default=1)
    ap.add_argument("--phase-points", type=int, default=129)
    ap.add_argument("--max-subdivision-depth", type=int, default=12)
    ap.add_argument("--retry-depth", type=int, default=16)
    ap.add_argument("--retry-search-cells", type=int, default=20)

    ap.add_argument("--x-min", type=float, default=-2.0)
    ap.add_argument("--x-max", type=float, default=0.125)
    ap.add_argument("--x-step", type=float, default=0.125)

    ap.add_argument(
        "--phase-relative-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--slow-x-relative-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_critical_layer_homogenization_v193",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    mod = importlib.import_module(args.v192_module)

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )
    base = pd.read_csv(args.baseline_profile).sort_values("x").reset_index(drop=True)

    j = args.switch_index-1
    left = hull.iloc[j]
    right = hull.iloc[j+1]

    c1 = mod.match_candidate(
        cand, left["beta_active"], left["gamma_active"]
    )
    c2 = mod.match_candidate(
        cand, right["beta_active"], right["gamma_active"]
    )

    b1 = mp.mpf(str(float(c1["beta"])))
    g1 = mp.mpf(str(float(c1["gamma"])))
    b2 = mp.mpf(str(float(c2["beta"])))
    g2 = mp.mpf(str(float(c2["gamma"])))

    ts = mp.mpf(str(float(left["tau_end"])))
    da = abs(b2-b1)
    dg = abs(g2-g1)
    period = 2*mp.pi/dg

    phase = mod.TwoLayerPhase(b1, g1, b2, g2)

    n = int(round((args.x_max-args.x_min)/args.x_step))
    xvals = [
        mp.mpf(str(args.x_min + k*args.x_step))
        for k in range(n+1)
    ]
    if float(xvals[-1]) < args.x_max-1e-12:
        xvals.append(mp.mpf(str(args.x_max)))

    print("="*186)
    print("ROT-RH v193 — CRITICAL-LAYER HOMOGENIZATION REFINEMENT + PROFILE MERGE")
    print("="*186)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switch                            : {args.switch_index}")
    print(f"critical x window                 : [{args.x_min},{args.x_max}]")
    print(f"x step                            : {args.x_step}")
    print(f"critical x samples                : {len(xvals)}")
    print(f"phase points / cycle              : {args.phase_points}")
    print(f"branches / x                      : {args.branch_count}")
    print(f"fast phase period                 : {mp.nstr(period,12)}")
    print("="*186)

    rows = []
    unresolved = []

    for idx, x in enumerate(xvals, 1):
        tau = ts+x/da
        ga = g1 if x < 0 else g2
        center = ga

        rr = mod.cycle_average(
            phase, tau, center, ga, period, args.phase_points,
            tol, frac, args.newton_iters, args.search_cells,
            args.branch_count, args.max_subdivision_depth
        )
        good = [r for r in rr if r.get("ok")]

        retried = False
        if not good:
            retried = True
            rr = mod.cycle_average(
                phase, tau, center, ga, period, args.phase_points,
                tol, frac, args.newton_iters, args.retry_search_cells,
                args.branch_count, args.retry_depth
            )
            good = [r for r in rr if r.get("ok")]

        if not good:
            unresolved.append(float(x))
            print(
                f"[{idx:2d}/{len(xvals)}] x={float(x):7.3f} UNRESOLVED"
            )
            continue

        vals = np.asarray(
            [float(r["mean_abs_epsilon_over_gamma"]) for r in good],
            float
        )
        mixvals = np.asarray(
            [float(r["mean_abs_mix_over_gamma"]) for r in good],
            float
        )
        p2 = np.asarray(
            [float(r["mean_abs_epsilon_over_gamma_phase_stride2"]) for r in good],
            float
        )

        mean = float(np.mean(vals))
        meanmix = float(np.mean(mixvals))
        meanp2 = float(np.mean(p2))
        phase_diff = abs(meanp2-mean)/max(abs(mean), 1e-300)

        spread = (
            float((np.max(vals)-np.min(vals))/max(abs(mean),1e-300))
            if len(vals) > 1 else 0.0
        )

        rows.append({
            "x": float(x),
            "tau": float(tau),
            "gamma_active": float(ga),
            "branches_completed": len(good),
            "mean_abs_epsilon_over_gamma": mean,
            "mean_abs_mix_over_gamma": meanmix,
            "mean_abs_epsilon_over_gamma_phase_stride2": meanp2,
            "phase_stride2_relative_difference": phase_diff,
            "branch_relative_spread": spread,
            "max_identity_resid": max(
                float(r["max_identity_resid"]) for r in good
            ),
            "max_depth": max(int(r["max_depth"]) for r in good),
            "max_projection": max(float(r["max_proj"]) for r in good),
            "retried": retried,
        })

        print(
            f"[{idx:2d}/{len(xvals)}] "
            f"x={float(x):7.3f} "
            f"<|eps|>/g={mean:.6e} "
            f"phaseDiff={phase_diff:.3e} "
            f"{'RETRY' if retried else ''}"
        )

    target = pd.DataFrame(rows).sort_values("x").reset_index(drop=True)
    target.to_csv(args.prefix+"_CRITICAL_PROFILE.csv", index=False)

    if len(target) < 4:
        verdict = "CRITICAL_LAYER_UNRESOLVED"
        summary = {
            "version": 193,
            "unresolved_x": unresolved,
            "verdict": verdict,
        }
    else:
        xmin = float(target["x"].min())
        xmax = float(target["x"].max())

        outside = base[
            (base["x"] < xmin-1e-12) | (base["x"] > xmax+1e-12)
        ].copy()

        merged = pd.concat([outside, target], ignore_index=True)
        merged = (
            merged.sort_values("x")
            .drop_duplicates("x", keep="last")
            .reset_index(drop=True)
        )
        merged.to_csv(args.prefix+"_MERGED_PROFILE.csv", index=False)

        fine_ratio = profile_integral(merged)

        merged2 = decimate_target_merge(base, target, 2)
        merged4 = decimate_target_merge(base, target, 4)
        ratio2 = profile_integral(merged2)
        ratio4 = profile_integral(merged4)

        diff2 = abs(ratio2-fine_ratio)/max(abs(fine_ratio),1e-300)
        diff4 = abs(ratio4-fine_ratio)/max(abs(fine_ratio),1e-300)

        max_phase_diff = float(
            target["phase_stride2_relative_difference"].max()
        )
        phase_converged = bool(
            max_phase_diff <= args.phase_relative_gate
        )
        x_converged = bool(
            diff2 <= args.slow_x_relative_gate
            and diff4 <= 2*args.slow_x_relative_gate
        )
        complete = len(unresolved) == 0

        if complete and phase_converged and x_converged:
            verdict = "CRITICAL_LAYER_HOMOGENIZATION_CONVERGED"
        elif not complete:
            verdict = "CRITICAL_LAYER_POINTS_UNRESOLVED"
        elif not phase_converged:
            verdict = "CRITICAL_LAYER_PHASE_QUADRATURE_UNRESOLVED"
        else:
            verdict = "CRITICAL_LAYER_SLOW_X_QUADRATURE_UNRESOLVED"

        summary = {
            "version": 193,
            "switch": args.switch_index,
            "critical_x_min": args.x_min,
            "critical_x_max": args.x_max,
            "critical_x_step": args.x_step,
            "critical_points_requested": len(xvals),
            "critical_points_completed": len(target),
            "unresolved_x": unresolved,
            "merged_homogenized_absolute_epsilon_over_active": fine_ratio,
            "merged_stride2_critical": ratio2,
            "merged_stride4_critical": ratio4,
            "critical_stride2_relative_difference": diff2,
            "critical_stride4_relative_difference": diff4,
            "max_phase_stride2_relative_difference": max_phase_diff,
            "phase_quadrature_converged": phase_converged,
            "slow_x_quadrature_converged": x_converged,
            "complete": complete,
            "verdict": verdict,
        }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*186)
    if "merged_homogenized_absolute_epsilon_over_active" in summary:
        print(
            f"merged homogenized |eps| / active : "
            f"{summary['merged_homogenized_absolute_epsilon_over_active']:.12e}"
        )
        print(
            f"critical stride-2 merged estimate : "
            f"{summary['merged_stride2_critical']:.12e}"
        )
        print(
            f"critical stride-4 merged estimate : "
            f"{summary['merged_stride4_critical']:.12e}"
        )
        print(
            f"critical stride-2 rel difference  : "
            f"{summary['critical_stride2_relative_difference']:.6e}"
        )
        print(
            f"critical stride-4 rel difference  : "
            f"{summary['critical_stride4_relative_difference']:.6e}"
        )
        print(
            f"max phase stride-2 rel difference : "
            f"{summary['max_phase_stride2_relative_difference']:.6e}"
        )
    print(f"unresolved x                       : {summary.get('unresolved_x', [])}")
    print(f"VERDICT                            : {summary['verdict']}")
    print("="*186)


if __name__ == "__main__":
    main()
