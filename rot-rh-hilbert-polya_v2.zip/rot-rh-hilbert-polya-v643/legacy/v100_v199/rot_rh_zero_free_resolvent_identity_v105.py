#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v105 — Zero-Free Arithmetic Resolvent Identity Audit
============================================================

This is the theorem-shaped test suggested by the analytic attack.

Let the frozen positive spectrum be E_k and define

    R_op(a) = sum_k 1/(E_k^2 + a^2).

If
    D(t)=det(I-t^2 H^-2)=Xi(t)/Xi(0),
then for sigma=1/2+a,

    R_Xi(a) = (1/(2a)) * xi'(sigma)/xi(sigma).

For a>1/2, sigma>1 and this has the ABSOLUTELY CONVERGENT, ZERO-FREE
Euler-product form

    R_arith(a)
      = 1/(a^2-1/4)
        + [psi(sigma/2)-log(pi)]/(4a)
        - (1/(2a)) sum_{n>=2} Lambda(n)/n^sigma.

No Xi evaluation, zeta evaluation, or zero ordinate is required.

The identity follows from the exact Cauchy transforms

    int_0^inf cos(E log n)/(E^2+a^2) dE
      = pi/(2a) n^-a

and the Poisson integral for the Gamma/digamma term.

This script loads the PRE-XI frozen v102.1 completed moments and compares:
    frozen operator resolvent  vs  absolutely convergent arithmetic RHS.

The operator resolvent is evaluated from its trace-moment series

    R_op(a) = S1 - a^2 S2 + a^4 S3 - ...

with a rigorous geometric remainder bound using E1.

The Dirichlet-series truncation is bounded using Lambda(n)<=log n:

    sum_{n>N} Lambda(n)n^-sigma
      <= integral_N^inf log(x)x^-sigma dx + endpoint term.

No Xi firewall needs to be opened at any point.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import digamma

VERSION = "v105"
BUILD = "2026-08-17-zero-free-arithmetic-resolvent-identity-v105"
EPS = 1e-15


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def operator_resolvent_from_moments(moments, E1, a, order):
    """
    R(a)=sum_k lambda_k/(1+a^2 lambda_k)
        = sum_{r=0}^{M-1} (-a^2)^r S_{r+1} + remainder.

    Since 0<lambda_k<=1/E1^2 and r=a^2/E1^2<1,

      |remainder| <= S1 * r^M/(1-r).
    """
    S = np.asarray(moments, float)
    M = min(int(order), len(S))
    a = float(a)
    E1 = float(E1)
    ratio = (a / E1) ** 2
    if ratio >= 1:
        raise ValueError(f"Need a<E1 for moment series; a={a}, E1={E1}")

    val = 0.0
    p = 1.0
    for r in range(M):
        val += p * float(S[r])
        p *= -(a * a)

    rem = float(S[0]) * (ratio ** M) / (1.0 - ratio)
    return float(val), float(rem)


def dirichlet_tail_bound(N, sigma):
    """
    Lambda(n)<=log n and f(x)=log(x)x^-sigma is decreasing for large x.

    Sum_{n>N} <= f(N+1) + integral_N^inf f(x) dx.
    """
    N = float(N)
    sigma = float(sigma)
    q = sigma - 1.0
    integ = N ** (1.0 - sigma) * (
        math.log(N) / q + 1.0 / (q * q)
    )
    endpoint = math.log(N + 1.0) * (N + 1.0) ** (-sigma)
    return float(integ + endpoint)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list", default="4000,8000,16000")
    ap.add_argument("--depth", type=int, default=48)
    ap.add_argument("--method", default="full_em1")
    ap.add_argument("--a-probes", default="2,3,4,5")
    ap.add_argument("--moment-order", type=int, default=10)
    ap.add_argument("--dirichlet-nmax", type=int, default=2000000)
    ap.add_argument(
        "--prefix",
        default="rot_rh_zero_free_resolvent_identity_v105",
    )
    args = ap.parse_args()

    Ls = parse_ints(args.L_list)
    aprobes = parse_floats(args.a_probes)

    vp = Path(args.v102_prefix).expanduser().resolve()
    archive = Path(str(vp) + "_FROZEN_PRE_XI.npz")
    manifest_path = Path(str(vp) + "_FROZEN_MANIFEST.json")
    if not archive.exists() or not manifest_path.exists():
        raise FileNotFoundError("v102.1 frozen files not found.")

    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    got = sha256_file(archive)
    if got != man.get("sha256"):
        raise RuntimeError("v102.1 frozen SHA mismatch.")

    data = np.load(archive, allow_pickle=False)
    base = importlib.import_module(args.base_module)

    print("=" * 144)
    print("ROT-RH v105 — ZERO-FREE ARITHMETIC RESOLVENT IDENTITY AUDIT")
    print("=" * 144)
    print("v102.1 SHA verified             :", True)
    print("v102.1 SHA                      :", got)
    print("L ladder                        :", Ls)
    print("depth                           :", args.depth)
    print("a probes (sigma=1/2+a)          :", aprobes)
    print("moment order                    :", args.moment_order)
    print("Dirichlet nmax                  :", args.dirichlet_nmax)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 144)

    print("[1] Build absolutely convergent Mangoldt Dirichlet data", flush=True)
    numbers, lambdas, _ = base.mangoldt_terms(int(args.dirichlet_nmax))
    nums = numbers.astype(float)
    lam = np.asarray(lambdas, float)
    lognums = np.log(nums)

    target = {}
    for a in aprobes:
        sigma = 0.5 + float(a)
        # Stable summation in ordinary double is ample at sigma>=2.5.
        dsum = float(np.sum(lam * np.exp(-sigma * lognums)))
        dbound = dirichlet_tail_bound(args.dirichlet_nmax, sigma)

        rational = 1.0 / (a * a - 0.25)
        arch = (float(digamma(sigma / 2.0)) - math.log(math.pi)) / (4.0 * a)
        prime = -dsum / (2.0 * a)
        rhs = rational + arch + prime
        rhs_unc = dbound / (2.0 * a)

        target[a] = {
            "sigma": sigma,
            "dirichlet_sum": dsum,
            "dirichlet_tail_bound": dbound,
            "rational": rational,
            "arch": arch,
            "prime": prime,
            "rhs": rhs,
            "rhs_uncertainty": rhs_unc,
        }
        print(
            f"  a={a:g} sigma={sigma:g}: RHS={rhs:.15e} "
            f"DirichletTail<={rhs_unc:.3e}"
        )

    print("[2] Frozen operator-resolvent comparison", flush=True)
    rows = []
    for L in Ls:
        rk = f"roots_L{L}_d{args.depth}"
        mk = f"mom_{args.method}_L{L}_d{args.depth}"
        if rk not in data or mk not in data:
            raise KeyError(f"Missing frozen {rk} or {mk}")
        roots = np.asarray(data[rk], float)
        moments = np.asarray(data[mk], float)
        E1 = float(roots[0])

        for a in aprobes:
            op, oprem = operator_resolvent_from_moments(
                moments, E1, a, args.moment_order
            )
            t = target[a]
            diff = op - t["rhs"]
            total_cert = oprem + t["rhs_uncertainty"]
            row = {
                "L": L,
                "depth": args.depth,
                "a": a,
                "sigma": t["sigma"],
                "operator_resolvent": op,
                "operator_series_remainder_bound": oprem,
                "arithmetic_resolvent": t["rhs"],
                "dirichlet_RHS_uncertainty_bound": t["rhs_uncertainty"],
                "difference": diff,
                "absolute_difference": abs(diff),
                "relative_difference": abs(diff) / max(abs(t["rhs"]), EPS),
                "combined_numerical_bound": total_cert,
                "difference_over_combined_bound":
                    abs(diff) / max(total_cert, EPS),
            }
            rows.append(row)
            print(
                f"  L={L:<6d} a={a:g}: "
                f"Rop={op:.15e} Rarith={t['rhs']:.15e} "
                f"|d|={abs(diff):.3e} rel={row['relative_difference']:.3e} "
                f"series<={oprem:.1e} dirTail<={t['rhs_uncertainty']:.1e}"
            )

    print("[3] Zero-free L-flow of the resolvent", flush=True)
    flow_rows = []
    for a in aprobes:
        ar = [r for r in rows if r["a"] == a]
        for r0, r1 in zip(ar[:-1], ar[1:]):
            d = abs(r1["operator_resolvent"] - r0["operator_resolvent"])
            flow_rows.append({
                "a": a,
                "L_from": r0["L"],
                "L_to": r1["L"],
                "absolute_drift": d,
                "relative_drift":
                    d / max(abs(r0["operator_resolvent"]), EPS),
            })
        last = flow_rows[-1]
        print(
            f"  a={a:g}, latest {last['L_from']}->{last['L_to']}: "
            f"abs={last['absolute_drift']:.3e} "
            f"rel={last['relative_drift']:.3e}"
        )

    finalL = Ls[-1]
    final_rows = [r for r in rows if r["L"] == finalL]
    max_rel = max(r["relative_difference"] for r in final_rows)
    max_abs = max(r["absolute_difference"] for r in final_rows)

    # This is deliberately a numerical theorem audit, not a proof gate.
    gates = {
        "all_operator_series_remainders_below_1e8":
            all(r["operator_series_remainder_bound"] < 1e-8 for r in final_rows),
        "all_dirichlet_tail_bounds_below_1e8":
            all(r["dirichlet_RHS_uncertainty_bound"] < 1e-8 for r in final_rows),
        "final_relative_resolvent_error_below_1e5":
            max_rel < 1e-5,
    }

    verdict = (
        "PASS_V105_ZERO_FREE_ARITHMETIC_RESOLVENT_IDENTITY_NUMERICALLY_SUPPORTED"
        if all(gates.values())
        else "PARTIAL_V105_RESOLVENT_IDENTITY_NEEDS_MORE_RESOLUTION_OR_FAILS"
    )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_RESOLVENT.csv"), rows)
    write_csv(Path(str(prefix) + "_L_FLOW.csv"), flow_rows)
    out = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "source_v102_sha256": got,
        "gates": gates,
        "final_max_relative_difference": max_rel,
        "final_max_absolute_difference": max_abs,
        "theorem_target": (
            "Prove uniform trace boundedness and convergence of "
            "R_j(a)=sum_k 1/(E_k^2+a^2) for every a>1/2 to the absolutely "
            "convergent arithmetic formula. Stieltjes-transform uniqueness "
            "then yields all trace moments; determinant normality plus "
            "analytic uniqueness yields Xi and Hurwitz gives RH."
        ),
    }
    Path(str(prefix) + "_VERDICT.json").write_text(
        json.dumps(out, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 144)
    print("FINAL v105 VERDICT")
    print("=" * 144)
    print("verdict                         :", verdict)
    print("final max relative difference   :", f"{max_rel:.12e}")
    print("final max absolute difference   :", f"{max_abs:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("=" * 144)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
