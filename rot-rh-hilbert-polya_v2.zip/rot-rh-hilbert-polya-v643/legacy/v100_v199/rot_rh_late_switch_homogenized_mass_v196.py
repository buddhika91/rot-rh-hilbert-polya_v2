#!/usr/bin/env python3
"""
ROT-RH v196 — LATE-SWITCH HOMOGENIZED INTRINSIC-MASS REPLICATION

Goal
----
Test whether the corrected phase-homogenized intrinsic switch mass

    K_j^hom = integral <|epsilon_j|>_phase / Delta gamma_j dx

remains O(1) across late synthetic dominance switches.

This script computes switches 114 and 136 from scratch on a standardized
intrinsic x-grid and loads switch 159 from the frozen v195 summary.

It uses the v192 phase-homogenization engine and retries each x with several
equivalent phase-window offsets.  Only one local branch is used, because v192
showed branch agreement at ~1e-6 or better in the material region.

No Xi / zeta / known zeros are used.

Requires:
  rot_rh_transition_homogenization_v192.py
"""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def mp_trapezoid(xs, ys):
    if len(xs) < 2:
        return mp.nan
    s = mp.mpf("0")
    for i in range(len(xs)-1):
        s += (xs[i+1]-xs[i])*(ys[i+1]+ys[i])/2
    return s


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def decimated(df, stride):
    d = df.sort_values("x").reset_index(drop=True)
    ids = list(range(0, len(d), stride))
    if len(d)-1 not in ids:
        ids.append(len(d)-1)
    return d.iloc[sorted(set(ids))].copy()


def K_from_profile(df, dg):
    d = df.sort_values("x")
    x = d["x"].to_numpy(float)
    ga = d["gamma_active"].to_numpy(float)
    r = d["mean_abs_epsilon_over_gamma"].to_numpy(float)
    eps = r*ga
    return trapz(x, eps/dg)


def cycle_shifted(
    mod, phase, tau0, center_E, ga, period, phase_points,
    tol, frac, iters, search_cells, max_depth, offset_fraction
):
    off = mp.mpf(str(offset_fraction))
    tstart = tau0 - period/2 + off*period
    tend = tstart + period

    roots = mod.local_roots(
        phase, tstart, center_E, tol, frac, iters,
        search_cells, 1
    )
    if not roots:
        return None

    Y = roots[0]["Y"]
    ts = [
        tstart + (tend-tstart)*mp.mpf(k)/(phase_points-1)
        for k in range(phase_points)
    ]

    rows = []
    max_depth_seen = 0

    for k, t in enumerate(ts):
        if k > 0:
            adv = mod.advance(
                phase, Y, ts[k-1], t,
                tol, frac, iters, max_depth
            )
            if not adv["ok"]:
                return None
            Y = adv["Y"]
            max_depth_seen = max(max_depth_seen, int(adv["max_depth"]))

        ev = phase.eval_Y(Y, t, ga)
        rows.append((t, ev))

    tv = [z[0] for z in rows]
    eps = [abs(z[1]["epsilon"]) for z in rows]
    mix = [abs(z[1]["epsilon_mix"]) for z in rows]

    mean_eps = mp_trapezoid(tv, eps)/(tend-tstart)
    mean_mix = mp_trapezoid(tv, mix)/(tend-tstart)

    ids2 = list(range(0, len(tv), 2))
    if len(tv)-1 not in ids2:
        ids2.append(len(tv)-1)

    tv2 = [tv[i] for i in ids2]
    eps2 = [eps[i] for i in ids2]
    mean_eps2 = mp_trapezoid(tv2, eps2)/(tend-tstart)

    return {
        "mean_abs_epsilon_over_gamma": mean_eps/abs(ga),
        "mean_abs_mix_over_gamma": mean_mix/abs(ga),
        "phase_stride2_relative_difference":
            abs(mean_eps2-mean_eps)/max(abs(mean_eps), mp.mpf("1e-100")),
        "max_depth": max_depth_seen,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--v192-module",
        default="rot_rh_transition_homogenization_v192",
    )
    ap.add_argument(
        "--v195-summary",
        default="rot_rh_homogenized_intrinsic_mass_v195_SUMMARY.json",
        help="Frozen switch-159 reference.",
    )
    ap.add_argument("--switch-indices", default="114,136")

    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument("--tol-exp", type=int, default=32)
    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--cell-fraction", type=float, default=0.20)
    ap.add_argument("--search-cells", type=int, default=16)
    ap.add_argument("--phase-points", type=int, default=65)
    ap.add_argument("--max-subdivision-depth", type=int, default=14)

    ap.add_argument(
        "--x-values",
        default="-16,-12,-8,-6,-5,-4,-3,-2.5,-2,-1.75,-1.5,-1.25,-1,-0.875,-0.75,-0.625,-0.5,-0.375,-0.25,-0.125,0,0.125,0.25,0.5,1,2,4",
    )
    ap.add_argument(
        "--phase-offsets",
        default="0.125,0.25,0.5,0.75",
    )
    ap.add_argument(
        "--success-offsets-needed",
        type=int,
        default=2,
    )
    ap.add_argument(
        "--offset-spread-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--phase-grid-gate",
        type=float,
        default=0.10,
    )
    ap.add_argument(
        "--boundary-signal-gate",
        type=float,
        default=1e-6,
        help="Require endpoint <|eps|>/gamma below this to regard x window as wide enough.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_late_switch_homogenized_mass_v196",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps
    tol = mp.power(10, -args.tol_exp)
    frac = mp.mpf(str(args.cell_fraction))

    mod = importlib.import_module(args.v192_module)

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    switches = [
        int(x.strip()) for x in args.switch_indices.split(",") if x.strip()
    ]
    xs = [
        mp.mpf(x.strip()) for x in args.x_values.split(",") if x.strip()
    ]
    offsets = [
        float(x.strip()) for x in args.phase_offsets.split(",") if x.strip()
    ]

    # Frozen switch-159 reference.
    ref159 = json.loads(Path(args.v195_summary).read_text(encoding="utf-8"))

    print("="*186)
    print("ROT-RH v196 — LATE-SWITCH HOMOGENIZED INTRINSIC-MASS REPLICATION")
    print("="*186)
    print("Xi / zeta / known zeros          : NONE")
    print(f"new switches                      : {switches}")
    print(f"frozen switch-159 K               : {ref159['K_hom']:.12e}")
    print(f"x samples / switch                : {len(xs)}")
    print(f"phase points / cycle              : {args.phase_points}")
    print("="*186)

    profiles = []
    summaries = []

    for sw in switches:
        j = sw-1
        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand, left["beta_active"], left["gamma_active"]
        )
        c2 = match_candidate(
            cand, right["beta_active"], right["gamma_active"]
        )

        b1 = mp.mpf(str(float(c1["beta"])))
        g1 = mp.mpf(str(float(c1["gamma"])))
        b2 = mp.mpf(str(float(c2["beta"])))
        g2 = mp.mpf(str(float(c2["gamma"])))

        ts = mp.mpf(str(float(left["tau_end"])))
        da = abs(b2-b1)
        dg = abs(g2-g1)
        period = 2*mp.pi/dg

        phase = mod.TwoLayerPhase(b1, g1, b2, g2)

        local = []
        unresolved = []

        print()
        print(
            f"[switch {sw}] dg={float(dg):.6e} da={float(da):.6e} "
            f"tau={float(ts):.6e}"
        )

        for ix, x in enumerate(xs, 1):
            tau = ts+x/da
            ga = g1 if x < 0 else g2
            center = ga

            vals = []
            pdiffs = []

            for off in offsets:
                r = cycle_shifted(
                    mod, phase, tau, center, ga, period,
                    args.phase_points, tol, frac,
                    args.newton_iters, args.search_cells,
                    args.max_subdivision_depth, off
                )
                if r is None:
                    continue

                vals.append(float(r["mean_abs_epsilon_over_gamma"]))
                pdiffs.append(float(r["phase_stride2_relative_difference"]))

                if len(vals) >= args.success_offsets_needed:
                    break

            if not vals:
                unresolved.append(float(x))
                print(f"  x={float(x):7.3f} UNRESOLVED")
                continue

            mean = float(np.mean(vals))
            spread = (
                float((np.max(vals)-np.min(vals))/max(abs(mean),1e-300))
                if len(vals) > 1 else 0.0
            )
            max_pdiff = max(pdiffs) if pdiffs else np.nan

            accepted = bool(
                len(vals) >= args.success_offsets_needed
                and spread <= args.offset_spread_gate
                and max_pdiff <= args.phase_grid_gate
            )

            if not accepted:
                unresolved.append(float(x))

            local.append({
                "switch": sw,
                "x": float(x),
                "tau": float(tau),
                "gamma_active": float(ga),
                "mean_abs_epsilon_over_gamma": mean,
                "successful_offsets": len(vals),
                "offset_relative_spread": spread,
                "max_phase_stride2_relative_difference": max_pdiff,
                "accepted": accepted,
            })

            print(
                f"  x={float(x):7.3f} r={mean:.3e} "
                f"off={len(vals)} spread={spread:.2e} "
                f"phase={max_pdiff:.2e} {'OK' if accepted else 'CHECK'}"
            )

        df = pd.DataFrame(local).sort_values("x").reset_index(drop=True)
        profiles.append(df)

        good = df[df["accepted"]].copy()

        if len(good) < 6:
            summaries.append({
                "switch": sw,
                "K_hom": np.nan,
                "verdict": "INSUFFICIENT_ACCEPTED_PROFILE",
                "unresolved_x": unresolved,
            })
            continue

        K = K_from_profile(good, float(dg))
        K2 = K_from_profile(decimated(good, 2), float(dg))
        K4 = K_from_profile(decimated(good, 4), float(dg))

        left_signal = float(good.iloc[0]["mean_abs_epsilon_over_gamma"])
        right_signal = float(good.iloc[-1]["mean_abs_epsilon_over_gamma"])
        boundary_ok = bool(
            left_signal <= args.boundary_signal_gate
            and right_signal <= args.boundary_signal_gate
        )

        I = K*float(dg)/float(da)
        ggeom = float(mp.sqrt(g1*g2))
        R = I/(ggeom*float(ts))

        verdict = (
            "HOMOGENIZED_K_PROFILE_SUPPORTED"
            if len(unresolved) == 0 and boundary_ok
            else "HOMOGENIZED_K_PROFILE_PARTIAL"
        )

        summaries.append({
            "switch": sw,
            "gamma_left": float(g1),
            "gamma_right": float(g2),
            "delta_gamma": float(dg),
            "delta_a": float(da),
            "tau_switch": float(ts),
            "K_hom": K,
            "K_hom_stride2": K2,
            "K_hom_stride4": K4,
            "K_stride2_relative_difference":
                abs(K2-K)/max(abs(K),1e-300),
            "K_stride4_relative_difference":
                abs(K4-K)/max(abs(K),1e-300),
            "I_hom": I,
            "I_over_gamma_geom_tau": R,
            "left_boundary_signal": left_signal,
            "right_boundary_signal": right_signal,
            "boundary_ok": boundary_ok,
            "unresolved_x": unresolved,
            "verdict": verdict,
        })

        print(
            f"  => K={K:.6e} K2={K2:.6e} K4={K4:.6e} "
            f"I/(g*tau)={R:.3e} boundary_ok={boundary_ok}"
        )

    allprof = pd.concat(profiles, ignore_index=True) if profiles else pd.DataFrame()
    swdf = pd.DataFrame(summaries)

    # Append frozen switch159 reference for scaling table.
    row159 = {
        "switch": 159,
        "gamma_left": ref159["gamma_left"],
        "gamma_right": ref159["gamma_right"],
        "delta_gamma": ref159["delta_gamma"],
        "delta_a": ref159["delta_a"],
        "tau_switch": ref159["tau_switch"],
        "K_hom": ref159["K_hom"],
        "K_hom_stride2": ref159["K_hom_stride2"],
        "K_hom_stride4": ref159["K_hom_stride4"],
        "K_stride2_relative_difference":
            ref159["K_stride2_relative_difference"],
        "K_stride4_relative_difference":
            ref159["K_stride4_relative_difference"],
        "I_hom": ref159["I_hom_tau_integral"],
        "I_over_gamma_geom_tau": ref159["I_over_gamma_geom_tau"],
        "left_boundary_signal": np.nan,
        "right_boundary_signal": np.nan,
        "boundary_ok": True,
        "unresolved_x": [],
        "verdict": "FROZEN_V195_REFERENCE",
    }

    comp = pd.concat(
        [swdf, pd.DataFrame([row159])],
        ignore_index=True
    ).sort_values("switch")

    finite = comp[np.isfinite(comp["K_hom"])].copy()
    Kvals = finite["K_hom"].to_numpy(float)

    if len(Kvals) >= 3:
        Kmax = float(np.max(Kvals))
        Kmin = float(np.min(Kvals))
        Kratio = Kmax/max(Kmin,1e-300)
    else:
        Kmax = Kmin = Kratio = np.nan

    if len(Kvals) >= 3 and Kmax < 5.0:
        final_verdict = "LATE_SWITCH_HOMOGENIZED_K_O1_SUPPORTED"
    else:
        final_verdict = "LATE_SWITCH_HOMOGENIZED_K_SCALING_UNRESOLVED"

    allprof.to_csv(args.prefix+"_PROFILES.csv", index=False)
    comp.to_csv(args.prefix+"_SWITCHES.csv", index=False)

    summary = {
        "version": 196,
        "switches": finite["switch"].astype(int).tolist(),
        "K_values": finite["K_hom"].tolist(),
        "K_min": Kmin,
        "K_max": Kmax,
        "K_max_over_min": Kratio,
        "verdict": final_verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*186)
    for _, r in comp.iterrows():
        print(
            f"switch {int(r['switch']):3d} "
            f"K={r['K_hom']:.6e} "
            f"I/(g*tau)={r['I_over_gamma_geom_tau']:.6e} "
            f"[{r['verdict']}]"
        )
    print(f"K min / max / ratio               : {Kmin:.6e} / {Kmax:.6e} / {Kratio:.6e}")
    print(f"VERDICT                            : {final_verdict}")
    print("="*186)


if __name__ == "__main__":
    main()
