#!/usr/bin/env python3
"""
ROT-RH v182 — EXACT SWITCH-ERROR DECOMPOSITION AUDIT

Purpose
-------
After v181 showed small Cesaro switch errors even at the highest audited
scales, v182 decomposes the exact phase-cell error

    epsilon = d(tau E)/dtau - gamma_active

into three algebraically exact pieces.

For the scaled Gamma-phase terms z_j define

    R = Re sum z_j
    G = sum gamma_j Re z_j
    A = sum a_j Im z_j
    Q = Im sum i*psi(w_j)*z_j,

where
    a_j = beta_j - 1/2,
    w_j = a_j + i(E-gamma_j),
    psi = digamma.

Then

    S_E = tau*R + Q,

and

    S_tau = E*R - G + A.

Therefore, along the implicit root,

    d(tau E)/dtau
      = E - tau*S_tau/S_E,

so EXACTLY

    epsilon
      = [ tau*(G-gamma_active*R)
          - tau*A
          + Q*(E-gamma_active) ]
        / (tau*R+Q).

Thus

    epsilon = epsilon_mix + epsilon_A + epsilon_digamma

with

    epsilon_mix      = tau*(G-gamma_active*R)/D
    epsilon_A        = -tau*A/D
    epsilon_digamma  = Q*(E-gamma_active)/D
    D                = tau*R+Q.

This script recomputes those terms at existing high-precision v181 sample
points.  It does NO continuation and is therefore fast.

Inputs
------
--candidates-csv
--hull-csv
--samples-csv
    Comma-separated list of one or more v181 *_SAMPLES.csv files.

Outputs
-------
<prefix>_POINTS.csv
<prefix>_SWITCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


class ExactPhaseDecomposition:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []

        for b, gg in [(b1, g1), (b2, g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b-mp.mpf("0.5")

            # rho, conjugate, functional mirror, mirror conjugate
            self.a += [a, a, -a, -a]
            self.g += [gg, -gg, gg, -gg]

    def evaluate(self, E, tau, gamma_active):
        E = mp.mpf(str(E))
        tau = mp.mpf(str(tau))
        ga = mp.mpf(str(gamma_active))

        ws = []
        logs = []

        for a, g in zip(self.a, self.g):
            w = a + 1j*(E-g)
            ws.append(w)
            logs.append(
                mp.loggamma(w)
                + a*tau
                + 1j*(E-g)*tau
            )

        shift = max(mp.re(z) for z in logs)
        zs = [mp.exp(z-shift) for z in logs]

        # Basic exact phase quantities.
        Z = mp.fsum(zs)
        S = mp.im(Z)

        R = mp.re(Z)
        G = mp.fsum(
            g*mp.re(z)
            for g, z in zip(self.g, zs)
        )
        A = mp.fsum(
            a*mp.im(z)
            for a, z in zip(self.a, zs)
        )

        Q = mp.im(mp.fsum(
            1j*mp.digamma(w)*z
            for w, z in zip(ws, zs)
        ))

        D = tau*R + Q

        # Direct derivatives for an independent identity check.
        SE_direct = mp.im(mp.fsum(
            1j*(mp.digamma(w)+tau)*z
            for w, z in zip(ws, zs)
        ))
        St_direct = mp.im(mp.fsum(
            w*z
            for w, z in zip(ws, zs)
        ))

        Yt_direct = E - tau*St_direct/SE_direct
        eps_direct = Yt_direct-ga

        eps_mix = tau*(G-ga*R)/D
        eps_A = -tau*A/D
        eps_dig = Q*(E-ga)/D
        eps_sum = eps_mix+eps_A+eps_dig

        # Conditioning / asymptotic diagnostics.
        q_over_tauR = (
            abs(Q)/(tau*abs(R))
            if R != 0 else mp.inf
        )
        soft_gamma = (
            G/R if R != 0 else mp.nan
        )

        # Independent algebra identities.
        SE_identity_resid = abs(SE_direct-D)
        St_formula = E*R-G+A
        St_identity_resid = abs(St_direct-St_formula)
        eps_identity_resid = abs(eps_direct-eps_sum)

        return {
            "S_abs": abs(S),
            "R": R,
            "G": G,
            "A": A,
            "Q": Q,
            "D": D,
            "soft_gamma": soft_gamma,
            "q_over_tauR": q_over_tauR,
            "SE_abs": abs(SE_direct),
            "SE_identity_resid": SE_identity_resid,
            "St_identity_resid": St_identity_resid,
            "epsilon_direct": eps_direct,
            "epsilon_mix": eps_mix,
            "epsilon_A": eps_A,
            "epsilon_digamma": eps_dig,
            "epsilon_sum": eps_sum,
            "epsilon_identity_resid": eps_identity_resid,
            "Yt_direct": Yt_direct,
        }


def trapezoid(x, y):
    return float(
        np.trapezoid(
            np.asarray(y, float),
            np.asarray(x, float)
        )
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument(
        "--samples-csv",
        required=True,
        help="Comma-separated v181 *_SAMPLES.csv files.",
    )
    ap.add_argument("--dps", type=int, default=70)
    ap.add_argument(
        "--identity-gate",
        type=float,
        default=1e-25,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_switch_error_decomposition_v182",
    )

    args = ap.parse_args()

    mp.mp.dps = args.dps

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    sample_files = [
        x.strip()
        for x in args.samples_csv.split(",")
        if x.strip()
    ]

    frames = []
    for f in sample_files:
        p = Path(f)
        if not p.exists():
            raise FileNotFoundError(f)
        d = pd.read_csv(p)
        d["source_file"] = p.name
        frames.append(d)

    if not frames:
        raise RuntimeError("No sample files supplied.")

    samples = pd.concat(frames, ignore_index=True)

    required = {"switch", "tau", "E"}
    if not required.issubset(samples.columns):
        raise RuntimeError(
            f"Sample CSVs need columns {sorted(required)}."
        )

    # Normalize gamma-active column name.
    if "gamma_active" in samples.columns:
        samples["_gamma_active_input"] = samples["gamma_active"]
    elif "gamma_active_local" in samples.columns:
        samples["_gamma_active_input"] = samples["gamma_active_local"]
    else:
        samples["_gamma_active_input"] = np.nan

    # Drop duplicate points if same switch was present in multiple files.
    samples = (
        samples
        .sort_values(["switch", "tau"])
        .drop_duplicates(["switch", "tau"], keep="last")
        .reset_index(drop=True)
    )

    print("="*174)
    print("ROT-RH v182 — EXACT SWITCH-ERROR DECOMPOSITION AUDIT")
    print("="*174)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate layers                  : {len(cand)}")
    print(f"active hull segments              : {len(hull)}")
    print(f"sample files                      : {len(sample_files)}")
    print(f"sample rows                       : {len(samples)}")
    print(f"switches                          : {sorted(samples['switch'].astype(int).unique().tolist())}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*174)

    point_rows = []
    switch_rows = []

    phases = {}

    for _, r in samples.iterrows():
        sw = int(r["switch"])
        j = sw-1

        if j < 0 or j+1 >= len(hull):
            raise ValueError(f"Switch {sw} outside hull.")

        left = hull.iloc[j]
        right = hull.iloc[j+1]

        c1 = match_candidate(
            cand,
            left["beta_active"],
            left["gamma_active"],
        )
        c2 = match_candidate(
            cand,
            right["beta_active"],
            right["gamma_active"],
        )

        b1 = float(c1["beta"])
        g1 = float(c1["gamma"])
        b2 = float(c2["beta"])
        g2 = float(c2["gamma"])

        key = (sw, b1, g1, b2, g2)
        if key not in phases:
            phases[key] = ExactPhaseDecomposition(
                b1, g1, b2, g2
            )
        phase = phases[key]

        tau = float(r["tau"])
        E = float(r["E"])
        ts = float(left["tau_end"])
        ga = g1 if tau <= ts else g2

        dec = phase.evaluate(E, tau, ga)

        out = {
            "switch": sw,
            "tau": tau,
            "tau_switch": ts,
            "E": E,
            "gamma_active": ga,
            "gamma_left": g1,
            "gamma_right": g2,
            "source_file": r["source_file"],
        }

        for k, v in dec.items():
            try:
                out[k] = float(v)
            except Exception:
                out[k] = np.nan

        scale = max(abs(ga), 1.0)
        out["abs_epsilon_over_gamma"] = abs(
            out["epsilon_direct"]
        )/scale
        out["abs_mix_over_gamma"] = abs(
            out["epsilon_mix"]
        )/scale
        out["abs_A_over_gamma"] = abs(
            out["epsilon_A"]
        )/scale
        out["abs_digamma_over_gamma"] = abs(
            out["epsilon_digamma"]
        )/scale

        point_rows.append(out)

    pts = (
        pd.DataFrame(point_rows)
        .sort_values(["switch", "tau"])
        .reset_index(drop=True)
    )

    for sw, g in pts.groupby("switch"):
        g = g.sort_values("tau")

        tau = g["tau"].to_numpy(float)
        active = g["gamma_active"].to_numpy(float)

        e = g["epsilon_direct"].to_numpy(float)
        em = g["epsilon_mix"].to_numpy(float)
        ea = g["epsilon_A"].to_numpy(float)
        ed = g["epsilon_digamma"].to_numpy(float)

        active_int = trapezoid(tau, active)

        abs_total = trapezoid(tau, np.abs(e))
        abs_mix = trapezoid(tau, np.abs(em))
        abs_A = trapezoid(tau, np.abs(ea))
        abs_dig = trapezoid(tau, np.abs(ed))

        signed_total = trapezoid(tau, e)
        signed_mix = trapezoid(tau, em)
        signed_A = trapezoid(tau, ea)
        signed_dig = trapezoid(tau, ed)

        denom = max(abs(active_int), 1e-300)

        components = {
            "mix": abs_mix,
            "A": abs_A,
            "digamma": abs_dig,
        }
        dominant = max(components, key=components.get)

        rr = {
            "switch": int(sw),
            "samples": len(g),
            "tau_min": float(tau.min()),
            "tau_max": float(tau.max()),
            "gamma_left": float(g.iloc[0]["gamma_left"]),
            "gamma_right": float(g.iloc[0]["gamma_right"]),
            "active_integral": active_int,
            "signed_total_over_active": signed_total/denom,
            "absolute_total_over_active": abs_total/denom,
            "absolute_mix_over_active": abs_mix/denom,
            "absolute_A_over_active": abs_A/denom,
            "absolute_digamma_over_active": abs_dig/denom,
            "signed_mix_over_active": signed_mix/denom,
            "signed_A_over_active": signed_A/denom,
            "signed_digamma_over_active": signed_dig/denom,
            "dominant_component": dominant,
            "max_q_over_tauR": float(
                g["q_over_tauR"].replace(
                    [np.inf, -np.inf], np.nan
                ).max()
            ),
            "max_abs_epsilon_over_gamma": float(
                g["abs_epsilon_over_gamma"].max()
            ),
            "max_identity_residual": float(
                g["epsilon_identity_resid"].max()
            ),
            "max_phase_residual": float(
                g["S_abs"].max()
            ),
        }

        switch_rows.append(rr)

        print(
            f"[switch {int(sw):4d}] "
            f"|eps|/active={rr['absolute_total_over_active']:.3e} "
            f"mix={rr['absolute_mix_over_active']:.3e} "
            f"A={rr['absolute_A_over_active']:.3e} "
            f"dig={rr['absolute_digamma_over_active']:.3e} "
            f"dominant={dominant} "
            f"Q/(tau R)<={rr['max_q_over_tauR']:.3e}"
        )

    swdf = pd.DataFrame(switch_rows)

    max_identity = float(
        pts["epsilon_identity_resid"].max()
    )
    identity_pass = bool(
        max_identity <= args.identity_gate
    )

    # Across audited switches, identify which analytic term carries most L1 mass.
    totals = {
        "mix": float(swdf["absolute_mix_over_active"].sum()),
        "A": float(swdf["absolute_A_over_active"].sum()),
        "digamma": float(
            swdf["absolute_digamma_over_active"].sum()
        ),
    }
    dominant_global = max(totals, key=totals.get)

    verdict = (
        "EXACT_DECOMPOSITION_VERIFIED"
        if identity_pass
        else "DECOMPOSITION_IDENTITY_NUMERIC_WARNING"
    )

    pts.to_csv(
        args.prefix+"_POINTS.csv",
        index=False,
    )
    swdf.to_csv(
        args.prefix+"_SWITCHES.csv",
        index=False,
    )

    summary = {
        "version": 182,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "switches": [
            int(x)
            for x in sorted(
                pts["switch"].unique().tolist()
            )
        ],
        "max_epsilon_identity_residual": max_identity,
        "identity_gate": args.identity_gate,
        "identity_pass": identity_pass,
        "aggregate_component_scores": totals,
        "dominant_global_component": dominant_global,
        "verdict": verdict,
    }

    Path(
        args.prefix+"_SUMMARY.json"
    ).write_text(
        json.dumps(
            native(summary),
            indent=2,
            allow_nan=True,
        ),
        encoding="utf-8",
    )

    print()
    print("="*174)
    print(f"max epsilon identity residual      : {max_identity:.6e}")
    print(f"identity gate                      : {args.identity_gate:.6e}")
    print(f"identity pass                      : {identity_pass}")
    print(f"aggregate mix score                : {totals['mix']:.6e}")
    print(f"aggregate A score                  : {totals['A']:.6e}")
    print(f"aggregate digamma score            : {totals['digamma']:.6e}")
    print(f"dominant analytic component        : {dominant_global}")
    print(f"VERDICT                            : {verdict}")
    print("="*174)

    print("NEXT ANALYTIC TARGET:")
    if dominant_global == "mix":
        print("  Bound the soft two-layer gamma mixing term")
        print("      tau*(G-gamma_active*R)/(tau*R+Q)")
        print("  and show its switch-integrated mass is Cesaro-negligible.")
    elif dominant_global == "A":
        print("  Bound the beta-offset / imaginary-amplitude term")
        print("      -tau*A/(tau*R+Q)")
        print("  uniformly through dominance switches.")
    else:
        print("  Bound the digamma correction")
        print("      Q*(E-gamma_active)/(tau*R+Q)")
        print("  using asymptotics for psi(w) and denominator transversality.")


if __name__ == "__main__":
    main()
