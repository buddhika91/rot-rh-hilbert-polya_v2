#!/usr/bin/env python3
"""
ROT-RH v168 — DYADIC BLOCK INTERIOR-DIAMETER AUDIT

ZERO-COST postprocessor.

Purpose
-------
v167 strongly supported decay of dyadic endpoint increments

    D_j = ||lambda(2L_j)-lambda(L_j)||_1,

on the fixed finite block.

To pass from a dyadic subsequence to arbitrary cutoffs, Lemma 1 also needs
control inside each dyadic interval [L,2L].

The existing moving-root trajectory already contains the sqrt(2)-midpoint
for every exact dyadic block:

       L  ->  ~sqrt(2)L  ->  2L.

v168 therefore computes the discrete three-point block diameter

    B_j = max {
              ||lambda(M)-lambda(L)||_1,
              ||lambda(2L)-lambda(M)||_1,
              ||lambda(2L)-lambda(L)||_1
            },

with M the existing sqrt(2)-midpoint.

It also computes the midpoint excursion relative to the endpoint chord and
fits the block diameter to

    B_j ~ C L^{-alpha}.

If B_j contracts with a positive exponent, then the numerical evidence
supports BOTH parts of the dyadic Lemma-1 architecture:

    (A) dyadic endpoint convergence;
    (B) shrinking within-block diameter.

NO Xi / zeta / known-zero data.
NO phase builds, prime sums, or root solves.

Outputs
-------
<prefix>_BLOCKS.csv
<prefix>_MODES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def fit_power(L, y):
    L = np.asarray(L, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (L > 0) & (y > 0) & np.isfinite(y)

    X = np.log(L[mask])
    Y = np.log(y[mask])

    if len(X) < 2:
        return np.nan, np.nan, np.nan

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    alpha = float(-coef[1])
    C = float(math.exp(coef[0]))

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, C, r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--roots-npz",
        default="rot_rh_prospective_dyadic_holdout_v167_ROOTS.npz",
    )
    ap.add_argument("--modes", type=int, default=32)

    ap.add_argument(
        "--dyadic-left",
        default="512000,1024000,2048000,4096000,8192000",
    )
    ap.add_argument(
        "--midpoints",
        default="724077,1448155,2896310,5792619,11585238",
    )

    ap.add_argument(
        "--minimum-alpha",
        type=float,
        default=0.02,
    )
    ap.add_argument(
        "--minimum-r2",
        type=float,
        default=0.85,
    )
    ap.add_argument(
        "--latest-ratio-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--minimum-modal-diameter-contraction-fraction",
        type=float,
        default=0.50,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_dyadic_block_interior_v168",
    )

    args = ap.parse_args()

    z = np.load(args.roots_npz)
    Lnet = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    n = min(args.modes, roots.shape[1])
    roots = roots[:, :n]
    lam = roots**(-2)

    lefts = csv_ints(args.dyadic_left)
    mids = csv_ints(args.midpoints)

    if len(lefts) != len(mids):
        raise RuntimeError("Need one midpoint for each dyadic left endpoint.")

    root_map = {}
    lam_map = {}

    for L in set(lefts + mids + [2*x for x in lefts]):
        hit = np.where(Lnet == L)[0]
        if not len(hit):
            raise RuntimeError(f"Required cutoff {L} missing from roots NPZ.")
        idx = int(hit[0])
        root_map[L] = roots[idx]
        lam_map[L] = lam[idx]

    print("=" * 150)
    print("ROT-RH v168 — DYADIC BLOCK INTERIOR-DIAMETER AUDIT")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"modes                             : 1..{n}")
    print(f"dyadic left endpoints             : {lefts}")
    print(f"sqrt(2) midpoints                 : {mids}")
    print("=" * 150)

    block_rows = []
    modal_block_diameters = []

    for j,(L,M) in enumerate(zip(lefts,mids)):
        R = 2*L

        lL = lam_map[L]
        lM = lam_map[M]
        lR = lam_map[R]

        LM = float(np.sum(np.abs(lM-lL)))
        MR = float(np.sum(np.abs(lR-lM)))
        LR = float(np.sum(np.abs(lR-lL)))

        diameter = max(LM,MR,LR)

        modal_diam = np.maximum.reduce([
            np.abs(lM-lL),
            np.abs(lR-lM),
            np.abs(lR-lL),
        ])
        modal_block_diameters.append(modal_diam)

        # Distance of midpoint from the linear chord midpoint in lambda-space.
        chord_mid = 0.5*(lL+lR)
        midpoint_excursion = float(np.sum(np.abs(lM-chord_mid)))

        # Triangle excess measures micromotion relative to direct endpoint move.
        triangle_excess = LM + MR - LR
        cancellation_factor = (LM+MR)/max(LR,1e-300)

        row = dict(
            block=j+1,
            L=L,
            M=M,
            R=R,
            midpoint_ratio=float(M/L),
            left_mid_l1=LM,
            mid_right_l1=MR,
            endpoint_l1=LR,
            block_diameter_l1=diameter,
            midpoint_chord_excursion_l1=midpoint_excursion,
            triangle_excess_l1=triangle_excess,
            cancellation_factor=cancellation_factor,
            max_modal_block_diameter=float(np.max(modal_diam)),
            median_modal_block_diameter=float(np.median(modal_diam)),
        )

        if j == 0:
            row["diameter_ratio"] = np.nan
            row["endpoint_ratio"] = np.nan
            row["excursion_ratio"] = np.nan
        else:
            prev = block_rows[-1]
            row["diameter_ratio"] = (
                diameter/max(prev["block_diameter_l1"],1e-300)
            )
            row["endpoint_ratio"] = (
                LR/max(prev["endpoint_l1"],1e-300)
            )
            row["excursion_ratio"] = (
                midpoint_excursion/
                max(prev["midpoint_chord_excursion_l1"],1e-300)
            )

        block_rows.append(row)

    B = np.array([r["block_diameter_l1"] for r in block_rows],dtype=float)
    D = np.array([r["endpoint_l1"] for r in block_rows],dtype=float)
    X = np.array(
        [r["midpoint_chord_excursion_l1"] for r in block_rows],
        dtype=float
    )
    Larr = np.array(lefts,dtype=float)

    alpha_B,C_B,r2_B = fit_power(Larr,B)
    alpha_D,C_D,r2_D = fit_power(Larr,D)
    alpha_X,C_X,r2_X = fit_power(Larr,X)

    latest_ratio = float(B[-1]/B[-2])

    modal_block_diameters = np.vstack(modal_block_diameters)

    mode_rows = []

    for k in range(n):
        vals = modal_block_diameters[:,k]
        alpha_k,_,r2_k = fit_power(Larr,vals)

        latest_ratio_k = float(vals[-1]/max(vals[-2],1e-300))

        mode_rows.append(dict(
            k=k+1,
            first_block_diameter=float(vals[0]),
            latest_block_diameter=float(vals[-1]),
            latest_over_first=float(vals[-1]/max(vals[0],1e-300)),
            latest_ratio=latest_ratio_k,
            latest_contracts=bool(vals[-1] < vals[-2]),
            power_alpha=alpha_k,
            power_R2=r2_k,
        ))

    modes_df = pd.DataFrame(mode_rows)

    modal_contract_fraction = float(
        np.mean(modes_df["latest_contracts"].to_numpy(dtype=bool))
    )
    positive_modal_alpha_fraction = float(
        np.mean(modes_df["power_alpha"].to_numpy(dtype=float)>0)
    )

    block_pass = bool(
        alpha_B > args.minimum_alpha
        and r2_B >= args.minimum_r2
        and latest_ratio < args.latest_ratio_gate
        and modal_contract_fraction
            >= args.minimum_modal_diameter_contraction_fraction
    )

    if block_pass:
        verdict = "DYADIC_INTERMEDIATE_BLOCK_DIAMETER_STRONGLY_SUPPORTED"
    else:
        verdict = "DYADIC_INTERMEDIATE_BLOCK_DIAMETER_UNRESOLVED"

    pd.DataFrame(block_rows).to_csv(
        args.prefix+"_BLOCKS.csv",index=False
    )
    modes_df.to_csv(
        args.prefix+"_MODES.csv",index=False
    )

    summary = dict(
        version=168,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        modes=n,
        blocks=block_rows,
        fits=dict(
            block_diameter=dict(alpha=alpha_B,R2=r2_B,C=C_B),
            endpoint=dict(alpha=alpha_D,R2=r2_D,C=C_D),
            midpoint_excursion=dict(alpha=alpha_X,R2=r2_X,C=C_X),
        ),
        latest_block_diameter_ratio=latest_ratio,
        modal_latest_contraction_fraction=modal_contract_fraction,
        positive_modal_alpha_fraction=positive_modal_alpha_fraction,
        verdict=verdict,
        theorem_target=(
            "For fixed N prove both: "
            "(i) dyadic endpoint increments tend to zero with enough control, "
            "and (ii) sup_{L<=M<=2L} ||lambda(M)-lambda(L)||_1 -> 0. "
            "The current three-point block diameter is a numerical proxy for (ii)."
        ),
    )

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o,np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    print()
    print("Dyadic three-point block diameters")
    print("-"*150)
    print(
        f"{'block':>6} {'L':>10} {'mid':>10} {'2L':>10} "
        f"{'L-mid':>13} {'mid-2L':>13} {'L-2L':>13} "
        f"{'diam':>13} {'ratio':>9} {'cancel':>9}"
    )

    for r in block_rows:
        print(
            f"{r['block']:6d} "
            f"{r['L']:10d} "
            f"{r['M']:10d} "
            f"{r['R']:10d} "
            f"{r['left_mid_l1']:13.6e} "
            f"{r['mid_right_l1']:13.6e} "
            f"{r['endpoint_l1']:13.6e} "
            f"{r['block_diameter_l1']:13.6e} "
            f"{r['diameter_ratio']:9.6f} "
            f"{r['cancellation_factor']:9.4f}"
        )

    print()
    print("Worst latest modal block-diameter ratios")
    print("-"*150)
    worst = modes_df.sort_values(
        "latest_ratio",ascending=False
    ).head(min(16,n))

    print(
        f"{'k':>4} {'first':>14} {'latest':>14} "
        f"{'latest/first':>13} {'latest r':>10} "
        f"{'alpha':>10} {'R2':>8}"
    )

    for _,r in worst.iterrows():
        print(
            f"{int(r['k']):4d} "
            f"{r['first_block_diameter']:14.6e} "
            f"{r['latest_block_diameter']:14.6e} "
            f"{r['latest_over_first']:13.6f} "
            f"{r['latest_ratio']:10.6f} "
            f"{r['power_alpha']:10.6f} "
            f"{r['power_R2']:8.4f}"
        )

    print()
    print("="*150)
    print(f"block-diameter alpha              : {alpha_B:.9f}")
    print(f"block-diameter R2                 : {r2_B:.6f}")
    print(f"endpoint alpha                    : {alpha_D:.9f}")
    print(f"endpoint R2                       : {r2_D:.6f}")
    print(f"midpoint-excursion alpha          : {alpha_X:.9f}")
    print(f"midpoint-excursion R2             : {r2_X:.6f}")
    print(f"latest block-diameter ratio       : {latest_ratio:.9f}")
    print(f"modal latest contraction fraction : {modal_contract_fraction:.6f}")
    print(f"positive modal-alpha fraction     : {positive_modal_alpha_fraction:.6f}")
    print(f"VERDICT                           : {verdict}")
    print("="*150)
    print("LEMMA-1 NUMERICAL STOPPING RULE:")
    print("  If this passes alongside v167, both the dyadic endpoint and")
    print("  within-block pieces are numerically supported. Further cutoff")
    print("  extension is no longer the priority; the next work is analytic.")


if __name__ == "__main__":
    main()
