#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v121 — Preregistered Blind Prime–Gamma Phase-Lock Replication
====================================================================

BACKGROUND
----------
v120 (post-hoc on k=48..767) found:
  * finite-part AC+counter defects almost exactly cancel;
  * prime and Gamma/arch defects individually have O(1e-1) cumulative drift;
  * their ACTUAL index alignment reduces the cumulative defect to O(1e-2);
  * shift=0 was the best of all 720 circular alignments for cumulative drift;
  * the first two DFT modes were almost perfectly anti-phased and amplitude
    matched.

v121 freezes that mechanism BEFORE computing any new cells.

FRESH BLIND REGION
------------------
    W1 = 768..927    (160 unseen cells)
    W2 = 928..1087   (160 unseen cells)
    Combined = 768..1087 (320 unseen cells)

PREREGISTERED SCIENTIFIC GATES
------------------------------
Numerical:
  root residual < 1e-8
  counterterm qphase/qder < 5e-6
  cell integration qcheck < 1e-8

Mechanism:
  finite-part ||q_AC+q_counter||/||q_total|| <= 1e-3

For EACH 160-cell window:
  prime–Gamma cumulative cancellation ratio <= 0.30
  actual circular-shift cumulative percentile <= 0.05

For combined 320 cells:
  prime–Gamma cumulative cancellation ratio <= 0.20
  actual circular-shift cumulative percentile <= 0.01
  random-permutation cumulative percentile <= 0.01
  random-permutation low-frequency percentile <= 0.01
  DFT bins 1 and 2:
      phase cosine <= -0.90
      cancellation ratio <= 0.25

All thresholds are written into PREFREEZE.json before support construction.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import digamma

VERSION = "v121"
BUILD = "2026-08-17-preregistered-blind-prime-gamma-phase-lock-v121"
EPS = 1e-30


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def q_total_cell(phase, lo, hi, k, q):
    E, W = nodes(float(lo), float(hi), int(q))
    F = np.asarray(phase.F(E), float)
    Q = F - float(k)
    return {
        "q": float(np.sum(W * Q)),
        "max_abs_Q": float(np.max(np.abs(Q))),
        "abs_q_integral": float(np.sum(W * np.abs(Q))),
    }


def q_from_fprime(func, lo, hi, q):
    E, W = nodes(float(lo), float(hi), int(q))
    mid = 0.5 * (float(lo) + float(hi))
    fp = np.asarray(func(E), float)
    return float(-np.sum(W * (E - mid) * fp))


def arch_fprime(E):
    E = np.asarray(E, float)
    return (
        np.real(digamma(0.25 + 0.5j * E)) - math.log(math.pi)
    ) / (2.0 * math.pi)


def ac_fprime(E):
    E = np.asarray(E, float)
    w = math.log(2.0)
    Aprime = -math.sqrt(2.0) * (
        E * np.sin(w * E) + 0.5 * np.cos(w * E)
    ) / (E * E + 0.25)
    return -Aprime / math.pi


def prime_endpoint_functions(Evals, phase_w, logs, chunk_terms):
    Evals = np.asarray(Evals, float)
    phase_w = np.asarray(phase_w, float)
    logs = np.asarray(logs, float)

    Fprime_phase = np.zeros(len(Evals), float)
    anti = np.zeros(len(Evals), float)

    n = len(logs)
    for s in range(0, n, int(chunk_terms)):
        e = min(n, s + int(chunk_terms))
        lg = logs[s:e]
        ww = phase_w[s:e]
        ang = Evals[:, None] * lg[None, :]

        Fprime_phase += -np.sum(
            np.sin(ang) * ww[None, :], axis=1
        ) / math.pi
        anti += np.sum(
            np.cos(ang) * (ww / lg)[None, :], axis=1
        ) / math.pi

    return Fprime_phase, anti


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def alignment_metrics(qp, qa, lowfreq_bins, permutations, rng):
    qp = np.asarray(qp, float)
    qa = np.asarray(qa, float)
    actual = qp + qa

    pcum = cumulative_max(qp)
    acum = cumulative_max(qa)
    tcum = cumulative_max(actual)
    cancel_ratio = tcum / max(pcum + acum, EPS)

    # all circular shifts
    sc = np.empty(len(qp), float)
    sl = np.empty(len(qp), float)
    for s in range(len(qp)):
        x = qp + np.roll(qa, s)
        sc[s] = cumulative_max(x)
        sl[s] = lowfreq_fraction(x, lowfreq_bins)

    shift_c_pct = percentile_le(sc, sc[0])
    shift_l_pct = percentile_le(sl, sl[0])

    # random permutations
    rc = np.empty(int(permutations), float)
    rl = np.empty(int(permutations), float)
    for t in range(int(permutations)):
        x = qp + rng.permutation(qa)
        rc[t] = cumulative_max(x)
        rl[t] = lowfreq_fraction(x, lowfreq_bins)

    perm_c_pct = percentile_le(rc, tcum)
    actual_lowf = lowfreq_fraction(actual, lowfreq_bins)
    perm_l_pct = percentile_le(rl, actual_lowf)

    # low-frequency bins
    P = np.fft.rfft(qp - np.mean(qp))
    A = np.fft.rfft(qa - np.mean(qa))
    T = P + A
    freq = []
    for j in range(1, min(lowfreq_bins, len(P) - 1) + 1):
        den = abs(P[j]) + abs(A[j])
        freq.append({
            "bin": j,
            "prime_amp": float(abs(P[j])),
            "arch_amp": float(abs(A[j])),
            "combined_amp": float(abs(T[j])),
            "cancellation_ratio": float(abs(T[j]) / max(den, EPS)),
            "phase_cosine": float(
                np.real(P[j] * np.conj(A[j]))
                / max(abs(P[j]) * abs(A[j]), EPS)
            ),
            "prime_to_arch_amp_ratio": float(
                abs(P[j]) / max(abs(A[j]), EPS)
            ),
        })

    return {
        "prime_cumulative_max": pcum,
        "arch_cumulative_max": acum,
        "combined_cumulative_max": tcum,
        "cumulative_cancellation_ratio": cancel_ratio,
        "combined_lowfreq_fraction": actual_lowf,
        "shift_cumulative_percentile": shift_c_pct,
        "shift_lowfreq_percentile": shift_l_pct,
        "shift_best_cumulative": float(np.min(sc)),
        "shift_best_index": int(np.argmin(sc)),
        "shift_median_cumulative": float(np.median(sc[1:] if len(sc) > 1 else sc)),
        "perm_cumulative_percentile": perm_c_pct,
        "perm_lowfreq_percentile": perm_l_pct,
        "perm_cumulative_mean": float(np.mean(rc)),
        "freq": freq,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--blind-start", type=int, default=768)
    ap.add_argument("--window-size", type=int, default=160)
    ap.add_argument("--blind-windows", type=int, default=2)
    ap.add_argument("--max-depth", type=int, default=1088)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=6144)
    ap.add_argument("--counter-qcheck", type=int, default=12288)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--cell-q", type=int, default=64)
    ap.add_argument("--cell-qcheck", type=int, default=128)
    ap.add_argument("--component-q", type=int, default=32)
    ap.add_argument("--component-qcheck", type=int, default=64)
    ap.add_argument("--prime-chunk-terms", type=int, default=2048)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument(
        "--prefix",
        default="rot_rh_blind_prime_gamma_phase_lock_v121",
    )
    args = ap.parse_args()

    # Frozen design.
    if args.blind_start != 768:
        raise ValueError("v121 is frozen for blind-start=768.")
    if args.window_size != 160 or args.blind_windows != 2:
        raise ValueError("v121 is frozen for two 160-cell windows.")

    windows = [
        (768, 927),
        (928, 1087),
    ]
    combined = (768, 1087)
    if args.max_depth < 1088:
        raise ValueError("Need max-depth >=1088.")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    try:
        code_path = Path(__file__).resolve()
        code_sha = sha256_file(code_path)
    except Exception:
        code_path = None
        code_sha = None

    prereg = {
        "version": VERSION,
        "build": BUILD,
        "scientific_preregistration": True,
        "created_before_blind_support": True,
        "code_path": str(code_path) if code_path else None,
        "code_sha256": code_sha,
        "L": int(args.L),
        "prior_data_boundary": 767,
        "fresh_windows": [list(x) for x in windows],
        "combined_window": list(combined),
        "hypothesis": (
            "The adaptive spectral mesh exhibits a persistent very-low-frequency "
            "prime–Gamma phase lock: q_prime and q_arch are specifically aligned "
            "so their cumulative trapezoid defects cancel far more strongly "
            "than circular-shift or random-permutation controls."
        ),
        "scientific_gates": {
            "finite_part_rel_l2": "<=1e-3",
            "W1_cancellation_ratio": "<=0.30",
            "W1_shift_cumulative_percentile": "<=0.05",
            "W2_cancellation_ratio": "<=0.30",
            "W2_shift_cumulative_percentile": "<=0.05",
            "combined_cancellation_ratio": "<=0.20",
            "combined_shift_cumulative_percentile": "<=0.01",
            "combined_permutation_cumulative_percentile": "<=0.01",
            "combined_permutation_lowfreq_percentile": "<=0.01",
            "combined_bin1_phase_cosine": "<=-0.90",
            "combined_bin2_phase_cosine": "<=-0.90",
            "combined_bin1_cancellation_ratio": "<=0.25",
            "combined_bin2_cancellation_ratio": "<=0.25",
        },
        "numerical_gates": {
            "root_residual": "<1e-8",
            "counterterm_qphase_qder": "<5e-6",
            "cell_qcheck": "<1e-8",
            "component_qcheck": "<1e-8",
        },
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
    }
    prefreeze_path = Path(str(prefix) + "_PREFREEZE.json")
    prefreeze_path.write_text(json.dumps(prereg, indent=2), encoding="utf-8")
    prefreeze_sha = sha256_file(prefreeze_path)

    print("=" * 164)
    print("ROT-RH v121 — PREREGISTERED BLIND PRIME–GAMMA PHASE-LOCK REPLICATION")
    print("=" * 164)
    print("PREFREEZE SHA                   :", prefreeze_sha)
    print("L                               :", args.L)
    print("fresh windows                   :", windows)
    print("combined                        :", combined)
    print("counter q / qcheck              :", args.counter_q, "/", args.counter_qcheck)
    print("permutations                    :", args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 164)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("[1] Build fresh high-resolution zero-free support", flush=True)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    support = v102.ordered_support(
        phase,
        depth=int(args.max_depth),
        scan_points=int(args.scan_points),
        qcheck=int(args.counter_qcheck),
    )
    roots = np.asarray(support.roots, float)

    print(
        f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
        f"maxres={np.max(support.residuals):.3e} "
        f"qphase={support.quadrature_phase_rel_l2:.3e} "
        f"qder={support.quadrature_deriv_rel_l2:.3e}"
    )

    ks = list(range(combined[0], combined[1] + 1))
    lo = np.asarray([roots[k - 1] for k in ks], float)
    hi = np.asarray([roots[k] for k in ks], float)
    widths = hi - lo
    endpoints = np.concatenate([[lo[0]], hi])

    print("[2] Compute 320 fresh total staircase defects", flush=True)
    qtot = np.empty(len(ks), float)
    maxQ = np.empty(len(ks), float)
    cell_qdiff = np.empty(len(ks), float)
    absQint = np.empty(len(ks), float)

    for j, k in enumerate(ks):
        r = q_total_cell(phase, lo[j], hi[j], k, args.cell_q)
        rc = q_total_cell(phase, lo[j], hi[j], k, args.cell_qcheck)
        qtot[j] = rc["q"]
        maxQ[j] = rc["max_abs_Q"]
        absQint[j] = rc["abs_q_integral"]
        cell_qdiff[j] = abs(r["q"] - rc["q"])

        if (j + 1) % 80 == 0:
            print(
                f"  through k={k}: max|Q|={np.max(maxQ[j-79:j+1]):.6f} "
                f"max qdiff={np.max(cell_qdiff[j-79:j+1]):.2e}"
            )

    print("[3] Prime / Gamma / AC component defects", flush=True)
    pw = np.asarray(phase.phase_w, float)
    logs = np.asarray(phase.logs, float)
    prime_phase_endpoint, prime_anti = prime_endpoint_functions(
        endpoints, pw, logs, args.prime_chunk_terms
    )
    qprime = (
        prime_anti[1:] - prime_anti[:-1]
        - 0.5 * widths * (
            prime_phase_endpoint[:-1] + prime_phase_endpoint[1:]
        )
    )

    qarch = np.empty(len(ks), float)
    qac = np.empty(len(ks), float)
    qarch0 = np.empty(len(ks), float)
    qac0 = np.empty(len(ks), float)

    for j in range(len(ks)):
        qarch0[j] = q_from_fprime(
            arch_fprime, lo[j], hi[j], args.component_q
        )
        qarch[j] = q_from_fprime(
            arch_fprime, lo[j], hi[j], args.component_qcheck
        )
        qac0[j] = q_from_fprime(
            ac_fprime, lo[j], hi[j], args.component_q
        )
        qac[j] = q_from_fprime(
            ac_fprime, lo[j], hi[j], args.component_qcheck
        )

    component_qcheck = max(
        float(np.max(np.abs(qarch - qarch0))),
        float(np.max(np.abs(qac - qac0))),
    )

    qcounter = qtot - qprime - qarch - qac
    qfp = qac + qcounter
    fp_rel = float(
        np.linalg.norm(qfp) / max(np.linalg.norm(qtot), EPS)
    )

    print("  finite-part relL2              :", f"{fp_rel:.3e}")
    print("  component qcheck               :", f"{component_qcheck:.3e}")

    rng = np.random.default_rng(args.seed)

    def sl(a, b):
        j0 = a - combined[0]
        j1 = b - combined[0] + 1
        return slice(j0, j1)

    print("[4] Frozen blind alignment tests", flush=True)
    result_rows = []
    window_metrics = []

    for wi, (a, b) in enumerate(windows, start=1):
        s = sl(a, b)
        met = alignment_metrics(
            qprime[s], qarch[s],
            args.lowfreq_bins, args.permutations, rng
        )
        window_metrics.append(met)
        print(
            f"  W{wi} {a}-{b}: "
            f"cancel={met['cumulative_cancellation_ratio']:.4f} "
            f"shiftPct={100*met['shift_cumulative_percentile']:.4f}% "
            f"permCumPct={100*met['perm_cumulative_percentile']:.4f}% "
            f"lowFPct={100*met['perm_lowfreq_percentile']:.4f}%"
        )
        result_rows.append({
            "kind": f"W{wi}",
            "k_start": a,
            "k_end": b,
            **{k: v for k, v in met.items() if k != "freq"},
        })

    cm = alignment_metrics(
        qprime, qarch,
        args.lowfreq_bins, args.permutations, rng
    )
    result_rows.append({
        "kind": "COMBINED",
        "k_start": combined[0],
        "k_end": combined[1],
        **{k: v for k, v in cm.items() if k != "freq"},
    })

    print(
        f"  COMBINED {combined[0]}-{combined[1]}: "
        f"cancel={cm['cumulative_cancellation_ratio']:.4f} "
        f"shiftPct={100*cm['shift_cumulative_percentile']:.4f}% "
        f"permCumPct={100*cm['perm_cumulative_percentile']:.4f}% "
        f"lowFPct={100*cm['perm_lowfreq_percentile']:.4f}%"
    )

    print("[5] Combined low-frequency phase lock", flush=True)
    for fr in cm["freq"][:8]:
        print(
            f"  bin {fr['bin']:>2d}: "
            f"cancel={fr['cancellation_ratio']:.3e} "
            f"phaseCos={fr['phase_cosine']:+.6f} "
            f"|P|/|A|={fr['prime_to_arch_amp_ratio']:.3f}"
        )

    f1 = cm["freq"][0]
    f2 = cm["freq"][1]

    gates = {
        "root_residual_below_1e8":
            bool(float(np.max(support.residuals)) < 1e-8),
        "counterterm_quadrature_stable":
            bool(
                support.quadrature_phase_rel_l2 < 5e-6
                and support.quadrature_deriv_rel_l2 < 5e-6
            ),
        "cell_qcheck_below_1e8":
            bool(float(np.max(cell_qdiff)) < 1e-8),
        "component_qcheck_below_1e8":
            bool(component_qcheck < 1e-8),

        "finite_part_rel_l2_below_1e3":
            bool(fp_rel <= 1e-3),

        "W1_cancel_ratio_below_0p30":
            bool(window_metrics[0]["cumulative_cancellation_ratio"] <= 0.30),
        "W1_shift_pct_below_0p05":
            bool(window_metrics[0]["shift_cumulative_percentile"] <= 0.05),

        "W2_cancel_ratio_below_0p30":
            bool(window_metrics[1]["cumulative_cancellation_ratio"] <= 0.30),
        "W2_shift_pct_below_0p05":
            bool(window_metrics[1]["shift_cumulative_percentile"] <= 0.05),

        "combined_cancel_ratio_below_0p20":
            bool(cm["cumulative_cancellation_ratio"] <= 0.20),
        "combined_shift_pct_below_0p01":
            bool(cm["shift_cumulative_percentile"] <= 0.01),
        "combined_perm_cum_pct_below_0p01":
            bool(cm["perm_cumulative_percentile"] <= 0.01),
        "combined_perm_lowf_pct_below_0p01":
            bool(cm["perm_lowfreq_percentile"] <= 0.01),

        "combined_bin1_phasecos_below_m0p90":
            bool(f1["phase_cosine"] <= -0.90),
        "combined_bin2_phasecos_below_m0p90":
            bool(f2["phase_cosine"] <= -0.90),
        "combined_bin1_cancel_below_0p25":
            bool(f1["cancellation_ratio"] <= 0.25),
        "combined_bin2_cancel_below_0p25":
            bool(f2["cancellation_ratio"] <= 0.25),
    }

    numerical_names = [
        "root_residual_below_1e8",
        "counterterm_quadrature_stable",
        "cell_qcheck_below_1e8",
        "component_qcheck_below_1e8",
    ]
    scientific_names = [
        k for k in gates if k not in numerical_names
    ]

    if all(gates[k] for k in numerical_names) and all(
        gates[k] for k in scientific_names
    ):
        verdict = (
            "PASS_V121_PREREGISTERED_PRIME_GAMMA_PHASE_LOCK_REPLICATES_BLIND"
        )
    elif all(gates[k] for k in numerical_names):
        verdict = (
            "NO_GO_V121_PRIME_GAMMA_PHASE_LOCK_FAILS_FROZEN_BLIND_GATES"
        )
    else:
        verdict = "FAIL_V121_NUMERICAL_SUPPORT_INVALID"

    cell_rows = []
    for j, k in enumerate(ks):
        cell_rows.append({
            "cell_k": k,
            "lo": lo[j],
            "hi": hi[j],
            "width": widths[j],
            "q_total": qtot[j],
            "q_prime": qprime[j],
            "q_arch": qarch[j],
            "q_AC": qac[j],
            "q_counter": qcounter[j],
            "q_finite_part_pair": qfp[j],
            "max_abs_Q": maxQ[j],
            "abs_Q_integral": absQint[j],
            "cell_qcheck_absdiff": cell_qdiff[j],
        })

    freq_rows = [
        {
            "kind": "COMBINED",
            "k_start": combined[0],
            "k_end": combined[1],
            **fr,
        }
        for fr in cm["freq"]
    ]

    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_WINDOWS.csv"), result_rows)
    write_csv(Path(str(prefix) + "_FREQUENCIES.csv"), freq_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "prefreeze_sha256": prefreeze_sha,
        "gates": gates,
        "finite_part_rel_l2": fp_rel,
        "W1": window_metrics[0],
        "W2": window_metrics[1],
        "combined": cm,
        "interpretation": (
            "A PASS is a fresh preregistered replication that the actual "
            "spectral-index alignment of prime and Gamma adaptive trapezoid "
            "defects is special, particularly in the first two low-frequency "
            "modes. It does not prove that this lock persists to infinite "
            "depth or that it is independent of the adaptive total-phase mesh."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 164)
    print("FINAL v121 VERDICT")
    print("=" * 164)
    print("verdict                         :", verdict)
    print("PREFREEZE SHA                   :", prefreeze_sha)
    print("finite-part relL2               :", f"{fp_rel:.12e}")
    print("W1 cancellation ratio           :",
          f"{window_metrics[0]['cumulative_cancellation_ratio']:.12e}")
    print("W1 circular-shift percentile    :",
          f"{100*window_metrics[0]['shift_cumulative_percentile']:.6f}%")
    print("W2 cancellation ratio           :",
          f"{window_metrics[1]['cumulative_cancellation_ratio']:.12e}")
    print("W2 circular-shift percentile    :",
          f"{100*window_metrics[1]['shift_cumulative_percentile']:.6f}%")
    print("combined cancellation ratio     :",
          f"{cm['cumulative_cancellation_ratio']:.12e}")
    print("combined circular-shift pct     :",
          f"{100*cm['shift_cumulative_percentile']:.6f}%")
    print("combined permutation cum pct    :",
          f"{100*cm['perm_cumulative_percentile']:.6f}%")
    print("combined permutation lowF pct   :",
          f"{100*cm['perm_lowfreq_percentile']:.6f}%")
    print("bin1 phaseCos / cancel          :",
          f"{f1['phase_cosine']:+.6f} / {f1['cancellation_ratio']:.6e}")
    print("bin2 phaseCos / cancel          :",
          f"{f2['phase_cosine']:+.6f} / {f2['cancellation_ratio']:.6e}")
    print("qphase                          :",
          f"{support.quadrature_phase_rel_l2:.12e}")
    print("qder                            :",
          f"{support.quadrature_deriv_rel_l2:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 164)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
