#!/usr/bin/env python3
"""
ROT-RH v149 — ROLLING HELD-OUT AGGREGATE TRACE-MODULUS AUDIT

ZERO-COST postprocessor.
No phase builds, root solving, prime sums, Xi, zeta, or known-zero data.

Motivation
----------
v148 showed that a single per-mode power modulus is too strong:
some individual modes exhibit micromotion and violate the frozen bound.

But trace-norm cutoff independence does NOT require each mode to obey
the same pointwise modulus.  For each finite N it is enough to prove an
aggregate l1 modulus

    D_N(L,M)
      = sum_{k<=N} |lambda_k(L)-lambda_k(M)|
      <= C_N * omega(L,M),                              (1)

where omega(L,M) -> 0 as L,M -> infinity.

This script tests the power candidate

    omega_alpha(L,M) = |L^(-alpha) - M^(-alpha)|        (2)

directly at the aggregate level, using the all-pairs v146 results.

Rolling held-out design
-----------------------
For each holdout endpoint H:

  H = 362039:
      train only on pairs with L_b < 362039,
      test all pairs ending at 362039.

  H = 512000:
      train only on pairs with L_b < 512000,
      test all pairs ending at 512000.

For each alpha, training determines FOUR independent constants:
  C_def    for sum |old-root defect|,
  C_shift  for sum |Delta E|,
  C_bound  for sum implicit-function upper bounds,
  C_trace  for finite-mode trace distance.

All are multiplied by one frozen safety factor BEFORE testing.

An alpha passes only if every held-out aggregate pair satisfies all four
bounds.

Why this is theorem-relevant
----------------------------
If for every finite N,

    D_N(L,M) <= C_N |L^(-alpha)-M^(-alpha)|,

then D_N(L,M)->0 for arbitrary L,M->infinity.

Combined with a proven uniform summable high-k majorant,

    sup_L sum_{k>N} lambda_k(L) -> 0,

we get

    ||K_L-K_M||_1
      <= C_N |L^(-alpha)-M^(-alpha)|
         + 2 sup_R sum_{k>N} lambda_k(R),

which is the full trace-class Cauchy criterion.

Outputs
-------
<prefix>_ALPHA_SCAN.csv
<prefix>_HOLDOUT.csv
<prefix>_CONSTANTS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


METRICS = {
    "defect": "sum_abs_defect_1_N",
    "shift": "sum_abs_shift_1_N",
    "implicit": "sum_implicit_bound_1_N",
    "trace": "trace_distance_1_N",
}


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def omega(L, M, alpha):
    return abs(float(L) ** (-alpha) - float(M) ** (-alpha))


def safe_ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.inf


def fit_constants(train, alpha, safety):
    out = {}

    for label, col in METRICS.items():
        vals = []
        for _, r in train.iterrows():
            w = omega(r["L_a"], r["L_b"], alpha)
            if w > 0:
                vals.append(float(r[col]) / w)

        if not vals:
            raise RuntimeError(f"No training data for metric {label}.")

        raw = max(vals)
        out[label] = dict(
            raw=raw,
            safe=safety * raw,
        )

    return out


def test_holdout(test, alpha, constants, H):
    rows = []
    all_pass = True

    for _, r in test.iterrows():
        w = omega(r["L_a"], r["L_b"], alpha)

        row = dict(
            alpha=float(alpha),
            holdout_L=int(H),
            L_a=int(r["L_a"]),
            L_b=int(r["L_b"]),
            omega=w,
        )

        for label, col in METRICS.items():
            actual = float(r[col])
            bound = constants[label]["safe"] * w
            rr = safe_ratio(actual, bound)
            passed = rr <= 1.0

            row[f"{label}_actual"] = actual
            row[f"{label}_bound"] = bound
            row[f"{label}_ratio"] = rr
            row[f"{label}_pass"] = int(passed)

            if not passed:
                all_pass = False

        rows.append(row)

    return all_pass, rows


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--pairs-csv",
        default="rot_rh_all_pairs_local_cutoff_v146_PAIRS.csv",
    )
    ap.add_argument(
        "--holdout-L-list",
        default="362039,512000",
    )

    ap.add_argument("--alpha-min", type=float, default=0.01)
    ap.add_argument("--alpha-max", type=float, default=1.50)
    ap.add_argument("--alpha-points", type=int, default=300)

    ap.add_argument(
        "--safety-factor",
        type=float,
        default=1.25,
        help="Frozen multiplier on training-derived aggregate constants.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_aggregate_trace_modulus_v149",
    )

    args = ap.parse_args()

    df = pd.read_csv(args.pairs_csv)

    required = {"L_a", "L_b"} | set(METRICS.values())
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(f"Missing required columns: {sorted(missing)}")

    holdouts = sorted(set(csv_ints(args.holdout_L_list)))
    alphas = np.linspace(args.alpha_min, args.alpha_max, args.alpha_points)

    print("=" * 132)
    print("ROT-RH v149 — ROLLING HELD-OUT AGGREGATE TRACE-MODULUS AUDIT")
    print("=" * 132)
    print("Xi / zeta / known zeros          : NONE")
    print(f"rolling holdouts                  : {holdouts}")
    print(f"alpha grid                        : {args.alpha_min}..{args.alpha_max} ({args.alpha_points})")
    print(f"FROZEN safety factor              : {args.safety_factor}")
    print("required held-out aggregate cover : 100% of pairs, all four metrics")
    print("=" * 132)

    scan_rows = []
    detail_by_alpha = {}
    constants_by_alpha = {}

    for alpha in alphas:
        alpha_pass = True
        alpha_details = []
        alpha_constants = []

        worst = {label: 0.0 for label in METRICS}
        required_sf = 0.0

        for H in holdouts:
            train = df[df["L_b"] < H].copy()
            test = df[df["L_b"] == H].copy()

            if train.empty or test.empty:
                alpha_pass = False
                continue

            constants = fit_constants(
                train=train,
                alpha=float(alpha),
                safety=float(args.safety_factor),
            )

            passed, rows = test_holdout(
                test=test,
                alpha=float(alpha),
                constants=constants,
                H=H,
            )

            if not passed:
                alpha_pass = False

            alpha_details.extend(rows)

            for label in METRICS:
                alpha_constants.append(dict(
                    alpha=float(alpha),
                    holdout_L=int(H),
                    metric=label,
                    training_constant_raw=constants[label]["raw"],
                    training_constant_safe=constants[label]["safe"],
                ))

            for row in rows:
                for label in METRICS:
                    rr = float(row[f"{label}_ratio"])
                    worst[label] = max(worst[label], rr)
                    required_sf = max(
                        required_sf,
                        args.safety_factor * rr,
                    )

        detail_by_alpha[float(alpha)] = alpha_details
        constants_by_alpha[float(alpha)] = alpha_constants

        scan_rows.append(dict(
            alpha=float(alpha),
            pass_all_holdouts=int(alpha_pass),
            worst_defect_ratio=worst["defect"],
            worst_shift_ratio=worst["shift"],
            worst_implicit_ratio=worst["implicit"],
            worst_trace_ratio=worst["trace"],
            minimum_required_safety_factor=required_sf,
        ))

    scan = pd.DataFrame(scan_rows)
    scan.to_csv(args.prefix + "_ALPHA_SCAN.csv", index=False)

    passed = scan[scan["pass_all_holdouts"] == 1]

    if not passed.empty:
        # Largest passing alpha = strongest empirically supported rate.
        selected = passed.sort_values("alpha").iloc[-1]
        verdict = "ROLLING_AGGREGATE_TRACE_MODULUS_SUPPORTED"
    else:
        selected = scan.sort_values(
            ["minimum_required_safety_factor", "alpha"],
            ascending=[True, False],
        ).iloc[0]
        verdict = "ROLLING_AGGREGATE_TRACE_MODULUS_UNRESOLVED"

    alpha_star = float(selected["alpha"])
    details = detail_by_alpha[alpha_star]
    constants = constants_by_alpha[alpha_star]

    pd.DataFrame(details).to_csv(
        args.prefix + "_HOLDOUT.csv",
        index=False,
    )
    pd.DataFrame(constants).to_csv(
        args.prefix + "_CONSTANTS.csv",
        index=False,
    )

    # Extract the latest training constant for the trace metric,
    # i.e. the constant fitted before the largest holdout.
    largest_H = max(holdouts)
    latest_trace_const_rows = [
        r for r in constants
        if r["holdout_L"] == largest_H and r["metric"] == "trace"
    ]

    C_trace = (
        float(latest_trace_const_rows[0]["training_constant_safe"])
        if latest_trace_const_rows else np.nan
    )

    examples = []
    if np.isfinite(C_trace):
        for L in [512000, 1000000, 2000000, 4000000, 8000000]:
            M = 2 * L
            w = omega(L, M, alpha_star)
            examples.append(dict(
                L=L,
                M=M,
                omega=w,
                finite_mode_trace_upper_bound=C_trace * w,
            ))

    summary = dict(
        version=149,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        rolling_holdouts=holdouts,
        frozen_safety_factor=args.safety_factor,
        selected_alpha=alpha_star,
        selected_metrics={
            k: (
                float(v)
                if isinstance(v, (float, np.floating))
                else int(v)
            )
            for k, v in selected.to_dict().items()
        },
        selected_latest_trace_constant=(
            C_trace if np.isfinite(C_trace) else None
        ),
        finite_mode_examples=examples,
        empirical_theorem_candidate=(
            f"D_N(L,M) <= C_N |L^(-{alpha_star:.8g})-M^(-{alpha_star:.8g})| "
            "for the tested finite block, with C_N determined before each holdout."
        ),
        verdict=verdict,
        mathematical_note=(
            "Unlike a per-mode modulus, an aggregate l1 modulus is exactly "
            "what finite-rank trace-norm convergence requires. Individual "
            "mode micromotion is allowed."
        ),
        proof_gap=(
            "The rolling held-out result is numerical evidence. "
            "A rigorous theorem must derive an aggregate finite-mode modulus "
            "directly from the cutoff-difference defect/kernel, uniformly for "
            "arbitrary sufficiently large L,M."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("Selected rolling aggregate modulus")
    print("-" * 132)
    print(f"alpha                              : {alpha_star:.9f}")
    print(f"frozen safety factor               : {args.safety_factor:.6f}")
    print(f"worst held-out defect ratio        : {selected['worst_defect_ratio']:.6f}")
    print(f"worst held-out root-shift ratio    : {selected['worst_shift_ratio']:.6f}")
    print(f"worst held-out implicit ratio      : {selected['worst_implicit_ratio']:.6f}")
    print(f"worst held-out trace ratio         : {selected['worst_trace_ratio']:.6f}")
    print(f"minimum required safety factor     : {selected['minimum_required_safety_factor']:.6f}")
    if np.isfinite(C_trace):
        print(f"latest finite-mode trace C_N       : {C_trace:.9e}")

    print()
    print("Held-out aggregate predictions")
    print("-" * 132)

    for r in details:
        print(
            f"H={r['holdout_L']:>6d} "
            f"{r['L_a']:>7d}->{r['L_b']:<7d}  "
            f"def x={r['defect_ratio']:.4f}  "
            f"shift x={r['shift_ratio']:.4f}  "
            f"impl x={r['implicit_ratio']:.4f}  "
            f"trace x={r['trace_ratio']:.4f}"
        )

    if examples:
        print()
        print("Selected finite-mode asymptotic trace bounds")
        print("-" * 132)
        for r in examples:
            print(
                f"{r['L']:>8d}->{r['M']:<8d}  "
                f"d_N <= {r['finite_mode_trace_upper_bound']:.6e}"
            )

    print()
    print("=" * 132)
    print(f"VERDICT                            : {verdict}")
    print("=" * 132)
    print("THEOREM TARGET:")
    print(
        f"  Prove D_N(L,M) <= C_N |L^(-{alpha_star:.8g})-M^(-{alpha_star:.8g})|"
    )
    print("  directly in l1 over the first N modes. Per-mode monotone/power")
    print("  behavior is not required for trace-norm cutoff independence.")


if __name__ == "__main__":
    main()
