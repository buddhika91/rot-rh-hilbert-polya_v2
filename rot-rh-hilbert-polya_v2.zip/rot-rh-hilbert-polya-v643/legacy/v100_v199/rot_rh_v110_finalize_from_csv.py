#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import csv
import json
from pathlib import Path
import numpy as np

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def f(row, key):
    return float(row[key])

def b(x):
    return bool(x)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v110-prefix", default="rot_rh_out_of_sample_tail_unseen_roots_v110")
    ap.add_argument("--final-L", type=int, default=16000)
    args = ap.parse_args()

    p = Path(args.v110_prefix).expanduser().resolve()
    blocks_path = Path(str(p) + "_BLOCKS.csv")
    phase_path = Path(str(p) + "_PHASE.csv")
    if not blocks_path.exists() or not phase_path.exists():
        raise FileNotFoundError("Expected v110 BLOCKS/PHASE CSVs were not found.")

    blocks = read_csv(blocks_path)
    phases = read_csv(phase_path)
    final = [r for r in blocks if int(float(r["L"])) == args.final_L]
    if not final:
        raise RuntimeError(f"No block rows for L={args.final_L}")

    # Discover resolvent probes from columns.
    rcols = sorted(
        k for k in final[0].keys()
        if k.startswith("R_a") and k.endswith("_relative_error")
    )
    ocols = sorted(
        k for k in final[0].keys()
        if k.startswith("R_a") and k.endswith("_order_stability")
    )

    max_s1 = max(f(r, "S1_relative_error") for r in final)
    max_mom = max(f(r, "moment_rel_l2_first_reported") for r in final)
    max_r = max(f(r, k) for r in final for k in rcols)
    max_order = max(f(r, k) for r in final for k in ocols)

    moment_cols = sorted(
        k for k in final[0].keys()
        if k.startswith("S") and k.endswith("_relerr")
        and k[1:-7].isdigit()
    )
    per_moment_max = {
        k.replace("_relerr", ""): max(f(r, k) for r in final)
        for k in moment_cols
    }
    per_resolvent_max = {
        k.replace("_relative_error", ""): max(f(r, k) for r in final)
        for k in rcols
    }

    gates = {
        "deep_roots_numerically_valid":
            all(f(r, "max_root_residual") < 1e-8 for r in phases),
        "counterterm_quadrature_stable":
            all(f(r, "qphase") < 5e-6 and f(r, "qder") < 5e-6 for r in phases),
        "unseen_block_S1_pred_below_1e4": max_s1 < 1e-4,
        "unseen_block_moments_below_1e3": max_mom < 1e-3,
        "unseen_block_resolvent_below_1e4": max_r < 1e-4,
        "block_resolvent_tail_order_stable": max_order < 1e-8,
    }

    verdict = (
        "PASS_V110_ARITHMETIC_TAIL_PREDICTS_UNSEEN_OPERATOR_ROOT_BLOCKS__"
        "TAIL_CIRCULARITY_RISK_SUBSTANTIALLY_REDUCED"
        if all(gates.values())
        else "PARTIAL_V110_ARITHMETIC_TAIL_AUDIT"
    )

    packet = {
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "gates": gates,
        "final_L": args.final_L,
        "final_max_unseen_block_S1_relative_error": max_s1,
        "final_max_unseen_block_moment_relative_L2": max_mom,
        "final_max_unseen_block_resolvent_relative_error": max_r,
        "final_max_resolvent_order_instability": max_order,
        "final_per_moment_max_relative_errors": per_moment_max,
        "final_per_resolvent_max_relative_errors": per_resolvent_max,
        "caveat": (
            "Block predictions use the held-out block endpoint E_M in "
            "T(E_N)-T(E_M). This validates conditional tail interpolation "
            "between spectral endpoints, but is not a fully blind forecast "
            "of E_M itself."
        ),
    }

    out = Path(str(p) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("=" * 120)
    print("ROT-RH v110 FAST FINALIZER")
    print("=" * 120)
    print("verdict                              :", verdict)
    print("final max unseen-block S1 rel error  :", f"{max_s1:.12e}")
    print("final max moment rel-L2              :", f"{max_mom:.12e}")
    print("final max block-resolvent rel error  :", f"{max_r:.12e}")
    print("final max resolvent order instability:", f"{max_order:.12e}")
    print("per-moment max relative errors        :", per_moment_max)
    print("per-resolvent max relative errors     :", per_resolvent_max)
    print("gates                                :", gates)
    print("RH proof                             : FALSE")
    print("caveat                               : endpoint-conditional, not fully blind")
    print("verdict file                         :", out)
    print("=" * 120)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
