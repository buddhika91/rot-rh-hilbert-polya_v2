#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v120 — Prime–Gamma Alignment / Low-Frequency Cancellation Red-Team
=========================================================================

Consumes only v119_CELLS.csv. No roots/phases are recomputed.

v119 found
    q_total = q_prime + q_arch + q_AC + q_counter
with
    q_AC + q_counter ~ 0
and the small cumulative total arising from prime–arch cancellation.

v120 asks whether that cancellation depends specifically on the ACTUAL
spectral-index alignment.

Controls
--------
1. All circular shifts of q_arch relative to q_prime.
2. Random permutations of q_arch relative to q_prime.

Metrics
-------
* cumulative maximum of q_prime + aligned q_arch;
* low-frequency power fraction;
* RMS of the combined cell sequence;
* DFT-bin cancellation ratios for the first low-frequency modes.

Also quantifies the finite-part cancellation q_AC+q_counter.

This is a post-hoc mechanism audit, not a new RH test.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

VERSION = "v120"
BUILD = "2026-08-17-prime-gamma-alignment-lowfreq-redteam-v120"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row, key):
    return float(row[key])


def i(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p)-1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x*x)))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def corr(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v119-prefix",
        default="rot_rh_adaptive_trapezoid_decomposition_v119",
    )
    ap.add_argument("--k-start", type=int, default=48)
    ap.add_argument("--k-end", type=int, default=767)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument(
        "--prefix",
        default="rot_rh_prime_gamma_alignment_v120",
    )
    args = ap.parse_args()

    src = Path(args.v119_prefix).expanduser().resolve()
    cells_path = Path(str(src) + "_CELLS.csv")
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rr = sorted(
        [
            r for r in raw
            if args.k_start <= i(r, "cell_k") <= args.k_end
        ],
        key=lambda r: i(r, "cell_k"),
    )
    if len(rr) != args.k_end - args.k_start + 1:
        raise RuntimeError("Requested cell range is incomplete.")

    qtot = np.asarray([f(r, "q_total") for r in rr], float)
    qp = np.asarray([f(r, "q_prime") for r in rr], float)
    qa = np.asarray([f(r, "q_arch") for r in rr], float)
    qac = np.asarray([f(r, "q_AC") for r in rr], float)
    qc = np.asarray([f(r, "q_counter_residual") for r in rr], float)

    qfp = qac + qc
    qpa = qp + qa
    recon = qpa + qfp

    print("=" * 154)
    print("ROT-RH v120 — PRIME–GAMMA ALIGNMENT / LOW-FREQUENCY CANCELLATION RED-TEAM")
    print("=" * 154)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("cell count                      :", len(rr))
    print("circular shift controls         :", len(rr))
    print("random permutations             :", args.permutations)
    print("low-frequency bins              :", args.lowfreq_bins)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 154)

    print("[1] Exact component reconstruction / finite-part cancellation")
    recon_rel = float(
        np.linalg.norm(recon-qtot) / max(np.linalg.norm(qtot), EPS)
    )
    fp_rel = float(
        np.linalg.norm(qfp) / max(np.linalg.norm(qtot), EPS)
    )
    fp_cmax = cumulative_max(qfp)
    print("  reconstruction relL2           :", f"{recon_rel:.12e}")
    print("  ||AC+counter|| / ||total||     :", f"{fp_rel:.12e}")
    print("  cumMax(AC+counter)             :", f"{fp_cmax:.12e}")
    print("  corr(AC,-counter)              :", f"{corr(qac,-qc):.12e}")

    actual = qpa
    actual_cmax = cumulative_max(actual)
    actual_lowf = lowfreq_fraction(actual, args.lowfreq_bins)
    actual_rms = rms(actual)

    prime_cmax = cumulative_max(qp)
    arch_cmax = cumulative_max(qa)
    cancellation_ratio = actual_cmax / max(prime_cmax + arch_cmax, EPS)

    print("[2] Actual prime–Gamma cancellation")
    print("  prime cumulative max           :", f"{prime_cmax:.12e}")
    print("  arch cumulative max            :", f"{arch_cmax:.12e}")
    print("  prime+arch cumulative max      :", f"{actual_cmax:.12e}")
    print("  cumulative cancellation ratio  :", f"{cancellation_ratio:.12e}")
    print("  prime+arch lowfreq fraction    :", f"{actual_lowf:.12e}")
    print("  prime+arch cell RMS            :", f"{actual_rms:.12e}")

    print("[3] All circular-shift alignment controls")
    shift_rows = []
    shift_cmax = np.empty(len(rr), float)
    shift_lowf = np.empty(len(rr), float)
    shift_rms = np.empty(len(rr), float)

    for s in range(len(rr)):
        x = qp + np.roll(qa, s)
        shift_cmax[s] = cumulative_max(x)
        shift_lowf[s] = lowfreq_fraction(x, args.lowfreq_bins)
        shift_rms[s] = rms(x)
        shift_rows.append({
            "shift": s,
            "cumulative_max": shift_cmax[s],
            "lowfreq_fraction": shift_lowf[s],
            "cell_rms": shift_rms[s],
        })

    actual_shift_c_pct = percentile_le(shift_cmax, shift_cmax[0])
    actual_shift_l_pct = percentile_le(shift_lowf, shift_lowf[0])
    actual_shift_r_pct = percentile_le(shift_rms, shift_rms[0])

    nonzero_c = shift_cmax[1:]
    nonzero_l = shift_lowf[1:]
    print("  actual shift=0 cumMax           :", f"{shift_cmax[0]:.12e}")
    print("  nonzero-shift cumMax median     :", f"{np.median(nonzero_c):.12e}")
    print("  shift-0 cum lower percentile    :", f"{100*actual_shift_c_pct:.6f}%")
    print("  shift-0 lowF lower percentile   :", f"{100*actual_shift_l_pct:.6f}%")
    print("  shift-0 RMS lower percentile    :", f"{100*actual_shift_r_pct:.6f}%")
    print("  best nonzero shift              :", int(1+np.argmin(nonzero_c)))
    print("  best nonzero cumMax             :", f"{np.min(nonzero_c):.12e}")

    print("[4] Random-permutation alignment controls")
    rng = np.random.default_rng(args.seed)
    pc = np.empty(args.permutations, float)
    pl = np.empty(args.permutations, float)
    pr = np.empty(args.permutations, float)
    for t in range(args.permutations):
        x = qp + rng.permutation(qa)
        pc[t] = cumulative_max(x)
        pl[t] = lowfreq_fraction(x, args.lowfreq_bins)
        pr[t] = rms(x)

    perm_c_pct = percentile_le(pc, actual_cmax)
    perm_l_pct = percentile_le(pl, actual_lowf)
    perm_r_pct = percentile_le(pr, actual_rms)
    print("  permutation cumMax mean         :", f"{np.mean(pc):.12e}")
    print("  actual cumulative percentile    :", f"{100*perm_c_pct:.6f}%")
    print("  actual lowF percentile          :", f"{100*perm_l_pct:.6f}%")
    print("  actual RMS percentile           :", f"{100*perm_r_pct:.6f}%")

    print("[5] Frequency-by-frequency prime–Gamma cancellation")
    # Remove DC to focus on structured low-frequency modes.
    P = np.fft.rfft(qp - np.mean(qp))
    A = np.fft.rfft(qa - np.mean(qa))
    T = P + A
    freq_rows = []
    maxbin = min(args.lowfreq_bins, len(P)-1)
    for j in range(1, maxbin+1):
        den = abs(P[j]) + abs(A[j])
        cr = abs(T[j]) / max(den, EPS)
        phase_cos = float(
            np.real(P[j] * np.conj(A[j]))
            / max(abs(P[j])*abs(A[j]), EPS)
        )
        amp_ratio = abs(P[j]) / max(abs(A[j]), EPS)
        row = {
            "frequency_bin": j,
            "prime_amplitude": abs(P[j]),
            "arch_amplitude": abs(A[j]),
            "combined_amplitude": abs(T[j]),
            "cancellation_ratio": cr,
            "phase_cosine": phase_cos,
            "prime_to_arch_amplitude_ratio": amp_ratio,
        }
        freq_rows.append(row)
        print(
            f"  bin {j:>2d}: cancel={cr:.3e} "
            f"phaseCos={phase_cos:+.6f} "
            f"|P|/|A|={amp_ratio:.3f}"
        )

    # Conservative mechanism classification.
    aligned_special = (
        actual_shift_c_pct <= 0.01
        and perm_c_pct <= 0.01
        and perm_l_pct <= 0.01
    )
    fp_negligible = fp_rel < 0.01

    if aligned_special and fp_negligible:
        mechanism = (
            "SPECIFIC_PRIME_GAMMA_SPECTRAL_ALIGNMENT_DRIVES_LOW_FREQUENCY_CANCELLATION"
        )
    elif aligned_special:
        mechanism = (
            "PRIME_GAMMA_ALIGNMENT_SPECIAL_BUT_FINITE_PART_RESIDUAL_NONNEGLIGIBLE"
        )
    else:
        mechanism = (
            "PRIME_GAMMA_CANCELLATION_NOT_UNIQUE_UNDER_ALIGNMENT_CONTROLS"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix) + "_SHIFTS.csv"), shift_rows)
    write_csv(Path(str(prefix) + "_FREQUENCIES.csv"), freq_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V120_ALIGNMENT_RED_TEAM_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "finite_part_rel_l2": fp_rel,
        "finite_part_cumulative_max": fp_cmax,
        "prime_arch_cumulative_cancellation_ratio": cancellation_ratio,
        "actual_shift_cumulative_lower_percentile": actual_shift_c_pct,
        "actual_shift_lowfreq_lower_percentile": actual_shift_l_pct,
        "actual_permutation_cumulative_lower_percentile": perm_c_pct,
        "actual_permutation_lowfreq_lower_percentile": perm_l_pct,
        "frequency_rows": freq_rows,
        "interpretation": (
            "If the true index alignment is exceptional under both circular "
            "shifts and random permutations, the bounded adaptive trapezoid "
            "defect is carried by a specific phase relationship between the "
            "prime and Gamma components, not by generic cancellation of two "
            "smooth sequences. This remains post-hoc and does not prove the "
            "alignment persists to infinite depth."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 154)
    print("FINAL v120 VERDICT")
    print("=" * 154)
    print("verdict                         : PASS_V120_ALIGNMENT_RED_TEAM_COMPLETE")
    print("mechanism                       :", mechanism)
    print("finite-part relL2               :", f"{fp_rel:.12e}")
    print("prime-Gamma cancellation ratio  :", f"{cancellation_ratio:.12e}")
    print("circular-shift cum percentile   :", f"{100*actual_shift_c_pct:.6f}%")
    print("permutation cum percentile      :", f"{100*perm_c_pct:.6f}%")
    print("permutation lowF percentile     :", f"{100*perm_l_pct:.6f}%")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 154)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
