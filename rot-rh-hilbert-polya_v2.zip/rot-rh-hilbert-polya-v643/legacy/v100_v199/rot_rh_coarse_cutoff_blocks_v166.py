#!/usr/bin/env python3
"""
ROT-RH v166 — COARSE-GRAINED CUTOFF BLOCK CANCELLATION / TERM AUDIT

ZERO-COST postprocessor.

Purpose
-------
The sqrt(2)-spaced moving-root trajectory shows strong shell micromotion.
Adjacent trace increments can therefore be noisy even when endpoint
differences over a larger multiplicative cutoff step contract.

For the operator eigenvalue vector

    lambda(L) = (E_1(L)^-2, ..., E_N(L)^-2),

v166 computes exact endpoint increments over blocks of w adjacent shells:

    D_w(j) = ||lambda(L_{j+w}) - lambda(L_j)||_1.

For the current approximately sqrt(2)-spaced grid:
    w=1  -> factor ~sqrt(2),
    w=2  -> factor ~2,
    w=4  -> factor ~4.

It also compares D_w(j) with the total adjacent variation inside the same
block,

    V_w(j) = sum_{r=j}^{j+w-1}
               ||lambda(L_{r+1})-lambda(L_r)||_1,

and reports the cancellation factor

    C_w(j) = V_w(j) / D_w(j).

If D_2 or D_4 contracts substantially more cleanly than D_1 while C_w>1,
the finite-block limit is being approached through cutoff micromotion and
the theorem should be formulated on multiplicative endpoint blocks rather
than absolute shell variation.

A particularly useful sufficient route would be to prove on a fixed block N

    ||lambda(2L)-lambda(L)||_1 <= omega_N(L),
    omega_N(L) -> 0,

plus a summability or telescoping control on a geometric subsequence, and
then control intermediate cutoffs by the local root bound.

NO Xi / zeta / known-zero data.
NO phase builds, prime sums, or root solves.

Outputs
-------
<prefix>_BLOCKS.csv
<prefix>_WIDTH_SUMMARY.csv
<prefix>_MODES_W2.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def fit_power(L, y):
    L = np.asarray(L, dtype=float)
    y = np.asarray(y, dtype=float)

    mask = (L > 0) & (y > 0) & np.isfinite(y)
    X = np.log(L[mask])
    Y = np.log(y[mask])

    if len(X) < 2:
        return np.nan, np.nan

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    alpha = float(-coef[1])

    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return alpha, r2


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_two_shell_modal_envelope_v165_ROOTS.npz",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument(
        "--widths",
        default="1,2,4",
        help="Adjacent-shell block widths.",
    )
    ap.add_argument(
        "--factor2-latest-ratio-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--factor2-positive-alpha-gate",
        type=float,
        default=0.0,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_coarse_cutoff_blocks_v166",
    )
    args = ap.parse_args()

    widths = csv_ints(args.widths)
    if not widths:
        raise RuntimeError("Need at least one width.")

    z = np.load(args.roots_npz)
    L = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    if roots.ndim != 2:
        raise RuntimeError("Expected 2D roots matrix.")

    n = min(args.modes, roots.shape[1])
    roots = roots[:, :n]
    lam = roots**(-2)

    if len(L) != roots.shape[0]:
        raise RuntimeError("Cutoff/root dimension mismatch.")

    print("=" * 150)
    print("ROT-RH v166 — COARSE-GRAINED CUTOFF BLOCK CANCELLATION / TERM AUDIT")
    print("=" * 150)
    print("Xi / zeta / known zeros          : NONE")
    print(f"cutoffs                           : {L.tolist()}")
    print(f"modes                             : 1..{n}")
    print(f"block widths                      : {widths}")
    print("=" * 150)

    adjacent = lam[1:] - lam[:-1]
    adjacent_l1 = np.sum(np.abs(adjacent), axis=1)

    block_rows = []
    width_rows = []

    for w in widths:
        if w <= 0 or w >= len(L):
            continue

        rows_this = []

        # All overlapping blocks.
        for j in range(0, len(L)-w):
            net = lam[j+w] - lam[j]
            D = float(np.sum(np.abs(net)))
            V = float(np.sum(adjacent_l1[j:j+w]))
            cancel = V/max(D, 1e-300)

            row = dict(
                width=w,
                start_index=j,
                end_index=j+w,
                L=int(L[j]),
                M=int(L[j+w]),
                ratio_M_over_L=float(L[j+w]/L[j]),
                endpoint_l1=D,
                internal_abs_variation=V,
                cancellation_factor=cancel,
                max_modal_endpoint=float(np.max(np.abs(net))),
                median_modal_endpoint=float(np.median(np.abs(net))),
                overlapping=True,
            )
            block_rows.append(row)
            rows_this.append(row)

        # Disjoint blocks anchored at the first cutoff.
        disjoint = []
        j = 0
        while j+w < len(L):
            net = lam[j+w] - lam[j]
            D = float(np.sum(np.abs(net)))
            V = float(np.sum(adjacent_l1[j:j+w]))
            disjoint.append(dict(
                j=j,
                L=int(L[j]),
                M=int(L[j+w]),
                D=D,
                V=V,
                cancel=V/max(D,1e-300),
            ))
            j += w

        if len(disjoint) >= 2:
            Lfit = np.array([r["L"] for r in disjoint], dtype=float)
            Dfit = np.array([r["D"] for r in disjoint], dtype=float)
            alpha, r2 = fit_power(Lfit, Dfit)

            ratios = [
                disjoint[i]["D"]/max(disjoint[i-1]["D"],1e-300)
                for i in range(1,len(disjoint))
            ]
            latest_ratio = float(ratios[-1])
            mean_ratio = float(np.mean(ratios))
        else:
            alpha = np.nan
            r2 = np.nan
            latest_ratio = np.nan
            mean_ratio = np.nan

        width_rows.append(dict(
            width=w,
            approximate_cutoff_factor=float(
                np.median([
                    L[j+w]/L[j]
                    for j in range(len(L)-w)
                ])
            ),
            overlapping_block_count=len(rows_this),
            disjoint_block_count=len(disjoint),
            disjoint_power_alpha=alpha,
            disjoint_power_R2=r2,
            disjoint_latest_ratio=latest_ratio,
            disjoint_mean_ratio=mean_ratio,
            mean_cancellation_factor=float(
                np.mean([r["cancellation_factor"] for r in rows_this])
            ),
            median_cancellation_factor=float(
                np.median([r["cancellation_factor"] for r in rows_this])
            ),
            latest_overlapping_endpoint=float(rows_this[-1]["endpoint_l1"]),
            latest_overlapping_cancellation=float(
                rows_this[-1]["cancellation_factor"]
            ),
        ))

    blocks_df = pd.DataFrame(block_rows)
    widths_df = pd.DataFrame(width_rows)

    # ------------------------------------------------------------------
    # Modewise factor-2 (w=2) endpoint increments on disjoint blocks.
    # ------------------------------------------------------------------
    mode_rows = []

    if 2 in widths and len(L) >= 5:
        starts = list(range(0, len(L)-2, 2))

        for k in range(n):
            vals = []
            Ls = []

            for j in starts:
                if j+2 >= len(L):
                    continue
                vals.append(abs(lam[j+2,k]-lam[j,k]))
                Ls.append(L[j])

            vals = np.asarray(vals,dtype=float)
            Ls = np.asarray(Ls,dtype=float)

            alpha, r2 = fit_power(Ls, vals)

            if len(vals) >= 2:
                latest_ratio = float(vals[-1]/max(vals[-2],1e-300))
            else:
                latest_ratio = np.nan

            mode_rows.append(dict(
                k=k+1,
                blocks=len(vals),
                first_factor2_increment=float(vals[0]) if len(vals) else np.nan,
                latest_factor2_increment=float(vals[-1]) if len(vals) else np.nan,
                latest_over_first=float(
                    vals[-1]/max(vals[0],1e-300)
                ) if len(vals) else np.nan,
                latest_ratio=latest_ratio,
                power_alpha=alpha,
                power_R2=r2,
            ))

    modes_w2_df = pd.DataFrame(mode_rows)

    # ------------------------------------------------------------------
    # Decision around factor-2 coarse increments.
    # ------------------------------------------------------------------
    w2 = None
    for r in width_rows:
        if r["width"] == 2:
            w2 = r
            break

    if w2 is not None:
        factor2_pass = bool(
            np.isfinite(w2["disjoint_latest_ratio"])
            and w2["disjoint_latest_ratio"]
                < args.factor2_latest_ratio_gate
            and np.isfinite(w2["disjoint_power_alpha"])
            and w2["disjoint_power_alpha"]
                > args.factor2_positive_alpha_gate
        )
    else:
        factor2_pass = False

    if factor2_pass:
        verdict = "COARSE_FACTOR2_ENDPOINT_CONTRACTION_STRONGLY_SUPPORTED"
    else:
        verdict = "COARSE_ENDPOINT_CONTRACTION_UNRESOLVED"

    blocks_df.to_csv(
        args.prefix+"_BLOCKS.csv",index=False
    )
    widths_df.to_csv(
        args.prefix+"_WIDTH_SUMMARY.csv",index=False
    )
    modes_w2_df.to_csv(
        args.prefix+"_MODES_W2.csv",index=False
    )

    summary = dict(
        version=166,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        cutoffs=L.tolist(),
        modes=n,
        width_summary=width_rows,
        factor2_pass=bool(factor2_pass),
        verdict=verdict,
        theorem_interpretation=(
            "If factor-2 endpoint increments contract more cleanly than "
            "sqrt(2)-shell total variation, formulate Lemma 1 on a dyadic "
            "subsequence lambda(2^j L0), then separately control intermediate "
            "cutoffs using local phase/root estimates."
        ),
    )

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda o: o.item() if isinstance(o,np.generic)
            else (_ for _ in ()).throw(
                TypeError(
                    f"Object of type {type(o).__name__} is not JSON serializable"
                )
            ),
        ),
        encoding="utf-8",
    )

    print()
    print("Coarse endpoint block summary")
    print("-" * 150)
    print(
        f"{'w':>3} {'factor':>9} {'overlap':>8} {'disjoint':>9} "
        f"{'alpha':>10} {'R2':>8} {'latest r':>10} "
        f"{'mean r':>10} {'mean cancel':>12} {'latest D':>13}"
    )

    for r in width_rows:
        print(
            f"{r['width']:3d} "
            f"{r['approximate_cutoff_factor']:9.4f} "
            f"{r['overlapping_block_count']:8d} "
            f"{r['disjoint_block_count']:9d} "
            f"{r['disjoint_power_alpha']:10.6f} "
            f"{r['disjoint_power_R2']:8.4f} "
            f"{r['disjoint_latest_ratio']:10.6f} "
            f"{r['disjoint_mean_ratio']:10.6f} "
            f"{r['mean_cancellation_factor']:12.4f} "
            f"{r['latest_overlapping_endpoint']:13.6e}"
        )

    if len(modes_w2_df):
        print()
        print("Worst factor-2 modal endpoint ratios")
        print("-" * 150)
        worst = modes_w2_df.sort_values(
            "latest_ratio",ascending=False
        ).head(min(16,n))

        print(
            f"{'k':>4} {'first':>14} {'latest':>14} "
            f"{'latest/first':>13} {'latest r':>10} "
            f"{'alpha':>10} {'R2':>8}"
        )
        for _,r in worst.iterrows():
            print(
                f"{int(r['k']):4d} "
                f"{r['first_factor2_increment']:14.6e} "
                f"{r['latest_factor2_increment']:14.6e} "
                f"{r['latest_over_first']:13.6f} "
                f"{r['latest_ratio']:10.6f} "
                f"{r['power_alpha']:10.6f} "
                f"{r['power_R2']:8.4f}"
            )

    print()
    print("=" * 150)
    if w2 is not None:
        print(f"factor-2 disjoint alpha            : {w2['disjoint_power_alpha']:.9f}")
        print(f"factor-2 disjoint R2               : {w2['disjoint_power_R2']:.6f}")
        print(f"factor-2 latest contraction ratio  : {w2['disjoint_latest_ratio']:.9f}")
        print(f"factor-2 mean cancellation factor  : {w2['mean_cancellation_factor']:.6f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 150)
    print("NEXT PROOF DECISION:")
    print("  If factor-2 endpoint increments contract cleanly, use a DYADIC")
    print("  Lemma-1 architecture:")
    print()
    print("      lambda(2^j L0) is Cauchy")
    print("      + intermediate-cutoff control")
    print("      => full cutoff independence.")
    print()
    print("  This avoids trying to bound the much stronger absolute shell")
    print("  variation that micromotion has repeatedly shown to be unstable.")


if __name__ == "__main__":
    main()
