#!/usr/bin/env python3
"""
ROT-RH v199 — HULL-GEOMETRY CUMULATIVE SWITCH-COST AUDIT

Static audit. No root continuation, no mpmath, no Xi/zeta/known zeros.

Uses only the frozen v169 dominance hull and candidate sequence.

For adjacent active hull layers j -> j+1:

    Delta a_j = beta_{j+1} - beta_j
    Delta gamma_j = gamma_{j+1} - gamma_j
    tau_j = switch time

and tests the Gamma-intercept geometry prediction

    (Delta gamma_j / Delta a_j) / tau_j  ->  2/pi.

Given a uniform homogenized switch-mass bound

    K_j <= K_bound,

the cumulative switch error satisfies

    E_switch(T_N)
      <= K_bound * sum_{j<N} Delta gamma_j / Delta a_j.

The driving term in Y'=gamma_active+epsilon is

    G_active(T_N)
      = integral gamma_active(tau) d tau,

computed exactly from the piecewise-constant active hull labels.

The theorem-shaped diagnostic is therefore

    B_N(K_bound)
      = K_bound * sum Delta gamma/Delta a
        / integral gamma_active d tau.

If B_N -> 0, the cumulative switch-error contribution is asymptotically
negligible relative to the active-gamma drive.

Two constants are reported:
  empirical K = 0.9545493177  (v198 mean)
  rigorous-numerical majorant C = 1.284148 (v198 sampled m <= C e^x)

No Xi / zeta / known zeros are used.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


TWOPI_INV = 2.0 / np.pi


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def safe_power_fit(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]
    if len(x) < 3:
        return np.nan, np.nan
    lx = np.log(x)
    ly = np.log(y)
    coef = np.polyfit(lx, ly, 1)
    pred = np.polyval(coef, lx)
    den = np.sum((ly-ly.mean())**2)
    r2 = 1.0 - np.sum((ly-pred)**2)/den if den > 0 else np.nan
    return float(coef[0]), float(r2)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv", required=True)
    ap.add_argument("--hull-csv", required=True)
    ap.add_argument("--empirical-K", type=float, default=0.9545493177)
    ap.add_argument("--majorant-C", type=float, default=1.284148)
    ap.add_argument(
        "--tail-start-switch",
        type=int,
        default=80,
        help="Start index for asymptotic fit diagnostics.",
    )
    ap.add_argument(
        "--report-switches",
        default="24,46,69,91,114,136,159",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_hull_cumulative_switch_cost_v199",
    )
    args = ap.parse_args()

    cand = pd.read_csv(args.candidates_csv)
    hull = (
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    if len(hull) < 2:
        raise RuntimeError("Hull needs at least two active segments.")

    # Resolve active layer beta/gamma robustly from hull, falling back to
    # nearest candidate match if required.
    layers = []
    for i, r in hull.iterrows():
        if "beta_active" in hull.columns and "gamma_active" in hull.columns:
            beta = float(r["beta_active"])
            gamma = float(r["gamma_active"])
        elif "beta" in hull.columns and "gamma" in hull.columns:
            beta = float(r["beta"])
            gamma = float(r["gamma"])
        else:
            raise RuntimeError(
                "Hull requires beta_active/gamma_active or beta/gamma columns."
            )

        # candidate snapping gives consistent exact layer metadata
        c = match_candidate(cand, beta, gamma)
        layers.append({
            "beta": float(c["beta"]),
            "gamma": float(c["gamma"]),
            "tau_start": float(r["tau_start"]),
            "tau_end": float(r["tau_end"]),
        })

    rows = []
    cum_cost_raw = 0.0
    cum_active = 0.0

    # Integrate active gamma segment-by-segment.  For endpoint after switch j,
    # include segment j (0-based left segment) through tau_end.
    for j in range(len(layers)-1):
        L = layers[j]
        R = layers[j+1]

        dt = L["tau_end"] - L["tau_start"]
        if dt < 0:
            raise RuntimeError(f"Negative hull duration at segment {j+1}.")
        cum_active += L["gamma"] * dt

        da = R["beta"] - L["beta"]
        dg = R["gamma"] - L["gamma"]
        tau = L["tau_end"]

        if da == 0:
            raw = np.inf
            q = np.inf
        else:
            raw = abs(dg/da)
            q = raw/tau if tau != 0 else np.inf

        cum_cost_raw += raw

        Bemp = args.empirical_K * cum_cost_raw / max(abs(cum_active), 1e-300)
        Bmaj = args.majorant_C * cum_cost_raw / max(abs(cum_active), 1e-300)

        # asymptotic 2/pi substitution
        cum_tau = sum(
            layers[k]["tau_end"]
            for k in range(j+1)
        )
        Bmaj_asym = (
            args.majorant_C * TWOPI_INV * cum_tau
            / max(abs(cum_active), 1e-300)
        )

        rows.append({
            "switch": j+1,
            "tau_switch": tau,
            "beta_left": L["beta"],
            "beta_right": R["beta"],
            "gamma_left": L["gamma"],
            "gamma_right": R["gamma"],
            "delta_a": da,
            "delta_gamma": dg,
            "raw_switch_scale_dg_over_da": raw,
            "q_raw_over_tau": q,
            "q_over_2pi_inverse": q/TWOPI_INV,
            "cum_raw_switch_scale": cum_cost_raw,
            "cum_active_gamma_integral": cum_active,
            "cum_empirical_error_ratio": Bemp,
            "cum_majorant_error_ratio": Bmaj,
            "cum_majorant_asym_2pi_ratio": Bmaj_asym,
            "local_empirical_ratio_vs_gamma_tau":
                args.empirical_K * raw / max(abs(L["gamma"]*tau), 1e-300),
            "local_majorant_ratio_vs_gamma_tau":
                args.majorant_C * raw / max(abs(L["gamma"]*tau), 1e-300),
        })

    df = pd.DataFrame(rows)

    # Tail fits.
    tail = df[df["switch"] >= args.tail_start_switch].copy()
    pB, r2B = safe_power_fit(
        tail["tau_switch"],
        tail["cum_majorant_error_ratio"],
    )
    pQ, r2Q = safe_power_fit(
        tail["tau_switch"],
        np.abs(tail["q_raw_over_tau"]-TWOPI_INV),
    )

    # Compare raw hull identity to 2/pi.
    q = df["q_raw_over_tau"].to_numpy(float)
    qrel = np.abs(q/TWOPI_INV - 1.0)

    report_switches = [
        int(s.strip())
        for s in args.report_switches.split(",")
        if s.strip()
    ]
    report = df[df["switch"].isin(report_switches)].copy()

    # Check cumulative tau dominance:
    # sum_{k<=j} tau_k / tau_j
    taus = df["tau_switch"].to_numpy(float)
    ctaus = np.cumsum(taus)
    df["cum_tau_over_latest_tau"] = ctaus/taus

    # active integral relative to latest gamma*tau
    df["active_integral_over_gamma_tau"] = (
        df["cum_active_gamma_integral"]
        / (
            df["gamma_left"].to_numpy(float)
            * df["tau_switch"].to_numpy(float)
        )
    )

    # A clean sufficient-condition proxy:
    # majorant cumulative ratio <= C*(2/pi)*(sum tau)/(active integral)
    # already reported above.
    final = df.iloc[-1]

    # Monotonic tail decrease check for the actual cumulative majorant ratio.
    tailB = tail["cum_majorant_error_ratio"].to_numpy(float)
    tail_decrease_fraction = (
        float(np.mean(np.diff(tailB) < 0))
        if len(tailB) > 1 else np.nan
    )

    # Conservative verdict.
    q_identity_supported = bool(
        np.nanmedian(qrel[-min(40,len(qrel)):]) <= 0.05
    )
    cumulative_decay_supported = bool(
        np.isfinite(pB)
        and pB < -0.1
        and tail_decrease_fraction >= 0.8
        and float(final["cum_majorant_error_ratio"]) < 0.05
    )

    if q_identity_supported and cumulative_decay_supported:
        verdict = "HULL_GEOMETRY_CUMULATIVE_SWITCH_COST_DECAY_SUPPORTED"
    elif cumulative_decay_supported:
        verdict = "CUMULATIVE_SWITCH_COST_DECAY_SUPPORTED_GEOMETRY_PARTIAL"
    else:
        verdict = "CUMULATIVE_SWITCH_COST_DECAY_UNRESOLVED"

    df.to_csv(args.prefix+"_SWITCHES.csv", index=False)

    summary = {
        "version": 199,
        "switches": len(df),
        "two_over_pi": TWOPI_INV,
        "q_raw_over_tau_median_all": float(np.nanmedian(q)),
        "q_raw_over_tau_median_last40": float(np.nanmedian(q[-min(40,len(q)):])),
        "q_relative_error_median_last40": float(
            np.nanmedian(qrel[-min(40,len(qrel)):])
        ),
        "q_relative_error_max_last40": float(
            np.nanmax(qrel[-min(40,len(qrel)):])
        ),
        "final_cumulative_empirical_error_ratio": float(
            final["cum_empirical_error_ratio"]
        ),
        "final_cumulative_majorant_error_ratio": float(
            final["cum_majorant_error_ratio"]
        ),
        "final_cumulative_majorant_asym_2pi_ratio": float(
            final["cum_majorant_asym_2pi_ratio"]
        ),
        "final_cum_tau_over_latest_tau": float(
            final["cum_tau_over_latest_tau"]
        ),
        "final_active_integral_over_gamma_tau": float(
            final["active_integral_over_gamma_tau"]
        ),
        "tail_majorant_ratio_power_vs_tau": pB,
        "tail_majorant_ratio_log_R2": r2B,
        "tail_decrease_fraction": tail_decrease_fraction,
        "q_error_power_vs_tau": pQ,
        "q_error_log_R2": r2Q,
        "q_identity_supported": q_identity_supported,
        "cumulative_decay_supported": cumulative_decay_supported,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print("="*188)
    print("ROT-RH v199 — HULL-GEOMETRY CUMULATIVE SWITCH-COST AUDIT")
    print("="*188)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switches                          : {len(df)}")
    print(f"2/pi                              : {TWOPI_INV:.12e}")
    print(f"empirical K                       : {args.empirical_K:.12e}")
    print(f"majorant C                        : {args.majorant_C:.12e}")
    print("="*188)

    for _, r in report.iterrows():
        print(
            f"[switch {int(r['switch']):3d}] "
            f"tau={r['tau_switch']:.3e} "
            f"gamma={r['gamma_left']:.3e} "
            f"(dg/da)/tau={r['q_raw_over_tau']:.6e} "
            f"/(2/pi)={r['q_over_2pi_inverse']:.6e} "
            f"cumMaj/active={r['cum_majorant_error_ratio']:.6e}"
        )

    print()
    print(f"median (dg/da)/tau, last 40       : {summary['q_raw_over_tau_median_last40']:.12e}")
    print(f"median rel error vs 2/pi, last 40 : {summary['q_relative_error_median_last40']:.6e}")
    print(f"max rel error vs 2/pi, last 40    : {summary['q_relative_error_max_last40']:.6e}")
    print(f"final empirical cumulative ratio  : {summary['final_cumulative_empirical_error_ratio']:.12e}")
    print(f"final majorant cumulative ratio   : {summary['final_cumulative_majorant_error_ratio']:.12e}")
    print(f"final 2/pi asym majorant ratio    : {summary['final_cumulative_majorant_asym_2pi_ratio']:.12e}")
    print(f"sum tau_j / latest tau            : {summary['final_cum_tau_over_latest_tau']:.6e}")
    print(f"active integral / (gamma*tau)     : {summary['final_active_integral_over_gamma_tau']:.6e}")
    print(f"tail cumulative ratio ~ tau^p     : p={pB:.6f} log-R2={r2B:.6f}")
    print(f"tail decrease fraction            : {tail_decrease_fraction:.6f}")
    print(f"VERDICT                           : {verdict}")
    print("="*188)


if __name__ == "__main__":
    main()
