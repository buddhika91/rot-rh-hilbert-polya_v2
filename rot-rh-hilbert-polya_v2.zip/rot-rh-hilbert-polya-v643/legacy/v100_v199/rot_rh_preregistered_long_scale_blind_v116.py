#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v116 — Preregistered Long-Scale Blind Staircase Replication
==================================================================

BACKGROUND
----------
v114 was a preregistered FAIL for the hypothesis that *each 80-cell window*
shows cumulative suppression, although:
  * 4/4 blind 80-cell windows showed low-frequency suppression;
  * the combined 320-cell blind region showed very strong cumulative and
    low-frequency suppression.

v115 established that those v114 statistics were numerically stable under
a much finer PNT-counterterm quadrature.

v116 therefore freezes a NEW hypothesis BEFORE computing any new roots:

    The natural structured-cancellation scale is >=160 cells.

FRESH BLIND REGION
------------------
No cell k>=448 has been inspected in the prior v114/v115 sequence.

Default confirmatory windows:
    W1 = 448..607   (160 fresh cells)
    W2 = 608..767   (160 fresh cells)
    Combined = 448..767 (320 fresh cells)

Preregistered PASS gates
------------------------
Both 160-cell windows must independently satisfy:
    cumulative permutation lower-tail percentile <= 0.05
    low-frequency permutation lower-tail percentile <= 0.05

The combined 320-cell region must satisfy:
    cumulative percentile <= 0.01
    low-frequency percentile <= 0.01

These gates are written to a PREFREEZE manifest before the phase/support is
constructed.

Non-gated diagnostics:
    * four 80-cell subwindows;
    * cumulative prefix growth at 80,160,240,320 cells;
    * dyadic block-sum suppression;
    * max |F-N|;
    * apparent growth exponent.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss

VERSION = "v116"
BUILD = "2026-08-17-preregistered-long-scale-blind-staircase-v116"
EPS = 1e-30


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def cell_area(phase, lo, hi, k, q):
    E, W = nodes(float(lo), float(hi), int(q))
    F = np.asarray(phase.F(E), float)
    Q = F - float(k)
    return {
        "Q_area": float(np.sum(W * Q)),
        "abs_Q_area": float(np.sum(W * np.abs(Q))),
        "max_abs_Q": float(np.max(np.abs(Q))),
        "min_Q": float(np.min(Q)),
        "max_Q": float(np.max(Q)),
        "width": float(hi - lo),
    }


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c) - np.min(c))


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def permutation_metrics(x, nperm, rng, lowfreq_bins):
    x = np.asarray(x, float)
    real_c = cumulative_max(x)
    real_r = cumulative_range(x)
    real_l = lowfreq_fraction(x, lowfreq_bins)

    pc = np.empty(int(nperm), float)
    pr = np.empty(int(nperm), float)
    pl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        y = rng.permutation(x)
        pc[t] = cumulative_max(y)
        pr[t] = cumulative_range(y)
        pl[t] = lowfreq_fraction(y, lowfreq_bins)

    return {
        "cell_count": len(x),
        "mean_area": float(np.mean(x)),
        "mean_abs_area": float(np.mean(np.abs(x))),
        "rms_area": float(np.sqrt(np.mean(x*x))),
        "max_abs_area": float(np.max(np.abs(x))),
        "sum_area": float(np.sum(x)),
        "real_cumulative_max": real_c,
        "real_cumulative_range": real_r,
        "real_lowfreq_fraction": real_l,
        "perm_cumulative_max_mean": float(np.mean(pc)),
        "perm_cumulative_max_median": float(np.median(pc)),
        "perm_cumulative_max_p05": float(np.quantile(pc, 0.05)),
        "perm_cumulative_max_p95": float(np.quantile(pc, 0.95)),
        "cumulative_lower_tail_percentile": percentile_le(pc, real_c),
        "perm_cumulative_range_mean": float(np.mean(pr)),
        "range_lower_tail_percentile": percentile_le(pr, real_r),
        "perm_lowfreq_mean": float(np.mean(pl)),
        "perm_lowfreq_p05": float(np.quantile(pl, 0.05)),
        "perm_lowfreq_p95": float(np.quantile(pl, 0.95)),
        "lowfreq_lower_tail_percentile": percentile_le(pl, real_l),
    }


def dyadic_block_rms(x, block):
    x = np.asarray(x, float)
    b = int(block)
    n = len(x) // b
    if n < 1:
        return float("nan")
    y = x[:n*b].reshape(n, b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))


def growth_exponent(prefix_lengths, prefix_cmax):
    n = np.asarray(prefix_lengths, float)
    y = np.asarray(prefix_cmax, float)
    mask = (n > 0) & (y > 0)
    if np.sum(mask) < 3:
        return float("nan")
    X = np.column_stack([np.ones(np.sum(mask)), np.log(n[mask])])
    beta, *_ = np.linalg.lstsq(X, np.log(y[mask]), rcond=None)
    return float(beta[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--blind-start", type=int, default=448)
    ap.add_argument("--window-size", type=int, default=160)
    ap.add_argument("--blind-windows", type=int, default=2)
    ap.add_argument("--max-depth", type=int, default=768)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=3072)
    ap.add_argument("--counter-qcheck", type=int, default=6144)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--cell-q", type=int, default=64)
    ap.add_argument("--cell-qcheck", type=int, default=128)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--lowfreq-bins", type=int, default=4)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument(
        "--prefix",
        default="rot_rh_long_scale_blind_staircase_v116",
    )
    args = ap.parse_args()

    if args.blind_windows != 2:
        raise ValueError(
            "v116 preregistration is frozen for exactly two 160-cell windows."
        )
    if args.window_size != 160:
        raise ValueError(
            "v116 preregistration is frozen for window-size=160."
        )
    if args.blind_start != 448:
        raise ValueError(
            "v116 preregistration is frozen for blind-start=448."
        )

    windows = []
    for j in range(args.blind_windows):
        a = args.blind_start + j * args.window_size
        b = a + args.window_size - 1
        windows.append((a, b))
    combined = (windows[0][0], windows[-1][1])

    required_depth = combined[1] + 1
    if args.max_depth < required_depth:
        raise ValueError(
            f"Need max-depth >= {required_depth}; got {args.max_depth}"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    try:
        code_path = Path(__file__).resolve()
        code_sha = sha256_file(code_path)
    except Exception:
        code_path = None
        code_sha = None

    prereg = {
        "version": VERSION,
        "build": BUILD,
        "created_before_blind_support": True,
        "scientific_preregistration": True,
        "code_path": str(code_path) if code_path else None,
        "code_sha256": code_sha,
        "L": int(args.L),
        "fresh_blind_windows": [list(x) for x in windows],
        "combined_blind_window": list(combined),
        "prior_data_boundary": 447,
        "hypothesis": (
            "Structured staircase cancellation replicates at a natural scale "
            "of 160 cells or longer, even though the earlier 80-cell "
            "cumulative hypothesis failed."
        ),
        "pass_gates": {
            "W1_cumulative_percentile": "<=0.05",
            "W1_lowfreq_percentile": "<=0.05",
            "W2_cumulative_percentile": "<=0.05",
            "W2_lowfreq_percentile": "<=0.05",
            "combined_cumulative_percentile": "<=0.01",
            "combined_lowfreq_percentile": "<=0.01",
        },
        "non_gated": [
            "80-cell subwindow statistics",
            "prefix growth",
            "growth exponent",
            "dyadic block suppression",
            "max |F-N|",
        ],
        "counter_q": int(args.counter_q),
        "counter_qcheck": int(args.counter_qcheck),
        "permutations": int(args.permutations),
        "lowfreq_bins": int(args.lowfreq_bins),
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
    }
    prereg_path = Path(str(prefix) + "_PREFREEZE.json")
    prereg_path.write_text(json.dumps(prereg, indent=2), encoding="utf-8")
    prereg_sha = sha256_file(prereg_path)

    print("=" * 160)
    print("ROT-RH v116 — PREREGISTERED LONG-SCALE BLIND STAIRCASE REPLICATION")
    print("=" * 160)
    print("PREFREEZE SHA                   :", prereg_sha)
    print("L                               :", args.L)
    print("fresh blind windows             :", windows)
    print("combined blind                  :", combined)
    print("max depth                       :", args.max_depth)
    print("counter q / qcheck              :", args.counter_q, "/", args.counter_qcheck)
    print("permutations                    :", args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 160)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("[1] Build zero-free high-resolution phase and fresh deep support", flush=True)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    support = v102.ordered_support(
        phase,
        depth=int(args.max_depth),
        scan_points=int(args.scan_points),
        qcheck=int(args.counter_qcheck),
    )
    roots = np.asarray(support.roots, float)

    print(
        f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
        f"maxres={np.max(support.residuals):.3e} "
        f"qphase={support.quadrature_phase_rel_l2:.3e} "
        f"qder={support.quadrature_deriv_rel_l2:.3e}"
    )

    print("[2] Compute 320 entirely fresh cell areas", flush=True)
    cell_rows = []
    for k in range(combined[0], combined[1] + 1):
        lo = float(roots[k - 1])
        hi = float(roots[k])
        r = cell_area(phase, lo, hi, k, args.cell_q)
        rc = cell_area(phase, lo, hi, k, args.cell_qcheck)

        cell_rows.append({
            "L": args.L,
            "cell_k": k,
            "lo": lo,
            "hi": hi,
            "width": rc["width"],
            "Q_area": rc["Q_area"],
            "Q_area_qcheck_absdiff": abs(r["Q_area"] - rc["Q_area"]),
            "abs_Q_area": rc["abs_Q_area"],
            "max_abs_Q": rc["max_abs_Q"],
            "min_Q": rc["min_Q"],
            "max_Q": rc["max_Q"],
        })

        if (k - combined[0] + 1) % 80 == 0:
            block = cell_rows[-80:]
            print(
                f"  through k={k}: max|Q|="
                f"{max(x['max_abs_Q'] for x in block):.6f} "
                f"max qdiff="
                f"{max(x['Q_area_qcheck_absdiff'] for x in block):.2e}"
            )

    cmap = {int(r["cell_k"]): r for r in cell_rows}

    def seq(a, b):
        return np.asarray(
            [float(cmap[k]["Q_area"]) for k in range(a, b + 1)],
            float,
        )

    rng = np.random.default_rng(args.seed)

    print("[3] Frozen 160-cell confirmatory tests", flush=True)
    window_rows = []
    gated_rows = []
    for j, (a, b) in enumerate(windows, start=1):
        met = permutation_metrics(
            seq(a, b), args.permutations, rng, args.lowfreq_bins
        )
        row = {
            "kind": "gated_160",
            "window_index": j,
            "k_start": a,
            "k_end": b,
            **met,
        }
        window_rows.append(row)
        gated_rows.append(row)
        print(
            f"  W{j} {a}-{b}: "
            f"cumPct={100*met['cumulative_lower_tail_percentile']:.4f}% "
            f"lowFPct={100*met['lowfreq_lower_tail_percentile']:.4f}% "
            f"cumMax={met['real_cumulative_max']:.3e}"
        )

    combined_met = permutation_metrics(
        seq(*combined), args.permutations, rng, args.lowfreq_bins
    )
    combined_row = {
        "kind": "gated_combined_320",
        "window_index": 999,
        "k_start": combined[0],
        "k_end": combined[1],
        **combined_met,
    }
    window_rows.append(combined_row)
    print(
        f"  COMBINED {combined[0]}-{combined[1]}: "
        f"cumPct={100*combined_met['cumulative_lower_tail_percentile']:.4f}% "
        f"lowFPct={100*combined_met['lowfreq_lower_tail_percentile']:.4f}% "
        f"cumMax={combined_met['real_cumulative_max']:.3e}"
    )

    print("[4] Non-gated 80-cell subwindows", flush=True)
    sub80_rows = []
    sub_start = combined[0]
    sub_index = 0
    while sub_start <= combined[1]:
        sub_end = sub_start + 79
        met = permutation_metrics(
            seq(sub_start, sub_end),
            args.permutations,
            rng,
            args.lowfreq_bins,
        )
        row = {
            "kind": "diagnostic_80",
            "window_index": sub_index + 1,
            "k_start": sub_start,
            "k_end": sub_end,
            **met,
        }
        sub80_rows.append(row)
        window_rows.append(row)
        print(
            f"  d80-{sub_index+1} {sub_start}-{sub_end}: "
            f"cumPct={100*met['cumulative_lower_tail_percentile']:.3f}% "
            f"lowFPct={100*met['lowfreq_lower_tail_percentile']:.3f}%"
        )
        sub_index += 1
        sub_start = sub_end + 1

    print("[5] Non-gated growth / scale diagnostics", flush=True)
    full = seq(*combined)
    prefix_rows = []
    pns = []
    pcms = []
    for n in [80, 160, 240, 320]:
        x = full[:n]
        cm = cumulative_max(x)
        pns.append(n)
        pcms.append(cm)
        prefix_rows.append({
            "prefix_cells": n,
            "k_end": combined[0] + n - 1,
            "cumulative_max": cm,
            "cumulative_range": cumulative_range(x),
            "lowfreq_fraction": lowfreq_fraction(x, args.lowfreq_bins),
        })
        print(
            f"  prefix n={n:<3d} k_end={combined[0]+n-1}: "
            f"cumMax={cm:.3e}"
        )
    alpha = growth_exponent(pns, pcms)
    print("  growth alpha                    :", f"{alpha:+.6f}")

    block_rows = []
    for b in [1, 2, 4, 8, 16, 32, 64, 80, 160]:
        if b > len(full):
            continue
        real = dyadic_block_rms(full, b)
        ctrl = np.empty(args.permutations, float)
        for t in range(args.permutations):
            ctrl[t] = dyadic_block_rms(rng.permutation(full), b)
        block_rows.append({
            "block_size": b,
            "real_block_sum_rms": real,
            "perm_mean": float(np.mean(ctrl)),
            "perm_p05": float(np.quantile(ctrl, 0.05)),
            "perm_p95": float(np.quantile(ctrl, 0.95)),
            "lower_tail_percentile": percentile_le(ctrl, real),
            "suppression_ratio":
                real / max(float(np.mean(ctrl)), EPS),
        })

    max_qdiff = max(r["Q_area_qcheck_absdiff"] for r in cell_rows)
    max_abs_Q = max(r["max_abs_Q"] for r in cell_rows)

    gates = {
        "deep_root_residual_below_1e8":
            bool(float(np.max(support.residuals)) < 1e-8),
        "counterterm_quadrature_stable":
            bool(
                support.quadrature_phase_rel_l2 < 5e-6
                and support.quadrature_deriv_rel_l2 < 5e-6
            ),
        "cell_quadrature_stable":
            bool(max_qdiff < 1e-8),

        "W1_cumulative_p_le_0p05":
            bool(gated_rows[0]["cumulative_lower_tail_percentile"] <= 0.05),
        "W1_lowfreq_p_le_0p05":
            bool(gated_rows[0]["lowfreq_lower_tail_percentile"] <= 0.05),
        "W2_cumulative_p_le_0p05":
            bool(gated_rows[1]["cumulative_lower_tail_percentile"] <= 0.05),
        "W2_lowfreq_p_le_0p05":
            bool(gated_rows[1]["lowfreq_lower_tail_percentile"] <= 0.05),

        "combined_cumulative_p_le_0p01":
            bool(combined_met["cumulative_lower_tail_percentile"] <= 0.01),
        "combined_lowfreq_p_le_0p01":
            bool(combined_met["lowfreq_lower_tail_percentile"] <= 0.01),
    }

    numerical = [
        "deep_root_residual_below_1e8",
        "counterterm_quadrature_stable",
        "cell_quadrature_stable",
    ]
    scientific = [
        "W1_cumulative_p_le_0p05",
        "W1_lowfreq_p_le_0p05",
        "W2_cumulative_p_le_0p05",
        "W2_lowfreq_p_le_0p05",
        "combined_cumulative_p_le_0p01",
        "combined_lowfreq_p_le_0p01",
    ]

    if all(gates[k] for k in numerical) and all(gates[k] for k in scientific):
        verdict = (
            "PASS_V116_PREREGISTERED_LONG_SCALE_CANCELLATION_REPLICATES_BLIND"
        )
    elif all(gates[k] for k in numerical):
        verdict = (
            "NO_GO_V116_LONG_SCALE_CANCELLATION_DOES_NOT_MEET_FROZEN_BLIND_GATES"
        )
    else:
        verdict = "FAIL_V116_NUMERICAL_SUPPORT_INVALID"

    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_WINDOWS.csv"), window_rows)
    write_csv(Path(str(prefix) + "_PREFIX_GROWTH.csv"), prefix_rows)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "prefreeze_sha256": prereg_sha,
        "gates": gates,
        "fresh_windows": [list(x) for x in windows],
        "combined_window": list(combined),
        "W1": gated_rows[0],
        "W2": gated_rows[1],
        "combined": combined_met,
        "diagnostic_80_windows_not_gated": sub80_rows,
        "growth_alpha_not_gated": alpha,
        "max_abs_Q_not_gated": max_abs_Q,
        "max_cell_qcheck_difference": max_qdiff,
        "interpretation": (
            "A PASS is a genuinely fresh preregistered replication of the "
            "post-v114 hypothesis that structured staircase cancellation "
            "acts reliably on >=160-cell scales. It still does not prove a "
            "uniformly bounded primitive as k->infinity."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 160)
    print("FINAL v116 VERDICT")
    print("=" * 160)
    print("verdict                         :", verdict)
    print("PREFREEZE SHA                   :", prereg_sha)
    print("W1 cumulative pct               :",
          f"{100*gated_rows[0]['cumulative_lower_tail_percentile']:.6f}%")
    print("W1 lowfreq pct                  :",
          f"{100*gated_rows[0]['lowfreq_lower_tail_percentile']:.6f}%")
    print("W2 cumulative pct               :",
          f"{100*gated_rows[1]['cumulative_lower_tail_percentile']:.6f}%")
    print("W2 lowfreq pct                  :",
          f"{100*gated_rows[1]['lowfreq_lower_tail_percentile']:.6f}%")
    print("combined cumulative pct         :",
          f"{100*combined_met['cumulative_lower_tail_percentile']:.6f}%")
    print("combined lowfreq pct            :",
          f"{100*combined_met['lowfreq_lower_tail_percentile']:.6f}%")
    print("growth alpha (not gated)        :", f"{alpha:.12e}")
    print("max |F-N| (not gated)           :", f"{max_abs_Q:.12e}")
    print("max cell q-check difference     :", f"{max_qdiff:.12e}")
    print("qphase                          :", f"{support.quadrature_phase_rel_l2:.12e}")
    print("qder                            :", f"{support.quadrature_deriv_rel_l2:.12e}")
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 160)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
