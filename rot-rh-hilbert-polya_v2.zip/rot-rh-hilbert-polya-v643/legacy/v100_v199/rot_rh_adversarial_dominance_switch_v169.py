#!/usr/bin/env python3
"""
ROT-RH v169 — ADVERSARIAL DOMINANCE-SWITCH / CESARO-ACTIVE-ORDINATE AUDIT

Purpose
-------
Attack the proposed dominance-switch condition

    A(T) = (1/T) ∫_{tau0}^T gamma_active(tau) d tau

by constructing SYNTHETIC hypothetical zero layers rho_j = beta_j + i gamma_j
that satisfy only a chosen zero-free-region envelope.

This script is a theorem-falsifier for the implication

    [zero-free envelope + basic strip constraints]
        => [bounded/convergent Cesaro active ordinate].

It is NOT a simulation of the actual zeta zeros, and a synthetic failure is
NOT a counterexample to RH or to the actual ROT-RH operator.  A failure means
only that the selected generic constraints are insufficient to prove the
dominance-switch theorem.

Amplitude model
---------------
For a fixed bounded spectral reference E, the zero contribution has the
leading logarithmic amplitude

    S_rho(tau;E)
      = (beta - 1/2) tau
        + Re log Gamma(beta-1/2 + i(E-gamma))
        [+ log|2^(rho-s)-1| if --include-dyadic-factor].

For fixed rho and E this is an EXACT LINE in tau:

    S_j(tau) = a_j tau + b_j.

The script computes the exact upper hull of these lines.  Therefore switch
times and the integral of gamma_active are evaluated analytically, not from
a fine tau grid.

Zero-free envelope
------------------
Default:
    beta <= 1 - 1/[R (log gamma)^(2/3) (log log gamma)^(1/3)]

with R=55.241, a conservative fully explicit Vinogradov-Korobov-type
constant available in the literature for |t| >= 3.

R is deliberately parameterized.  For an asymptotic Ford-style stronger
model one may run, for example,

    --vk-R 49.13

provided one interprets that choice in its asymptotic range.

Models
------
1. zero_free_boundary
   Dense log-gamma grid with beta exactly at the allowed right boundary.
   This is pointwise adversarial in beta.

2. optimized_sequence
   For logarithmically spaced tau anchors, directly optimize gamma to
   maximize S(tau) on the zero-free boundary.  The union of those optimizers
   is then passed to the exact line-hull calculation.

3. random_adversarial
   Random gamma and beta values inside the allowed region.  Many trials are
   searched and the trial maximizing the terminal Cesaro ordinate is kept.

Main verdicts
-------------
KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE
    A sparse synthetic sequence satisfying the selected constraints develops
    an unbounded-looking active ordinate / growing Cesaro mean over the tested
    asymptotic window.  Therefore those constraints ALONE cannot prove DS.

NO_ADVERSARIAL_DS_FAILURE_FOUND
    No failure was found.  This is NOT a proof; inspect the active hull for a
    structural inequality worth proving.

GAMMA_RANGE_SATURATED_INCREASE_MAX
    The active layer reached the top of the gamma search range, so enlarge it.

NO Xi, zeta evaluation, or known-zero ordinates are used.

Outputs
-------
<prefix>_<model>_CANDIDATES.csv
<prefix>_<model>_HULL.csv
<prefix>_<model>_CESARO.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import minimize_scalar
    from scipy.special import loggamma
except Exception as exc:
    raise RuntimeError(
        "v169 requires scipy.optimize and scipy.special."
    ) from exc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def safe_loglog(gamma):
    lg = np.log(gamma)
    llg = np.log(lg)
    return lg, llg


def beta_boundary(gamma, R, margin=0.0):
    """
    Admissible right boundary:
        beta <= 1 - 1/[R (log g)^(2/3)(loglog g)^(1/3)].

    Returns NaN if loglog gamma is not positive or if the boundary is <= 1/2.
    """
    g = np.asarray(gamma, dtype=float)
    out = np.full_like(g, np.nan, dtype=float)

    ok = g > math.e
    if not np.any(ok):
        return out

    lg = np.log(g[ok])
    llg = np.log(lg)

    ok2 = llg > 0
    vals = np.full_like(lg, np.nan)

    denom = (
        R
        * np.power(lg[ok2], 2.0/3.0)
        * np.power(llg[ok2], 1.0/3.0)
    )
    vals[ok2] = 1.0 - 1.0/denom - margin

    tmp = out[ok]
    tmp[:] = vals
    out[ok] = tmp

    out[out <= 0.5] = np.nan
    out[out >= 1.0] = np.nextafter(1.0, 0.0)
    return out


def line_intercept(beta, gamma, E_ref, include_dyadic_factor):
    """
    b_j = Re log Gamma(a + i(E-gamma)) + optional dyadic-difference factor.
    """
    beta = np.asarray(beta, dtype=float)
    gamma = np.asarray(gamma, dtype=float)

    a = beta - 0.5
    z = a + 1j*(E_ref-gamma)

    b = np.real(loggamma(z))

    if include_dyadic_factor:
        # |2^z - 1| is bounded and stable here because Re z < 1/2.
        q = np.exp(z*math.log(2.0)) - 1.0
        b = b + np.log(np.maximum(np.abs(q), 1e-300))

    return b


def make_candidates(gamma, beta, E_ref, include_dyadic_factor, source):
    gamma = np.asarray(gamma, dtype=float)
    beta = np.asarray(beta, dtype=float)

    ok = (
        np.isfinite(gamma)
        & np.isfinite(beta)
        & (gamma > 0)
        & (beta > 0.5)
        & (beta < 1.0)
    )

    gamma = gamma[ok]
    beta = beta[ok]

    slope = beta - 0.5
    intercept = line_intercept(
        beta, gamma, E_ref, include_dyadic_factor
    )

    ok2 = np.isfinite(intercept)
    gamma = gamma[ok2]
    beta = beta[ok2]
    slope = slope[ok2]
    intercept = intercept[ok2]

    df = pd.DataFrame({
        "gamma": gamma,
        "beta": beta,
        "slope": slope,
        "intercept": intercept,
        "source": source,
    })

    # Duplicate slopes are useless except for the largest intercept.
    # Quantization prevents numerical near-duplicates from bloating the hull.
    if len(df):
        df["slope_key"] = np.round(df["slope"], 14)
        idx = df.groupby("slope_key")["intercept"].idxmax()
        df = df.loc[idx].drop(columns=["slope_key"])
        df = df.sort_values(["slope", "intercept"]).reset_index(drop=True)

    return df


@dataclass
class HullLine:
    gamma: float
    beta: float
    slope: float
    intercept: float
    start: float   # tau at which this line becomes the upper envelope


def build_upper_hull(candidates: pd.DataFrame):
    """
    Exact upper envelope of lines y = m tau + b.

    Lines are sorted by increasing slope.  Each retained hull line stores the
    tau value at which it first dominates the previous hull line.
    """
    if len(candidates) == 0:
        return []

    c = candidates.sort_values(["slope", "intercept"]).copy()

    # Keep only the highest intercept for exactly repeated slopes.
    reduced = []
    for _, r in c.iterrows():
        m = float(r["slope"])
        if reduced and abs(m-reduced[-1]["slope"]) <= 1e-15:
            if float(r["intercept"]) > reduced[-1]["intercept"]:
                reduced[-1] = {
                    "gamma": float(r["gamma"]),
                    "beta": float(r["beta"]),
                    "slope": m,
                    "intercept": float(r["intercept"]),
                }
        else:
            reduced.append({
                "gamma": float(r["gamma"]),
                "beta": float(r["beta"]),
                "slope": m,
                "intercept": float(r["intercept"]),
            })

    hull: list[HullLine] = []

    for r in reduced:
        m = r["slope"]
        b = r["intercept"]

        while hull:
            last = hull[-1]
            # New = last at:
            # (m-last.m) tau = last.b - b
            denom = m-last.slope
            if denom <= 0:
                raise RuntimeError("Hull slopes are not strictly increasing.")

            x = (last.intercept-b)/denom

            if x <= last.start:
                hull.pop()
            else:
                break

        if not hull:
            start = -np.inf
        else:
            last = hull[-1]
            start = (last.intercept-b)/(m-last.slope)

        hull.append(HullLine(
            gamma=r["gamma"],
            beta=r["beta"],
            slope=m,
            intercept=b,
            start=float(start),
        ))

    return hull


def hull_segments(hull, tau_min, tau_max):
    """
    Restrict exact hull to [tau_min, tau_max].
    """
    rows = []

    for i, h in enumerate(hull):
        left = max(tau_min, h.start)
        right = tau_max

        if i+1 < len(hull):
            right = min(right, hull[i+1].start)

        if right <= left:
            continue

        rows.append({
            "hull_index": i,
            "tau_start": float(left),
            "tau_end": float(right),
            "duration": float(right-left),
            "gamma_active": h.gamma,
            "beta_active": h.beta,
            "slope": h.slope,
            "intercept": h.intercept,
            "score_at_start": h.slope*left+h.intercept,
            "score_at_end": h.slope*right+h.intercept,
        })

    return pd.DataFrame(rows)


def active_at_tau(segments: pd.DataFrame, tau):
    if len(segments) == 0:
        return np.nan, np.nan
    hit = segments[
        (segments["tau_start"] <= tau)
        & (tau <= segments["tau_end"] + 1e-12)
    ]
    if len(hit):
        r = hit.iloc[-1]
        return float(r["gamma_active"]), float(r["beta_active"])

    # Numerical endpoint fallback.
    if tau < float(segments.iloc[0]["tau_start"]):
        r = segments.iloc[0]
    else:
        r = segments.iloc[-1]
    return float(r["gamma_active"]), float(r["beta_active"])


def integral_gamma_to(segments: pd.DataFrame, tau_min, tau):
    if tau <= tau_min or len(segments) == 0:
        return 0.0

    total = 0.0
    for _, r in segments.iterrows():
        a = max(float(r["tau_start"]), tau_min)
        b = min(float(r["tau_end"]), tau)
        if b > a:
            total += float(r["gamma_active"])*(b-a)
        if float(r["tau_end"]) >= tau:
            break
    return total


def evaluate_cesaro(segments, tau_min, tau_max, points):
    # Use log-spacing for asymptotic resolution.
    lo = max(tau_min, 1e-6)
    taus = np.geomspace(lo, tau_max, points)

    rows = []
    for tau in taus:
        g, b = active_at_tau(segments, float(tau))
        integ = integral_gamma_to(segments, tau_min, float(tau))

        rows.append({
            "tau": float(tau),
            "gamma_active": g,
            "beta_active": b,
            # DS normalization as discussed in the proof attack.
            "cesaro_origin": float(integ/max(tau, 1e-300)),
            # Also report the literal mean over the sampled window.
            "cesaro_window": float(
                integ/max(tau-tau_min, 1e-300)
            ) if tau > tau_min else np.nan,
        })

    return pd.DataFrame(rows)


def loglog_growth_fit(x, y, tail_fraction=0.5):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    n = len(x)
    start = max(0, int((1.0-tail_fraction)*n))

    x = x[start:]
    y = y[start:]

    mask = (x > 0) & (y > 0) & np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]

    if len(x) < 3:
        return np.nan, np.nan

    X = np.log(x)
    Y = np.log(y)

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    p = float(coef[1])
    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return p, r2


# ---------------------------------------------------------------------------
# Candidate generators
# ---------------------------------------------------------------------------

def generate_boundary(args):
    gamma_max = args.gamma_max
    gamma = np.geomspace(args.gamma_min, gamma_max, args.gamma_points)
    beta = beta_boundary(gamma, args.vk_R, args.vk_margin)
    return make_candidates(
        gamma, beta, args.E_ref,
        args.include_dyadic_factor,
        "zero_free_boundary",
    )


def boundary_score_loggamma(logg, tau, args):
    g = math.exp(logg)
    b = beta_boundary(
        np.array([g]), args.vk_R, args.vk_margin
    )[0]
    if not np.isfinite(b):
        return -np.inf

    intercept = line_intercept(
        np.array([b]), np.array([g]),
        args.E_ref, args.include_dyadic_factor
    )[0]

    return (b-0.5)*tau + intercept


def generate_optimized(args):
    tau_anchors = np.geomspace(
        args.tau_min, args.tau_max, args.opt_tau_anchors
    )

    logs = []
    lg_min = math.log(args.gamma_min)
    lg_max = math.log(args.gamma_max)

    # Always include endpoints.
    logs.extend([lg_min, lg_max])

    for tau in tau_anchors:
        res = minimize_scalar(
            lambda x: -boundary_score_loggamma(x, tau, args),
            bounds=(lg_min, lg_max),
            method="bounded",
            options={"xatol": args.opt_loggamma_tol},
        )
        if res.success and np.isfinite(res.fun):
            logs.append(float(res.x))

    gamma = np.exp(np.asarray(logs, dtype=float))
    gamma = np.unique(np.round(gamma, 10))
    beta = beta_boundary(gamma, args.vk_R, args.vk_margin)

    return make_candidates(
        gamma, beta, args.E_ref,
        args.include_dyadic_factor,
        "optimized_sequence",
    )


def generate_random_trial(args, rng):
    lg = rng.uniform(
        math.log(args.gamma_min),
        math.log(args.gamma_max),
        size=args.random_points,
    )
    gamma = np.exp(lg)

    bmax = beta_boundary(gamma, args.vk_R, args.vk_margin)

    ok = np.isfinite(bmax)
    gamma = gamma[ok]
    bmax = bmax[ok]

    # Bias toward the dangerous right boundary while still exploring interior.
    # u=1 sits on the boundary; beta_bias>1 piles samples near 1.
    u = 1.0 - rng.random(len(gamma))**args.random_beta_bias
    beta = 0.5 + u*(bmax-0.5)

    # Explicitly include a sparse set of boundary points so each random trial
    # can discover a meaningful upper envelope.
    boundary_idx = rng.choice(
        len(gamma),
        size=min(args.random_boundary_points, len(gamma)),
        replace=False,
    )
    beta[boundary_idx] = bmax[boundary_idx]

    return make_candidates(
        gamma, beta, args.E_ref,
        args.include_dyadic_factor,
        "random_adversarial",
    )


# ---------------------------------------------------------------------------
# Analysis / verdict
# ---------------------------------------------------------------------------

def analyze_candidates(name, candidates, args):
    hull = build_upper_hull(candidates)
    seg = hull_segments(hull, args.tau_min, args.tau_max)

    if len(seg) == 0:
        raise RuntimeError(f"{name}: empty hull on requested tau interval.")

    ces = evaluate_cesaro(
        seg, args.tau_min, args.tau_max, args.tau_eval_points
    )

    p_ces, r2_ces = loglog_growth_fit(
        ces["tau"].to_numpy(),
        ces["cesaro_origin"].to_numpy(),
        tail_fraction=args.growth_fit_tail_fraction,
    )

    p_gamma, r2_gamma = loglog_growth_fit(
        ces["tau"].to_numpy(),
        ces["gamma_active"].to_numpy(),
        tail_fraction=args.growth_fit_tail_fraction,
    )

    gamma_initial = float(seg.iloc[0]["gamma_active"])
    gamma_terminal = float(seg.iloc[-1]["gamma_active"])

    cesaro_terminal = float(ces.iloc[-1]["cesaro_origin"])
    cesaro_mid = float(
        ces.iloc[max(0, len(ces)//2)]["cesaro_origin"]
    )

    switch_count = max(0, len(seg)-1)

    gamma_range_hit = bool(
        gamma_terminal >= args.gamma_edge_fraction*args.gamma_max
    )

    growth_failure = bool(
        np.isfinite(p_ces)
        and p_ces > args.cesaro_growth_exponent_gate
        and cesaro_terminal
            > args.cesaro_growth_factor_gate*max(cesaro_mid, 1e-300)
        and gamma_terminal
            > args.active_gamma_growth_factor_gate
              * max(gamma_initial, 1e-300)
    )

    if gamma_range_hit:
        verdict = "GAMMA_RANGE_SATURATED_INCREASE_MAX"
    elif growth_failure:
        verdict = "KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE"
    else:
        verdict = "NO_ADVERSARIAL_DS_FAILURE_FOUND"

    summary = {
        "model": name,
        "candidate_count": int(len(candidates)),
        "active_hull_segments": int(len(seg)),
        "switch_count": int(switch_count),
        "gamma_initial": gamma_initial,
        "gamma_terminal": gamma_terminal,
        "gamma_growth_factor": gamma_terminal/max(gamma_initial, 1e-300),
        "cesaro_terminal": cesaro_terminal,
        "cesaro_mid": cesaro_mid,
        "cesaro_growth_factor_mid_to_terminal": (
            cesaro_terminal/max(cesaro_mid, 1e-300)
        ),
        "cesaro_loglog_exponent": p_ces,
        "cesaro_loglog_R2": r2_ces,
        "active_gamma_loglog_exponent": p_gamma,
        "active_gamma_loglog_R2": r2_gamma,
        "gamma_range_hit": gamma_range_hit,
        "verdict": verdict,
    }

    return seg, ces, summary


def run_model(name, args, rng):
    if name == "zero_free_boundary":
        candidates = generate_boundary(args)
        seg, ces, summary = analyze_candidates(
            name, candidates, args
        )
        return candidates, seg, ces, summary

    if name == "optimized_sequence":
        candidates = generate_optimized(args)
        seg, ces, summary = analyze_candidates(
            name, candidates, args
        )
        return candidates, seg, ces, summary

    if name == "random_adversarial":
        best = None
        trial_summaries = []

        for trial in range(args.random_trials):
            cand = generate_random_trial(args, rng)
            seg, ces, summ = analyze_candidates(
                name, cand, args
            )
            summ["trial"] = trial
            trial_summaries.append(summ)

            # Prefer a non-saturated high terminal Cesaro mean.
            score = (
                -1e100 if summ["gamma_range_hit"]
                else summ["cesaro_terminal"]
            )

            if best is None or score > best[0]:
                best = (score, cand, seg, ces, summ)

        _, candidates, seg, ces, summary = best
        summary["trial_count"] = args.random_trials
        summary["best_trial"] = int(summary["trial"])
        summary["all_trials_known_constraints_allow_failure"] = int(
            sum(
                s["verdict"] == "KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE"
                for s in trial_summaries
            )
        )

        return candidates, seg, ces, summary

    raise ValueError(name)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--model",
        choices=[
            "all",
            "zero_free_boundary",
            "optimized_sequence",
            "random_adversarial",
        ],
        default="all",
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1.0e8)
    ap.add_argument("--tau-eval-points", type=int, default=320)

    ap.add_argument("--gamma-min", type=float, default=10.0)
    ap.add_argument(
        "--gamma-max",
        type=float,
        default=0.0,
        help=(
            "0 means auto=max(1e4,tau_max). This is synthetic and does not "
            "evaluate zeta at these heights."
        ),
    )
    ap.add_argument("--gamma-points", type=int, default=6000)

    ap.add_argument(
        "--vk-R",
        dest="vk_R",
        type=float,
        default=55.241,
        help=(
            "Denominator R in beta <= 1 - 1/[R log(g)^(2/3) "
            "loglog(g)^(1/3)]. Parameterized deliberately."
        ),
    )
    ap.add_argument("--vk-margin", type=float, default=1e-12)

    ap.add_argument(
        "--E-ref",
        dest="E_ref",
        type=float,
        default=20.0,
    )
    ap.add_argument(
        "--include-dyadic-factor",
        action="store_true",
        help="Include log|2^(rho-s)-1| in each line intercept.",
    )

    ap.add_argument("--opt-tau-anchors", type=int, default=160)
    ap.add_argument("--opt-loggamma-tol", type=float, default=1e-8)

    ap.add_argument("--random-trials", type=int, default=128)
    ap.add_argument("--random-points", type=int, default=512)
    ap.add_argument("--random-boundary-points", type=int, default=64)
    ap.add_argument(
        "--random-beta-bias",
        type=float,
        default=4.0,
        help="Higher values bias random beta samples toward the right boundary.",
    )
    ap.add_argument("--seed", type=int, default=20260819)

    ap.add_argument(
        "--growth-fit-tail-fraction",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--cesaro-growth-exponent-gate",
        type=float,
        default=0.05,
    )
    ap.add_argument(
        "--cesaro-growth-factor-gate",
        type=float,
        default=1.5,
    )
    ap.add_argument(
        "--active-gamma-growth-factor-gate",
        type=float,
        default=3.0,
    )
    ap.add_argument(
        "--gamma-edge-fraction",
        type=float,
        default=0.80,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_adversarial_dominance_switch_v169",
    )

    args = ap.parse_args()

    if args.tau_max <= args.tau_min:
        raise RuntimeError("--tau-max must exceed --tau-min.")
    if args.gamma_min <= math.e:
        raise RuntimeError("--gamma-min must exceed e so loglog(gamma)>0.")
    if args.vk_R <= 0:
        raise RuntimeError("--vk-R must be positive.")

    if args.gamma_max == 0.0:
        args.gamma_max = max(1.0e4, args.tau_max)

    if args.gamma_max <= args.gamma_min:
        raise RuntimeError("--gamma-max must exceed --gamma-min.")

    models = (
        [
            "zero_free_boundary",
            "optimized_sequence",
            "random_adversarial",
        ]
        if args.model == "all"
        else [args.model]
    )

    rng = np.random.default_rng(args.seed)

    print("=" * 158)
    print("ROT-RH v169 — ADVERSARIAL DOMINANCE-SWITCH / CESARO ACTIVE-ORDINATE AUDIT")
    print("=" * 158)
    print("Xi / zeta / known zeros          : NONE")
    print(f"models                            : {models}")
    print(f"tau window                        : [{args.tau_min:.6g}, {args.tau_max:.6g}]")
    print(f"gamma window                      : [{args.gamma_min:.6g}, {args.gamma_max:.6g}]")
    print(f"VK denominator R                  : {args.vk_R}")
    print(f"E reference                       : {args.E_ref}")
    print(f"dyadic factor included            : {args.include_dyadic_factor}")
    print("=" * 158)
    print("INTERPRETATION: synthetic failures test sufficiency of the selected generic constraints only.")
    print()

    summaries = {}

    for name in models:
        print(f"[{name}] generating adversarial candidates ...", flush=True)
        candidates, seg, ces, summ = run_model(name, args, rng)

        candidates.to_csv(
            f"{args.prefix}_{name}_CANDIDATES.csv",
            index=False,
        )
        seg.to_csv(
            f"{args.prefix}_{name}_HULL.csv",
            index=False,
        )
        ces.to_csv(
            f"{args.prefix}_{name}_CESARO.csv",
            index=False,
        )

        summaries[name] = summ

        print(
            f"  candidates={summ['candidate_count']:,}  "
            f"active segments={summ['active_hull_segments']:,}  "
            f"switches={summ['switch_count']:,}"
        )
        print(
            f"  gamma active: {summ['gamma_initial']:.6e} "
            f"-> {summ['gamma_terminal']:.6e}  "
            f"(x{summ['gamma_growth_factor']:.3e})"
        )
        print(
            f"  terminal Cesaro={summ['cesaro_terminal']:.6e}  "
            f"growth exponent={summ['cesaro_loglog_exponent']:.6f}  "
            f"R2={summ['cesaro_loglog_R2']:.6f}"
        )
        print(f"  VERDICT: {summ['verdict']}")
        print()

    # Overall verdict: a single valid synthetic failure is enough to show
    # that the chosen generic constraints alone do not imply DS.
    vals = [s["verdict"] for s in summaries.values()]

    if "KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE" in vals:
        overall = "KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE"
    elif "GAMMA_RANGE_SATURATED_INCREASE_MAX" in vals:
        overall = "GAMMA_RANGE_SATURATED_INCREASE_MAX"
    else:
        overall = "NO_ADVERSARIAL_DS_FAILURE_FOUND"

    summary = {
        "version": 169,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "warning": (
            "Synthetic candidate layers are not claimed to be actual zeta "
            "zeros. A failure only proves that the selected generic constraints "
            "are insufficient by themselves to force the DS condition."
        ),
        "parameters": {
            "tau_min": args.tau_min,
            "tau_max": args.tau_max,
            "gamma_min": args.gamma_min,
            "gamma_max": args.gamma_max,
            "vk_R": args.vk_R,
            "vk_margin": args.vk_margin,
            "E_ref": args.E_ref,
            "include_dyadic_factor": args.include_dyadic_factor,
            "seed": args.seed,
        },
        "models": summaries,
        "overall_verdict": overall,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print("=" * 158)
    print(f"OVERALL VERDICT: {overall}")
    print("=" * 158)

    if overall == "KNOWN_CONSTRAINTS_ALLOW_DS_FAILURE":
        print("MATHEMATICAL CONSEQUENCE:")
        print("  The selected zero-free envelope / strip constraints ALONE do not")
        print("  force a bounded or convergent Cesaro active ordinate in this")
        print("  dominance-score model.  Lemma 1 therefore needs an additional")
        print("  structural ingredient (zero correlations, root-flow geometry,")
        print("  coefficient cancellation, or a stronger analytic constraint).")
    elif overall == "GAMMA_RANGE_SATURATED_INCREASE_MAX":
        print("ACTION:")
        print("  Increase --gamma-max.  The current test hit the search boundary,")
        print("  so the asymptotic active-layer behavior has not been resolved.")
    else:
        print("ACTION:")
        print("  Inspect the exact active hull and optimizer.  Absence of a synthetic")
        print("  failure is not a proof; look for the inequality preventing growth.")


if __name__ == "__main__":
    main()
