#!/usr/bin/env python3
"""
ROT-RH v135 — LOW-MODE FINITE-PART NUMERICAL-STABILITY AUDIT

Purpose
-------
Test whether the low-mode 64k -> 128k trace-norm plateau seen in v132/v133
is large compared with the numerical/regulator sensitivity of the v102.1
finite-part phase calculation.

This is designed to be much cheaper than rebuilding 1408 roots:
  * load the already-computed L=64000 and L=128000 roots,
  * build ONE stricter phase at L=128000,
  * refine only the first --modes roots (default 32),
  * compare the stricter roots with the cached baseline roots.

No Xi, zeta, or known-zero data are used.

Important interpretation
------------------------
A small sensitivity ratio strongly suggests that the observed low-mode burst
is not caused by changing q/tail truncation at the tested level. It does NOT
exclude a systematic error shared by both numerical schemes. A large ratio
means the cutoff-removal conclusion is currently numerically contaminated and
the finite-part quadrature must be repaired before going to larger L.

Outputs
-------
<prefix>_MODES.csv
<prefix>_SUMMARY.json
<prefix>_HIGH_ROOTS.npz
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from scipy.optimize import brentq
except Exception:
    brentq = None


def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def scalar_call(fn, x):
    """Robust scalar wrapper for scalar- or vector-valued upstream APIs."""
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))
    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Upstream phase function returned empty output.")
    return float(a[0])


def refine_root(phase, x0, target, left, right, max_iter, tol, max_step):
    def g(x):
        return scalar_call(phase.F, x) - target

    def gp(x):
        return scalar_call(phase.Fprime, x)

    x = float(x0)
    left = float(left)
    right = float(right)

    # Safeguarded Newton first.
    for _ in range(max_iter):
        fx = g(x)
        if abs(fx) <= tol:
            return x, abs(fx), "newton"

        d = gp(x)
        if not np.isfinite(d) or abs(d) < 1e-14:
            break

        step = fx / d
        step = float(np.clip(step, -max_step, max_step))
        xn = x - step

        if not (left < xn < right) or not np.isfinite(xn):
            xn = 0.5 * (x + (left if fx > 0 else right))

        if abs(xn - x) <= 1e-15 * max(1.0, abs(x)):
            x = xn
            break
        x = xn

    fx = g(x)
    if abs(fx) <= max(10 * tol, 1e-11):
        return x, abs(fx), "newton_loose"

    # Local bracketing fallback.
    if brentq is not None:
        gl = g(left)
        gr = g(right)
        if np.isfinite(gl) and np.isfinite(gr) and gl * gr <= 0:
            xr = brentq(g, left, right, xtol=tol, rtol=1e-13, maxiter=100)
            return float(xr), abs(g(xr)), "brentq"

    return x, abs(fx), "failed"


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-prev", type=int, default=64000)
    ap.add_argument("--L-test", type=int, default=128000)
    ap.add_argument("--modes", type=int, default=32)

    # Baseline v132 used tail-factor=18, counter-q=8192.
    # Build one stricter stress configuration only.
    ap.add_argument("--high-tail-factor", type=float, default=24.0)
    ap.add_argument("--high-counter-q", type=int, default=16384)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--root-tol", type=float, default=2e-10)
    ap.add_argument(
        "--max-newton-step",
        type=float,
        default=0.10,
        help="Maximum Newton correction in E per iteration.",
    )
    ap.add_argument(
        "--stable-ratio-gate",
        type=float,
        default=0.05,
        help="High-resolution numerical sensitivity / actual cutoff motion.",
    )
    ap.add_argument(
        "--concern-ratio-gate",
        type=float,
        default=0.20,
    )
    ap.add_argument(
        "--focus-modes",
        default="9,10,13,14",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_low_mode_finite_part_stability_v135",
    )
    args = ap.parse_args()

    focus = [int(s.strip()) for s in args.focus_modes.split(",") if s.strip()]

    z = np.load(args.roots_npz)
    Ls = np.asarray(z["L"], dtype=int)
    roots = np.asarray(z["roots"], dtype=float)

    if args.L_prev not in Ls or args.L_test not in Ls:
        raise RuntimeError(
            f"Need both L={args.L_prev} and L={args.L_test} in {args.roots_npz}."
        )

    ip = int(np.where(Ls == args.L_prev)[0][0])
    it = int(np.where(Ls == args.L_test)[0][0])

    rprev_all = roots[ip]
    rbase_all = roots[it]
    n = min(args.modes, len(rbase_all))
    if n < 2:
        raise RuntimeError("Need at least 2 modes.")

    rprev = rprev_all[:n].copy()
    rbase = rbase_all[:n].copy()

    print("=" * 122)
    print("ROT-RH v135 — LOW-MODE FINITE-PART NUMERICAL-STABILITY AUDIT")
    print("=" * 122)
    print("Xi / zeta / known zeros          : NONE")
    print(f"baseline roots                    : {args.roots_npz}")
    print(f"actual cutoff interval            : {args.L_prev} -> {args.L_test}")
    print(f"modes refined                     : 1..{n}")
    print(f"strict phase at L                 : {args.L_test}")
    print(f"high tail factor                  : {args.high_tail_factor}")
    print(f"high counter q                    : {args.high_counter_q}")
    print("=" * 122)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print(f"[L={args.L_test}] building ONE stricter RenormalizedPhase ...", flush=True)
    phase = v102.RenormalizedPhase.build(
        base,
        int(args.L_test),
        float(args.high_tail_factor),
        int(args.high_counter_q),
    )
    print("[phase] built; refining low modes only ...", flush=True)

    rhigh = np.empty(n, dtype=float)
    residual = np.empty(n, dtype=float)
    methods = []

    # Brackets use neighboring cached L=128k roots, preserving mode identity.
    for j in range(n):
        x0 = float(rbase_all[j])

        if j == 0:
            gap_r = float(rbase_all[j + 1] - rbase_all[j])
            left = max(1e-8, x0 - 0.45 * gap_r)
        else:
            left = 0.5 * float(rbase_all[j - 1] + rbase_all[j])

        right = 0.5 * float(rbase_all[j] + rbase_all[j + 1])

        x, res, method = refine_root(
            phase=phase,
            x0=x0,
            target=(j + 1) - 0.5,
            left=left,
            right=right,
            max_iter=args.newton_iters,
            tol=args.root_tol,
            max_step=args.max_newton_step,
        )
        rhigh[j] = x
        residual[j] = res
        methods.append(method)

        if (j + 1) <= 16 or (j + 1) in focus:
            print(
                f"k={j+1:3d}  "
                f"E_base={x0:.12f}  E_high={x:.12f}  "
                f"dE={x-x0:+.3e}  res={res:.2e}  {method}"
            )

    if np.any(np.diff(rhigh) <= 0):
        raise RuntimeError("Refined high-resolution roots lost ordering.")

    lam_prev = 1.0 / rprev**2
    lam_base = 1.0 / rbase**2
    lam_high = 1.0 / rhigh**2

    actual = np.abs(lam_base - lam_prev)
    sensitivity = np.abs(lam_high - lam_base)
    corrected_actual = np.abs(lam_high - lam_prev)

    tiny = np.finfo(float).tiny
    ratio = sensitivity / np.maximum(actual, tiny)

    rows = []
    for j in range(n):
        rows.append(
            dict(
                k=j + 1,
                E_prev=float(rprev[j]),
                E_base_test=float(rbase[j]),
                E_high_test=float(rhigh[j]),
                root_shift_high_minus_base=float(rhigh[j] - rbase[j]),
                high_root_residual=float(residual[j]),
                refinement_method=methods[j],
                actual_cutoff_abs_delta_lambda=float(actual[j]),
                numerical_abs_delta_lambda=float(sensitivity[j]),
                sensitivity_over_actual=float(ratio[j]),
                corrected_cutoff_abs_delta_lambda=float(corrected_actual[j]),
                corrected_over_baseline_cutoff_motion=(
                    float(corrected_actual[j] / actual[j])
                    if actual[j] > 0 else np.nan
                ),
            )
        )

    write_csv(Path(args.prefix + "_MODES.csv"), rows)
    np.savez_compressed(
        args.prefix + "_HIGH_ROOTS.npz",
        L_test=np.array([args.L_test]),
        roots_high=rhigh,
        roots_baseline=rbase,
        residuals=residual,
    )

    def agg(m):
        m = min(m, n)
        A = float(np.sum(actual[:m]))
        S = float(np.sum(sensitivity[:m]))
        C = float(np.sum(corrected_actual[:m]))
        return dict(
            modes=m,
            baseline_cutoff_trace=A,
            numerical_sensitivity_trace=S,
            sensitivity_over_actual=(S / A if A > 0 else np.nan),
            corrected_cutoff_trace=C,
            corrected_over_baseline=(C / A if A > 0 else np.nan),
        )

    agg16 = agg(16)
    agg32 = agg(n)

    focus_rows = [rows[k - 1] for k in focus if 1 <= k <= n]
    focus_actual = float(sum(r["actual_cutoff_abs_delta_lambda"] for r in focus_rows))
    focus_sens = float(sum(r["numerical_abs_delta_lambda"] for r in focus_rows))
    focus_ratio = focus_sens / focus_actual if focus_actual > 0 else np.nan

    failed = [rows[i]["k"] for i, m in enumerate(methods) if m == "failed"]
    max_res = float(np.max(residual))

    # Classification.
    worst_aggregate = max(
        agg16["sensitivity_over_actual"],
        agg32["sensitivity_over_actual"],
        focus_ratio if np.isfinite(focus_ratio) else 0.0,
    )

    if failed or max_res > 1e-7:
        diagnosis = "REFINEMENT_FAILURE"
    elif worst_aggregate <= args.stable_ratio_gate:
        diagnosis = "NUMERICALLY_STABLE_AT_TESTED_RESOLUTION"
    elif worst_aggregate >= args.concern_ratio_gate:
        diagnosis = "NUMERICAL_OR_REGULATOR_SENSITIVITY_IS_MATERIAL"
    else:
        diagnosis = "INTERMEDIATE_SENSITIVITY"

    summary = dict(
        version=135,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        L_prev=args.L_prev,
        L_test=args.L_test,
        modes=n,
        high_tail_factor=args.high_tail_factor,
        high_counter_q=args.high_counter_q,
        max_high_root_residual=max_res,
        failed_modes=failed,
        first_16=agg16,
        all_tested=agg32,
        focus_modes=focus,
        focus_sensitivity_over_actual=focus_ratio,
        worst_aggregate_sensitivity_ratio=worst_aggregate,
        diagnosis=diagnosis,
        caveat=(
            "The high-resolution calculation uses the same upstream finite-part "
            "implementation, so stability does not rule out a systematic error shared "
            "by both resolutions. Instability, however, is direct evidence that the "
            "current cutoff-flow measurement is numerically/regulator contaminated."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print()
    print("=" * 122)
    print(f"max strict root residual          : {max_res:.3e}")
    print(f"failed refinements                : {failed}")
    print()
    print(
        f"modes 1..16 sensitivity / cutoff motion : "
        f"{agg16['sensitivity_over_actual']:.6e}"
    )
    print(
        f"modes 1..{n} sensitivity / cutoff motion : "
        f"{agg32['sensitivity_over_actual']:.6e}"
    )
    print(
        f"focus {focus} sensitivity / motion       : "
        f"{focus_ratio:.6e}"
    )
    print(
        f"corrected/baseline trace, modes 1..16    : "
        f"{agg16['corrected_over_baseline']:.9f}"
    )
    print(
        f"corrected/baseline trace, modes 1..{n}    : "
        f"{agg32['corrected_over_baseline']:.9f}"
    )
    print(f"DIAGNOSIS                         : {diagnosis}")
    print("=" * 122)


if __name__ == "__main__":
    main()
