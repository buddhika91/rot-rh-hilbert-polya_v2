#!/usr/bin/env python3
"""
ROT-RH v151 — ABEL/PNT REMAINDER BARRIER AUDIT

Purpose
-------
Sharpen v150 by expressing its weighted cutoff discrepancy through the
UNWEIGHTED prime-power counting remainder

    J(x) = sum_{p^a <= x} 1/a,
    Li_2(x) = int_2^x dt/log t,
    B(x) = J(x) - Li_2(x).

For a cutoff pair L<M define

    g_{L,M}(x)
      = x^(-1/2) [ exp(-x/M) - exp(-x/L) ].

Then the weighted discrepancy is exactly

    D_{L,M}(X)
      = sum_{p^a<=X} (1/a) g(p^a)
        - int_2^X g(x)/log(x) dx

and Abel/Stieltjes summation gives

    D_{L,M}(X)
      = g(X) B(X) - int_2^X B(x) g'(x) dx.          (1)

This script tests (1), then separates

    signed Abel term   = g(X)B(X) - int B g',
    absolute Abel bound= |g(X)B(X)| + int |B g'|.

The distinction matters:
  * If the absolute bound itself -> 0, a straightforward PNT-remainder
    estimate could prove cutoff independence.
  * If the signed expression is tiny only because of strong cancellation
    while the absolute bound does not shrink, the proof route needs
    additional oscillatory/arithmetic structure.

Scaling barrier
---------------
If heuristically

    |B(x)| <= C x^beta (log x)^q,

then for comparable cutoffs M/L=O(1), the weighted Abel expression scales
roughly like

    L^(beta-1/2) (log L)^q.

Thus beta < 1/2 is a clean absolute-decay regime; beta = 1/2 is critical
(up to logarithms).  v151 estimates effective beta from the computed B(x)
and reports how close the numerical mechanism is to this threshold.

NO Xi / zeta / known-zero data are used.

Outputs
-------
<prefix>_PAIRS.csv
<prefix>_B_ENVELOPE.csv.gz
<prefix>_WINDOW_FITS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.integrate import cumulative_trapezoid
except Exception as exc:
    raise RuntimeError("scipy is required for v151") from exc


def parse_pairs(s):
    out = []
    for item in s.split(","):
        if not item.strip():
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    primes = prime_sieve(nmax)

    ns = [primes.astype(np.int64)]
    ws = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        ns.append(np.asarray(extra_n, dtype=np.int64))
        ws.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(ns)
    w = np.concatenate(ws)
    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def gfun(x, L, M):
    x = np.asarray(x, dtype=float)
    return x**(-0.5) * (np.exp(-x/M) - np.exp(-x/L))


def gprime(x, L, M):
    """
    d/dx [ x^-1/2 (e^-x/M - e^-x/L) ]
    """
    x = np.asarray(x, dtype=float)
    a = np.exp(-x/M)
    b = np.exp(-x/L)
    return (
        -0.5 * x**(-1.5) * (a - b)
        + x**(-0.5) * (-a/M + b/L)
    )


def li2_grid(x):
    """
    Numerically construct Li_2(x)=int_2^x dt/log t on the supplied grid.
    """
    f = 1.0 / np.log(x)
    return np.concatenate([
        np.array([0.0]),
        cumulative_trapezoid(f, x)
    ])


def loglog_fit(x, y):
    mask = (x > 1.0) & (y > 0.0) & np.isfinite(y)
    if np.sum(mask) < 3:
        return np.nan, np.nan

    X = np.log(x[mask])
    Y = np.log(y[mask])

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A @ coef

    ss_res = np.sum((Y - pred)**2)
    ss_tot = np.sum((Y - np.mean(Y))**2)
    r2 = 1.0 - ss_res/ss_tot if ss_tot > 0 else np.nan

    return float(coef[1]), float(r2)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--x-grid-points",
        type=int,
        default=200001,
        help="Hybrid log-grid sample count for B(x) and Abel integrals.",
    )
    ap.add_argument(
        "--x-min-fit",
        type=float,
        default=1000.0,
    )
    ap.add_argument(
        "--window-count",
        type=int,
        default=8,
    )
    ap.add_argument(
        "--save-stride",
        type=int,
        default=128,
    )
    ap.add_argument(
        "--abel-identity-gate",
        type=float,
        default=5e-5,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_abel_pnt_barrier_v151",
    )

    args = ap.parse_args()

    pairs = parse_pairs(args.pairs)
    xmax = int(math.ceil(args.tail_factor * max(M for _, M in pairs)))

    print("=" * 136)
    print("ROT-RH v151 — ABEL/PNT REMAINDER BARRIER AUDIT")
    print("=" * 136)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"xmax                              : {xmax:,}")
    print(f"x-grid points                     : {args.x_grid_points}")
    print(f"fit begins                        : {args.x_min_fit}")
    print("=" * 136)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_w = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    cJ = np.cumsum(atom_w)

    print(f"[arithmetic] prime-power atoms     : {len(atom_n):,}")

    # Hybrid grid: dense enough near 2, logarithmic at large x.
    # geomspace includes all scales relevant to the kernel.
    x = np.geomspace(2.0, float(xmax), args.x_grid_points)
    x[0] = 2.0
    x[-1] = float(xmax)

    idx = np.searchsorted(atom_x, x, side="right") - 1
    J = np.zeros_like(x)
    good = idx >= 0
    J[good] = cJ[idx[good]]

    Li2 = li2_grid(x)
    B = J - Li2
    absB = np.abs(B)

    # Running envelope avoids fitting local zero crossings of B.
    Benv = np.maximum.accumulate(absB)

    # Global effective power exponent on the running envelope.
    fitmask = x >= args.x_min_fit
    beta_global, beta_r2 = loglog_fit(x[fitmask], Benv[fitmask])

    # Window fits in log x.
    lx_lo = math.log(max(args.x_min_fit, 2.0))
    lx_hi = math.log(xmax)
    edges = np.exp(np.linspace(lx_lo, lx_hi, args.window_count + 1))

    window_rows = []
    for i in range(args.window_count):
        lo, hi = edges[i], edges[i+1]
        mask = (x >= lo) & (x <= hi)
        beta, r2 = loglog_fit(x[mask], Benv[mask])

        # Also normalized critical envelopes.
        crit = Benv[mask] / np.sqrt(x[mask])
        crit_log = crit / np.maximum(np.log(x[mask]), 1.0)

        window_rows.append(dict(
            window=i+1,
            x_lo=float(lo),
            x_hi=float(hi),
            beta_envelope=beta,
            beta_r2=r2,
            max_B_over_sqrtx=float(np.max(crit)),
            median_B_over_sqrtx=float(np.median(crit)),
            max_B_over_sqrtx_logx=float(np.max(crit_log)),
        ))

    pd.DataFrame(window_rows).to_csv(
        args.prefix + "_WINDOW_FITS.csv",
        index=False,
    )

    pair_rows = []

    for L, M in pairs:
        g = gfun(x, L, M)
        gp = gprime(x, L, M)

        # Abel reconstruction:
        # D(X) = g(X)B(X) - int_2^X B g'
        signed_integrand = B * gp
        signed_int = float(np.trapezoid(signed_integrand, x))
        boundary = float(g[-1] * B[-1])
        D_abel = boundary - signed_int

        absolute_abel = (
            abs(boundary)
            + float(np.trapezoid(np.abs(signed_integrand), x))
        )

        # Direct weighted discrepancy from atoms and continuum.
        ga = gfun(atom_x, L, M)
        discrete = float(np.dot(atom_w, ga))
        continuum = float(np.trapezoid(g / np.log(x), x))
        D_direct = discrete - continuum

        identity_res = D_direct - D_abel

        # Signed-cancellation factor: absolute bound / achieved signed value.
        cancellation_factor = (
            absolute_abel / abs(D_direct)
            if abs(D_direct) > 0 else np.inf
        )

        # Kernel-weighted criticality diagnostics.
        # If |B| <= C sqrt(x), then the following C controls the Abel bound.
        C_half = float(np.max(absB / np.sqrt(x)))
        half_shape_bound = (
            C_half * (
                abs(g[-1]) * math.sqrt(x[-1])
                + float(np.trapezoid(np.sqrt(x) * np.abs(gp), x))
            )
        )

        # Same with the running envelope rather than a single global C.
        envelope_abs_bound = (
            abs(g[-1]) * Benv[-1]
            + float(np.trapezoid(Benv * np.abs(gp), x))
        )

        pair_rows.append(dict(
            L=L,
            M=M,
            ratio_L=float(M/L),

            D_direct=D_direct,
            D_abel=D_abel,
            abel_identity_residual=identity_res,
            abs_abel_identity_residual=abs(identity_res),

            boundary_term=boundary,
            signed_integral_term=-signed_int,
            absolute_abel_bound=absolute_abel,
            cancellation_factor=cancellation_factor,

            global_C_for_B_le_C_sqrtx=C_half,
            sqrtx_shape_bound=half_shape_bound,
            envelope_absolute_bound=envelope_abs_bound,
        ))

        print(
            f"[{L}->{M}] "
            f"Ddirect={D_direct:+.6e}  "
            f"Dabel={D_abel:+.6e}  "
            f"id={identity_res:.3e}  "
            f"abs-bound={absolute_abel:.6e}  "
            f"cancel={cancellation_factor:.2f}x"
        )

    # Ratios along cutoff sequence.
    for i, r in enumerate(pair_rows):
        for key in [
            "D_direct",
            "absolute_abel_bound",
            "sqrtx_shape_bound",
            "envelope_absolute_bound",
        ]:
            name = key + "_ratio"
            if i == 0:
                r[name] = np.nan
            else:
                a = abs(r[key])
                b = abs(pair_rows[i-1][key])
                r[name] = a/b if b > 0 else np.nan

    pd.DataFrame(pair_rows).to_csv(
        args.prefix + "_PAIRS.csv",
        index=False,
    )

    # Save a thinned B envelope.
    stride = max(1, args.save_stride)
    take = np.arange(0, len(x), stride, dtype=int)
    if take[-1] != len(x)-1:
        take = np.concatenate([take, [len(x)-1]])

    env_df = pd.DataFrame(dict(
        x=x[take],
        J=J[take],
        Li2=Li2[take],
        B=B[take],
        abs_B=absB[take],
        running_abs_B_envelope=Benv[take],
        Benv_over_sqrtx=Benv[take]/np.sqrt(x[take]),
        Benv_over_x=Benv[take]/x[take],
    ))
    env_df.to_csv(
        args.prefix + "_B_ENVELOPE.csv.gz",
        index=False,
        compression="gzip",
    )

    identity_ok = all(
        r["abs_abel_identity_residual"] <= args.abel_identity_gate
        for r in pair_rows
    )

    latest_abs_ratio = pair_rows[-1]["absolute_abel_bound_ratio"]
    latest_direct_ratio = abs(pair_rows[-1]["D_direct_ratio"])

    # Interpretation of beta.
    if np.isfinite(beta_global):
        if beta_global < 0.5:
            beta_status = "SUBCRITICAL_BETA_LT_HALF"
        elif beta_global < 0.6:
            beta_status = "NEAR_CRITICAL_BETA_APPROX_HALF"
        else:
            beta_status = "SUPERCRITICAL_BETA_GT_HALF"
    else:
        beta_status = "BETA_UNRESOLVED"

    if identity_ok and latest_abs_ratio < 1.0 and beta_global < 0.5:
        verdict = "ABSOLUTE_ABEL_PNT_ROUTE_PROMISING"
    elif identity_ok and latest_direct_ratio < 1.0:
        verdict = "SIGNED_CUTOFF_DISCREPANCY_DECAYS_BUT_ABSOLUTE_PNT_ROUTE_NOT_YET_PROVED"
    else:
        verdict = "ABEL_PNT_ROUTE_UNRESOLVED"

    summary = dict(
        version=151,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        identity=(
            "D_LM(X)=g_LM(X)B(X)-int_2^X B(x)g'_LM(x)dx"
        ),
        B_definition=(
            "B(x)=sum_{p^a<=x}1/a - int_2^x dt/log t"
        ),
        effective_B_envelope_fit=dict(
            beta_global=beta_global,
            r2=beta_r2,
            status=beta_status,
            critical_threshold=0.5,
        ),
        pair_results=pair_rows,
        identity_pass=identity_ok,
        verdict=verdict,
        analytic_warning=(
            "An absolute-value proof based only on a bound |B(x)|<=C x^beta "
            "naturally needs beta<1/2 for decay under the x^-1/2 regulator. "
            "If available unconditional PNT bounds are effectively beta>1/2, "
            "this route cannot by itself prove cutoff removal and one must exploit "
            "additional signed/oscillatory structure rather than absolute values."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print()
    print("B(x) running-envelope power fits")
    print("-" * 136)
    print(
        f"{'window':>7} {'x_lo':>13} {'x_hi':>13} "
        f"{'beta':>10} {'R2':>9} {'max B/sqrtx':>16}"
    )
    for r in window_rows:
        print(
            f"{r['window']:7d} "
            f"{r['x_lo']:13.3f} "
            f"{r['x_hi']:13.3f} "
            f"{r['beta_envelope']:10.6f} "
            f"{r['beta_r2']:9.5f} "
            f"{r['max_B_over_sqrtx']:16.6e}"
        )

    print()
    print("Pair Abel/PNT summaries")
    print("-" * 136)
    print(
        f"{'pair':>18} {'|D direct|':>13} {'abs Abel':>13} "
        f"{'cancel x':>10} {'abs ratio':>10} {'direct ratio':>12}"
    )
    for r in pair_rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{abs(r['D_direct']):13.6e} "
            f"{r['absolute_abel_bound']:13.6e} "
            f"{r['cancellation_factor']:10.3f} "
            f"{r['absolute_abel_bound_ratio']:10.6f} "
            f"{abs(r['D_direct_ratio']):12.6f}"
        )

    print()
    print("=" * 136)
    print(f"Abel identity pass                 : {identity_ok}")
    print(f"global effective beta              : {beta_global:.9f}")
    print(f"beta R^2                           : {beta_r2:.6f}")
    print(f"beta status                        : {beta_status}")
    print(f"latest absolute-Abel ratio         : {latest_abs_ratio:.9f}")
    print(f"latest signed-discrepancy ratio    : {latest_direct_ratio:.9f}")
    print(f"VERDICT                            : {verdict}")
    print("=" * 136)
    print("DECISION RULE:")
    print("  If the absolute Abel bound shrinks with a demonstrably sub-1/2 B(x)")
    print("  envelope, pursue a direct PNT-remainder proof.")
    print("  If only the signed discrepancy shrinks while the absolute bound does not,")
    print("  stop using absolute PNT bounds: the proof must retain oscillatory/signed")
    print("  cancellation in the cutoff-difference kernel.")


if __name__ == "__main__":
    main()
