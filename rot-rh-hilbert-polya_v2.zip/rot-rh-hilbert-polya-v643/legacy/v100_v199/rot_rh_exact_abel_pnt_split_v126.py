#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v126 — Exact Abel/PNT Split of the Mangoldt Staircase Kernel
====================================================================

PURPOSE
-------
v123 preregistered PASS established prime self-cancellation on fresh
k=1088..1407. v124/v125 showed that the small prime defect depends on robust,
specific cancellation across arithmetic scales.

v126 rewrites the exact prime defect in the arithmetic variable n and applies
DISCRETE ABEL SUMMATION exactly.

For one spectral cell k,

    q_k^prime = sum_{n>=2} Lambda(n) a_k(n),

where, for the finite-L exponential regulator,

    a_k(n)
      = [2 e^{-n/L}/(pi sqrt(n) (log n)^2)]
        sin(m_k log n)
        [delta cos(delta)-sin(delta)],

    m_k   = (E_k+E_{k+1})/2,
    delta = (E_{k+1}-E_k) log(n)/2.

For a spectral prefix containing r cells,

    A_r(n) = sum_{k=1}^r a_k(n),

    S_r = sum_n Lambda(n) A_r(n).

Let
    psi(x)=sum_{n<=x} Lambda(n)=x+E_PNT(x).

Discrete Abel summation is exactly

    S_r =
      psi(N) A_r(N)
      + sum_{n=2}^{N-1} psi(n)[A_r(n)-A_r(n+1)]

and therefore

    S_r = S_main + S_error,

where S_main uses psi(n)->n and S_error uses E_PNT(n)=psi(n)-n.

The script:
  * infers Lambda(n) from the frozen phase coefficients and validates the
    finite-L weight formula;
  * reconstructs the stored q_prime cell sequence;
  * constructs A_r(n) for selected spectral prefixes on EVERY integer
    n=2..Nmax (not only prime powers);
  * checks direct Mangoldt sum == Abel sum;
  * reports PNT-main and PNT-error contributions separately;
  * measures whether another large main/error cancellation is required.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v126"
BUILD = "2026-08-18-exact-abel-pnt-split-mangoldt-kernel-v126"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def exact_kernel_unweighted(mid, h, nvals, L):
    """
    Return a_k(n) with Lambda(n) factored OUT:

      q_{k,n} = Lambda(n) a_k(n).

    mid,h are shape (cells,), nvals shape (Nchunk,).
    Output shape (cells,Nchunk).
    """
    nvals = np.asarray(nvals, float)
    logn = np.log(nvals)
    delta = 0.5 * h[:, None] * logn[None, :]
    phase = mid[:, None] * logn[None, :]

    pref = (
        2.0
        * np.exp(-nvals / float(L))
        / (
            math.pi
            * np.sqrt(nvals)
            * logn * logn
        )
    )

    return (
        np.sin(phase)
        * (delta * np.cos(delta) - np.sin(delta))
        * pref[None, :]
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v123-prefix",
        default="rot_rh_blind_prime_self_cancellation_v123",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)
    ap.add_argument("--k-start", type=int, default=1088)
    ap.add_argument("--k-end", type=int, default=1407)
    ap.add_argument(
        "--spectral-prefixes",
        default="80,160,240,320",
    )
    ap.add_argument("--integer-chunk", type=int, default=4096)
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_abel_pnt_split_v126",
    )
    args = ap.parse_args()

    cells_path = Path(
        str(Path(args.v123_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    if not cells_path.exists():
        raise FileNotFoundError(cells_path)

    raw = read_csv(cells_path)
    rows = sorted(
        [
            r for r in raw
            if args.k_start <= int(float(r["k"])) <= args.k_end
        ],
        key=lambda r: int(float(r["k"])),
    )
    if len(rows) != args.k_end - args.k_start + 1:
        raise RuntimeError("Requested v123 cell range incomplete.")

    lo = np.asarray([float(r["lo"]) for r in rows], float)
    hi = np.asarray([float(r["hi"]) for r in rows], float)
    h = hi - lo
    mid = 0.5 * (lo + hi)
    qprime_ref = np.asarray([float(r["q_prime"]) for r in rows], float)

    prefixes = parse_ints(args.spectral_prefixes)
    if any(p <= 0 or p > len(rows) for p in prefixes):
        raise ValueError("Invalid spectral prefix.")
    prefixes = sorted(set(prefixes))

    print("=" * 164)
    print("ROT-RH v126 — EXACT ABEL/PNT SPLIT OF THE MANGOLDT STAIRCASE KERNEL")
    print("=" * 164)
    print("source                          :", cells_path)
    print("cells                           :", f"{args.k_start}..{args.k_end}")
    print("spectral prefixes               :", prefixes)
    print("L                               :", args.L)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 164)

    print("[1] Recover/validate Lambda(n) from finite-L phase coefficients", flush=True)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )

    w = np.asarray(phase.phase_w, float)
    logs = np.asarray(phase.logs, float)
    n_support = np.rint(np.exp(logs)).astype(int)

    if np.max(np.abs(np.log(n_support.astype(float)) - logs)) > 1e-10:
        raise RuntimeError("Could not recover integer n from phase.logs.")

    # Expected:
    # phase_w = Lambda(n)/(log n sqrt n) * exp(-n/L).
    lam = (
        w
        * logs
        * np.sqrt(n_support.astype(float))
        * np.exp(n_support.astype(float) / float(args.L))
    )

    # For n=p^m, Lambda(n)/log n = 1/m.
    inv_m = lam / logs
    m_est = np.maximum(
        1,
        np.rint(1.0 / np.maximum(inv_m, EPS)).astype(int),
    )
    reciprocal_resid = np.max(
        np.abs(inv_m - 1.0 / m_est)
    )

    # Reconstruct weights from inferred Lambda.
    w_recon = (
        lam
        / (
            logs
            * np.sqrt(n_support.astype(float))
        )
        * np.exp(-n_support.astype(float) / float(args.L))
    )
    weight_rel = float(
        np.linalg.norm(w_recon - w) / max(np.linalg.norm(w), EPS)
    )

    Nmax = int(np.max(n_support))
    lambda_integer = np.zeros(Nmax + 1, float)
    lambda_integer[n_support] = lam
    psi = np.cumsum(lambda_integer)

    print("  support terms                  :", len(n_support))
    print("  Nmax                           :", Nmax)
    print("  weight reconstruction relL2    :", f"{weight_rel:.12e}")
    print("  max Lambda/log reciprocal resid:", f"{reciprocal_resid:.12e}")
    print("  psi(Nmax)                      :", f"{psi[Nmax]:.12e}")
    print("  psi(Nmax)-Nmax                 :", f"{psi[Nmax]-Nmax:.12e}")

    if weight_rel > 1e-10 or reciprocal_resid > 1e-8:
        raise RuntimeError(
            "Finite-L phase weight convention did not validate; "
            "do not trust Abel/PNT split."
        )

    print("[2] Reconstruct q_prime cell sequence from inferred Lambda", flush=True)
    qrecon = np.zeros(len(rows), float)

    for s in range(0, len(n_support), int(args.integer_chunk)):
        e = min(len(n_support), s + int(args.integer_chunk))
        ns = n_support[s:e]
        K = exact_kernel_unweighted(
            mid, h, ns.astype(float), args.L
        )
        qrecon += K @ lam[s:e]

    recon_rel = float(
        np.linalg.norm(qrecon - qprime_ref)
        / max(np.linalg.norm(qprime_ref), EPS)
    )
    recon_max = float(np.max(np.abs(qrecon - qprime_ref)))

    print("  cell reconstruction relL2      :", f"{recon_rel:.12e}")
    print("  cell reconstruction max abs    :", f"{recon_max:.12e}")

    print("[3] Build A_r(n)=sum_{k<=r} a_k(n) on every integer n", flush=True)
    # Shape: number of requested spectral prefixes x (Nmax+1).
    A = np.zeros((len(prefixes), Nmax + 1), float)

    n0 = 2
    for s in range(n0, Nmax + 1, int(args.integer_chunk)):
        e = min(Nmax + 1, s + int(args.integer_chunk))
        ns = np.arange(s, e, dtype=float)

        K = exact_kernel_unweighted(mid, h, ns, args.L)
        CK = np.cumsum(K, axis=0)

        for pi, p in enumerate(prefixes):
            A[pi, s:e] = CK[p - 1, :]

        if e == Nmax + 1 or (e - n0) % (16 * int(args.integer_chunk)) == 0:
            print(f"  integers through n={e-1}/{Nmax}", flush=True)

    print("[4] Exact direct sum vs Abel sum; split psi=n+(psi-n)")
    out_rows = []

    nidx = np.arange(2, Nmax + 1, dtype=float)
    E_pnt = psi - np.arange(Nmax + 1, dtype=float)

    for pi, p in enumerate(prefixes):
        a = A[pi]

        # Direct exact Mangoldt sum.
        direct = float(np.dot(lambda_integer[2:], a[2:]))

        # Exact Abel sum:
        # psi(N)a(N) + sum_{n=2}^{N-1} psi(n)(a(n)-a(n+1))
        da = a[2:Nmax] - a[3:Nmax+1]
        abel = float(
            psi[Nmax] * a[Nmax]
            + np.dot(psi[2:Nmax], da)
        )

        # PNT main psi(n) -> n.
        main = float(
            Nmax * a[Nmax]
            + np.dot(
                np.arange(2, Nmax, dtype=float),
                da,
            )
        )

        # PNT remainder E(n)=psi(n)-n.
        err = float(
            E_pnt[Nmax] * a[Nmax]
            + np.dot(E_pnt[2:Nmax], da)
        )

        stored = float(np.sum(qprime_ref[:p]))
        recon_cells = float(np.sum(qrecon[:p]))

        denom = abs(main) + abs(err)
        main_error_cancel = abs(direct) / max(denom, EPS)

        row = {
            "spectral_prefix_cells": p,
            "k_end": args.k_start + p - 1,
            "stored_prime_prefix_sum": stored,
            "reconstructed_cell_prefix_sum": recon_cells,
            "direct_integer_mangoldt_sum": direct,
            "abel_sum": abel,
            "pnt_main_contribution": main,
            "pnt_error_contribution": err,
            "direct_minus_abel": direct - abel,
            "direct_minus_main_plus_error": direct - (main + err),
            "direct_over_abs_main_plus_abs_error": main_error_cancel,
            "abs_main_over_abs_direct": abs(main) / max(abs(direct), EPS),
            "abs_error_over_abs_direct": abs(err) / max(abs(direct), EPS),
        }
        out_rows.append(row)

        print(
            f"  r={p:<3d} k_end={row['k_end']}: "
            f"S={direct:+.6e} "
            f"main={main:+.6e} "
            f"Epsi={err:+.6e} "
            f"cancelRatio={main_error_cancel:.3e} "
            f"AbelErr={abs(direct-abel):.2e}"
        )

    print("[5] Arithmetic cutoff flow for the full spectral prefix", flush=True)
    # For the largest spectral prefix, inspect cumulative arithmetic build-up.
    a = A[-1]
    direct_terms = lambda_integer * a
    direct_cum = np.cumsum(direct_terms)

    # Main Abel contribution as a cumulative identity at each N:
    # M(N) = N a(N) + sum_{n=2}^{N-1} n(a(n)-a(n+1)).
    # This simplifies to 2a(2)+sum_{n=3}^N a(n), but compute directly by
    # cumulative form for numerical transparency.
    main_cum = np.zeros(Nmax + 1, float)
    err_cum = np.zeros(Nmax + 1, float)

    main_cum[2] = 2.0 * a[2]
    err_cum[2] = E_pnt[2] * a[2]

    # Recurrences derived from adding the next Abel point.
    # Main(N)=2a2+sum_{3..N}a(n).
    if Nmax >= 3:
        main_cum[3:] = (
            2.0 * a[2]
            + np.cumsum(a[3:])
        )
        err_cum[3:] = direct_cum[3:] - main_cum[3:]

    # Logarithmic checkpoints.
    cutoffs = []
    x = 2
    while x < Nmax:
        cutoffs.append(x)
        x = max(x + 1, int(round(x * 1.5)))
    if cutoffs[-1] != Nmax:
        cutoffs.append(Nmax)

    cutoff_rows = []
    for N in cutoffs:
        d = float(direct_cum[N])
        m = float(main_cum[N])
        er = float(err_cum[N])
        cr = abs(d) / max(abs(m) + abs(er), EPS)
        cutoff_rows.append({
            "N": N,
            "direct_cumulative": d,
            "pnt_main_cumulative": m,
            "pnt_error_cumulative": er,
            "main_error_cancellation_ratio": cr,
            "psi_minus_N": float(E_pnt[N]),
        })

    # Summarize arithmetic-scale maxima.
    max_direct = float(np.max(np.abs(direct_cum[2:])))
    max_main = float(np.max(np.abs(main_cum[2:])))
    max_err = float(np.max(np.abs(err_cum[2:])))
    final_direct = float(direct_cum[Nmax])
    final_main = float(main_cum[Nmax])
    final_err = float(err_cum[Nmax])

    print("  arithmetic cutoff max |direct| :", f"{max_direct:.12e}")
    print("  arithmetic cutoff max |main|   :", f"{max_main:.12e}")
    print("  arithmetic cutoff max |error|  :", f"{max_err:.12e}")
    print("  final direct                    :", f"{final_direct:+.12e}")
    print("  final PNT main                  :", f"{final_main:+.12e}")
    print("  final PNT error                 :", f"{final_err:+.12e}")
    print(
        "  final main/error cancellation  :",
        f"{abs(final_direct)/max(abs(final_main)+abs(final_err),EPS):.12e}"
    )

    # Conservative classification.
    final_ratio = abs(final_direct) / max(
        abs(final_main) + abs(final_err), EPS
    )
    main_small = abs(final_main) <= 3.0 * max(abs(final_direct), EPS)
    err_small = abs(final_err) <= 3.0 * max(abs(final_direct), EPS)

    if main_small and err_small:
        mechanism = (
            "PNT_MAIN_AND_PNT_ERROR_ARE_SEPARATELY_CONTROLLED_AT_THIS_SCALE"
        )
    elif final_ratio <= 0.10:
        mechanism = (
            "LARGE_PNT_MAIN_ERROR_CANCELLATION_REMAINS_ESSENTIAL"
        )
    elif abs(final_err) < abs(final_main):
        mechanism = (
            "OSCILLATORY_PNT_MAIN_DOMINATES__PNT_ERROR_IS_SECONDARY"
        )
    else:
        mechanism = (
            "PNT_ERROR_TERM_IS_COMPARABLE_OR_DOMINANT__THEOREM_DIFFICULTY_HIGH"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    write_csv(Path(str(prefix) + "_PREFIX_SPLIT.csv"), out_rows)
    write_csv(Path(str(prefix) + "_ARITHMETIC_CUTOFF_FLOW.csv"), cutoff_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V126_EXACT_ABEL_PNT_SPLIT_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "spectral_prefixes": prefixes,
        "Nmax": Nmax,
        "weight_reconstruction_rel_l2": weight_rel,
        "lambda_log_reciprocal_residual": reciprocal_resid,
        "cell_reconstruction_rel_l2": recon_rel,
        "cell_reconstruction_max_abs": recon_max,
        "prefix_rows": out_rows,
        "full_prefix_arithmetic_cutoff_max_direct": max_direct,
        "full_prefix_arithmetic_cutoff_max_main": max_main,
        "full_prefix_arithmetic_cutoff_max_error": max_err,
        "full_prefix_final_direct": final_direct,
        "full_prefix_final_pnt_main": final_main,
        "full_prefix_final_pnt_error": final_err,
        "full_prefix_main_error_cancellation_ratio": final_ratio,
        "interpretation": (
            "The Abel/PNT split is exact and zero-free. If the PNT main and "
            "psi(x)-x contributions are separately of the same small order as "
            "the final prime defect, a proof may proceed using an oscillatory "
            "integral estimate plus an available PNT remainder bound. If they "
            "are individually much larger and cancel, then another delicate "
            "arithmetic cancellation remains and naive separate bounds will "
            "again destroy the observed mechanism."
        ),
    }

    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 164)
    print("FINAL v126 VERDICT")
    print("=" * 164)
    print("verdict                         : PASS_V126_EXACT_ABEL_PNT_SPLIT_COMPLETE")
    print("mechanism                       :", mechanism)
    print("weight reconstruction relL2     :", f"{weight_rel:.12e}")
    print("cell reconstruction relL2       :", f"{recon_rel:.12e}")
    print("final direct                    :", f"{final_direct:+.12e}")
    print("final PNT main                  :", f"{final_main:+.12e}")
    print("final PNT error                 :", f"{final_err:+.12e}")
    print("main/error cancellation ratio   :", f"{final_ratio:.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 164)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
