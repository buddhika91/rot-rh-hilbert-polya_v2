#!/usr/bin/env python3
"""
ROT-RH v188 — EXACT ENVELOPE-BALANCE OFFSET / MULTICROSSING AUDIT

Uses v187 POINTS.csv only. No mpmath, no continuation.

Let
    L(x) = log(A2/A1),
    x = Delta a * (tau-tau_s),

where tau_s is the nominal dominance-hull switch.

Questions:
1. Is L(0) close to zero?
2. Where does the exact grouped envelope actually balance, L=0?
3. Is there one crossing or many?
4. Does lambda=dL/dtau change sign repeatedly?
5. How much of the apparent broad mixing width around x=0 is simply caused
   by a displacement between the nominal hull switch and the exact
   grouped-envelope balance point?

If there is one dominant zero crossing at x=x*, define centered coordinate
    x_c = x-x*.
Then compare the mixing-profile quantile widths in x_c with the local
slope-derived scale
    B = Delta a / |lambda(x*)|.

Outputs
-------
<prefix>_CROSSINGS.csv
<prefix>_POINTS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


LOGISTIC_X50_OVER_B = 0.881373587019543
LOGISTIC_X90_OVER_B = -np.log(2.0**0.1 - 1.0)


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def interp_zero(x1, y1, x2, y2):
    if y2 == y1:
        return 0.5*(x1+x2)
    return x1 - y1*(x2-x1)/(y2-y1)


def cumulative_centered_width(x, m, center, q, grid_n=8193):
    x = np.asarray(x, float)-float(center)
    m = np.asarray(m, float)

    ok = np.isfinite(x) & np.isfinite(m)
    x = x[ok]
    m = m[ok]

    if len(x) < 2:
        return np.nan, np.nan

    o = np.argsort(x)
    x = x[o]
    m = m[o]

    xmax = min(abs(float(x[0])), abs(float(x[-1])))
    if xmax <= 0:
        return np.nan, np.nan

    X = np.linspace(0.0, xmax, grid_n)
    f = np.interp(X, x, m) + np.interp(-X, x, m)

    K = np.zeros_like(X)
    dx = np.diff(X)
    K[1:] = np.cumsum(0.5*(f[1:]+f[:-1])*dx)

    if K[-1] <= 0:
        return np.nan, 0.0

    return float(np.interp(q*K[-1], K, X)), float(K[-1])


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--points-csv",
        default="rot_rh_grouped_envelope_slope_v187_POINTS.csv",
    )
    ap.add_argument("--switch-indices", default="159")
    ap.add_argument(
        "--near-balance-log-gate",
        type=float,
        default=1.0,
        help="Count points with |log(A2/A1)| below this.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_envelope_balance_offset_v188",
    )
    args = ap.parse_args()

    pts = pd.read_csv(args.points_csv)

    required = {
        "switch","tau","tau_switch","x",
        "log_A2_A1","lambda_group","B_group","m_env",
    }
    missing = required-set(pts.columns)
    if missing:
        raise RuntimeError(f"Missing columns: {sorted(missing)}")

    switches = [
        int(t.strip())
        for t in args.switch_indices.split(",")
        if t.strip()
    ]
    pts = pts[pts["switch"].astype(int).isin(switches)].copy()

    print("="*178)
    print("ROT-RH v188 — EXACT ENVELOPE-BALANCE OFFSET / MULTICROSSING AUDIT")
    print("="*178)
    print(f"switches                          : {switches}")
    print(f"points csv                        : {args.points_csv}")
    print("="*178)

    cross_rows = []
    out_rows = []
    summaries = []

    for sw, g0 in pts.groupby("switch"):
        g = g0.sort_values("x").reset_index(drop=True).copy()

        x = g["x"].to_numpy(float)
        L = g["log_A2_A1"].to_numpy(float)
        lam = g["lambda_group"].to_numpy(float)
        B = g["B_group"].to_numpy(float)
        m = g["m_env"].to_numpy(float)

        # L at nominal x=0.
        L0 = float(np.interp(0.0, x, L))
        lam0 = float(np.interp(0.0, x, lam))
        B0 = float(np.interp(0.0, x, B))

        # Zero crossings of exact grouped envelope ratio.
        crossings = []
        for i in range(len(g)-1):
            y1,y2 = L[i],L[i+1]
            if y1 == 0:
                crossings.append(float(x[i]))
            elif y1*y2 < 0:
                crossings.append(
                    float(interp_zero(x[i],y1,x[i+1],y2))
                )
        if L[-1] == 0:
            crossings.append(float(x[-1]))

        # de-duplicate very close crossings
        crossings_sorted = []
        for z in sorted(crossings):
            if not crossings_sorted or abs(z-crossings_sorted[-1]) > 1e-9:
                crossings_sorted.append(z)
        crossings = crossings_sorted

        # Sign changes of exact derivative.
        sign_changes_lambda = 0
        for i in range(len(lam)-1):
            if np.isfinite(lam[i]) and np.isfinite(lam[i+1]):
                if lam[i]*lam[i+1] < 0:
                    sign_changes_lambda += 1

        # Nearest exact balance crossing to nominal switch.
        if crossings:
            xstar = min(crossings, key=abs)
            lam_star = float(np.interp(xstar, x, lam))
            Bstar = float(np.interp(xstar, x, B))
        else:
            xstar = np.nan
            lam_star = np.nan
            Bstar = np.nan

        # First-order local prediction for balance offset from x=0:
        # dL/dx = lambda / Delta a, while B=Delta a/|lambda|.
        # Signed dx prediction = -L0 / (dL/dx).
        # Need sign(lambda); magnitude Delta a cancels through B.
        if np.isfinite(B0) and lam0 != 0:
            xstar_linear = -L0 * B0 * np.sign(lam0)
        else:
            xstar_linear = np.nan

        # Widths about nominal center and exact balance center.
        X50_nom,K_nom = cumulative_centered_width(x,m,0.0,0.50)
        X90_nom,_ = cumulative_centered_width(x,m,0.0,0.90)

        if np.isfinite(xstar):
            X50_bal,K_bal = cumulative_centered_width(x,m,xstar,0.50)
            X90_bal,_ = cumulative_centered_width(x,m,xstar,0.90)
        else:
            X50_bal=X90_bal=K_bal=np.nan

        B50_bal = (
            X50_bal/LOGISTIC_X50_OVER_B
            if np.isfinite(X50_bal) else np.nan
        )
        B90_bal = (
            X90_bal/LOGISTIC_X90_OVER_B
            if np.isfinite(X90_bal) else np.nan
        )

        # How much of sampled interval has near-balanced grouped envelope?
        near_frac = float(
            np.mean(np.abs(L) <= args.near_balance_log_gate)
        )

        # Does the nominal active label agree with exact envelope dominance?
        # Before nominal x=0 layer1 should dominate => L<0.
        # After nominal x=0 layer2 should dominate => L>0.
        expected_sign = np.where(x < 0, -1.0, +1.0)
        actual_sign = np.sign(L)
        mismatch = (
            (actual_sign != 0)
            & (actual_sign != expected_sign)
        )
        mismatch_frac = float(np.mean(mismatch))

        # Add centered point data.
        for i,row in g.iterrows():
            rr = dict(row)
            rr["x_balance_centered"] = (
                float(row["x"])-xstar if np.isfinite(xstar) else np.nan
            )
            rr["envelope_nominal_active_mismatch"] = bool(mismatch[i])
            out_rows.append(rr)

        for n,z in enumerate(crossings, start=1):
            cross_rows.append({
                "switch":int(sw),
                "crossing_number":n,
                "x_crossing":z,
                "tau_crossing":float(np.interp(z,x,g["tau"].to_numpy(float))),
                "lambda_at_crossing":float(np.interp(z,x,lam)),
                "B_at_crossing":float(np.interp(z,x,B)),
            })

        # Classification.
        single_crossing = len(crossings) == 1
        offset_large = bool(
            np.isfinite(xstar)
            and np.isfinite(Bstar)
            and Bstar > 0
            and abs(xstar)/Bstar >= 5
        )
        nonmonotone = sign_changes_lambda > 0

        if single_crossing and offset_large and not nonmonotone:
            mechanism = "NOMINAL_TO_EXACT_BALANCE_OFFSET"
        elif len(crossings) > 1 or nonmonotone:
            mechanism = "NONMONOTONE_OR_MULTICROSSING_ENVELOPE"
        elif single_crossing:
            mechanism = "SINGLE_CROSSING_LOCAL_WIDTH"
        else:
            mechanism = "NO_EXACT_BALANCE_CROSSING_IN_WINDOW"

        summaries.append({
            "switch":int(sw),
            "L_at_nominal_switch":L0,
            "lambda_at_nominal_switch":lam0,
            "B_at_nominal_switch":B0,
            "zero_crossing_count":len(crossings),
            "lambda_sign_change_count":sign_changes_lambda,
            "nearest_balance_x":xstar,
            "linear_predicted_balance_x":xstar_linear,
            "lambda_at_balance":lam_star,
            "B_at_balance":Bstar,
            "offset_over_B_balance":(
                abs(xstar)/Bstar
                if np.isfinite(xstar) and np.isfinite(Bstar) and Bstar>0
                else np.nan
            ),
            "X50_nominal":X50_nom,
            "X90_nominal":X90_nom,
            "X50_balance_centered":X50_bal,
            "X90_balance_centered":X90_bal,
            "B50_balance_centered":B50_bal,
            "B90_balance_centered":B90_bal,
            "near_balance_fraction":near_frac,
            "nominal_active_envelope_mismatch_fraction":mismatch_frac,
            "mechanism":mechanism,
        })

        print(
            f"[switch {int(sw):4d}] "
            f"L(0)={L0:.3e} "
            f"crossings={len(crossings)} "
            f"x*={xstar:.3e} "
            f"B*={Bstar:.3e} "
            f"|x*|/B*={abs(xstar)/Bstar if np.isfinite(xstar) and Bstar>0 else np.nan:.3e} "
            f"lambda sign changes={sign_changes_lambda} "
            f"mismatch={mismatch_frac:.3f} "
            f"mechanism={mechanism}"
        )

    out = pd.DataFrame(out_rows)
    crosses = pd.DataFrame(cross_rows)
    swdf = pd.DataFrame(summaries)

    out.to_csv(args.prefix+"_POINTS.csv",index=False)
    crosses.to_csv(args.prefix+"_CROSSINGS.csv",index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv",index=False)

    if len(swdf)==1:
        verdict = str(swdf.iloc[0]["mechanism"])
    else:
        uniq = sorted(swdf["mechanism"].unique().tolist())
        verdict = uniq[0] if len(uniq)==1 else "MIXED_ENVELOPE_GEOMETRY"

    summary = {
        "version":188,
        "switches":switches,
        "verdict":verdict,
    }
    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*178)
    for _,r in swdf.iterrows():
        print(f"switch {int(r['switch'])}")
        print(f"  L at nominal switch             : {r['L_at_nominal_switch']:.6e}")
        print(f"  exact balance crossings         : {int(r['zero_crossing_count'])}")
        print(f"  nearest balance x               : {r['nearest_balance_x']:.6e}")
        print(f"  linear-predicted balance x      : {r['linear_predicted_balance_x']:.6e}")
        print(f"  B at exact balance              : {r['B_at_balance']:.6e}")
        print(f"  |balance offset| / B            : {r['offset_over_B_balance']:.6e}")
        print(f"  lambda sign changes             : {int(r['lambda_sign_change_count'])}")
        print(f"  nominal-active mismatch fraction: {r['nominal_active_envelope_mismatch_fraction']:.6e}")
        print(f"  X90 nominal centered            : {r['X90_nominal']:.6e}")
        print(f"  X90 balance centered            : {r['X90_balance_centered']:.6e}")
        print(f"  mechanism                       : {r['mechanism']}")
    print(f"VERDICT                           : {verdict}")
    print("="*178)


if __name__ == "__main__":
    main()
