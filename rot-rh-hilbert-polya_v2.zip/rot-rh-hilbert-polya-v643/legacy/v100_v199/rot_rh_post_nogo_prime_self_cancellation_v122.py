#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v122 — Post-NOGO Prime Self-Cancellation / Global Defect Extension
=========================================================================

PURPOSE
-------
v121 preregistered NO-GO:
    the prime–Gamma phase lock seen post-hoc in v120 does NOT replicate on
    fresh cells k=768..1087.

At those depths the low-frequency prime amplitudes exceed Gamma amplitudes by
large factors, so Gamma can no longer be the asymptotic cancellation partner.

v122 uses ONLY already-written v119 and v121 component CSVs to ask:

  1. Does the TOTAL staircase boundary defect remain controlled through
     k=1087, or does it begin growing again?

  2. On the fresh v121 region, is q_total already essentially q_prime?

  3. Does the PRIME defect sequence itself show non-random low-frequency /
     cumulative cancellation versus permutations of the same q_prime values?

  4. How does Gamma's relative size change from the old region 48..767 to the
     fresh region 768..1087?

This is a post-hoc mechanism diagnostic after a preregistered NO-GO.
It must NOT be called a preregistered confirmation.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.
NO root/phase recomputation.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v122"
BUILD = "2026-08-18-post-nogo-prime-self-cancellation-global-defect-v122"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row, key):
    return float(row[key])


def i(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c) - np.min(c))


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def corr(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if np.std(a) <= EPS or np.std(b) <= EPS:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x*x)))


def permutation_single_sequence(x, nperm, rng, lowfreq_bins):
    """
    Test whether the actual ORDERING of one scalar sequence is special.
    Permuting x preserves its one-point distribution exactly.
    """
    x = np.asarray(x, float)
    real_c = cumulative_max(x)
    real_l = lowfreq_fraction(x, lowfreq_bins)

    pc = np.empty(int(nperm), float)
    pl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        y = rng.permutation(x)
        pc[t] = cumulative_max(y)
        pl[t] = lowfreq_fraction(y, lowfreq_bins)

    return {
        "real_cumulative_max": real_c,
        "real_lowfreq_fraction": real_l,
        "perm_cumulative_mean": float(np.mean(pc)),
        "perm_cumulative_p05": float(np.quantile(pc, 0.05)),
        "perm_cumulative_p50": float(np.quantile(pc, 0.50)),
        "perm_lowfreq_mean": float(np.mean(pl)),
        "cumulative_lower_tail_percentile": percentile_le(pc, real_c),
        "lowfreq_lower_tail_percentile": percentile_le(pl, real_l),
    }


def block_sum_rms(x, block):
    x = np.asarray(x, float)
    b = int(block)
    n = len(x) // b
    if n < 1:
        return float("nan")
    y = x[:n*b].reshape(n, b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))


def region_summary(name, ks, qt, qp, qa, qfp, lowfreq_bins):
    qt = np.asarray(qt, float)
    qp = np.asarray(qp, float)
    qa = np.asarray(qa, float)
    qfp = np.asarray(qfp, float)

    return {
        "region": name,
        "k_start": int(ks[0]),
        "k_end": int(ks[-1]),
        "cell_count": len(ks),
        "total_rms": rms(qt),
        "prime_rms": rms(qp),
        "arch_rms": rms(qa),
        "finite_part_rms": rms(qfp),
        "arch_over_prime_rms": rms(qa) / max(rms(qp), EPS),
        "finite_part_over_total_rms": rms(qfp) / max(rms(qt), EPS),
        "corr_total_prime": corr(qt, qp),
        "total_minus_prime_rel_l2":
            float(np.linalg.norm(qt - qp) / max(np.linalg.norm(qt), EPS)),
        "total_cumulative_max": cumulative_max(qt),
        "prime_cumulative_max": cumulative_max(qp),
        "arch_cumulative_max": cumulative_max(qa),
        "finite_part_cumulative_max": cumulative_max(qfp),
        "total_cumulative_range": cumulative_range(qt),
        "prime_cumulative_range": cumulative_range(qp),
        "total_lowfreq_fraction": lowfreq_fraction(qt, lowfreq_bins),
        "prime_lowfreq_fraction": lowfreq_fraction(qp, lowfreq_bins),
        "arch_lowfreq_fraction": lowfreq_fraction(qa, lowfreq_bins),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v119-prefix",
        default="rot_rh_adaptive_trapezoid_decomposition_v119",
    )
    ap.add_argument(
        "--v121-prefix",
        default="rot_rh_blind_prime_gamma_phase_lock_v121",
    )
    ap.add_argument("--old-start", type=int, default=48)
    ap.add_argument("--old-end", type=int, default=767)
    ap.add_argument("--fresh-start", type=int, default=768)
    ap.add_argument("--fresh-end", type=int, default=1087)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--lowfreq-bins", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260818)
    ap.add_argument(
        "--prefix",
        default="rot_rh_post_nogo_prime_self_cancellation_v122",
    )
    args = ap.parse_args()

    p119 = Path(args.v119_prefix).expanduser().resolve()
    p121 = Path(args.v121_prefix).expanduser().resolve()
    f119 = Path(str(p119) + "_CELLS.csv")
    f121 = Path(str(p121) + "_CELLS.csv")
    if not f119.exists():
        raise FileNotFoundError(f119)
    if not f121.exists():
        raise FileNotFoundError(f121)

    old_raw = read_csv(f119)
    fresh_raw = read_csv(f121)

    old = sorted(
        [
            r for r in old_raw
            if args.old_start <= i(r, "cell_k") <= args.old_end
        ],
        key=lambda r: i(r, "cell_k"),
    )
    fresh = sorted(
        [
            r for r in fresh_raw
            if args.fresh_start <= i(r, "cell_k") <= args.fresh_end
        ],
        key=lambda r: i(r, "cell_k"),
    )

    if len(old) != args.old_end - args.old_start + 1:
        raise RuntimeError("Old v119 range incomplete.")
    if len(fresh) != args.fresh_end - args.fresh_start + 1:
        raise RuntimeError("Fresh v121 range incomplete.")

    # Normalize schema.
    old_rows = []
    for r in old:
        old_rows.append({
            "k": i(r, "cell_k"),
            "q_total": f(r, "q_total"),
            "q_prime": f(r, "q_prime"),
            "q_arch": f(r, "q_arch"),
            "q_fp": f(r, "q_AC") + f(r, "q_counter_residual"),
        })

    fresh_rows = []
    for r in fresh:
        fresh_rows.append({
            "k": i(r, "cell_k"),
            "q_total": f(r, "q_total"),
            "q_prime": f(r, "q_prime"),
            "q_arch": f(r, "q_arch"),
            "q_fp": f(r, "q_finite_part_pair"),
        })

    all_rows = old_rows + fresh_rows

    def arr(rows, key):
        return np.asarray([r[key] for r in rows], float)

    def ksarr(rows):
        return np.asarray([r["k"] for r in rows], int)

    old_summary = region_summary(
        "old_48_767",
        ksarr(old_rows),
        arr(old_rows, "q_total"),
        arr(old_rows, "q_prime"),
        arr(old_rows, "q_arch"),
        arr(old_rows, "q_fp"),
        args.lowfreq_bins,
    )
    fresh_summary = region_summary(
        "fresh_768_1087",
        ksarr(fresh_rows),
        arr(fresh_rows, "q_total"),
        arr(fresh_rows, "q_prime"),
        arr(fresh_rows, "q_arch"),
        arr(fresh_rows, "q_fp"),
        args.lowfreq_bins,
    )
    full_summary = region_summary(
        "full_48_1087",
        ksarr(all_rows),
        arr(all_rows, "q_total"),
        arr(all_rows, "q_prime"),
        arr(all_rows, "q_arch"),
        arr(all_rows, "q_fp"),
        args.lowfreq_bins,
    )

    print("=" * 158)
    print("ROT-RH v122 — POST-NOGO PRIME SELF-CANCELLATION / GLOBAL DEFECT EXTENSION")
    print("=" * 158)
    print("v119 source                     :", f119)
    print("v121 source                     :", f121)
    print("old region                      :", f"{args.old_start}..{args.old_end}")
    print("fresh region                    :", f"{args.fresh_start}..{args.fresh_end}")
    print("combined region                 :", f"{args.old_start}..{args.fresh_end}")
    print("permutations                    :", args.permutations)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 158)

    print("[1] Mechanism migration old -> fresh")
    for s in [old_summary, fresh_summary]:
        print(
            f"  {s['region']}: "
            f"arch/prime RMS={s['arch_over_prime_rms']:.3e} "
            f"corr(total,prime)={s['corr_total_prime']:+.6f} "
            f"||total-prime||/||total||={s['total_minus_prime_rel_l2']:.3e} "
            f"cumMax total={s['total_cumulative_max']:.3e} "
            f"prime={s['prime_cumulative_max']:.3e}"
        )

    arch_drop = (
        old_summary["arch_over_prime_rms"]
        / max(fresh_summary["arch_over_prime_rms"], EPS)
    )
    print("  Gamma relative-size drop       :", f"{arch_drop:.6f}x")

    print("[2] Fresh-region prime-ordering red-team")
    rng = np.random.default_rng(args.seed)
    fresh_prime = arr(fresh_rows, "q_prime")
    fresh_total = arr(fresh_rows, "q_total")

    pm = permutation_single_sequence(
        fresh_prime, args.permutations, rng, args.lowfreq_bins
    )
    tm = permutation_single_sequence(
        fresh_total, args.permutations, rng, args.lowfreq_bins
    )

    print("  PRIME actual cumMax             :", f"{pm['real_cumulative_max']:.12e}")
    print("  PRIME permutation mean          :", f"{pm['perm_cumulative_mean']:.12e}")
    print("  PRIME cumulative percentile     :", f"{100*pm['cumulative_lower_tail_percentile']:.6f}%")
    print("  PRIME lowF percentile           :", f"{100*pm['lowfreq_lower_tail_percentile']:.6f}%")
    print("  TOTAL cumulative percentile     :", f"{100*tm['cumulative_lower_tail_percentile']:.6f}%")
    print("  TOTAL lowF percentile           :", f"{100*tm['lowfreq_lower_tail_percentile']:.6f}%")

    print("[3] Fresh multi-scale block-sum suppression")
    block_rows = []
    for b in [1, 2, 4, 8, 16, 32, 64, 80, 160]:
        if b > len(fresh_prime):
            continue
        realp = block_sum_rms(fresh_prime, b)
        realt = block_sum_rms(fresh_total, b)

        ctrlp = np.empty(args.permutations, float)
        ctrlt = np.empty(args.permutations, float)
        for t in range(args.permutations):
            ctrlp[t] = block_sum_rms(
                rng.permutation(fresh_prime), b
            )
            ctrlt[t] = block_sum_rms(
                rng.permutation(fresh_total), b
            )

        row = {
            "block_size": b,
            "prime_real_rms": realp,
            "prime_perm_mean": float(np.mean(ctrlp)),
            "prime_lower_percentile": percentile_le(ctrlp, realp),
            "prime_suppression_ratio":
                realp / max(float(np.mean(ctrlp)), EPS),
            "total_real_rms": realt,
            "total_perm_mean": float(np.mean(ctrlt)),
            "total_lower_percentile": percentile_le(ctrlt, realt),
            "total_suppression_ratio":
                realt / max(float(np.mean(ctrlt)), EPS),
        }
        block_rows.append(row)
        print(
            f"  block={b:<3d}: "
            f"prime ratio={row['prime_suppression_ratio']:.3f} "
            f"p={100*row['prime_lower_percentile']:.3f}% | "
            f"total ratio={row['total_suppression_ratio']:.3f} "
            f"p={100*row['total_lower_percentile']:.3f}%"
        )

    print("[4] Global boundary-defect extension through k=1087")
    qt_full = arr(all_rows, "q_total")
    qp_full = arr(all_rows, "q_prime")
    ctot = np.cumsum(qt_full)
    cprime = np.cumsum(qp_full)

    prefix_rows = []
    for n in list(range(80, len(qt_full) + 1, 80)):
        cm_t = cumulative_max(qt_full[:n])
        cm_p = cumulative_max(qp_full[:n])
        prefix_rows.append({
            "prefix_cells": n,
            "k_end": args.old_start + n - 1,
            "total_cumulative_max": cm_t,
            "prime_cumulative_max": cm_p,
        })
        print(
            f"  n={n:<4d} k_end={args.old_start+n-1}: "
            f"totalCumMax={cm_t:.6e} "
            f"primeCumMax={cm_p:.6e}"
        )

    # Include exact final 1040-cell endpoint if 1040 is not a multiple of 80.
    if prefix_rows[-1]["prefix_cells"] != len(qt_full):
        n = len(qt_full)
        cm_t = cumulative_max(qt_full)
        cm_p = cumulative_max(qp_full)
        prefix_rows.append({
            "prefix_cells": n,
            "k_end": args.fresh_end,
            "total_cumulative_max": cm_t,
            "prime_cumulative_max": cm_p,
        })
        print(
            f"  n={n:<4d} k_end={args.fresh_end}: "
            f"totalCumMax={cm_t:.6e} "
            f"primeCumMax={cm_p:.6e}"
        )

    old_plateau = old_summary["total_cumulative_max"]
    full_cmax = full_summary["total_cumulative_max"]
    growth_factor = full_cmax / max(old_plateau, EPS)

    # Mechanism classification.
    prime_dominant_fresh = (
        fresh_summary["arch_over_prime_rms"] < 0.10
        and fresh_summary["corr_total_prime"] > 0.99
        and fresh_summary["total_minus_prime_rel_l2"] < 0.15
    )
    prime_ordering_special = (
        pm["cumulative_lower_tail_percentile"] <= 0.05
        and pm["lowfreq_lower_tail_percentile"] <= 0.05
    )
    global_defect_still_Osame = growth_factor <= 3.0

    if prime_dominant_fresh and prime_ordering_special and global_defect_still_Osame:
        mechanism = (
            "PRIME_SELF_CANCELLATION_REPLACES_FINITE_DEPTH_PRIME_GAMMA_LOCK"
        )
    elif prime_dominant_fresh and global_defect_still_Osame:
        mechanism = (
            "PRIME_DOMINATES_FRESH_TOTAL_BUT_SELF_CANCELLATION_NOT_STATISTICALLY_SPECIAL"
        )
    elif not global_defect_still_Osame:
        mechanism = (
            "GLOBAL_STAIRCASE_DEFECT_GROWS_AFTER_V121__BOUNDED_PRIMITIVE_HYPOTHESIS_WEAKENED"
        )
    else:
        mechanism = "POST_NOGO_MECHANISM_UNRESOLVED"

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(
        Path(str(prefix) + "_REGIONS.csv"),
        [old_summary, fresh_summary, full_summary],
    )
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)
    write_csv(Path(str(prefix) + "_PREFIX.csv"), prefix_rows)

    merged_rows = []
    rt = 0.0
    rp = 0.0
    for r in all_rows:
        rt += r["q_total"]
        rp += r["q_prime"]
        merged_rows.append({
            **r,
            "cum_total_from_k48": rt,
            "cum_prime_from_k48": rp,
        })
    write_csv(Path(str(prefix) + "_MERGED_CELLS.csv"), merged_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V122_POST_NOGO_DIAGNOSTIC_COMPLETE",
        "mechanism": mechanism,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "old_summary": old_summary,
        "fresh_summary": fresh_summary,
        "full_summary": full_summary,
        "gamma_relative_size_drop_factor": arch_drop,
        "fresh_prime_permutation_metrics": pm,
        "fresh_total_permutation_metrics": tm,
        "global_total_cumulative_growth_factor_vs_k767": growth_factor,
        "interpretation": (
            "v121 falsified persistent prime-Gamma locking. If the fresh total "
            "is already prime-dominated and the prime sequence itself has "
            "unusually suppressed cumulative/low-frequency power, the next "
            "candidate mechanism is internal prime self-cancellation on the "
            "adaptive total-phase mesh. If the global total defect begins "
            "growing substantially, the earlier bounded-primitive hypothesis "
            "must be weakened rather than rescued by a new mechanism."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("FINAL v122 VERDICT")
    print("=" * 158)
    print("verdict                         : PASS_V122_POST_NOGO_DIAGNOSTIC_COMPLETE")
    print("mechanism                       :", mechanism)
    print("fresh arch/prime RMS            :", f"{fresh_summary['arch_over_prime_rms']:.12e}")
    print("fresh corr(total,prime)         :", f"{fresh_summary['corr_total_prime']:.12e}")
    print("fresh prime cumulative pct      :", f"{100*pm['cumulative_lower_tail_percentile']:.6f}%")
    print("fresh prime lowF pct            :", f"{100*pm['lowfreq_lower_tail_percentile']:.6f}%")
    print("full total cumulative max       :", f"{full_cmax:.12e}")
    print("growth factor vs k<=767         :", f"{growth_factor:.12e}")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 158)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
