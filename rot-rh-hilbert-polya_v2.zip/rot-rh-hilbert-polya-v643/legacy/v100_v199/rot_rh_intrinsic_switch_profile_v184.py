#!/usr/bin/env python3
"""
ROT-RH v184 — INTRINSIC SWITCH-PROFILE / MIXING-TAIL AUDIT

Purpose
-------
v183 falsified the naive global scaling
    I_mix = O(Delta gamma / Delta a)
because switch 159 had
    K = I_mix * Delta a / Delta gamma ~ 78,
while switches 114/136 had K ~ 0.3.

But v183 integrated different finite audit windows.  The correct intrinsic
switch coordinate is

    x = Delta a * (tau - tau_switch).

Since
    d tau = d x / Delta a,

we have exactly

    K(X)
      := (Delta a / Delta gamma)
         * int_{|x|<=X} |epsilon_mix| d tau
       = int_{|x|<=X}
           |epsilon_mix|/Delta gamma dx.

Thus K(X) is a dimensionless cumulative profile area.

This script uses the already root-reprojected v183 POINTS.csv.
It performs NO continuation and NO high-precision phase evaluation.

Questions answered
------------------
1. Does K(X) saturate by X=O(1..10)?
   -> supports a localized two-layer switch.

2. Does K(X) keep growing roughly linearly with X?
   -> the mixing error has a persistent tail and the naive O(1/Delta a)
      switch-width estimate is false.

3. Does the far-tail pointwise ratio
       |epsilon_mix|/Delta gamma
   decay with |x|?
   -> fit a power law on the available far-tail samples.

Outputs
-------
<prefix>_PROFILES.csv
<prefix>_SWITCHES.csv
<prefix>_TAIL_FITS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return 0.0
    order = np.argsort(x)
    return float(np.trapezoid(y[order], x[order]))


def cumulative_area(g, X):
    """Interpolate boundaries at +/-X, then integrate m(x)."""
    g = g.sort_values("x")
    x = g["x"].to_numpy(float)
    m = g["m_abs"].to_numpy(float)

    lo = max(float(np.min(x)), -float(X))
    hi = min(float(np.max(x)), +float(X))

    if hi <= lo:
        return np.nan, 0.0

    mask = (x >= lo) & (x <= hi)
    xx = x[mask]
    mm = m[mask]

    # Add exact clipped endpoints by linear interpolation.
    add_x = []
    add_m = []

    if len(xx) == 0 or xx[0] > lo:
        add_x.append(lo)
        add_m.append(float(np.interp(lo, x, m)))
    if len(xx) == 0 or xx[-1] < hi:
        add_x.append(hi)
        add_m.append(float(np.interp(hi, x, m)))

    if add_x:
        xx = np.concatenate([xx, np.asarray(add_x)])
        mm = np.concatenate([mm, np.asarray(add_m)])
        order = np.argsort(xx)
        xx = xx[order]
        mm = mm[order]

    return trapz(xx, mm), hi-lo


def loglog_fit(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)

    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]

    if len(x) < 4:
        return {"n": len(x), "slope": np.nan, "r2": np.nan}

    X = np.log(x)
    Y = np.log(y)

    p = np.polyfit(X, Y, 1)
    pred = p[0]*X+p[1]

    ssr = float(np.sum((Y-pred)**2))
    sst = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0-ssr/sst if sst > 0 else np.nan

    return {
        "n": len(x),
        "slope": float(p[0]),
        "r2": float(r2),
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--points-csv",
        default="rot_rh_global_cesaro_mix_scale_v183_POINTS.csv",
    )
    ap.add_argument(
        "--x-cuts",
        default="0.5,1,2,4,8,16,32,64,128",
    )
    ap.add_argument(
        "--tail-x-min",
        type=float,
        default=8.0,
    )
    ap.add_argument(
        "--boundary-decay-gate",
        type=float,
        default=0.05,
        help="Late-boundary m=|eps_mix|/Delta gamma below this is considered small.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_intrinsic_switch_profile_v184",
    )

    args = ap.parse_args()

    pts = pd.read_csv(args.points_csv)

    required = {
        "switch", "tau", "tau_switch",
        "beta_left", "beta_right",
        "gamma_left", "gamma_right",
        "epsilon_mix",
    }
    if not required.issubset(pts.columns):
        raise RuntimeError(
            "POINTS csv missing columns: "
            + str(sorted(required-set(pts.columns)))
        )

    cuts = sorted(
        float(x.strip())
        for x in args.x_cuts.split(",")
        if x.strip()
    )

    profile_rows = []
    switch_rows = []
    tail_rows = []

    print("="*166)
    print("ROT-RH v184 — INTRINSIC SWITCH-PROFILE / MIXING-TAIL AUDIT")
    print("="*166)
    print(f"points csv                        : {args.points_csv}")
    print(f"switches                          : {sorted(pts['switch'].astype(int).unique().tolist())}")
    print(f"x cuts                            : {cuts}")
    print(f"tail fit |x| >=                   : {args.tail_x_min}")
    print("="*166)

    for sw, g0 in pts.groupby("switch"):
        g = g0.copy().sort_values("tau")

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        g1 = float(g.iloc[0]["gamma_left"])
        g2 = float(g.iloc[0]["gamma_right"])
        ts = float(g.iloc[0]["tau_switch"])

        da = abs(b2-b1)
        dg = abs(g2-g1)

        if da <= 0 or dg <= 0:
            continue

        g["x"] = da*(g["tau"].to_numpy(float)-ts)
        g["m_abs"] = np.abs(g["epsilon_mix"].to_numpy(float))/dg
        g["m_signed"] = g["epsilon_mix"].to_numpy(float)/dg

        xmin = float(g["x"].min())
        xmax = float(g["x"].max())
        xabsmax = max(abs(xmin), abs(xmax))

        # Full available dimensionless area.
        K_full = trapz(g["x"], g["m_abs"])

        # Boundary magnitudes.
        left_row = g.iloc[0]
        right_row = g.iloc[-1]
        m_left = float(left_row["m_abs"])
        m_right = float(right_row["m_abs"])
        m_boundary = max(m_left, m_right)

        cut_areas = {}
        prev_area = np.nan

        for X in cuts:
            area, covered_width = cumulative_area(g, X)
            cut_areas[X] = area

            profile_rows.append({
                "switch": int(sw),
                "X": X,
                "K_X": area,
                "covered_x_width": covered_width,
                "K_X_over_K_full": (
                    area/K_full if K_full > 0 and np.isfinite(area)
                    else np.nan
                ),
                "delta_a": da,
                "delta_gamma": dg,
                "tau_switch": ts,
                "x_min": xmin,
                "x_max": xmax,
            })

            prev_area = area

        # Growth over common X=4 -> 8 if available.
        K4 = cut_areas.get(4.0, np.nan)
        K8 = cut_areas.get(8.0, np.nan)
        K16 = cut_areas.get(16.0, np.nan)

        growth_4_8 = (
            K8/K4 if np.isfinite(K4) and K4 > 0 and np.isfinite(K8)
            else np.nan
        )
        growth_8_16 = (
            K16/K8 if np.isfinite(K8) and K8 > 0 and np.isfinite(K16)
            else np.nan
        )

        # Far-tail pointwise decay fit m ~ |x|^p.
        absx = np.abs(g["x"].to_numpy(float))
        m = g["m_abs"].to_numpy(float)
        tail_mask = absx >= args.tail_x_min

        fit = loglog_fit(absx[tail_mask], m[tail_mask])

        tail_rows.append({
            "switch": int(sw),
            "tail_x_min": args.tail_x_min,
            "n": fit["n"],
            "slope": fit["slope"],
            "r2": fit["r2"],
        })

        switch_rows.append({
            "switch": int(sw),
            "tau_switch": ts,
            "delta_a": da,
            "delta_gamma": dg,
            "x_min": xmin,
            "x_max": xmax,
            "x_abs_max": xabsmax,
            "K_full": K_full,
            "K_4": K4,
            "K_8": K8,
            "K_16": K16,
            "growth_K4_to_K8": growth_4_8,
            "growth_K8_to_K16": growth_8_16,
            "m_left_boundary": m_left,
            "m_right_boundary": m_right,
            "m_max_boundary": m_boundary,
            "tail_slope": fit["slope"],
            "tail_r2": fit["r2"],
        })

        print(
            f"[switch {int(sw):4d}] "
            f"x=[{xmin:.2f},{xmax:.2f}] "
            f"Kfull={K_full:.3e} "
            f"K4={K4:.3e} K8={K8:.3e} K16={K16:.3e} "
            f"boundary m={m_boundary:.3e} "
            f"tail p={fit['slope']:.3f} R2={fit['r2']:.3f}"
        )

    prof = pd.DataFrame(profile_rows)
    swdf = pd.DataFrame(switch_rows)
    tails = pd.DataFrame(tail_rows)

    prof.to_csv(args.prefix+"_PROFILES.csv", index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv", index=False)
    tails.to_csv(args.prefix+"_TAIL_FITS.csv", index=False)

    # Cross-switch comparison at common intrinsic cut X=8.
    common = prof[np.isclose(prof["X"], 8.0)].copy()
    common = common[np.isfinite(common["K_X"])]

    if len(common) >= 3:
        K8_min = float(common["K_X"].min())
        K8_max = float(common["K_X"].max())
        K8_spread = K8_max/max(K8_min, 1e-300)
    else:
        K8_min = K8_max = K8_spread = np.nan

    # Diagnose late switch specifically.
    late = swdf.sort_values("tau_switch").iloc[-1]
    late_boundary_small = bool(
        late["m_max_boundary"] <= args.boundary_decay_gate
    )

    late_K8 = float(late["K_8"]) if np.isfinite(late["K_8"]) else np.nan
    late_K16 = float(late["K_16"]) if np.isfinite(late["K_16"]) else np.nan

    if (
        np.isfinite(late_K8)
        and np.isfinite(late_K16)
        and late_K8 > 0
    ):
        late_growth = late_K16/late_K8
    else:
        late_growth = np.nan

    # If K doubles when X doubles and boundary amplitude remains non-small,
    # that's persistent-tail evidence.
    persistent_tail = bool(
        np.isfinite(late_growth)
        and late_growth >= 1.5
        and not late_boundary_small
    )

    localized_tail = bool(
        np.isfinite(late_growth)
        and late_growth <= 1.2
        and late_boundary_small
    )

    if persistent_tail:
        verdict = "INTRINSIC_MIXING_TAIL_PERSISTS"
    elif localized_tail:
        verdict = "INTRINSIC_MIXING_PROFILE_LOCALIZED"
    else:
        verdict = "INTRINSIC_MIXING_PROFILE_UNRESOLVED"

    summary = {
        "version": 184,
        "switches": swdf["switch"].astype(int).tolist(),
        "common_X8_K_min": K8_min,
        "common_X8_K_max": K8_max,
        "common_X8_spread": K8_spread,
        "late_switch": int(late["switch"]),
        "late_boundary_m": float(late["m_max_boundary"]),
        "late_boundary_small": late_boundary_small,
        "late_K8": late_K8,
        "late_K16": late_K16,
        "late_K16_over_K8": late_growth,
        "persistent_tail": persistent_tail,
        "localized_tail": localized_tail,
        "verdict": verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*166)
    print(f"common K(8) spread                : {K8_spread:.6e}")
    print(f"late switch                       : {int(late['switch'])}")
    print(f"late boundary m                   : {float(late['m_max_boundary']):.6e}")
    print(f"late K(8)                         : {late_K8:.6e}")
    print(f"late K(16)                        : {late_K16:.6e}")
    print(f"late K(16)/K(8)                   : {late_growth:.6e}")
    print(f"VERDICT                           : {verdict}")
    print("="*166)

    if verdict == "INTRINSIC_MIXING_TAIL_PERSISTS":
        print("CONSEQUENCE:")
        print("  The mixing error is not confined to an O(1/Delta a) transition layer.")
        print("  The proposed I_mix=O(Delta gamma/Delta a) bound is structurally false")
        print("  for the audited phase-root dynamics. Analyze the far-tail mechanism.")
    elif verdict == "INTRINSIC_MIXING_PROFILE_LOCALIZED":
        print("CONSEQUENCE:")
        print("  The intrinsic profile saturates. The v183 anomaly came from integrating")
        print("  window-dependent far regions rather than the true transition mass.")
    else:
        print("ACTION:")
        print("  Inspect K(X) and boundary amplitudes; extend only the late-switch sample")
        print("  if the intrinsic x coverage is insufficient.")


if __name__ == "__main__":
    main()
