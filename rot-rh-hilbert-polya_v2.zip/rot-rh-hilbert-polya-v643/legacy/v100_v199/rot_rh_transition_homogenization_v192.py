#!/usr/bin/env python3
"""
ROT-RH v192 — TRANSITION-ZONE HOMOGENIZATION CONVERGENCE AUDIT

Motivation
----------
v190 showed that the switch contains a narrow/high-amplitude micromotion region
and that direct continuation across the full intrinsic window would require
resolving the relative phase scale

    Delta tau_fast ~ 2*pi/Delta gamma,

which is tiny compared with the slow switch scale.

Instead of resolving billions of fast cycles, v191 freezes the slow intrinsic
coordinate

    x = Delta a * (tau-tau_s),

and for each selected x:
  1. finds several neighboring local roots near the currently active gamma;
  2. follows each root through ONE full fast relative-phase period;
  3. averages |epsilon| and |epsilon_mix| over that cycle;
  4. checks branch-to-branch variability;
  5. integrates the phase-averaged profile over x.

This is a numerical homogenization test, not a proof.

No Xi / zeta / known zeros are used.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def match_candidate(cand, beta, gamma):
    g = cand["gamma"].to_numpy(float)
    b = cand["beta"].to_numpy(float)
    scale = max(abs(float(gamma)), 1.0)
    score = np.abs(g-float(gamma))/scale + 1e-3*np.abs(b-float(beta))
    return cand.iloc[int(np.argmin(score))]


def trapz_mp(xs, ys):
    if len(xs) < 2:
        return mp.nan
    s = mp.mpf("0")
    for i in range(len(xs)-1):
        s += (xs[i+1]-xs[i])*(ys[i+1]+ys[i])/2
    return s


class TwoLayerPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a = []
        self.g = []
        for b, gg in [(b1,g1),(b2,g2)]:
            b = mp.mpf(str(b))
            gg = mp.mpf(str(gg))
            a = b-mp.mpf("0.5")
            self.a += [a,a,-a,-a]
            self.g += [gg,-gg,gg,-gg]

    def eval_E(self, E, tau):
        E=mp.mpf(E); tau=mp.mpf(tau)
        ws=[]; logs=[]
        for a,g in zip(self.a,self.g):
            w=a+1j*(E-g)
            ws.append(w)
            logs.append(mp.loggamma(w)+a*tau+1j*(E-g)*tau)

        sh=max(mp.re(z) for z in logs)
        zs=[mp.exp(z-sh) for z in logs]

        Z=mp.fsum(zs)
        S=mp.im(Z)
        R=mp.re(Z)
        G=mp.fsum(g*mp.re(z) for g,z in zip(self.g,zs))
        A=mp.fsum(a*mp.im(z) for a,z in zip(self.a,zs))
        Q=mp.im(mp.fsum(
            1j*mp.digamma(w)*z for w,z in zip(ws,zs)
        ))
        SE=tau*R+Q
        St=E*R-G+A
        return {"S":S,"R":R,"G":G,"A":A,"Q":Q,"SE":SE,"St":St}

    def eval_Y(self,Y,tau,ga):
        tau=mp.mpf(tau); Y=mp.mpf(Y); ga=mp.mpf(ga)
        E=Y/tau
        q=self.eval_E(E,tau)
        Yt=E-tau*q["St"]/q["SE"]
        eps=Yt-ga
        em=tau*(q["G"]-ga*q["R"])/q["SE"]
        ea=-tau*q["A"]/q["SE"]
        ed=q["Q"]*(E-ga)/q["SE"]
        return {
            **q,"E":E,"Y":Y,"Yt":Yt,
            "epsilon":eps,"epsilon_mix":em,
            "epsilon_A":ea,"epsilon_digamma":ed,
            "identity_resid":abs(eps-(em+ea+ed)),
        }

    def flow_Y(self,Y,tau):
        tau=mp.mpf(tau)
        E=mp.mpf(Y)/tau
        q=self.eval_E(E,tau)
        return E-tau*q["St"]/q["SE"]


def newton_Y(phase,Y0,tau,tol,cell_fraction,iters):
    Y=mp.mpf(Y0); tau=mp.mpf(tau)
    total=mp.mpf("0"); maxstep=mp.mpf("0")

    for k in range(iters):
        E=Y/tau
        q=phase.eval_E(E,tau)
        if abs(q["S"]) <= tol:
            return {
                "ok":True,"Y":Y,"E":E,
                "residual":abs(q["S"]),
                "total_shift":abs(total)/mp.pi,
                "max_step":maxstep,
            }
        SY=q["SE"]/tau
        if SY == 0 or not mp.isfinite(SY):
            return {"ok":False,"reason":"SY_zero"}
        step=-q["S"]/SY
        ratio=abs(step)/mp.pi
        if ratio > cell_fraction:
            return {"ok":False,"reason":"cell_gate","ratio":ratio}
        Y += step
        total += step
        maxstep=max(maxstep,ratio)

    E=Y/tau
    q=phase.eval_E(E,tau)
    return {
        "ok":bool(abs(q["S"])<=tol),
        "reason":"newton_no_convergence",
        "Y":Y,"E":E,
        "residual":abs(q["S"]),
        "total_shift":abs(total)/mp.pi,
        "max_step":maxstep,
    }


def local_roots(phase,tau,center_E,tol,cell_fraction,iters,cells,needed):
    tau=mp.mpf(tau)
    centerY=tau*mp.mpf(center_E)
    roots=[]

    for j in range(-2*cells,2*cells+1):
        seed=centerY+mp.mpf(j)*mp.pi/2
        p=newton_Y(phase,seed,tau,tol,cell_fraction,iters)
        if not p["ok"]:
            continue

        # dedupe in Y by a small fraction of one root cell
        duplicate=False
        for r in roots:
            if abs(p["Y"]-r["Y"]) < mp.mpf("0.20")*mp.pi:
                duplicate=True
                break
        if not duplicate:
            roots.append(p)

    roots.sort(key=lambda r: abs(r["E"]-mp.mpf(center_E)))

    if len(roots) < needed:
        return roots
    return roots[:needed]


def rk4_predict(phase,Y0,t0,t1):
    h=t1-t0
    k1=phase.flow_Y(Y0,t0)
    k2=phase.flow_Y(Y0+h*k1/2,t0+h/2)
    k3=phase.flow_Y(Y0+h*k2/2,t0+h/2)
    k4=phase.flow_Y(Y0+h*k3,t1)
    return Y0+h*(k1+2*k2+2*k3+k4)/6


def advance(phase,Y0,t0,t1,tol,frac,iters,max_depth,depth=0):
    try:
        pred=rk4_predict(phase,Y0,t0,t1)
        p=newton_Y(phase,pred,t1,tol,frac,iters)
    except Exception:
        p={"ok":False}

    if p.get("ok",False):
        return {
            "ok":True,"Y":p["Y"],
            "max_depth":depth,
            "max_proj":max(p["total_shift"],p["max_step"]),
        }

    if depth >= max_depth:
        return {"ok":False,"reason":"max_depth","depth":depth}

    tm=(t0+t1)/2
    a=advance(phase,Y0,t0,tm,tol,frac,iters,max_depth,depth+1)
    if not a["ok"]:
        return a
    b=advance(phase,a["Y"],tm,t1,tol,frac,iters,max_depth,depth+1)
    if not b["ok"]:
        return b

    return {
        "ok":True,"Y":b["Y"],
        "max_depth":max(a["max_depth"],b["max_depth"]),
        "max_proj":max(a["max_proj"],b["max_proj"]),
    }


def cycle_average(
    phase,tau0,center_E,ga,period,phase_points,
    tol,frac,iters,search_cells,branch_count,max_depth
):
    # symmetric one-period window around frozen slow point
    tstart=tau0-period/2
    tend=tau0+period/2

    roots=local_roots(
        phase,tstart,center_E,tol,frac,iters,
        search_cells,branch_count
    )

    results=[]

    for branch_id,r0 in enumerate(roots):
        Y=r0["Y"]
        ts=[
            tstart+(tend-tstart)*mp.mpf(k)/(phase_points-1)
            for k in range(phase_points)
        ]

        rows=[]
        ok=True
        md=0
        mpj=mp.mpf("0")

        for k,t in enumerate(ts):
            if k>0:
                adv=advance(
                    phase,Y,ts[k-1],t,tol,frac,iters,max_depth
                )
                if not adv["ok"]:
                    ok=False
                    break
                Y=adv["Y"]
                md=max(md,adv["max_depth"])
                mpj=max(mpj,adv["max_proj"])

            ev=phase.eval_Y(Y,t,ga)
            rows.append((t,ev))

        if not ok or len(rows)!=phase_points:
            results.append({
                "branch":branch_id,
                "ok":False,
            })
            continue

        tv=[z[0] for z in rows]
        eps=[abs(z[1]["epsilon"]) for z in rows]
        mix=[abs(z[1]["epsilon_mix"]) for z in rows]
        ident=[z[1]["identity_resid"] for z in rows]

        mean_eps=trapz_mp(tv,eps)/(tend-tstart)
        mean_mix=trapz_mp(tv,mix)/(tend-tstart)

        # Phase-resolution check from the same fine cycle:
        # every second sample, preserving final endpoint.
        ids2=list(range(0,len(tv),2))
        if len(tv)-1 not in ids2:
            ids2.append(len(tv)-1)
        tv2=[tv[i] for i in ids2]
        eps2=[eps[i] for i in ids2]
        mix2=[mix[i] for i in ids2]
        mean_eps2=trapz_mp(tv2,eps2)/(tend-tstart)
        mean_mix2=trapz_mp(tv2,mix2)/(tend-tstart)

        results.append({
            "branch":branch_id,
            "ok":True,
            "mean_abs_epsilon":mean_eps,
            "mean_abs_mix":mean_mix,
            "mean_abs_epsilon_over_gamma":mean_eps/abs(ga),
            "mean_abs_mix_over_gamma":mean_mix/abs(ga),
            "mean_abs_epsilon_over_gamma_phase_stride2":mean_eps2/abs(ga),
            "mean_abs_mix_over_gamma_phase_stride2":mean_mix2/abs(ga),
            "max_identity_resid":max(ident),
            "max_depth":md,
            "max_proj":mpj,
        })

    return results


def main():
    ap=argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv",required=True)
    ap.add_argument("--hull-csv",required=True)
    ap.add_argument("--switch-index",type=int,default=159)
    ap.add_argument("--dps",type=int,default=55)
    ap.add_argument("--tol-exp",type=int,default=35)
    ap.add_argument("--newton-iters",type=int,default=10)
    ap.add_argument("--cell-fraction",type=float,default=0.20)
    ap.add_argument("--search-cells",type=int,default=8)
    ap.add_argument("--branch-count",type=int,default=3)
    ap.add_argument("--phase-points",type=int,default=33)
    ap.add_argument("--max-subdivision-depth",type=int,default=8)
    ap.add_argument(
        "--x-values",
        default="-16,-12,-8,-6,-5,-4,-3,-2.5,-2,-1.75,-1.5,-1.25,-1,-0.875,-0.75,-0.625,-0.5,-0.375,-0.25,-0.125,0.125,0.25,0.5,1,2,4",
    )
    ap.add_argument(
        "--branch-spread-gate",
        type=float,
        default=0.25,
        help="Max relative branch spread allowed where the homogenized signal is material.",
    )
    ap.add_argument(
        "--material-signal-gate",
        type=float,
        default=1e-10,
        help="Ignore relative branch spread below this <|eps|>/gamma level as numerical dust.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_transition_homogenization_v192",
    )
    args=ap.parse_args()

    mp.mp.dps=args.dps
    tol=mp.power(10,-args.tol_exp)
    frac=mp.mpf(str(args.cell_fraction))

    cand=pd.read_csv(args.candidates_csv)
    hull=(
        pd.read_csv(args.hull_csv)
        .sort_values("tau_start")
        .reset_index(drop=True)
    )

    j=args.switch_index-1
    left=hull.iloc[j]
    right=hull.iloc[j+1]

    c1=match_candidate(cand,left["beta_active"],left["gamma_active"])
    c2=match_candidate(cand,right["beta_active"],right["gamma_active"])

    b1=mp.mpf(str(float(c1["beta"])))
    g1=mp.mpf(str(float(c1["gamma"])))
    b2=mp.mpf(str(float(c2["beta"])))
    g2=mp.mpf(str(float(c2["gamma"])))

    ts=mp.mpf(str(float(left["tau_end"])))
    da=abs(b2-b1)
    dg=abs(g2-g1)
    period=2*mp.pi/dg

    phase=TwoLayerPhase(b1,g1,b2,g2)

    xs=sorted(
        mp.mpf(x.strip())
        for x in args.x_values.split(",")
        if x.strip()
    )

    print("="*184)
    print("ROT-RH v192 — TRANSITION-ZONE HOMOGENIZATION CONVERGENCE AUDIT")
    print("="*184)
    print("Xi / zeta / known zeros          : NONE")
    print(f"switch                            : {args.switch_index}")
    print(f"gamma                             : {mp.nstr(g1,12)} -> {mp.nstr(g2,12)}")
    print(f"delta gamma                       : {mp.nstr(dg,12)}")
    print(f"delta a                           : {mp.nstr(da,12)}")
    print(f"fast phase period dTau            : {mp.nstr(period,12)}")
    print(f"slow x samples                    : {len(xs)}")
    print(f"phase points / cycle              : {args.phase_points}")
    print(f"branches / x                      : {args.branch_count}")
    print("="*184)

    out=[]
    unresolved=0

    for idx,x in enumerate(xs,1):
        tau=ts+x/da
        ga=g1 if x<0 else g2
        center=ga

        rr=cycle_average(
            phase,tau,center,ga,period,args.phase_points,
            tol,frac,args.newton_iters,args.search_cells,
            args.branch_count,args.max_subdivision_depth
        )

        good=[r for r in rr if r.get("ok")]
        if not good:
            unresolved+=1
            print(
                f"[{idx:2d}/{len(xs)}] x={float(x):8.2f} UNRESOLVED"
            )
            continue

        vals=np.array(
            [float(r["mean_abs_epsilon_over_gamma"]) for r in good],
            float
        )
        mixvals=np.array(
            [float(r["mean_abs_mix_over_gamma"]) for r in good],
            float
        )

        mean=float(np.mean(vals))
        spread=(
            float((np.max(vals)-np.min(vals))/max(mean,1e-300))
            if len(vals)>1 else 0.0
        )
        meanmix=float(np.mean(mixvals))
        phase2vals=np.array(
            [float(r["mean_abs_epsilon_over_gamma_phase_stride2"]) for r in good],
            float
        )
        mean_phase2=float(np.mean(phase2vals))
        phase_rel_diff=abs(mean_phase2-mean)/max(abs(mean),1e-300)

        out.append({
            "x":float(x),
            "tau":float(tau),
            "gamma_active":float(ga),
            "branches_completed":len(good),
            "mean_abs_epsilon_over_gamma":mean,
            "mean_abs_mix_over_gamma":meanmix,
            "mean_abs_epsilon_over_gamma_phase_stride2":mean_phase2,
            "phase_stride2_relative_difference":phase_rel_diff,
            "branch_relative_spread":spread,
            "max_identity_resid":max(
                float(r["max_identity_resid"]) for r in good
            ),
            "max_depth":max(int(r["max_depth"]) for r in good),
            "max_projection":max(float(r["max_proj"]) for r in good),
        })

        print(
            f"[{idx:2d}/{len(xs)}] "
            f"x={float(x):8.2f} "
            f"<|eps|>/g={mean:.3e} "
            f"mix={meanmix:.3e} "
            f"branches={len(good)} "
            f"spread={spread:.3e}"
        )

    df=pd.DataFrame(out).sort_values("x")
    df.to_csv(args.prefix+"_PROFILE.csv",index=False)

    if len(df)<4:
        verdict="HOMOGENIZED_PROFILE_UNRESOLVED"
        summary={"version":192,"verdict":verdict}
    else:
        xv=df["x"].to_numpy(float)
        ga=df["gamma_active"].to_numpy(float)
        r=df["mean_abs_epsilon_over_gamma"].to_numpy(float)

        # mean |epsilon| = ratio * gamma
        epsavg=r*ga

        num=float(np.trapezoid(epsavg,xv))
        den=float(np.trapezoid(ga,xv))
        global_ratio=num/max(abs(den),1e-300)

        material = df[
            df["mean_abs_epsilon_over_gamma"] >= args.material_signal_gate
        ].copy()
        max_spread_all=float(df["branch_relative_spread"].max())
        max_spread_material=(
            float(material["branch_relative_spread"].max())
            if len(material) else 0.0
        )
        branch_stable=bool(
            max_spread_material <= args.branch_spread_gate
        )
        max_phase_diff_material=(
            float(material["phase_stride2_relative_difference"].max())
            if len(material) else 0.0
        )
        phase_quadrature_converged=bool(
            max_phase_diff_material <= 0.10
        )
        profile_complete=bool(unresolved==0)

        # Slow-x quadrature convergence: compare all x samples with every
        # second and every fourth profile point, preserving final endpoint.
        def prof_ratio_stride(stride):
            ids=list(range(0,len(df),stride))
            if len(df)-1 not in ids:
                ids.append(len(df)-1)
            d=df.iloc[sorted(set(ids))]
            xx=d["x"].to_numpy(float)
            gg=d["gamma_active"].to_numpy(float)
            rr=d["mean_abs_epsilon_over_gamma"].to_numpy(float)
            nn=float(np.trapezoid(rr*gg,xx))
            dd=float(np.trapezoid(gg,xx))
            return nn/max(abs(dd),1e-300)

        global_ratio_s2=prof_ratio_stride(2)
        global_ratio_s4=prof_ratio_stride(4)
        xdiff2=abs(global_ratio_s2-global_ratio)/max(abs(global_ratio),1e-300)
        xdiff4=abs(global_ratio_s4-global_ratio)/max(abs(global_ratio),1e-300)
        x_quadrature_converged=bool(xdiff2 <= 0.10 and xdiff4 <= 0.25)

        if profile_complete and branch_stable and phase_quadrature_converged and x_quadrature_converged:
            verdict="TRANSITION_HOMOGENIZATION_CONVERGED"
        elif profile_complete and branch_stable and not phase_quadrature_converged:
            verdict="TRANSITION_HOMOGENIZATION_PHASE_GRID_UNRESOLVED"
        elif profile_complete and branch_stable:
            verdict="TRANSITION_HOMOGENIZATION_X_GRID_UNRESOLVED"
        elif profile_complete:
            verdict="TRANSITION_HOMOGENIZATION_BRANCH_DEPENDENCE"
        else:
            verdict="TRANSITION_HOMOGENIZATION_PARTIALLY_UNRESOLVED"

        summary={
            "version":192,
            "switch":args.switch_index,
            "fast_phase_period":float(period),
            "x_samples_requested":len(xs),
            "x_samples_completed":len(df),
            "unresolved_x_samples":unresolved,
            "phase_points":args.phase_points,
            "branch_count":args.branch_count,
            "homogenized_absolute_epsilon_over_active":global_ratio,
            "homogenized_stride2_x":global_ratio_s2,
            "homogenized_stride4_x":global_ratio_s4,
            "x_relative_difference_stride2":xdiff2,
            "x_relative_difference_stride4":xdiff4,
            "x_quadrature_converged":x_quadrature_converged,
            "max_branch_relative_spread_all":max_spread_all,
            "max_branch_relative_spread_material":max_spread_material,
            "material_signal_gate":args.material_signal_gate,
            "material_x_samples":len(material),
            "max_phase_stride2_relative_difference_material":max_phase_diff_material,
            "phase_quadrature_converged":phase_quadrature_converged,
            "branch_stable":branch_stable,
            "profile_complete":profile_complete,
            "verdict":verdict,
        }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*184)
    if "homogenized_absolute_epsilon_over_active" in summary:
        print(
            f"homogenized |eps| / active        : "
            f"{summary['homogenized_absolute_epsilon_over_active']:.12e}"
        )
        print(
            f"homogenized stride-2 x            : "
            f"{summary['homogenized_stride2_x']:.12e}"
        )
        print(
            f"homogenized stride-4 x            : "
            f"{summary['homogenized_stride4_x']:.12e}"
        )
        print(
            f"x stride-2 relative difference    : "
            f"{summary['x_relative_difference_stride2']:.6e}"
        )
        print(
            f"x stride-4 relative difference    : "
            f"{summary['x_relative_difference_stride4']:.6e}"
        )
        print(
            f"max branch spread (material only) : "
            f"{summary['max_branch_relative_spread_material']:.6e}"
        )
        print(
            f"max phase stride-2 diff (material): "
            f"{summary['max_phase_stride2_relative_difference_material']:.6e}"
        )
        print(
            f"material x samples                : "
            f"{summary['material_x_samples']}"
        )
        print(
            f"x samples completed               : "
            f"{summary['x_samples_completed']}/{summary['x_samples_requested']}"
        )
    print(f"VERDICT                            : {summary['verdict']}")
    print("="*184)


if __name__=="__main__":
    main()
