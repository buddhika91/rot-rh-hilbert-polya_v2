#!/usr/bin/env python3
"""
ROT-RH v186.1 — ACTIVE-ORIENTED ENVELOPE VS SIGNED-WEIGHT MIXING AUDIT

Fixes the diagnostic flaw in v186.

For the two positive-gamma layer groups C1,C2:
    A_i = |C_i|
    W_i = Re C_i

At each point orient ratios relative to the CURRENTLY ACTIVE layer:

    q_A = A_other / A_active                  >= 0
    r_W = W_other / W_active                  signed

Envelope-only mixing prediction:
    m_env = q_A / (1 + q_A)

Exact signed-weight pair prediction:
    m_W = | r_W / (1 + r_W) |

The exact normalized mixing from the phase decomposition is
    m_exact = |epsilon_mix| / Delta gamma.

If m_exact ~ m_W but is much broader/larger than m_env, the broadening is
phase/signed-weight driven.  If m_env already matches m_exact, the envelope
itself explains the broad profile and the v185 slope diagnostic was simply
not the right envelope width measure.

No continuation is performed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import mpmath as mp


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def trapz(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    if len(x) < 2:
        return 0.0
    o = np.argsort(x)
    return float(np.trapezoid(y[o], x[o]))


def rms(a):
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    return float(np.sqrt(np.mean(a*a))) if len(a) else np.nan


def cumulative_symmetric_width(x, m, q=0.9, grid_n=8193):
    x = np.asarray(x, float)
    m = np.asarray(m, float)
    ok = np.isfinite(x) & np.isfinite(m)
    x = x[ok]; m = m[ok]
    if len(x) < 2:
        return np.nan, np.nan

    o = np.argsort(x)
    x = x[o]; m = m[o]
    xmax = min(abs(float(x[0])), abs(float(x[-1])))
    if xmax <= 0:
        return np.nan, np.nan

    X = np.linspace(0.0, xmax, grid_n)
    fp = np.interp(X, x, m)
    fm = np.interp(-X, x, m)
    f = fp + fm

    K = np.zeros_like(X)
    dx = np.diff(X)
    K[1:] = np.cumsum(0.5*(f[1:]+f[:-1])*dx)

    if K[-1] <= 0:
        return np.nan, 0.0

    target = q*K[-1]
    Xq = float(np.interp(target, K, X))
    return Xq, float(K[-1])


class PairPhase:
    def __init__(self, b1, g1, b2, g2):
        self.a1 = mp.mpf(str(b1)) - mp.mpf("0.5")
        self.a2 = mp.mpf(str(b2)) - mp.mpf("0.5")
        self.g1 = mp.mpf(str(g1))
        self.g2 = mp.mpf(str(g2))

    @staticmethod
    def term(a, g, E, tau):
        w = a + 1j*(E-g)
        logz = mp.loggamma(w) + a*tau + 1j*(E-g)*tau
        return w, logz

    def evaluate(self, E, tau, gamma_active):
        E = mp.mpf(str(E))
        tau = mp.mpf(str(tau))
        ga = mp.mpf(str(gamma_active))

        specs = [
            ("1p", self.a1,  self.g1),
            ("1n", self.a1, -self.g1),
            ("1pm",-self.a1, self.g1),
            ("1nm",-self.a1,-self.g1),
            ("2p", self.a2,  self.g2),
            ("2n", self.a2, -self.g2),
            ("2pm",-self.a2, self.g2),
            ("2nm",-self.a2,-self.g2),
        ]

        raw = []
        for name,a,g in specs:
            w,logz = self.term(a,g,E,tau)
            raw.append((name,a,g,w,logz))

        shift = max(mp.re(z[-1]) for z in raw)
        T = {}
        for name,a,g,w,logz in raw:
            T[name] = {
                "a":a, "g":g, "w":w,
                "z":mp.exp(logz-shift)
            }

        C1 = T["1p"]["z"] + T["1pm"]["z"]
        C2 = T["2p"]["z"] + T["2pm"]["z"]

        A1,A2 = abs(C1),abs(C2)
        W1,W2 = mp.re(C1),mp.re(C2)

        # Full exact decomposition mix term.
        all_terms = list(T.values())
        R = mp.fsum(mp.re(t["z"]) for t in all_terms)
        G = mp.fsum(t["g"]*mp.re(t["z"]) for t in all_terms)
        Q = mp.im(mp.fsum(
            1j*mp.digamma(t["w"])*t["z"] for t in all_terms
        ))
        D = tau*R + Q
        eps_mix = tau*(G-ga*R)/D
        dg = abs(self.g2-self.g1)
        m_exact = abs(eps_mix)/dg if dg != 0 else mp.nan

        # Pair exact soft mixing.
        Rp = W1+W2
        Gp = self.g1*W1+self.g2*W2
        eps_pair = (Gp/Rp-ga) if Rp != 0 else mp.nan
        m_pair = abs(eps_pair)/dg if dg != 0 else mp.nan

        if abs(ga-self.g1) <= abs(ga-self.g2):
            Aact,Aoth = A1,A2
            Wact,Woth = W1,W2
            active_id = 1
        else:
            Aact,Aoth = A2,A1
            Wact,Woth = W2,W1
            active_id = 2

        qA = Aoth/Aact if Aact != 0 else mp.inf
        rW = Woth/Wact if Wact != 0 else mp.inf

        m_env = qA/(1+qA) if mp.isfinite(qA) else mp.mpf("1")
        m_W = abs(rW/(1+rW)) if mp.isfinite(rW) and (1+rW)!=0 else mp.inf

        cos1 = W1/A1 if A1 != 0 else mp.nan
        cos2 = W2/A2 if A2 != 0 else mp.nan

        phase_factor = (
            abs(rW)/qA
            if qA != 0 and mp.isfinite(qA) and mp.isfinite(rW)
            else mp.nan
        )

        return {
            "active_id": active_id,
            "A1": A1, "A2": A2,
            "W1": W1, "W2": W2,
            "cos1": cos1, "cos2": cos2,
            "qA_other_over_active": qA,
            "rW_other_over_active": rW,
            "phase_factor_abs": phase_factor,
            "m_env": m_env,
            "m_W": m_W,
            "m_pair": m_pair,
            "m_exact": m_exact,
            "pair_error": abs(m_exact-m_pair),
            "weight_error": abs(m_exact-m_W),
            "env_error": abs(m_exact-m_env),
        }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--points-csv",
        default="rot_rh_global_cesaro_mix_scale_v183_POINTS.csv",
    )
    ap.add_argument("--switch-indices", default="159")
    ap.add_argument("--dps", type=int, default=50)
    ap.add_argument(
        "--phase-broadening-factor-gate",
        type=float,
        default=2.0,
        help="K_exact/K_env above this indicates substantial phase broadening."
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_active_oriented_mix_v186_1",
    )
    args = ap.parse_args()

    mp.mp.dps = args.dps
    switches = [
        int(x.strip()) for x in args.switch_indices.split(",") if x.strip()
    ]

    pts = pd.read_csv(args.points_csv)
    pts = pts[pts["switch"].astype(int).isin(switches)].copy()

    required = {
        "switch","tau","E","tau_switch",
        "beta_left","beta_right",
        "gamma_left","gamma_right","gamma_active"
    }
    missing = required-set(pts.columns)
    if missing:
        raise RuntimeError(f"Missing columns: {sorted(missing)}")

    print("="*176)
    print("ROT-RH v186.1 — ACTIVE-ORIENTED ENVELOPE VS SIGNED-WEIGHT MIXING AUDIT")
    print("="*176)
    print(f"switches                          : {switches}")
    print(f"rows                              : {len(pts)}")
    print(f"mpmath dps                        : {args.dps}")
    print("="*176)

    rows = []
    sums = []

    for sw,g in pts.groupby("switch"):
        g = g.sort_values("tau").reset_index(drop=True)

        b1 = float(g.iloc[0]["beta_left"])
        b2 = float(g.iloc[0]["beta_right"])
        g1 = float(g.iloc[0]["gamma_left"])
        g2 = float(g.iloc[0]["gamma_right"])
        ts = float(g.iloc[0]["tau_switch"])
        da = abs(b2-b1)

        phase = PairPhase(b1,g1,b2,g2)

        local = []
        for _,r in g.iterrows():
            out = phase.evaluate(
                float(r["E"]),
                float(r["tau"]),
                float(r["gamma_active"]),
            )
            rr = {
                "switch":int(sw),
                "tau":float(r["tau"]),
                "x":da*(float(r["tau"])-ts),
                "E":float(r["E"]),
                "gamma_active":float(r["gamma_active"]),
            }
            for k,v in out.items():
                try:
                    rr[k] = float(v)
                except Exception:
                    rr[k] = np.nan
            rows.append(rr)
            local.append(rr)

        d = pd.DataFrame(local).sort_values("x")
        x = d["x"].to_numpy(float)
        me = d["m_exact"].to_numpy(float)
        mw = d["m_W"].to_numpy(float)
        ma = d["m_env"].to_numpy(float)

        K_exact = trapz(x, me)
        K_W = trapz(x, mw)
        K_env = trapz(x, ma)

        X50_exact,_ = cumulative_symmetric_width(x,me,0.50)
        X90_exact,_ = cumulative_symmetric_width(x,me,0.90)
        X50_env,_ = cumulative_symmetric_width(x,ma,0.50)
        X90_env,_ = cumulative_symmetric_width(x,ma,0.90)

        rmse_W = rms(mw-me)
        rmse_env = rms(ma-me)

        broadening_area = K_exact/max(K_env,1e-300)
        broadening_X90 = X90_exact/max(X90_env,1e-300)

        qpf = d["phase_factor_abs"].replace(
            [np.inf,-np.inf],np.nan
        ).dropna().to_numpy(float)

        p50 = float(np.quantile(qpf,.50)) if len(qpf) else np.nan
        p90 = float(np.quantile(qpf,.90)) if len(qpf) else np.nan
        p99 = float(np.quantile(qpf,.99)) if len(qpf) else np.nan

        phase_supported = bool(
            rmse_W <= max(1e-6,0.05*rms(me))
            and broadening_area >= args.phase_broadening_factor_gate
        )
        envelope_supported = bool(
            rmse_env <= max(1e-6,0.05*rms(me))
        )

        sums.append({
            "switch":int(sw),
            "samples":len(d),
            "K_exact":K_exact,
            "K_signed_weight":K_W,
            "K_envelope":K_env,
            "K_exact_over_K_env":broadening_area,
            "X50_exact":X50_exact,
            "X90_exact":X90_exact,
            "X50_env":X50_env,
            "X90_env":X90_env,
            "X90_exact_over_env":broadening_X90,
            "rmse_signed_weight_vs_exact":rmse_W,
            "rmse_envelope_vs_exact":rmse_env,
            "phase_factor_q50":p50,
            "phase_factor_q90":p90,
            "phase_factor_q99":p99,
            "phase_broadening_supported":phase_supported,
            "envelope_explains_mixing":envelope_supported,
        })

        print(
            f"[switch {int(sw):4d}] "
            f"K exact/W/env={K_exact:.3e}/{K_W:.3e}/{K_env:.3e} "
            f"Kexact/Kenv={broadening_area:.3e} "
            f"X90 exact/env={X90_exact:.3e}/{X90_env:.3e} "
            f"RMSE W={rmse_W:.3e} env={rmse_env:.3e} "
            f"phase q50/q90/q99={p50:.3e}/{p90:.3e}/{p99:.3e}"
        )

    out = pd.DataFrame(rows)
    swdf = pd.DataFrame(sums)

    if len(swdf) and swdf["phase_broadening_supported"].all():
        verdict = "ACTIVE_ORIENTED_PHASE_BROADENING_SUPPORTED"
    elif len(swdf) and swdf["envelope_explains_mixing"].all():
        verdict = "ACTIVE_ORIENTED_ENVELOPE_MIXING_SUPPORTED"
    else:
        verdict = "ACTIVE_ORIENTED_MIXING_MECHANISM_UNRESOLVED"

    out.to_csv(args.prefix+"_POINTS.csv",index=False)
    swdf.to_csv(args.prefix+"_SWITCHES.csv",index=False)

    summary = {
        "version":"186.1",
        "switches":switches,
        "verdict":verdict,
    }
    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary),indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*176)
    for _,r in swdf.iterrows():
        print(f"switch {int(r['switch'])}")
        print(f"  K exact / K envelope            : {r['K_exact_over_K_env']:.6e}")
        print(f"  X90 exact / envelope            : {r['X90_exact_over_env']:.6e}")
        print(f"  RMSE signed-weight vs exact     : {r['rmse_signed_weight_vs_exact']:.6e}")
        print(f"  RMSE envelope vs exact          : {r['rmse_envelope_vs_exact']:.6e}")
        print(f"  phase factor q50/q90/q99        : {r['phase_factor_q50']:.6e} / {r['phase_factor_q90']:.6e} / {r['phase_factor_q99']:.6e}")
        print(f"  phase broadening supported      : {bool(r['phase_broadening_supported'])}")
        print(f"  envelope explains mixing        : {bool(r['envelope_explains_mixing'])}")
    print(f"VERDICT                           : {verdict}")
    print("="*176)


if __name__ == "__main__":
    main()
