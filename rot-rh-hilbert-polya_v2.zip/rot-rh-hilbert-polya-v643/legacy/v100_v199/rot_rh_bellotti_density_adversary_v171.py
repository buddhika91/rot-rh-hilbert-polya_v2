#!/usr/bin/env python3
"""
ROT-RH v171 — BELLOTTI-STYLE ZERO-DENSITY-CONSTRAINED DOMINANCE AUDIT

Purpose
-------
v169/v170 showed that:
  * a Korobov-Vinogradov zero-free envelope alone allows runaway dominant
    zero heights; and
  * the corresponding full synthetic phase can drag continued roots to
    large E.

Those synthetic zero layers did NOT enforce the strongest known
near-boundary zero-density structure.

Bellotti (2025) proves, asymptotically, that for any fixed A>A0, where A0 is
the Korobov-Vinogradov zero-free constant, the number

    N(sigma,T),   sigma >= 1 - A f(T),

with
    f(T)=(log T)^(-2/3)(loglog T)^(-1/3),

is O_A(1).

v171 asks a deliberately STRONGER adversarial question:

    Even if we impose a hard cap
        N(1-A f(T),T) <= C
    for EVERY synthetic test height T,

    with very small C (including C=1),
    can the dominance-switch/Cesaro runaway mechanism still occur?

If runaway survives C=1, then any theorem whose only structural content is an
unspecified O_A(1) near-boundary count cannot, by itself, prove the desired
dominance-switch condition.

IMPORTANT
---------
This is still a SYNTHETIC theorem-falsifier.  It does not construct actual
zeta zeros.  The hard cap is a model inspired by the form of Bellotti's
theorem, and for C=1 it is intentionally stronger than the published O(1)
statement.

Candidate construction
----------------------
Generate a dense boundary pool

    beta(gamma) = 1 - A0 f(gamma)

using A0 = 1 / R in the same parameterization as v169.

For each A = mu*A0, mu>1, greedily retain the densest possible increasing
sequence satisfying

    #{ accepted rho_i:
         gamma_i <= T,
         beta_i >= 1 - A f(T) } <= C

at every candidate T.

Because the threshold 1-A f(T) increases with T, checking the constraint at
every candidate endpoint is sufficient for this monotone pool.

Then compute the exact upper envelope of the score lines

    S_j(tau)
      = (beta_j-1/2) tau
        + Re log Gamma(beta_j-1/2+i(E-gamma_j)),

and exactly integrate gamma_active(tau).

Outputs are compatible with v170:
    <prefix>_mu<MU>_cap<C>_CANDIDATES.csv
    <prefix>_mu<MU>_cap<C>_HULL.csv
    <prefix>_mu<MU>_cap<C>_CESARO.csv

NO Xi / zeta evaluations / known-zero ordinates are used.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.special import loggamma
except Exception as exc:
    raise RuntimeError("v171 requires scipy.special.loggamma.") from exc


def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


def csv_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def csv_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def f_vk(gamma):
    g = np.asarray(gamma, dtype=float)
    out = np.full_like(g, np.nan, dtype=float)

    ok = g > math.e
    if not np.any(ok):
        return out

    lg = np.log(g[ok])
    llg = np.log(lg)

    ok2 = llg > 0
    vals = np.full_like(lg, np.nan)

    vals[ok2] = (
        np.power(lg[ok2], -2.0/3.0)
        * np.power(llg[ok2], -1.0/3.0)
    )

    tmp = out[ok]
    tmp[:] = vals
    out[ok] = tmp
    return out


def boundary_beta(gamma, A0, margin):
    b = 1.0 - A0*f_vk(gamma) - margin
    b[(b <= 0.5) | (b >= 1.0)] = np.nan
    return b


def intercept(beta, gamma, E_ref, include_dyadic_factor):
    a = beta-0.5
    z = a + 1j*(E_ref-gamma)
    val = np.real(loggamma(z))

    if include_dyadic_factor:
        q = np.exp(z*math.log(2.0))-1.0
        val = val + np.log(np.maximum(np.abs(q), 1e-300))

    return val


def greedy_density_prune(pool, A, cap):
    """
    Densest greedy subsequence under:
        count{gamma_i<=T, beta_i >= 1-A f(T)} <= cap
    checked at every candidate T.

    Pool must be sorted by gamma ascending.
    """
    accepted_gamma = []
    accepted_beta = []
    accepted_rows = []

    for _, r in pool.iterrows():
        g = float(r["gamma"])
        b = float(r["beta"])

        sigma = float(1.0-A*f_vk(np.array([g]))[0])

        # Number of already accepted zeros that are still to the right of the
        # moving Bellotti-style threshold at this T.
        active_count = sum(bb >= sigma for bb in accepted_beta)

        if b >= sigma:
            if active_count >= cap:
                continue

        accepted_gamma.append(g)
        accepted_beta.append(b)

        rr = r.to_dict()
        rr["density_sigma_at_accept"] = sigma
        rr["density_count_before_accept"] = active_count
        rr["density_count_after_accept"] = active_count + (1 if b >= sigma else 0)
        accepted_rows.append(rr)

    return pd.DataFrame(accepted_rows)


def verify_density_cap(candidates, A, cap):
    """
    Exact O(n^2) verification at all retained candidate endpoints.
    Candidate counts are small enough after pruning.
    """
    g = candidates["gamma"].to_numpy(dtype=float)
    b = candidates["beta"].to_numpy(dtype=float)

    worst = 0
    worst_T = np.nan
    worst_sigma = np.nan

    for T in g:
        sigma = float(1.0-A*f_vk(np.array([T]))[0])
        count = int(np.sum((g <= T) & (b >= sigma)))
        if count > worst:
            worst = count
            worst_T = float(T)
            worst_sigma = sigma

    return worst, worst_T, worst_sigma, bool(worst <= cap)


@dataclass
class HullLine:
    gamma: float
    beta: float
    slope: float
    intercept: float
    start: float


def build_upper_hull(candidates):
    c = candidates.sort_values(["slope", "intercept"]).copy()

    reduced = []
    for _, r in c.iterrows():
        item = {
            "gamma": float(r["gamma"]),
            "beta": float(r["beta"]),
            "slope": float(r["slope"]),
            "intercept": float(r["intercept"]),
        }

        if reduced and abs(item["slope"]-reduced[-1]["slope"]) <= 1e-15:
            if item["intercept"] > reduced[-1]["intercept"]:
                reduced[-1] = item
        else:
            reduced.append(item)

    hull = []

    for r in reduced:
        while hull:
            last = hull[-1]
            denom = r["slope"]-last.slope
            if denom <= 0:
                raise RuntimeError("Non-increasing hull slope.")
            x = (last.intercept-r["intercept"])/denom
            if x <= last.start:
                hull.pop()
            else:
                break

        if not hull:
            start = -np.inf
        else:
            last = hull[-1]
            start = (
                (last.intercept-r["intercept"])
                /(r["slope"]-last.slope)
            )

        hull.append(HullLine(
            gamma=r["gamma"],
            beta=r["beta"],
            slope=r["slope"],
            intercept=r["intercept"],
            start=float(start),
        ))

    return hull


def hull_segments(hull, tau_min, tau_max):
    rows = []

    for i, h in enumerate(hull):
        left = max(tau_min, h.start)
        right = tau_max
        if i+1 < len(hull):
            right = min(right, hull[i+1].start)

        if right <= left:
            continue

        rows.append({
            "hull_index": i,
            "tau_start": float(left),
            "tau_end": float(right),
            "duration": float(right-left),
            "gamma_active": h.gamma,
            "beta_active": h.beta,
            "slope": h.slope,
            "intercept": h.intercept,
            "score_start": h.slope*left+h.intercept,
            "score_end": h.slope*right+h.intercept,
        })

    return pd.DataFrame(rows)


def active_at(segments, tau):
    ends = segments["tau_end"].to_numpy(dtype=float)
    idx = int(np.searchsorted(ends, tau, side="left"))
    idx = min(max(idx, 0), len(segments)-1)
    r = segments.iloc[idx]
    return float(r["gamma_active"]), float(r["beta_active"])


def integrate_gamma(segments, tau_min, tau):
    total = 0.0
    for _, r in segments.iterrows():
        a = max(tau_min, float(r["tau_start"]))
        b = min(tau, float(r["tau_end"]))
        if b > a:
            total += float(r["gamma_active"])*(b-a)
        if float(r["tau_end"]) >= tau:
            break
    return total


def cesaro_table(segments, tau_min, tau_max, points):
    taus = np.geomspace(max(tau_min, 1e-9), tau_max, points)
    rows = []

    for tau in taus:
        g, b = active_at(segments, float(tau))
        integ = integrate_gamma(segments, tau_min, float(tau))

        rows.append({
            "tau": float(tau),
            "gamma_active": g,
            "beta_active": b,
            "cesaro_origin": float(integ/max(tau, 1e-300)),
            "cesaro_window": (
                float(integ/max(tau-tau_min, 1e-300))
                if tau > tau_min else np.nan
            ),
        })

    return pd.DataFrame(rows)


def growth_fit(x, y, tail_fraction):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    start = max(0, int((1.0-tail_fraction)*len(x)))
    x = x[start:]
    y = y[start:]

    ok = (x > 0) & (y > 0) & np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]

    if len(x) < 3:
        return np.nan, np.nan

    X = np.log(x)
    Y = np.log(y)

    A = np.vstack([np.ones_like(X), X]).T
    coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
    pred = A@coef

    p = float(coef[1])
    ss_res = float(np.sum((Y-pred)**2))
    ss_tot = float(np.sum((Y-np.mean(Y))**2))
    r2 = 1.0-ss_res/ss_tot if ss_tot > 0 else np.nan

    return p, r2


def slug_mu(mu):
    s = f"{mu:g}".replace(".", "p")
    return s


def analyze_combo(pool, mu, cap, args, A0):
    A = mu*A0

    pruned = greedy_density_prune(pool, A, cap)

    if len(pruned) == 0:
        raise RuntimeError(f"mu={mu}, cap={cap}: pruning removed all candidates.")

    worst, worstT, worstSigma, density_ok = verify_density_cap(
        pruned, A, cap
    )

    pruned = pruned.copy()
    pruned["slope"] = pruned["beta"]-0.5
    pruned["intercept"] = intercept(
        pruned["beta"].to_numpy(dtype=float),
        pruned["gamma"].to_numpy(dtype=float),
        args.E_ref,
        args.include_dyadic_factor,
    )

    hull = build_upper_hull(pruned)
    seg = hull_segments(hull, args.tau_min, args.tau_max)

    if len(seg) == 0:
        raise RuntimeError(f"mu={mu}, cap={cap}: empty active hull.")

    ces = cesaro_table(
        seg,
        args.tau_min,
        args.tau_max,
        args.tau_eval_points,
    )

    p_c, r2_c = growth_fit(
        ces["tau"], ces["cesaro_origin"], args.growth_fit_tail_fraction
    )
    p_g, r2_g = growth_fit(
        ces["tau"], ces["gamma_active"], args.growth_fit_tail_fraction
    )

    g0 = float(seg.iloc[0]["gamma_active"])
    g1 = float(seg.iloc[-1]["gamma_active"])

    c_mid = float(ces.iloc[len(ces)//2]["cesaro_origin"])
    c_end = float(ces.iloc[-1]["cesaro_origin"])

    range_hit = bool(g1 >= args.gamma_edge_fraction*args.gamma_max)

    runaway = bool(
        np.isfinite(p_c)
        and p_c > args.cesaro_growth_exponent_gate
        and c_end > args.cesaro_growth_factor_gate*max(c_mid, 1e-300)
        and g1 > args.active_gamma_growth_factor_gate*max(g0, 1e-300)
    )

    if not density_ok:
        verdict = "INTERNAL_DENSITY_CONSTRAINT_FAILURE"
    elif range_hit:
        verdict = "GAMMA_RANGE_SATURATED_INCREASE_MAX"
    elif runaway:
        verdict = "O1_ZERO_DENSITY_STILL_ALLOWS_DS_FAILURE"
    else:
        verdict = "NO_DS_FAILURE_UNDER_THIS_DENSITY_CAP"

    return pruned, seg, ces, {
        "mu": mu,
        "A0": A0,
        "A": A,
        "density_cap": cap,
        "candidate_count": int(len(pruned)),
        "worst_density_count": int(worst),
        "worst_density_T": worstT,
        "worst_density_sigma": worstSigma,
        "density_constraint_pass": density_ok,
        "active_segments": int(len(seg)),
        "switch_count": int(max(0, len(seg)-1)),
        "gamma_initial": g0,
        "gamma_terminal": g1,
        "gamma_growth_factor": g1/max(g0, 1e-300),
        "cesaro_terminal": c_end,
        "cesaro_mid": c_mid,
        "cesaro_growth_factor": c_end/max(c_mid, 1e-300),
        "cesaro_growth_exponent": p_c,
        "cesaro_growth_R2": r2_c,
        "active_gamma_growth_exponent": p_g,
        "active_gamma_growth_R2": r2_g,
        "gamma_range_hit": range_hit,
        "verdict": verdict,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)
    ap.add_argument("--tau-eval-points", type=int, default=320)

    ap.add_argument("--gamma-min", type=float, default=10.0)
    ap.add_argument("--gamma-max", type=float, default=1e8)
    ap.add_argument("--gamma-points", type=int, default=20000)

    ap.add_argument(
        "--vk-R",
        dest="vk_R",
        type=float,
        default=55.241,
        help=(
            "v169 denominator convention: A0=1/R in "
            "beta <= 1-A0 f(gamma)."
        ),
    )
    ap.add_argument("--vk-margin", type=float, default=1e-12)

    ap.add_argument(
        "--A-multipliers",
        default="1.01,1.1,2,4",
        help="Test A=mu*A0 with each fixed mu>1.",
    )
    ap.add_argument(
        "--density-caps",
        default="1,2,4",
        help=(
            "Hard synthetic caps for N(1-A f(T),T). "
            "cap=1 is intentionally stronger than O(1)."
        ),
    )

    ap.add_argument("--E-ref", type=float, default=20.0)
    ap.add_argument("--include-dyadic-factor", action="store_true")

    ap.add_argument("--growth-fit-tail-fraction", type=float, default=0.5)
    ap.add_argument("--cesaro-growth-exponent-gate", type=float, default=0.05)
    ap.add_argument("--cesaro-growth-factor-gate", type=float, default=1.5)
    ap.add_argument("--active-gamma-growth-factor-gate", type=float, default=3.0)
    ap.add_argument("--gamma-edge-fraction", type=float, default=0.8)

    ap.add_argument(
        "--prefix",
        default="rot_rh_bellotti_density_adversary_v171",
    )

    args = ap.parse_args()

    if args.tau_max <= args.tau_min:
        raise RuntimeError("tau-max must exceed tau-min.")
    if args.gamma_max <= args.gamma_min:
        raise RuntimeError("gamma-max must exceed gamma-min.")

    mus = csv_floats(args.A_multipliers)
    caps = csv_ints(args.density_caps)

    if any(mu <= 1.0 for mu in mus):
        raise RuntimeError("Every A multiplier must satisfy mu>1.")
    if any(c <= 0 for c in caps):
        raise RuntimeError("Every density cap must be positive.")

    A0 = 1.0/args.vk_R

    gamma = np.geomspace(
        args.gamma_min,
        args.gamma_max,
        args.gamma_points,
    )
    beta = boundary_beta(gamma, A0, args.vk_margin)

    ok = np.isfinite(beta)

    pool = pd.DataFrame({
        "gamma": gamma[ok],
        "beta": beta[ok],
        "source": "VK_boundary_pool",
    }).sort_values("gamma").reset_index(drop=True)

    print("=" * 164)
    print("ROT-RH v171 — BELLOTTI-STYLE ZERO-DENSITY-CONSTRAINED DOMINANCE AUDIT")
    print("=" * 164)
    print("Xi / zeta / known zeros          : NONE")
    print(f"tau window                        : [{args.tau_min:.6g}, {args.tau_max:.6g}]")
    print(f"gamma window                      : [{args.gamma_min:.6g}, {args.gamma_max:.6g}]")
    print(f"boundary pool                     : {len(pool):,}")
    print(f"v169 R convention                 : R={args.vk_R}")
    print(f"A0=1/R                            : {A0:.12e}")
    print(f"A/A0 multipliers                  : {mus}")
    print(f"hard density caps                 : {caps}")
    print("=" * 164)
    print("NOTE: cap=1 is stronger than Bellotti's published O_A(1) conclusion.")
    print()

    summaries = []
    strongest_failure = None

    for mu in mus:
        for cap in caps:
            print(f"[mu={mu:g}, cap={cap}] pruning and building exact hull ...", flush=True)

            cand, hull, ces, summ = analyze_combo(
                pool, mu, cap, args, A0
            )

            tag = f"mu{slug_mu(mu)}_cap{cap}"

            cand.to_csv(
                f"{args.prefix}_{tag}_CANDIDATES.csv",
                index=False,
            )
            hull.to_csv(
                f"{args.prefix}_{tag}_HULL.csv",
                index=False,
            )
            ces.to_csv(
                f"{args.prefix}_{tag}_CESARO.csv",
                index=False,
            )

            summaries.append(summ)

            print(
                f"  retained={summ['candidate_count']:,}  "
                f"worst density={summ['worst_density_count']}/{cap}  "
                f"active segments={summ['active_segments']:,}"
            )
            print(
                f"  gamma: {summ['gamma_initial']:.6e}"
                f" -> {summ['gamma_terminal']:.6e}"
                f"  (x{summ['gamma_growth_factor']:.3e})"
            )
            print(
                f"  Cesaro terminal={summ['cesaro_terminal']:.6e}  "
                f"p={summ['cesaro_growth_exponent']:.6f}  "
                f"R2={summ['cesaro_growth_R2']:.6f}"
            )
            print(f"  VERDICT: {summ['verdict']}")
            print()

            # "Strongest" synthetic falsification = smallest cap, then largest
            # mu, because that is the most restrictive tested near-boundary
            # count model.
            if summ["verdict"] == "O1_ZERO_DENSITY_STILL_ALLOWS_DS_FAILURE":
                key = (-cap, mu)
                if strongest_failure is None or key > strongest_failure[0]:
                    strongest_failure = (key, tag, summ)

    # Overall decision.
    if any(
        s["verdict"] == "INTERNAL_DENSITY_CONSTRAINT_FAILURE"
        for s in summaries
    ):
        overall = "INTERNAL_DENSITY_CONSTRAINT_FAILURE"
    elif any(
        s["verdict"] == "GAMMA_RANGE_SATURATED_INCREASE_MAX"
        for s in summaries
    ):
        overall = "GAMMA_RANGE_SATURATED_INCREASE_MAX"
    elif any(
        s["verdict"] == "O1_ZERO_DENSITY_STILL_ALLOWS_DS_FAILURE"
        and s["density_cap"] == 1
        for s in summaries
    ):
        overall = "EVEN_CAP1_ZERO_DENSITY_ALLOWS_DS_FAILURE"
    elif any(
        s["verdict"] == "O1_ZERO_DENSITY_STILL_ALLOWS_DS_FAILURE"
        for s in summaries
    ):
        overall = "FINITE_ZERO_DENSITY_CAP_ALLOWS_DS_FAILURE"
    else:
        overall = "NO_DS_FAILURE_UNDER_TESTED_DENSITY_CAPS"

    summary = {
        "version": 171,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "mathematical_scope": (
            "Synthetic hard-cap model inspired by Bellotti's asymptotic "
            "N(1-A f(T),T)=O_A(1) theorem.  It does not encode all properties "
            "of the actual zeta-zero set."
        ),
        "parameters": {
            "tau_min": args.tau_min,
            "tau_max": args.tau_max,
            "gamma_min": args.gamma_min,
            "gamma_max": args.gamma_max,
            "gamma_points": args.gamma_points,
            "vk_R": args.vk_R,
            "A0": A0,
            "A_multipliers": mus,
            "density_caps": caps,
            "E_ref": args.E_ref,
        },
        "tests": summaries,
        "strongest_failure": (
            None if strongest_failure is None
            else {
                "tag": strongest_failure[1],
                "summary": strongest_failure[2],
            }
        ),
        "overall_verdict": overall,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print("=" * 164)
    print(f"OVERALL VERDICT: {overall}")
    print("=" * 164)

    if overall == "EVEN_CAP1_ZERO_DENSITY_ALLOWS_DS_FAILURE":
        print("CONSEQUENCE:")
        print("  Even an intentionally stronger cap N(1-A f(T),T)<=1 does not")
        print("  prevent runaway dominance in the synthetic Gamma-weighted model.")
        print("  Therefore an O_A(1) near-boundary zero-density theorem, by itself,")
        print("  cannot close the dominance-switch proof route.")
        if strongest_failure is not None:
            print()
            print("NEXT v170 INPUTS (strong restrictive failure):")
            print(
                f"  --candidates-csv .\\{args.prefix}_{strongest_failure[1]}_CANDIDATES.csv"
            )
            print(
                f"  --hull-csv .\\{args.prefix}_{strongest_failure[1]}_HULL.csv"
            )
    elif overall == "GAMMA_RANGE_SATURATED_INCREASE_MAX":
        print("ACTION:")
        print("  Increase --gamma-max before drawing an asymptotic conclusion.")
    else:
        print("ACTION:")
        print("  Inspect which density cap/multiplier suppresses the hull.  That")
        print("  identifies the exact zero-density inequality worth translating")
        print("  into an analytic Lemma-1 estimate.")


if __name__ == "__main__":
    main()
