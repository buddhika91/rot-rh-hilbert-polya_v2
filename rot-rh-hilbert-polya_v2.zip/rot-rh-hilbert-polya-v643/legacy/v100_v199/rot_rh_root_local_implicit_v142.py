#!/usr/bin/env python3
"""
ROT-RH v142 — DIRECT ROOT-LOCAL IMPLICIT-FUNCTION AUDIT

Purpose
-------
Test the local mechanism for fixed-mode cutoff convergence directly.

For a tracked mode k, define the secular equation

    F_L(E_k(L)) = k - 1/2.

For an adjacent cutoff pair L -> 2L, evaluate the NEW phase F_{2L}
at the OLD root E_k(L):

    delta_{k,L}
      = F_{2L}(E_k(L)) - (k - 1/2).

Since

    F_{2L}(E_k(2L)) = k - 1/2,

the mean-value theorem gives, for some xi between the two roots,

    |E_k(2L)-E_k(L)|
      = |delta_{k,L}| / |F'_{2L}(xi)|.

Therefore, if F'_{2L} does not vanish on the segment joining the roots,

    |E_k(2L)-E_k(L)|
      <= |delta_{k,L}| / min_segment |F'_{2L}|.

This script tests that relationship directly using:
  * roots at 128k from v132,
  * roots at 256k from v137,
  * roots at 512k from v138,
  * direct F and F' evaluations from freshly built 256k and 512k phases.

NO interpolation from v140 is used.
NO Xi, zeta, or known-zero data are used.

It also checks the exact secant quantity

    s_k = |delta_{k,L}| / |Delta E_k|

against the sampled derivative range on the root segment.  If F' keeps one
sign and is sampled densely enough, s_k should lie between the sampled
min/max |F'|.

Outputs
-------
<prefix>_MODES.csv
<prefix>_PAIRS.csv
<prefix>_LOCAL_SAMPLES.csv
<prefix>_VERDICT.json
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import warnings
from pathlib import Path

import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


# ----------------------------------------------------------------------
# utilities
# ----------------------------------------------------------------------

def write_csv(path: Path, rows):
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return

    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def csv_ints(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def scalar_call(fn, x):
    try:
        y = fn(float(x))
    except Exception:
        y = fn(np.array([float(x)], dtype=float))

    a = np.asarray(y, dtype=float).reshape(-1)
    if len(a) == 0:
        raise RuntimeError("Upstream phase function returned empty output.")
    return float(a[0])


def vector_call(fn, x):
    x = np.asarray(x, dtype=float)

    try:
        y = np.asarray(fn(x), dtype=float)
        if y.shape == x.shape:
            return y
        if y.size == x.size:
            return y.reshape(x.shape)
    except Exception:
        pass

    out = np.empty_like(x)
    for i, xx in enumerate(x):
        out[i] = scalar_call(fn, float(xx))
    return out


def safe_ratio(a, b):
    if np.isfinite(a) and np.isfinite(b) and b > 0:
        return float(a / b)
    return np.nan


def local_p(prev, new):
    if prev <= 0 or new <= 0:
        return np.nan
    return float(-math.log(new / prev, 2.0))


def load_endpoint(path):
    z = np.load(path)
    L = int(np.asarray(z["L_new"]).reshape(-1)[0])
    roots = np.asarray(z["roots_new"], dtype=float)
    return L, roots


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
        help="v132 roots containing L=128000.",
    )
    ap.add_argument(
        "--endpoint-256",
        default="rot_rh_low_mode_endpoint_v137_ENDPOINT.npz",
    )
    ap.add_argument(
        "--endpoint-512",
        default="rot_rh_low_mode_endpoint_v138_ENDPOINT.npz",
    )

    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--focus-modes", default="9,10,13,14")

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument(
        "--segment-samples",
        type=int,
        default=17,
        help="Direct F' samples on each old-root -> new-root segment.",
    )
    ap.add_argument(
        "--margin-fraction",
        type=float,
        default=0.20,
        help="Extend local derivative audit by this fraction of |Delta E| on both sides.",
    )
    ap.add_argument(
        "--minimum-margin",
        type=float,
        default=1e-5,
        help="Minimum absolute E margin around a root segment.",
    )

    ap.add_argument(
        "--old-root-defect-contraction-gate",
        type=float,
        default=0.95,
        help="Aggregate |F_new(E_old)-target| ratio required for contraction.",
    )
    ap.add_argument(
        "--root-shift-contraction-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--derivative-floor-gate",
        type=float,
        default=0.05,
        help="Minimum sampled |F'| required for strong local transversality.",
    )
    ap.add_argument(
        "--bound-slack",
        type=float,
        default=1.02,
        help="Allow this multiplicative slack when checking actual shift <= defect/min|F'|.",
    )
    ap.add_argument(
        "--secant-range-slack",
        type=float,
        default=0.02,
        help="Relative slack for secant derivative lying inside sampled derivative range.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_root_local_implicit_v142",
    )

    args = ap.parse_args()

    if args.segment_samples < 3:
        raise RuntimeError("--segment-samples must be at least 3.")

    focus = csv_ints(args.focus_modes)

    # ------------------------------------------------------------------
    # Load roots
    # ------------------------------------------------------------------
    z = np.load(args.base_roots_npz)
    Lbase = np.asarray(z["L"], dtype=int)
    Rbase = np.asarray(z["roots"], dtype=float)

    h = np.where(Lbase == 128000)[0]
    if not len(h):
        raise RuntimeError("L=128000 not found in base roots NPZ.")
    r128 = Rbase[int(h[0])]

    L256, r256 = load_endpoint(args.endpoint_256)
    L512, r512 = load_endpoint(args.endpoint_512)

    if L256 != 256000:
        raise RuntimeError(f"Expected endpoint-256 to contain L=256000, got {L256}.")
    if L512 != 512000:
        raise RuntimeError(f"Expected endpoint-512 to contain L=512000, got {L512}.")

    n = min(args.modes, len(r128), len(r256), len(r512))
    if n < 1:
        raise RuntimeError("No modes available.")

    roots = {
        128000: np.asarray(r128[:n], float),
        256000: np.asarray(r256[:n], float),
        512000: np.asarray(r512[:n], float),
    }

    print("=" * 128)
    print("ROT-RH v142 — DIRECT ROOT-LOCAL IMPLICIT-FUNCTION AUDIT")
    print("=" * 128)
    print("Xi / zeta / known zeros          : NONE")
    print(f"tracked modes                     : 1..{n}")
    print("cutoff pairs                      : 128000->256000, 256000->512000")
    print(f"segment samples                   : {args.segment_samples}")
    print(f"tail factor / counter q           : {args.tail_factor} / {args.counter_q}")
    print("=" * 128)

    # ------------------------------------------------------------------
    # Build only the NEW phases for the two pairs.
    # ------------------------------------------------------------------
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    phases = {}
    warning_messages = {}

    for L in (256000, 512000):
        print(f"[L={L}] building RenormalizedPhase ...", flush=True)
        with warnings.catch_warnings(record=True) as wrn:
            warnings.simplefilter("always")
            phases[L] = v102.RenormalizedPhase.build(
                base,
                int(L),
                float(args.tail_factor),
                int(args.counter_q),
            )
        warning_messages[L] = [str(w.message) for w in wrn]

        if warning_messages[L]:
            print(f"[L={L}] built with {len(warning_messages[L])} warning(s)")
            for msg in warning_messages[L][:2]:
                print(f"           warning: {msg}")
        else:
            print(f"[L={L}] built with no captured warnings")

    # ------------------------------------------------------------------
    # Direct local audits
    # ------------------------------------------------------------------
    mode_rows = []
    local_sample_rows = []
    pair_rows = []

    pairs = [
        (128000, 256000),
        (256000, 512000),
    ]

    pair_defect_sums = []
    pair_shift_sums = []
    pair_bound_sums = []

    for L_old, L_new in pairs:
        phase = phases[L_new]

        defect_sum = 0.0
        shift_sum = 0.0
        bound_sum = 0.0

        strong_transverse_count = 0
        sign_stable_count = 0
        bound_pass_count = 0
        secant_range_pass_count = 0
        new_root_residual_pass_count = 0

        for k0 in range(n):
            k = k0 + 1
            target = k - 0.5

            E_old = float(roots[L_old][k0])
            E_new = float(roots[L_new][k0])
            shift = abs(E_new - E_old)

            # Exact direct secular values under the NEW phase.
            F_at_old = scalar_call(phase.F, E_old)
            F_at_new = scalar_call(phase.F, E_new)

            defect = F_at_old - target
            new_root_residual = F_at_new - target

            # Segment plus a small margin.
            margin = max(
                args.minimum_margin,
                args.margin_fraction * max(shift, args.minimum_margin),
            )

            lo = min(E_old, E_new) - margin
            hi = max(E_old, E_new) + margin

            xs = np.linspace(lo, hi, args.segment_samples, dtype=float)
            fp = vector_call(phase.Fprime, xs)

            abs_fp = np.abs(fp)
            min_abs_fp = float(np.min(abs_fp))
            max_abs_fp = float(np.max(abs_fp))

            fp_min_signed = float(np.min(fp))
            fp_max_signed = float(np.max(fp))

            sign_stable = bool(
                np.all(fp > 0.0) or np.all(fp < 0.0)
            )

            strong_transverse = bool(
                min_abs_fp >= args.derivative_floor_gate
            )

            # Mean-value upper bound using sampled derivative floor.
            shift_bound = (
                abs(defect) / min_abs_fp
                if min_abs_fp > 0 else np.inf
            )

            bound_pass = bool(
                np.isfinite(shift_bound)
                and shift <= args.bound_slack * shift_bound
            )

            # Exact secant derivative implied by old/new root pair.
            secant_abs = (
                abs(defect) / shift
                if shift > 0 else np.nan
            )

            lo_allowed = (1.0 - args.secant_range_slack) * min_abs_fp
            hi_allowed = (1.0 + args.secant_range_slack) * max_abs_fp

            secant_range_pass = bool(
                np.isfinite(secant_abs)
                and secant_abs >= lo_allowed
                and secant_abs <= hi_allowed
            )

            new_root_residual_pass = bool(
                abs(new_root_residual) <= 5e-9
            )

            defect_sum += abs(defect)
            shift_sum += shift
            bound_sum += shift_bound if np.isfinite(shift_bound) else 0.0

            strong_transverse_count += int(strong_transverse)
            sign_stable_count += int(sign_stable)
            bound_pass_count += int(bound_pass)
            secant_range_pass_count += int(secant_range_pass)
            new_root_residual_pass_count += int(new_root_residual_pass)

            mode_rows.append(
                dict(
                    L_old=L_old,
                    L_new=L_new,
                    k=k,
                    target=target,
                    E_old=E_old,
                    E_new=E_new,
                    abs_root_shift=shift,
                    F_new_at_old=F_at_old,
                    old_root_defect_under_new_phase=defect,
                    abs_old_root_defect=abs(defect),
                    F_new_at_new=F_at_new,
                    new_root_residual=new_root_residual,
                    min_abs_Fprime_local=min_abs_fp,
                    max_abs_Fprime_local=max_abs_fp,
                    min_Fprime_signed=fp_min_signed,
                    max_Fprime_signed=fp_max_signed,
                    derivative_sign_stable=int(sign_stable),
                    strong_local_transversality=int(strong_transverse),
                    root_shift_upper_bound=shift_bound,
                    shift_over_bound=(
                        shift / shift_bound
                        if np.isfinite(shift_bound) and shift_bound > 0
                        else np.nan
                    ),
                    secant_abs_derivative=secant_abs,
                    secant_in_sampled_derivative_range=int(secant_range_pass),
                    root_bound_pass=int(bound_pass),
                    new_root_residual_pass=int(new_root_residual_pass),
                )
            )

            for j, (xx, ff) in enumerate(zip(xs, fp)):
                local_sample_rows.append(
                    dict(
                        L_old=L_old,
                        L_new=L_new,
                        k=k,
                        sample_index=j,
                        E=float(xx),
                        Fprime_new=float(ff),
                        abs_Fprime_new=float(abs(ff)),
                        segment_lo=lo,
                        segment_hi=hi,
                    )
                )

        pair_defect_sums.append(defect_sum)
        pair_shift_sums.append(shift_sum)
        pair_bound_sums.append(bound_sum)

        pair_rows.append(
            dict(
                L_old=L_old,
                L_new=L_new,
                modes=n,
                sum_abs_old_root_defect=defect_sum,
                sum_abs_root_shift=shift_sum,
                sum_sampled_shift_bound=bound_sum,
                strong_transversality_fraction=strong_transverse_count / n,
                derivative_sign_stable_fraction=sign_stable_count / n,
                root_bound_pass_fraction=bound_pass_count / n,
                secant_range_pass_fraction=secant_range_pass_count / n,
                new_root_residual_pass_fraction=new_root_residual_pass_count / n,
            )
        )

    # ------------------------------------------------------------------
    # Contraction ratios
    # ------------------------------------------------------------------
    defect_ratio = safe_ratio(pair_defect_sums[1], pair_defect_sums[0])
    shift_ratio = safe_ratio(pair_shift_sums[1], pair_shift_sums[0])
    bound_ratio = safe_ratio(pair_bound_sums[1], pair_bound_sums[0])

    pair_rows[0]["old_root_defect_contraction_ratio"] = np.nan
    pair_rows[0]["root_shift_contraction_ratio"] = np.nan
    pair_rows[0]["sampled_bound_contraction_ratio"] = np.nan

    pair_rows[1]["old_root_defect_contraction_ratio"] = defect_ratio
    pair_rows[1]["root_shift_contraction_ratio"] = shift_ratio
    pair_rows[1]["sampled_bound_contraction_ratio"] = bound_ratio

    # Per-mode contraction of defect and shift.
    per_mode_defect_contract = []
    per_mode_shift_contract = []

    for k in range(1, n + 1):
        r1 = next(
            r for r in mode_rows
            if r["L_old"] == 128000 and r["k"] == k
        )
        r2 = next(
            r for r in mode_rows
            if r["L_old"] == 256000 and r["k"] == k
        )

        dr = safe_ratio(
            r2["abs_old_root_defect"],
            r1["abs_old_root_defect"],
        )
        sr = safe_ratio(
            r2["abs_root_shift"],
            r1["abs_root_shift"],
        )

        r2["defect_contraction_ratio"] = dr
        r2["shift_contraction_ratio"] = sr
        r2["defect_local_p"] = (
            -math.log(dr, 2.0)
            if np.isfinite(dr) and dr > 0 else np.nan
        )
        r2["shift_local_p"] = (
            -math.log(sr, 2.0)
            if np.isfinite(sr) and sr > 0 else np.nan
        )

        r1["defect_contraction_ratio"] = np.nan
        r1["shift_contraction_ratio"] = np.nan
        r1["defect_local_p"] = np.nan
        r1["shift_local_p"] = np.nan

        per_mode_defect_contract.append(
            np.isfinite(dr)
            and dr < args.old_root_defect_contraction_gate
        )
        per_mode_shift_contract.append(
            np.isfinite(sr)
            and sr < args.root_shift_contraction_gate
        )

    write_csv(Path(args.prefix + "_MODES.csv"), mode_rows)
    write_csv(Path(args.prefix + "_PAIRS.csv"), pair_rows)
    write_csv(Path(args.prefix + "_LOCAL_SAMPLES.csv"), local_sample_rows)

    # ------------------------------------------------------------------
    # Focus-mode summaries
    # ------------------------------------------------------------------
    focus_latest = [
        r for r in mode_rows
        if r["L_old"] == 256000 and r["k"] in focus
    ]

    focus_prev = [
        r for r in mode_rows
        if r["L_old"] == 128000 and r["k"] in focus
    ]

    focus_def_prev = sum(r["abs_old_root_defect"] for r in focus_prev)
    focus_def_new = sum(r["abs_old_root_defect"] for r in focus_latest)
    focus_shift_prev = sum(r["abs_root_shift"] for r in focus_prev)
    focus_shift_new = sum(r["abs_root_shift"] for r in focus_latest)

    focus_def_ratio = safe_ratio(focus_def_new, focus_def_prev)
    focus_shift_ratio = safe_ratio(focus_shift_new, focus_shift_prev)

    latest_pair = pair_rows[-1]

    defect_contracts = bool(
        np.isfinite(defect_ratio)
        and defect_ratio < args.old_root_defect_contraction_gate
    )
    shift_contracts = bool(
        np.isfinite(shift_ratio)
        and shift_ratio < args.root_shift_contraction_gate
    )

    local_transverse_ok = bool(
        latest_pair["strong_transversality_fraction"] >= 0.95
    )
    sign_stable_ok = bool(
        latest_pair["derivative_sign_stable_fraction"] >= 0.95
    )
    bound_ok = bool(
        latest_pair["root_bound_pass_fraction"] >= 0.95
    )
    secant_ok = bool(
        latest_pair["secant_range_pass_fraction"] >= 0.90
    )
    root_residual_ok = bool(
        latest_pair["new_root_residual_pass_fraction"] >= 0.95
    )

    if (
        defect_contracts
        and shift_contracts
        and local_transverse_ok
        and sign_stable_ok
        and bound_ok
        and secant_ok
        and root_residual_ok
    ):
        verdict = "DIRECT_IMPLICIT_FUNCTION_MECHANISM_STRONGLY_SUPPORTED"
    elif (
        shift_contracts
        and local_transverse_ok
        and bound_ok
    ):
        verdict = "ROOT_CONVERGENCE_SUPPORTED_LOCAL_MECHANISM_PARTIAL"
    else:
        verdict = "DIRECT_LOCAL_MECHANISM_UNRESOLVED"

    summary = dict(
        version=142,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        theorem_mechanism=(
            "|E_k(2L)-E_k(L)| <= "
            "|F_{2L}(E_k(L))-(k-1/2)| / "
            "min_segment |F'_{2L}|"
        ),
        tracked_modes=n,
        focus_modes=focus,
        aggregate=dict(
            old_root_defect_ratio=defect_ratio,
            root_shift_ratio=shift_ratio,
            sampled_bound_ratio=bound_ratio,
            fraction_modes_defect_contracting=float(
                np.mean(per_mode_defect_contract)
            ),
            fraction_modes_shift_contracting=float(
                np.mean(per_mode_shift_contract)
            ),
        ),
        latest_pair_quality=dict(
            strong_transversality_fraction=
                latest_pair["strong_transversality_fraction"],
            derivative_sign_stable_fraction=
                latest_pair["derivative_sign_stable_fraction"],
            root_bound_pass_fraction=
                latest_pair["root_bound_pass_fraction"],
            secant_range_pass_fraction=
                latest_pair["secant_range_pass_fraction"],
            new_root_residual_pass_fraction=
                latest_pair["new_root_residual_pass_fraction"],
        ),
        focus=dict(
            old_root_defect_ratio=focus_def_ratio,
            root_shift_ratio=focus_shift_ratio,
        ),
        warnings_by_L=warning_messages,
        verdict=verdict,
        proof_status=(
            "NUMERICAL LOCAL IMPLICIT-FUNCTION AUDIT ONLY. "
            "A theorem still requires an analytic bound showing the "
            "old-root defects tend to zero and a nonvanishing derivative "
            "floor on the relevant root neighborhoods."
        ),
    )

    Path(args.prefix + "_VERDICT.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # terminal report
    # ------------------------------------------------------------------
    print()
    print("Pair summaries")
    print("-" * 128)
    for r in pair_rows:
        print(
            f"{r['L_old']:>6d}->{r['L_new']:<6d}  "
            f"sum|defect|={r['sum_abs_old_root_defect']:.6e}  "
            f"sum|dE|={r['sum_abs_root_shift']:.6e}  "
            f"transverse={100*r['strong_transversality_fraction']:.1f}%  "
            f"sign-stable={100*r['derivative_sign_stable_fraction']:.1f}%  "
            f"bound-pass={100*r['root_bound_pass_fraction']:.1f}%  "
            f"secant-pass={100*r['secant_range_pass_fraction']:.1f}%"
        )

    print()
    print("Latest focus modes")
    print("-" * 128)
    print(
        f"{'k':>4} "
        f"{'|defect|':>14} "
        f"{'|dE|':>14} "
        f"{'min|Fprime|':>14} "
        f"{'bound':>14} "
        f"{'d-ratio':>10} "
        f"{'shift-ratio':>12}"
    )

    for r in focus_latest:
        print(
            f"{r['k']:4d} "
            f"{r['abs_old_root_defect']:14.6e} "
            f"{r['abs_root_shift']:14.6e} "
            f"{r['min_abs_Fprime_local']:14.6e} "
            f"{r['root_shift_upper_bound']:14.6e} "
            f"{r['defect_contraction_ratio']:10.6f} "
            f"{r['shift_contraction_ratio']:12.6f}"
        )

    print()
    print("=" * 128)
    print(f"aggregate old-root defect ratio       : {defect_ratio:.9f}")
    print(f"aggregate root-shift ratio            : {shift_ratio:.9f}")
    print(f"aggregate sampled-bound ratio         : {bound_ratio:.9f}")
    print(f"focus old-root defect ratio           : {focus_def_ratio:.9f}")
    print(f"focus root-shift ratio                : {focus_shift_ratio:.9f}")
    print()
    print(
        f"fraction modes defect contracts       : "
        f"{np.mean(per_mode_defect_contract):.3f}"
    )
    print(
        f"fraction modes root shift contracts   : "
        f"{np.mean(per_mode_shift_contract):.3f}"
    )
    print(
        f"latest strong transversality          : "
        f"{latest_pair['strong_transversality_fraction']:.3f}"
    )
    print(
        f"latest derivative sign stability      : "
        f"{latest_pair['derivative_sign_stable_fraction']:.3f}"
    )
    print(
        f"latest mean-value bound pass           : "
        f"{latest_pair['root_bound_pass_fraction']:.3f}"
    )
    print(
        f"latest secant-range pass               : "
        f"{latest_pair['secant_range_pass_fraction']:.3f}"
    )
    print(f"VERDICT                                : {verdict}")
    print("=" * 128)


if __name__ == "__main__":
    main()
