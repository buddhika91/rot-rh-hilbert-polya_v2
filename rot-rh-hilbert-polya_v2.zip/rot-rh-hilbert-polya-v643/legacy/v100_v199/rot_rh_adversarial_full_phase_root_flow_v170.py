#!/usr/bin/env python3
"""
ROT-RH v170 — ADVERSARIAL FULL-PHASE MOVING-ROOT CONTINUATION AUDIT

Purpose
-------
v169 proved (at the synthetic-envelope level) that a zero-free-region bound
alone does NOT force the "Cesaro active ordinate" to remain bounded.

But that does not yet falsify moving-root cutoff convergence, because a
continued secular root can change local phase cell when dominant zero layers
switch.

v170 attacks the stronger and theorem-relevant question:

    Given the adversarial hypothetical zero layers from v169,
    does the FULL COMPETING COMPLEX ZERO-SIDE PHASE admit bounded,
    continuously continued secular-root branches?

Synthetic zero-side phase
-------------------------
For each hypothetical right-half zero rho_j = beta_j + i gamma_j, put

    a_j = beta_j - 1/2 > 0,

and use the asymptotic differentiated-phase building block

    Z_j(E,tau)
      = Gamma(a_j + i(E-gamma_j))
        exp[a_j tau + i(E-gamma_j) tau].

By default the conjugate ordinate -gamma_j is also included:

    Gamma(a_j + i(E+gamma_j))
    exp[a_j tau + i(E+gamma_j) tau].

The secular node model is

    S(E,tau) = Im sum_j Z_j(E,tau) = 0.

All terms are evaluated after subtracting the largest real log-amplitude,
so the calculation remains stable even for tau ~ 1e8.

This is deliberately an ASYMPTOTIC SYNTHETIC MODEL.  It does not claim to be
the complete finite-part ROT-RH phase, and a synthetic escaping branch is not
a counterexample to the actual operator.  Its role is to test whether moving
root geometry, by itself, can survive the exact adversarial dominance-switch
mechanism that defeated v169.

Continuation
------------
1. Find several initial phase roots near E_ref at tau_min.
2. Step through a tau mesh adapted to the v169 upper-hull switch times.
3. Predictor:
       dE/dtau = -S_tau / S_E.
4. Corrector:
       Newton projection back to S(E,tau)=0.
5. If Newton fails, use a local phase-cell bracket search.

Diagnostics
-----------
For every branch:
  * initial/final/max |E|;
  * endpoint displacement;
  * total variation;
  * maximum |dE/dtau|;
  * minimum |S_E|;
  * number of phase-cell changes relative to the v169 active layer;
  * correlation with gamma_active;
  * whether the branch escapes toward the runaway active ordinate.

Main interpretations
--------------------
ROOT_GEOMETRY_SURVIVES_ADVERSARIAL_SWITCHING
    Active gamma runs away but all tracked roots stay in a bounded tube.
    Then the DS condition was too strong; phase-cell relabeling/root geometry
    is a plausible missing ingredient for Lemma 1.

SYNTHETIC_ROOT_ESCAPE_FOUND
    One or more branches escape strongly under the adversarial zero-side
    phase.  Then root geometry alone does not rescue Lemma 1 from the generic
    zero constraints.

TRANSVERSALITY_BREAKDOWN_AT_SWITCHES
    The continuation repeatedly encounters S_E ~ 0.  Then branch
    bifurcation/degeneracy is the precise analytic issue to understand.

NO Xi, zeta evaluations, or known zero ordinates are used.

Expected v169 inputs
--------------------
rot_rh_adversarial_dominance_switch_v169_optimized_sequence_CANDIDATES.csv
rot_rh_adversarial_dominance_switch_v169_optimized_sequence_HULL.csv

Outputs
-------
<prefix>_TRAJECTORIES.csv
<prefix>_BRANCHES.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
    from scipy.special import loggamma, digamma
except Exception as exc:
    raise RuntimeError(
        "v170 requires scipy.optimize and scipy.special."
    ) from exc


# ---------------------------------------------------------------------------
# JSON helper
# ---------------------------------------------------------------------------

def native(x):
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): native(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [native(v) for v in x]
    return x


# ---------------------------------------------------------------------------
# Synthetic phase
# ---------------------------------------------------------------------------

class SyntheticZeroPhase:
    def __init__(
        self,
        beta,
        gamma,
        include_conjugates=True,
        include_functional_mirror=False,
        top_terms=0,
    ):
        beta = np.asarray(beta, dtype=float)
        gamma = np.asarray(gamma, dtype=float)

        ok = (
            np.isfinite(beta)
            & np.isfinite(gamma)
            & (beta > 0.5)
            & (beta < 1.0)
            & (gamma > 0)
        )

        beta = beta[ok]
        gamma = gamma[ok]

        if len(beta) == 0:
            raise RuntimeError("No admissible synthetic zero layers.")

        aa = []
        gg = []
        labels = []

        for i, (b, g) in enumerate(zip(beta, gamma)):
            a = b - 0.5

            aa.append(a)
            gg.append(g)
            labels.append((i, "+gamma", b, g))

            if include_conjugates:
                aa.append(a)
                gg.append(-g)
                labels.append((i, "-gamma", b, -g))

            if include_functional_mirror:
                am = (1.0-b) - 0.5  # = -a
                aa.append(am)
                gg.append(g)
                labels.append((i, "mirror+gamma", 1.0-b, g))

                if include_conjugates:
                    aa.append(am)
                    gg.append(-g)
                    labels.append((i, "mirror-gamma", 1.0-b, -g))

        self.a = np.asarray(aa, dtype=float)
        self.gamma = np.asarray(gg, dtype=float)
        self.labels = labels
        self.top_terms = int(top_terms)

    def _terms(self, E, tau):
        """
        Return stable scaled complex terms and their w=a+i(E-gamma).

        The common positive scale exp(max real log term) is omitted.  Zeros of
        Im sum are unchanged.
        """
        w = self.a + 1j*(E-self.gamma)
        lg = loggamma(w)
        logz = lg + self.a*tau + 1j*(E-self.gamma)*tau

        real = np.real(logz)

        if self.top_terms > 0 and self.top_terms < len(real):
            # Keep only the most competitive amplitudes at this (E,tau).
            idx = np.argpartition(real, -self.top_terms)[-self.top_terms:]
            w = w[idx]
            logz = logz[idx]
            real = real[idx]

        shift = float(np.max(real))
        z = np.exp(logz-shift)

        return z, w, shift

    def eval(self, E, tau):
        """
        S, S_E, S_tau, max_log_amplitude, effective_terms.

        Derivatives are evaluated for the original unscaled sum modulo the
        common positive scale.  At S=0 the scale derivative drops out of the
        implicit-flow ratio exactly.
        """
        z, w, shift = self._terms(E, tau)

        total = np.sum(z)
        S = float(np.imag(total))

        psi = digamma(w)

        # d/dE [Gamma(w) exp(...)] = i(psi(w)+tau) Z
        dE = np.sum(1j*(psi+tau)*z)
        S_E = float(np.imag(dE))

        # d/dtau at fixed E: w Z
        dt = np.sum(w*z)
        S_tau = float(np.imag(dt))

        return S, S_E, S_tau, shift, len(z)


# ---------------------------------------------------------------------------
# v169 active-hull helper
# ---------------------------------------------------------------------------

def active_hull_at(hull, tau):
    if len(hull) == 0:
        return np.nan, np.nan

    # HULL.csv is restricted to the tested tau interval and contains
    # non-overlapping [tau_start,tau_end] segments.
    arr_start = hull["tau_start"].to_numpy(dtype=float)
    arr_end = hull["tau_end"].to_numpy(dtype=float)

    idx = np.searchsorted(arr_end, tau, side="left")
    idx = min(max(idx, 0), len(hull)-1)

    # Small endpoint correction.
    if not (arr_start[idx]-1e-12 <= tau <= arr_end[idx]+1e-12):
        idx = int(np.argmin(np.abs(arr_start-tau)))

    r = hull.iloc[idx]
    return float(r["gamma_active"]), float(r["beta_active"])


def active_phase_cell(E, tau, gamma_active, beta_active):
    if not np.isfinite(gamma_active) or not np.isfinite(beta_active):
        return np.nan

    a = beta_active-0.5
    w = a + 1j*(E-gamma_active)
    phase = float(np.imag(loggamma(w)) + (E-gamma_active)*tau)
    return int(np.rint(phase/math.pi))


# ---------------------------------------------------------------------------
# Tau mesh
# ---------------------------------------------------------------------------

def build_tau_mesh(
    hull,
    tau_min,
    tau_max,
    points_per_segment,
    switch_rel_width,
    switch_points,
    global_log_points,
):
    vals = [tau_min, tau_max]

    # Global logarithmic backbone.
    vals.extend(
        np.geomspace(
            max(tau_min, 1e-9),
            tau_max,
            global_log_points,
        ).tolist()
    )

    for _, r in hull.iterrows():
        a = max(tau_min, float(r["tau_start"]))
        b = min(tau_max, float(r["tau_end"]))
        if b <= a:
            continue

        # Interior points are geometrically spaced when possible.
        if a > 0 and b/a > 1.000001:
            pts = np.geomspace(a, b, points_per_segment+2)
        else:
            pts = np.linspace(a, b, points_per_segment+2)

        vals.extend(pts.tolist())

    # Densify around every switch.
    starts = hull["tau_start"].to_numpy(dtype=float)
    for sw in starts[1:]:
        if not (tau_min < sw < tau_max):
            continue

        rel = np.linspace(
            -switch_rel_width,
            switch_rel_width,
            2*switch_points+1,
        )
        local = sw*(1.0+rel)
        local = local[(local >= tau_min) & (local <= tau_max)]
        vals.extend(local.tolist())
        vals.append(float(sw))

    vals = np.asarray(vals, dtype=float)
    vals = vals[np.isfinite(vals)]
    vals = vals[(vals >= tau_min) & (vals <= tau_max)]
    vals = np.unique(np.round(vals, 10))
    vals.sort()

    return vals


# ---------------------------------------------------------------------------
# Initial roots
# ---------------------------------------------------------------------------

def find_initial_roots(phase, tau, E_min, E_max, grid_points):
    xs = np.linspace(E_min, E_max, grid_points)
    fs = np.empty_like(xs)

    for i, x in enumerate(xs):
        fs[i] = phase.eval(float(x), tau)[0]

    roots = []

    for i in range(len(xs)-1):
        a, b = xs[i], xs[i+1]
        fa, fb = fs[i], fs[i+1]

        if not (np.isfinite(fa) and np.isfinite(fb)):
            continue

        if fa == 0.0:
            roots.append(float(a))
            continue

        if fa*fb < 0:
            try:
                r = brentq(
                    lambda E: phase.eval(E, tau)[0],
                    float(a), float(b),
                    xtol=1e-13,
                    rtol=1e-13,
                    maxiter=100,
                )
                roots.append(float(r))
            except Exception:
                pass

    if not roots:
        raise RuntimeError("No initial phase roots found.")

    roots = np.asarray(sorted(set(np.round(roots, 12))), dtype=float)
    return roots


# ---------------------------------------------------------------------------
# Predictor/corrector
# ---------------------------------------------------------------------------

def correct_root(
    phase,
    tau,
    E_pred,
    newton_iters,
    residual_tol,
    max_newton_spacing_fraction,
    bracket_cells,
    bracket_samples_per_cell,
):
    E = float(E_pred)
    last_SE = np.nan

    spacing = math.pi/max(tau, 1.0)
    max_step = max_newton_spacing_fraction*spacing

    for it in range(newton_iters):
        S, SE, St, logamp, nt = phase.eval(E, tau)
        last_SE = SE

        if abs(S) <= residual_tol:
            return E, abs(S), abs(SE), "newton", it+1

        if not np.isfinite(SE) or abs(SE) < 1e-14:
            break

        step = -S/SE
        step = float(np.clip(step, -max_step, max_step))
        E += step

    # Local bracket search centered on predictor/current estimate.
    radius = bracket_cells*spacing
    q = max(
        17,
        int(2*bracket_cells*bracket_samples_per_cell)+1
    )
    xs = np.linspace(E_pred-radius, E_pred+radius, q)
    fs = np.array(
        [phase.eval(float(x), tau)[0] for x in xs],
        dtype=float,
    )

    candidates = []

    for i in range(len(xs)-1):
        if not (np.isfinite(fs[i]) and np.isfinite(fs[i+1])):
            continue
        if fs[i] == 0:
            candidates.append(float(xs[i]))
        elif fs[i]*fs[i+1] < 0:
            try:
                r = brentq(
                    lambda x: phase.eval(x, tau)[0],
                    float(xs[i]), float(xs[i+1]),
                    xtol=1e-13,
                    rtol=1e-13,
                    maxiter=100,
                )
                candidates.append(float(r))
            except Exception:
                pass

    if candidates:
        root = min(candidates, key=lambda x: abs(x-E_pred))
        S, SE, *_ = phase.eval(root, tau)
        return root, abs(S), abs(SE), "brent", 0

    # Failed projection.
    S, SE, *_ = phase.eval(E, tau)
    return E, abs(S), abs(SE), "failed", newton_iters


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--candidates-csv",
        default=(
            "rot_rh_adversarial_dominance_switch_v169_"
            "optimized_sequence_CANDIDATES.csv"
        ),
    )
    ap.add_argument(
        "--hull-csv",
        default=(
            "rot_rh_adversarial_dominance_switch_v169_"
            "optimized_sequence_HULL.csv"
        ),
    )

    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1.0e8)

    ap.add_argument("--E-ref", type=float, default=20.0)
    ap.add_argument("--E-window", type=float, default=1.0)
    ap.add_argument("--branches", type=int, default=8)
    ap.add_argument("--initial-grid-points", type=int, default=2000)

    ap.add_argument("--include-conjugates", action="store_true", default=True)
    ap.add_argument("--no-conjugates", action="store_true")
    ap.add_argument("--include-functional-mirror", action="store_true")

    ap.add_argument(
        "--top-terms",
        type=int,
        default=0,
        help="0 uses every synthetic zero term; otherwise keep top amplitudes.",
    )

    ap.add_argument("--points-per-segment", type=int, default=2)
    ap.add_argument("--global-log-points", type=int, default=400)
    ap.add_argument("--switch-rel-width", type=float, default=2.5e-4)
    ap.add_argument("--switch-points", type=int, default=3)

    ap.add_argument("--newton-iters", type=int, default=12)
    ap.add_argument("--residual-tol", type=float, default=1e-10)
    ap.add_argument(
        "--max-newton-spacing-fraction",
        type=float,
        default=0.45,
    )
    ap.add_argument("--bracket-cells", type=float, default=4.0)
    ap.add_argument("--bracket-samples-per-cell", type=int, default=8)

    ap.add_argument(
        "--transversality-gate",
        type=float,
        default=1e-5,
    )
    ap.add_argument(
        "--bounded-E-gate",
        type=float,
        default=200.0,
        help="Absolute-E threshold for synthetic escape classification.",
    )
    ap.add_argument(
        "--active-gamma-runaway-factor",
        type=float,
        default=50.0,
    )
    ap.add_argument(
        "--root-runaway-factor",
        type=float,
        default=5.0,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_adversarial_full_phase_root_flow_v170",
    )

    args = ap.parse_args()

    cand = pd.read_csv(args.candidates_csv)
    hull = pd.read_csv(args.hull_csv)

    need_c = {"beta", "gamma"}
    need_h = {"tau_start", "tau_end", "gamma_active", "beta_active"}

    if not need_c.issubset(cand.columns):
        raise RuntimeError(
            f"Candidates CSV missing {sorted(need_c-set(cand.columns))}"
        )
    if not need_h.issubset(hull.columns):
        raise RuntimeError(
            f"Hull CSV missing {sorted(need_h-set(hull.columns))}"
        )

    hull = hull.sort_values("tau_start").reset_index(drop=True)

    include_conjugates = args.include_conjugates and not args.no_conjugates

    phase = SyntheticZeroPhase(
        cand["beta"].to_numpy(dtype=float),
        cand["gamma"].to_numpy(dtype=float),
        include_conjugates=include_conjugates,
        include_functional_mirror=args.include_functional_mirror,
        top_terms=args.top_terms,
    )

    tau_mesh = build_tau_mesh(
        hull,
        args.tau_min,
        args.tau_max,
        args.points_per_segment,
        args.switch_rel_width,
        args.switch_points,
        args.global_log_points,
    )

    print("=" * 162)
    print("ROT-RH v170 — ADVERSARIAL FULL-PHASE MOVING-ROOT CONTINUATION AUDIT")
    print("=" * 162)
    print("Xi / zeta / known zeros          : NONE")
    print(f"candidate zero layers             : {len(cand)}")
    print(f"complex terms incl. symmetries    : {len(phase.a)}")
    print(f"v169 active hull segments         : {len(hull)}")
    print(f"tau mesh points                   : {len(tau_mesh)}")
    print(f"tau window                        : [{args.tau_min:.6g}, {args.tau_max:.6g}]")
    print(f"initial E window                  : [{args.E_ref-args.E_window:.6f}, {args.E_ref+args.E_window:.6f}]")
    print(f"conjugate ordinates               : {include_conjugates}")
    print(f"functional mirrors                : {args.include_functional_mirror}")
    print(f"top-terms truncation              : {args.top_terms}")
    print("=" * 162)

    # ------------------------------------------------------------------
    # Initial roots
    # ------------------------------------------------------------------
    roots0 = find_initial_roots(
        phase,
        args.tau_min,
        args.E_ref-args.E_window,
        args.E_ref+args.E_window,
        args.initial_grid_points,
    )

    order = np.argsort(np.abs(roots0-args.E_ref))
    chosen = roots0[order[:min(args.branches, len(roots0))]]
    chosen = np.sort(chosen)

    print(f"initial roots found               : {len(roots0)}")
    print(f"tracking branches                 : {len(chosen)}")
    print("initial E                         : "
          + ", ".join(f"{x:.9f}" for x in chosen))
    print()

    # ------------------------------------------------------------------
    # Continue branches
    # ------------------------------------------------------------------
    trajectories = []
    branch_state = []

    tau0 = float(tau_mesh[0])

    for bi, E0 in enumerate(chosen, start=1):
        gact, bact = active_hull_at(hull, tau0)
        cell = active_phase_cell(E0, tau0, gact, bact)
        S, SE, St, logamp, nt = phase.eval(E0, tau0)

        trajectories.append({
            "branch": bi,
            "tau": tau0,
            "E": float(E0),
            "residual": abs(S),
            "abs_S_E": abs(SE),
            "dE_dtau": float(-St/SE) if abs(SE)>1e-300 else np.nan,
            "gamma_active": gact,
            "beta_active": bact,
            "phase_cell": cell,
            "method": "initial",
            "max_log_amplitude": logamp,
        })

        branch_state.append({
            "E": float(E0),
            "tau": tau0,
            "cell": cell,
            "failed": False,
        })

    for ti in range(1, len(tau_mesh)):
        tau_new = float(tau_mesh[ti])

        if ti % max(1, len(tau_mesh)//20) == 0:
            print(
                f"[continue] {ti}/{len(tau_mesh)-1} "
                f"tau={tau_new:.6e}",
                flush=True,
            )

        gact, bact = active_hull_at(hull, tau_new)

        for bi, st in enumerate(branch_state, start=1):
            if st["failed"]:
                continue

            E_old = st["E"]
            tau_old = st["tau"]
            dt = tau_new-tau_old

            S0, SE0, St0, _, _ = phase.eval(E_old, tau_old)

            if np.isfinite(SE0) and abs(SE0) > 1e-14:
                flow = -St0/SE0
            else:
                flow = 0.0

            # Predictor.  Avoid absurd one-step jumps; local correction handles
            # the phase cell.  The cap scales with E but does not force boundedness.
            pred_step = flow*dt
            cap = max(1.0, 0.25*max(abs(E_old), 1.0))
            pred_step = float(np.clip(pred_step, -cap, cap))
            E_pred = E_old+pred_step

            E_new, res, absSE, method, nit = correct_root(
                phase,
                tau_new,
                E_pred,
                args.newton_iters,
                args.residual_tol,
                args.max_newton_spacing_fraction,
                args.bracket_cells,
                args.bracket_samples_per_cell,
            )

            if method == "failed":
                st["failed"] = True

            S1, SE1, St1, logamp, nt = phase.eval(E_new, tau_new)
            flow1 = (
                float(-St1/SE1)
                if np.isfinite(SE1) and abs(SE1)>1e-300
                else np.nan
            )

            cell_new = active_phase_cell(
                E_new, tau_new, gact, bact
            )

            trajectories.append({
                "branch": bi,
                "tau": tau_new,
                "E": float(E_new),
                "residual": float(res),
                "abs_S_E": float(absSE),
                "dE_dtau": flow1,
                "gamma_active": gact,
                "beta_active": bact,
                "phase_cell": cell_new,
                "method": method,
                "max_log_amplitude": logamp,
            })

            st["E"] = float(E_new)
            st["tau"] = tau_new
            st["cell"] = cell_new

    tr = pd.DataFrame(trajectories)

    # ------------------------------------------------------------------
    # Branch summaries
    # ------------------------------------------------------------------
    branch_rows = []

    gamma_global_initial = float(
        tr.sort_values("tau").iloc[0]["gamma_active"]
    )
    gamma_global_terminal = float(
        tr.sort_values("tau").iloc[-1]["gamma_active"]
    )
    active_gamma_runaway = bool(
        gamma_global_terminal
        > args.active_gamma_runaway_factor
          * max(gamma_global_initial, 1e-300)
    )

    any_escape = False
    any_trans_break = False

    for bi in sorted(tr["branch"].unique()):
        g = tr[tr["branch"] == bi].sort_values("tau").copy()

        E = g["E"].to_numpy(dtype=float)
        tau = g["tau"].to_numpy(dtype=float)
        cells = g["phase_cell"].to_numpy()
        absSE = g["abs_S_E"].to_numpy(dtype=float)

        dE = np.diff(E)
        total_var = float(np.sum(np.abs(dE)))

        finite_cells = pd.Series(cells).dropna().to_numpy()
        if len(finite_cells) >= 2:
            cell_changes = int(np.sum(
                finite_cells[1:] != finite_cells[:-1]
            ))
        else:
            cell_changes = 0

        # Correlation can be misleading across huge scale differences, but is
        # useful diagnostically.
        ga = g["gamma_active"].to_numpy(dtype=float)
        if np.std(E)>0 and np.std(ga)>0:
            corr = float(np.corrcoef(E, ga)[0,1])
        else:
            corr = np.nan

        failed_steps = int(np.sum(g["method"] == "failed"))
        brent_steps = int(np.sum(g["method"] == "brent"))

        E_growth_factor = float(
            max(np.max(np.abs(E)), 1e-300)
            / max(abs(E[0]), 1e-300)
        )

        escaped = bool(
            np.max(np.abs(E)) > args.bounded_E_gate
            or E_growth_factor > args.root_runaway_factor
        )

        trans_break = bool(
            np.min(absSE) < args.transversality_gate
        )

        any_escape = any_escape or escaped
        any_trans_break = any_trans_break or trans_break

        branch_rows.append({
            "branch": int(bi),
            "points": int(len(g)),
            "E_initial": float(E[0]),
            "E_final": float(E[-1]),
            "E_min": float(np.min(E)),
            "E_max": float(np.max(E)),
            "max_abs_E": float(np.max(np.abs(E))),
            "endpoint_displacement": float(E[-1]-E[0]),
            "total_variation": total_var,
            "E_growth_factor": E_growth_factor,
            "min_abs_S_E": float(np.min(absSE)),
            "max_abs_dE_dtau": float(
                np.nanmax(np.abs(g["dE_dtau"].to_numpy(dtype=float)))
            ),
            "phase_cell_changes": cell_changes,
            "active_gamma_correlation": corr,
            "brent_steps": brent_steps,
            "failed_steps": failed_steps,
            "escaped": escaped,
            "transversality_breakdown": trans_break,
        })

    branches = pd.DataFrame(branch_rows)

    if any_escape:
        verdict = "SYNTHETIC_ROOT_ESCAPE_FOUND"
    elif any_trans_break:
        verdict = "TRANSVERSALITY_BREAKDOWN_AT_SWITCHES"
    else:
        verdict = "ROOT_GEOMETRY_SURVIVES_ADVERSARIAL_SWITCHING"

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------
    tr.to_csv(
        args.prefix+"_TRAJECTORIES.csv",
        index=False,
    )
    branches.to_csv(
        args.prefix+"_BRANCHES.csv",
        index=False,
    )

    summary = {
        "version": 170,
        "firewall": {
            "xi_used": False,
            "zeta_used": False,
            "known_zeros_used": False,
        },
        "warning": (
            "This is an asymptotic synthetic zero-side phase model built from "
            "hypothetical zero layers satisfying the v169 adversarial setup. "
            "It is not the complete ROT-RH phase."
        ),
        "candidate_layers": int(len(cand)),
        "complex_terms": int(len(phase.a)),
        "tau_points": int(len(tau_mesh)),
        "branches": int(len(branches)),
        "gamma_active_initial": gamma_global_initial,
        "gamma_active_terminal": gamma_global_terminal,
        "gamma_active_growth_factor": (
            gamma_global_terminal/max(gamma_global_initial,1e-300)
        ),
        "active_gamma_runaway": active_gamma_runaway,
        "any_root_escape": bool(any_escape),
        "any_transversality_breakdown": bool(any_trans_break),
        "branch_summaries": branch_rows,
        "verdict": verdict,
        "interpretation": (
            "If active gamma runs away while the actual continued phase-node "
            "roots remain bounded, the Cesaro-active-ordinate condition is "
            "too strong and phase-cell relabeling/root geometry is a plausible "
            "missing mechanism. If roots escape, generic zero constraints plus "
            "root geometry are still insufficient."
        ),
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(native(summary), indent=2, allow_nan=True),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Terminal
    # ------------------------------------------------------------------
    print()
    print("Branch summaries")
    print("-" * 162)
    print(
        f"{'br':>3} {'E0':>12} {'Efinal':>12} {'Emin':>12} {'Emax':>12} "
        f"{'TV':>12} {'min|SE|':>12} {'cells':>8} "
        f"{'corr(g)':>10} {'Brent':>7} {'fail':>6} {'escape':>8}"
    )

    for _, r in branches.iterrows():
        print(
            f"{int(r['branch']):3d} "
            f"{r['E_initial']:12.6f} "
            f"{r['E_final']:12.6f} "
            f"{r['E_min']:12.6f} "
            f"{r['E_max']:12.6f} "
            f"{r['total_variation']:12.6e} "
            f"{r['min_abs_S_E']:12.4e} "
            f"{int(r['phase_cell_changes']):8d} "
            f"{r['active_gamma_correlation']:10.4f} "
            f"{int(r['brent_steps']):7d} "
            f"{int(r['failed_steps']):6d} "
            f"{str(bool(r['escaped'])):>8}"
        )

    print()
    print("=" * 162)
    print(f"active gamma initial              : {gamma_global_initial:.6e}")
    print(f"active gamma terminal             : {gamma_global_terminal:.6e}")
    print(
        f"active gamma growth factor        : "
        f"{gamma_global_terminal/max(gamma_global_initial,1e-300):.6e}"
    )
    print(f"active gamma runaway              : {active_gamma_runaway}")
    print(f"any root escape                   : {any_escape}")
    print(f"any transversality breakdown      : {any_trans_break}")
    print(f"VERDICT                           : {verdict}")
    print("=" * 162)

    if verdict == "ROOT_GEOMETRY_SURVIVES_ADVERSARIAL_SWITCHING":
        print("NEXT ANALYTIC TARGET:")
        print("  Prove bounded continued roots despite unbounded amplitude-envelope")
        print("  switching.  The phase-cell index changes are then the key invariant")
        print("  missing from the v169 active-ordinate model.")
    elif verdict == "TRANSVERSALITY_BREAKDOWN_AT_SWITCHES":
        print("NEXT ANALYTIC TARGET:")
        print("  Study zeros of the competing coefficient / simultaneous S=S_E=0.")
        print("  Branch bifurcation, not amplitude growth, is the remaining obstacle.")
    else:
        print("NEXT ANALYTIC TARGET:")
        print("  Root geometry alone does not rescue the generic adversarial model.")
        print("  Additional arithmetic structure of the actual zeta zero ensemble")
        print("  would be required to prove Lemma 1.")


if __name__ == "__main__":
    main()
