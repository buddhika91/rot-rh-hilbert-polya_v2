#!/usr/bin/env python3
"""
ROT-RH v157 — SIGNED PRIMITIVE SHELL / MICROMOTION-CANCELLATION AUDIT

Purpose
-------
v155-v156 showed that absolute derivative integrability is too strong:
the local total variation

    T_N(a) = sum_{k<=N} |d lambda_k/da|

can grow even while endpoint trace differences shrink.

The correct object is therefore the EXACT cutoff-difference primitive

    delta_k(L,M)
      = F_M(E_k(L)) - (k-1/2)
      = [Delta M(E_k) - Delta P(E_k)] / pi,

already validated in v150/v153.

v157 resolves that primitive by dimensionless arithmetic scale

    y = x/M.

For each adjacent cutoff pair L<M and each frozen old root E_k(L), it computes

    Delta P_s(E)
      = sum_{p^a in shell s}
          (1/a) p^{-a/2}
          [e^{-p^a/M}-e^{-p^a/L}]
          sin(E log p^a),

and

    Delta M_s(E)
      = int_{shell s}
          [e^{-x/M}-e^{-x/L}]
          x^{-1/2} sin(E log x)/log x dx,

then

    c_{k,s}(L,M)
      = [Delta M_s(E_k)-Delta P_s(E_k)]/pi.

Thus

    delta_k(L,M) = sum_s c_{k,s} + tail.

Diagnostics
-----------
1. Reconstruct the actual v150 secular defect from shell contributions.
2. Measure signed cancellation:
       sum_s |c_{k,s}| / |sum_s c_{k,s}|.
3. Measure cumulative HIGH-y signed tails:
       |sum_{s>=j} c_{k,s}|.
4. Compare normalized shell profiles across increasing cutoff pairs.
5. Identify which dimensionless arithmetic shells drive the shrinking
   finite-block defect.

Why y=x/M?
----------
For comparable cutoff ratios M/L, the exponential kernel becomes

    e^{-y} - e^{-(M/L)y},

so the smooth regulator shape is cutoff-independent in y.  A stable shell
profile in y would point toward a scale-invariant signed-kernel theorem,
rather than a total-variation theorem in a=1/L.

NO Xi / zeta / known-zero data are used.
No phase builds and no root solves are performed.

Inputs
------
v150 ROOTS CSV supplies the actual old-root secular defects and root energies.

Outputs
-------
<prefix>_SHELL_MODES.csv
<prefix>_PAIR_SUMMARY.csv
<prefix>_SHELL_SUMMARY.csv
<prefix>_TAILS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss


def parse_pairs(s):
    out = []
    for item in s.split(","):
        item = item.strip()
        if not item:
            continue
        a, b = item.split(":")
        a, b = int(a), int(b)
        if not a < b:
            raise ValueError(f"Need L<M, got {item}")
        out.append((a, b))
    return out


def parse_floats(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    lim = int(math.isqrt(nmax))
    for p in range(2, lim + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve)


def prime_power_atoms(nmax):
    """
    atoms n=p^a with coefficient Lambda(n)/log n = 1/a.
    """
    primes = prime_sieve(nmax)

    n_parts = [primes.astype(np.int64)]
    w_parts = [np.ones(len(primes), dtype=np.float64)]

    extra_n = []
    extra_w = []

    for p in primes[primes <= int(math.isqrt(nmax))].tolist():
        x = p * p
        a = 2
        while x <= nmax:
            extra_n.append(x)
            extra_w.append(1.0 / a)
            if x > nmax // p:
                break
            x *= p
            a += 1

    if extra_n:
        n_parts.append(np.asarray(extra_n, dtype=np.int64))
        w_parts.append(np.asarray(extra_w, dtype=np.float64))

    n = np.concatenate(n_parts)
    w = np.concatenate(w_parts)

    order = np.argsort(n, kind="mergesort")
    return n[order], w[order]


def continuum_shell(E, L, M, xlo, xhi, gl_nodes, gl_weights):
    """
    Integrate in u=log x:

      int [e^-x/M - e^-x/L] x^-1/2 sin(E log x)/log x dx

    dx=e^u du, hence density
      [..] e^(u/2)/u.
    """
    if not (xhi > xlo >= 2.0):
        return 0.0

    ulo = math.log(xlo)
    uhi = math.log(xhi)

    mid = 0.5 * (ulo + uhi)
    half = 0.5 * (uhi - ulo)

    u = mid + half * gl_nodes
    x = np.exp(u)

    reg = np.exp(-x/M) - np.exp(-x/L)
    density = reg * np.exp(0.5*u) / u

    return float(
        half * np.dot(
            gl_weights,
            density * np.sin(E*u)
        )
    )


def correlation(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)

    if np.allclose(a, a[0]) or np.allclose(b, b[0]):
        return np.nan

    return float(np.corrcoef(a, b)[0, 1])


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v150-roots-csv",
        default="rot_rh_cutoff_difference_kernel_v150_ROOTS.csv",
    )
    ap.add_argument(
        "--pairs",
        default="128000:181019,181019:256000,256000:362039,362039:512000",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--y-shell-edges",
        default="0,0.03125,0.0625,0.125,0.25,0.5,1,2,4,8,12,18",
        help="Dimensionless shell edges in y=x/M.",
    )
    ap.add_argument(
        "--continuum-gl-order",
        type=int,
        default=256,
    )

    ap.add_argument(
        "--identity-rms-gate",
        type=float,
        default=2e-7,
        help="RMS shell reconstruction error vs v150 actual secular defect.",
    )
    ap.add_argument(
        "--outer-y-threshold",
        type=float,
        default=4.0,
        help="Treat shells y>=threshold as outer arithmetic tail.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_signed_primitive_shells_v157",
    )

    args = ap.parse_args()

    pairs = parse_pairs(args.pairs)
    yedges = parse_floats(args.y_shell_edges)

    if len(yedges) < 3 or yedges[0] != 0.0:
        raise RuntimeError("y-shell edges must begin at 0 and contain >=3 points.")
    if any(yedges[i+1] <= yedges[i] for i in range(len(yedges)-1)):
        raise RuntimeError("y-shell edges must be strictly increasing.")
    if yedges[-1] < args.tail_factor:
        raise RuntimeError(
            "Final y-shell edge must be >= tail-factor so shells cover the arithmetic cutoff."
        )

    roots_df = pd.read_csv(args.v150_roots_csv)
    roots_df = roots_df[roots_df["k"] <= args.modes].copy()

    max_M = max(M for _, M in pairs)
    xmax = int(math.ceil(args.tail_factor * max_M))

    print("=" * 144)
    print("ROT-RH v157 — SIGNED PRIMITIVE SHELL / MICROMOTION-CANCELLATION AUDIT")
    print("=" * 144)
    print("Xi / zeta / known zeros          : NONE")
    print(f"pairs                             : {pairs}")
    print(f"modes                             : 1..{args.modes}")
    print(f"prime-power xmax                  : {xmax:,}")
    print(f"y=x/M shell edges                 : {yedges}")
    print(f"continuum GL order                : {args.continuum_gl_order}")
    print("=" * 144)

    print("[arithmetic] sieving prime powers ...", flush=True)
    atom_n, atom_afac = prime_power_atoms(xmax)
    atom_x = atom_n.astype(np.float64)
    atom_u = np.log(atom_x)
    atom_base = atom_afac / np.sqrt(atom_x)

    print(f"[arithmetic] atoms                 : {len(atom_n):,}")

    gl_nodes, gl_weights = leggauss(args.continuum_gl_order)

    shell_mode_rows = []
    pair_rows = []
    shell_summary_rows = []
    tail_rows = []

    pair_profiles = []

    for pair_index, (L, M) in enumerate(pairs):
        print()
        print(f"[pair {L}->{M}] shell decomposition ...", flush=True)

        pr = roots_df[
            (roots_df["L"] == L)
            & (roots_df["M"] == M)
        ].sort_values("k")

        if len(pr) == 0:
            raise RuntimeError(
                f"No rows for pair {L}->{M} in {args.v150_roots_csv}"
            )

        pr = pr.iloc[:args.modes].copy()

        Es = pr["E_old"].to_numpy(dtype=float)
        actual_def = pr["actual_secular_defect"].to_numpy(dtype=float)
        ks = pr["k"].to_numpy(dtype=int)

        reg_atom = (
            np.exp(-atom_x / float(M))
            - np.exp(-atom_x / float(L))
        )
        atom_weight = atom_base * reg_atom

        nshell = len(yedges) - 1
        C = np.zeros((len(Es), nshell), dtype=float)
        DP = np.zeros_like(C)
        DM = np.zeros_like(C)

        shell_labels = []
        shell_xranges = []

        for s in range(nshell):
            ylo = yedges[s]
            yhi = yedges[s+1]

            xlo = max(2.0, ylo * M)
            xhi = min(float(xmax), yhi * M)

            shell_labels.append(f"{ylo:g}-{yhi:g}")
            shell_xranges.append((xlo, xhi))

            if xhi <= xlo:
                continue

            # Exact discrete atoms in [xlo,xhi), final shell includes endpoint.
            if s == nshell - 1:
                mask = (atom_x >= xlo) & (atom_x <= xhi)
            else:
                mask = (atom_x >= xlo) & (atom_x < xhi)

            uu = atom_u[mask]
            ww = atom_weight[mask]

            if len(uu):
                # modes x atoms, chunk to avoid huge temporary matrices
                dP = np.zeros(len(Es), dtype=float)
                chunk = 65536
                for i in range(0, len(uu), chunk):
                    uc = uu[i:i+chunk]
                    wc = ww[i:i+chunk]
                    # shape (modes,chunk)
                    dP += np.sin(np.outer(Es, uc)) @ wc
            else:
                dP = np.zeros(len(Es), dtype=float)

            dM = np.array([
                continuum_shell(
                    E=float(E),
                    L=L,
                    M=M,
                    xlo=xlo,
                    xhi=xhi,
                    gl_nodes=gl_nodes,
                    gl_weights=gl_weights,
                )
                for E in Es
            ], dtype=float)

            DP[:, s] = dP
            DM[:, s] = dM
            C[:, s] = (dM - dP) / math.pi

        reconstructed = np.sum(C, axis=1)
        identity_res = actual_def - reconstructed

        abs_shell_sum = np.sum(np.abs(C), axis=1)
        cancellation = abs_shell_sum / np.maximum(
            np.abs(reconstructed), 1e-300
        )

        # High-y tail primitives.
        tail_matrix = np.zeros_like(C)
        running = np.zeros(len(Es), dtype=float)
        for s in range(nshell-1, -1, -1):
            running = running + C[:, s]
            tail_matrix[:, s] = running

        # Save mode-shell rows.
        for i, k in enumerate(ks):
            for s in range(nshell):
                ylo, yhi = yedges[s], yedges[s+1]
                xlo, xhi = shell_xranges[s]

                shell_mode_rows.append(dict(
                    L=L,
                    M=M,
                    k=int(k),
                    E_old=float(Es[i]),
                    shell=s+1,
                    y_lo=ylo,
                    y_hi=yhi,
                    x_lo=xlo,
                    x_hi=xhi,
                    deltaP_shell=float(DP[i, s]),
                    deltaM_shell=float(DM[i, s]),
                    secular_shell=float(C[i, s]),
                    abs_secular_shell=float(abs(C[i, s])),
                    high_y_tail_from_shell=float(tail_matrix[i, s]),
                    abs_high_y_tail_from_shell=float(abs(tail_matrix[i, s])),
                ))

        # Shell aggregate profile across modes: exactly topology-relevant l1.
        profile = np.sum(np.abs(C), axis=0)
        signed_profile = np.sum(C, axis=0)
        pair_profiles.append(profile / max(np.sum(profile), 1e-300))

        for s in range(nshell):
            ylo, yhi = yedges[s], yedges[s+1]

            high_tail_l1 = float(np.sum(np.abs(tail_matrix[:, s])))

            shell_summary_rows.append(dict(
                L=L,
                M=M,
                shell=s+1,
                y_lo=ylo,
                y_hi=yhi,
                l1_shell_over_modes=float(profile[s]),
                signed_shell_over_modes=float(signed_profile[s]),
                shell_share_of_total_variation=float(
                    profile[s] / max(np.sum(profile), 1e-300)
                ),
                high_y_tail_l1_from_shell=high_tail_l1,
                high_y_tail_over_actual_defect_l1=float(
                    high_tail_l1 /
                    max(np.sum(np.abs(actual_def)), 1e-300)
                ),
            ))

        # Outer y tail.
        outer_idx = next(
            (s for s in range(nshell) if yedges[s] >= args.outer_y_threshold),
            nshell
        )

        if outer_idx < nshell:
            outer_tail_l1 = float(
                np.sum(np.abs(tail_matrix[:, outer_idx]))
            )
        else:
            outer_tail_l1 = 0.0

        actual_l1 = float(np.sum(np.abs(actual_def)))
        recon_l1 = float(np.sum(np.abs(reconstructed)))
        total_shell_variation = float(np.sum(abs_shell_sum))

        rms = float(np.sqrt(np.mean(identity_res**2)))
        max_id = float(np.max(np.abs(identity_res)))

        pair_rows.append(dict(
            L=L,
            M=M,
            ratio_L=float(M/L),
            modes=len(Es),
            actual_defect_l1=actual_l1,
            reconstructed_defect_l1=recon_l1,
            total_shell_variation=total_shell_variation,
            aggregate_cancellation_factor=float(
                total_shell_variation /
                max(recon_l1, 1e-300)
            ),
            median_mode_cancellation_factor=float(np.median(cancellation)),
            max_mode_cancellation_factor=float(np.max(cancellation)),
            identity_rms=rms,
            identity_max=max_id,
            outer_y_threshold=args.outer_y_threshold,
            outer_signed_tail_l1=outer_tail_l1,
            outer_tail_over_actual_l1=float(
                outer_tail_l1/max(actual_l1, 1e-300)
            ),
        ))

        # Per starting shell tail table.
        for s in range(nshell):
            tail_l1 = float(np.sum(np.abs(tail_matrix[:, s])))
            tail_rows.append(dict(
                L=L,
                M=M,
                from_shell=s+1,
                from_y=yedges[s],
                high_y_signed_tail_l1=tail_l1,
                ratio_to_actual_defect_l1=float(
                    tail_l1/max(actual_l1, 1e-300)
                ),
            ))

        print(
            f"[pair {L}->{M}] "
            f"actual L1={actual_l1:.6e}  "
            f"recon L1={recon_l1:.6e}  "
            f"shell-var={total_shell_variation:.6e}  "
            f"cancel={total_shell_variation/max(recon_l1,1e-300):.2f}x  "
            f"id-rms={rms:.3e}  "
            f"outer-tail/actual={outer_tail_l1/max(actual_l1,1e-300):.3e}"
        )

    # ------------------------------------------------------------------
    # pair-to-pair shell-profile self similarity
    # ------------------------------------------------------------------
    profile_corrs = []

    for i in range(1, len(pair_profiles)):
        c = correlation(pair_profiles[i-1], pair_profiles[i])
        l1dist = float(np.sum(np.abs(
            pair_profiles[i] - pair_profiles[i-1]
        )))
        profile_corrs.append(dict(
            previous_pair=f"{pairs[i-1][0]}->{pairs[i-1][1]}",
            current_pair=f"{pairs[i][0]}->{pairs[i][1]}",
            profile_correlation=c,
            normalized_profile_l1_distance=l1dist,
        ))

    # Add contraction ratios.
    for i, r in enumerate(pair_rows):
        if i == 0:
            r["actual_defect_l1_ratio"] = np.nan
            r["shell_variation_ratio"] = np.nan
            r["outer_tail_ratio"] = np.nan
        else:
            prev = pair_rows[i-1]
            r["actual_defect_l1_ratio"] = (
                r["actual_defect_l1"] /
                max(prev["actual_defect_l1"], 1e-300)
            )
            r["shell_variation_ratio"] = (
                r["total_shell_variation"] /
                max(prev["total_shell_variation"], 1e-300)
            )
            r["outer_tail_ratio"] = (
                r["outer_signed_tail_l1"] /
                max(prev["outer_signed_tail_l1"], 1e-300)
            )

    shell_mode_df = pd.DataFrame(shell_mode_rows)
    pair_df = pd.DataFrame(pair_rows)
    shell_summary_df = pd.DataFrame(shell_summary_rows)
    tails_df = pd.DataFrame(tail_rows)

    shell_mode_df.to_csv(
        args.prefix + "_SHELL_MODES.csv", index=False
    )
    pair_df.to_csv(
        args.prefix + "_PAIR_SUMMARY.csv", index=False
    )
    shell_summary_df.to_csv(
        args.prefix + "_SHELL_SUMMARY.csv", index=False
    )
    tails_df.to_csv(
        args.prefix + "_TAILS.csv", index=False
    )

    identity_ok = all(
        r["identity_rms"] <= args.identity_rms_gate
        for r in pair_rows
    )

    corr_vals = [
        r["profile_correlation"]
        for r in profile_corrs
        if np.isfinite(r["profile_correlation"])
    ]
    mean_corr = float(np.mean(corr_vals)) if corr_vals else np.nan

    actual_contracts = all(
        pair_rows[i]["actual_defect_l1_ratio"] < 1.0
        for i in range(1, len(pair_rows))
    )

    outer_contracts = all(
        pair_rows[i]["outer_tail_ratio"] < 1.0
        for i in range(1, len(pair_rows))
        if np.isfinite(pair_rows[i]["outer_tail_ratio"])
    )

    if (
        identity_ok
        and actual_contracts
        and mean_corr > 0.80
    ):
        verdict = "SIGNED_PRIMITIVE_SCALE_PROFILE_STRONGLY_SUPPORTED"
    elif identity_ok and actual_contracts:
        verdict = "SIGNED_PRIMITIVE_CONTRACTION_SUPPORTED_PROFILE_EVOLVES"
    else:
        verdict = "SIGNED_PRIMITIVE_SHELL_MECHANISM_UNRESOLVED"

    summary = dict(
        version=157,
        firewall=dict(
            xi_used=False,
            zeta_used=False,
            known_zeros_used=False,
        ),
        shell_coordinate="y=x/M",
        y_shell_edges=yedges,
        pair_results=pair_rows,
        shell_profile_similarity=profile_corrs,
        mean_adjacent_profile_correlation=mean_corr,
        identity_pass=identity_ok,
        actual_defect_contracts=actual_contracts,
        outer_tail_contracts=outer_contracts,
        verdict=verdict,
        theorem_target=(
            "Prove the signed weighted-PNT primitive itself tends to zero "
            "on each fixed spectral block. The y=x/M shell decomposition "
            "tests whether a scale-invariant signed cancellation mechanism "
            "can replace the false bounded-total-variation requirement."
        ),
    )

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    # ------------------------------------------------------------------
    # terminal
    # ------------------------------------------------------------------
    print()
    print("Pair primitive summaries")
    print("-" * 144)
    print(
        f"{'pair':>18} {'actual L1':>13} {'recon L1':>13} "
        f"{'shell var':>13} {'cancel':>9} {'id RMS':>11} "
        f"{'outer/actual':>13} {'def ratio':>10}"
    )

    for r in pair_rows:
        print(
            f"{r['L']:>7d}->{r['M']:<7d} "
            f"{r['actual_defect_l1']:13.6e} "
            f"{r['reconstructed_defect_l1']:13.6e} "
            f"{r['total_shell_variation']:13.6e} "
            f"{r['aggregate_cancellation_factor']:9.3f} "
            f"{r['identity_rms']:11.3e} "
            f"{r['outer_tail_over_actual_l1']:13.6e} "
            f"{r['actual_defect_l1_ratio']:10.6f}"
        )

    print()
    print("Dimensionless shell l1 profiles")
    print("-" * 144)

    # Compact table: each shell across pairs.
    shell_labels = [
        f"{yedges[s]:g}-{yedges[s+1]:g}"
        for s in range(len(yedges)-1)
    ]

    print(
        f"{'y shell':>14} "
        + " ".join(
            f"{L}->{M}".rjust(15)
            for L, M in pairs
        )
    )

    for s, label in enumerate(shell_labels, start=1):
        vals = []
        for L, M in pairs:
            q = shell_summary_df[
                (shell_summary_df["L"] == L)
                & (shell_summary_df["M"] == M)
                & (shell_summary_df["shell"] == s)
            ]
            vals.append(
                float(q.iloc[0]["shell_share_of_total_variation"])
                if len(q) else np.nan
            )

        print(
            f"{label:>14} "
            + " ".join(f"{v:15.6f}" for v in vals)
        )

    print()
    print("Adjacent normalized-profile similarity")
    print("-" * 144)
    for r in profile_corrs:
        print(
            f"{r['previous_pair']:>18} -> {r['current_pair']:<18}  "
            f"corr={r['profile_correlation']:.6f}  "
            f"L1 distance={r['normalized_profile_l1_distance']:.6f}"
        )

    print()
    print("=" * 144)
    print(f"shell reconstruction identity pass : {identity_ok}")
    print(f"actual defect contracts             : {actual_contracts}")
    print(f"outer y-tail contracts              : {outer_contracts}")
    print(f"mean adjacent shell-profile corr    : {mean_corr:.9f}")
    print(f"VERDICT                             : {verdict}")
    print("=" * 144)
    print("NEXT DECISION:")
    print("  Stable y-shell profile + shrinking signed primitive -> formulate the")
    print("  cutoff theorem directly in the dimensionless kernel y=x/M.")
    print("  If cancellation instead migrates strongly between shells, construct")
    print("  the next audit around cumulative signed shell primitives rather than")
    print("  any absolute envelope.")


if __name__ == "__main__":
    main()
