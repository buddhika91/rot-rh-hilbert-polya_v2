#!/usr/bin/env python3
"""
ROT-RH v141 — ROOT-LOCAL PHASE / TRANSVERSALITY AUDIT

ZERO-COST postprocessor. No new phase builds, no root solving, no prime sums,
no Xi, no zeta, no known-zero data.

Why v141
--------
v140 showed that raw global compact-uniform phase convergence on E in [0,120]
is NOT supported:
    ||F_512 - F_256||_inf > ||F_256 - F_128||_inf.

But global positivity of F' is not required for fixed-root convergence.
For a tracked crossing, only local transversality and local control of the
secular defect are relevant.

This script combines:
  * v140 sampled F/F' data,
  * v132 roots at L=128000,
  * v137 roots at L=256000,
  * v138 roots at L=512000,

and asks:

  1. Where does the global phase sup discrepancy occur?
  2. Is it concentrated away from the first 32 tracked crossings?
  3. Is F'_L nonzero / positive at those crossings?
  4. Does the phase discrepancy inside root-centered cells contract?
  5. Does the root displacement itself contract relative to local derivative scale?

Important
---------
Because v140's E grid is sparse, F and F' at exact roots are obtained by
linear interpolation from the saved samples.  This is a localization audit,
not a proof and not a high-precision derivative certification.

Outputs
-------
<prefix>_ROOTS.csv
<prefix>_PAIRS.csv
<prefix>_SUP_LOCATIONS.csv
<prefix>_SUMMARY.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None


def write_csv(path, rows):
    path = Path(path)
    if pd is not None:
        pd.DataFrame(rows).to_csv(path, index=False)
        return
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def interp(x, xp, fp):
    return float(np.interp(float(x), xp, fp))


def load_endpoint(path):
    z = np.load(path)
    L = int(np.asarray(z["L_new"]).reshape(-1)[0])
    roots = np.asarray(z["roots_new"], float)
    return L, roots


def local_p(prev, new):
    if prev <= 0 or new <= 0:
        return np.nan
    return float(-math.log(new / prev, 2.0))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--samples-npz",
        default="rot_rh_compact_uniform_phase_v140_SAMPLES.npz",
    )
    ap.add_argument(
        "--base-roots-npz",
        default="rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz",
    )
    ap.add_argument(
        "--endpoint-256",
        default="rot_rh_low_mode_endpoint_v137_ENDPOINT.npz",
    )
    ap.add_argument(
        "--endpoint-512",
        default="rot_rh_low_mode_endpoint_v138_ENDPOINT.npz",
    )
    ap.add_argument("--modes", type=int, default=32)
    ap.add_argument("--cell-fraction", type=float, default=0.40)
    ap.add_argument("--root-near-radius", type=float, default=0.35)
    ap.add_argument("--local-Fprime-gate", type=float, default=0.10)
    ap.add_argument("--local-phase-contraction-gate", type=float, default=0.95)
    ap.add_argument(
        "--prefix",
        default="rot_rh_root_local_phase_v141",
    )
    args = ap.parse_args()

    s = np.load(args.samples_npz)
    Ls = np.asarray(s["L"], int)
    Egrid = np.asarray(s["E"], float)
    Fmat = np.asarray(s["F"], float)
    Fpmat = np.asarray(s["Fprime"], float)

    wanted = [128000, 256000, 512000]
    idx = {}
    for L in wanted:
        hit = np.where(Ls == L)[0]
        if not len(hit):
            raise RuntimeError(f"Missing L={L} in v140 samples.")
        idx[L] = int(hit[0])

    # Roots at 128k
    z = np.load(args.base_roots_npz)
    Lbase = np.asarray(z["L"], int)
    Rbase = np.asarray(z["roots"], float)
    h = np.where(Lbase == 128000)[0]
    if not len(h):
        raise RuntimeError("Missing L=128000 roots in base NPZ.")
    r128 = Rbase[int(h[0])]

    L256, r256 = load_endpoint(args.endpoint_256)
    L512, r512 = load_endpoint(args.endpoint_512)
    if L256 != 256000 or L512 != 512000:
        raise RuntimeError("Endpoint files do not contain expected 256k/512k cutoffs.")

    n = min(args.modes, len(r128), len(r256), len(r512))
    roots = {
        128000: r128[:n],
        256000: r256[:n],
        512000: r512[:n],
    }

    F = {L: Fmat[idx[L]] for L in wanted}
    Fp = {L: Fpmat[idx[L]] for L in wanted}

    pairs = [(128000, 256000), (256000, 512000)]

    print("=" * 124)
    print("ROT-RH v141 — ROOT-LOCAL PHASE / TRANSVERSALITY AUDIT")
    print("=" * 124)
    print("Xi / zeta / known zeros          : NONE")
    print(f"sample grid points                : {len(Egrid)}")
    print(f"tracked modes                     : 1..{n}")
    print(f"cell fraction                     : {args.cell_fraction}")
    print("=" * 124)

    # Global sup locations
    sup_rows = []
    for a, b in pairs:
        dF = F[b] - F[a]
        dFp = Fp[b] - Fp[a]
        i = int(np.argmax(np.abs(dF)))
        j = int(np.argmax(np.abs(dFp)))
        Esup = float(Egrid[i])
        nearest_root_dist = float(np.min(np.abs(roots[b] - Esup)))
        nearest_k = int(np.argmin(np.abs(roots[b] - Esup))) + 1
        sup_rows.append(dict(
            L_a=a, L_b=b,
            sup_abs_delta_F=float(abs(dF[i])),
            E_at_sup_delta_F=Esup,
            nearest_tracked_root_k=nearest_k,
            distance_to_nearest_tracked_root=nearest_root_dist,
            sup_is_near_tracked_root=int(nearest_root_dist <= args.root_near_radius),
            sup_abs_delta_Fprime=float(abs(dFp[j])),
            E_at_sup_delta_Fprime=float(Egrid[j]),
        ))
    write_csv(args.prefix + "_SUP_LOCATIONS.csv", sup_rows)

    root_rows = []
    pair_rows = []

    # Build root-centered local cells from each pair's later roots.
    pair_cell_sums = []
    pair_root_shift_sums = []

    for a, b in pairs:
        dFgrid = F[b] - F[a]
        dFpgrid = Fp[b] - Fp[a]

        local_sup_sum = 0.0
        root_shift_sum = 0.0
        local_transverse = 0

        for k in range(n):
            rb = float(roots[b][k])
            ra = float(roots[a][k])

            # Cell width from neighboring roots at later cutoff.
            if k == 0:
                gap = float(roots[b][1] - roots[b][0])
            elif k == n - 1:
                gap = float(roots[b][-1] - roots[b][-2])
            else:
                gap = float(min(
                    roots[b][k] - roots[b][k-1],
                    roots[b][k+1] - roots[b][k]
                ))

            halfw = args.cell_fraction * gap
            lo, hi = rb - halfw, rb + halfw
            m = (Egrid >= lo) & (Egrid <= hi)

            if np.any(m):
                cell_sup_dF = float(np.max(np.abs(dFgrid[m])))
                cell_sup_dFp = float(np.max(np.abs(dFpgrid[m])))
                cell_min_abs_Fpb = float(np.min(np.abs(Fp[b][m])))
            else:
                cell_sup_dF = abs(interp(rb, Egrid, dFgrid))
                cell_sup_dFp = abs(interp(rb, Egrid, dFpgrid))
                cell_min_abs_Fpb = abs(interp(rb, Egrid, Fp[b]))

            Fpa_root = interp(ra, Egrid, Fp[a])
            Fpb_root = interp(rb, Egrid, Fp[b])
            dF_at_rb = interp(rb, Egrid, dFgrid)
            dF_at_ra = interp(ra, Egrid, dFgrid)

            shift = abs(rb - ra)
            local_bound = (
                cell_sup_dF / cell_min_abs_Fpb
                if cell_min_abs_Fpb > 0 else np.inf
            )

            transverse = (
                abs(Fpa_root) > args.local_Fprime_gate
                and abs(Fpb_root) > args.local_Fprime_gate
            )
            local_transverse += int(transverse)
            local_sup_sum += cell_sup_dF
            root_shift_sum += shift

            root_rows.append(dict(
                L_a=a,
                L_b=b,
                k=k+1,
                E_a=ra,
                E_b=rb,
                abs_root_shift=shift,
                Fprime_a_at_root_interp=Fpa_root,
                Fprime_b_at_root_interp=Fpb_root,
                local_transversality=int(transverse),
                delta_F_at_Ea_interp=dF_at_ra,
                delta_F_at_Eb_interp=dF_at_rb,
                cell_lo=lo,
                cell_hi=hi,
                cell_points=int(np.sum(m)),
                cell_sup_abs_delta_F=cell_sup_dF,
                cell_sup_abs_delta_Fprime=cell_sup_dFp,
                cell_min_abs_Fprime_b=cell_min_abs_Fpb,
                mean_value_root_shift_bound=local_bound,
                shift_over_bound=(
                    shift/local_bound
                    if np.isfinite(local_bound) and local_bound > 0 else np.nan
                ),
            ))

        pair_cell_sums.append(local_sup_sum)
        pair_root_shift_sums.append(root_shift_sum)

        pair_rows.append(dict(
            L_a=a,
            L_b=b,
            tracked_modes=n,
            sum_cell_sup_abs_delta_F=local_sup_sum,
            sum_abs_root_shift=root_shift_sum,
            locally_transverse_modes=local_transverse,
            locally_transverse_fraction=local_transverse/n,
        ))

    # Contraction ratios
    if len(pair_rows) == 2:
        cell_ratio = pair_cell_sums[1] / pair_cell_sums[0] if pair_cell_sums[0] > 0 else np.nan
        shift_ratio = pair_root_shift_sums[1] / pair_root_shift_sums[0] if pair_root_shift_sums[0] > 0 else np.nan
        pair_rows[0]["cell_phase_contraction_ratio"] = np.nan
        pair_rows[0]["root_shift_contraction_ratio"] = np.nan
        pair_rows[1]["cell_phase_contraction_ratio"] = cell_ratio
        pair_rows[1]["root_shift_contraction_ratio"] = shift_ratio
    else:
        cell_ratio = np.nan
        shift_ratio = np.nan

    write_csv(args.prefix + "_ROOTS.csv", root_rows)
    write_csv(args.prefix + "_PAIRS.csv", pair_rows)

    latest_rows = [r for r in root_rows if r["L_a"] == 256000 and r["L_b"] == 512000]
    frac_latest_transverse = float(np.mean([r["local_transversality"] for r in latest_rows]))
    frac_cell_phase_contract = np.nan

    # Compare each mode's cell sup between pair 1 and pair 2.
    mode_contract_flags = []
    per_mode_ratios = []
    for k in range(1, n+1):
        r1 = next(r for r in root_rows if r["L_a"] == 128000 and r["k"] == k)
        r2 = next(r for r in root_rows if r["L_a"] == 256000 and r["k"] == k)
        ratio = (
            r2["cell_sup_abs_delta_F"] / r1["cell_sup_abs_delta_F"]
            if r1["cell_sup_abs_delta_F"] > 0 else np.nan
        )
        per_mode_ratios.append(ratio)
        mode_contract_flags.append(
            np.isfinite(ratio) and ratio < args.local_phase_contraction_gate
        )

    frac_cell_phase_contract = float(np.mean(mode_contract_flags))

    global_sup_near = [bool(r["sup_is_near_tracked_root"]) for r in sup_rows]
    global_sup_away_from_roots = not any(global_sup_near)

    if (
        frac_latest_transverse >= 0.95
        and frac_cell_phase_contract >= 0.75
        and np.isfinite(shift_ratio)
        and shift_ratio < 1.0
    ):
        verdict = "ROOT_LOCAL_CONVERGENCE_EVIDENCE_STRONG"
    elif frac_latest_transverse >= 0.95 and shift_ratio < 1.0:
        verdict = "ROOT_SHIFTS_CONTRACT_LOCAL_PHASE_MIXED"
    else:
        verdict = "ROOT_LOCAL_CONVERGENCE_UNRESOLVED"

    summary = dict(
        version=141,
        firewall=dict(xi_used=False, zeta_used=False, known_zeros_used=False),
        global_v140_result="RAW_GLOBAL_COMPACT_UNIFORM_PHASE_CONVERGENCE_NOT_SUPPORTED",
        tracked_modes=n,
        global_sup_away_from_tracked_roots=global_sup_away_from_roots,
        latest_root_shift_contraction_ratio=shift_ratio,
        aggregate_root_cell_phase_contraction_ratio=cell_ratio,
        fraction_modes_with_contracting_root_cell_phase=frac_cell_phase_contract,
        latest_local_transversality_fraction=frac_latest_transverse,
        median_per_mode_cell_phase_ratio=float(np.nanmedian(per_mode_ratios)),
        verdict=verdict,
        interpretation=(
            "This audit asks whether v140's global phase obstruction is relevant "
            "to the actual tracked crossings. Global F' positivity is not required; "
            "only local nonvanishing derivative near each crossing is relevant."
        ),
        caveat=(
            "Exact-root F/F' values are interpolated from the v140 sampled grid. "
            "If this audit is favorable, the next numerical check should evaluate "
            "F and F' directly at the roots with small local probes."
        ),
    )
    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print()
    print("Global v140 sup locations")
    print("-" * 124)
    for r in sup_rows:
        print(
            f"{r['L_a']:>6d}->{r['L_b']:<6d} "
            f"sup|dF|={r['sup_abs_delta_F']:.6e} at E={r['E_at_sup_delta_F']:.6f} "
            f"nearest k={r['nearest_tracked_root_k']:2d}, "
            f"distance={r['distance_to_nearest_tracked_root']:.4f}"
        )

    print()
    print("Root-local pair summaries")
    print("-" * 124)
    for r in pair_rows:
        print(
            f"{r['L_a']:>6d}->{r['L_b']:<6d} "
            f"sum cell sup|dF|={r['sum_cell_sup_abs_delta_F']:.6e}  "
            f"sum |dE|={r['sum_abs_root_shift']:.6e}  "
            f"local transverse={100*r['locally_transverse_fraction']:.1f}%  "
            f"cell ratio={r.get('cell_phase_contraction_ratio', np.nan):.6f}  "
            f"shift ratio={r.get('root_shift_contraction_ratio', np.nan):.6f}"
        )

    print()
    print("=" * 124)
    print(f"aggregate root-cell phase ratio       : {cell_ratio:.9f}")
    print(f"aggregate root-shift ratio            : {shift_ratio:.9f}")
    print(f"median per-mode cell phase ratio      : {np.nanmedian(per_mode_ratios):.9f}")
    print(f"fraction modes cell phase contracts   : {frac_cell_phase_contract:.3f}")
    print(f"latest local transversality fraction  : {frac_latest_transverse:.3f}")
    print(f"global sup away from tracked roots    : {global_sup_away_from_roots}")
    print(f"VERDICT                               : {verdict}")
    print("=" * 124)


if __name__ == "__main__":
    main()
