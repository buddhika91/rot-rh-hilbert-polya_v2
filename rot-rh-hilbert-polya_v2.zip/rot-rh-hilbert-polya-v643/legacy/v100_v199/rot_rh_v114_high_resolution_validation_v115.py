#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v114 — Preregistered Blind Deep Staircase Cancellation Audit
====================================================================

WHY THIS TEST
-------------
v113 found strong multi-cell cancellation on the already-studied calibration
window k=48..127:
  * cumulative excursion far below permutations;
  * strongly suppressed low-frequency power.

But that was exploratory. v114 freezes the metrics and tests NEW, deeper cells.

DEFAULT DESIGN
--------------
Calibration:
    k = 48..127          (80 cells; already seen)

Blind windows:
    W1 = 128..207        (80 NEW cells)
    W2 = 208..287
    W3 = 288..367
    W4 = 368..447

A support depth of 448 supplies the right endpoint for cell k=447.

Preregistered metrics for every blind window:
  1. cumulative-max lower-tail percentile under permutations of the SAME q_k;
  2. low-frequency-power lower-tail percentile under those permutations.

Combined blind test:
    concatenate k=128..447 (320 cells) and repeat both permutation tests.

PASS gates (frozen in code before blind roots are inspected):
  * at least 3/4 blind windows have cumulative percentile <= 5%;
  * at least 3/4 blind windows have low-frequency percentile <= 5%;
  * combined 320-cell cumulative percentile <= 1%;
  * combined 320-cell low-frequency percentile <= 1%.

Additional diagnostics (not pass gates):
  * cumulative max at prefix lengths 80,160,240,320,400;
  * multi-scale growth exponent from those prefix maxima;
  * dyadic block-sum suppression;
  * half-cell band max |F-N|.

NO Xi evaluations.
NO zeta evaluations.
NO known zero ordinates.

The script writes a PREFREEZE manifest containing the code SHA, test windows,
metrics, and gates BEFORE it builds the deep spectrum.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import os
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss

VERSION = "v115"
BUILD = "2026-08-17-v114-high-resolution-technical-validation-v115"
EPS = 1e-30


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def nodes(lo, hi, q):
    x, w = leggauss(int(q))
    E = 0.5 * (hi - lo) * (x + 1.0) + lo
    W = 0.5 * (hi - lo) * w
    return E, W


def cell_area(phase, lo, hi, k, q):
    E, W = nodes(float(lo), float(hi), int(q))
    F = np.asarray(phase.F(E), float)
    Q = F - float(k)
    return {
        "Q_area": float(np.sum(W * Q)),
        "abs_Q_area": float(np.sum(W * np.abs(Q))),
        "max_abs_Q": float(np.max(np.abs(Q))),
        "min_Q": float(np.min(Q)),
        "max_Q": float(np.max(Q)),
        "width": float(hi - lo),
    }


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c) - np.min(c))


def lowfreq_fraction(x, bins=4):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z) ** 2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p) - 1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def permutation_metrics(x, nperm, rng, lowfreq_bins):
    x = np.asarray(x, float)
    real_c = cumulative_max(x)
    real_r = cumulative_range(x)
    real_l = lowfreq_fraction(x, lowfreq_bins)

    pc = np.empty(int(nperm), float)
    pr = np.empty(int(nperm), float)
    pl = np.empty(int(nperm), float)
    for t in range(int(nperm)):
        y = rng.permutation(x)
        pc[t] = cumulative_max(y)
        pr[t] = cumulative_range(y)
        pl[t] = lowfreq_fraction(y, lowfreq_bins)

    return {
        "cell_count": len(x),
        "mean_area": float(np.mean(x)),
        "mean_abs_area": float(np.mean(np.abs(x))),
        "rms_area": float(np.sqrt(np.mean(x*x))),
        "max_abs_area": float(np.max(np.abs(x))),
        "sum_area": float(np.sum(x)),
        "real_cumulative_max": real_c,
        "real_cumulative_range": real_r,
        "real_lowfreq_fraction": real_l,
        "perm_cumulative_max_mean": float(np.mean(pc)),
        "perm_cumulative_max_median": float(np.median(pc)),
        "perm_cumulative_max_p05": float(np.quantile(pc, 0.05)),
        "perm_cumulative_max_p95": float(np.quantile(pc, 0.95)),
        "cumulative_lower_tail_percentile": percentile_le(pc, real_c),
        "perm_cumulative_range_mean": float(np.mean(pr)),
        "range_lower_tail_percentile": percentile_le(pr, real_r),
        "perm_lowfreq_mean": float(np.mean(pl)),
        "perm_lowfreq_p05": float(np.quantile(pl, 0.05)),
        "perm_lowfreq_p95": float(np.quantile(pl, 0.95)),
        "lowfreq_lower_tail_percentile": percentile_le(pl, real_l),
    }


def dyadic_block_rms(x, block):
    x = np.asarray(x, float)
    b = int(block)
    n = len(x) // b
    if n < 1:
        return float("nan")
    y = x[:n*b].reshape(n, b).sum(axis=1)
    return float(np.sqrt(np.mean(y*y)))


def multiscale_growth(prefix_lengths, prefix_cmax):
    n = np.asarray(prefix_lengths, float)
    y = np.asarray(prefix_cmax, float)
    mask = (n > 0) & (y > 0)
    if np.sum(mask) < 3:
        return float("nan")
    X = np.column_stack([np.ones(np.sum(mask)), np.log(n[mask])])
    beta, *_ = np.linalg.lstsq(X, np.log(y[mask]), rcond=None)
    return float(beta[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L", type=int, default=16000)
    ap.add_argument("--max-depth", type=int, default=448)
    ap.add_argument("--calibration-start", type=int, default=48)
    ap.add_argument("--window-size", type=int, default=80)
    ap.add_argument("--blind-windows", type=int, default=4)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=1536)
    ap.add_argument("--counter-qcheck", type=int, default=3072)
    ap.add_argument("--scan-points", type=int, default=96)
    ap.add_argument("--cell-q", type=int, default=64)
    ap.add_argument("--cell-qcheck", type=int, default=128)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--lowfreq-bins", type=int, default=4)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument(
        "--baseline-v114-prefix",
        default="rot_rh_blind_deep_staircase_cancellation_v114",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_v114_high_resolution_validation_v115",
    )
    args = ap.parse_args()

    cal0 = int(args.calibration_start)
    w = int(args.window_size)
    cal1 = cal0 + w - 1
    blind = []
    start = cal1 + 1
    for j in range(int(args.blind_windows)):
        blind.append((start + j*w, start + (j+1)*w - 1))

    required_depth = blind[-1][1] + 1
    if args.max_depth < required_depth:
        raise ValueError(
            f"max-depth={args.max_depth} is too small; need >= {required_depth}"
        )

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    # Freeze design BEFORE deep support is built.
    try:
        code_path = Path(__file__).resolve()
        code_sha = sha256_file(code_path)
    except Exception:
        code_path = None
        code_sha = None

    prereg = {
        "version": VERSION,
        "build": BUILD,
        "scientific_preregistration": False,
        "purpose": (
            "Technical high-resolution validation of the already-seen v114 "
            "window statistics. This run must not be used to retroactively "
            "change the v114 preregistered verdict."
        ),
        "code_path": str(code_path) if code_path else None,
        "code_sha256": code_sha,
        "L": int(args.L),
        "calibration_window": [cal0, cal1],
        "blind_windows": [list(x) for x in blind],
        "combined_blind_window": [blind[0][0], blind[-1][1]],
        "counter_q": int(args.counter_q),
        "counter_qcheck": int(args.counter_qcheck),
        "baseline_v114_prefix": args.baseline_v114_prefix,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
    }
    prereg_path = Path(str(prefix) + "_TECHNICAL_MANIFEST.json")
    prereg_path.write_text(json.dumps(prereg, indent=2), encoding="utf-8")
    prereg_sha = sha256_file(prereg_path)

    print("=" * 158)
    print("ROT-RH v115 — HIGH-RESOLUTION TECHNICAL VALIDATION OF v114")
    print("=" * 158)
    print("TECHNICAL MANIFEST SHA          :", prereg_sha)
    print("L                               :", args.L)
    print("max depth                       :", args.max_depth)
    print("calibration window              :", (cal0, cal1))
    print("blind windows                   :", blind)
    print("permutations/window             :", args.permutations)
    print("low-frequency bins              :", args.lowfreq_bins)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("=" * 158)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    print("[1] Build frozen zero-free phase and blind deep support", flush=True)
    phase = v102.RenormalizedPhase.build(
        base, int(args.L), float(args.tail_factor), int(args.counter_q)
    )
    support = v102.ordered_support(
        phase,
        depth=int(args.max_depth),
        scan_points=int(args.scan_points),
        qcheck=int(args.counter_qcheck),
    )
    roots = np.asarray(support.roots, float)
    print(
        f"  roots=[{roots[0]:.6f},{roots[-1]:.6f}] "
        f"maxres={np.max(support.residuals):.3e} "
        f"qphase={support.quadrature_phase_rel_l2:.3e} "
        f"qder={support.quadrature_deriv_rel_l2:.3e}"
    )

    all_start = cal0
    all_end = blind[-1][1]
    cell_rows = []

    print("[2] Compute calibration + previously unseen cell areas", flush=True)
    for k in range(all_start, all_end + 1):
        lo = float(roots[k - 1])
        hi = float(roots[k])
        r = cell_area(phase, lo, hi, k, args.cell_q)
        rc = cell_area(phase, lo, hi, k, args.cell_qcheck)

        row = {
            "L": args.L,
            "cell_k": k,
            "lo": lo,
            "hi": hi,
            "Q_area": rc["Q_area"],
            "Q_area_qcheck_absdiff": abs(r["Q_area"] - rc["Q_area"]),
            "abs_Q_area": rc["abs_Q_area"],
            "max_abs_Q": rc["max_abs_Q"],
            "min_Q": rc["min_Q"],
            "max_Q": rc["max_Q"],
            "width": rc["width"],
        }
        cell_rows.append(row)

        if (k - all_start + 1) % 80 == 0:
            print(
                f"  through k={k}: max|Q|="
                f"{max(x['max_abs_Q'] for x in cell_rows[-80:]):.6f} "
                f"max qdiff="
                f"{max(x['Q_area_qcheck_absdiff'] for x in cell_rows[-80:]):.2e}"
            )

    mp = {int(r["cell_k"]): r for r in cell_rows}

    def seq(a, b):
        return np.asarray([float(mp[k]["Q_area"]) for k in range(a, b+1)])

    rng = np.random.default_rng(args.seed)

    print("[3] Preregistered calibration and blind permutation tests", flush=True)
    window_rows = []

    cal_metrics = permutation_metrics(
        seq(cal0, cal1), args.permutations, rng, args.lowfreq_bins
    )
    cal_row = {
        "kind": "calibration",
        "window_index": 0,
        "k_start": cal0,
        "k_end": cal1,
        **cal_metrics,
    }
    window_rows.append(cal_row)
    print(
        f"  CAL {cal0}-{cal1}: "
        f"cumPct={100*cal_metrics['cumulative_lower_tail_percentile']:.3f}% "
        f"lowFPct={100*cal_metrics['lowfreq_lower_tail_percentile']:.3f}% "
        f"cumMax={cal_metrics['real_cumulative_max']:.3e}"
    )

    blind_rows = []
    for j, (a, b) in enumerate(blind, start=1):
        met = permutation_metrics(
            seq(a, b), args.permutations, rng, args.lowfreq_bins
        )
        row = {
            "kind": "blind",
            "window_index": j,
            "k_start": a,
            "k_end": b,
            **met,
        }
        blind_rows.append(row)
        window_rows.append(row)
        print(
            f"  BLIND{j} {a}-{b}: "
            f"cumPct={100*met['cumulative_lower_tail_percentile']:.3f}% "
            f"lowFPct={100*met['lowfreq_lower_tail_percentile']:.3f}% "
            f"cumMax={met['real_cumulative_max']:.3e}"
        )

    cb0, cb1 = blind[0][0], blind[-1][1]
    combined_metrics = permutation_metrics(
        seq(cb0, cb1), args.permutations, rng, args.lowfreq_bins
    )
    combined_row = {
        "kind": "combined_blind",
        "window_index": 999,
        "k_start": cb0,
        "k_end": cb1,
        **combined_metrics,
    }
    window_rows.append(combined_row)
    print(
        f"  COMBINED BLIND {cb0}-{cb1}: "
        f"cumPct={100*combined_metrics['cumulative_lower_tail_percentile']:.4f}% "
        f"lowFPct={100*combined_metrics['lowfreq_lower_tail_percentile']:.4f}% "
        f"cumMax={combined_metrics['real_cumulative_max']:.3e}"
    )

    print("[4] Non-gated multiscale diagnostics", flush=True)
    full = seq(cal0, cb1)
    prefix_rows = []
    prefix_lengths = []
    prefix_cmax = []
    for n in range(w, len(full) + 1, w):
        x = full[:n]
        cm = cumulative_max(x)
        prefix_lengths.append(n)
        prefix_cmax.append(cm)
        prefix_rows.append({
            "cells_from_k": cal0,
            "prefix_cell_count": n,
            "k_end": cal0 + n - 1,
            "cumulative_max": cm,
            "cumulative_range": cumulative_range(x),
            "lowfreq_fraction": lowfreq_fraction(x, args.lowfreq_bins),
        })
        print(
            f"  prefix n={n:<3d} k_end={cal0+n-1}: "
            f"cumMax={cm:.3e}"
        )

    alpha = multiscale_growth(prefix_lengths, prefix_cmax)
    print("  multi-window growth alpha      :", f"{alpha:+.6f}")

    block_rows = []
    blind_concat = seq(cb0, cb1)
    for b in [1, 2, 4, 8, 16, 32, 64, 80]:
        if b > len(blind_concat):
            continue
        real = dyadic_block_rms(blind_concat, b)
        ctrl = np.empty(args.permutations, float)
        for t in range(args.permutations):
            ctrl[t] = dyadic_block_rms(
                rng.permutation(blind_concat), b
            )
        block_rows.append({
            "block_size": b,
            "real_block_sum_rms": real,
            "perm_mean": float(np.mean(ctrl)),
            "perm_p05": float(np.quantile(ctrl, 0.05)),
            "perm_p95": float(np.quantile(ctrl, 0.95)),
            "lower_tail_percentile": percentile_le(ctrl, real),
            "suppression_ratio": real / max(float(np.mean(ctrl)), EPS),
        })

    # Compare the high-resolution cell sequence against the original v114.
    baseline_cells_path = Path(
        str(Path(args.baseline_v114_prefix).expanduser().resolve()) + "_CELLS.csv"
    )
    baseline_comparison = {
        "available": False,
        "cell_area_relative_l2": None,
        "cell_area_max_abs_difference": None,
        "cell_area_correlation": None,
        "root_boundary_max_abs_shift_proxy": None,
    }
    if baseline_cells_path.exists():
        with open(baseline_cells_path, newline="", encoding="utf-8") as f:
            old_rows = list(csv.DictReader(f))
        old_map = {
            int(float(r["cell_k"])): r
            for r in old_rows
            if all_start <= int(float(r["cell_k"])) <= all_end
        }
        common = [r for r in cell_rows if int(r["cell_k"]) in old_map]
        if common:
            old_q = np.asarray(
                [float(old_map[int(r["cell_k"])]["Q_area"]) for r in common],
                float,
            )
            new_q = np.asarray([float(r["Q_area"]) for r in common], float)
            old_hi = np.asarray(
                [float(old_map[int(r["cell_k"])]["hi"]) for r in common],
                float,
            )
            new_hi = np.asarray([float(r["hi"]) for r in common], float)
            baseline_comparison = {
                "available": True,
                "cell_count": len(common),
                "cell_area_relative_l2": float(
                    np.linalg.norm(new_q-old_q) /
                    max(np.linalg.norm(new_q), EPS)
                ),
                "cell_area_max_abs_difference": float(
                    np.max(np.abs(new_q-old_q))
                ),
                "cell_area_correlation": float(
                    np.corrcoef(old_q, new_q)[0, 1]
                ),
                "root_boundary_max_abs_shift_proxy": float(
                    np.max(np.abs(new_hi-old_hi))
                ),
            }
            print("[5] Original-v114 vs high-resolution sequence")
            print(
                "  cell-area relL2 drift            :",
                f"{baseline_comparison['cell_area_relative_l2']:.3e}"
            )
            print(
                "  cell-area correlation            :",
                f"{baseline_comparison['cell_area_correlation']:.12f}"
            )
            print(
                "  max cell-area abs difference     :",
                f"{baseline_comparison['cell_area_max_abs_difference']:.3e}"
            )
            print(
                "  max root-boundary shift proxy    :",
                f"{baseline_comparison['root_boundary_max_abs_shift_proxy']:.3e}"
            )

    cum_pass_count = sum(
        r["cumulative_lower_tail_percentile"] <= 0.05 for r in blind_rows
    )
    lowf_pass_count = sum(
        r["lowfreq_lower_tail_percentile"] <= 0.05 for r in blind_rows
    )

    gates = {
        "deep_root_residual_below_1e8":
            bool(float(np.max(support.residuals)) < 1e-8),
        "counterterm_quadrature_stable":
            bool(
                support.quadrature_phase_rel_l2 < 5e-6
                and support.quadrature_deriv_rel_l2 < 5e-6
            ),
        "cell_quadrature_stable":
            bool(
                max(r["Q_area_qcheck_absdiff"] for r in cell_rows) < 1e-8
            ),
        "at_least_3_of_4_blind_cumulative_p_le_0p05":
            bool(cum_pass_count >= 3),
        "at_least_3_of_4_blind_lowfreq_p_le_0p05":
            bool(lowf_pass_count >= 3),
        "combined_blind_cumulative_p_le_0p01":
            bool(combined_metrics["cumulative_lower_tail_percentile"] <= 0.01),
        "combined_blind_lowfreq_p_le_0p01":
            bool(combined_metrics["lowfreq_lower_tail_percentile"] <= 0.01),
    }

    core_gates = [
        "at_least_3_of_4_blind_cumulative_p_le_0p05",
        "at_least_3_of_4_blind_lowfreq_p_le_0p05",
        "combined_blind_cumulative_p_le_0p01",
        "combined_blind_lowfreq_p_le_0p01",
    ]
    numerical_gates = [
        "deep_root_residual_below_1e8",
        "counterterm_quadrature_stable",
        "cell_quadrature_stable",
    ]

    baseline_stable = (
        baseline_comparison["available"]
        and baseline_comparison["cell_area_relative_l2"] is not None
        and baseline_comparison["cell_area_relative_l2"] < 0.05
        and baseline_comparison["cell_area_correlation"] > 0.99
    )

    if all(gates[k] for k in numerical_gates) and baseline_stable:
        verdict = (
            "PASS_V115_HIGH_RESOLUTION_VALIDATES_V114_STATISTICS__"
            "ORIGINAL_V114_SCIENTIFIC_VERDICT_REMAINS_FAIL"
        )
    elif all(gates[k] for k in numerical_gates):
        verdict = (
            "PARTIAL_V115_HIGH_RESOLUTION_VALID_BUT_V114_CELL_SEQUENCE_SHIFTS"
        )
    else:
        verdict = "FAIL_V115_HIGH_RESOLUTION_NUMERICAL_SUPPORT_STILL_INVALID"

    max_abs_Q = max(r["max_abs_Q"] for r in cell_rows)
    max_qdiff = max(r["Q_area_qcheck_absdiff"] for r in cell_rows)

    write_csv(Path(str(prefix) + "_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix) + "_WINDOWS.csv"), window_rows)
    write_csv(Path(str(prefix) + "_PREFIX_GROWTH.csv"), prefix_rows)
    write_csv(Path(str(prefix) + "_BLOCKS.csv"), block_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "technical_manifest_sha256": prereg_sha,
        "gates": gates,
        "baseline_comparison": baseline_comparison,
        "blind_cumulative_pass_count": cum_pass_count,
        "blind_lowfreq_pass_count": lowf_pass_count,
        "combined_blind": combined_metrics,
        "multiwindow_growth_alpha_not_gated": alpha,
        "max_abs_Q_not_gated": max_abs_Q,
        "max_cell_quadrature_difference": max_qdiff,
        "interpretation": (
            "This is a post-hoc technical resolution validation only. "
            "It tests whether the v114 cell sequence and window statistics "
            "survive a much finer PNT-counterterm quadrature. It cannot "
            "retroactively alter the preregistered v114 scientific verdict."
        ),
    }
    out = Path(str(prefix) + "_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n" + "=" * 158)
    print("FINAL v115 TECHNICAL VERDICT")
    print("=" * 158)
    print("verdict                         :", verdict)
    print("TECHNICAL MANIFEST SHA          :", prereg_sha)
    print("blind cumulative pass count     :", f"{cum_pass_count}/{len(blind_rows)}")
    print("blind lowfreq pass count        :", f"{lowf_pass_count}/{len(blind_rows)}")
    print("combined blind cumulative pct   :",
          f"{100*combined_metrics['cumulative_lower_tail_percentile']:.6f}%")
    print("combined blind lowfreq pct      :",
          f"{100*combined_metrics['lowfreq_lower_tail_percentile']:.6f}%")
    print("multi-window alpha (not gated)  :", f"{alpha:.12e}")
    print("max |F-N| (not gated)           :", f"{max_abs_Q:.12e}")
    print("max cell q-check difference     :", f"{max_qdiff:.12e}")
    print("baseline comparison             :", baseline_comparison)
    print("gates                           :", gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", out)
    print("=" * 158)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
