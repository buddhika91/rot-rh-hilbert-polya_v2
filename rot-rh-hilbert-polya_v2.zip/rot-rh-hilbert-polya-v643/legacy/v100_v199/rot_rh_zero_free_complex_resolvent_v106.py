#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v106 — Zero-Free Complex Resolvent Open-Set Audit
=========================================================

Strengthens v105.

v105 evaluated
    R(a)=sum_k 1/(E_k^2+a^2)
from a global moment series, so small real a probes were dominated by S1.

v106 instead evaluates:
    * the first N spectral levels EXACTLY in the resolvent;
    * only the omitted high-energy tail via frozen inverse moments.

Thus large/complex a values substantially reweight the low spectrum and provide
a much more independent test of the resolvent as an analytic function.

For complex a with Re(a)>1/2,

  sigma = 1/2 + a

lies in Re(sigma)>1, where

  -zeta'/zeta(sigma) = sum Lambda(n)n^-sigma

is absolutely convergent.

The zero-free arithmetic target is

  R_arith(a)
    = 1/(a^2-1/4)
      + [psi((1/2+a)/2)-log(pi)]/(4a)
      - [1/(2a)] sum Lambda(n)n^(-(1/2+a)).

NO Xi, zeta function calls, or known zeros are used.

Frozen operator evaluation:
  R_op(a)
    = sum_{k<=N} 1/(E_k^2+a^2)
      + sum_{r=0}^{M-1} (-a^2)^r T_{r+1},

where T_m is the frozen full_em1 tail moment:
  T_m = S_m^completed - sum_{k<=N}E_k^(-2m).

For |a|<E_N, the omitted tail-series geometric estimate is tiny even when
|a| is comparable to E_1, because only the HIGH-ENERGY tail is expanded.

This directly audits the analytic resolvent identity on a 2D complex-a grid.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import digamma

EPS=1e-15
VERSION="v106"
BUILD="2026-08-17-zero-free-complex-resolvent-open-set-v106"


def parse_ints(s):
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()


def write_csv(path,rows):
    if not rows:
        Path(path).write_text("",encoding="utf-8"); return
    fields=list(rows[0].keys())
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def partial_moments(roots,order):
    r=np.asarray(roots,float)
    return np.asarray(
        [float(np.sum(r**(-2*m))) for m in range(1,order+1)],float
    )


def operator_resolvent_prefix_tail(roots,completed_moments,a,order):
    """
    Exact finite-prefix resolvent plus frozen tail moment series.

    The tail expansion parameter is |a|^2/E_N^2, not |a|^2/E_1^2.
    """
    r=np.asarray(roots,float)
    cm=np.asarray(completed_moments,float)
    M=min(int(order),len(cm))
    pm=partial_moments(r,M)
    tail=cm[:M]-pm

    aa=complex(a)
    prefix=np.sum(1.0/(r*r+aa*aa))

    t=0.0j
    p=1.0+0.0j
    for q in range(M):
        t += p*float(tail[q])
        p *= -(aa*aa)

    EN=float(r[-1])
    ratio=(abs(aa)/EN)**2
    if ratio>=1:
        raise ValueError(f"Need |a|<E_N; |a|={abs(aa)}, E_N={EN}")

    # Conservative tail-series estimate from positive T1 scale.
    rem=abs(float(tail[0]))*(ratio**M)/(1.0-ratio)
    return complex(prefix+t),float(rem),complex(prefix),complex(t)


def dirichlet_tail_bound(N,sigma_real):
    N=float(N); sig=float(sigma_real)
    q=sig-1.0
    integ=N**(1.0-sig)*(math.log(N)/q+1.0/(q*q))
    endpoint=math.log(N+1.0)*(N+1.0)**(-sig)
    return float(integ+endpoint)


def arithmetic_resolvent(a,nums,lam,lognums,nmax):
    a=complex(a)
    sigma=0.5+a
    if sigma.real<=1:
        raise ValueError("Need Re(1/2+a)>1.")

    terms=lam*np.exp(-sigma*lognums)
    dsum=complex(np.sum(terms))

    rational=1.0/(a*a-0.25)
    arch=(digamma(sigma/2.0)-math.log(math.pi))/(4.0*a)
    prime=-dsum/(2.0*a)
    rhs=complex(rational+arch+prime)

    db=dirichlet_tail_bound(nmax,sigma.real)
    rhs_unc=db/(2.0*abs(a))
    return rhs,float(rhs_unc),complex(rational),complex(arch),complex(prime)


def sym_rel(a,b):
    return abs(a-b)/(1.0+abs(a)+abs(b))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--v102-prefix",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument("--L-list",default="4000,8000,16000")
    ap.add_argument("--depth",type=int,default=48)
    ap.add_argument("--method",default="full_em1")
    ap.add_argument("--a-real",default="2,3,5")
    ap.add_argument("--a-imag",default="0,2,5,8,12")
    ap.add_argument("--moment-order",type=int,default=10)
    ap.add_argument("--dirichlet-nmax",type=int,default=2000000)
    ap.add_argument(
        "--prefix",
        default="rot_rh_zero_free_complex_resolvent_v106",
    )
    args=ap.parse_args()

    Ls=parse_ints(args.L_list)
    are=parse_floats(args.a_real)
    aim=parse_floats(args.a_imag)
    aprobes=[complex(x,y) for x in are for y in aim]

    vp=Path(args.v102_prefix).expanduser().resolve()
    archive=Path(str(vp)+"_FROZEN_PRE_XI.npz")
    manifest=Path(str(vp)+"_FROZEN_MANIFEST.json")
    man=json.loads(manifest.read_text(encoding="utf-8"))
    got=sha256_file(archive)
    if got!=man.get("sha256"):
        raise RuntimeError("v102.1 SHA mismatch.")
    data=np.load(archive,allow_pickle=False)

    base=importlib.import_module(args.base_module)

    print("="*152)
    print("ROT-RH v106 — ZERO-FREE COMPLEX RESOLVENT OPEN-SET AUDIT")
    print("="*152)
    print("v102.1 SHA verified             :",True)
    print("L ladder                        :",Ls)
    print("depth                           :",args.depth)
    print("a real parts                    :",are)
    print("a imaginary parts               :",aim)
    print("complex probes                  :",len(aprobes))
    print("moment tail order               :",args.moment_order)
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("="*152)

    print("[1] Absolutely convergent Mangoldt Dirichlet data",flush=True)
    numbers,lambdas,_=base.mangoldt_terms(int(args.dirichlet_nmax))
    nums=numbers.astype(float)
    lam=np.asarray(lambdas,float)
    lognums=np.log(nums)

    targets={}
    for a in aprobes:
        targets[a]=arithmetic_resolvent(
            a,nums,lam,lognums,args.dirichlet_nmax
        )

    print("[2] Exact-prefix + frozen-tail operator resolvent",flush=True)
    rows=[]
    for L in Ls:
        roots=np.asarray(data[f"roots_L{L}_d{args.depth}"],float)
        cm=np.asarray(
            data[f"mom_{args.method}_L{L}_d{args.depth}"],float
        )
        for a in aprobes:
            op,orem,prefix_part,tail_part=operator_resolvent_prefix_tail(
                roots,cm,a,args.moment_order
            )
            rhs,runc,rat,arch,prime=targets[a]
            diff=op-rhs
            row={
                "L":L,
                "a_real":a.real,
                "a_imag":a.imag,
                "a_abs":abs(a),
                "operator_real":op.real,
                "operator_imag":op.imag,
                "arith_real":rhs.real,
                "arith_imag":rhs.imag,
                "difference_abs":abs(diff),
                "relative_difference":
                    abs(diff)/max(abs(rhs),EPS),
                "symmetric_difference":sym_rel(op,rhs),
                "operator_tail_series_bound":orem,
                "dirichlet_RHS_bound":runc,
                "prefix_real":prefix_part.real,
                "prefix_imag":prefix_part.imag,
                "tail_real":tail_part.real,
                "tail_imag":tail_part.imag,
                "rational_real":rat.real,
                "rational_imag":rat.imag,
                "arch_real":arch.real,
                "arch_imag":arch.imag,
                "prime_real":prime.real,
                "prime_imag":prime.imag,
            }
            rows.append(row)

    # Summary by L.
    for L in Ls:
        rr=[r for r in rows if r["L"]==L]
        maxrel=max(r["relative_difference"] for r in rr)
        maxabs=max(r["difference_abs"] for r in rr)
        medrel=float(np.median([r["relative_difference"] for r in rr]))
        print(
            f"  L={L:<6d}: max rel={maxrel:.3e} "
            f"median rel={medrel:.3e} max |d|={maxabs:.3e}"
        )

    # Print selected hard probes.
    print("[3] Selected hard probes at final L",flush=True)
    finalL=Ls[-1]
    final=[r for r in rows if r["L"]==finalL]
    final_sorted=sorted(final,key=lambda r:r["a_abs"],reverse=True)
    for r in final_sorted[:min(8,len(final_sorted))]:
        print(
            f"  a={r['a_real']:+.1f}{r['a_imag']:+.1f}i "
            f"|a|={r['a_abs']:.2f}: "
            f"|d|={r['difference_abs']:.3e} "
            f"rel={r['relative_difference']:.3e} "
            f"tailSeries<={r['operator_tail_series_bound']:.1e} "
            f"DirTail<={r['dirichlet_RHS_bound']:.1e}"
        )

    print("[4] Zero-free complex resolvent L-flow",flush=True)
    flow=[]
    for a in aprobes:
        ar=[r for r in rows if r["a_real"]==a.real and r["a_imag"]==a.imag]
        for r0,r1 in zip(ar[:-1],ar[1:]):
            z0=complex(r0["operator_real"],r0["operator_imag"])
            z1=complex(r1["operator_real"],r1["operator_imag"])
            flow.append({
                "a_real":a.real,
                "a_imag":a.imag,
                "L_from":r0["L"],
                "L_to":r1["L"],
                "absolute_drift":abs(z1-z0),
                "relative_drift":abs(z1-z0)/max(abs(z0),EPS),
            })

    latest=[
        r for r in flow
        if r["L_from"]==Ls[-2] and r["L_to"]==Ls[-1]
    ]
    print(
        "  latest max relative drift       :",
        f"{max(r['relative_drift'] for r in latest):.3e}"
    )
    print(
        "  latest median relative drift    :",
        f"{np.median([r['relative_drift'] for r in latest]):.3e}"
    )

    final_max_rel=max(r["relative_difference"] for r in final)
    final_med_rel=float(np.median([r["relative_difference"] for r in final]))
    final_max_abs=max(r["difference_abs"] for r in final)
    max_tail_bound=max(r["operator_tail_series_bound"] for r in final)
    max_dir_bound=max(r["dirichlet_RHS_bound"] for r in final)

    gates={
        "complex_open_set_final_max_rel_below_1e5":final_max_rel<1e-5,
        "complex_open_set_final_median_rel_below_1e6":final_med_rel<1e-6,
        "tail_series_bound_below_1e8":max_tail_bound<1e-8,
        "dirichlet_tail_bound_below_1e8":max_dir_bound<1e-8,
    }

    verdict=(
        "PASS_V106_ZERO_FREE_COMPLEX_RESOLVENT_OPEN_SET_SUPPORTED"
        if all(gates.values())
        else "PARTIAL_V106_COMPLEX_RESOLVENT_OPEN_SET_NOT_FULLY_CLOSED"
    )

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)
    write_csv(Path(str(prefix)+"_RESOLVENT.csv"),rows)
    write_csv(Path(str(prefix)+"_L_FLOW.csv"),flow)
    Path(str(prefix)+"_VERDICT.json").write_text(
        json.dumps({
            "version":VERSION,
            "build":BUILD,
            "verdict":verdict,
            "RH_proof":False,
            "Xi_used":False,
            "zeta_used":False,
            "known_zeros_used":False,
            "source_v102_sha256":got,
            "gates":gates,
            "final_max_relative_difference":final_max_rel,
            "final_median_relative_difference":final_med_rel,
            "final_max_absolute_difference":final_max_abs,
            "theorem_target":(
                "Prove exact fixed-L resolvents converge locally uniformly "
                "for a on a nonempty open subset of Re(a)>1/2 to the "
                "absolutely convergent arithmetic resolvent. One resolvent "
                "bound yields uniform trace normality; logarithmic-derivative "
                "identity then identifies every normal-family limit with "
                "Xi/Xi(0), and Hurwitz gives RH."
            )
        },indent=2),
        encoding="utf-8"
    )

    print("\n"+"="*152)
    print("FINAL v106 VERDICT")
    print("="*152)
    print("verdict                         :",verdict)
    print("final max relative difference   :",f"{final_max_rel:.12e}")
    print("final median relative difference:",f"{final_med_rel:.12e}")
    print("final max absolute difference   :",f"{final_max_abs:.12e}")
    print("max tail-series bound           :",f"{max_tail_bound:.12e}")
    print("max Dirichlet-tail bound        :",f"{max_dir_bound:.12e}")
    print("gates                           :",gates)
    print("Xi used                         : FALSE")
    print("zeta used                       : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("="*152)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
