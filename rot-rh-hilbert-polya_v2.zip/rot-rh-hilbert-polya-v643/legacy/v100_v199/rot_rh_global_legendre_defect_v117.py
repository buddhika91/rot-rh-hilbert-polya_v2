#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v117 — Global Legendre-Defect Assembly / Theorem-Bound Audit
===================================================================

Consumes only already-computed high-resolution cell CSVs:
  * v115: k=48..447
  * v116: k=448..767

No roots/phases are recomputed.

Exact geometry
--------------
For
    q_k = int_{E_k}^{E_{k+1}} (F_L(E)-k) dE,

define
    Phi_L(E)=int_0^E F_L(u)du,
    B_k = Phi_L(E_k)-k E_k + sum_{j=1}^k E_j.

Then exactly
    q_k = B_{k+1}-B_k.

Therefore the cumulative cell-area sequence is the increment of a
Legendre-like defect B_k.

v117 assembles a contiguous 720-cell sequence k=48..767 and computes:
  * boundary defect excursion max |B_k-B_48|;
  * defect range;
  * prefix growth at 80-cell increments;
  * post-hoc permutation controls for the full 720-cell ordering;
  * a conservative continuous-primitive bound

        C_A <= C_B + max_cell( max|Q| * width ),

    where C_B is the boundary-defect excursion.

The last quantity gives a theorem-shaped implication. If the same C_A bound
were proved uniformly to infinity, then for any high-energy decreasing g with
g''>=0,

    |int_{E_N}^inf Q(E) g'(E) dE|
      <= C_A |g'(E_N)|.

Hence for inverse moments g(E)=E^(-2m),

    staircase tail correction
      <= C_A * 2m * E_N^(-2m-1).

For the resolvent g(E)=1/(E^2+a^2), once E_N>a/sqrt(3),

    correction
      <= C_A * 2 E_N/(E_N^2+a^2)^2.

This is NOT a proof of uniform boundedness. It quantifies exactly how strong
the consequence would be if the observed defect bound can be proved.

NO Xi, zeta, or known-zero data.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

VERSION = "v117"
BUILD = "2026-08-17-global-legendre-defect-theorem-bound-v117"
EPS = 1e-30


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row, key):
    return float(row[key])


def i(row, key):
    return int(float(row[key]))


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with open(path, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cumulative_max(x):
    x = np.asarray(x, float)
    return float(np.max(np.abs(np.cumsum(x)))) if len(x) else 0.0


def cumulative_range(x):
    x = np.asarray(x, float)
    c = np.concatenate([[0.0], np.cumsum(x)])
    return float(np.max(c)-np.min(c))


def lowfreq_fraction(x, bins):
    x = np.asarray(x, float)
    y = x - np.mean(x)
    z = np.fft.rfft(y)
    p = np.abs(z)**2
    if len(p) <= 1 or np.sum(p[1:]) <= EPS:
        return 0.0
    b = min(int(bins), len(p)-1)
    return float(np.sum(p[1:b+1]) / np.sum(p[1:]))


def percentile_le(samples, value):
    a = np.asarray(samples, float)
    return float(np.mean(a <= value))


def growth_exponent(ns, vals):
    n = np.asarray(ns, float)
    y = np.asarray(vals, float)
    mask = (n > 0) & (y > 0)
    if np.sum(mask) < 3:
        return float("nan")
    X = np.column_stack([np.ones(np.sum(mask)), np.log(n[mask])])
    beta, *_ = np.linalg.lstsq(X, np.log(y[mask]), rcond=None)
    return float(beta[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--v115-prefix",
        default="rot_rh_v114_high_resolution_validation_v115",
    )
    ap.add_argument(
        "--v116-prefix",
        default="rot_rh_long_scale_blind_staircase_v116",
    )
    ap.add_argument("--k-start", type=int, default=48)
    ap.add_argument("--k-end", type=int, default=767)
    ap.add_argument("--permutations", type=int, default=20000)
    ap.add_argument("--lowfreq-bins", type=int, default=4)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument("--moment-order", type=int, default=4)
    ap.add_argument("--a-probes", default="2,5,10")
    ap.add_argument(
        "--bound-starts",
        default="48,128,448,608",
        help="Cell indices k at whose left boundary E_k theorem bounds are reported.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_global_legendre_defect_v117",
    )
    args = ap.parse_args()

    p115 = Path(args.v115_prefix).expanduser().resolve()
    p116 = Path(args.v116_prefix).expanduser().resolve()
    f115 = Path(str(p115) + "_CELLS.csv")
    f116 = Path(str(p116) + "_CELLS.csv")
    if not f115.exists():
        raise FileNotFoundError(f115)
    if not f116.exists():
        raise FileNotFoundError(f116)

    rows = read_csv(f115) + read_csv(f116)
    mp = {}
    duplicates = []
    for r in rows:
        k = i(r, "cell_k")
        if args.k_start <= k <= args.k_end:
            if k in mp:
                duplicates.append(k)
            mp[k] = r

    expected = list(range(args.k_start, args.k_end+1))
    missing = [k for k in expected if k not in mp]
    if missing:
        raise RuntimeError(f"Missing cells: {missing[:20]}")

    rr = [mp[k] for k in expected]
    q = np.asarray([f(r, "Q_area") for r in rr], float)
    widths = np.asarray([f(r, "width") for r in rr], float)
    qmax = np.asarray([f(r, "max_abs_Q") for r in rr], float)
    lo = np.asarray([f(r, "lo") for r in rr], float)
    hi = np.asarray([f(r, "hi") for r in rr], float)

    # B_{k+1}-B_{k_start} = cumulative q.
    Binc = np.concatenate([[0.0], np.cumsum(q)])
    CB = float(np.max(np.abs(Binc)))
    Brange = float(np.max(Binc)-np.min(Binc))
    within_cell_allowance = float(np.max(qmax * widths))
    CA = CB + within_cell_allowance

    print("="*152)
    print("ROT-RH v117 — GLOBAL LEGENDRE-DEFECT ASSEMBLY / THEOREM-BOUND AUDIT")
    print("="*152)
    print("v115 cells                      :", f115)
    print("v116 cells                      :", f116)
    print("assembled cells                 :", f"{args.k_start}..{args.k_end}")
    print("cell count                      :", len(q))
    print("duplicates overwritten          :", sorted(set(duplicates)))
    print("Xi evaluations                  : NONE")
    print("zeta evaluations                : NONE")
    print("known zero ordinates            : NONE")
    print("="*152)

    print("[1] Global defect geometry")
    print("  max |B_k-B_start|              :", f"{CB:.12e}")
    print("  B range                         :", f"{Brange:.12e}")
    print("  max within-cell |Q|*width       :", f"{within_cell_allowance:.12e}")
    print("  conservative continuous C_A     :", f"{CA:.12e}")
    print("  max |Q|                         :", f"{np.max(qmax):.12e}")
    print("  max cell width                  :", f"{np.max(widths):.12e}")
    print("  mean |cell-average Q|           :",
          f"{np.mean(np.abs(q/widths)):.12e}")

    print("[2] Prefix growth at fixed 80-cell increments")
    prefix_rows = []
    ns, cms = [], []
    for n in range(80, len(q)+1, 80):
        x = q[:n]
        cm = cumulative_max(x)
        ns.append(n)
        cms.append(cm)
        prefix_rows.append({
            "prefix_cells": n,
            "k_end": args.k_start+n-1,
            "cumulative_max": cm,
            "cumulative_range": cumulative_range(x),
            "lowfreq_fraction": lowfreq_fraction(x, args.lowfreq_bins),
        })
        print(
            f"  n={n:<3d}, k_end={args.k_start+n-1}: "
            f"cumMax={cm:.6e}"
        )
    alpha = growth_exponent(ns, cms)
    print("  fitted prefix growth alpha      :", f"{alpha:+.6f}")

    print("[3] Post-hoc full-720 permutation red-team")
    rng = np.random.default_rng(args.seed)
    real_c = cumulative_max(q)
    real_l = lowfreq_fraction(q, args.lowfreq_bins)
    pc = np.empty(args.permutations, float)
    pl = np.empty(args.permutations, float)
    for t in range(args.permutations):
        y = rng.permutation(q)
        pc[t] = cumulative_max(y)
        pl[t] = lowfreq_fraction(y, args.lowfreq_bins)

    c_pct = percentile_le(pc, real_c)
    l_pct = percentile_le(pl, real_l)
    print("  real cumulative max             :", f"{real_c:.12e}")
    print("  permutation cumulative mean     :", f"{np.mean(pc):.12e}")
    print("  cumulative lower percentile     :", f"{100*c_pct:.6f}%")
    print("  real low-frequency fraction     :", f"{real_l:.12e}")
    print("  low-frequency lower percentile  :", f"{100*l_pct:.6f}%")

    print("[4] Theorem-shaped tail bounds if C_A is uniform")
    starts = [int(x.strip()) for x in args.bound_starts.split(",") if x.strip()]
    aprobes = [float(x.strip()) for x in args.a_probes.split(",") if x.strip()]
    bound_rows = []
    for k in starts:
        if k < args.k_start or k > args.k_end:
            continue
        E = float(mp[k]["lo"])  # left boundary is E_k
        row = {
            "k_start": k,
            "E_k": E,
            "C_A_assumed": CA,
        }
        for m in range(1, args.moment_order+1):
            b = CA * (2*m) * E**(-2*m-1)
            row[f"S{m}_staircase_tail_bound"] = b
        for a in aprobes:
            gp = 2.0*E/(E*E+a*a)**2
            row[f"R_a{a:g}_staircase_tail_bound"] = CA*gp
        bound_rows.append(row)

        print(
            f"  k={k:<3d} E={E:9.3f}: "
            f"S1<={row['S1_staircase_tail_bound']:.3e} "
            f"R(a=2)<={row.get('R_a2_staircase_tail_bound', float('nan')):.3e}"
        )

    # Cellwise output with assembled B increments.
    cell_rows = []
    c = 0.0
    for idx, k in enumerate(expected):
        cell_rows.append({
            "cell_k": k,
            "lo": lo[idx],
            "hi": hi[idx],
            "width": widths[idx],
            "Q_area": q[idx],
            "max_abs_Q": qmax[idx],
            "B_increment_before": c,
            "B_increment_after": c + q[idx],
            "within_cell_primitive_allowance": qmax[idx]*widths[idx],
        })
        c += q[idx]

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_csv(Path(str(prefix)+"_CELLS.csv"), cell_rows)
    write_csv(Path(str(prefix)+"_PREFIX.csv"), prefix_rows)
    write_csv(Path(str(prefix)+"_TAIL_BOUNDS.csv"), bound_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": "PASS_V117_GLOBAL_DEFECT_ASSEMBLY_COMPLETE",
        "RH_proof": False,
        "Xi_used": False,
        "zeta_used": False,
        "known_zeros_used": False,
        "cell_range": [args.k_start, args.k_end],
        "cell_count": len(q),
        "boundary_defect_max_abs": CB,
        "boundary_defect_range": Brange,
        "max_within_cell_allowance": within_cell_allowance,
        "conservative_continuous_primitive_bound": CA,
        "prefix_growth_alpha_posthoc": alpha,
        "full_sequence_cumulative_lower_percentile_posthoc": c_pct,
        "full_sequence_lowfreq_lower_percentile_posthoc": l_pct,
        "theorem_implication": (
            "If a uniform version of the observed boundary-defect and "
            "half-cell/spacing bounds is proved for all subsequent cells, "
            "then the continuous staircase primitive is uniformly bounded "
            "by C_A and the exact staircase correction to inverse moments "
            "and resolvents gains one inverse-energy power."
        ),
    }
    out = Path(str(prefix)+"_VERDICT.json")
    out.write_text(json.dumps(packet, indent=2), encoding="utf-8")

    print("\n"+"="*152)
    print("FINAL v117 VERDICT")
    print("="*152)
    print("verdict                          : PASS_V117_GLOBAL_DEFECT_ASSEMBLY_COMPLETE")
    print("boundary defect max |B-B48|      :", f"{CB:.12e}")
    print("conservative continuous C_A      :", f"{CA:.12e}")
    print("post-hoc prefix growth alpha     :", f"{alpha:.12e}")
    print("full-720 cumulative percentile   :", f"{100*c_pct:.6f}%")
    print("full-720 lowfreq percentile      :", f"{100*l_pct:.6f}%")
    print("RH proof                         : FALSE")
    print("verdict file                     :", out)
    print("="*152)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
