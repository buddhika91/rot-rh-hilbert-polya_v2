#!/usr/bin/env python3
"""
ROT-RH v215 — THREE-REGION FINITE-PARTITION / ABSOLUTE CUTOFF BOUND AUDIT

Zero-blind prime-side test.
No Xi / zeta evaluations / known-zero ordinates.

PURPOSE
-------
v214 showed that for every tested FIXED scaled-shell resolution up to 640,

    L1_N(L,E) = sum_j |D_j(L,E)|

decreases with L, including a negative holdout slope at the finest resolution.

A rigorous proof does NOT require taking the shell width to zero.  A finite
partition is enough if the two ends of scaled cutoff space can be controlled.

Write u = n/L and split

    (0,infinity)
      = (0,eps)
        union [eps,U]
        union (U,infinity).

Then for the centered cutoff difference,

    |Delta A_L(E)|
      <= |D_head(L,E;eps)|
         + sum_{j=1}^N |D_bulk,j(L,E;eps,U)|
         + |D_tail(L,E;U)|.

v215 tests exactly this architecture.

HEAD
----
For several eps values, compute the ONE centered discrepancy over

    2/L <= u < eps.

This keeps all prime/continuum cancellation inside the head rather than
microscopically partitioning it.

BULK
----
For one fixed baseline [eps0,U0], use N fixed logarithmic scaled shells and
compute the absolute shell L1 bound.

TAIL
----
For several U values, compute the ONE centered discrepancy over

    U <= u <= u_trunc.

The numerical tail is truncated at fixed scaled u_trunc; the script reports
the exponential weight at that edge.  This is a numerical audit, not a
rigorous infinite-tail proof.

BASELINE ABSOLUTE BOUND
-----------------------
For baseline eps0,U0,N,

    B_L(E) =
        |D_head(eps0)|
        + L1_bulk(eps0,U0,N)
        + |D_tail(U0)|,

which bounds the full numerically represented centered difference by triangle
inequality.

DECISIVE DIAGNOSTICS
--------------------
1. Does max_E B_L have a negative all-L and holdout slope?
2. Do all/most energies have negative B_L slopes?
3. At the largest L, does head magnitude shrink as eps decreases?
4. At the largest L, does tail magnitude shrink as U increases?
5. Are head and tail small compared with the bulk absolute bound?

A strong pass gives a concrete analytic blueprint:

  Lemma H: head -> 0 uniformly by a local PNT/finite-part estimate.
  Lemma B: each of finitely many fixed scaled bulk discrepancies -> 0.
  Lemma T: tail -> 0 uniformly from exponential damping plus centered PNT.
  Then finite triangle inequality gives Delta A_L -> 0.

This script is finite-range numerical evidence only.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def parse_float_list(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def power_slope(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)

    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]

    if len(x) < 3:
        return np.nan, np.nan

    lx = np.log(x)
    ly = np.log(y)

    c = np.polyfit(lx, ly, 1)
    pred = np.polyval(c, lx)

    den = np.sum((ly - ly.mean())**2)
    r2 = (
        1.0 - np.sum((ly - pred)**2)/den
        if den > 0 else np.nan
    )

    return float(c[0]), float(r2)


def prime_master_shell_matrix(
    n,
    coeff,
    logn,
    energies,
    L,
    ratio,
    edges,
    chunk,
):
    shells = len(edges)-1
    out = np.zeros((shells, len(energies)), dtype=np.complex128)

    nf = n.astype(np.float64)
    u = nf/L

    valid = (u >= edges[0]) & (u <= edges[-1])
    idx = np.flatnonzero(valid)

    if not len(idx):
        return out

    sid = np.searchsorted(edges, u[idx], side="right")-1
    sid = np.clip(sid, 0, shells-1)

    amp = coeff[idx] * (
        np.exp(-nf[idx]/(ratio*L))
        - np.exp(-nf[idx]/L)
    )

    tt = logn[idx]

    for lo in range(0, len(idx), chunk):
        hi = min(len(idx), lo+chunk)

        t = tt[lo:hi]
        a = amp[lo:hi]
        s = sid[lo:hi]

        phase = np.exp(
            1j*t[:,None]*energies[None,:]
        )
        z = a[:,None]*phase

        for k in range(len(energies)):
            re = np.bincount(
                s,
                weights=z[:,k].real,
                minlength=shells,
            )
            im = np.bincount(
                s,
                weights=z[:,k].imag,
                minlength=shells,
            )
            out[:,k] += re + 1j*im

    return out


def continuum_master_shell_matrix(
    edges,
    energies,
    L,
    ratio,
    nodes,
):
    shells = len(edges)-1
    out = np.zeros((shells, len(energies)), dtype=np.complex128)

    gx, gw = np.polynomial.legendre.leggauss(nodes)
    log2 = math.log(2.0)

    tedges = np.log(L*edges)

    for j in range(shells):
        a = max(float(tedges[j]), log2)
        b = float(tedges[j+1])

        if b <= a:
            continue

        mid = 0.5*(a+b)
        half = 0.5*(b-a)

        t = mid + half*gx
        w = half*gw
        x = np.exp(t)

        dw = (
            np.exp(-x/(ratio*L))
            - np.exp(-x/L)
        )

        base = (
            w*np.exp(0.5*t)*dw/t
        )

        phase = np.exp(
            1j*t[:,None]*energies[None,:]
        )

        out[j,:] = np.sum(
            base[:,None]*phase,
            axis=0,
        )

    return out


def edge_index(master_edges, x):
    i = int(np.searchsorted(master_edges, x))
    if i >= len(master_edges) or not np.isclose(
        master_edges[i], x, rtol=1e-12, atol=1e-15
    ):
        # try previous due float
        if i > 0 and np.isclose(
            master_edges[i-1], x, rtol=1e-12, atol=1e-15
        ):
            return i-1
        raise RuntimeError(f"Requested edge {x} not found in master grid.")
    return i


def interval_sum(D, master_edges, lo, hi):
    ilo = edge_index(master_edges, lo)
    ihi = edge_index(master_edges, hi)
    return np.sum(D[ilo:ihi,:], axis=0)


def bulk_L1(D, master_edges, bulk_edges):
    vals = []
    for a,b in zip(bulk_edges[:-1], bulk_edges[1:]):
        vals.append(interval_sum(D, master_edges, a, b))
    Z = np.stack(vals, axis=0)
    return np.sum(np.abs(Z), axis=0), Z


def norm_rel(a, b, floor=1e-30):
    return float(
        np.linalg.norm(a-b)
        / max(np.linalg.norm(a), np.linalg.norm(b), floor)
    )


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v212-module",
        default="rot_rh_euler_product_coupling_v212",
    )

    ap.add_argument(
        "--L-list",
        default="4000,8000,16000,32000,64000,128000,256000",
    )
    ap.add_argument("--ratio", type=float, default=2.0)

    ap.add_argument("--emin", type=float, default=10.0)
    ap.add_argument("--emax", type=float, default=80.0)
    ap.add_argument("--energy-count", type=int, default=29)
    ap.add_argument("--energy-values", default="")

    ap.add_argument(
        "--head-eps-values",
        default="0.001,0.002,0.005,0.01,0.02,0.05",
    )
    ap.add_argument(
        "--baseline-eps",
        type=float,
        default=0.01,
    )

    ap.add_argument(
        "--tail-U-values",
        default="8,12,16,24,32",
    )
    ap.add_argument(
        "--baseline-U",
        type=float,
        default=16.0,
    )

    ap.add_argument(
        "--bulk-shells",
        type=int,
        default=80,
    )

    ap.add_argument(
        "--u-trunc",
        type=float,
        default=64.0,
    )

    ap.add_argument(
        "--quad-nodes-per-master-shell",
        type=int,
        default=12,
    )
    ap.add_argument(
        "--quad-check-factor",
        type=int,
        default=2,
    )
    ap.add_argument(
        "--quad-norm-rel-gate",
        type=float,
        default=1e-8,
    )

    ap.add_argument(
        "--prime-chunk",
        type=int,
        default=65536,
    )

    ap.add_argument(
        "--holdout-points",
        type=int,
        default=4,
    )

    ap.add_argument(
        "--bound-all-slope-gate",
        type=float,
        default=-0.02,
    )
    ap.add_argument(
        "--bound-holdout-slope-gate",
        type=float,
        default=-0.01,
    )
    ap.add_argument(
        "--negative-energy-fraction-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--endpoint-monotonic-fraction-gate",
        type=float,
        default=0.80,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_three_region_absolute_bound_v215",
    )

    args = ap.parse_args()

    v212 = importlib.import_module(args.v212_module)

    Ls = np.asarray(parse_float_list(args.L_list), dtype=float)

    if args.energy_values.strip():
        energies = np.asarray(
            parse_float_list(args.energy_values),
            dtype=float,
        )
    else:
        energies = np.linspace(
            args.emin,
            args.emax,
            args.energy_count,
        )

    head_eps = sorted(set(parse_float_list(args.head_eps_values)))
    tail_Us = sorted(set(parse_float_list(args.tail_U_values)))

    if args.baseline_eps not in head_eps:
        head_eps.append(args.baseline_eps)
        head_eps = sorted(head_eps)

    if args.baseline_U not in tail_Us:
        tail_Us.append(args.baseline_U)
        tail_Us = sorted(tail_Us)

    if not (
        0 < min(head_eps)
        <= args.baseline_eps
        < args.baseline_U
        <= max(tail_Us)
        < args.u_trunc
    ):
        raise RuntimeError("Invalid head/bulk/tail scale ordering.")

    Lmax = float(np.max(Ls))
    u_min = 2.0/Lmax

    bulk_edges = np.geomspace(
        args.baseline_eps,
        args.baseline_U,
        args.bulk_shells+1,
    )

    # Master grid includes every requested endpoint exactly.
    raw_edges = [
        u_min,
        *head_eps,
        *bulk_edges.tolist(),
        *tail_Us,
        args.u_trunc,
    ]

    master_edges = np.asarray(
        sorted(set(float(x) for x in raw_edges)),
        dtype=float,
    )

    # Remove anything below full-support u_min except u_min itself.
    master_edges = master_edges[master_edges >= u_min*(1-1e-15)]

    nmax = int(math.ceil(args.u_trunc*Lmax))

    print("="*202)
    print("ROT-RH v215 — THREE-REGION FINITE-PARTITION / ABSOLUTE CUTOFF BOUND AUDIT")
    print("="*202)
    print("Xi / zeta / known zeros          : NONE")
    print(f"L values                          : {Ls.tolist()}")
    print(f"energies                          : {len(energies)}")
    print(f"full-support u_min                : {u_min:.12e}")
    print(f"head eps values                   : {head_eps}")
    print(f"baseline bulk                     : [{args.baseline_eps},{args.baseline_U}] with {args.bulk_shells} shells")
    print(f"tail U values                     : {tail_Us}")
    print(f"u truncation                       : {args.u_trunc}")
    print(f"master shells                     : {len(master_edges)-1}")
    print(f"nmax                              : {nmax}")
    print(f"long exponential at u_trunc       : {math.exp(-args.u_trunc/args.ratio):.6e}")
    print("="*202)

    n, exponents, coeff, primes = v212.build_prime_powers(nmax)
    logn = np.log(n.astype(np.float64))

    print(f"primes <= nmax                    : {len(primes)}")
    print(f"prime powers incl primes          : {len(n)}")

    head_data = {
        eps: np.zeros((len(Ls),len(energies)),float)
        for eps in head_eps
    }
    tail_data = {
        U: np.zeros((len(Ls),len(energies)),float)
        for U in tail_Us
    }

    bulk_data = np.zeros((len(Ls),len(energies)),float)
    bound_data = np.zeros((len(Ls),len(energies)),float)
    actual_data = np.zeros((len(Ls),len(energies)),float)

    qrels = []
    rows = []

    for i,L in enumerate(Ls):
        P = prime_master_shell_matrix(
            n=n,
            coeff=coeff,
            logn=logn,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            edges=master_edges,
            chunk=args.prime_chunk,
        )

        M1 = continuum_master_shell_matrix(
            edges=master_edges,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            nodes=args.quad_nodes_per_master_shell,
        )

        M2 = continuum_master_shell_matrix(
            edges=master_edges,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            nodes=(
                args.quad_nodes_per_master_shell
                * args.quad_check_factor
            ),
        )

        qrel = norm_rel(M1,M2)
        qrels.append(qrel)

        D = P-M2

        for eps in head_eps:
            z = interval_sum(
                D,
                master_edges,
                u_min,
                eps,
            )
            head_data[eps][i,:] = np.abs(z)

        for U in tail_Us:
            z = interval_sum(
                D,
                master_edges,
                U,
                args.u_trunc,
            )
            tail_data[U][i,:] = np.abs(z)

        bulkL1, bulkZ = bulk_L1(
            D,
            master_edges,
            bulk_edges,
        )
        bulk_data[i,:] = bulkL1

        head0 = head_data[args.baseline_eps][i,:]
        tail0 = tail_data[args.baseline_U][i,:]

        B = head0 + bulkL1 + tail0
        bound_data[i,:] = B

        actual = np.abs(np.sum(D,axis=0))
        actual_data[i,:] = actual

        row = {
            "L":float(L),
            "head_max":float(np.max(head0)),
            "bulk_L1_max":float(np.max(bulkL1)),
            "tail_max":float(np.max(tail0)),
            "bound_max":float(np.max(B)),
            "actual_max":float(np.max(actual)),
            "actual_over_bound_max":float(
                np.max(actual/np.maximum(B,1e-300))
            ),
            "quad_norm_rel":qrel,
        }

        rows.append(row)

        print(
            f"L={L:10.0f} "
            f"head={row['head_max']:.3e} "
            f"bulk={row['bulk_L1_max']:.3e} "
            f"tail={row['tail_max']:.3e} "
            f"BOUND={row['bound_max']:.3e} "
            f"actual={row['actual_max']:.3e} "
            f"q={qrel:.3e}"
        )

    hp = args.holdout_points
    holdL = Ls[-hp:]

    # Baseline bound slopes.
    bmax = np.max(bound_data,axis=1)
    brms = np.sqrt(np.mean(bound_data**2,axis=1))

    p_all,r_all = power_slope(Ls,bmax)
    p_hold,r_hold = power_slope(holdL,bmax[-hp:])
    p_rms,r_rms = power_slope(Ls,brms)

    energy_slopes = []
    energy_hold_slopes = []

    for k in range(len(energies)):
        p,_ = power_slope(Ls,bound_data[:,k])
        ph,_ = power_slope(holdL,bound_data[-hp:,k])
        energy_slopes.append(p)
        energy_hold_slopes.append(ph)

    energy_slopes = np.asarray(energy_slopes,float)
    energy_hold_slopes = np.asarray(energy_hold_slopes,float)

    neg_frac = float(np.mean(energy_slopes<0))
    neg_hold_frac = float(np.mean(energy_hold_slopes<0))

    # Head endpoint behavior at final L.
    head_final = np.array([
        np.max(head_data[eps][-1,:])
        for eps in head_eps
    ],float)

    # As eps increases, head magnitude should generally grow.
    head_monotonic_fraction = (
        float(np.mean(np.diff(head_final)>=0))
        if len(head_final)>1 else 1.0
    )

    # Tail endpoint behavior at final L.
    tail_final = np.array([
        np.max(tail_data[U][-1,:])
        for U in tail_Us
    ],float)

    # As U increases, tail magnitude should generally shrink.
    tail_monotonic_fraction = (
        float(np.mean(np.diff(tail_final)<=0))
        if len(tail_final)>1 else 1.0
    )

    # Endpoint slopes for each eps/U.
    head_rows = []
    for eps in head_eps:
        y = np.max(head_data[eps],axis=1)
        p,r2 = power_slope(Ls,y)
        ph,rh = power_slope(holdL,y[-hp:])
        head_rows.append({
            "eps":eps,
            "max_slope_all":p,
            "max_log_R2_all":r2,
            "max_slope_holdout":ph,
            "max_log_R2_holdout":rh,
            "final_max":float(y[-1]),
        })

    tail_rows = []
    for U in tail_Us:
        y = np.max(tail_data[U],axis=1)
        p,r2 = power_slope(Ls,y)
        ph,rh = power_slope(holdL,y[-hp:])
        tail_rows.append({
            "U":U,
            "max_slope_all":p,
            "max_log_R2_all":r2,
            "max_slope_holdout":ph,
            "max_log_R2_holdout":rh,
            "final_max":float(y[-1]),
        })

    hdf = pd.DataFrame(head_rows)
    tdf = pd.DataFrame(tail_rows)

    quad_pass = bool(max(qrels)<=args.quad_norm_rel_gate)

    bound_pass = bool(
        p_all <= args.bound_all_slope_gate
        and p_hold <= args.bound_holdout_slope_gate
        and neg_frac >= args.negative_energy_fraction_gate
        and neg_hold_frac >= args.negative_energy_fraction_gate
    )

    endpoint_pass = bool(
        head_monotonic_fraction
            >= args.endpoint_monotonic_fraction_gate
        and tail_monotonic_fraction
            >= args.endpoint_monotonic_fraction_gate
    )

    if quad_pass and bound_pass and endpoint_pass:
        verdict = "THREE_REGION_ABSOLUTE_CUTOFF_BOUND_STRONGLY_SUPPORTED"
    elif quad_pass and bound_pass:
        verdict = "ABSOLUTE_BOUND_CONTRACTS_ENDPOINT_UNIFORMITY_PARTIAL"
    elif quad_pass:
        verdict = "THREE_REGION_ABSOLUTE_ROUTE_UNRESOLVED"
    else:
        verdict = "NUMERICAL_QUADRATURE_UNRESOLVED"

    ldf = pd.DataFrame(rows)
    ldf.to_csv(args.prefix+"_L_VALUES.csv",index=False)
    hdf.to_csv(args.prefix+"_HEAD.csv",index=False)
    tdf.to_csv(args.prefix+"_TAIL.csv",index=False)

    summary = {
        "version":215,
        "firewall":"Xi / zeta / known zeros: NONE",
        "L_values":Ls.tolist(),
        "baseline_eps":args.baseline_eps,
        "baseline_U":args.baseline_U,
        "bulk_shells":args.bulk_shells,
        "u_trunc":args.u_trunc,
        "nmax":nmax,
        "long_exponential_weight_at_u_trunc":
            math.exp(-args.u_trunc/args.ratio),
        "max_continuum_quadrature_norm_relative_discrepancy":
            float(max(qrels)),
        "bound_max_slope_all":p_all,
        "bound_max_log_R2_all":r_all,
        "bound_max_slope_holdout":p_hold,
        "bound_max_log_R2_holdout":r_hold,
        "bound_RMS_slope_all":p_rms,
        "bound_RMS_log_R2_all":r_rms,
        "negative_energy_fraction_all":neg_frac,
        "negative_energy_fraction_holdout":neg_hold_frac,
        "head_final_monotonic_fraction":head_monotonic_fraction,
        "tail_final_monotonic_fraction":tail_monotonic_fraction,
        "final_head_max_baseline":float(
            np.max(head_data[args.baseline_eps][-1,:])
        ),
        "final_bulk_L1_max":float(
            np.max(bulk_data[-1,:])
        ),
        "final_tail_max_baseline":float(
            np.max(tail_data[args.baseline_U][-1,:])
        ),
        "final_bound_max":float(np.max(bound_data[-1,:])),
        "final_actual_max":float(np.max(actual_data[-1,:])),
        "quad_pass":quad_pass,
        "bound_pass":bound_pass,
        "endpoint_pass":endpoint_pass,
        "verdict":verdict,
        "proof_blueprint_if_passed":{
            "head":"prove one centered low-u discrepancy tends uniformly to zero",
            "bulk":"prove finitely many fixed scaled-shell centered discrepancies tend to zero",
            "tail":"prove one centered high-u discrepancy is uniformly small as U grows",
            "closure":"finite triangle inequality gives cutoff difference -> 0",
        },
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*202)
    print("THREE-REGION DIAGNOSTICS")
    print(f"bound max slope all               : {p_all:.9f}  R2={r_all:.6f}")
    print(f"bound max slope holdout           : {p_hold:.9f}  R2={r_hold:.6f}")
    print(f"bound RMS slope all               : {p_rms:.9f}  R2={r_rms:.6f}")
    print(f"negative energy fraction all      : {neg_frac:.6f}")
    print(f"negative energy fraction holdout  : {neg_hold_frac:.6f}")
    print(f"head final monotonic fraction     : {head_monotonic_fraction:.6f}")
    print(f"tail final monotonic fraction     : {tail_monotonic_fraction:.6f}")
    print(f"quadrature norm-relative max      : {max(qrels):.6e}")
    print()
    print("HEAD SCAN")
    for _,r in hdf.iterrows():
        print(
            f"eps={r['eps']:.4g} "
            f"pAll={r['max_slope_all']:.6f} "
            f"pHold={r['max_slope_holdout']:.6f} "
            f"final={r['final_max']:.6e}"
        )
    print()
    print("TAIL SCAN")
    for _,r in tdf.iterrows():
        print(
            f"U={r['U']:.4g} "
            f"pAll={r['max_slope_all']:.6f} "
            f"pHold={r['max_slope_holdout']:.6f} "
            f"final={r['final_max']:.6e}"
        )
    print()
    print(f"VERDICT                           : {verdict}")
    print("="*202)


if __name__ == "__main__":
    main()
