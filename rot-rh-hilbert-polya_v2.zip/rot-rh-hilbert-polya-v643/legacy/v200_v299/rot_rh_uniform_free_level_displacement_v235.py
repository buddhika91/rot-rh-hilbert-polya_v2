#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v235 — PROSPECTIVE UNIFORM FREE-LEVEL DISPLACEMENT / WEYL TRANSFER AUDIT
==============================================================================

Motivation
----------
v234 showed that the sharp arithmetic remainder envelope C_R=0.11652 is
genuinely root-locked: it holds at every tested arithmetic root, but no fixed
nonzero fraction of every neighboring cell inherits it.

For the high-mode trace tail we do not actually need an off-spectrum phase
bound.  A cleaner equivalent route is to compare the arithmetic roots directly
with the free Archimedean roots.

Let A_k be the zero-blind free level defined by

    theta(A_k)/pi + 1 = k - 1/2.

Suppose there is a cutoff-independent finite D such that

    |E_k(L) - A_k| <= D

for all sufficiently large L and all k.

v232 analytically proved

    theta(E)/pi + 1 <= 2.25 + 0.25 E log(E+e),  E>=7.

At A_k this implies, for k>=6,

    A_k >= 2 k/log(k+e).

Hence a uniform displacement theorem gives

    E_k(L) >= 2 k/log(k+e) - D.

Whenever k/log(k+e) >= D,

    E_k(L) >= k/log(k+e).

Therefore the single statement

    sup_{L,k} |E_k(L)-A_k| < infinity

is already sufficient for the uniform summable domination

    E_k(L)^(-2) <= [log(k+e)/k]^2

beyond an explicit finite k0.

This is substantially weaker than proving the sharp root-local C_R bound and
does not require extending that bound off the spectrum.

What v235 does
--------------
* ZERO-BLIND: no Xi, zeta values, or known zero ordinates.
* Load the v230 canonical arithmetic roots.
* Compute the free Archimedean A_k independently from theta only.
* Freeze an additive displacement envelope D_safe on a training rectangle.
* Test it in TWO independent prospective directions:
    1. future cutoffs, on the common low modes;
    2. high modes, on developed earlier cutoffs.
* Diagnose whether displacement grows or decays with k and L.
* Convert D_safe into an explicit theorem-candidate k0 and the conditional
  uniform trace-tail majorant with c=1.
* Compare the displacement route to the older root-local remainder route.

No root solves involving the arithmetic phase are performed.  Only free theta
levels are solved, which are construction-independent and zero-blind.

Scientific boundary
-------------------
A PASS is not a proof of a uniform displacement theorem.  It establishes that
the existing zero-blind root data support a much cleaner high-mode theorem
target.  The remaining analytic task would be to prove a finite D directly
from the moving-root/cutoff flow.

Version: 235
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd

try:
    from scipy.optimize import brentq
except Exception as exc:
    raise RuntimeError("v235 requires scipy.optimize") from exc

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v235 requires tqdm") from exc


VERSION = 235
EE = math.e


def free_levels(base, depth: int) -> np.ndarray:
    """
    Compute A_k from smooth_count(A_k)=k-1/2 using only theta.
    Warm brackets make this fast even for depth ~1e4.
    """
    out = np.empty(int(depth), float)
    lower = 7.0
    upper = 20.0

    for k in tqdm(range(1, int(depth) + 1), desc="Free theta levels", unit="k"):
        target = float(k) - 0.5

        if k > 1:
            lower = out[k - 2] + 1e-10
            upper = max(lower + 1.0, out[k - 2] + 8.0)

        while base.smooth_count(float(upper)) < target:
            upper *= 1.25
            if upper > 1e9:
                raise RuntimeError(f"Failed to bracket free level k={k}")

        out[k - 1] = brentq(
            lambda x: base.smooth_count(float(x)) - target,
            lower,
            upper,
            xtol=1e-13,
            rtol=1e-13,
            maxiter=300,
        )

    return out


def linfit_loglog(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x, y = x[m], y[m]
    if len(x) < 3 or np.ptp(np.log(x)) <= 0:
        return dict(n=int(len(x)), slope=np.nan, r2=np.nan)

    X = np.column_stack([np.ones(len(x)), np.log(x)])
    yy = np.log(y)
    beta, *_ = np.linalg.lstsq(X, yy, rcond=None)
    pred = X @ beta
    sse = float(np.sum((yy - pred) ** 2))
    sst = float(np.sum((yy - yy.mean()) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0

    return dict(
        n=int(len(x)),
        slope=float(beta[1]),
        r2=float(r2),
    )


def minimum_k_for_displacement(D: float, c_free=2.0, c_target=1.0) -> int:
    """
    Need
        c_free*k/log(k+e) - D >= c_target*k/log(k+e)
    i.e.
        (c_free-c_target)*k/log(k+e) >= D.
    """
    gap = float(c_free) - float(c_target)
    if gap <= 0:
        return -1

    k = 6
    while gap * k / math.log(k + EE) < D:
        k += 1
        if k > 10**9:
            return -1
    return k


def trace_tail_majorant(c: float, N: int) -> float:
    if c <= 0 or N < 3:
        return float("inf")
    d = math.log1p(EE / float(N))
    u = math.log(float(N)) + d
    return (u*u + 2*u + 2) / (float(N) * c*c)


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--canonical-roots",
        default="rot_rh_dominated_convergence_cutoff_independence_v230_CANONICAL_ROOTS.csv.gz",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    # Freeze D on a rectangle; holdouts probe orthogonal directions.
    ap.add_argument("--train-cutoff-max", type=int, default=512000)
    ap.add_argument("--train-mode-max", type=int, default=256)
    ap.add_argument("--k-min", type=int, default=6)

    # Additive slack is fixed before holdout inspection.
    ap.add_argument("--D-additive-slack", type=float, default=0.25)
    ap.add_argument("--D-relative-slack", type=float, default=0.05)

    ap.add_argument("--minimum-future-cutoff-rows", type=int, default=64)
    ap.add_argument("--minimum-high-mode-rows", type=int, default=128)
    ap.add_argument("--minimum-future-cutoffs", type=int, default=2)

    # Trend diagnostics only reject clear blow-up.
    ap.add_argument("--mode-displacement-slope-gate", type=float, default=0.10)
    ap.add_argument("--cutoff-displacement-slope-gate", type=float, default=0.10)

    ap.add_argument(
        "--tail-N-values",
        default="32,64,128,256,512,1024,4096,16384,65536",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_uniform_free_level_displacement_v235",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    roots = pd.read_csv(args.canonical_roots)
    need = {"L", "k", "E"}
    miss = need - set(roots.columns)
    if miss:
        raise KeyError(f"canonical roots missing {sorted(miss)}")

    roots = roots[
        np.isfinite(roots["L"])
        & np.isfinite(roots["k"])
        & np.isfinite(roots["E"])
        & (roots["L"] > 0)
        & (roots["k"] >= args.k_min)
        & (roots["E"] > 0)
    ].copy()
    roots["L"] = roots["L"].astype(int)
    roots["k"] = roots["k"].astype(int)

    if roots.empty:
        raise RuntimeError("No roots survive filters")

    max_k = int(roots["k"].max())

    import importlib
    base = importlib.import_module(args.base_module)
    A = free_levels(base, max_k)

    roots["A_free"] = A[roots["k"].to_numpy(int) - 1]
    roots["displacement"] = roots["E"] - roots["A_free"]
    roots["abs_displacement"] = np.abs(roots["displacement"])
    roots["relative_displacement"] = (
        roots["abs_displacement"] / roots["A_free"]
    )
    roots["cell_scale_proxy"] = (
        roots["A_free"]
        * np.log(roots["k"].to_numpy(float) + EE)
        / roots["k"].to_numpy(float)
    )

    train = roots[
        (roots["L"] <= args.train_cutoff_max)
        & (roots["k"] <= args.train_mode_max)
    ].copy()
    if train.empty:
        raise RuntimeError("Training rectangle empty")

    D_train = float(train["abs_displacement"].max())
    D_safe = max(
        D_train + float(args.D_additive_slack),
        D_train * (1.0 + float(args.D_relative_slack)),
    )

    future = roots[roots["L"] > args.train_cutoff_max].copy()
    highmode = roots[
        (roots["L"] <= args.train_cutoff_max)
        & (roots["k"] > args.train_mode_max)
    ].copy()

    def holdout_stats(df, label):
        if df.empty:
            return dict(
                label=label, rows=0, cutoffs=0, modes=0,
                max_abs_displacement=np.nan,
                D_margin=np.nan,
                failures=0,
            )
        mx = float(df["abs_displacement"].max())
        return dict(
            label=label,
            rows=int(len(df)),
            cutoffs=int(df["L"].nunique()),
            modes=int(df["k"].nunique()),
            max_abs_displacement=mx,
            D_margin=float(D_safe / mx) if mx > 0 else np.inf,
            failures=int(np.sum(df["abs_displacement"].to_numpy(float) > D_safe)),
        )

    future_stats = holdout_stats(future, "future_cutoff")
    highmode_stats = holdout_stats(highmode, "high_mode")

    # Per-cutoff displacement maxima over common k to remove depth confounding.
    cutoffs = sorted(roots["L"].unique().tolist())
    maxk_by_L = roots.groupby("L")["k"].max().to_dict()
    common_k = min(int(maxk_by_L[L]) for L in cutoffs)
    common_k = max(common_k, args.k_min)

    cutoff_rows = []
    for L, g in roots[roots["k"] <= common_k].groupby("L", sort=True):
        cutoff_rows.append({
            "L": int(L),
            "common_k_max": common_k,
            "max_abs_displacement": float(g["abs_displacement"].max()),
            "median_abs_displacement": float(g["abs_displacement"].median()),
            "max_relative_displacement": float(g["relative_displacement"].max()),
            "D_failures": int(np.sum(g["abs_displacement"] > D_safe)),
        })
    cutoff_df = pd.DataFrame(cutoff_rows)
    cutoff_fit = linfit_loglog(
        cutoff_df["L"].to_numpy(float),
        cutoff_df["max_abs_displacement"].to_numpy(float),
    )

    # Per-mode worst displacement over all available cutoffs.
    mode_rows = []
    for k, g in roots.groupby("k", sort=True):
        mode_rows.append({
            "k": int(k),
            "cutoffs": int(g["L"].nunique()),
            "max_abs_displacement": float(g["abs_displacement"].max()),
            "median_abs_displacement": float(g["abs_displacement"].median()),
            "max_relative_displacement": float(g["relative_displacement"].max()),
            "D_failures": int(np.sum(g["abs_displacement"] > D_safe)),
        })
    mode_df = pd.DataFrame(mode_rows)

    upper = mode_df[
        mode_df["k"] >= max(args.train_mode_max, int(mode_df["k"].median()))
    ].copy()
    if len(upper) < 3:
        upper = mode_df.iloc[len(mode_df)//2:].copy()

    mode_fit = linfit_loglog(
        upper["k"].to_numpy(float),
        upper["max_abs_displacement"].to_numpy(float),
    )

    # Training/holdout worst cases.
    worst_train = train.loc[train["abs_displacement"].idxmax()]
    worst_all = roots.loc[roots["abs_displacement"].idxmax()]
    worst_future = (
        future.loc[future["abs_displacement"].idxmax()]
        if len(future) else None
    )
    worst_high = (
        highmode.loc[highmode["abs_displacement"].idxmax()]
        if len(highmode) else None
    )

    # Analytic transfer from v232:
    # free A_k >= 2 k/log(k+e), k>=6.
    c_free = 2.0
    c_transfer = 1.0
    k0_D = minimum_k_for_displacement(D_safe, c_free, c_transfer)
    k0 = max(6, k0_D)

    roots["transferred_lower_bound"] = (
        c_transfer
        * roots["k"].to_numpy(float)
        / np.log(roots["k"].to_numpy(float) + EE)
    )
    transfer_test = roots[roots["k"] >= k0].copy()
    transfer_test["E_over_transferred_bound"] = (
        transfer_test["E"] / transfer_test["transferred_lower_bound"]
    )
    min_transfer_margin = float(
        transfer_test["E_over_transferred_bound"].min()
    )

    tail_N_values = [
        int(x.strip())
        for x in args.tail_N_values.split(",")
        if x.strip()
    ]
    tail_rows = []
    for N in sorted(set(tail_N_values)):
        tail_rows.append({
            "N": int(N),
            "single_operator_tail_bound_c1": trace_tail_majorant(c_transfer, N),
            "pairwise_two_operator_tail_bound_c1": 2.0 * trace_tail_majorant(c_transfer, N),
        })
    tail_df = pd.DataFrame(tail_rows)

    gates = {
        "training_displacement_finite": bool(np.isfinite(D_safe) and D_safe > 0),
        "future_cutoff_holdout_coverage": bool(
            future_stats["rows"] >= args.minimum_future_cutoff_rows
            and future_stats["cutoffs"] >= args.minimum_future_cutoffs
        ),
        "future_cutoff_displacement_holdout_pass": bool(
            future_stats["failures"] == 0
        ),
        "high_mode_holdout_coverage": bool(
            highmode_stats["rows"] >= args.minimum_high_mode_rows
        ),
        "high_mode_displacement_holdout_pass": bool(
            highmode_stats["failures"] == 0
        ),
        "cutoff_displacement_not_power_blowing_up": bool(
            np.isfinite(cutoff_fit["slope"])
            and cutoff_fit["slope"] <= args.cutoff_displacement_slope_gate
        ),
        "high_mode_displacement_not_power_blowing_up": bool(
            np.isfinite(mode_fit["slope"])
            and mode_fit["slope"] <= args.mode_displacement_slope_gate
        ),
        "transferred_weyl_bound_pass_on_available_roots": bool(
            min_transfer_margin >= 1.0
        ),
    }
    failed = [k for k, v in gates.items() if not v]

    verdict = (
        "UNIFORM_FREE_LEVEL_DISPLACEMENT_WEYL_TRANSFER_STRONGLY_SUPPORTED"
        if not failed
        else
        "UNIFORM_FREE_LEVEL_DISPLACEMENT_TARGET_UNRESOLVED"
    )

    prefix = args.prefix
    root_path = Path(prefix + "_ROOTS.csv.gz")
    cutoff_path = Path(prefix + "_CUTOFFS.csv")
    mode_path = Path(prefix + "_MODES.csv")
    tail_path = Path(prefix + "_TAIL_MAJORANTS.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM_TARGET.md")

    roots.to_csv(root_path, index=False, compression="gzip")
    cutoff_df.to_csv(cutoff_path, index=False)
    mode_df.to_csv(mode_path, index=False)
    tail_df.to_csv(tail_path, index=False)

    def row_dict(row):
        if row is None:
            return None
        return {
            "L": int(row["L"]),
            "k": int(row["k"]),
            "E": float(row["E"]),
            "A_free": float(row["A_free"]),
            "displacement": float(row["displacement"]),
            "abs_displacement": float(row["abs_displacement"]),
        }

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "arithmetic_root_solves": False,
        },
        "training": {
            "train_cutoff_max": args.train_cutoff_max,
            "train_mode_max": args.train_mode_max,
            "rows": int(len(train)),
            "maximum_observed_displacement": D_train,
            "additive_slack": args.D_additive_slack,
            "relative_slack": args.D_relative_slack,
            "frozen_D_safe": D_safe,
            "worst_training_row": row_dict(worst_train),
        },
        "future_cutoff_holdout": future_stats,
        "high_mode_holdout": highmode_stats,
        "worst_available_rows": {
            "all": row_dict(worst_all),
            "future_cutoff": row_dict(worst_future),
            "high_mode": row_dict(worst_high),
        },
        "trend_diagnostics": {
            "common_k_for_cutoff_fit": common_k,
            "cutoff_max_displacement_loglog": cutoff_fit,
            "upper_mode_max_displacement_loglog": mode_fit,
        },
        "analytic_transfer": {
            "input_from_v232": (
                "smooth_count(E) <= 2.25 + 0.25 E log(E+e), E>=7"
            ),
            "free_level_consequence": (
                "A_k >= 2 k/log(k+e) for k>=6"
            ),
            "conditional_uniform_displacement_hypothesis": (
                f"|E_k(L)-A_k| <= D={D_safe:.12g}"
            ),
            "transferred_bound": (
                f"E_k(L) >= k/log(k+e) for k>={k0}"
            ),
            "c_transfer": c_transfer,
            "k0_from_D": k0_D,
            "registered_k0": k0,
            "minimum_available_E_over_transferred_bound": min_transfer_margin,
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "proof_status": (
            "NOT A PROOF. v235 reformulates the high-mode arithmetic remainder "
            "problem as a uniform spectral-displacement theorem. If one proves "
            "sup_{L,k}|E_k(L)-A_k|<infinity, v232 transfers the free Weyl lower "
            "bound immediately and supplies the summable trace-tail majorant."
        ),
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    theorem = f"""# ROT-RH v235 — displacement-transfer theorem target

Let `A_k` be the free Archimedean level

`theta(A_k)/pi + 1 = k-1/2`.

v232 proves

`theta(E)/pi + 1 <= 2.25 + 0.25 E log(E+e)` for `E>=7`.

Therefore, for `k>=6`,

`A_k >= 2 k/log(k+e)`.

The new theorem target is simply:

`|E_k(L)-A_k| <= D`

for one finite constant `D`, uniformly in sufficiently large `L` and all `k`.

The frozen numerical candidate from training is

`D = {D_safe:.15g}`.

If that theorem is proved, then for `k>={k0}`,

`E_k(L) >= k/log(k+e)`,

so

`E_k(L)^(-2) <= [log(k+e)/k]^2`.

The right-hand side is summable. Combined with fixed-mode convergence,
dominated convergence yields

`||K_L-K_infinity||_1 -> 0`.

This route uses no off-spectrum `C_R` neighborhood estimate and is compatible
with the root-locking found by v234.

What remains analytic is to prove the uniform displacement theorem from the
moving-root cutoff identity / signed arithmetic shell flow.
"""
    theorem_path.write_text(theorem, encoding="utf-8")

    print("=" * 184)
    print("ROT-RH v235 — PROSPECTIVE UNIFORM FREE-LEVEL DISPLACEMENT / WEYL TRANSFER AUDIT")
    print("=" * 184)
    print("Xi / zeta / known-zero data        : NONE")
    print("arithmetic root solves              : NONE")
    print(f"deepest mode                        : {max_k}")
    print(f"cutoffs                             : {sorted(roots['L'].unique().tolist())}")
    print()
    print("TRAINING DISPLACEMENT ENVELOPE")
    print("-" * 184)
    print(f"training max |E-A|                  : {D_train:.12f}")
    print(f"frozen D_safe                       : {D_safe:.12f}")
    print(
        "future-cutoff holdout              : "
        f"rows={future_stats['rows']} "
        f"cutoffs={future_stats['cutoffs']} "
        f"max={future_stats['max_abs_displacement']:.9f} "
        f"D/max={future_stats['D_margin']:.6f} "
        f"failures={future_stats['failures']}"
    )
    print(
        "high-mode holdout                  : "
        f"rows={highmode_stats['rows']} "
        f"modes={highmode_stats['modes']} "
        f"max={highmode_stats['max_abs_displacement']:.9f} "
        f"D/max={highmode_stats['D_margin']:.6f} "
        f"failures={highmode_stats['failures']}"
    )
    print()
    print("TREND DIAGNOSTICS")
    print("-" * 184)
    print(
        "common-k cutoff max displacement   : "
        f"slope={cutoff_fit['slope']:.9f} R2={cutoff_fit['r2']:.6f}"
    )
    print(
        "upper-mode max displacement        : "
        f"slope={mode_fit['slope']:.9f} R2={mode_fit['r2']:.6f}"
    )
    print()
    print("ANALYTIC WEYL TRANSFER")
    print("-" * 184)
    print("v232 free-level bound               : A_k >= 2 k/log(k+e), k>=6")
    print(f"conditional displacement D          : {D_safe:.12f}")
    print(f"transferred theorem candidate       : E_k(L) >= k/log(k+e), k>={k0}")
    print(f"minimum available E / transfer bound: {min_transfer_margin:.9f}")
    print()
    print("CONDITIONAL TRACE TAIL (c=1)")
    print("-" * 184)
    for r in tail_rows:
        print(
            f"N={r['N']:>7d}  "
            f"single<={r['single_operator_tail_bound_c1']:.6e}  "
            f"two<={r['pairwise_two_operator_tail_bound_c1']:.6e}"
        )
    print()
    print("=" * 184)
    print("FAILED GATES                        :", failed if failed else "none")
    print("NUMERICAL VERDICT                   :", verdict)
    print("PROOF VERDICT                       : OPEN — UNIFORM SPECTRAL DISPLACEMENT THEOREM")
    print("=" * 184)
    print("Files written:")
    for p in [root_path, cutoff_path, mode_path, tail_path, summary_path, theorem_path]:
        print(" ", p)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
