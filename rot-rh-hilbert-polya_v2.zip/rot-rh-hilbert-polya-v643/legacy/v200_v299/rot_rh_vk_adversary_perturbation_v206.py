#!/usr/bin/env python3
"""
ROT-RH v206 — VK-ADVERSARY PERTURBATION / UPPER-HULL ROBUSTNESS AUDIT

Static Monte-Carlo geometry audit.
No root continuation. No Xi / zeta / known zeros.

WHY THIS TEST
-------------
v205 matched the VK logarithmic boundary at ~1e-11 relative scale.  That is
not independent evidence: the synthetic v169 candidates were constructed on
(or essentially on) that boundary.

v206 asks the genuinely independent question:

    Is the infinite-switch / high-gamma upper-hull behavior robust if the
    exact VK gap law is broken?

We perturb each positive candidate gap

    g_j = beta_sup - beta_j

multiplicatively:

    g_j' = g_j * exp(sigma * Z_j),

with iid standard-normal Z_j, while keeping gamma_j fixed.

We then rebuild the entire upper envelope from scratch using the late Gamma
intercept law

    S_j(tau) = (beta_j'-1/2) tau - (pi/2) gamma_j.

For each perturbation level sigma and Monte-Carlo trial, we measure:

  * number of active upper-hull segments on [tau_min,tau_max];
  * highest active gamma reached;
  * last switch time;
  * active-gamma average on [tau_min,tau_max];
  * conservative cumulative switch-cost ratio

        C * sum(Delta gamma/Delta a)
        --------------------------------
        integral gamma_active d tau

    with C inherited from v198.

A trial is counted as "runaway-like" if it retains:
  * many active record switches,
  * active gamma comparable to the unperturbed baseline,
  * a late switch scale comparable to baseline,
  * a small cumulative switch-cost ratio.

This tests ROBUSTNESS OF THE SYNTHETIC OBSTRUCTION ONLY.
It makes no claim about actual zeta-zero geometry.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


PI_OVER_2 = np.pi / 2.0


def upper_hull(lines):
    """
    Upper envelope of lines y = m*x + c for increasing x.

    Input list of dicts with keys m,c,beta,gamma,idx.
    Returns list with added 'start' = x where each line becomes active.

    Lines are sorted by slope. Equal slopes retain only largest intercept.
    """
    ordered = sorted(lines, key=lambda z: (z["m"], z["c"]))

    unique = []
    for z in ordered:
        if unique and abs(z["m"]-unique[-1]["m"]) <= 1e-18:
            # same slope: keep larger intercept
            if z["c"] > unique[-1]["c"]:
                unique[-1] = z
        else:
            unique.append(z)

    hull = []
    starts = []

    for z in unique:
        m = z["m"]
        c = z["c"]

        while hull:
            p = hull[-1]
            den = m-p["m"]
            if den <= 0:
                x = np.inf
            else:
                x = (p["c"]-c)/den

            if len(hull) == 1 or x > starts[-1]:
                break

            hull.pop()
            starts.pop()

        if not hull:
            hull.append(z.copy())
            starts.append(-np.inf)
        else:
            p = hull[-1]
            x = (p["c"]-c)/(m-p["m"])
            zz = z.copy()
            hull.append(zz)
            starts.append(float(x))

    for z, s in zip(hull, starts):
        z["start"] = s

    return hull


def restrict_hull(hull, tau_min, tau_max):
    """
    Convert full hull to active segments intersecting [tau_min,tau_max].
    """
    out = []

    for i,z in enumerate(hull):
        lo = max(float(z["start"]), tau_min)
        hi = tau_max
        if i+1 < len(hull):
            hi = min(float(hull[i+1]["start"]), tau_max)

        if hi <= tau_min or lo >= tau_max or hi <= lo:
            continue

        q = z.copy()
        q["seg_start"] = lo
        q["seg_end"] = hi
        out.append(q)

    return out


def metrics(segments, C):
    if not segments:
        return {
            "active_segments": 0,
            "switches": 0,
            "max_active_gamma": np.nan,
            "terminal_gamma": np.nan,
            "first_active_gamma": np.nan,
            "last_switch_tau": np.nan,
            "active_integral": 0.0,
            "active_average": np.nan,
            "raw_switch_cost": np.nan,
            "majorant_ratio": np.nan,
        }

    active_integral = sum(
        abs(z["gamma"])*(z["seg_end"]-z["seg_start"])
        for z in segments
    )
    total_dt = segments[-1]["seg_end"]-segments[0]["seg_start"]
    active_average = active_integral/max(total_dt, 1e-300)

    raw = 0.0
    for i in range(len(segments)-1):
        a1 = segments[i]["m"]
        a2 = segments[i+1]["m"]
        g1 = abs(segments[i]["gamma"])
        g2 = abs(segments[i+1]["gamma"])
        da = a2-a1
        dg = g2-g1
        if da <= 0:
            raw = np.inf
            break
        raw += abs(dg/da)

    ratio = C*raw/max(active_integral,1e-300)

    last_switch = (
        float(segments[-1]["seg_start"])
        if len(segments) >= 2 else np.nan
    )

    gammas = np.array([abs(z["gamma"]) for z in segments], float)

    return {
        "active_segments": len(segments),
        "switches": max(0,len(segments)-1),
        "max_active_gamma": float(np.max(gammas)),
        "terminal_gamma": float(gammas[-1]),
        "first_active_gamma": float(gammas[0]),
        "last_switch_tau": last_switch,
        "active_integral": float(active_integral),
        "active_average": float(active_average),
        "raw_switch_cost": float(raw),
        "majorant_ratio": float(ratio),
    }


def build_lines(beta, gamma):
    lines = []
    for i,(b,g) in enumerate(zip(beta,gamma)):
        lines.append({
            "idx": i,
            "beta": float(b),
            "gamma": float(g),
            "m": float(b-0.5),
            "c": float(-PI_OVER_2*abs(g)),
        })
    return lines


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--candidates-csv", required=True)

    ap.add_argument("--beta-sup", type=float, default=1.0)
    ap.add_argument("--tau-min", type=float, default=100.0)
    ap.add_argument("--tau-max", type=float, default=1e8)

    ap.add_argument(
        "--sigmas",
        default="0,0.0001,0.0003,0.001,0.003,0.01,0.03,0.05",
        help="Log-gap perturbation standard deviations.",
    )
    ap.add_argument("--trials", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260819)

    ap.add_argument(
        "--majorant-C",
        type=float,
        default=1.284148,
    )

    ap.add_argument(
        "--segment-fraction-gate",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--gamma-fraction-gate",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--last-switch-fraction-gate",
        type=float,
        default=0.10,
    )
    ap.add_argument(
        "--majorant-ratio-gate",
        type=float,
        default=0.02,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_vk_adversary_perturbation_v206",
    )

    args = ap.parse_args()

    df = pd.read_csv(args.candidates_csv)

    if not {"beta","gamma"}.issubset(df.columns):
        raise RuntimeError("Candidates CSV must contain beta and gamma columns.")

    beta0 = df["beta"].to_numpy(float)
    gamma0 = df["gamma"].to_numpy(float)

    # Work with positive-gamma candidate representatives only.
    keep = (
        np.isfinite(beta0)
        & np.isfinite(gamma0)
        & (gamma0 > 0)
        & (beta0 < args.beta_sup)
        & (beta0 > 0.5)
    )

    beta0 = beta0[keep]
    gamma0 = gamma0[keep]

    if len(beta0) < 10:
        raise RuntimeError("Too few positive candidates after filtering.")

    gap0 = args.beta_sup-beta0

    # Baseline reconstructed using pi/2 Gamma intercept law.
    base_hull = upper_hull(build_lines(beta0,gamma0))
    base_seg = restrict_hull(base_hull,args.tau_min,args.tau_max)
    base = metrics(base_seg,args.majorant_C)

    if base["active_segments"] < 2:
        raise RuntimeError("Baseline reconstructed hull has too few segments.")

    sigmas = [
        float(x.strip())
        for x in args.sigmas.split(",")
        if x.strip()
    ]

    rng = np.random.default_rng(args.seed)

    trial_rows = []

    print("="*194)
    print("ROT-RH v206 — VK-ADVERSARY PERTURBATION / UPPER-HULL ROBUSTNESS AUDIT")
    print("="*194)
    print("Xi / zeta / known zeros          : NONE")
    print(f"positive candidates                : {len(beta0)}")
    print(f"tau window                         : [{args.tau_min:.3e},{args.tau_max:.3e}]")
    print(f"majorant C                         : {args.majorant_C:.6f}")
    print("="*194)
    print("BASELINE reconstructed with b=(pi/2)gamma")
    print(f"  active segments                  : {base['active_segments']}")
    print(f"  max active gamma                 : {base['max_active_gamma']:.6e}")
    print(f"  terminal gamma                   : {base['terminal_gamma']:.6e}")
    print(f"  last switch tau                  : {base['last_switch_tau']:.6e}")
    print(f"  active average gamma             : {base['active_average']:.6e}")
    print(f"  majorant cumulative ratio        : {base['majorant_ratio']:.6e}")
    print("="*194)

    for sigma in sigmas:
        ntr = 1 if sigma == 0 else args.trials

        for t in range(ntr):
            if sigma == 0:
                gap = gap0.copy()
            else:
                z = rng.standard_normal(len(gap0))
                gap = gap0*np.exp(sigma*z)

            beta = args.beta_sup-gap

            lines = build_lines(beta,gamma0)
            hull = upper_hull(lines)
            seg = restrict_hull(hull,args.tau_min,args.tau_max)
            m = metrics(seg,args.majorant_C)

            seg_ok = (
                m["active_segments"]
                >= args.segment_fraction_gate*base["active_segments"]
            )
            gamma_ok = (
                np.isfinite(m["max_active_gamma"])
                and m["max_active_gamma"]
                >= args.gamma_fraction_gate*base["max_active_gamma"]
            )
            switch_ok = (
                np.isfinite(m["last_switch_tau"])
                and m["last_switch_tau"]
                >= args.last_switch_fraction_gate*base["last_switch_tau"]
            )
            cost_ok = (
                np.isfinite(m["majorant_ratio"])
                and m["majorant_ratio"] <= args.majorant_ratio_gate
            )

            runaway_like = bool(seg_ok and gamma_ok and switch_ok and cost_ok)

            trial_rows.append({
                "sigma": sigma,
                "trial": t,
                **m,
                "segment_gate_pass": seg_ok,
                "gamma_gate_pass": gamma_ok,
                "late_switch_gate_pass": switch_ok,
                "cost_gate_pass": cost_ok,
                "runaway_like": runaway_like,
            })

    trials = pd.DataFrame(trial_rows)

    summary_rows = []

    for sigma,g in trials.groupby("sigma",sort=True):
        summary_rows.append({
            "sigma": float(sigma),
            "trials": len(g),
            "runaway_fraction": float(np.mean(g["runaway_like"])),
            "segment_gate_fraction": float(np.mean(g["segment_gate_pass"])),
            "gamma_gate_fraction": float(np.mean(g["gamma_gate_pass"])),
            "late_switch_gate_fraction": float(np.mean(g["late_switch_gate_pass"])),
            "cost_gate_fraction": float(np.mean(g["cost_gate_pass"])),
            "active_segments_median": float(np.median(g["active_segments"])),
            "active_segments_q10": float(np.quantile(g["active_segments"],0.10)),
            "active_segments_q90": float(np.quantile(g["active_segments"],0.90)),
            "max_active_gamma_median": float(np.nanmedian(g["max_active_gamma"])),
            "last_switch_tau_median": float(np.nanmedian(g["last_switch_tau"])),
            "majorant_ratio_median": float(np.nanmedian(g["majorant_ratio"])),
            "active_average_median": float(np.nanmedian(g["active_average"])),
        })

    summ = pd.DataFrame(summary_rows).sort_values("sigma")

    # Robustness classification.
    positive = summ[summ["sigma"] > 0].copy()

    # Largest sigma with >=90% runaway-like survival.
    robust90 = positive[positive["runaway_fraction"] >= 0.90]
    sigma90 = (
        float(robust90["sigma"].max())
        if len(robust90) else 0.0
    )

    robust50 = positive[positive["runaway_fraction"] >= 0.50]
    sigma50 = (
        float(robust50["sigma"].max())
        if len(robust50) else 0.0
    )

    if sigma90 >= 0.01:
        verdict = "INFINITE_SWITCH_SYNTHETIC_OBSTRUCTION_PERCENT_LEVEL_ROBUST"
    elif sigma50 >= 0.01:
        verdict = "INFINITE_SWITCH_SYNTHETIC_OBSTRUCTION_MODERATELY_ROBUST"
    elif sigma90 >= 0.001:
        verdict = "INFINITE_SWITCH_SYNTHETIC_OBSTRUCTION_SMALL_PERTURBATION_ROBUST"
    else:
        verdict = "INFINITE_SWITCH_SYNTHETIC_OBSTRUCTION_FINE_TUNING_UNRESOLVED"

    trials.to_csv(args.prefix+"_TRIALS.csv",index=False)
    summ.to_csv(args.prefix+"_SUMMARY_TABLE.csv",index=False)

    js = {
        "version":206,
        "candidate_count":len(beta0),
        "tau_min":args.tau_min,
        "tau_max":args.tau_max,
        "baseline":base,
        "largest_sigma_with_90pct_runaway_survival":sigma90,
        "largest_sigma_with_50pct_runaway_survival":sigma50,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(js,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    for _,r in summ.iterrows():
        print(
            f"sigma={r['sigma']:.4f} "
            f"runaway={r['runaway_fraction']:.3f} "
            f"segments_med={r['active_segments_median']:.1f} "
            f"gammaMax_med={r['max_active_gamma_median']:.3e} "
            f"lastTau_med={r['last_switch_tau_median']:.3e} "
            f"cost_med={r['majorant_ratio_median']:.3e}"
        )

    print()
    print(f"largest sigma with >=90% survival : {sigma90:.6e}")
    print(f"largest sigma with >=50% survival : {sigma50:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*194)


if __name__ == "__main__":
    main()
