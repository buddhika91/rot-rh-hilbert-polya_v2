#!/usr/bin/env python3
"""
ROT-RH v216 — PHASE-RESOLVED THREE-REGION ABSOLUTE BOUND CERTIFICATION

Zero-blind prime-side audit.
No Xi / zeta evaluations / known-zero ordinates.

WHY v216
--------
v215 produced a very strong three-region signal:

    bound max slope all      ~ -0.111
    bound max slope holdout  ~ -0.070
    all sampled energies had negative slopes
    head/tail endpoint scans were monotone at final L

but its verdict was NUMERICAL_QUADRATURE_UNRESOLVED because the continuum
integral was evaluated with only 12 and 24 Gauss-Legendre nodes over some
master t=log(x) intervals spanning several units.

At E=80, such an interval contains hundreds of radians of phase.  The failed
quadrature gate is therefore expected under-resolution, not evidence against
the absolute route.

v216 fixes ONLY the integration.

For each master interval [t0,t1], it splits it into composite subintervals so

    E_max * Delta t <= phase_step,

then applies Gauss-Legendre quadrature on each subinterval.

Two independent resolutions are used:

    coarse phase step = phase_step
    fine phase step   = phase_step / check_factor

The fine result is used in all physics diagnostics.  The global complex-matrix
norm discrepancy between coarse and fine continuum evaluations must satisfy a
strict gate.

The arithmetic decomposition and theorem-shaped three-region bound are the
same as v215:

    |Delta A_L(E)|
      <= |D_head(eps0)|
         + sum_{j=1}^N |D_bulk,j|
         + |D_tail(U0)|.

This script is finite-range numerical evidence only.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def parse_float_list(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def power_slope(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]
    if len(x) < 3:
        return np.nan, np.nan
    lx = np.log(x)
    ly = np.log(y)
    c = np.polyfit(lx, ly, 1)
    pred = np.polyval(c, lx)
    den = np.sum((ly - ly.mean())**2)
    r2 = 1.0 - np.sum((ly-pred)**2)/den if den > 0 else np.nan
    return float(c[0]), float(r2)


def norm_rel(a, b, floor=1e-300):
    return float(
        np.linalg.norm(a-b) /
        max(np.linalg.norm(a), np.linalg.norm(b), floor)
    )


def edge_index(edges, x):
    i = int(np.searchsorted(edges, x))
    if i < len(edges) and np.isclose(edges[i], x, rtol=1e-12, atol=1e-15):
        return i
    if i > 0 and np.isclose(edges[i-1], x, rtol=1e-12, atol=1e-15):
        return i-1
    raise RuntimeError(f"Requested edge {x} not present in master grid.")


def interval_sum(D, edges, lo, hi):
    ilo = edge_index(edges, lo)
    ihi = edge_index(edges, hi)
    return np.sum(D[ilo:ihi, :], axis=0)


def bulk_L1(D, edges, bulk_edges):
    z = []
    for a,b in zip(bulk_edges[:-1], bulk_edges[1:]):
        z.append(interval_sum(D, edges, a, b))
    Z = np.stack(z, axis=0)
    return np.sum(np.abs(Z), axis=0)


def prime_master_shell_matrix(
    n, coeff, logn, energies, L, ratio, edges, chunk
):
    nshell = len(edges)-1
    out = np.zeros((nshell, len(energies)), dtype=np.complex128)

    nf = n.astype(np.float64)
    u = nf/L
    valid = (u >= edges[0]) & (u <= edges[-1])
    idx = np.flatnonzero(valid)

    if len(idx) == 0:
        return out

    sid = np.searchsorted(edges, u[idx], side="right") - 1
    sid = np.clip(sid, 0, nshell-1)

    amp = coeff[idx] * (
        np.exp(-nf[idx]/(ratio*L))
        - np.exp(-nf[idx]/L)
    )
    tt = logn[idx]

    for lo in range(0, len(idx), chunk):
        hi = min(len(idx), lo+chunk)
        t = tt[lo:hi]
        a = amp[lo:hi]
        s = sid[lo:hi]

        phase = np.exp(1j*t[:,None]*energies[None,:])
        z = a[:,None]*phase

        for k in range(len(energies)):
            re = np.bincount(s, weights=z[:,k].real, minlength=nshell)
            im = np.bincount(s, weights=z[:,k].imag, minlength=nshell)
            out[:,k] += re + 1j*im

    return out


def continuum_phase_resolved(
    edges,
    energies,
    L,
    ratio,
    gl_nodes,
    phase_step,
):
    """
    Composite Gauss-Legendre on t=log x.

    Each master interval is subdivided until
        max(|E|,1) * dt <= phase_step.
    """
    nshell = len(edges)-1
    out = np.zeros((nshell, len(energies)), dtype=np.complex128)

    gx, gw = np.polynomial.legendre.leggauss(gl_nodes)
    log2 = math.log(2.0)
    emax = max(float(np.max(np.abs(energies))), 1.0)

    tedges = np.log(L*edges)

    total_subintervals = 0

    for j in range(nshell):
        a = max(float(tedges[j]), log2)
        b = float(tedges[j+1])

        if b <= a:
            continue

        width = b-a
        nsub = max(1, int(math.ceil(emax*width/phase_step)))
        total_subintervals += nsub

        # Process each subinterval.  Number is modest (~few thousand total).
        acc = np.zeros(len(energies), dtype=np.complex128)

        for q in range(nsub):
            aa = a + width*q/nsub
            bb = a + width*(q+1)/nsub

            mid = 0.5*(aa+bb)
            half = 0.5*(bb-aa)

            t = mid + half*gx
            w = half*gw
            x = np.exp(t)

            dw = (
                np.exp(-x/(ratio*L))
                - np.exp(-x/L)
            )

            base = w*np.exp(0.5*t)*dw/t
            phase = np.exp(1j*t[:,None]*energies[None,:])

            acc += np.sum(base[:,None]*phase, axis=0)

        out[j,:] = acc

    return out, total_subintervals


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--v212-module",
                    default="rot_rh_euler_product_coupling_v212")
    ap.add_argument("--L-list",
                    default="4000,8000,16000,32000,64000,128000,256000")
    ap.add_argument("--ratio", type=float, default=2.0)

    ap.add_argument("--emin", type=float, default=10.0)
    ap.add_argument("--emax", type=float, default=80.0)
    ap.add_argument("--energy-count", type=int, default=29)
    ap.add_argument("--energy-values", default="")

    ap.add_argument("--head-eps-values",
                    default="0.001,0.002,0.005,0.01,0.02,0.05")
    ap.add_argument("--baseline-eps", type=float, default=0.01)

    ap.add_argument("--tail-U-values",
                    default="8,12,16,24,32")
    ap.add_argument("--baseline-U", type=float, default=16.0)

    ap.add_argument("--bulk-shells", type=int, default=80)
    ap.add_argument("--u-trunc", type=float, default=64.0)

    ap.add_argument("--gl-nodes", type=int, default=8)
    ap.add_argument("--phase-step", type=float, default=0.50,
                    help="Maximum Emax*dt on coarse composite subinterval.")
    ap.add_argument("--phase-check-factor", type=float, default=2.0)
    ap.add_argument("--quad-norm-rel-gate", type=float, default=1e-9)

    ap.add_argument("--prime-chunk", type=int, default=65536)
    ap.add_argument("--holdout-points", type=int, default=4)

    ap.add_argument("--bound-all-slope-gate", type=float, default=-0.02)
    ap.add_argument("--bound-holdout-slope-gate", type=float, default=-0.01)
    ap.add_argument("--negative-energy-fraction-gate", type=float, default=0.90)
    ap.add_argument("--endpoint-monotonic-fraction-gate",
                    type=float, default=0.80)

    ap.add_argument("--prefix",
                    default="rot_rh_phase_resolved_three_region_v216")

    args = ap.parse_args()
    v212 = importlib.import_module(args.v212_module)

    Ls = np.asarray(parse_float_list(args.L_list), dtype=float)
    if np.any(np.diff(Ls) <= 0):
        raise RuntimeError("L-list must be increasing.")

    if args.energy_values.strip():
        energies = np.asarray(parse_float_list(args.energy_values), dtype=float)
    else:
        energies = np.linspace(args.emin, args.emax, args.energy_count)

    head_eps = sorted(set(parse_float_list(args.head_eps_values)))
    tail_Us = sorted(set(parse_float_list(args.tail_U_values)))

    if args.baseline_eps not in head_eps:
        head_eps.append(args.baseline_eps)
        head_eps.sort()
    if args.baseline_U not in tail_Us:
        tail_Us.append(args.baseline_U)
        tail_Us.sort()

    Lmax = float(np.max(Ls))
    u_min = 2.0/Lmax

    bulk_edges = np.geomspace(
        args.baseline_eps,
        args.baseline_U,
        args.bulk_shells+1,
    )

    raw_edges = [
        u_min,
        *head_eps,
        *bulk_edges.tolist(),
        *tail_Us,
        args.u_trunc,
    ]
    master_edges = np.asarray(sorted(set(float(x) for x in raw_edges)))
    master_edges = master_edges[master_edges >= u_min*(1-1e-15)]

    nmax = int(math.ceil(args.u_trunc*Lmax))

    print("="*202)
    print("ROT-RH v216 — PHASE-RESOLVED THREE-REGION ABSOLUTE BOUND CERTIFICATION")
    print("="*202)
    print("Xi / zeta / known zeros          : NONE")
    print(f"L values                          : {Ls.tolist()}")
    print(f"energies                          : {len(energies)} over [{energies.min():.3f},{energies.max():.3f}]")
    print(f"full-support u_min                : {u_min:.12e}")
    print(f"baseline bulk                     : [{args.baseline_eps},{args.baseline_U}] with {args.bulk_shells} shells")
    print(f"u truncation                      : {args.u_trunc}")
    print(f"master shells                     : {len(master_edges)-1}")
    print(f"GL nodes/subinterval              : {args.gl_nodes}")
    print(f"coarse phase step                 : {args.phase_step}")
    print(f"fine phase step                   : {args.phase_step/args.phase_check_factor}")
    print(f"nmax                              : {nmax}")
    print(f"long exponential at u_trunc       : {math.exp(-args.u_trunc/args.ratio):.6e}")
    print("="*202)

    n, exponents, coeff, primes = v212.build_prime_powers(nmax)
    logn = np.log(n.astype(np.float64))

    print(f"primes <= nmax                    : {len(primes)}")
    print(f"prime powers incl primes          : {len(n)}")

    head_data = {
        eps: np.zeros((len(Ls),len(energies)), dtype=float)
        for eps in head_eps
    }
    tail_data = {
        U: np.zeros((len(Ls),len(energies)), dtype=float)
        for U in tail_Us
    }

    bulk_data = np.zeros((len(Ls),len(energies)), dtype=float)
    bound_data = np.zeros((len(Ls),len(energies)), dtype=float)
    actual_data = np.zeros((len(Ls),len(energies)), dtype=float)

    qrels = []
    rows = []

    for i,L in enumerate(Ls):
        P = prime_master_shell_matrix(
            n=n, coeff=coeff, logn=logn, energies=energies,
            L=float(L), ratio=args.ratio, edges=master_edges,
            chunk=args.prime_chunk,
        )

        Mcoarse, nsub_c = continuum_phase_resolved(
            master_edges, energies, float(L), args.ratio,
            args.gl_nodes, args.phase_step,
        )
        Mfine, nsub_f = continuum_phase_resolved(
            master_edges, energies, float(L), args.ratio,
            args.gl_nodes, args.phase_step/args.phase_check_factor,
        )

        qrel = norm_rel(Mcoarse, Mfine)
        qrels.append(qrel)

        D = P-Mfine

        for eps in head_eps:
            z = interval_sum(D, master_edges, u_min, eps)
            head_data[eps][i,:] = np.abs(z)

        for U in tail_Us:
            z = interval_sum(D, master_edges, U, args.u_trunc)
            tail_data[U][i,:] = np.abs(z)

        bulk = bulk_L1(D, master_edges, bulk_edges)
        bulk_data[i,:] = bulk

        head0 = head_data[args.baseline_eps][i,:]
        tail0 = tail_data[args.baseline_U][i,:]

        B = head0 + bulk + tail0
        bound_data[i,:] = B

        actual = np.abs(np.sum(D,axis=0))
        actual_data[i,:] = actual

        row = {
            "L":float(L),
            "head_max":float(np.max(head0)),
            "bulk_L1_max":float(np.max(bulk)),
            "tail_max":float(np.max(tail0)),
            "bound_max":float(np.max(B)),
            "actual_max":float(np.max(actual)),
            "quad_norm_rel":qrel,
            "coarse_subintervals":nsub_c,
            "fine_subintervals":nsub_f,
        }
        rows.append(row)

        print(
            f"L={L:10.0f} "
            f"head={row['head_max']:.3e} "
            f"bulk={row['bulk_L1_max']:.3e} "
            f"tail={row['tail_max']:.3e} "
            f"BOUND={row['bound_max']:.3e} "
            f"actual={row['actual_max']:.3e} "
            f"q={qrel:.3e} "
            f"sub={nsub_c}/{nsub_f}"
        )

    hp = args.holdout_points
    holdL = Ls[-hp:]

    bmax = np.max(bound_data,axis=1)
    brms = np.sqrt(np.mean(bound_data**2,axis=1))

    p_all,r_all = power_slope(Ls,bmax)
    p_hold,r_hold = power_slope(holdL,bmax[-hp:])
    p_rms,r_rms = power_slope(Ls,brms)

    energy_slopes = []
    energy_hold_slopes = []
    for k in range(len(energies)):
        p,_ = power_slope(Ls,bound_data[:,k])
        ph,_ = power_slope(holdL,bound_data[-hp:,k])
        energy_slopes.append(p)
        energy_hold_slopes.append(ph)

    energy_slopes = np.asarray(energy_slopes)
    energy_hold_slopes = np.asarray(energy_hold_slopes)

    neg_frac = float(np.mean(energy_slopes < 0))
    neg_hold_frac = float(np.mean(energy_hold_slopes < 0))

    # Final-L endpoint monotonicity.
    head_final = np.asarray([
        np.max(head_data[eps][-1,:]) for eps in head_eps
    ])
    tail_final = np.asarray([
        np.max(tail_data[U][-1,:]) for U in tail_Us
    ])

    head_mon = float(np.mean(np.diff(head_final) >= 0)) if len(head_final)>1 else 1.0
    tail_mon = float(np.mean(np.diff(tail_final) <= 0)) if len(tail_final)>1 else 1.0

    head_rows = []
    for eps in head_eps:
        y = np.max(head_data[eps],axis=1)
        p,r = power_slope(Ls,y)
        ph,rh = power_slope(holdL,y[-hp:])
        head_rows.append({
            "eps":eps,
            "slope_all":p,
            "R2_all":r,
            "slope_holdout":ph,
            "R2_holdout":rh,
            "final_max":float(y[-1]),
        })

    tail_rows = []
    for U in tail_Us:
        y = np.max(tail_data[U],axis=1)
        p,r = power_slope(Ls,y)
        ph,rh = power_slope(holdL,y[-hp:])
        tail_rows.append({
            "U":U,
            "slope_all":p,
            "R2_all":r,
            "slope_holdout":ph,
            "R2_holdout":rh,
            "final_max":float(y[-1]),
        })

    hdf = pd.DataFrame(head_rows)
    tdf = pd.DataFrame(tail_rows)
    ldf = pd.DataFrame(rows)

    quad_pass = bool(max(qrels) <= args.quad_norm_rel_gate)
    bound_pass = bool(
        p_all <= args.bound_all_slope_gate
        and p_hold <= args.bound_holdout_slope_gate
        and neg_frac >= args.negative_energy_fraction_gate
        and neg_hold_frac >= args.negative_energy_fraction_gate
    )
    endpoint_pass = bool(
        head_mon >= args.endpoint_monotonic_fraction_gate
        and tail_mon >= args.endpoint_monotonic_fraction_gate
    )

    if quad_pass and bound_pass and endpoint_pass:
        verdict = "PHASE_RESOLVED_THREE_REGION_ABSOLUTE_BOUND_STRONGLY_SUPPORTED"
    elif quad_pass and bound_pass:
        verdict = "PHASE_RESOLVED_ABSOLUTE_BOUND_ENDPOINT_PARTIAL"
    elif not quad_pass:
        verdict = "PHASE_RESOLVED_QUADRATURE_STILL_UNRESOLVED"
    else:
        verdict = "THREE_REGION_ABSOLUTE_ROUTE_UNRESOLVED"

    ldf.to_csv(args.prefix+"_L_VALUES.csv",index=False)
    hdf.to_csv(args.prefix+"_HEAD.csv",index=False)
    tdf.to_csv(args.prefix+"_TAIL.csv",index=False)

    summary = {
        "version":216,
        "firewall":"Xi / zeta / known zeros: NONE",
        "L_values":Ls.tolist(),
        "energies":energies.tolist(),
        "u_min_full_support":u_min,
        "baseline_eps":args.baseline_eps,
        "baseline_U":args.baseline_U,
        "bulk_shells":args.bulk_shells,
        "u_trunc":args.u_trunc,
        "gl_nodes":args.gl_nodes,
        "coarse_phase_step":args.phase_step,
        "fine_phase_step":args.phase_step/args.phase_check_factor,
        "max_continuum_quadrature_norm_relative_discrepancy":float(max(qrels)),
        "bound_max_slope_all":p_all,
        "bound_max_R2_all":r_all,
        "bound_max_slope_holdout":p_hold,
        "bound_max_R2_holdout":r_hold,
        "bound_RMS_slope_all":p_rms,
        "bound_RMS_R2_all":r_rms,
        "negative_energy_fraction_all":neg_frac,
        "negative_energy_fraction_holdout":neg_hold_frac,
        "head_final_monotonic_fraction":head_mon,
        "tail_final_monotonic_fraction":tail_mon,
        "final_head_baseline_max":float(np.max(head_data[args.baseline_eps][-1,:])),
        "final_bulk_L1_max":float(np.max(bulk_data[-1,:])),
        "final_tail_baseline_max":float(np.max(tail_data[args.baseline_U][-1,:])),
        "final_bound_max":float(np.max(bound_data[-1,:])),
        "final_actual_max":float(np.max(actual_data[-1,:])),
        "quad_pass":quad_pass,
        "bound_pass":bound_pass,
        "endpoint_pass":endpoint_pass,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*202)
    print("PHASE-RESOLVED CERTIFICATION")
    print(f"max quadrature norm-relative diff : {max(qrels):.6e}")
    print(f"bound max slope all               : {p_all:.9f}  R2={r_all:.6f}")
    print(f"bound max slope holdout           : {p_hold:.9f}  R2={r_hold:.6f}")
    print(f"bound RMS slope all               : {p_rms:.9f}  R2={r_rms:.6f}")
    print(f"negative energy fraction all      : {neg_frac:.6f}")
    print(f"negative energy fraction holdout  : {neg_hold_frac:.6f}")
    print(f"head final monotonic fraction     : {head_mon:.6f}")
    print(f"tail final monotonic fraction     : {tail_mon:.6f}")

    print()
    print("HEAD SCAN")
    for _,r in hdf.iterrows():
        print(
            f"eps={r['eps']:.4g} "
            f"pAll={r['slope_all']:.6f} "
            f"pHold={r['slope_holdout']:.6f} "
            f"final={r['final_max']:.6e}"
        )

    print()
    print("TAIL SCAN")
    for _,r in tdf.iterrows():
        print(
            f"U={r['U']:.4g} "
            f"pAll={r['slope_all']:.6f} "
            f"pHold={r['slope_holdout']:.6f} "
            f"final={r['final_max']:.6e}"
        )

    print()
    print(f"VERDICT                           : {verdict}")
    print("="*202)


if __name__ == "__main__":
    main()
