#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v253 — CENTERED-MANGOLDT MAXIMAL DYADIC PARTIAL-SUM AUDIT
================================================================

Purpose
-------
v252 found that endpoint dyadic centered-Mangoldt shell amplitudes have positive
raw decay exponents on the tested panel, but endpoint shell sums alone are not
enough to control the exponentially weighted shell.

The theorem-relevant object is the MAXIMAL raw partial sum inside a dyadic shell:

    A_k(X,Y)
      = sum_{X<=n<=Y}
          q_n n^{iE_k}/(sqrt(n) log n),

    M_k(X)
      = sup_{X<=Y<2X} |A_k(X,Y)|,

where
    q_2 = Lambda(2)-2,
    q_n = Lambda(n)-1 for n>=3.

For the decreasing regulator w_L(n)=exp(-n/L), discrete Abel summation gives

    |sum_{X<=n<2X} q_n w_L(n) n^{iE}/(sqrt(n)log n)|
      <= w_L(X) M_k(X)
      <= M_k(X).

Therefore, if for some p>0

    M_k(X) <= C X^{-p}

uniformly in high k and dyadic X, then

    sum_j M_k(2^j) < infinity,

which gives a cutoff-uniform absolute bound for the frozen critical transform.

v253:
* computes the exact integer-by-integer M_k(X) on each tested dyadic shell;
* cross-checks the shell endpoint against v252 raw shell sums;
* verifies the Abel weighted-shell inequality against v252;
* freezes a common positive p and global C using TRAINING shells only;
* tests later dyadic shells prospectively.

This remains a finite numerical audit, not an all-k/all-X proof.

No Xi, zeta values, or known zero ordinates are used.

Version: 253
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 253
EPS = np.finfo(float).eps


def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def fit_power(X, M):
    X = np.asarray(X, float)
    M = np.asarray(M, float)
    keep = np.isfinite(X) & np.isfinite(M) & (X > 0) & (M > 0)
    X = X[keep]
    M = M[keep]

    if len(X) < 3:
        return dict(n=int(len(X)), p=np.nan, r2=np.nan, C=np.nan)

    x = np.log(X)
    y = np.log(M)
    A = np.column_stack([np.ones(len(x)), x])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = A @ beta
    sse = float(np.sum((y - pred) ** 2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0

    return dict(
        n=int(len(X)),
        p=float(-beta[1]),
        r2=float(r2),
        C=float(math.exp(beta[0])),
    )


def shell_partial_maxima(
    energies,
    lo,
    hi,
    numbers,
    lambdas,
    integer_chunk,
):
    """
    Exact integer-by-integer maximal complex partial sum on [lo, hi].

    q_n = Lambda(n)-1, except q_2=Lambda(2)-2.
    """
    energies = np.asarray(energies, float)
    running = np.zeros(len(energies), dtype=np.complex128)
    max_abs = np.zeros(len(energies), float)
    argmax_n = np.full(len(energies), int(lo), int)

    chunk = max(4096, int(integer_chunk))
    start = int(lo)

    while start <= int(hi):
        stop = min(start + chunk - 1, int(hi))
        n_int = np.arange(start, stop + 1, dtype=int)
        n = n_int.astype(float)

        # Dense centered coefficient q_n.
        q = -np.ones(len(n), float)

        left = int(np.searchsorted(numbers, start, side="left"))
        right = int(np.searchsorted(numbers, stop, side="right"))
        if right > left:
            idx = numbers[left:right] - start
            q[idx] += lambdas[left:right]

        if start <= 2 <= stop:
            q[2 - start] -= 1.0

        logn = np.log(n)
        coeff = q / (np.sqrt(n) * logn)

        phase = np.exp(
            1j * np.outer(energies, logn)
        )
        vals = phase * coeff[None, :]

        cs = np.cumsum(vals, axis=1)
        cs += running[:, None]

        abs_cs = np.abs(cs)
        loc = np.argmax(abs_cs, axis=1)
        loc_abs = abs_cs[np.arange(len(energies)), loc]

        improve = loc_abs > max_abs
        if np.any(improve):
            max_abs[improve] = loc_abs[improve]
            argmax_n[improve] = (
                start + loc[improve]
            )

        running = cs[:, -1]
        start = stop + 1

    return running, max_abs, argmax_n


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v249-pairs",
        default="rot_rh_direct_endpoint_secant_v249_PAIRS.csv",
    )
    ap.add_argument(
        "--v252-shells",
        default="rot_rh_centered_mangoldt_shells_v252_SHELLS.csv.gz",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--reference-cutoff", type=int, default=4000)
    ap.add_argument(
        "--k-values",
        default="257,320,384,512,640,768,896,1024,1152,1280,1408",
    )
    ap.add_argument("--shell-min", type=int, default=4096)
    ap.add_argument(
        "--training-shell-max",
        type=int,
        default=262144,
    )
    ap.add_argument(
        "--integer-chunk",
        type=int,
        default=131072,
    )

    ap.add_argument(
        "--p-safety-fraction",
        type=float,
        default=0.75,
        help="Freeze p = fraction * minimum training per-mode fitted p.",
    )
    ap.add_argument(
        "--envelope-safety-factor",
        type=float,
        default=1.25,
    )
    ap.add_argument(
        "--endpoint-crosscheck-tol",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--abel-inequality-slack",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--require-positive-frozen-p",
        action="store_true",
    )
    ap.add_argument(
        "--require-holdout-envelope",
        action="store_true",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_centered_mangoldt_maximal_dyadic_v253",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()

    if args.shell_min < 2:
        raise ValueError("--shell-min must be >=2")
    if args.training_shell_max < args.shell_min:
        raise ValueError(
            "--training-shell-max must be >= --shell-min"
        )
    if not (0.0 < args.p_safety_fraction <= 1.0):
        raise ValueError("--p-safety-fraction must be in (0,1]")
    if args.envelope_safety_factor <= 1.0:
        raise ValueError("--envelope-safety-factor must be >1")
    if args.integer_chunk < 4096:
        raise ValueError("--integer-chunk must be >=4096")

    # --------------------------------------------------------------
    # Anchor energies
    # --------------------------------------------------------------
    v249 = pd.read_csv(args.v249_pairs)
    need249 = {"k", "L0", "E0"}
    miss = need249 - set(v249.columns)
    if miss:
        raise KeyError(f"v249 pairs missing {sorted(miss)}")

    v249["k"] = v249["k"].astype(int)
    v249["L0"] = v249["L0"].astype(int)

    L0 = int(args.reference_cutoff)
    ks_req = parse_ints(args.k_values)

    anchors = (
        v249[
            (v249["L0"] == L0)
            & (v249["k"].isin(ks_req))
        ][["k", "E0"]]
        .drop_duplicates("k")
        .sort_values("k")
    )

    ks = anchors["k"].astype(int).tolist()
    if sorted(ks) != sorted(ks_req):
        missing = sorted(set(ks_req) - set(ks))
        raise RuntimeError(
            "Missing anchor energies for k="
            + ",".join(map(str, missing))
        )

    energies = anchors["E0"].to_numpy(float)

    # --------------------------------------------------------------
    # Use v252 to define the exact shell range and for cross-checks.
    # Raw shell values are duplicated across L, so keep one row/shell/k.
    # --------------------------------------------------------------
    v252 = pd.read_csv(args.v252_shells)
    need252 = {
        "k", "L", "shell_index", "n_lo", "n_hi",
        "raw_real", "raw_imag",
        "weighted_real", "weighted_imag",
    }
    miss = need252 - set(v252.columns)
    if miss:
        raise KeyError(f"v252 shells missing {sorted(miss)}")

    for c in ("k", "L", "shell_index", "n_lo", "n_hi"):
        v252[c] = v252[c].astype(int)

    v252 = v252[v252["k"].isin(ks)].copy()

    raw_ref = (
        v252.sort_values("L")
        .drop_duplicates(["k", "shell_index"])
        .copy()
    )

    shell_table = (
        raw_ref[
            ["shell_index", "n_lo", "n_hi"]
        ]
        .drop_duplicates()
        .sort_values("shell_index")
    )
    shell_table = shell_table[
        shell_table["n_lo"] >= int(args.shell_min)
    ].copy()

    if shell_table.empty:
        raise RuntimeError("No shells at/above --shell-min")

    Nmax = int(shell_table["n_hi"].max())
    training_shells = shell_table[
        shell_table["n_lo"] <= int(args.training_shell_max)
    ]
    holdout_shells = shell_table[
        shell_table["n_lo"] > int(args.training_shell_max)
    ]

    if len(training_shells) < 4:
        raise RuntimeError("Need at least four training shells")
    if len(holdout_shells) < 2:
        raise RuntimeError("Need at least two holdout shells")

    base = importlib.import_module(args.base_module)

    print("=" * 194)
    print(
        "ROT-RH v253 — CENTERED-MANGOLDT MAXIMAL DYADIC "
        "PARTIAL-SUM AUDIT"
    )
    print("=" * 194)
    print("Xi / zeta / known-zero data        : NONE")
    print(f"reference cutoff                    : {L0}")
    print(f"high modes                          : {ks}")
    print(f"shell minimum X                     : {args.shell_min}")
    print(
        f"training shell max X                : "
        f"{args.training_shell_max}"
    )
    print(f"maximum shell endpoint              : {Nmax}")
    print(
        f"training / holdout shells           : "
        f"{len(training_shells)} / {len(holdout_shells)}"
    )
    print("=" * 194)

    print(f"[1] Shared Mangoldt sieve through N={Nmax}")
    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(numbers, int)
    lambdas = np.asarray(lambdas, float)

    # --------------------------------------------------------------
    # Exact shell maximal partial sums.
    # --------------------------------------------------------------
    rows = []

    print("[2] Exact integer-by-integer maximal partial sums")
    for rr in tqdm(
        list(shell_table.itertuples(index=False)),
        desc="dyadic maximal shells",
        unit="shell",
    ):
        endpoint, max_abs, argmax_n = shell_partial_maxima(
            energies=energies,
            lo=int(rr.n_lo),
            hi=int(rr.n_hi),
            numbers=numbers,
            lambdas=lambdas,
            integer_chunk=int(args.integer_chunk),
        )

        X = float(rr.n_lo)
        for i, k in enumerate(ks):
            rows.append({
                "k": int(k),
                "shell_index": int(rr.shell_index),
                "X": int(rr.n_lo),
                "n_hi": int(rr.n_hi),
                "E_anchor": float(energies[i]),
                "endpoint_real": float(np.real(endpoint[i])),
                "endpoint_imag": float(np.imag(endpoint[i])),
                "endpoint_abs": float(abs(endpoint[i])),
                "max_partial_abs": float(max_abs[i]),
                "argmax_n": int(argmax_n[i]),
                "argmax_fraction": float(
                    (argmax_n[i] - rr.n_lo)
                    / max(rr.n_hi - rr.n_lo, 1)
                ),
                "endpoint_over_max": float(
                    abs(endpoint[i]) / max(max_abs[i], EPS)
                ),
                "is_training": bool(
                    int(rr.n_lo) <= int(args.training_shell_max)
                ),
                "is_holdout": bool(
                    int(rr.n_lo) > int(args.training_shell_max)
                ),
            })

    maxima = pd.DataFrame(rows)

    # --------------------------------------------------------------
    # Exact endpoint cross-check against v252 raw shell sums.
    # --------------------------------------------------------------
    cross = maxima.merge(
        raw_ref[
            [
                "k", "shell_index", "n_lo",
                "raw_real", "raw_imag",
            ]
        ].rename(columns={"n_lo": "X"}),
        on=["k", "shell_index", "X"],
        how="left",
        validate="one_to_one",
    )

    cross["endpoint_crosscheck_error"] = np.abs(
        (
            cross["endpoint_real"].to_numpy(float)
            + 1j * cross["endpoint_imag"].to_numpy(float)
        )
        -
        (
            cross["raw_real"].to_numpy(float)
            + 1j * cross["raw_imag"].to_numpy(float)
        )
    )
    max_endpoint_cross = float(
        cross["endpoint_crosscheck_error"].max()
    )

    # --------------------------------------------------------------
    # Verify the Abel inequality numerically for every v252 weighted shell:
    #
    #   |weighted shell| <= exp(-X/L) * M_k(X)
    #
    # Since v252 sums to a common global Nmax rather than each 18L truncation,
    # the same monotone-weight inequality applies on every shell.
    # --------------------------------------------------------------
    abel = v252.merge(
        maxima[
            ["k", "shell_index", "X", "max_partial_abs"]
        ],
        left_on=["k", "shell_index", "n_lo"],
        right_on=["k", "shell_index", "X"],
        how="inner",
    )

    weighted_abs = np.abs(
        abel["weighted_real"].to_numpy(float)
        + 1j * abel["weighted_imag"].to_numpy(float)
    )
    wX = np.exp(
        -abel["n_lo"].to_numpy(float)
        / abel["L"].to_numpy(float)
    )
    abel_bound = (
        wX * abel["max_partial_abs"].to_numpy(float)
    )

    abel["weighted_abs"] = weighted_abs
    abel["abel_bound"] = abel_bound
    abel["weighted_over_abel_bound"] = (
        weighted_abs
        / np.maximum(abel_bound, EPS)
    )
    max_abel_ratio = float(
        abel["weighted_over_abel_bound"].max()
    )

    # --------------------------------------------------------------
    # Training fits and common frozen p.
    # --------------------------------------------------------------
    mode_rows = []
    train_p = []

    for k, g in maxima.groupby("k", sort=True):
        tr = g[g["is_training"]].sort_values("X")
        ho = g[g["is_holdout"]].sort_values("X")

        fit = fit_power(
            tr["X"].to_numpy(float),
            tr["max_partial_abs"].to_numpy(float),
        )
        train_p.append(float(fit["p"]))

        mode_rows.append({
            "k": int(k),
            "training_fit_p": float(fit["p"]),
            "training_fit_r2": float(fit["r2"]),
            "training_max_partial": float(
                tr["max_partial_abs"].max()
            ),
            "holdout_max_partial": float(
                ho["max_partial_abs"].max()
            ),
            "holdout_over_training_max": float(
                ho["max_partial_abs"].max()
                / max(tr["max_partial_abs"].max(), EPS)
            ),
            "minimum_endpoint_over_max_training": float(
                tr["endpoint_over_max"].min()
            ),
            "minimum_endpoint_over_max_holdout": float(
                ho["endpoint_over_max"].min()
            ),
        })

    mode_df = pd.DataFrame(mode_rows)

    min_training_p = float(np.min(train_p))
    frozen_p = float(
        max(0.0, args.p_safety_fraction * min_training_p)
    )

    train_all = maxima[maxima["is_training"]].copy()
    hold_all = maxima[maxima["is_holdout"]].copy()

    if frozen_p > 0:
        C_train_raw = float(np.max(
            train_all["max_partial_abs"].to_numpy(float)
            * (
                train_all["X"].to_numpy(float)
                ** frozen_p
            )
        ))
        frozen_C = (
            float(args.envelope_safety_factor)
            * C_train_raw
        )

        maxima["envelope"] = (
            frozen_C
            * maxima["X"].to_numpy(float) ** (-frozen_p)
        )
        maxima["envelope_margin"] = (
            maxima["envelope"].to_numpy(float)
            / np.maximum(
                maxima["max_partial_abs"].to_numpy(float),
                EPS,
            )
        )
        maxima["envelope_pass"] = (
            maxima["max_partial_abs"]
            <= maxima["envelope"]
        )

        holdout_pass = bool(
            maxima[maxima["is_holdout"]]["envelope_pass"].all()
        )
        min_holdout_margin = float(
            maxima[maxima["is_holdout"]][
                "envelope_margin"
            ].min()
        )

        # Geometric dyadic tail bound beginning at first holdout X.
        X0 = float(
            maxima[maxima["is_holdout"]]["X"].min()
        )
        ratio = 2.0 ** (-frozen_p)
        geometric_tail_bound = float(
            frozen_C * X0 ** (-frozen_p)
            / max(1.0 - ratio, EPS)
        )
    else:
        frozen_C = float("nan")
        holdout_pass = False
        min_holdout_margin = float("nan")
        geometric_tail_bound = float("inf")

        maxima["envelope"] = np.nan
        maxima["envelope_margin"] = np.nan
        maxima["envelope_pass"] = False

    # Per-mode holdout envelope stats after frozen p/C are known.
    final_mode_rows = []
    for r in mode_rows:
        k = int(r["k"])
        g = maxima[maxima["k"] == k]
        ho = g[g["is_holdout"]]
        rr = dict(r)
        rr.update({
            "frozen_common_p": frozen_p,
            "minimum_holdout_envelope_margin": (
                float(ho["envelope_margin"].min())
                if frozen_p > 0 else np.nan
            ),
            "all_holdouts_pass": (
                bool(ho["envelope_pass"].all())
                if frozen_p > 0 else False
            ),
        })
        final_mode_rows.append(rr)

    modes = pd.DataFrame(final_mode_rows)

    gates = {
        "v252_endpoint_crosscheck_pass": bool(
            max_endpoint_cross <= args.endpoint_crosscheck_tol
        ),
        "discrete_abel_inequality_pass": bool(
            max_abel_ratio
            <= 1.0 + args.abel_inequality_slack
        ),
        "frozen_common_p_positive": bool(frozen_p > 0.0),
        "prospective_holdout_envelope_pass": bool(holdout_pass),
    }

    failed = []
    for name, ok in gates.items():
        required = True
        if name == "frozen_common_p_positive":
            required = bool(args.require_positive_frozen_p)
        if name == "prospective_holdout_envelope_pass":
            required = bool(args.require_holdout_envelope)
        if required and not ok:
            failed.append(name)

    if frozen_p > 0 and holdout_pass:
        mechanism = (
            "POSITIVE_MAXIMAL_DYADIC_DECAY_SURVIVES_HOLDOUTS"
        )
    elif frozen_p > 0:
        mechanism = (
            "POSITIVE_TRAINING_DYADIC_DECAY_FAILS_HOLDOUT_ENVELOPE"
        )
    else:
        mechanism = (
            "NO_COMMON_POSITIVE_MAXIMAL_DYADIC_DECAY_ON_TRAINING"
        )

    verdict = (
        "MAXIMAL_DYADIC_PARTIAL_SUM_AUDIT_VERIFIED"
        if not failed
        else
        "MAXIMAL_DYADIC_PARTIAL_SUM_AUDIT_GATE_FAILURE"
    )

    prefix = args.prefix
    maxima_path = Path(prefix + "_MAXIMA.csv.gz")
    modes_path = Path(prefix + "_MODES.csv")
    cross_path = Path(prefix + "_V252_ENDPOINT_CROSSCHECK.csv")
    abel_path = Path(prefix + "_ABEL_INEQUALITY.csv.gz")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_NEXT_THEOREM.md")

    maxima.to_csv(
        maxima_path, index=False, compression="gzip"
    )
    modes.to_csv(modes_path, index=False)
    cross.to_csv(cross_path, index=False)
    abel.to_csv(
        abel_path, index=False, compression="gzip"
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
        },
        "panel": {
            "reference_cutoff": L0,
            "k_values": ks,
            "shell_min": int(args.shell_min),
            "training_shell_max": int(args.training_shell_max),
            "maximum_shell_endpoint": Nmax,
            "training_shells": int(len(training_shells)),
            "holdout_shells": int(len(holdout_shells)),
        },
        "identities": {
            "maximum_v252_endpoint_crosscheck_error": (
                max_endpoint_cross
            ),
            "maximum_weighted_over_Abel_bound": max_abel_ratio,
        },
        "training_envelope": {
            "minimum_training_mode_fit_p": min_training_p,
            "p_safety_fraction": float(args.p_safety_fraction),
            "frozen_common_p": frozen_p,
            "envelope_safety_factor": float(
                args.envelope_safety_factor
            ),
            "frozen_C": frozen_C,
        },
        "holdout": {
            "all_holdouts_pass": holdout_pass,
            "minimum_holdout_margin": min_holdout_margin,
            "geometric_tail_bound_from_first_holdout": (
                geometric_tail_bound
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "analytic_reduction": {
            "maximal_partial_sum": (
                "M_k(X)=sup_{X<=Y<2X}|sum_{X<=n<=Y} "
                "q_n n^{iE_k}/(sqrt(n)log n)|"
            ),
            "Abel_bound": (
                "|weighted dyadic shell| <= exp(-X/L) M_k(X) <= M_k(X)"
            ),
            "sufficient_tail_theorem": (
                "If M_k(X)<=C X^{-p} uniformly for some p>0, "
                "then dyadic shell sums are absolutely summable uniformly in L."
            ),
        },
        "proof_status": (
            "OPEN. v253 computes exact finite-shell maxima and a prospective "
            "envelope only. Proving a uniform positive p for all sufficiently "
            "large dyadic X and all high arithmetic anchor energies remains "
            "the analytic theorem."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }
    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    if mechanism == (
        "POSITIVE_MAXIMAL_DYADIC_DECAY_SURVIVES_HOLDOUTS"
    ):
        next_text = (
            "# v253 next theorem target\n\n"
            "The theorem-relevant maximal raw dyadic partial sums admit a "
            "common positive training exponent and the frozen envelope survives "
            "later shells. This is the first numerical route that would make "
            "the frozen critical transform absolutely summable by Abel "
            "summation if promoted analytically. Next, test the same envelope "
            "prospectively in the MODE direction (new higher k) or derive an "
            "analytic centered-Mangoldt exponential-sum bound.\n"
        )
    elif frozen_p > 0:
        next_text = (
            "# v253 next theorem target\n\n"
            "Training shells suggest positive maximal-partial-sum decay, but "
            "the frozen envelope breaks on later shells. Inspect where the "
            "break occurs before pursuing an absolute dyadic theorem.\n"
        )
    else:
        next_text = (
            "# v253 next theorem target\n\n"
            "There is no common positive decay exponent for the maximal raw "
            "dyadic partial sums on the training panel. Endpoint shell decay "
            "from v252 was therefore insufficient; the theorem must retain "
            "additional signed structure rather than use an absolute dyadic "
            "majorant.\n"
        )
    theorem_path.write_text(next_text, encoding="utf-8")

    print()
    print("=" * 194)
    print("ROT-RH v253 — MAXIMAL DYADIC PARTIAL-SUM SUMMARY")
    print("=" * 194)
    for r in final_mode_rows:
        print(
            f"k={r['k']:>4d} "
            f"pTrain={r['training_fit_p']:+.4f} "
            f"R2={r['training_fit_r2']:.3f} "
            f"hold/train={r['holdout_over_training_max']:.3f} "
            f"holdMargin={r['minimum_holdout_envelope_margin']:.3f}"
        )

    print()
    print("IDENTITIES / ABEL")
    print("-" * 194)
    print(
        "max v252 endpoint crosscheck error : "
        f"{max_endpoint_cross:.3e}"
    )
    print(
        "max weighted shell / Abel bound    : "
        f"{max_abel_ratio:.9f}"
    )

    print()
    print("PROSPECTIVE COMMON ENVELOPE")
    print("-" * 194)
    print(
        "minimum training fitted p          : "
        f"{min_training_p:+.9f}"
    )
    print(
        "frozen common p                    : "
        f"{frozen_p:.9f}"
    )
    print(
        "frozen global C                    : "
        f"{frozen_C:.9e}"
    )
    print(
        "all holdout shells pass            : "
        f"{holdout_pass}"
    )
    print(
        "minimum holdout envelope margin    : "
        f"{min_holdout_margin:.6f}"
    )
    print(
        "geometric tail bound @ first holdout: "
        f"{geometric_tail_bound:.9e}"
    )
    print(f"MECHANISM                           : {mechanism}")

    print()
    print("=" * 194)
    print("FAILED GATES                        :", failed if failed else "none")
    print("VERDICT                             :", verdict)
    print(
        "PROOF VERDICT                       : OPEN — "
        "UNIFORM MAXIMAL CENTERED-MANGOLDT DYADIC BOUND"
    )
    print("=" * 194)
    print("Files written:")
    for path in (
        maxima_path,
        modes_path,
        cross_path,
        abel_path,
        summary_path,
        theorem_path,
    ):
        print(" ", path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
