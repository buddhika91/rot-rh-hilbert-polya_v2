#!/usr/bin/env python3
"""
ROT-RH v218 — EXPLICIT-FORMULA ZERO-PAIR TRANSFER / RH-STRENGTH AUDIT

Static analytic-kernel diagnostic.
No Xi / zeta evaluations / known-zero ordinates.

PURPOSE
-------
v216 certified a finite three-region absolute cutoff bound numerically.
v217 showed that its observed contraction is compatible with logarithmic decay
and therefore may still be RH-strength.

v218 tests that point directly from the explicit formula.

For the prime-power counting function J(x),

    d(J-Li)(x)

has a nontrivial-zero contribution

    - x^(rho-1) dx / log x

for each rho (schematically; trivial/pole terms are separate).

For a cutoff pair L -> rL and s = 1/2 - iE, a zero rho contributes on a fixed
scaled interval x=L u:

    D_rho,j(L,E)
      = - L^(rho-s)
          integral_j
            u^(rho-s-1)
            [exp(-u/r)-exp(-u)]
            du / (log L + log u).

As L -> infinity with the scaled interval fixed,

    D_rho,j(L,E)
      ~ - L^(rho-s)/log L * K_j(rho-s),

where

    K_j(z)
      = integral_j u^(z-1)[exp(-u/r)-exp(-u)] du.

For the conjugate pair beta +/- i gamma and s=1/2-iE, factor out e^(iE logL):

    pair_j
      ~ -(L^a/log L) e^(iE logL)
          [
            e^(+i gamma logL) K_j(a+i(gamma+E))
            +
            e^(-i gamma logL) K_j(a+i(E-gamma))
          ],

    a = beta - 1/2.

The v216-type absolute shell norm therefore has leading pair transfer

    G(phi)
      = sum_j | e^(i phi) K_j(a+i(gamma+E))
                + e^(-i phi) K_j(a+i(E-gamma)) |,

    phi = gamma log L.

v218 computes:
  * G_min over phi in [0,2pi];
  * G_median and G_max;
  * the single-zero shell gain sum |K_j|;
  * high-gamma decay of G_min;
  * the crossover against the fitted v216 logarithmic baseline
        B_fit(L)=C/(log L)^q
    using the actual unit-multiplicity leading coefficient G_min.

If G_min > 0, an isolated conjugate pair cannot phase-cancel simultaneously
in every finite shell at leading order.  For any a>0,

    (L^a/log L) G_min

eventually grows.

IMPORTANT LIMITATION
--------------------
This does NOT prove RH equivalence:
  * multiple zeros with the same/rightward beta can cancel inside a shell;
  * a nonattained right-edge supremum remains a collective problem;
  * the leading asymptotic requires fixed rho and L -> infinity.

The purpose is narrower: decide whether the three-region absolute-shell route
has genuinely bypassed off-critical-zero growth.  A positive transfer shows
that it has not, at least for an isolated fixed off-critical zero pair.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import mpmath as mp
import numpy as np
import pandas as pd


def parse_float_list(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def fit_loglaw(L, B):
    x = np.log(np.log(L))
    y = np.log(B)
    c = np.polyfit(x,y,1)
    q = float(-c[0])
    logC = float(c[1])

    pred = np.exp(logC - q*x)
    ly = np.log(B)
    lp = np.log(pred)
    den = np.sum((ly-ly.mean())**2)
    r2 = 1.0 - np.sum((ly-lp)**2)/den if den > 0 else np.nan

    return q, logC, float(r2)


def kernel_interval(z, lo, hi, ratio):
    """
    K_[lo,hi](z)
      = int_lo^hi u^(z-1) [exp(-u/ratio)-exp(-u)] du.

    Uses incomplete gamma functions:
      int u^(z-1)e^(-u/r)du = r^z Gamma(z, lo/r, hi/r).
    """
    zmp = mp.mpc(z.real, z.imag)
    rmp = mp.mpf(ratio)

    lomp = mp.mpf(lo) if lo > 0 else mp.mpf("0")
    himp = mp.inf if math.isinf(hi) else mp.mpf(hi)

    a1 = lomp/rmp
    b1 = mp.inf if himp == mp.inf else himp/rmp

    term_r = mp.power(rmp,zmp) * mp.gammainc(zmp,a1,b1)
    term_1 = mp.gammainc(zmp,lomp,himp)

    return complex(term_r-term_1)


def build_partition(eps, U, bulk_shells):
    bulk = np.geomspace(eps,U,bulk_shells+1)

    intervals = [(0.0,eps,"head")]

    for j,(a,b) in enumerate(zip(bulk[:-1],bulk[1:])):
        intervals.append((float(a),float(b),f"bulk_{j:03d}"))

    intervals.append((U,math.inf,"tail"))

    return intervals


def kernel_vector(z, intervals, ratio):
    return np.asarray([
        kernel_interval(z,a,b,ratio)
        for a,b,_ in intervals
    ],dtype=np.complex128)


def pair_gain_scan(Kplus, Kminus, phase_points):
    phi = np.linspace(
        0.0,2.0*math.pi,phase_points,
        endpoint=False,
    )

    # Chunk to avoid unnecessary large temporaries.
    best = np.inf
    vals = []

    chunk = 512
    for lo in range(0,len(phi),chunk):
        ph = phi[lo:lo+chunk]
        ep = np.exp(1j*ph)[:,None]
        em = np.exp(-1j*ph)[:,None]

        g = np.sum(
            np.abs(ep*Kplus[None,:] + em*Kminus[None,:]),
            axis=1,
        )

        best = min(best,float(np.min(g)))
        vals.append(g)

    vals = np.concatenate(vals)

    return {
        "min":float(best),
        "q05":float(np.quantile(vals,0.05)),
        "median":float(np.median(vals)),
        "q95":float(np.quantile(vals,0.95)),
        "max":float(np.max(vals)),
    }


def crossover_logL(a, gain, logC, q, y0, ymax):
    """
    Solve
        gain * exp(a y) / y = exp(logC) / y^q
    for y=log L, y>=y0.

    Equivalent:
        a y + (q-1) log y + log gain - logC = 0.
    """
    if a <= 0 or gain <= 0:
        return np.nan

    def F(y):
        return (
            a*y
            + (q-1.0)*math.log(y)
            + math.log(gain)
            - logC
        )

    f0 = F(y0)
    if f0 >= 0:
        return y0

    y = y0
    fy = f0

    while y < ymax:
        yn = min(ymax,max(y+1.0,1.5*y))
        fn = F(yn)

        if fn >= 0:
            lo,hi = y,yn
            for _ in range(180):
                mid = 0.5*(lo+hi)
                fm = F(mid)
                if fm >= 0:
                    hi = mid
                else:
                    lo = mid
            return 0.5*(lo+hi)

        y,fy = yn,fn

    return np.nan


def power_fit_gamma(gamma, gain):
    gamma = np.asarray(gamma,float)
    gain = np.asarray(gain,float)

    ok = (
        np.isfinite(gamma)
        & np.isfinite(gain)
        & (gamma > 0)
        & (gain > 0)
    )

    gamma = gamma[ok]
    gain = gain[ok]

    if len(gamma) < 3:
        return np.nan,np.nan

    x = np.log(gamma)
    y = np.log(gain)

    c = np.polyfit(x,y,1)
    pred = np.polyval(c,x)

    den = np.sum((y-y.mean())**2)
    r2 = 1.0-np.sum((y-pred)**2)/den if den>0 else np.nan

    # gain ~ gamma^{-q}
    return float(-c[0]),float(r2)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v216-l-values-csv",
        default="rot_rh_phase_resolved_three_region_v216_L_VALUES.csv",
    )

    ap.add_argument("--ratio",type=float,default=2.0)
    ap.add_argument("--baseline-eps",type=float,default=0.01)
    ap.add_argument("--baseline-U",type=float,default=16.0)
    ap.add_argument("--bulk-shells",type=int,default=80)

    ap.add_argument(
        "--beta-values",
        default="0.501,0.505,0.510,0.550,0.750",
    )
    ap.add_argument(
        "--gamma-values",
        default="20,50,100,300,1000,3000,10000",
    )
    ap.add_argument(
        "--energy-values",
        default="10,25,50,80",
    )

    ap.add_argument("--phase-points",type=int,default=4096)
    ap.add_argument("--mp-dps",type=int,default=50)

    ap.add_argument(
        "--gain-floor-gate",
        type=float,
        default=1e-12,
        help="Numerical nondegeneracy gate for pair transfer G_min.",
    )
    ap.add_argument(
        "--max-logL",
        type=float,
        default=1e8,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_zero_pair_transfer_v218",
    )

    args = ap.parse_args()

    mp.mp.dps = args.mp_dps

    src = pd.read_csv(args.v216_l_values_csv).sort_values("L")
    if not {"L","bound_max"}.issubset(src.columns):
        raise RuntimeError("v216 CSV must contain L and bound_max.")

    L = src["L"].to_numpy(float)
    B = src["bound_max"].to_numpy(float)

    q,logC,logR2 = fit_loglaw(L,B)

    betas = parse_float_list(args.beta_values)
    gammas = parse_float_list(args.gamma_values)
    energies = parse_float_list(args.energy_values)

    intervals = build_partition(
        args.baseline_eps,
        args.baseline_U,
        args.bulk_shells,
    )

    print("="*202)
    print("ROT-RH v218 — EXPLICIT-FORMULA ZERO-PAIR TRANSFER / RH-STRENGTH AUDIT")
    print("="*202)
    print("Xi / zeta / known zeros          : NONE")
    print(f"partition                         : head + {args.bulk_shells} bulk + tail")
    print(f"scaled head/bulk/tail             : (0,{args.baseline_eps}) / [{args.baseline_eps},{args.baseline_U}] / ({args.baseline_U},inf)")
    print(f"hypothetical betas                : {betas}")
    print(f"hypothetical gammas               : {gammas}")
    print(f"energies                          : {energies}")
    print(f"phase points                      : {args.phase_points}")
    print(f"mp dps                            : {args.mp_dps}")
    print(f"v216 log-law q                    : {q:.9f}  R2={logR2:.6f}")
    print("="*202)

    rows = []

    y0 = math.log(float(L[-1]))

    for beta in betas:
        a = beta-0.5

        for gamma in gammas:
            for E in energies:
                zplus = complex(a,gamma+E)
                zminus = complex(a,E-gamma)

                Kplus = kernel_vector(
                    zplus,intervals,args.ratio
                )
                Kminus = kernel_vector(
                    zminus,intervals,args.ratio
                )

                gain = pair_gain_scan(
                    Kplus,Kminus,args.phase_points
                )

                single_plus = float(np.sum(np.abs(Kplus)))
                single_minus = float(np.sum(np.abs(Kminus)))

                # Simple phase-independent reverse-triangle lower bound.
                reverse_lower = float(np.sum(
                    np.abs(np.abs(Kplus)-np.abs(Kminus))
                ))

                yc = crossover_logL(
                    a=a,
                    gain=gain["min"],
                    logC=logC,
                    q=q,
                    y0=y0,
                    ymax=args.max_logL,
                )

                rows.append({
                    "beta":beta,
                    "a_beta_minus_half":a,
                    "gamma":gamma,
                    "E":E,
                    "single_gain_plus":single_plus,
                    "single_gain_minus":single_minus,
                    "pair_gain_reverse_triangle_lower":reverse_lower,
                    "pair_gain_min_phase_scan":gain["min"],
                    "pair_gain_q05":gain["q05"],
                    "pair_gain_median":gain["median"],
                    "pair_gain_q95":gain["q95"],
                    "pair_gain_max":gain["max"],
                    "pair_gain_min_over_median":(
                        gain["min"]/max(gain["median"],1e-300)
                    ),
                    "crossover_logL_vs_v216_loglaw":yc,
                    "crossover_log10L_vs_v216_loglaw":(
                        yc/math.log(10.0)
                        if np.isfinite(yc) else np.nan
                    ),
                })

            # compact progress at E closest to 50
            subset = [r for r in rows
                      if r["beta"]==beta and r["gamma"]==gamma]
            rr = min(subset,key=lambda x:abs(x["E"]-50.0))
            print(
                f"beta={beta:.3f} gamma={gamma:8.1f} "
                f"E={rr['E']:5.1f} "
                f"Gmin={rr['pair_gain_min_phase_scan']:.3e} "
                f"Gmed={rr['pair_gain_median']:.3e} "
                f"log10Lcross={rr['crossover_log10L_vs_v216_loglaw']:.3e}"
            )

    df = pd.DataFrame(rows)

    # Gamma-decay fits for each beta,E.
    fit_rows = []

    for beta in betas:
        for E in energies:
            d = df[
                np.isclose(df["beta"],beta)
                & np.isclose(df["E"],E)
            ].sort_values("gamma")

            qg,r2g = power_fit_gamma(
                d["gamma"].to_numpy(float),
                d["pair_gain_min_phase_scan"].to_numpy(float),
            )

            fit_rows.append({
                "beta":beta,
                "E":E,
                "pair_gain_gamma_decay_q":qg,
                "pair_gain_gamma_log_R2":r2g,
                "min_gain_over_gamma_grid":float(
                    d["pair_gain_min_phase_scan"].min()
                ),
                "max_gain_over_gamma_grid":float(
                    d["pair_gain_min_phase_scan"].max()
                ),
            })

    fdf = pd.DataFrame(fit_rows)

    min_gain = float(df["pair_gain_min_phase_scan"].min())
    nondegenerate_fraction = float(np.mean(
        df["pair_gain_min_phase_scan"].to_numpy(float)
        > args.gain_floor_gate
    ))

    all_tested_nondegenerate = bool(
        nondegenerate_fraction == 1.0
    )

    finite_cross_fraction = float(np.mean(
        np.isfinite(
            df["crossover_logL_vs_v216_loglaw"].to_numpy(float)
        )
    ))

    if all_tested_nondegenerate and finite_cross_fraction >= 0.95:
        verdict = "ISOLATED_OFFCRITICAL_ZERO_PAIR_EVENTUALLY_BREAKS_ABSOLUTE_BOUND"
    elif nondegenerate_fraction >= 0.95:
        verdict = "ZERO_PAIR_TRANSFER_NONDEGENERATE_CROSSOVER_PARTIAL"
    else:
        verdict = "ZERO_PAIR_TRANSFER_RH_STRENGTH_UNRESOLVED"

    df.to_csv(args.prefix+"_TRANSFER.csv",index=False)
    fdf.to_csv(args.prefix+"_GAMMA_FITS.csv",index=False)

    summary = {
        "version":218,
        "firewall":"No Xi / zeta evaluations / known-zero ordinates",
        "partition":{
            "eps":args.baseline_eps,
            "U":args.baseline_U,
            "bulk_shells":args.bulk_shells,
            "regions_total":len(intervals),
        },
        "v216_loglaw":{
            "q":q,
            "logC":logC,
            "R2":logR2,
        },
        "minimum_pair_gain_over_test_grid":min_gain,
        "nondegenerate_fraction":nondegenerate_fraction,
        "finite_crossover_fraction":finite_cross_fraction,
        "verdict":verdict,
        "interpretation":(
            "A strong pass shows that an isolated fixed off-critical conjugate "
            "zero pair has nonzero leading transfer into the same finite "
            "absolute-shell partition used by v216 and eventually outgrows "
            "the fitted critical/logarithmic baseline. Thus the absolute "
            "route does not unconditionally bypass off-critical zeros; proving "
            "its limit would itself exclude at least isolated rightmost "
            "off-critical pairs. Collective multiple-zero/nonattained-supremum "
            "cancellation remains separate."
        ),
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*202)
    print("ZERO-PAIR TRANSFER SUMMARY")
    print(f"minimum G_min over test grid      : {min_gain:.6e}")
    print(f"nondegenerate fraction            : {nondegenerate_fraction:.6f}")
    print(f"finite crossover fraction         : {finite_cross_fraction:.6f}")

    qvals = fdf["pair_gain_gamma_decay_q"].to_numpy(float)
    qvals = qvals[np.isfinite(qvals)]
    if len(qvals):
        print(
            f"gamma-decay q median/q10/q90      : "
            f"{np.median(qvals):.6f} / "
            f"{np.quantile(qvals,0.10):.6f} / "
            f"{np.quantile(qvals,0.90):.6f}"
        )

    print(f"VERDICT                           : {verdict}")
    print("="*202)


if __name__ == "__main__":
    main()
