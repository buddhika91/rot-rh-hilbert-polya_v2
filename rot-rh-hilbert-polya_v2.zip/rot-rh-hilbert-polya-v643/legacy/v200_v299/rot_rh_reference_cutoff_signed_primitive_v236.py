#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v236 — REFERENCE-CUTOFF BOUNDED SIGNED-PRIMITIVE AUDIT
==============================================================

Goal
----
After v235, the high-mode theorem can be reduced to a root-space statement.

Let A_k be the free Archimedean level and choose one fixed finite reference
cutoff L0.  Then

    |E_k(L)-A_k|
      <= |E_k(L0)-A_k| + |E_k(L)-E_k(L0)|.

At fixed finite L0, the finite-part phase is a bounded function of E, whereas
the Archimedean count grows without bound.  Hence

    sup_k |E_k(L0)-A_k| < infinity

is an elementary fixed-cutoff statement once the fixed-L0 phase bounds are
written explicitly.

Therefore the only genuinely moving-cutoff theorem needed for the high-mode
tail is

    sup_{L>=L0,k} |E_k(L)-E_k(L0)| < infinity.

This is a BOUNDED SIGNED PRIMITIVE statement.  It does NOT require

    sum_j |E_k(L_{j+1})-E_k(L_j)| < infinity

or absolute regulator-derivative integrability.

v236 is a zero-cost postprocessor of v235 ROOTS.csv.gz.  It:

* freezes a bound B_safe for |E_k(L)-E_k(L0)| on a training rectangle;
* tests THREE disjoint holdout regions:
    1. future-cutoff strip       L>L_train, k<=k_train;
    2. high-mode strip           L<=L_train, k>k_train;
    3. future+high-mode corner   L>L_train, k>k_train;
* measures signed-primitive cancellation mode-by-mode:
      total variation = sum |Delta E|,
      net excursion   = max_L |E_k(L)-E_k(L0)|,
      cancellation ratio = net excursion / total variation;
* counts increment sign changes;
* checks whether max reference displacement exhibits power growth in L or k;
* combines the empirical fixed-reference free displacement with B_safe only as
  a NUMERICAL candidate for the global D of v235.

No Xi, zeta values, known-zero ordinates, prime sums, or root solves.

Scientific boundary
-------------------
A PASS is not a proof of bounded cutoff flow.  It identifies the correct
analytic target:

    prove the signed root-flow primitive remains uniformly bounded,

preferably from the exact finite-part cutoff-difference / Abel identity and a
Dirichlet or summation-by-parts argument.  v131 and v156 already show why this
is the appropriate mechanism rather than absolute derivative integrability.

Version: 236
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v236 requires tqdm") from exc


VERSION = 236
EE = math.e


def linfit_loglog(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x, y = x[m], y[m]
    if len(x) < 3 or np.ptp(np.log(x)) <= 0:
        return dict(n=int(len(x)), slope=np.nan, r2=np.nan)

    X = np.column_stack([np.ones(len(x)), np.log(x)])
    yy = np.log(y)
    beta, *_ = np.linalg.lstsq(X, yy, rcond=None)
    pred = X @ beta
    sse = float(np.sum((yy - pred)**2))
    sst = float(np.sum((yy - yy.mean())**2))
    r2 = 1.0 - sse/sst if sst > 0 else 1.0
    return dict(n=int(len(x)), slope=float(beta[1]), r2=float(r2))


def minimum_k_for_D(D, c_free=2.0, c_target=1.0):
    gap = float(c_free) - float(c_target)
    if gap <= 0 or D < 0:
        return -1
    k = 6
    while gap * k / math.log(k + EE) < D:
        k += 1
        if k > 10**9:
            return -1
    return k


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v235-roots",
        default="rot_rh_uniform_free_level_displacement_v235_ROOTS.csv.gz",
    )
    ap.add_argument(
        "--v235-summary",
        default="rot_rh_uniform_free_level_displacement_v235_SUMMARY.json",
    )
    ap.add_argument("--reference-cutoff", type=int, default=4000)

    # Deliberately smaller rectangle than v235, leaving a true future/high corner.
    ap.add_argument("--train-cutoff-max", type=int, default=128000)
    ap.add_argument("--train-mode-max", type=int, default=256)

    ap.add_argument("--B-additive-slack", type=float, default=0.15)
    ap.add_argument("--B-relative-slack", type=float, default=0.10)

    ap.add_argument("--minimum-future-strip-rows", type=int, default=64)
    ap.add_argument("--minimum-highmode-strip-rows", type=int, default=256)
    ap.add_argument("--minimum-corner-rows", type=int, default=128)

    # Reject only clear power-law blow-up.
    ap.add_argument("--cutoff-excursion-slope-gate", type=float, default=0.10)
    ap.add_argument("--mode-excursion-slope-gate", type=float, default=0.10)

    ap.add_argument(
        "--prefix",
        default="rot_rh_reference_cutoff_signed_primitive_v236",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    roots = pd.read_csv(args.v235_roots)
    need = {"L", "k", "E", "A_free", "displacement", "abs_displacement"}
    miss = need - set(roots.columns)
    if miss:
        raise KeyError(f"v235 roots missing {sorted(miss)}")

    roots = roots[
        np.isfinite(roots["L"])
        & np.isfinite(roots["k"])
        & np.isfinite(roots["E"])
        & np.isfinite(roots["A_free"])
        & (roots["L"] > 0)
        & (roots["k"] >= 1)
        & (roots["E"] > 0)
    ].copy()
    roots["L"] = roots["L"].astype(int)
    roots["k"] = roots["k"].astype(int)

    if args.reference_cutoff not in set(roots["L"]):
        raise RuntimeError("Reference cutoff absent")

    ref = (
        roots[roots["L"] == args.reference_cutoff][
            ["k", "E", "A_free", "abs_displacement"]
        ]
        .rename(columns={
            "E": "E_ref",
            "A_free": "A_free_ref",
            "abs_displacement": "ref_abs_free_displacement",
        })
        .copy()
    )

    deepest = int(roots["k"].max())
    if int(ref["k"].max()) < deepest:
        raise RuntimeError(
            f"Reference cutoff supports only k={int(ref['k'].max())}, "
            f"but full data reach k={deepest}"
        )

    d = roots.merge(ref, on="k", how="inner", validate="many_to_one")
    d["ref_shift"] = d["E"] - d["E_ref"]
    d["abs_ref_shift"] = np.abs(d["ref_shift"])

    # ------------------------------------------------------------
    # Freeze B on training rectangle.
    # ------------------------------------------------------------
    train = d[
        (d["L"] <= args.train_cutoff_max)
        & (d["k"] <= args.train_mode_max)
    ].copy()
    if train.empty:
        raise RuntimeError("Training rectangle empty")

    B_train = float(train["abs_ref_shift"].max())
    B_safe = max(
        B_train + float(args.B_additive_slack),
        B_train * (1.0 + float(args.B_relative_slack)),
    )

    # Disjoint holdout regions.
    future_strip = d[
        (d["L"] > args.train_cutoff_max)
        & (d["k"] <= args.train_mode_max)
    ].copy()
    highmode_strip = d[
        (d["L"] <= args.train_cutoff_max)
        & (d["k"] > args.train_mode_max)
    ].copy()
    corner = d[
        (d["L"] > args.train_cutoff_max)
        & (d["k"] > args.train_mode_max)
    ].copy()

    def hstats(df, label):
        if df.empty:
            return dict(
                label=label, rows=0, cutoffs=0, modes=0,
                max_abs_ref_shift=np.nan, B_over_max=np.nan, failures=0,
            )
        mx = float(df["abs_ref_shift"].max())
        return dict(
            label=label,
            rows=int(len(df)),
            cutoffs=int(df["L"].nunique()),
            modes=int(df["k"].nunique()),
            max_abs_ref_shift=mx,
            B_over_max=float(B_safe/mx) if mx > 0 else np.inf,
            failures=int(np.sum(df["abs_ref_shift"].to_numpy(float) > B_safe)),
        )

    future_stats = hstats(future_strip, "future_cutoff_strip")
    high_stats = hstats(highmode_strip, "high_mode_strip")
    corner_stats = hstats(corner, "future_high_mode_corner")

    # ------------------------------------------------------------
    # Mode-by-mode signed primitive anatomy.
    # ------------------------------------------------------------
    mode_rows = []
    increment_rows = []

    for k, g in tqdm(d.groupby("k", sort=True), desc="Signed primitive by mode", unit="k"):
        g = g.sort_values("L")
        Ls = g["L"].to_numpy(int)
        Es = g["E"].to_numpy(float)
        shifts = g["ref_shift"].to_numpy(float)

        inc = np.diff(Es)
        tv = float(np.sum(np.abs(inc))) if len(inc) else 0.0
        max_exc = float(np.max(np.abs(shifts)))
        final_exc = float(shifts[-1])
        cancel_ratio = max_exc / tv if tv > 0 else 0.0

        nonzero_sign = np.sign(inc[np.abs(inc) > 1e-15])
        sign_changes = int(
            np.sum(nonzero_sign[1:] * nonzero_sign[:-1] < 0)
        ) if len(nonzero_sign) >= 2 else 0

        mode_rows.append({
            "k": int(k),
            "cutoffs": int(len(g)),
            "L_min": int(Ls[0]),
            "L_max": int(Ls[-1]),
            "max_abs_ref_shift": max_exc,
            "final_ref_shift": final_exc,
            "total_variation": tv,
            "max_excursion_over_total_variation": cancel_ratio,
            "sign_changes": sign_changes,
            "reference_abs_free_displacement": float(
                g["ref_abs_free_displacement"].iloc[0]
            ),
            "max_abs_free_displacement_all_L": float(
                g["abs_displacement"].max()
            ),
        })

        for j in range(len(inc)):
            increment_rows.append({
                "k": int(k),
                "L1": int(Ls[j]),
                "L2": int(Ls[j+1]),
                "delta_E": float(inc[j]),
                "abs_delta_E": float(abs(inc[j])),
                "primitive_at_L2": float(shifts[j+1]),
                "abs_primitive_at_L2": float(abs(shifts[j+1])),
            })

    mode_df = pd.DataFrame(mode_rows)
    inc_df = pd.DataFrame(increment_rows)

    # Upper-mode trend in max signed primitive.
    upper = mode_df[
        mode_df["k"] >= max(args.train_mode_max, int(mode_df["k"].median()))
    ].copy()
    if len(upper) < 3:
        upper = mode_df.iloc[len(mode_df)//2:].copy()

    mode_fit = linfit_loglog(
        upper["k"].to_numpy(float),
        upper["max_abs_ref_shift"].to_numpy(float),
    )

    # Cutoff-wise maximum primitive on common modes.
    common_k = min(
        int(g["k"].max())
        for _, g in d.groupby("L")
    )
    common_k = max(common_k, 1)

    cutoff_rows = []
    for L, g in d[d["k"] <= common_k].groupby("L", sort=True):
        cutoff_rows.append({
            "L": int(L),
            "common_k_max": int(common_k),
            "max_abs_ref_shift": float(g["abs_ref_shift"].max()),
            "median_abs_ref_shift": float(g["abs_ref_shift"].median()),
            "B_failures": int(np.sum(g["abs_ref_shift"] > B_safe)),
        })
    cutoff_df = pd.DataFrame(cutoff_rows)
    cutoff_nonref = cutoff_df[cutoff_df["L"] > args.reference_cutoff]
    cutoff_fit = linfit_loglog(
        cutoff_nonref["L"].to_numpy(float),
        cutoff_nonref["max_abs_ref_shift"].to_numpy(float),
    )

    # Cancellation summaries by mode ranges.
    def band_label(k):
        if k <= 32:
            return "1-32"
        if k <= 128:
            return "33-128"
        if k <= 256:
            return "129-256"
        if k <= 512:
            return "257-512"
        if k <= 1024:
            return "513-1024"
        return "1025+"

    mode_df["band"] = [band_label(k) for k in mode_df["k"]]
    band_rows = []
    for band, g in mode_df.groupby("band", sort=False):
        band_rows.append({
            "band": band,
            "modes": int(len(g)),
            "max_ref_shift": float(g["max_abs_ref_shift"].max()),
            "median_ref_shift": float(g["max_abs_ref_shift"].median()),
            "median_total_variation": float(g["total_variation"].median()),
            "median_excursion_over_variation": float(
                g["max_excursion_over_total_variation"].median()
            ),
            "fraction_with_sign_change": float(
                np.mean(g["sign_changes"].to_numpy(int) > 0)
            ),
            "median_sign_changes": float(g["sign_changes"].median()),
        })
    band_df = pd.DataFrame(band_rows)

    # ------------------------------------------------------------
    # Combine only as numerical candidate D; theorem only needs finiteness.
    # ------------------------------------------------------------
    D_ref_emp = float(ref["ref_abs_free_displacement"].max())
    D_candidate = D_ref_emp + B_safe
    k0_candidate = minimum_k_for_D(D_candidate)

    d["candidate_transfer_bound"] = (
        d["k"].to_numpy(float)
        / np.log(d["k"].to_numpy(float) + EE)
    )
    tr = d[d["k"] >= max(6, k0_candidate)].copy()
    min_transfer = float(
        np.min(tr["E"].to_numpy(float) / tr["candidate_transfer_bound"].to_numpy(float))
    )

    # ------------------------------------------------------------
    # Gates.
    # ------------------------------------------------------------
    gates = {
        "reference_supports_all_modes": bool(int(ref["k"].max()) >= deepest),

        "future_strip_coverage": bool(
            future_stats["rows"] >= args.minimum_future_strip_rows
        ),
        "future_strip_pass": bool(future_stats["failures"] == 0),

        "highmode_strip_coverage": bool(
            high_stats["rows"] >= args.minimum_highmode_strip_rows
        ),
        "highmode_strip_pass": bool(high_stats["failures"] == 0),

        "corner_holdout_coverage": bool(
            corner_stats["rows"] >= args.minimum_corner_rows
        ),
        "corner_holdout_pass": bool(corner_stats["failures"] == 0),

        "cutoff_primitive_not_power_blowing_up": bool(
            np.isfinite(cutoff_fit["slope"])
            and cutoff_fit["slope"] <= args.cutoff_excursion_slope_gate
        ),
        "mode_primitive_not_power_blowing_up": bool(
            np.isfinite(mode_fit["slope"])
            and mode_fit["slope"] <= args.mode_excursion_slope_gate
        ),
        "candidate_weyl_transfer_pass_available": bool(min_transfer >= 1.0),
    }

    failed = [k for k, v in gates.items() if not v]

    verdict = (
        "REFERENCE_CUTOFF_BOUNDED_SIGNED_PRIMITIVE_STRONGLY_SUPPORTED"
        if not failed
        else
        "REFERENCE_CUTOFF_BOUNDED_PRIMITIVE_TARGET_UNRESOLVED"
    )

    # ------------------------------------------------------------
    # Save.
    # ------------------------------------------------------------
    prefix = args.prefix
    roots_path = Path(prefix + "_ROOTS.csv.gz")
    modes_path = Path(prefix + "_MODES.csv")
    increments_path = Path(prefix + "_INCREMENTS.csv.gz")
    cutoffs_path = Path(prefix + "_CUTOFFS.csv")
    bands_path = Path(prefix + "_BANDS.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM_TARGET.md")

    d.to_csv(roots_path, index=False, compression="gzip")
    mode_df.to_csv(modes_path, index=False)
    inc_df.to_csv(increments_path, index=False, compression="gzip")
    cutoff_df.to_csv(cutoffs_path, index=False)
    band_df.to_csv(bands_path, index=False)

    def native(x):
        if isinstance(x, dict):
            return {str(k): native(v) for k, v in x.items()}
        if isinstance(x, list):
            return [native(v) for v in x]
        if isinstance(x, np.generic):
            return x.item()
        if isinstance(x, float) and not math.isfinite(x):
            return None
        return x

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "prime_sums": False,
            "root_solves": False,
        },
        "reference_cutoff": args.reference_cutoff,
        "training_rectangle": {
            "L_max": args.train_cutoff_max,
            "k_max": args.train_mode_max,
            "training_max_abs_ref_shift": B_train,
            "B_additive_slack": args.B_additive_slack,
            "B_relative_slack": args.B_relative_slack,
            "frozen_B_safe": B_safe,
        },
        "holdouts": {
            "future_cutoff_strip": future_stats,
            "high_mode_strip": high_stats,
            "future_high_mode_corner": corner_stats,
        },
        "trend_diagnostics": {
            "common_k": common_k,
            "cutoff_primitive_loglog": cutoff_fit,
            "upper_mode_primitive_loglog": mode_fit,
        },
        "signed_primitive_diagnostics": {
            "median_mode_excursion_over_total_variation": float(
                mode_df["max_excursion_over_total_variation"].median()
            ),
            "fraction_modes_with_at_least_one_sign_change": float(
                np.mean(mode_df["sign_changes"].to_numpy(int) > 0)
            ),
            "median_sign_changes": float(mode_df["sign_changes"].median()),
        },
        "weyl_transfer_candidate": {
            "empirical_fixed_reference_free_displacement": D_ref_emp,
            "frozen_moving_cutoff_bound_B": B_safe,
            "numerical_D_candidate": D_candidate,
            "candidate_k0_for_E_ge_k_log_inverse": k0_candidate,
            "minimum_available_E_over_candidate_bound": min_transfer,
            "note": (
                "D_ref_emp is numerical only here. Analytically, one only needs "
                "to prove some finite fixed-L0 free displacement constant."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "proof_status": (
            "OPEN. The next analytic target is a uniform bounded signed primitive "
            "of the cutoff root flow relative to one fixed L0. Absolute variation "
            "or absolute regulator-derivative integrability is not required."
        ),
    }
    summary_path.write_text(
        json.dumps(native(summary), indent=2),
        encoding="utf-8",
    )

    theorem = f"""# ROT-RH v236 — bounded signed primitive theorem target

Choose `L0={args.reference_cutoff}`.

The high-mode theorem can be split as

`|E_k(L)-A_k| <= |E_k(L0)-A_k| + |E_k(L)-E_k(L0)|`.

## Fixed-reference term

For fixed finite `L0`, the finite Mangoldt/counterterm phase is bounded in `E`.
Combined with the unbounded Archimedean count, this gives

`sup_k |E_k(L0)-A_k| < infinity`.

An explicit constant may be crude; sharpness is irrelevant.

## Moving-cutoff term

The genuine theorem target is

`sup_(L>=L0,k) |E_k(L)-E_k(L0)| <= B < infinity`.

The training-only numerical candidate is

`B_safe = {B_safe:.15g}`.

The important point is that this is a signed-primitive bound.  It does not
require the total variation

`sum_j |E_k(L_(j+1))-E_k(L_j)|`

to converge.

## Route to proof

At moving roots,

`dE_k/d(log L) = - partial_(log L) F_L(E_k(L)) / partial_E F_L(E_k(L))`.

v229 provides the positive root transversality mechanism.

The numerator should be represented using the centered cutoff-difference / Abel
identity, and its primitive controlled by Dirichlet or summation by parts while
preserving the prime-counterterm cancellation.

This is exactly the mechanism suggested by v131 and by the v156 observation
that endpoint distance may remain small even when absolute derivative
integrability is poor.

Once finite constants for both terms are proved, v232 transfers the free Weyl
bound to a cutoff-uniform summable high-mode trace majorant.
"""
    theorem_path.write_text(theorem, encoding="utf-8")

    print("=" * 188)
    print("ROT-RH v236 — REFERENCE-CUTOFF BOUNDED SIGNED-PRIMITIVE AUDIT")
    print("=" * 188)
    print("Xi / zeta / known-zero data        : NONE")
    print("prime sums / root solves            : NONE / NONE")
    print(f"reference cutoff L0                 : {args.reference_cutoff}")
    print(f"deepest reference mode              : {int(ref['k'].max())}")
    print()
    print("TRAINING BOUND")
    print("-" * 188)
    print(f"training rectangle                  : L<={args.train_cutoff_max}, k<={args.train_mode_max}")
    print(f"training max |E(L)-E(L0)|           : {B_train:.12f}")
    print(f"frozen B_safe                       : {B_safe:.12f}")
    print()
    print("DISJOINT HOLDOUTS")
    print("-" * 188)
    for s in [future_stats, high_stats, corner_stats]:
        print(
            f"{s['label']:<28s}: "
            f"rows={s['rows']:<6d} "
            f"cutoffs={s['cutoffs']:<3d} "
            f"modes={s['modes']:<5d} "
            f"max={s['max_abs_ref_shift']:.9f} "
            f"B/max={s['B_over_max']:.6f} "
            f"failures={s['failures']}"
        )
    print()
    print("SIGNED PRIMITIVE ANATOMY")
    print("-" * 188)
    print(
        "median max-excursion / total-var   : "
        f"{mode_df['max_excursion_over_total_variation'].median():.6f}"
    )
    print(
        "fraction modes with sign reversal  : "
        f"{np.mean(mode_df['sign_changes'].to_numpy(int)>0):.6f}"
    )
    print(
        "median sign changes                 : "
        f"{mode_df['sign_changes'].median():.3f}"
    )
    print(
        "cutoff max-primitive slope          : "
        f"{cutoff_fit['slope']:.9f} R2={cutoff_fit['r2']:.6f}"
    )
    print(
        "upper-mode max-primitive slope      : "
        f"{mode_fit['slope']:.9f} R2={mode_fit['r2']:.6f}"
    )
    print()
    print("WEYL TRANSFER CANDIDATE")
    print("-" * 188)
    print(f"empirical fixed-L0 |E-A| max        : {D_ref_emp:.12f}")
    print(f"moving-cutoff B_safe                : {B_safe:.12f}")
    print(f"numerical D candidate               : {D_candidate:.12f}")
    print(f"candidate transfer k0               : {k0_candidate}")
    print(f"minimum available E / bound         : {min_transfer:.9f}")
    print()
    print("=" * 188)
    print("FAILED GATES                        :", failed if failed else "none")
    print("NUMERICAL VERDICT                   :", verdict)
    print("PROOF VERDICT                       : OPEN — BOUNDED SIGNED ROOT-FLOW PRIMITIVE")
    print("=" * 188)
    print("Files written:")
    for p in [
        roots_path, modes_path, increments_path,
        cutoffs_path, bands_path, summary_path, theorem_path,
    ]:
        print(" ", p)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
