#!/usr/bin/env python3
"""
ROT-RH v209 — ASYMPTOTIC MAYNARD–PRATT BRIDGE / o(1)-DENSITY STRESS TEST

Static asymptotic audit in u = log(gamma).
No root continuation. No Xi / zeta evaluations / known-zero data.

PURPOSE
-------
v208 could not literally test Maynard–Pratt Definition 9 because the synthetic
heights gamma <= 1.6e4 are far below the regime where

    (log log gamma)^3 <= log gamma / log log gamma.

Writing u = log gamma, this condition is

    (log u)^4 <= u.

v209 works directly in u, allowing astronomically large gamma without overflow.

It tests two logical bridges.

A. HALF-ISOLATION SPOILER AT GENUINE MP HEIGHTS

For a VK-style record boundary

    1-beta = mu * u^(-2/3) * (log u)^(-1/3),

the hull derivative gives

    tau ~= (pi/2) / (d beta / d gamma).

At a genuine MP-testable height, choose a hypothetical zero just below-left

    beta'  = beta - delta_beta,
    gamma' = gamma - delta_gamma,

with

    delta_beta < (log u)^3/u.

This violates the MP far-left alternative for every admissible Y; because it
is below the record, the near-same-beta-above alternative is unavailable.

The hull score still keeps the spoiler invisible if

    (pi/2) delta_gamma < delta_beta * tau.

Rather than forming gamma=exp(u), v209 compares scales in log-space:
  * log hull-safe delta_gamma cap;
  * log MP local radius = 2 log u;
  * log mean zero spacing ~ log(2pi/u).

B. CAN HALF-ISOLATED DENSITY ALONE KILL A SPARSE RECORD SEQUENCE?

Maynard–Pratt's density scale is

    N_HI(sigma,T) <= T^[2(1-sigma)+o(1)].

For R(T) record zeros in a dyadic block, the extra exponent required to absorb
them is

    eps_req(T) = log R(T)/log T - 2(1-sigma(T)).

If eps_req(T) -> 0, the unspecified T^{o(1)} factor can in principle absorb
the sparse records, so density alone does not yield a contradiction.

This is a theorem-logic audit, not a statement about actual zeta zeros.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


PI_OVER_2 = math.pi / 2.0
LOG_2PI = math.log(2.0 * math.pi)


def f_mp_activation(u: float) -> float:
    return u - math.log(u) ** 4


def bisect_root(lo: float, hi: float, iters: int = 200) -> float:
    flo = f_mp_activation(lo)
    fhi = f_mp_activation(hi)

    if flo == 0:
        return lo
    if fhi == 0:
        return hi
    if flo * fhi > 0:
        raise RuntimeError(
            f"Activation bracket has same sign: f({lo})={flo}, f({hi})={fhi}"
        )

    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        fm = f_mp_activation(mid)

        if flo * fm <= 0:
            hi = mid
            fhi = fm
        else:
            lo = mid
            flo = fm

    return 0.5 * (lo + hi)


def vk_log_gap(u: float, mu: float) -> float:
    lu = math.log(u)
    return (
        math.log(mu)
        - (2.0 / 3.0) * math.log(u)
        - (1.0 / 3.0) * math.log(lu)
    )


def vk_beta_from_u(u: float, mu: float) -> float:
    return 1.0 - math.exp(vk_log_gap(u, mu))


def log_vk_derivative_h(u: float) -> float:
    """
    Return log h where d beta / d gamma = mu * h(gamma)
    for the VK boundary beta = 1 - mu*f(gamma).
    """
    lu = math.log(u)

    logf = (
        -(2.0 / 3.0) * math.log(u)
        -(1.0 / 3.0) * math.log(lu)
    )

    bracket = (
        2.0 / (3.0 * u)
        + 1.0 / (3.0 * u * lu)
    )

    return logf - u + math.log(bracket)


def log_tau_vk(u: float, mu: float) -> float:
    return math.log(PI_OVER_2) - math.log(mu) - log_vk_derivative_h(u)


def spoiler_scales(u: float, mu: float, beta_fraction: float) -> dict:
    lu = math.log(u)

    # Definition-9 admissible log-Y interval.
    logY_min = lu ** 3
    logY_max = u / lu
    mp_testable = logY_min <= logY_max

    # Minimum far-left threshold over admissible Y:
    # (log u)^2 / (u/log u) = (log u)^3/u.
    delta_beta_critical = lu ** 3 / u
    delta_beta = beta_fraction * delta_beta_critical

    ltau = log_tau_vk(u, mu)

    # Hull-safe vertical-drop cap:
    # delta_gamma < (2/pi) * delta_beta * tau.
    log_hull_cap = (
        math.log(2.0 / math.pi)
        + math.log(delta_beta)
        + ltau
    )

    # MP local radius is (log gamma)^2 = u^2.
    log_local_radius = 2.0 * math.log(u)

    # Mean zeta zero spacing near height gamma is ~ 2pi/log gamma = 2pi/u.
    log_mean_spacing = LOG_2PI - math.log(u)

    return {
        "u_log_gamma": u,
        "log10_gamma": u / math.log(10.0),
        "loglog_gamma": lu,
        "MP_logY_min": logY_min,
        "MP_logY_max": logY_max,
        "MP_testable": mp_testable,
        "beta_vk": vk_beta_from_u(u, mu),
        "gap_vk": math.exp(vk_log_gap(u, mu)),
        "delta_beta_critical": delta_beta_critical,
        "spoiler_delta_beta": delta_beta,
        "log_tau_vk": ltau,
        "log10_tau_vk": ltau / math.log(10.0),
        "log_hull_safe_delta_gamma_cap": log_hull_cap,
        "log_MP_local_radius": log_local_radius,
        "log_mean_zero_spacing": log_mean_spacing,
        "log_hull_cap_over_MP_radius": log_hull_cap - log_local_radius,
        "log_MP_radius_over_mean_spacing": log_local_radius - log_mean_spacing,
        "hull_cap_exceeds_MP_radius": log_hull_cap >= log_local_radius,
    }


def log_record_count(
    model: str,
    u: float,
    const_R: float,
    log_power_a: float,
    loglog_power_b: float,
    delta: float,
) -> float:
    lu = math.log(u)

    if model == "constant":
        return math.log(const_R)
    if model == "log_power":
        return log_power_a * math.log(u)
    if model == "loglog_power":
        return loglog_power_b * math.log(lu)
    if model == "power_control":
        return delta * u

    raise ValueError(model)


def density_required_epsilon(
    u: float,
    sigma: float,
    model: str,
    const_R: float,
    log_power_a: float,
    loglog_power_b: float,
    delta: float,
):
    logR = log_record_count(
        model, u, const_R, log_power_a, loglog_power_b, delta
    )

    base_exp = 2.0 * (1.0 - sigma)

    # Since T = exp(u), log T = u.
    eps_req = logR / u - base_exp

    return logR, base_exp, eps_req


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--mu",
        type=float,
        default=1.810249633874e-2,
    )
    ap.add_argument(
        "--u-values",
        default="1e4,3e4,1e5,3e5,1e6,1e7,1e8,1e10,1e12",
    )
    ap.add_argument(
        "--activation-bracket",
        default="1000,20000",
    )
    ap.add_argument(
        "--spoiler-beta-fraction",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--constant-records",
        type=float,
        default=10.0,
    )
    ap.add_argument(
        "--log-power-a",
        type=float,
        default=1.0,
    )
    ap.add_argument(
        "--loglog-power-b",
        type=float,
        default=2.0,
    )
    ap.add_argument(
        "--power-control-delta",
        type=float,
        default=0.01,
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_asymptotic_mp_bridge_v209",
    )

    args = ap.parse_args()

    lo, hi = [
        float(x.strip())
        for x in args.activation_bracket.split(",")
    ]
    ucrit = bisect_root(lo, hi)

    uvals = sorted(set([
        ucrit,
        *[
            float(x.strip())
            for x in args.u_values.split(",")
            if x.strip()
        ],
    ]))

    scales = pd.DataFrame([
        spoiler_scales(
            u, args.mu, args.spoiler_beta_fraction
        )
        for u in uvals
    ])

    density_rows = []
    models = [
        "constant",
        "log_power",
        "loglog_power",
        "power_control",
    ]

    for _, r in scales.iterrows():
        u = float(r["u_log_gamma"])
        sigma = float(r["beta_vk"])

        for model in models:
            logR, base_exp, eps = density_required_epsilon(
                u,
                sigma,
                model,
                args.constant_records,
                args.log_power_a,
                args.loglog_power_b,
                args.power_control_delta,
            )

            density_rows.append({
                "u_log_gamma": u,
                "log10_gamma": float(r["log10_gamma"]),
                "model": model,
                "sigma_vk": sigma,
                "base_density_exponent_2_1_minus_sigma": base_exp,
                "log_record_count": logR,
                "record_exponent_logR_over_logT": logR / u,
                "epsilon_required": eps,
            })

    density = pd.DataFrame(density_rows)

    tail_scales = scales.tail(min(4, len(scales)))

    spoiler_supported = bool(
        tail_scales["MP_testable"].all()
        and tail_scales["hull_cap_exceeds_MP_radius"].all()
    )

    density_summary = {}

    for model in models:
        dd = density[density["model"] == model].sort_values("u_log_gamma")
        tail = dd.tail(min(4, len(dd)))

        eps = tail["epsilon_required"].to_numpy(float)
        positive_eps = np.maximum(eps, 0.0)

        density_summary[model] = {
            "epsilon_required_final": float(dd.iloc[-1]["epsilon_required"]),
            "positive_epsilon_required_final": float(
                max(dd.iloc[-1]["epsilon_required"], 0.0)
            ),
            "positive_epsilon_tail_max": float(np.max(positive_eps)),
            "epsilon_tail_decreasing": bool(
                np.all(np.diff(positive_eps) <= 1e-15)
            ),
        }

    subpower_models = [
        "constant",
        "log_power",
        "loglog_power",
    ]

    subpower_absorbable = all(
        density_summary[m]["positive_epsilon_required_final"] <= 1e-6
        for m in subpower_models
    )

    power_control_detected = bool(
        density_summary["power_control"][
            "positive_epsilon_required_final"
        ] >= 0.005
    )

    if spoiler_supported and subpower_absorbable and power_control_detected:
        verdict = (
            "MP_BRIDGE_REQUIRES_EXTRA_LOCAL_RIGIDITY_AND_"
            "SUPER_SPARSE_COUNTING"
        )
    elif spoiler_supported:
        verdict = (
            "ASYMPTOTIC_HALF_ISOLATION_NOT_FORCED_"
            "DENSITY_STATUS_PARTIAL"
        )
    else:
        verdict = "ASYMPTOTIC_MP_BRIDGE_UNRESOLVED"

    scales.to_csv(args.prefix + "_SCALES.csv", index=False)
    density.to_csv(args.prefix + "_DENSITY.csv", index=False)

    summary = {
        "version": 209,
        "mu": args.mu,
        "MP_activation_u_log_gamma": ucrit,
        "MP_activation_log10_gamma": ucrit / math.log(10.0),
        "spoiler_supported_at_tail_scales": spoiler_supported,
        "density_summary": density_summary,
        "subpower_record_models_absorbable_by_o1": subpower_absorbable,
        "power_control_density_pressure_detected": power_control_detected,
        "verdict": verdict,
    }

    Path(args.prefix + "_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, allow_nan=True),
        encoding="utf-8",
    )

    print("=" * 198)
    print("ROT-RH v209 — ASYMPTOTIC MAYNARD–PRATT BRIDGE / o(1)-DENSITY STRESS TEST")
    print("=" * 198)
    print("Xi / zeta / known zeros          : NONE")
    print(f"VK mu                              : {args.mu:.12e}")
    print(f"MP activation u=log(gamma)         : {ucrit:.12e}")
    print(f"MP activation log10(gamma)         : {ucrit/math.log(10.0):.12e}")
    print("=" * 198)

    for _, r in scales.iterrows():
        print(
            f"u={r['u_log_gamma']:.3e} "
            f"log10(gamma)={r['log10_gamma']:.3e} "
            f"MP={bool(r['MP_testable'])} "
            f"beta={r['beta_vk']:.12f} "
            f"logCap/R={r['log_hull_cap_over_MP_radius']:.3e} "
            f"log(R/spacing)={r['log_MP_radius_over_mean_spacing']:.3e}"
        )

    print()
    print("DENSITY o(1) REQUIREMENT")
    for model in models:
        ds = density_summary[model]
        print(
            f"{model:16s} "
            f"eps_req(final)={ds['epsilon_required_final']:.6e} "
            f"positive={ds['positive_epsilon_required_final']:.6e} "
            f"tailDecreasing={ds['epsilon_tail_decreasing']}"
        )

    print()
    print(
        f"subpower record models absorbable : "
        f"{subpower_absorbable}"
    )
    print(
        f"power-control pressure detected    : "
        f"{power_control_detected}"
    )
    print(f"VERDICT                            : {verdict}")
    print("=" * 198)


if __name__ == "__main__":
    main()
