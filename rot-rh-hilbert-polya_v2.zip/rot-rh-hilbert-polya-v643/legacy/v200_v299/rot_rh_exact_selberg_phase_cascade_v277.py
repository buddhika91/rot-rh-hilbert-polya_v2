#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v277 — EXACT SELBERG TRANSFER / PHASE-CASCADE AUDIT
===========================================================

Purpose
-------
v276 rigorously certified the NATURAL SELBERG JACOBIAN row gain

    G_J(n) <= 0.750940234607953 < 1

for every integer n>=2.

That is a genuine theorem-level local-stability component, but it is not yet
the exact recursion for the arithmetic coefficients and it does not by itself
bound the one-anchor Abel observable.

v277 now uses an exact identity that v275 did not fully exploit.

Exact linear Selberg transfer
-----------------------------
Let

    b(1)=0, b(n)=1 for n>=2,
    r(n)=Lambda(n)-1  (n>=2).

Selberg's identity gives

    r(n) log n
      + 2(b*r)(n)
      + (r*r)(n)
      = H(n),

where

    H(n)=(mu*log^2)(n)-log n-(b*b)(n).

Since Lambda=b+r,

    2b+r = b+Lambda,

and therefore EXACTLY

    r(n) log n + ((b+Lambda)*r)(n) = H(n).

This is linear in the actual arithmetic coefficient r once Lambda is regarded
as the fixed arithmetic input.

Natural critical state
----------------------
Define

    x_n = r(n)/(sqrt(n) log n),

    F_n = H(n)/(sqrt(n)(log n)^2).

Then

    x = F + K x,

with the strictly causal divisor transfer

    K_{n,d}
      = -(Lambda(k)+1) k^(-1/2)
         log(d)/(log n)^2,

    k=n/d >=2,   d>=2.

Because k>=2, K moves support at least by a factor two:

    support(K^j F) subset {n >= 2^(j+1)}.

Hence every finite truncation has the exact nilpotent expansion

    x = F + K F + K^2 F + ... .

This is a genuine recursive scale cascade, not a fitted model.

Fixed-anchor Abel observable
----------------------------
For

    phi_L(n)=exp(-n/L) n^(iE*),

the centered r-transform is

    T_r(L)=<phi_L,x>.

Therefore exactly

    T_r(L)=sum_j C_j(L),

    C_j(L)=<phi_L,K^j F>.

The operator-centered q-transform differs only by the fixed n=2 correction

    q_2=r_2-1.

What v277 tests
---------------
1. Exact pointwise transfer identity x=F+Kx.
2. Exact finite Neumann reconstruction from the K^j F layers.
3. Layer support doubling.
4. Phase-layer amplitudes C_j(L) on a frozen TRAIN/HOLDOUT cutoff split.
5. A training-only late-depth geometric envelope for |C_j|.
6. Prospective survival of that envelope on larger cutoffs, including newly
   activated cascade depths.
7. Frozen training bound on the absolute cascade sum sum_j |C_j|.

Interpretation
--------------
A pass would NOT prove the one-anchor boundedness lemma.

It would identify a much sharper theorem target:

    prove a cutoff-uniform summable bound on the exact Selberg phase-cascade
    layers <phi_L,K^j F>.

Because the cascade is exact and support doubles at every iterate, this is more
structured than a direct L->infinity extrapolation.

A failure means the exact Selberg transfer does not yield simple geometric
phase-layer summability, even though the Jacobian is globally contractive.

No Xi, zeta values, or zero ordinates are used.

Dependency
----------
The fast exact Dirichlet-transfer iteration uses numba.

    pip install numba

Version: 277
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 277
EPS = np.finfo(float).eps


def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


# ---------------------------------------------------------------------------
# Factor statistics for H(n)
# ---------------------------------------------------------------------------

def smallest_prime_factor(N):
    spf = np.arange(N + 1, dtype=np.int32)
    spf[0] = 0
    if N >= 1:
        spf[1] = 1

    root = int(math.isqrt(N))
    for p in tqdm(
        range(2, root + 1),
        desc="SPF sieve",
        unit="p",
        leave=False,
    ):
        if spf[p] != p:
            continue

        idx = np.arange(
            p * p,
            N + 1,
            p,
            dtype=np.int64,
        )
        if len(idx) == 0:
            continue

        m = spf[idx] == idx
        spf[idx[m]] = p

    return spf


def selberg_factor_statistics(spf):
    """
    Build
      tau(n) = divisor count,
      g(n)   = (mu*log^2)(n).

    Exact formulas:
      n=p^a:
        g=(2a-1)(log p)^2

      n=p^a q^b:
        g=2 log p log q

      >=3 distinct primes:
        g=0.
    """
    N = len(spf) - 1

    tau = np.ones(N + 1, dtype=np.int32)
    omega = np.zeros(N + 1, dtype=np.uint8)
    exponent = np.zeros(N + 1, dtype=np.uint8)
    distinct_log_sum = np.zeros(N + 1, dtype=np.float64)
    g = np.zeros(N + 1, dtype=np.float64)

    for n in tqdm(
        range(2, N + 1),
        desc="Selberg forcing stats",
        unit="n",
    ):
        p = int(spf[n])
        m = n // p
        lp = math.log(p)

        if m > 1 and m % p == 0:
            old_e = int(exponent[m])
            new_e = old_e + 1

            exponent[n] = new_e
            omega[n] = omega[m]
            distinct_log_sum[n] = distinct_log_sum[m]

            tau[n] = (
                tau[m]
                // (old_e + 1)
                * (new_e + 1)
            )

            if omega[n] == 1:
                g[n] = (2 * new_e - 1) * lp * lp
            else:
                g[n] = g[m]

        else:
            exponent[n] = 1
            omega[n] = omega[m] + 1
            distinct_log_sum[n] = distinct_log_sum[m] + lp
            tau[n] = tau[m] * 2

            if omega[m] == 0:
                g[n] = lp * lp
            elif omega[m] == 1:
                g[n] = 2.0 * lp * distinct_log_sum[m]
            else:
                g[n] = 0.0

    return tau, g


# ---------------------------------------------------------------------------
# Training-only geometric envelope
# ---------------------------------------------------------------------------

def fit_geometric_envelope(depth, amp, minimum_depth, safety):
    depth = np.asarray(depth, int)
    amp = np.asarray(amp, float)

    keep = (
        (depth >= int(minimum_depth))
        & np.isfinite(amp)
        & (amp > 1e-14)
    )

    x = depth[keep].astype(float)
    y = np.log(amp[keep])

    if len(x) < 4:
        return {
            "available": False,
            "q_fit": float("nan"),
            "r2": float("nan"),
            "Bsafe": float("nan"),
            "minimum_depth": int(minimum_depth),
        }

    A = np.column_stack([
        np.ones(len(x)),
        x - float(minimum_depth),
    ])

    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = A @ beta

    slope = float(beta[1])
    q = float(math.exp(slope))

    sse = float(np.sum((y - pred) ** 2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0

    if not (0.0 < q < 1.0):
        return {
            "available": True,
            "q_fit": q,
            "r2": r2,
            "Bsafe": float("nan"),
            "minimum_depth": int(minimum_depth),
        }

    # Freeze B from every retained training layer, with safety margin.
    B = 0.0
    for j, a in zip(depth[keep], amp[keep]):
        B = max(
            B,
            float(a) / (q ** (int(j) - int(minimum_depth))),
        )

    B *= float(safety)

    return {
        "available": True,
        "q_fit": q,
        "r2": r2,
        "Bsafe": B,
        "minimum_depth": int(minimum_depth),
    }


def geometric_bound(model, depth):
    if (
        not model["available"]
        or not np.isfinite(model["Bsafe"])
        or not (0.0 < model["q_fit"] < 1.0)
    ):
        return float("nan")

    j = int(depth)
    j0 = int(model["minimum_depth"])

    if j < j0:
        return float("nan")

    return float(
        model["Bsafe"]
        * model["q_fit"] ** (j - j0)
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--L-values",
        default="4000,8000,16000,32000,64000",
    )
    ap.add_argument(
        "--training-L-max",
        type=int,
        default=16000,
    )
    ap.add_argument(
        "--tail-factor",
        type=float,
        default=18.0,
    )

    ap.add_argument(
        "--minimum-envelope-depth",
        type=int,
        default=6,
    )
    ap.add_argument(
        "--envelope-safety",
        type=float,
        default=1.35,
    )
    ap.add_argument(
        "--minimum-envelope-r2",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--maximum-envelope-q",
        type=float,
        default=0.95,
    )

    ap.add_argument(
        "--absolute-sum-safety",
        type=float,
        default=1.25,
    )

    ap.add_argument(
        "--transfer-identity-tol",
        type=float,
        default=2e-11,
    )
    ap.add_argument(
        "--neumann-identity-tol",
        type=float,
        default=2e-10,
    )
    ap.add_argument(
        "--support-tol",
        type=float,
        default=1e-15,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_exact_selberg_phase_cascade_v277",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    try:
        from numba import njit
    except Exception as exc:
        raise RuntimeError(
            "v277 requires numba for the exact Dirichlet-transfer cascade.\n"
            "Install it with:\n\n"
            "    pip install numba\n\n"
            f"Import error: {exc}"
        )

    # Compile the exact transfer locally so the script has no external helper.
    @njit(cache=True)
    def apply_K(u, arithmetic_a, logs, N):
        """
        Exact forward transfer:
          (Ku)_{kd} +=
            -a(k) log(d)/(log(kd))^2 u_d

        with
          a(k)=(Lambda(k)+1)/sqrt(k).
        """
        out = np.zeros(N + 1, dtype=np.float64)

        for k in range(2, N // 2 + 1):
            ak = arithmetic_a[k]

            dmax = N // k
            for d in range(2, dmax + 1):
                n = k * d
                out[n] -= (
                    ak
                    * logs[d]
                    * u[d]
                    / (logs[n] * logs[n])
                )

        return out

    L_values = parse_ints(args.L_values)

    if not L_values:
        raise ValueError("No L values")

    if any(
        L_values[i + 1] <= L_values[i]
        for i in range(len(L_values) - 1)
    ):
        raise ValueError("L values must be strictly increasing")

    train_L = [
        L
        for L in L_values
        if L <= int(args.training_L_max)
    ]
    hold_L = [
        L
        for L in L_values
        if L > int(args.training_L_max)
    ]

    if not train_L or not hold_L:
        raise ValueError(
            "Need at least one training and one holdout L"
        )

    anchors = pd.read_csv(args.anchors)

    if not {"k", "E_anchor"}.issubset(anchors.columns):
        raise KeyError("anchors file must contain k,E_anchor")

    anchors["k"] = anchors["k"].astype(int)

    hit = anchors[
        anchors["k"] == int(args.anchor_k)
    ]

    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one anchor k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])

    Nmax = int(
        math.floor(
            float(args.tail_factor)
            * max(L_values)
        )
    )

    max_depth = int(math.floor(
        math.log(max(Nmax, 2), 2)
    )) + 2

    base = importlib.import_module(
        args.base_module
    )

    print("=" * 206)
    print("ROT-RH v277 — EXACT SELBERG TRANSFER / PHASE-CASCADE AUDIT")
    print("=" * 206)
    print("Xi / zeta / known-zero data         : NONE")
    print(f"anchor k                             : {args.anchor_k}")
    print(f"anchor E                             : {E:.15f}")
    print(f"L values                             : {L_values}")
    print(f"training L                           : {train_L}")
    print(f"holdout L                            : {hold_L}")
    print(f"tail factor                          : {args.tail_factor:g}")
    print(f"maximum arithmetic N                : {Nmax:,}")
    print(f"maximum cascade depth               : {max_depth}")
    print("=" * 206)

    # --------------------------------------------------------------
    # 1. Arithmetic + Selberg forcing
    # --------------------------------------------------------------
    print(f"[1] Arithmetic through N={Nmax:,}")

    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(
        numbers,
        dtype=np.int64,
    )
    lambdas = np.asarray(
        lambdas,
        dtype=np.float64,
    )

    lam = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    lam[numbers] = lambdas

    logs = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    idx = np.arange(
        2,
        Nmax + 1,
        dtype=np.float64,
    )
    logs[2:] = np.log(idx)

    sqrt_n = np.ones(
        Nmax + 1,
        dtype=np.float64,
    )
    sqrt_n[2:] = np.sqrt(idx)

    print("[2] Exact Selberg forcing")

    spf = smallest_prime_factor(Nmax)
    tau, g = selberg_factor_statistics(spf)
    del spf

    H = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    H[2:] = (
        g[2:]
        - logs[2:]
        - (
            tau[2:].astype(np.float64)
            - 2.0
        )
    )

    F = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    F[2:] = (
        H[2:]
        / (
            sqrt_n[2:]
            * logs[2:]
            * logs[2:]
        )
    )

    r = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    r[2:] = lam[2:] - 1.0

    x_true = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    x_true[2:] = (
        r[2:]
        / (
            sqrt_n[2:]
            * logs[2:]
        )
    )

    arithmetic_a = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    arithmetic_a[2:] = (
        lam[2:] + 1.0
    ) / sqrt_n[2:]

    # --------------------------------------------------------------
    # 3. JIT warmup + exact transfer identity
    # --------------------------------------------------------------
    print("[3] Exact linear transfer identity")

    warmN = min(Nmax, 64)
    _ = apply_K(
        F[:warmN + 1],
        arithmetic_a[:warmN + 1],
        logs[:warmN + 1],
        warmN,
    )

    Kx = apply_K(
        x_true,
        arithmetic_a,
        logs,
        Nmax,
    )

    transfer_resid = x_true - (
        F + Kx
    )

    max_transfer_error = float(
        np.max(
            np.abs(
                transfer_resid[2:]
            )
        )
    )

    # --------------------------------------------------------------
    # 4. Exact K^j F cascade
    # --------------------------------------------------------------
    print("[4] Exact phase cascade K^j F")

    # Precompute evaluation arrays for each L.
    eval_data = {}

    n_all = np.arange(
        2,
        Nmax + 1,
        dtype=np.float64,
    )

    phase_all = np.exp(
        1.0j * E * np.log(n_all)
    )

    for L in L_values:
        N = min(
            Nmax,
            int(math.floor(
                float(args.tail_factor)
                * float(L)
            )),
        )

        n = np.arange(
            2,
            N + 1,
            dtype=np.float64,
        )

        phi = (
            np.exp(-n / float(L))
            * phase_all[:N - 1]
        )

        T_r = complex(
            np.dot(
                phi,
                x_true[2:N + 1],
            )
        )

        correction2 = (
            np.exp(-2.0 / float(L))
            * np.exp(
                1.0j * E * math.log(2.0)
            )
            / (
                math.sqrt(2.0)
                * math.log(2.0)
            )
        )

        eval_data[L] = {
            "N": N,
            "phi": phi,
            "T_r": T_r,
            "T_q": T_r - correction2,
            "correction2": correction2,
            "layers": [],
        }

    layer_rows = []
    support_rows = []

    u = F.copy()
    reconstruction = np.zeros_like(
        F
    )

    for depth in tqdm(
        range(max_depth + 1),
        desc="Selberg cascade depth",
        unit="layer",
    ):
        reconstruction += u

        nz = np.flatnonzero(
            np.abs(u) > float(args.support_tol)
        )

        if len(nz):
            support_min = int(nz[0])
            support_max = int(nz[-1])
            layer_sup = float(
                np.max(
                    np.abs(
                        u[nz]
                    )
                )
            )
        else:
            support_min = -1
            support_max = -1
            layer_sup = 0.0

        expected_min = 2 ** (
            depth + 1
        )

        support_pass = bool(
            support_min < 0
            or support_min >= expected_min
        )

        support_rows.append({
            "depth": int(depth),
            "support_min": support_min,
            "support_max": support_max,
            "expected_min": expected_min,
            "support_doubling_pass": support_pass,
            "layer_supnorm": layer_sup,
        })

        for L in L_values:
            N = eval_data[L]["N"]
            phi = eval_data[L]["phi"]

            C = complex(
                np.dot(
                    phi,
                    u[2:N + 1],
                )
            )

            eval_data[L]["layers"].append(
                C
            )

            layer_rows.append({
                "L": int(L),
                "region": (
                    "TRAIN"
                    if L <= int(args.training_L_max)
                    else "HOLDOUT"
                ),
                "depth": int(depth),
                "support_min": support_min,
                "complex_abs": float(abs(C)),
                "real": float(np.real(C)),
                "imag": float(np.imag(C)),
                "imag_abs": float(
                    abs(np.imag(C))
                ),
            })

        if not len(nz):
            break

        u = apply_K(
            u,
            arithmetic_a,
            logs,
            Nmax,
        )

    actual_depths = max(
        row["depth"]
        for row in support_rows
    )

    reconstruction_error = float(
        np.max(
            np.abs(
                reconstruction[2:]
                - x_true[2:]
            )
        )
    )

    # --------------------------------------------------------------
    # 5. Neumann observable identities
    # --------------------------------------------------------------
    print("[5] Neumann observable identities")

    cutoff_rows = []
    max_observable_error = 0.0

    for L in L_values:
        layers = np.asarray(
            eval_data[L]["layers"],
            dtype=np.complex128,
        )

        reconstructed_T = complex(
            np.sum(layers)
        )

        T_r = eval_data[L]["T_r"]

        err = abs(
            reconstructed_T
            - T_r
        )

        max_observable_error = max(
            max_observable_error,
            err,
        )

        abs_sum = float(
            np.sum(
                np.abs(layers)
            )
        )

        imag_abs_sum = float(
            np.sum(
                np.abs(
                    np.imag(layers)
                )
            )
        )

        cutoff_rows.append({
            "L": int(L),
            "region": (
                "TRAIN"
                if L <= int(args.training_L_max)
                else "HOLDOUT"
            ),
            "N": int(eval_data[L]["N"]),
            "T_r_real": float(
                np.real(T_r)
            ),
            "T_r_imag": float(
                np.imag(T_r)
            ),
            "T_q_real": float(
                np.real(
                    eval_data[L]["T_q"]
                )
            ),
            "T_q_imag": float(
                np.imag(
                    eval_data[L]["T_q"]
                )
            ),
            "layer_sum_real": float(
                np.real(reconstructed_T)
            ),
            "layer_sum_imag": float(
                np.imag(reconstructed_T)
            ),
            "observable_identity_error": float(err),
            "absolute_complex_layer_sum": abs_sum,
            "absolute_imag_layer_sum": imag_abs_sum,
        })

    layer_df = pd.DataFrame(
        layer_rows
    )
    support_df = pd.DataFrame(
        support_rows
    )
    cutoff_df = pd.DataFrame(
        cutoff_rows
    )

    # --------------------------------------------------------------
    # 6. Training-only depth envelope
    # --------------------------------------------------------------
    print("[6] Training-only phase-layer envelope")

    train_layers = layer_df[
        layer_df["region"] == "TRAIN"
    ]

    # Use the maximum COMPLEX amplitude across training L at each depth.
    train_depth = (
        train_layers.groupby(
            "depth",
            as_index=False,
        )
        .agg(
            max_train_complex_abs=(
                "complex_abs",
                "max",
            ),
            max_train_imag_abs=(
                "imag_abs",
                "max",
            ),
        )
    )

    model = fit_geometric_envelope(
        train_depth["depth"].to_numpy(),
        train_depth[
            "max_train_complex_abs"
        ].to_numpy(),
        int(args.minimum_envelope_depth),
        float(args.envelope_safety),
    )

    layer_df[
        "frozen_geometric_bound"
    ] = layer_df["depth"].map(
        lambda j: geometric_bound(
            model,
            int(j),
        )
    )

    layer_df["envelope_margin"] = (
        layer_df[
            "frozen_geometric_bound"
        ]
        / np.maximum(
            layer_df["complex_abs"],
            1e-300,
        )
    )

    hold_envelope_rows = layer_df[
        (layer_df["region"] == "HOLDOUT")
        & (
            layer_df["depth"]
            >= int(args.minimum_envelope_depth)
        )
    ].copy()

    envelope_model_valid = bool(
        model["available"]
        and np.isfinite(model["Bsafe"])
        and 0.0 < model["q_fit"] < 1.0
        and model["q_fit"]
            <= float(args.maximum_envelope_q)
        and model["r2"]
            >= float(args.minimum_envelope_r2)
    )

    all_holdout_envelope_pass = bool(
        envelope_model_valid
        and len(hold_envelope_rows)
        and np.all(
            hold_envelope_rows[
                "complex_abs"
            ].to_numpy()
            <= hold_envelope_rows[
                "frozen_geometric_bound"
            ].to_numpy()
        )
    )

    min_holdout_margin = (
        float(
            hold_envelope_rows[
                "envelope_margin"
            ].min()
        )
        if (
            envelope_model_valid
            and len(hold_envelope_rows)
        )
        else float("nan")
    )

    # --------------------------------------------------------------
    # 7. Frozen absolute cascade-sum bound
    # --------------------------------------------------------------
    train_cut = cutoff_df[
        cutoff_df["region"] == "TRAIN"
    ]
    hold_cut = cutoff_df[
        cutoff_df["region"] == "HOLDOUT"
    ]

    frozen_abs_sum_bound = (
        float(args.absolute_sum_safety)
        * float(
            train_cut[
                "absolute_complex_layer_sum"
            ].max()
        )
    )

    cutoff_df[
        "frozen_absolute_sum_bound"
    ] = frozen_abs_sum_bound

    cutoff_df[
        "absolute_sum_margin"
    ] = (
        frozen_abs_sum_bound
        / np.maximum(
            cutoff_df[
                "absolute_complex_layer_sum"
            ],
            1e-300,
        )
    )

    hold_abs_sum_pass = bool(
        len(hold_cut)
        and (
            hold_cut[
                "absolute_complex_layer_sum"
            ]
            <= frozen_abs_sum_bound
        ).all()
    )

    min_hold_abs_sum_margin = (
        float(
            cutoff_df[
                cutoff_df["region"]
                == "HOLDOUT"
            ][
                "absolute_sum_margin"
            ].min()
        )
        if len(hold_cut)
        else float("nan")
    )

    # --------------------------------------------------------------
    # 8. Gates / classification
    # --------------------------------------------------------------
    support_pass = bool(
        support_df[
            "support_doubling_pass"
        ].all()
    )

    gates = {
        "exact_linear_transfer_identity": bool(
            max_transfer_error
            <= float(
                args.transfer_identity_tol
            )
        ),
        "finite_Neumann_coefficient_reconstruction": bool(
            reconstruction_error
            <= float(
                args.neumann_identity_tol
            )
        ),
        "finite_Neumann_observable_reconstruction": bool(
            max_observable_error
            <= float(
                args.neumann_identity_tol
            )
        ),
        "support_doubles_each_layer": support_pass,
        "training_geometric_envelope_valid": (
            envelope_model_valid
        ),
        "prospective_holdout_layer_envelope": (
            all_holdout_envelope_pass
        ),
        "prospective_holdout_absolute_layer_sum": (
            hold_abs_sum_pass
        ),
    }

    failed = [
        name
        for name, ok in gates.items()
        if not ok
    ]

    if not failed:
        mechanism = (
            "EXACT_SELBERG_PHASE_CASCADE_SUMMABILITY_PROSPECTIVELY_SUPPORTED"
        )
        next_theorem = (
            "Prove a cutoff-uniform summable majorant for the exact layers "
            "<phi_L,K^j F>. The finite recursion is exact and support doubles, "
            "so the theorem should target the multiplicative phase cancellation "
            "inside each transfer layer, not raw cutoff decay."
        )
    else:
        mechanism = (
            "SIMPLE_GEOMETRIC_SELBERG_PHASE_CASCADE_NOT_ESTABLISHED"
        )
        next_theorem = (
            "The exact transfer identity remains valid, but its phase layers do "
            "not satisfy the preregistered simple summability model. Inspect the "
            "layer table before proposing another boundedness mechanism."
        )

    verdict = (
        "EXACT_SELBERG_PHASE_CASCADE_AUDIT_VERIFIED"
        if not failed
        else
        "EXACT_SELBERG_PHASE_CASCADE_AUDIT_GATE_FAILURE"
    )

    # --------------------------------------------------------------
    # Files
    # --------------------------------------------------------------
    prefix = args.prefix

    layer_path = Path(
        prefix + "_LAYERS.csv"
    )
    support_path = Path(
        prefix + "_SUPPORT.csv"
    )
    cutoff_path = Path(
        prefix + "_CUTOFFS.csv"
    )
    summary_path = Path(
        prefix + "_SUMMARY.json"
    )
    theorem_path = Path(
        prefix + "_NEXT_THEOREM.md"
    )

    layer_df.to_csv(
        layer_path,
        index=False,
    )
    support_df.to_csv(
        support_path,
        index=False,
    )
    cutoff_df.to_csv(
        cutoff_path,
        index=False,
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "exact_transfer": {
            "equation": "x=F+Kx",
            "K": (
                "K_{n,d}=-(Lambda(n/d)+1)(n/d)^(-1/2)"
                "log(d)/(log n)^2"
            ),
            "maximum_pointwise_transfer_error": (
                max_transfer_error
            ),
            "maximum_coefficient_Neumann_error": (
                reconstruction_error
            ),
            "maximum_observable_Neumann_error": (
                max_observable_error
            ),
            "actual_cascade_depth": (
                actual_depths
            ),
            "support_doubling_pass": (
                support_pass
            ),
        },
        "training_only_envelope": model,
        "prospective_holdout": {
            "all_layer_envelope_pass": (
                all_holdout_envelope_pass
            ),
            "minimum_layer_envelope_margin": (
                min_holdout_margin
            ),
            "frozen_absolute_layer_sum_bound": (
                frozen_abs_sum_bound
            ),
            "holdout_absolute_layer_sum_pass": (
                hold_abs_sum_pass
            ),
            "minimum_absolute_sum_margin": (
                min_hold_abs_sum_margin
            ),
        },
        "interpretation": {
            "what_v276_closed": (
                "Global natural Selberg JACOBIAN row gain at the actual "
                "arithmetic state."
            ),
            "what_v277_tests": (
                "The exact arithmetic Selberg TRANSFER and whether its fixed-E "
                "phase cascade is uniformly summable."
            ),
            "important_distinction": (
                "The exact transfer K is not the v276 Jacobian J; v276's q<1 "
                "does not automatically imply ||K||<1."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN. A pass would identify an exact multiscale Selberg cascade "
            "whose layer summability is the next analytic theorem; it would not "
            "itself prove the one-anchor Abel bound."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            summary,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v277 — exact Selberg phase cascade

## Exact transfer

For

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`,

Selberg's identity gives exactly

`x=F+Kx`

with

`K_{{n,d}}=-(Lambda(n/d)+1)(n/d)^(-1/2)
log(d)/(log n)^2`.

The transfer is strictly causal and `K^j F` is supported only on
`n>=2^(j+1)`.

## Exact one-anchor expansion

For

`phi_L(n)=exp(-n/L)n^(iE*)`,

`T_r(L)=sum_j <phi_L,K^jF>`.

The operator-centered `q` transform differs by the bounded `n=2` correction.

## Frozen training envelope

Minimum fitted depth:

`{model["minimum_depth"]}`

Training-only fitted geometric ratio:

`q_depth = {model["q_fit"]}`

Training R^2:

`{model["r2"]}`

Frozen safe amplitude:

`Bsafe = {model["Bsafe"]}`

## Prospective holdout

Layer envelope pass:

`{all_holdout_envelope_pass}`

Minimum holdout layer margin:

`{min_holdout_margin}`

Frozen absolute cascade-sum bound:

`{frozen_abs_sum_bound}`

Holdout absolute cascade-sum pass:

`{hold_abs_sum_pass}`

## Status

Mechanism:

`{mechanism}`

{next_theorem}

This does not yet prove uniform boundedness as `L->infinity`. The required
analytic result is a cutoff-uniform summable majorant on the exact phase
cascade layers.
""",
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # Console
    # --------------------------------------------------------------
    print()
    print("=" * 206)
    print("ROT-RH v277 — EXACT SELBERG PHASE-CASCADE SUMMARY")
    print("=" * 206)

    print("EXACT IDENTITIES")
    print("-" * 206)
    print(
        "max x-(F+Kx) error                 : "
        f"{max_transfer_error:.3e}"
    )
    print(
        "max coefficient Neumann error      : "
        f"{reconstruction_error:.3e}"
    )
    print(
        "max observable Neumann error       : "
        f"{max_observable_error:.3e}"
    )
    print(
        "support-doubling identity          : "
        f"{support_pass}"
    )
    print(
        "actual cascade depth              : "
        f"{actual_depths}"
    )

    print()
    print("TRAINING-ONLY LAYER ENVELOPE")
    print("-" * 206)
    print(
        "minimum fitted depth              : "
        f"{model['minimum_depth']}"
    )
    print(
        "fitted q_depth                    : "
        f"{model['q_fit']:.6f}"
    )
    print(
        "fit R2                            : "
        f"{model['r2']:.6f}"
    )
    print(
        "frozen Bsafe                      : "
        f"{model['Bsafe']:.6e}"
    )
    print(
        "envelope model valid              : "
        f"{envelope_model_valid}"
    )

    print()
    print("PROSPECTIVE HOLDOUT")
    print("-" * 206)
    print(
        "all layer envelopes pass          : "
        f"{all_holdout_envelope_pass}"
    )
    print(
        "minimum layer margin              : "
        f"{min_holdout_margin:.6f}"
    )
    print(
        "frozen absolute layer-sum bound   : "
        f"{frozen_abs_sum_bound:.6e}"
    )
    print(
        "absolute layer-sum holdout pass   : "
        f"{hold_abs_sum_pass}"
    )
    print(
        "minimum absolute-sum margin       : "
        f"{min_hold_abs_sum_margin:.6f}"
    )

    print()
    print("MECHANISM                            :", mechanism)
    print("=" * 206)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print("VERDICT                              :", verdict)
    print(
        "PROOF VERDICT                        : OPEN — "
        "UNIFORM SUMMABILITY OF EXACT SELBERG PHASE CASCADE"
    )
    print("=" * 206)

    print("Files written:")
    print(" ", layer_path)
    print(" ", support_path)
    print(" ", cutoff_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
