#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v296 — R^7 ACTUAL-ORBIT SCALE-RECURSION ATTACK
======================================================

Purpose
-------
v295 reduced the remaining shallow/cutoff bridge to the all-N centered
Mangoldt prefix theorem.  v257 already classified a one-anchor bounded prefix
as RH-implying, so merely extending N again is not proof progress.

The next non-tautological mechanism is the exact block fixed-point recursion.

For the smooth-preconditioned Selberg transfer

    x = F0 + R x,

fix the independently selected block power m=7 (selected before v295 in the
v287/v288 line).  Define

    G7 = (I + R + ... + R^6) F0.

Then exactly

    x = G7 + R^7 x.

Because every application of R doubles support, the output prefix through

    N = 2^7 D = 128 D

of R^7 x depends only on the input coefficients x_2,...,x_D.

Let

    ||u||_pref,M
      = max_{2<=K<=M}
          |sum_{n=2}^K u_n exp(i E* log n)|.

If one could prove globally

    ||R^7 x||_pref,128D
      <= q ||x||_pref,D,          q < 1,

on the ACTUAL arithmetic orbit, and

    ||G7||_pref,N <= C_G

for every N, then

    M(128D) <= C_G + q M(D).

Iterating over scales gives

    sup_N M(N) <= max(finite head, C_G/(1-q)),

and therefore the all-N centered-prefix theorem (up to the fixed n=2
convention correction already isolated in v295).

Why this differs from v288
--------------------------
v288 studies the worst-case real-input operator norm of R^7.  v296 studies
the exact physical arithmetic orbit x itself.  This is weaker than an
operator-norm theorem and may permit arithmetic cancellations that arbitrary
real inputs do not.

Prospective design
------------------
The block power m=7 is frozen from v287/v288.

Default matched scales:
    DEVELOPMENT
        D=4096   -> N=524288
        D=8192   -> N=1048576
        D=16384  -> N=2097152

    NEW-QUANTITY HOLDOUT
        D=32768  -> N=4194304
        D=65536  -> N=8388608

No arithmetic beyond N=8388608 is needed; this range was already used before
v295.  The quantity tested here is new, but the arithmetic range itself is
not claimed to be unseen.

The DEVELOPMENT constants are frozen as

    q_safe = residual_safety * max_DEVELOPMENT q_actual(D)

and

    C_G_safe = forcing_safety * max_DEVELOPMENT ||G7||_pref,128D.

No scale fit is used as a gate.

Interpretation
--------------
PASS:
    Prospective evidence supports an actual-orbit scale recursion
        M(128D) <= C_G + q M(D), q<1.
    The next analytic theorem is to prove BOTH the residual contraction and
    the finite-block forcing bound uniformly for all D.

FAIL:
    Do not retune the holdout.  Inspect whether failure comes from the R^7
    residual gain or from G7.  This distinguishes the two analytic obstacles.

Proof status
------------
A finite pass is NOT a proof of the all-N prefix theorem, cutoff independence,
Fredholm-Xi, or RH.  The all-scale inequalities are the theorem.

No Xi, zeta values, zeta'/zeta values, or known zero ordinates are used.

Dependencies:
    numpy, pandas, tqdm, numba

Version: 296
"""

from __future__ import annotations

import argparse
import gc
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 296


def parse_ints(text):
    return [
        int(x.strip())
        for x in str(text).split(",")
        if x.strip()
    ]


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--D-checkpoints",
        default="4096,8192,16384,32768,65536",
    )
    ap.add_argument(
        "--development-D-max",
        type=int,
        default=16384,
    )

    ap.add_argument(
        "--block-power",
        type=int,
        default=7,
    )

    ap.add_argument(
        "--residual-safety",
        type=float,
        default=1.35,
    )
    ap.add_argument(
        "--forcing-safety",
        type=float,
        default=1.35,
    )
    ap.add_argument(
        "--maximum-frozen-q",
        type=float,
        default=0.95,
    )

    ap.add_argument(
        "--support-tol",
        type=float,
        default=1e-15,
    )
    ap.add_argument(
        "--identity-tol",
        type=float,
        default=3e-10,
    )

    ap.add_argument(
        "--v295-summary",
        default="rot_rh_shallow_prefix_closure_v295_SUMMARY.json",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_R7_actual_orbit_scale_recursion_v296",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    if int(args.block_power) != 7:
        raise ValueError(
            "v296 freezes m=7 from the independently selected v287/v288 line."
        )

    if not (
        args.residual_safety > 1.0
        and args.forcing_safety > 1.0
    ):
        raise ValueError(
            "Safety factors must exceed 1."
        )

    if not (
        0.0 < float(args.maximum_frozen_q) < 1.0
    ):
        raise ValueError(
            "--maximum-frozen-q must lie in (0,1)"
        )

    try:
        from numba import njit
    except Exception as exc:
        raise RuntimeError(
            "v296 requires numba.\n"
            "Install with:\n\n"
            "    pip install numba\n\n"
            f"Import error: {exc}"
        )

    D_values = sorted(
        set(parse_ints(args.D_checkpoints))
    )
    if not D_values:
        raise ValueError("No D checkpoints")

    development = [
        D for D in D_values
        if D <= int(args.development_D_max)
    ]
    holdout = [
        D for D in D_values
        if D > int(args.development_D_max)
    ]

    if not development or not holdout:
        raise ValueError(
            "Need DEVELOPMENT and HOLDOUT D checkpoints"
        )

    m = int(args.block_power)
    support_factor = 2 ** m

    pairs = [
        (int(D), int(support_factor * D))
        for D in D_values
    ]
    Nmax = max(N for _, N in pairs)

    # ------------------------------------------------------------------
    # Anchor
    # ------------------------------------------------------------------

    anchors = pd.read_csv(args.anchors)
    need = {"k", "E_anchor"}
    miss = need - set(anchors.columns)
    if miss:
        raise KeyError(
            f"anchors missing columns {sorted(miss)}"
        )

    anchors["k"] = anchors["k"].astype(int)

    hit = anchors[
        anchors["k"] == int(args.anchor_k)
    ]
    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one anchor k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])
    base = importlib.import_module(
        args.base_module
    )

    # ------------------------------------------------------------------
    # Numba helpers
    # ------------------------------------------------------------------

    @njit(cache=True)
    def build_spf(N):
        spf = np.arange(
            N + 1,
            dtype=np.int32,
        )
        spf[0] = 0

        if N >= 1:
            spf[1] = 1

        r = int(math.sqrt(N))
        for p in range(2, r + 1):
            if spf[p] != p:
                continue

            for n in range(
                p * p,
                N + 1,
                p,
            ):
                if spf[n] == n:
                    spf[n] = p

        return spf

    @njit(cache=True)
    def selberg_factor_stats(spf):
        N = len(spf) - 1

        tau = np.ones(
            N + 1,
            dtype=np.int32,
        )
        omega = np.zeros(
            N + 1,
            dtype=np.uint8,
        )
        exponent = np.zeros(
            N + 1,
            dtype=np.uint8,
        )
        distinct_log_sum = np.zeros(
            N + 1,
            dtype=np.float64,
        )
        g = np.zeros(
            N + 1,
            dtype=np.float64,
        )

        for n in range(2, N + 1):
            p = int(spf[n])
            r = n // p
            lp = math.log(p)

            if (
                r > 1
                and r % p == 0
            ):
                old_e = int(
                    exponent[r]
                )
                new_e = old_e + 1

                exponent[n] = new_e
                omega[n] = omega[r]
                distinct_log_sum[n] = (
                    distinct_log_sum[r]
                )

                tau[n] = (
                    tau[r]
                    // (old_e + 1)
                    * (new_e + 1)
                )

                if omega[n] == 1:
                    g[n] = (
                        (2 * new_e - 1)
                        * lp
                        * lp
                    )
                else:
                    g[n] = g[r]
            else:
                exponent[n] = 1
                omega[n] = omega[r] + 1
                distinct_log_sum[n] = (
                    distinct_log_sum[r]
                    + lp
                )
                tau[n] = tau[r] * 2

                if omega[r] == 0:
                    g[n] = lp * lp
                elif omega[r] == 1:
                    g[n] = (
                        2.0
                        * lp
                        * distinct_log_sum[r]
                    )
                else:
                    g[n] = 0.0

        return tau, g

    @njit(cache=True)
    def apply_Klambda_from(
        u,
        lam,
        logs,
        N,
        d_start,
    ):
        out = np.zeros(
            N + 1,
            dtype=np.float64,
        )

        lo = max(2, int(d_start))

        for d in range(
            lo,
            N // 2 + 1,
        ):
            ud = u[d]
            if ud == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(
                2,
                dmax + 1,
            ):
                lk = lam[k]
                if lk == 0.0:
                    continue

                n = k * d

                out[n] -= (
                    (lk / math.sqrt(k))
                    * ld
                    / (
                        logs[n]
                        * logs[n]
                    )
                    * ud
                )

        return out

    @njit(cache=True)
    def solve_I_minus_Kb_from(
        v,
        logs,
        N,
        d_start,
    ):
        y = v.copy()
        lo = max(2, int(d_start))

        for d in range(
            lo,
            N // 2 + 1,
        ):
            yd = y[d]
            if yd == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(
                2,
                dmax + 1,
            ):
                n = k * d

                y[n] -= (
                    (1.0 / math.sqrt(k))
                    * ld
                    / (
                        logs[n]
                        * logs[n]
                    )
                    * yd
                )

        return y

    @njit(cache=True)
    def apply_R_from(
        u,
        lam,
        logs,
        N,
        d_start,
    ):
        tmp = apply_Klambda_from(
            u,
            lam,
            logs,
            N,
            d_start,
        )

        out_start = max(
            2,
            2 * int(d_start),
        )

        return solve_I_minus_Kb_from(
            tmp,
            logs,
            N,
            out_start,
        )

    @njit(cache=True)
    def prefix_sup_at_checkpoints(
        u,
        phase_re,
        phase_im,
        checkpoints,
        N,
    ):
        out = np.zeros(
            len(checkpoints),
            dtype=np.float64,
        )

        zr = 0.0
        zi = 0.0
        smax = 0.0
        ci = 0

        for n in range(
            2,
            N + 1,
        ):
            un = u[n]

            if un != 0.0:
                zr += (
                    un * phase_re[n]
                )
                zi += (
                    un * phase_im[n]
                )

            a = math.sqrt(
                zr * zr + zi * zi
            )
            if a > smax:
                smax = a

            while (
                ci < len(checkpoints)
                and n >= checkpoints[ci]
            ):
                out[ci] = smax
                ci += 1

        while ci < len(checkpoints):
            out[ci] = smax
            ci += 1

        return out

    @njit(cache=True)
    def first_support_from(
        u,
        tol,
        start,
    ):
        N = len(u) - 1
        lo = max(2, int(start))

        for n in range(
            lo,
            N + 1,
        ):
            if abs(u[n]) > tol:
                return n

        return -1

    # ------------------------------------------------------------------
    # Banner
    # ------------------------------------------------------------------

    print("=" * 214)
    print(
        "ROT-RH v296 — R^7 ACTUAL-ORBIT SCALE-RECURSION ATTACK"
    )
    print("=" * 214)
    print(
        "Xi / zeta / known-zero data         : NONE"
    )
    print(
        f"anchor k                             : {args.anchor_k}"
    )
    print(
        f"anchor E                             : {E:.15f}"
    )
    print(
        f"frozen block power                   : {m}"
    )
    print(
        f"support factor                       : {support_factor}"
    )
    print(
        f"DEVELOPMENT D                        : {development}"
    )
    print(
        f"NEW-QUANTITY HOLDOUT D               : {holdout}"
    )
    print(
        f"maximum arithmetic N                : {Nmax:,}"
    )
    print("=" * 214)

    # ------------------------------------------------------------------
    # Arithmetic
    # ------------------------------------------------------------------

    print(
        f"[1] Arithmetic through N={Nmax:,}"
    )

    numbers, lambdas, _ = (
        base.mangoldt_terms(Nmax)
    )

    numbers = np.asarray(
        numbers,
        dtype=np.int64,
    )
    lambdas = np.asarray(
        lambdas,
        dtype=np.float64,
    )

    lam = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )
    lam[numbers] = lambdas

    del numbers, lambdas
    gc.collect()

    logs = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    nf = np.arange(
        2,
        Nmax + 1,
        dtype=np.float64,
    )
    logs[2:] = np.log(nf)

    sqrt_n = np.ones(
        Nmax + 1,
        dtype=np.float64,
    )
    sqrt_n[2:] = np.sqrt(nf)

    phase_re = np.ones(
        Nmax + 1,
        dtype=np.float64,
    )
    phase_im = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    theta = np.remainder(
        E * logs[2:],
        2.0 * math.pi,
    )

    phase_re[2:] = np.cos(theta)
    phase_im[2:] = np.sin(theta)

    del theta

    # ------------------------------------------------------------------
    # Exact physical state / forcing
    # ------------------------------------------------------------------

    print(
        "[2] Exact Selberg forcing / physical fixed point"
    )

    spf = build_spf(Nmax)
    tau, g = selberg_factor_stats(
        spf
    )

    del spf
    gc.collect()

    F = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    F[2:] = (
        (
            g[2:]
            - logs[2:]
            - (
                tau[2:].astype(
                    np.float64
                )
                - 2.0
            )
        )
        / (
            sqrt_n[2:]
            * logs[2:]
            * logs[2:]
        )
    )

    x_true = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    x_true[2:] = (
        (
            lam[2:]
            - 1.0
        )
        / (
            sqrt_n[2:]
            * logs[2:]
        )
    )

    del tau, g, sqrt_n, nf
    gc.collect()

    warmN = min(
        Nmax,
        64,
    )

    _ = solve_I_minus_Kb_from(
        F[:warmN + 1],
        logs[:warmN + 1],
        warmN,
        2,
    )

    F0 = solve_I_minus_Kb_from(
        F,
        logs,
        Nmax,
        2,
    )

    del F
    gc.collect()

    # One-step fixed point.
    Rx = apply_R_from(
        x_true,
        lam,
        logs,
        Nmax,
        2,
    )

    fixed_point_error = float(
        np.max(
            np.abs(
                x_true[2:]
                - (
                    F0[2:]
                    + Rx[2:]
                )
            )
        )
    )

    del Rx
    gc.collect()

    # ------------------------------------------------------------------
    # G7 and R^7 x
    # ------------------------------------------------------------------

    print(
        "[3] Exact G7 block forcing and R^7 physical residual"
    )

    # G7 = sum_{j=0}^6 R^j F0
    G7 = np.zeros_like(
        x_true
    )
    layer = F0

    layer_support = 2

    for j in tqdm(
        range(m),
        desc="G7 forcing layers",
        unit="layer",
    ):
        G7 += layer

        if j < m - 1:
            layer = apply_R_from(
                layer,
                lam,
                logs,
                Nmax,
                layer_support,
            )
            layer_support *= 2

    del layer, F0
    gc.collect()

    # R^7 x.
    residual = x_true.copy()
    residual_support = 2

    for _ in tqdm(
        range(m),
        desc="R^7 physical residual",
        unit="power",
    ):
        residual = apply_R_from(
            residual,
            lam,
            logs,
            Nmax,
            residual_support,
        )
        residual_support *= 2

    block_identity_error = float(
        np.max(
            np.abs(
                x_true[2:]
                - (
                    G7[2:]
                    + residual[2:]
                )
            )
        )
    )

    expected_residual_support = (
        2 ** (m + 1)
    )

    actual_residual_support = (
        first_support_from(
            residual,
            float(args.support_tol),
            expected_residual_support,
        )
    )

    support_pass = bool(
        actual_residual_support < 0
        or actual_residual_support
        >= expected_residual_support
    )

    # ------------------------------------------------------------------
    # Prefix norms at matched input/output scales
    # ------------------------------------------------------------------

    print(
        "[4] Matched-scale phase-prefix norms"
    )

    D_arr = np.asarray(
        D_values,
        dtype=np.int64,
    )
    N_values = [
        support_factor * D
        for D in D_values
    ]
    N_arr = np.asarray(
        N_values,
        dtype=np.int64,
    )

    # M_x(D) input prefix.
    x_input_pref = (
        prefix_sup_at_checkpoints(
            x_true,
            phase_re,
            phase_im,
            D_arr,
            Nmax,
        )
    )

    # M_x(128D), M_G7(128D), M_R7x(128D).
    x_output_pref = (
        prefix_sup_at_checkpoints(
            x_true,
            phase_re,
            phase_im,
            N_arr,
            Nmax,
        )
    )

    G_output_pref = (
        prefix_sup_at_checkpoints(
            G7,
            phase_re,
            phase_im,
            N_arr,
            Nmax,
        )
    )

    R_output_pref = (
        prefix_sup_at_checkpoints(
            residual,
            phase_re,
            phase_im,
            N_arr,
            Nmax,
        )
    )

    rows = []

    for i, D in enumerate(D_values):
        N = support_factor * D

        M_in = float(
            x_input_pref[i]
        )
        M_out = float(
            x_output_pref[i]
        )
        M_G = float(
            G_output_pref[i]
        )
        M_R = float(
            R_output_pref[i]
        )

        q_actual = float(
            M_R
            / max(
                M_in,
                1e-300,
            )
        )

        triangle_bound = (
            M_G + M_R
        )

        region = (
            "DEVELOPMENT"
            if D
            <= int(
                args.development_D_max
            )
            else "HOLDOUT"
        )

        rows.append({
            "D": int(D),
            "N": int(N),
            "region": region,
            "x_prefix_D": M_in,
            "x_prefix_N": M_out,
            "G7_prefix_N": M_G,
            "R7x_prefix_N": M_R,
            "actual_residual_gain": q_actual,
            "triangle_bound": float(
                triangle_bound
            ),
            "triangle_margin": float(
                triangle_bound
                / max(
                    M_out,
                    1e-300,
                )
            ),
        })

    scale_df = pd.DataFrame(
        rows
    )

    # ------------------------------------------------------------------
    # Freeze DEVELOPMENT constants
    # ------------------------------------------------------------------

    print(
        "[5] Freeze DEVELOPMENT actual-orbit recursion constants"
    )

    dev = scale_df[
        scale_df["region"]
        == "DEVELOPMENT"
    ].copy()

    hold = scale_df[
        scale_df["region"]
        == "HOLDOUT"
    ].copy()

    raw_q_dev = float(
        dev[
            "actual_residual_gain"
        ].max()
    )

    q_safe = float(
        args.residual_safety
        * raw_q_dev
    )

    raw_G_dev = float(
        dev[
            "G7_prefix_N"
        ].max()
    )

    C_G_safe = float(
        args.forcing_safety
        * raw_G_dev
    )

    q_model_valid = bool(
        np.isfinite(q_safe)
        and 0.0 <= q_safe
        < float(
            args.maximum_frozen_q
        )
    )

    candidate_global_bound = (
        C_G_safe
        / (
            1.0 - q_safe
        )
        if q_model_valid
        else float("inf")
    )

    # ------------------------------------------------------------------
    # Prospective holdout
    # ------------------------------------------------------------------

    print(
        "[6] Frozen actual-orbit scale-recursion HOLDOUT"
    )

    holdout_rows = []

    residual_holdout_pass = True
    forcing_holdout_pass = True
    candidate_cover_pass = True

    min_residual_margin = float(
        "inf"
    )
    min_forcing_margin = float(
        "inf"
    )
    min_candidate_margin = float(
        "inf"
    )

    for row in hold.itertuples(
        index=False
    ):
        qv = float(
            row.actual_residual_gain
        )
        Gv = float(
            row.G7_prefix_N
        )
        Mout = float(
            row.x_prefix_N
        )

        residual_pass = bool(
            q_model_valid
            and qv <= q_safe
        )

        forcing_pass = bool(
            Gv <= C_G_safe
        )

        cover_pass = bool(
            np.isfinite(
                candidate_global_bound
            )
            and Mout
            <= candidate_global_bound
        )

        residual_margin = (
            q_safe
            / max(
                qv,
                1e-300,
            )
            if q_model_valid
            else 0.0
        )

        forcing_margin = float(
            C_G_safe
            / max(
                Gv,
                1e-300,
            )
        )

        candidate_margin = (
            float(
                candidate_global_bound
                / max(
                    Mout,
                    1e-300,
                )
            )
            if np.isfinite(
                candidate_global_bound
            )
            else 0.0
        )

        residual_holdout_pass = (
            residual_holdout_pass
            and residual_pass
        )
        forcing_holdout_pass = (
            forcing_holdout_pass
            and forcing_pass
        )
        candidate_cover_pass = (
            candidate_cover_pass
            and cover_pass
        )

        min_residual_margin = min(
            min_residual_margin,
            residual_margin,
        )
        min_forcing_margin = min(
            min_forcing_margin,
            forcing_margin,
        )
        min_candidate_margin = min(
            min_candidate_margin,
            candidate_margin,
        )

        holdout_rows.append({
            "D": int(row.D),
            "N": int(row.N),
            "actual_residual_gain": qv,
            "frozen_q_safe": q_safe,
            "residual_margin": (
                residual_margin
            ),
            "residual_pass": (
                residual_pass
            ),
            "G7_prefix_N": Gv,
            "frozen_C_G_safe": (
                C_G_safe
            ),
            "forcing_margin": (
                forcing_margin
            ),
            "forcing_pass": (
                forcing_pass
            ),
            "x_prefix_N": Mout,
            "candidate_global_bound": (
                candidate_global_bound
            ),
            "candidate_margin": (
                candidate_margin
            ),
            "candidate_covers": (
                cover_pass
            ),
        })

    holdout_df = pd.DataFrame(
        holdout_rows
    )

    # ------------------------------------------------------------------
    # Optional v295 comparison
    # ------------------------------------------------------------------

    v295_loaded = False
    v295_Cx = float("nan")

    p295 = Path(
        args.v295_summary
    )

    if p295.exists():
        v295 = json.loads(
            p295.read_text(
                encoding="utf-8"
            )
        )

        if int(
            v295.get(
                "version",
                -1,
            )
        ) == 295:
            try:
                v295_Cx = float(
                    v295[
                        "exact_n2_bridge"
                    ][
                        "C_x_from_C_q"
                    ]
                )
                v295_loaded = bool(
                    np.isfinite(
                        v295_Cx
                    )
                )
            except Exception:
                v295_loaded = False

    # ------------------------------------------------------------------
    # Gates
    # ------------------------------------------------------------------

    gates = {
        "exact_one_step_fixed_point": bool(
            fixed_point_error
            <= float(
                args.identity_tol
            )
        ),
        "exact_R7_block_identity": bool(
            block_identity_error
            <= float(
                args.identity_tol
            )
        ),
        "R7_support_x128": (
            support_pass
        ),
        "development_frozen_q_below_gate": (
            q_model_valid
        ),
        "holdout_actual_R7_residual_gain": (
            residual_holdout_pass
        ),
        "holdout_G7_prefix_bound": (
            forcing_holdout_pass
        ),
        "candidate_recursive_bound_covers_holdout": (
            candidate_cover_pass
        ),
    }

    failed = [
        name
        for name, ok
        in gates.items()
        if not ok
    ]

    if not failed:
        mechanism = (
            "R7_ACTUAL_ORBIT_SCALE_RECURSION_PROSPECTIVELY_SUPPORTED"
        )
        verdict = (
            "R7_ACTUAL_ORBIT_ALLN_PREFIX_MECHANISM_VERIFIED"
        )
        next_theorem = (
            "Prove uniformly for every D that "
            "||R^7 x||_pref,128D <= q ||x||_pref,D with q<1, and prove "
            "sup_N ||G7||_pref,N <= C_G. The exact block identity then gives "
            "M(128D)<=C_G+qM(D), whose iteration yields an all-N centered-prefix "
            "bound. The finite pass is evidence only; the all-scale inequalities "
            "are the theorem."
        )
    else:
        mechanism = (
            "R7_ACTUAL_ORBIT_SCALE_RECURSION_NOT_ESTABLISHED"
        )
        verdict = (
            "R7_ACTUAL_ORBIT_ALLN_PREFIX_GATE_FAILURE"
        )

        if (
            not residual_holdout_pass
            and forcing_holdout_pass
        ):
            next_theorem = (
                "The finite-block forcing is stable, but the actual R^7 residual "
                "does not satisfy the frozen contraction. The remaining obstruction "
                "is the orbit-specific R^7 transfer, not G7."
            )
        elif (
            residual_holdout_pass
            and not forcing_holdout_pass
        ):
            next_theorem = (
                "The actual R^7 residual contraction survives, but G7 does not "
                "stay under the frozen prefix bound. Attack the finite seven-layer "
                "block forcing analytically rather than the infinite residual."
            )
        else:
            next_theorem = (
                "Both pieces need inspection. Do not retune this holdout. "
                "Use the scale table to identify whether q_actual or G7 is the "
                "dominant source of growth."
            )

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------

    out = args.prefix

    scales_path = Path(
        out + "_SCALES.csv"
    )
    holdout_path = Path(
        out + "_HOLDOUT.csv"
    )
    summary_path = Path(
        out + "_SUMMARY.json"
    )
    theorem_path = Path(
        out + "_NEXT_THEOREM.md"
    )

    scale_df.to_csv(
        scales_path,
        index=False,
    )

    holdout_df.to_csv(
        holdout_path,
        index=False,
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "zeta_log_derivative_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(
                args.anchor_k
            ),
            "E": E,
        },
        "block": {
            "power": m,
            "support_factor": (
                support_factor
            ),
            "identity": (
                "x=G7+R^7x, "
                "G7=(I+R+...+R^6)F0"
            ),
            "expected_R7_support_min": (
                expected_residual_support
            ),
            "actual_R7_support_min": (
                actual_residual_support
            ),
        },
        "exact_structure": {
            "one_step_fixed_point_error": (
                fixed_point_error
            ),
            "R7_block_identity_error": (
                block_identity_error
            ),
            "support_pass": (
                support_pass
            ),
        },
        "prospective_design": {
            "D_values": D_values,
            "development_D": (
                development
            ),
            "holdout_D": (
                holdout
            ),
            "matched_pairs": [
                {
                    "D": int(D),
                    "N": int(
                        support_factor * D
                    ),
                }
                for D in D_values
            ],
            "note": (
                "m=7 is frozen from v287/v288. "
                "The arithmetic range itself predates v295; "
                "the actual-orbit recursion quantity is new."
            ),
        },
        "development_freeze": {
            "raw_max_actual_residual_gain": (
                raw_q_dev
            ),
            "residual_safety": float(
                args.residual_safety
            ),
            "q_safe": q_safe,
            "maximum_frozen_q": float(
                args.maximum_frozen_q
            ),
            "q_model_valid": (
                q_model_valid
            ),
            "raw_max_G7_prefix": (
                raw_G_dev
            ),
            "forcing_safety": float(
                args.forcing_safety
            ),
            "C_G_safe": C_G_safe,
            "candidate_recursive_global_bound": (
                candidate_global_bound
            ),
        },
        "holdout": {
            "residual_pass": (
                residual_holdout_pass
            ),
            "minimum_residual_margin": (
                min_residual_margin
            ),
            "forcing_pass": (
                forcing_holdout_pass
            ),
            "minimum_forcing_margin": (
                min_forcing_margin
            ),
            "candidate_cover_pass": (
                candidate_cover_pass
            ),
            "minimum_candidate_margin": (
                min_candidate_margin
            ),
        },
        "v295_reference": {
            "loaded": (
                v295_loaded
            ),
            "conditional_physical_prefix_C_x": (
                v295_Cx
            ),
            "note": (
                "v295 C_x remains conditional on the all-N centered-prefix theorem; "
                "it is only a comparison diagnostic here."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": (
            next_theorem
        ),
        "proof_status": (
            "OPEN. A finite prospective pass would identify a concrete "
            "scale-recursion mechanism for the all-N centered-prefix theorem. "
            "The required all-D residual and G7 bounds remain analytic obligations."
        ),
        "runtime_seconds": (
            time.perf_counter()
            - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v296 — R^7 actual-orbit scale recursion

## Exact block identity

`x = G7 + R^7 x`

with

`G7 = (I + R + ... + R^6) F0`.

Because `R` doubles support, `R^7` maps input support `<=D` into output
support beginning at scale `128D`.

Define

`M_x(D)=||x||_(pref,D)`.

The candidate all-scale theorem is

`||R^7 x||_(pref,128D) <= q M_x(D)`

with one constant `q<1`, together with

`||G7||_(pref,N) <= C_G`

for all `N`.

Then

`M_x(128D) <= C_G + q M_x(D)`.

Iterating gives a uniform all-scale bound.  For example on exact powers of
128,

`M_x(128^r D0) <= C_G(1+q+...+q^(r-1)) + q^r M_x(D0)`

and hence

`limsup M_x <= C_G/(1-q)`.

Finite DEVELOPMENT freeze:

`q_safe = {q_safe}`

`C_G_safe = {C_G_safe}`

`candidate C_G/(1-q) = {candidate_global_bound}`.

Prospective mechanism:

`{mechanism}`

{next_theorem}

## Proof status

OPEN.  This script tests the mechanism on finite matched scales only.  An
all-D proof is required.  No zeta, Xi, or zero ordinates enter the construction
or the test.
""",
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Console summary
    # ------------------------------------------------------------------

    print()
    print("=" * 214)
    print(
        "ROT-RH v296 — R^7 ACTUAL-ORBIT SCALE-RECURSION SUMMARY"
    )
    print("=" * 214)

    print("EXACT STRUCTURE")
    print("-" * 214)
    print(
        "max x-(F0+Rx) error                 : "
        f"{fixed_point_error:.3e}"
    )
    print(
        "max x-(G7+R^7x) error               : "
        f"{block_identity_error:.3e}"
    )
    print(
        "expected R^7 support min             : "
        f"{expected_residual_support}"
    )
    print(
        "actual R^7 support min               : "
        f"{actual_residual_support}"
    )
    print(
        "support x128 pass                    : "
        f"{support_pass}"
    )

    print()
    print("MATCHED SCALE RECURSION")
    print("-" * 214)

    for row in scale_df.itertuples(
        index=False
    ):
        print(
            f"{str(row.region)[:4]:4s} "
            f"D={int(row.D):>6d} "
            f"N={int(row.N):>8d} "
            f"M(D)={float(row.x_prefix_D):.6e} "
            f"M(N)={float(row.x_prefix_N):.6e} "
            f"G7={float(row.G7_prefix_N):.6e} "
            f"R7x={float(row.R7x_prefix_N):.6e} "
            f"q_actual={float(row.actual_residual_gain):.6f}"
        )

    print()
    print("FROZEN DEVELOPMENT CONSTANTS")
    print("-" * 214)
    print(
        "raw max residual gain                : "
        f"{raw_q_dev:.9f}"
    )
    print(
        "frozen q_safe                        : "
        f"{q_safe:.9f}"
    )
    print(
        "q_safe below gate                    : "
        f"{q_model_valid}"
    )
    print(
        "raw max G7 prefix                    : "
        f"{raw_G_dev:.9e}"
    )
    print(
        "frozen C_G_safe                      : "
        f"{C_G_safe:.9e}"
    )
    print(
        "candidate C_G/(1-q)                  : "
        f"{candidate_global_bound:.9e}"
    )

    print()
    print("PROSPECTIVE HOLDOUT")
    print("-" * 214)
    print(
        "R^7 actual residual gain pass        : "
        f"{residual_holdout_pass}"
    )
    print(
        "minimum residual margin              : "
        f"{min_residual_margin:.6f}"
    )
    print(
        "G7 prefix bound pass                 : "
        f"{forcing_holdout_pass}"
    )
    print(
        "minimum G7 margin                    : "
        f"{min_forcing_margin:.6f}"
    )
    print(
        "candidate recursive bound covers     : "
        f"{candidate_cover_pass}"
    )
    print(
        "minimum candidate margin             : "
        f"{min_candidate_margin:.6f}"
    )

    if v295_loaded:
        print()
        print("v295 REFERENCE")
        print("-" * 214)
        print(
            "conditional physical-prefix C_x     : "
            f"{v295_Cx:.9e}"
        )

    print()
    print(
        "MECHANISM                            :",
        mechanism,
    )
    print("=" * 214)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print(
        "VERDICT                              :",
        verdict,
    )
    print(
        "PROOF VERDICT                        : OPEN — "
        "ALL-D R^7 ORBIT RECURSION + G7 PREFIX THEOREM"
    )
    print("=" * 214)

    print("Files written:")
    print(" ", scales_path)
    print(" ", holdout_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
