#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v264 — SINGLE-ANCHOR LOG-L FLOW / ABSOLUTE-INTEGRABILITY AUDIT
====================================================================

Purpose
-------
v263 reduces the RH-facing problem (using the Platt-Trudgian finite-height
verification) to boundedness of one literal v102.1 scalar phase

    Q(L;E*)
      = P_L(E*) - M_L(E*) + M_inf^AC(E*),

at one fixed zero-free arithmetic anchor E*.

v264 attacks the exact cutoff-flow anatomy, not a larger root panel.

Let
    u = log L,
    r = n/L.

Since
    d/du exp(-n/L) = r exp(-n/L),
    d^2/du^2 exp(-n/L) = r(r-1) exp(-n/L),

the literal prime and PNT-main terms have exact log-L derivatives

    Q_u  = P_u - M_u,
    Q_uu = P_uu - M_uu.

M_inf^AC is independent of L and drops out.

Why this matters
----------------
A very strong sufficient theorem would be

    integral_{log L0}^infinity |Q_u(u)| du < infinity,

or, for example,

    |Q_u(L)| <= C L^{-p},  p>0.

Then Q(L) converges and is bounded.

But this condition may be TOO STRONG: under a critical-line spectral picture,
Q can remain bounded through signed/almost-periodic oscillation while |Q_u|
does not become integrable.

v264 therefore measures:

  * Q, Q_u, Q_uu on a log-uniform L grid;
  * exact discrete derivative formulas for prime and continuum pieces;
  * finite-difference cross-check of Q_u;
  * cumulative signed flow versus actual Q displacement;
  * cumulative absolute variation;
  * late-window power-law fit for |Q_u|;
  * dyadic-block maxima of |Q_u| and their decay/growth exponent;
  * sign changes and total-variation/net-displacement ratio.

Interpretation
--------------
If a robust positive decay exponent p>0 appears in dyadic maxima of |Q_u|,
an absolute-integrability theorem may be worth attacking.

If |Q_u| stays O(1) or grows while Q remains modest, the theorem must preserve
signed oscillation.  Then the next analytic target is a Mellin/explicit-formula
or transfer/coboundary representation, not absolute PNT estimates.

No Xi, zeta values, or known zeta zero ordinates are used.

Version: 264
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 264
EPS = np.finfo(float).eps


def geometric_grid(L0, L1, steps_per_doubling):
    L0 = float(L0)
    L1 = float(L1)
    spd = int(steps_per_doubling)
    if L1 <= L0:
        raise ValueError("L-end must exceed L-start")
    if spd < 1:
        raise ValueError("steps-per-doubling must be >=1")

    step = math.log(2.0) / spd
    u0 = math.log(L0)
    u1 = math.log(L1)
    n = int(math.floor((u1 - u0) / step)) + 1
    u = u0 + step * np.arange(n + 1, dtype=float)
    u = u[u <= u1 + 1e-13]

    if len(u) == 0 or abs(u[-1] - u1) > 1e-12:
        u = np.append(u, u1)

    return np.exp(u)


def simpson_log_counter(E, L, q):
    """
    v102.1-compatible finite PNT counterterm grid plus exact log-L derivatives.
    The omitted x>36L continuum is exponentially tiny; return its absolute
    phase/flow majorants for diagnostics.
    """
    ppc = max(16, int(round(int(q) / 16.0)))
    design_emax = 220.0
    xmax_factor = 36.0

    ymin = math.log(2.0)
    xmax = xmax_factor * float(L)
    ymax = math.log(xmax)

    dy_target = 2.0 * math.pi / (ppc * design_emax)
    ngrid = max(2049, int(math.ceil((ymax - ymin) / dy_target)) + 1)
    if ngrid % 2 == 0:
        ngrid += 1

    y = np.linspace(ymin, ymax, ngrid)
    dy = float(y[1] - y[0])
    x = np.exp(y)

    w = np.ones(ngrid, float)
    w[1:-1:2] = 4.0
    w[2:-1:2] = 2.0
    w *= dy / 3.0

    common = np.exp(0.5 * y - x / float(L))
    phase_coeff = w * common / y

    s = np.sin(float(E) * y)
    r = x / float(L)

    M = float(np.dot(s, phase_coeff))
    Mu = float(np.dot(s, phase_coeff * r))
    Muu = float(np.dot(s, phase_coeff * r * (r - 1.0)))

    # Simple absolute tail bounds for x>36L.  For phase:
    # 1/log(xmax) int x^-1/2 e^-x/L dx.
    # Use erfc closed form: int_a^inf x^-1/2 e^-x/L dx
    # = sqrt(pi L) erfc(sqrt(a/L)).
    raw = (
        math.sqrt(math.pi * float(L))
        * math.erfc(math.sqrt(xmax / float(L)))
    )
    phase_tail = raw / math.log(xmax)

    # For u-derivative multiply by x/L:
    # (1/L) int_a^inf x^1/2 e^-x/L dx
    # = sqrt(L) Gamma(3/2,a/L).
    # Gamma(3/2,z)=0.5 sqrt(pi) erfc(sqrt z)+sqrt(z)e^-z.
    z = xmax / float(L)
    gamma32 = (
        0.5 * math.sqrt(math.pi) * math.erfc(math.sqrt(z))
        + math.sqrt(z) * math.exp(-z)
    )
    flow_tail = math.sqrt(float(L)) * gamma32 / math.log(xmax)

    # Second flow derivative absolute bound:
    # r|r-1| <= r(r+1), so bound by moments r + r^2.
    # Gamma(5/2,z)=3/4 sqrt(pi)erfc(sqrt z)
    #                 +(z^(3/2)+1.5 sqrt z)e^-z
    gamma52 = (
        0.75 * math.sqrt(math.pi) * math.erfc(math.sqrt(z))
        + (z ** 1.5 + 1.5 * math.sqrt(z)) * math.exp(-z)
    )
    second_tail = (
        math.sqrt(float(L)) * (gamma32 + gamma52)
        / math.log(xmax)
    )

    return M, Mu, Muu, phase_tail, flow_tail, second_tail


def prime_flow(
    E,
    L,
    tail_factor,
    numbers,
    lambdas,
):
    N = int(math.ceil(float(tail_factor) * float(L)))
    right = int(np.searchsorted(numbers, N, side="right"))

    n = numbers[:right].astype(float)
    lam = lambdas[:right].astype(float)
    logn = np.log(n)

    base = (
        lam
        / (logn * np.sqrt(n))
        * np.exp(-n / float(L))
        * np.sin(float(E) * logn)
    )
    r = n / float(L)

    P = float(np.sum(base))
    Pu = float(np.sum(base * r))
    Puu = float(np.sum(base * r * (r - 1.0)))

    return P, Pu, Puu, N


def linear_power_fit(L, y):
    L = np.asarray(L, float)
    y = np.asarray(y, float)
    keep = np.isfinite(L) & np.isfinite(y) & (L > 0) & (y > 0)

    L = L[keep]
    y = y[keep]
    if len(L) < 4:
        return dict(n=len(L), p=np.nan, r2=np.nan, C=np.nan)

    x = np.log(L)
    yy = np.log(y)

    A = np.column_stack([np.ones(len(x)), x])
    beta, *_ = np.linalg.lstsq(A, yy, rcond=None)
    pred = A @ beta

    sse = float(np.sum((yy - pred) ** 2))
    sst = float(np.sum((yy - np.mean(yy)) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0

    # y ~ C L^{-p}
    return {
        "n": int(len(L)),
        "p": float(-beta[1]),
        "r2": float(r2),
        "C": float(math.exp(beta[0])),
    }


def sign_changes(x, tol=1e-15):
    x = np.asarray(x, float)
    s = np.sign(x[np.abs(x) > tol])
    if len(s) < 2:
        return 0
    return int(np.sum(s[1:] * s[:-1] < 0))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--L-start", type=int, default=4000)
    ap.add_argument("--L-end", type=int, default=2048000)
    ap.add_argument("--steps-per-doubling", type=int, default=4)
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=16384)

    ap.add_argument(
        "--late-fraction",
        type=float,
        default=0.50,
        help="Fraction of largest-L samples used for pointwise |Q_u| fit.",
    )
    ap.add_argument(
        "--positive-decay-gate",
        type=float,
        default=0.05,
        help="Diagnostic p gate only; not a theorem.",
    )
    ap.add_argument(
        "--decay-r2-gate",
        type=float,
        default=0.50,
    )
    ap.add_argument(
        "--finite-difference-relative-tol",
        type=float,
        default=0.10,
        help="Interior central-difference Q_u cross-check tolerance.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_single_anchor_logL_flow_v264",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()

    if args.L_start < 2:
        raise ValueError("--L-start must be >=2")
    if args.L_end <= args.L_start:
        raise ValueError("--L-end must exceed --L-start")
    if not (0.2 <= args.late_fraction <= 0.9):
        raise ValueError("--late-fraction must be in [0.2,0.9]")

    anchors = pd.read_csv(args.anchors)
    need = {"k", "E_anchor"}
    miss = need - set(anchors.columns)
    if miss:
        raise KeyError(f"anchors file missing {sorted(miss)}")

    anchors["k"] = anchors["k"].astype(int)
    hit = anchors[anchors["k"] == int(args.anchor_k)]
    if len(hit) != 1:
        raise RuntimeError(
            f"Expected exactly one anchor for k={args.anchor_k}"
        )
    E = float(hit["E_anchor"].iloc[0])

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    Lgrid = geometric_grid(
        int(args.L_start),
        int(args.L_end),
        int(args.steps_per_doubling),
    )

    Nmax = int(
        math.ceil(float(args.tail_factor) * float(np.max(Lgrid)))
    )

    print("=" * 196)
    print("ROT-RH v264 — SINGLE-ANCHOR LOG-L FLOW / ABSOLUTE-INTEGRABILITY AUDIT")
    print("=" * 196)
    print("Xi / zeta / known-zero data        : NONE")
    print(f"anchor k                            : {args.anchor_k}")
    print(f"anchor E                            : {E:.15f}")
    print(f"L range                             : {args.L_start} .. {args.L_end}")
    print(f"steps per doubling                  : {args.steps_per_doubling}")
    print(f"number of L samples                 : {len(Lgrid)}")
    print(f"maximum arithmetic N               : {Nmax}")
    print("=" * 196)

    print(f"[1] Shared Mangoldt sieve through N={Nmax}")
    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(numbers, int)
    lambdas = np.asarray(lambdas, float)

    AC = float(
        v102.pnt_ac_phase(np.asarray([E], float))[0]
    )

    rows = []

    print("[2] Exact literal log-L flow")
    for Lf in tqdm(Lgrid, desc="log-L phase flow", unit="L"):
        L = float(Lf)

        P, Pu, Puu, N = prime_flow(
            E=E,
            L=L,
            tail_factor=float(args.tail_factor),
            numbers=numbers,
            lambdas=lambdas,
        )

        M, Mu, Muu, Mtail, Mutail, Muutail = simpson_log_counter(
            E=E,
            L=L,
            q=int(args.counter_q),
        )

        Q = P - M + AC
        Qu = Pu - Mu
        Quu = Puu - Muu

        rows.append({
            "L": L,
            "u_logL": math.log(L),
            "prime_N": int(N),
            "P": P,
            "M": M,
            "AC": AC,
            "Q": Q,
            "P_u": Pu,
            "M_u": Mu,
            "Q_u": Qu,
            "P_uu": Puu,
            "M_uu": Muu,
            "Q_uu": Quu,
            "counter_phase_tail_abs": Mtail,
            "counter_u_tail_abs": Mutail,
            "counter_uu_tail_abs": Muutail,
        })

    df = pd.DataFrame(rows)

    # --------------------------------------------------------------
    # Finite-difference derivative cross-check on the nonuniform last point.
    # np.gradient handles the actual u coordinates.
    # --------------------------------------------------------------
    u = df["u_logL"].to_numpy(float)
    Q = df["Q"].to_numpy(float)
    Qu = df["Q_u"].to_numpy(float)

    fd = np.gradient(Q, u, edge_order=2)
    df["Q_u_finite_difference"] = fd
    df["Q_u_fd_abs_error"] = np.abs(fd - Qu)
    df["Q_u_fd_rel_error"] = (
        np.abs(fd - Qu)
        / np.maximum(np.maximum(np.abs(fd), np.abs(Qu)), 1e-10)
    )

    interior = df.iloc[1:-1].copy()
    max_fd_rel = float(interior["Q_u_fd_rel_error"].max())

    # --------------------------------------------------------------
    # Integrate the exact Q_u over u.
    # --------------------------------------------------------------
    du = np.diff(u)
    qu_mid = 0.5 * (Qu[:-1] + Qu[1:])

    signed_inc = qu_mid * du
    abs_inc = np.abs(qu_mid) * du

    signed_cum = np.concatenate([[0.0], np.cumsum(signed_inc)])
    abs_cum = np.concatenate([[0.0], np.cumsum(abs_inc)])

    df["signed_integral_Q_u"] = signed_cum
    df["absolute_integral_Q_u"] = abs_cum
    df["actual_Q_minus_Q0"] = Q - Q[0]
    df["flow_reconstruction_error"] = np.abs(
        signed_cum - (Q - Q[0])
    )

    max_flow_recon = float(df["flow_reconstruction_error"].max())
    total_abs_variation = float(abs_cum[-1])
    net_displacement = float(abs(Q[-1] - Q[0]))
    tv_over_net = float(
        total_abs_variation / max(net_displacement, 1e-12)
    )

    # --------------------------------------------------------------
    # Late pointwise fit |Q_u| ~ C L^-p.
    # --------------------------------------------------------------
    nlate = max(
        4,
        int(math.ceil(float(args.late_fraction) * len(df))),
    )
    late = df.tail(nlate)

    point_fit = linear_power_fit(
        late["L"].to_numpy(float),
        np.abs(late["Q_u"].to_numpy(float)),
    )

    # --------------------------------------------------------------
    # Dyadic block maxima of |Q_u|.
    # --------------------------------------------------------------
    L0 = float(args.L_start)
    Lmax = float(args.L_end)

    block_rows = []
    j = 0
    while L0 * (2.0 ** j) <= Lmax * (1.0 + 1e-12):
        lo = L0 * (2.0 ** j)
        hi = min(L0 * (2.0 ** (j + 1)), Lmax * (1.0 + 1e-12))

        if hi < Lmax:
            g = df[(df["L"] >= lo) & (df["L"] < hi)]
        else:
            g = df[(df["L"] >= lo) & (df["L"] <= hi)]

        if len(g):
            idx = int(np.argmax(np.abs(g["Q_u"].to_numpy(float))))
            rr = g.iloc[idx]
            block_rows.append({
                "block_index": int(j),
                "L_lo": float(lo),
                "L_hi": float(hi),
                "L_at_max": float(rr["L"]),
                "max_abs_Q_u": float(abs(rr["Q_u"])),
                "max_abs_Q_uu": float(
                    np.max(np.abs(g["Q_uu"].to_numpy(float)))
                ),
                "Q_range": float(
                    g["Q"].max() - g["Q"].min()
                ),
                "Q_u_sign_changes": sign_changes(
                    g["Q_u"].to_numpy(float)
                ),
            })

        if hi >= Lmax:
            break
        j += 1

    blocks = pd.DataFrame(block_rows)

    # Fit only latter half of block maxima.
    if len(blocks) >= 4:
        bstart = len(blocks) // 2
        bfit_data = blocks.iloc[bstart:]
        block_fit = linear_power_fit(
            np.sqrt(
                bfit_data["L_lo"].to_numpy(float)
                * bfit_data["L_hi"].to_numpy(float)
            ),
            bfit_data["max_abs_Q_u"].to_numpy(float),
        )
    else:
        block_fit = dict(n=0, p=np.nan, r2=np.nan, C=np.nan)

    signs = sign_changes(Qu)
    q_range = float(np.max(Q) - np.min(Q))

    absolute_decay_supported = bool(
        np.isfinite(block_fit["p"])
        and block_fit["p"] >= float(args.positive_decay_gate)
        and block_fit["r2"] >= float(args.decay_r2_gate)
    )

    if absolute_decay_supported:
        mechanism = "POSITIVE_LOG_L_DERIVATIVE_DECAY_SUPPORTED"
        next_target = (
            "Attempt an analytic bound |Q_u(L)| <= C L^{-p}, p>0. "
            "If proved, Q has finite total variation and converges."
        )
    else:
        mechanism = "SIGNED_LOG_L_FLOW_REQUIRED"
        next_target = (
            "Do not pursue absolute derivative integrability. "
            "Seek an oscillatory Mellin/explicit-formula, transfer, or "
            "coboundary representation preserving signed cancellation."
        )

    gates = {
        "finite_difference_derivative_crosscheck_pass": bool(
            max_fd_rel <= float(args.finite_difference_relative_tol)
        ),
        "signed_flow_reconstructs_Q": bool(
            max_flow_recon <= max(1e-2, 0.05 * max(q_range, 1e-8))
        ),
        "all_values_finite": bool(
            np.all(np.isfinite(
                df[
                    ["Q", "Q_u", "Q_uu"]
                ].to_numpy(float)
            ))
        ),
    }

    failed = [name for name, ok in gates.items() if not ok]

    verdict = (
        "SINGLE_ANCHOR_LOG_L_FLOW_AUDIT_VERIFIED"
        if not failed
        else
        "SINGLE_ANCHOR_LOG_L_FLOW_AUDIT_GATE_FAILURE"
    )

    prefix = args.prefix
    detail_path = Path(prefix + "_FLOW.csv")
    blocks_path = Path(prefix + "_DYADIC_BLOCKS.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    next_path = Path(prefix + "_NEXT_THEOREM.md")

    df.to_csv(detail_path, index=False)
    blocks.to_csv(blocks_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "panel": {
            "L_start": int(args.L_start),
            "L_end": int(args.L_end),
            "steps_per_doubling": int(args.steps_per_doubling),
            "samples": int(len(df)),
            "tail_factor": float(args.tail_factor),
            "counter_q": int(args.counter_q),
        },
        "crosschecks": {
            "maximum_interior_finite_difference_relative_error": max_fd_rel,
            "maximum_signed_flow_reconstruction_error": max_flow_recon,
        },
        "flow_anatomy": {
            "Q_min": float(np.min(Q)),
            "Q_max": float(np.max(Q)),
            "Q_range": q_range,
            "Q_start": float(Q[0]),
            "Q_end": float(Q[-1]),
            "net_displacement": net_displacement,
            "absolute_logL_variation_proxy": total_abs_variation,
            "absolute_variation_over_net": tv_over_net,
            "Q_u_sign_changes": signs,
        },
        "pointwise_late_fit_abs_Q_u": point_fit,
        "dyadic_late_fit_max_abs_Q_u": block_fit,
        "mechanism": mechanism,
        "absolute_decay_supported": absolute_decay_supported,
        "next_analytic_target": next_target,
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "proof_status": (
            "Finite numerical flow audit only. A positive fitted exponent "
            "would not prove convergence; absence of such an exponent would "
            "rule out only the simplest absolute-integrability mechanism."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }

    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    next_path.write_text(
        "# ROT-RH v264 — next theorem direction\n\n"
        + f"Mechanism classification: `{mechanism}`.\n\n"
        + next_target
        + "\n",
        encoding="utf-8",
    )

    print()
    print("=" * 196)
    print("ROT-RH v264 — SINGLE-ANCHOR LOG-L FLOW SUMMARY")
    print("=" * 196)
    print(f"anchor E                            : {E:.12f}")
    print(f"Q start / end                       : {Q[0]:+.9e} / {Q[-1]:+.9e}")
    print(f"Q range                             : {q_range:.9e}")
    print(f"net |Q(end)-Q(start)|               : {net_displacement:.9e}")
    print(f"absolute log-L variation proxy      : {total_abs_variation:.9e}")
    print(f"variation / net                     : {tv_over_net:.6f}")
    print(f"Q_u sign changes                    : {signs}")

    print()
    print("DERIVATIVE CROSSCHECK")
    print("-" * 196)
    print(
        "max interior FD relative error      : "
        f"{max_fd_rel:.6e}"
    )
    print(
        "max signed-flow reconstruction error: "
        f"{max_flow_recon:.6e}"
    )

    print()
    print("LATE |Q_u| FIT")
    print("-" * 196)
    print(
        "pointwise p / R2                    : "
        f"{point_fit['p']:+.6f} / {point_fit['r2']:.6f}"
    )
    print(
        "dyadic-max p / R2                   : "
        f"{block_fit['p']:+.6f} / {block_fit['r2']:.6f}"
    )
    print(
        "positive absolute decay supported   : "
        f"{absolute_decay_supported}"
    )
    print(f"MECHANISM                           : {mechanism}")

    print()
    print("=" * 196)
    print("FAILED GATES                        :", failed if failed else "none")
    print("VERDICT                             :", verdict)
    print(
        "PROOF VERDICT                       : OPEN — "
        "ONE-ANCHOR LITERAL PHASE BOUNDEDNESS"
    )
    print("=" * 196)
    print("Files written:")
    print(" ", detail_path)
    print(" ", blocks_path)
    print(" ", summary_path)
    print(" ", next_path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
