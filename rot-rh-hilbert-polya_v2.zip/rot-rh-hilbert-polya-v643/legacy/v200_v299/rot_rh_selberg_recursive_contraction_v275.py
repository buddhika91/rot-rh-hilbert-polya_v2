#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v275 — SELBERG RECURSIVE CONTRACTION / ABEL-BOUND ATTACK
================================================================

Purpose
-------
v274 reduced the one-anchor RH route to a single lemma:

    sup_L |Q(L;E*)| < infinity,

equivalently (v262) boundedness of the centered sine-Abel transform

    T_E(L)
      = sum_{n>=2}
          q_n e^{-n/L} n^{-1/2} sin(E log n) / log n,

where

    q_2 = Lambda(2)-2,
    q_n = Lambda(n)-1, n>=3.

v275 attacks this lemma through Selberg's exact quadratic recursion rather
than another large-cutoff extrapolation.

Exact centered cumulative identity
----------------------------------
For

    R(N)=sum_{n=2}^N q_n,

we have exactly

    R(N)=psi(N)-N.

Therefore finite Abel summation gives

    sum_{n=2}^N q_n f(n)
      = R(N)f(N)
        + sum_{n=2}^{N-1} R(n)[f(n)-f(n+1)].

v275 verifies this at machine precision for the actual fixed-anchor kernel.

Exact Selberg recursion
-----------------------
Let

    b(1)=0,  b(n)=1 for n>=2,
    r(n)=Lambda(n)-b(n)=Lambda(n)-1, n>=2.

Selberg's pointwise identity is

    Lambda(n) log n + (Lambda*Lambda)(n)
      = (mu * log^2)(n).

Expanding Lambda=b+r gives

    r(n) log n
      + 2 (b*r)(n)
      + (r*r)(n)
      = H(n),

where

    H(n)=(mu*log^2)(n)-log n-(b*b)(n).

Since b(1)=r(1)=0, every convolution term on the left at n depends only on
proper divisors < n.  Thus this is a genuinely causal recursive arithmetic
law.

The forcing (mu*log^2)(n) has a simple exact factorization formula:

  * n=p^a:
        (2a-1)(log p)^2
  * n=p^a q^b, p!=q:
        2 log p log q
  * n with >=3 distinct prime factors:
        0.

Exact Frechet derivative
------------------------
Linearizing the recursion around the true r gives, for proper d|n,

    dr(n)/dr(d)
      = -2 Lambda(n/d)/log n.

Thus the recursive Jacobian is sparse and supported only when n/d is a
prime power.

For a weighted state

    x_n = r(n) / [n^sigma (log n)^tau],

the weighted l-infinity row gain is exactly bounded by

    G_abs(n;sigma,tau)
      = sum_{k|n, 2<=k<n}
          [2 Lambda(k)/log n]
          k^{-sigma}
          [log(n/k)/log n]^tau.

For the phase-aligned direction at the fixed anchor, the coherent gain is

    G_phase(n)
      = abs sum_k
          [same amplitude] exp(-i E log k).

v275 computes both prospectively on dyadic arithmetic blocks.

Why several weights are tested
------------------------------
The natural coefficient weight for the Abel transform is

    sigma=1/2, tau=1,

because

    x_n = r(n)/(sqrt(n) log n).

However, l-infinity contraction in that norm alone does NOT imply that
sum x_n e^{iE log n} is bounded: the evaluation functional is not absolutely
summable.

A weighted l-infinity norm would make absolute evaluation uniformly bounded
only if

    sigma < -1/2,

or at the boundary sigma=-1/2 with tau<0.

v275 therefore explicitly checks whether any such absolutely-compatible norm
is also Selberg-contractive.  If none is, but the natural phase-weighted norm
contracts, the remaining theorem must exploit oscillatory cancellation.

Transform decomposition
-----------------------
The exact recursive identity gives

    r = forcing + linear_feedback + quadratic_feedback.

v275 transforms all three components with the literal fixed-anchor Abel kernel
and checks:

    T_q
      = T_forcing + T_linear + T_quadratic - correction_at_n=2.

The forcing and feedback are then audited on frozen training and later holdout
cutoffs.

Important
---------
A finite contraction pass is NOT an RH proof.

The theorem-facing outcomes are:

A. If an absolutely evaluation-compatible norm has uniform gain <1, then a
   direct Banach contraction route may exist.

B. If only the natural/phase-sensitive coefficient norm contracts, the next
   theorem must be a phase-sensitive transfer or oscillatory Selberg estimate.

C. If even the natural weighted Jacobian does not contract, the Selberg route
   in this form is rejected.

No Xi, zeta values, zeta zero ordinates, or known-zero data are used.

Version: 275
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 275
EPS = np.finfo(float).eps


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_weights(text):
    """
    Format:
        sigma:tau,sigma:tau,...
    """
    out = []
    for tok in str(text).split(","):
        tok = tok.strip()
        if not tok:
            continue
        a, b = tok.split(":")
        out.append((float(a), float(b)))
    if not out:
        raise ValueError("No weights supplied")
    return out


def weight_name(sigma, tau):
    return f"sigma={sigma:g},tau={tau:g}"


def absolute_evaluation_compatible(sigma, tau):
    """
    Target:
      sum x_n n^(sigma-1/2) log^(tau-1)n e^{-nt} e^{iElogn}.

    Uniform absolute summability as t->0 requires:
      sigma-1/2 < -1
    or boundary exponent -1 with log power < -1.

    Hence:
      sigma < -1/2
    or
      sigma=-1/2 and tau<0.
    """
    if sigma < -0.5 - 1e-12:
        return True
    if abs(sigma + 0.5) <= 1e-12 and tau < 0:
        return True
    return False


# ---------------------------------------------------------------------------
# Smallest-prime-factor + Selberg forcing statistics
# ---------------------------------------------------------------------------

def smallest_prime_factor(N):
    """
    Vectorized SPF sieve.
    """
    spf = np.arange(N + 1, dtype=np.int32)
    if N >= 1:
        spf[1] = 1
    if N >= 0:
        spf[0] = 0

    root = int(math.isqrt(N))
    for p in tqdm(
        range(2, root + 1),
        desc="SPF sieve",
        unit="p",
        leave=False,
    ):
        if spf[p] != p:
            continue
        idx = np.arange(p * p, N + 1, p, dtype=np.int64)
        if not len(idx):
            continue
        m = spf[idx] == idx
        spf[idx[m]] = p
    return spf


def selberg_factor_statistics(spf):
    """
    Build:
      tau(n)                 divisor count
      g(n)=(mu*log^2)(n)     exact Selberg forcing atom

    Recurrence uses SPF and the fact that mu*log^2 vanishes when n has
    >=3 distinct prime factors.
    """
    N = len(spf) - 1

    tau = np.ones(N + 1, dtype=np.int32)
    omega = np.zeros(N + 1, dtype=np.uint8)
    exponent = np.zeros(N + 1, dtype=np.uint8)
    distinct_log_sum = np.zeros(N + 1, dtype=np.float64)
    g = np.zeros(N + 1, dtype=np.float64)

    for n in tqdm(
        range(2, N + 1),
        desc="Selberg factor stats",
        unit="n",
    ):
        p = int(spf[n])
        m = n // p
        lp = math.log(p)

        if m > 1 and m % p == 0:
            old_e = int(exponent[m])
            new_e = old_e + 1

            exponent[n] = new_e
            omega[n] = omega[m]
            distinct_log_sum[n] = distinct_log_sum[m]

            tau[n] = (
                tau[m]
                // (old_e + 1)
                * (new_e + 1)
            )

            if omega[n] == 1:
                g[n] = (2 * new_e - 1) * lp * lp
            else:
                # For exactly two distinct primes the value
                # 2 log p log q is independent of exponents.
                # For >=3 it is zero.
                g[n] = g[m]

        else:
            exponent[n] = 1
            omega[n] = omega[m] + 1
            distinct_log_sum[n] = distinct_log_sum[m] + lp
            tau[n] = tau[m] * 2

            if omega[m] == 0:
                g[n] = lp * lp
            elif omega[m] == 1:
                g[n] = 2.0 * lp * distinct_log_sum[m]
            else:
                g[n] = 0.0

    return tau, g


# ---------------------------------------------------------------------------
# Direct sampled Selberg identity
# ---------------------------------------------------------------------------

def divisor_lambda_convolution(n, lam):
    """
    Direct (Lambda*Lambda)(n) by divisor enumeration.
    Used only on sampled n for an independent identity check.
    """
    n = int(n)
    total = 0.0
    root = int(math.isqrt(n))

    for d in range(1, root + 1):
        if n % d:
            continue
        q = n // d

        total += float(lam[d]) * float(lam[q])
        if q != d:
            total += float(lam[q]) * float(lam[d])

    return total


# ---------------------------------------------------------------------------
# Weighted Selberg Jacobian on a dyadic block
# ---------------------------------------------------------------------------

def block_weighted_gain(
    N,
    E,
    pp_n,
    pp_lambda,
    sigma,
    tau,
):
    """
    Block n in [N,2N).

    Weighted absolute row gain:
      sum_k amp(n,k)

    Phase-aligned coherent row gain:
      |sum_k amp(n,k) exp(-i E log k)|

    where k=n/d is a prime-power quotient.
    """
    N = int(N)
    nvals = np.arange(N, 2 * N, dtype=np.int64)
    logn = np.log(nvals.astype(np.float64))

    abs_gain = np.zeros(N, dtype=np.float64)
    coherent = np.zeros(N, dtype=np.complex128)

    usable = np.flatnonzero(pp_n < N)

    for j in usable:
        k = int(pp_n[j])
        lk = float(pp_lambda[j])

        d_lo = max(2, (N + k - 1) // k)
        d_hi = (2 * N - 1) // k

        if d_hi < d_lo:
            continue

        d = np.arange(
            d_lo,
            d_hi + 1,
            dtype=np.int64,
        )
        n = k * d
        idx = n - N

        ln = logn[idx]

        amp = (
            2.0
            * lk
            / ln
            * (float(k) ** (-float(sigma)))
        )

        if tau != 0.0:
            amp = amp * (
                np.log(d.astype(np.float64))
                / ln
            ) ** float(tau)

        abs_gain[idx] += np.abs(amp)

        phase = np.exp(
            -1.0j * float(E) * math.log(k)
        )
        coherent[idx] += amp * phase

    phase_gain = np.abs(coherent)

    return {
        "abs_max": float(np.max(abs_gain)),
        "abs_p99": float(np.quantile(abs_gain, 0.99)),
        "abs_median": float(np.median(abs_gain)),
        "phase_max": float(np.max(phase_gain)),
        "phase_p99": float(np.quantile(phase_gain, 0.99)),
        "phase_median": float(np.median(phase_gain)),
        "raw_arrays": (abs_gain, phase_gain),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--L-values",
        default="4000,8000,16000,32000,64000,128000",
    )
    ap.add_argument(
        "--training-L-max",
        type=int,
        default=32000,
    )
    ap.add_argument("--tail-factor", type=float, default=18.0)

    ap.add_argument(
        "--block-starts",
        default="4096,8192,16384,32768,65536,131072,262144,524288",
    )
    ap.add_argument(
        "--training-block-max",
        type=int,
        default=65536,
    )

    ap.add_argument(
        "--weights",
        default="0:0,0.5:0,0.5:1,0.5:2,-0.5:-1,-0.75:0",
    )
    ap.add_argument(
        "--natural-sigma",
        type=float,
        default=0.5,
    )
    ap.add_argument(
        "--natural-tau",
        type=float,
        default=1.0,
    )

    ap.add_argument(
        "--selberg-samples",
        type=int,
        default=512,
    )
    ap.add_argument(
        "--seed",
        type=int,
        default=20260820,
    )

    ap.add_argument(
        "--abel-identity-tol",
        type=float,
        default=1e-9,
    )
    ap.add_argument(
        "--selberg-identity-tol",
        type=float,
        default=1e-10,
    )
    ap.add_argument(
        "--recursion-identity-tol",
        type=float,
        default=1e-10,
    )
    ap.add_argument(
        "--natural-abs-jacobian-gate",
        type=float,
        default=0.95,
    )
    ap.add_argument(
        "--natural-phase-jacobian-gate",
        type=float,
        default=0.75,
    )
    ap.add_argument(
        "--feedback-ratio-gate",
        type=float,
        default=0.98,
    )
    ap.add_argument(
        "--forcing-envelope-safety",
        type=float,
        default=1.25,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_selberg_recursive_contraction_v275",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    L_values = parse_ints(args.L_values)
    block_starts = parse_ints(args.block_starts)
    weights = parse_weights(args.weights)

    if not L_values or not block_starts:
        raise ValueError("Need L values and block starts")

    if any(L_values[i + 1] <= L_values[i] for i in range(len(L_values) - 1)):
        raise ValueError("L values must be increasing")
    if any(
        block_starts[i + 1] <= block_starts[i]
        for i in range(len(block_starts) - 1)
    ):
        raise ValueError("block starts must be increasing")

    anchors = pd.read_csv(args.anchors)
    if not {"k", "E_anchor"}.issubset(anchors.columns):
        raise KeyError("anchors file must contain k,E_anchor")

    anchors["k"] = anchors["k"].astype(int)
    hit = anchors[anchors["k"] == int(args.anchor_k)]

    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one anchor for k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])

    max_transform_N = int(
        math.ceil(
            float(args.tail_factor)
            * max(L_values)
        )
    )
    max_block_N = 2 * max(block_starts)
    Nmax = max(max_transform_N, max_block_N)

    base = importlib.import_module(args.base_module)

    print("=" * 204)
    print("ROT-RH v275 — SELBERG RECURSIVE CONTRACTION / ABEL-BOUND ATTACK")
    print("=" * 204)
    print("Xi / zeta / known-zero data         : NONE")
    print(f"anchor k                             : {args.anchor_k}")
    print(f"anchor E                             : {E:.15f}")
    print(f"L values                             : {L_values}")
    print(f"training L <=                        : {args.training_L_max}")
    print(f"block starts                         : {block_starts}")
    print(f"training block <=                    : {args.training_block_max}")
    print(f"maximum arithmetic N                : {Nmax}")
    print(f"weights                              : {weights}")
    print("=" * 204)

    # --------------------------------------------------------------
    # 1. Shared Mangoldt arithmetic
    # --------------------------------------------------------------
    print(f"[1] Shared Mangoldt sieve through N={Nmax:,}")

    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(numbers, dtype=np.int64)
    lambdas = np.asarray(lambdas, dtype=np.float64)

    lam = np.zeros(Nmax + 1, dtype=np.float64)
    lam[numbers] = lambdas

    pp_n = numbers.copy()
    pp_lambda = lambdas.copy()

    psi = np.cumsum(lam)

    # Exact centered cumulative identity.
    ncheck = np.arange(2, Nmax + 1, dtype=np.float64)
    cumulative_q = (
        np.cumsum(lam[2:] - 1.0)
    )
    cumulative_q[0:] -= 1.0  # q_2 has one extra -1

    cumulative_target = psi[2:] - ncheck

    max_cumulative_identity = float(
        np.max(
            np.abs(
                cumulative_q
                - cumulative_target
            )
        )
    )

    # --------------------------------------------------------------
    # 2. Factor statistics for exact Selberg recursion
    # --------------------------------------------------------------
    print("[2] Selberg forcing / divisor statistics")

    spf = smallest_prime_factor(Nmax)
    tau, g = selberg_factor_statistics(spf)

    # Factor-work arrays no longer needed after this point.
    del spf

    # --------------------------------------------------------------
    # 3. Independent sampled Selberg identity
    # --------------------------------------------------------------
    print("[3] Sampled pointwise Selberg identity")

    rng = random.Random(int(args.seed))
    sample_N = min(Nmax, max_transform_N)

    sample_ns = sorted(set(
        rng.randint(2, sample_N)
        for _ in range(int(args.selberg_samples))
    ))

    selberg_rows = []
    max_selberg_error = 0.0

    for n in tqdm(
        sample_ns,
        desc="Selberg identity samples",
        unit="n",
    ):
        ln = math.log(n)

        lhs = (
            float(lam[n]) * ln
            + divisor_lambda_convolution(n, lam)
        )
        rhs = float(g[n])

        err = abs(lhs - rhs)
        max_selberg_error = max(
            max_selberg_error,
            err,
        )

        selberg_rows.append({
            "n": int(n),
            "Lambda": float(lam[n]),
            "lhs_LambdaLog_plus_convolution": lhs,
            "rhs_mu_convolution_log2": rhs,
            "absolute_error": err,
        })

    # --------------------------------------------------------------
    # 4. Exact recursion + Abel transform decomposition
    # --------------------------------------------------------------
    print("[4] Exact recursive Abel transform decomposition")

    transform_rows = []
    max_recursion_error = 0.0
    max_abel_error = 0.0

    train_forcing_abs = []

    for L in tqdm(
        L_values,
        desc="Selberg-Abel cutoffs",
        unit="L",
    ):
        N = min(
            Nmax,
            int(math.floor(
                float(args.tail_factor)
                * float(L)
            )),
        )

        n = np.arange(
            2,
            N + 1,
            dtype=np.int64,
        )
        nf = n.astype(np.float64)
        ln = np.log(nf)

        lam_n = lam[2:N + 1]
        tau_n = tau[2:N + 1].astype(np.float64)
        g_n = g[2:N + 1]

        # r=Lambda-1 for every n>=2.
        r = lam_n - 1.0

        # Closed forms for the two Selberg convolution pieces:
        #
        # (b*r)(n)
        #   = sum_proper_divisors [Lambda(d)-1]
        #   = (log n - Lambda(n)) - (tau(n)-2).
        br = (
            (ln - lam_n)
            - (tau_n - 2.0)
        )

        # Lambda*Lambda = g - Lambda log n.
        #
        # r*r
        #   = Lambda*Lambda
        #     -2(b*Lambda)
        #     +(b*b)
        #
        # b*Lambda = log n - Lambda(n)
        # b*b       = tau(n)-2.
        rr = (
            g_n
            - lam_n * ln
            - 2.0 * (ln - lam_n)
            + (tau_n - 2.0)
        )

        forcing = (
            g_n
            - ln
            - (tau_n - 2.0)
        ) / ln

        linear = -2.0 * br / ln
        quadratic = -rr / ln

        reconstructed_r = (
            forcing
            + linear
            + quadratic
        )

        rec_err = float(
            np.max(
                np.abs(
                    reconstructed_r - r
                )
            )
        )
        max_recursion_error = max(
            max_recursion_error,
            rec_err,
        )

        kernel = (
            np.exp(-nf / float(L))
            * np.exp(1.0j * E * ln)
            / (np.sqrt(nf) * ln)
        )

        # q = r - delta_{n=2}
        T_r = complex(np.dot(r, kernel))
        T_q = T_r - complex(kernel[0])

        T_forcing = complex(
            np.dot(forcing, kernel)
        )
        T_linear = complex(
            np.dot(linear, kernel)
        )
        T_quadratic = complex(
            np.dot(quadratic, kernel)
        )

        T_reconstructed = (
            T_forcing
            + T_linear
            + T_quadratic
            - complex(kernel[0])
        )

        transform_identity_error = abs(
            T_reconstructed - T_q
        )

        # Exact discrete Abel summation of q.
        R = (
            psi[2:N + 1]
            - nf
        )

        T_abel = (
            complex(R[-1] * kernel[-1])
            + complex(
                np.dot(
                    R[:-1],
                    kernel[:-1] - kernel[1:],
                )
            )
        )

        abel_err = abs(T_abel - T_q)
        max_abel_error = max(
            max_abel_error,
            abel_err,
        )

        feedback = (
            T_linear
            + T_quadratic
        )

        sine_total = float(np.imag(T_q))
        sine_forcing = float(np.imag(T_forcing))
        sine_feedback = float(np.imag(feedback))

        feedback_ratio = (
            abs(sine_feedback)
            / max(abs(sine_total), 1e-15)
        )

        region = (
            "TRAIN"
            if L <= int(args.training_L_max)
            else "HOLDOUT"
        )

        if region == "TRAIN":
            train_forcing_abs.append(
                abs(sine_forcing)
            )

        transform_rows.append({
            "L": int(L),
            "N": int(N),
            "region": region,
            "recursion_max_pointwise_error": rec_err,
            "transform_identity_error": transform_identity_error,
            "abel_summation_identity_error": abel_err,
            "Tq_real": float(np.real(T_q)),
            "Tq_imag": sine_total,
            "Tforcing_real": float(np.real(T_forcing)),
            "Tforcing_imag": sine_forcing,
            "Tlinear_real": float(np.real(T_linear)),
            "Tlinear_imag": float(np.imag(T_linear)),
            "Tquadratic_real": float(np.real(T_quadratic)),
            "Tquadratic_imag": float(np.imag(T_quadratic)),
            "Tfeedback_real": float(np.real(feedback)),
            "Tfeedback_imag": sine_feedback,
            "sine_feedback_over_total": feedback_ratio,
        })

    transform_df = pd.DataFrame(transform_rows)

    forcing_envelope = (
        float(args.forcing_envelope_safety)
        * max(train_forcing_abs)
        if train_forcing_abs
        else float("nan")
    )

    transform_df["forcing_training_envelope"] = forcing_envelope
    transform_df["forcing_envelope_pass"] = (
        np.abs(transform_df["Tforcing_imag"])
        <= forcing_envelope
    )

    hold_transform = transform_df[
        transform_df["region"] == "HOLDOUT"
    ]

    forcing_holdout_pass = bool(
        len(hold_transform)
        and hold_transform[
            "forcing_envelope_pass"
        ].all()
    )

    feedback_holdout_pass = bool(
        len(hold_transform)
        and (
            hold_transform[
                "sine_feedback_over_total"
            ]
            <= float(args.feedback_ratio_gate)
        ).all()
    )

    max_hold_feedback_ratio = (
        float(
            hold_transform[
                "sine_feedback_over_total"
            ].max()
        )
        if len(hold_transform)
        else float("nan")
    )

    # --------------------------------------------------------------
    # 5. Exact weighted Jacobian gains
    # --------------------------------------------------------------
    print("[5] Weighted Selberg Jacobian contraction")

    gain_rows = []
    raw_identity_errors = []

    natural_key = (
        float(args.natural_sigma),
        float(args.natural_tau),
    )

    for N in tqdm(
        block_starts,
        desc="dyadic Selberg blocks",
        unit="block",
    ):
        for sigma, tau_w in weights:
            result = block_weighted_gain(
                N=N,
                E=E,
                pp_n=pp_n,
                pp_lambda=pp_lambda,
                sigma=sigma,
                tau=tau_w,
            )

            region = (
                "TRAIN"
                if N <= int(args.training_block_max)
                else "HOLDOUT"
            )

            gain_rows.append({
                "block_start": int(N),
                "block_end_exclusive": int(2 * N),
                "region": region,
                "sigma": sigma,
                "tau": tau_w,
                "weight": weight_name(
                    sigma,
                    tau_w,
                ),
                "absolute_evaluation_compatible": (
                    absolute_evaluation_compatible(
                        sigma,
                        tau_w,
                    )
                ),
                "abs_gain_max": result["abs_max"],
                "abs_gain_p99": result["abs_p99"],
                "abs_gain_median": result["abs_median"],
                "phase_gain_max": result["phase_max"],
                "phase_gain_p99": result["phase_p99"],
                "phase_gain_median": result["phase_median"],
            })

            # For sigma=tau=0 there is an independent exact row-sum identity
            #
            # 2/log n * sum_{k|n, proper} Lambda(k)
            #   = 2(log n - Lambda(n))/log n.
            if (
                abs(sigma) <= 1e-15
                and abs(tau_w) <= 1e-15
            ):
                abs_arr, _ = result["raw_arrays"]

                nvals = np.arange(
                    N,
                    2 * N,
                    dtype=np.int64,
                )
                exact = (
                    2.0
                    * (
                        np.log(
                            nvals.astype(np.float64)
                        )
                        - lam[N:2 * N]
                    )
                    / np.log(
                        nvals.astype(np.float64)
                    )
                )

                raw_identity_errors.append(
                    float(
                        np.max(
                            np.abs(
                                abs_arr - exact
                            )
                        )
                    )
                )

    gain_df = pd.DataFrame(gain_rows)

    max_raw_jacobian_identity = (
        max(raw_identity_errors)
        if raw_identity_errors
        else float("nan")
    )

    natural = gain_df[
        (np.isclose(
            gain_df["sigma"],
            float(args.natural_sigma),
        ))
        &
        (np.isclose(
            gain_df["tau"],
            float(args.natural_tau),
        ))
    ]

    if len(natural) != len(block_starts):
        raise RuntimeError(
            "Natural weight must be included in --weights"
        )

    natural_train = natural[
        natural["region"] == "TRAIN"
    ]
    natural_hold = natural[
        natural["region"] == "HOLDOUT"
    ]

    natural_abs_hold_max = (
        float(natural_hold["abs_gain_max"].max())
        if len(natural_hold)
        else float("nan")
    )
    natural_phase_hold_max = (
        float(natural_hold["phase_gain_max"].max())
        if len(natural_hold)
        else float("nan")
    )

    natural_abs_contraction = bool(
        len(natural_hold)
        and (
            natural_hold["abs_gain_max"]
            < float(args.natural_abs_jacobian_gate)
        ).all()
    )

    natural_phase_contraction = bool(
        len(natural_hold)
        and (
            natural_hold["phase_gain_max"]
            < float(args.natural_phase_jacobian_gate)
        ).all()
    )

    # Any norm that both:
    #   (a) makes absolute evaluation uniformly summable, and
    #   (b) is contractive in the full absolute Jacobian gain?
    absolute_banach_candidates = []

    for (sigma, tau_w), grp in gain_df.groupby(
        ["sigma", "tau"],
        sort=False,
    ):
        if not absolute_evaluation_compatible(
            float(sigma),
            float(tau_w),
        ):
            continue

        holdg = grp[
            grp["region"] == "HOLDOUT"
        ]

        qmax = (
            float(holdg["abs_gain_max"].max())
            if len(holdg)
            else float("inf")
        )

        absolute_banach_candidates.append({
            "sigma": float(sigma),
            "tau": float(tau_w),
            "holdout_abs_gain_max": qmax,
            "contractive": bool(qmax < 1.0),
        })

    direct_absolute_banach_route = any(
        r["contractive"]
        for r in absolute_banach_candidates
    )

    # --------------------------------------------------------------
    # Gates / classification
    # --------------------------------------------------------------
    gates = {
        "centered_cumulative_identity": bool(
            max_cumulative_identity
            <= float(args.selberg_identity_tol)
        ),
        "sampled_selberg_identity": bool(
            max_selberg_error
            <= float(args.selberg_identity_tol)
        ),
        "recursive_pointwise_identity": bool(
            max_recursion_error
            <= float(args.recursion_identity_tol)
        ),
        "abel_summation_identity": bool(
            max_abel_error
            <= float(args.abel_identity_tol)
        ),
        "raw_jacobian_row_sum_identity": bool(
            np.isfinite(max_raw_jacobian_identity)
            and max_raw_jacobian_identity
            <= 1e-10
        ),
        "natural_absolute_jacobian_contraction": (
            natural_abs_contraction
        ),
        "natural_phase_jacobian_contraction": (
            natural_phase_contraction
        ),
        "forcing_holdout_envelope": (
            forcing_holdout_pass
        ),
        "feedback_holdout_below_one": (
            feedback_holdout_pass
        ),
    }

    failed = [
        name
        for name, ok in gates.items()
        if not ok
    ]

    if (
        natural_abs_contraction
        and natural_phase_contraction
        and forcing_holdout_pass
        and feedback_holdout_pass
    ):
        if direct_absolute_banach_route:
            mechanism = (
                "SELBERG_DIRECT_BANACH_CONTRACTION_ROUTE_SUPPORTED"
            )
            next_theorem = (
                "Attempt to prove a uniform weighted Banach contraction and "
                "a uniform forcing bound analytically. Because the same weight "
                "also makes the Abel evaluation absolutely bounded, this could "
                "directly close the one-anchor lemma."
            )
        else:
            mechanism = (
                "SELBERG_PHASE_SENSITIVE_CONTRACTION_SUPPORTED_BUT_ABSOLUTE_CLOSURE_FAILS"
            )
            next_theorem = (
                "The Selberg recursion is genuinely contractive in the natural "
                "critical coefficient geometry, but every tested norm strong "
                "enough for absolute Abel evaluation is noncontractive. The "
                "next theorem must preserve the fixed E phase and prove a "
                "phase-sensitive/oscillatory transfer bound; ordinary absolute "
                "Banach norms are insufficient."
            )
    else:
        mechanism = (
            "SELBERG_RECURSIVE_CONTRACTION_NOT_ESTABLISHED"
        )
        next_theorem = (
            "Do not claim Selberg recursion closes boundedness. Inspect which "
            "of the exact recursion, forcing, Jacobian, or feedback gates failed "
            "before choosing another analytic route."
        )

    verdict = (
        "SELBERG_RECURSIVE_CONTRACTION_AUDIT_VERIFIED"
        if not failed
        else
        "SELBERG_RECURSIVE_CONTRACTION_AUDIT_GATE_FAILURE"
    )

    # --------------------------------------------------------------
    # Outputs
    # --------------------------------------------------------------
    prefix = args.prefix

    transform_path = Path(
        prefix + "_ABEL_DECOMPOSITION.csv"
    )
    gains_path = Path(
        prefix + "_JACOBIAN_GAINS.csv"
    )
    selberg_path = Path(
        prefix + "_SELBERG_SAMPLES.csv"
    )
    summary_path = Path(
        prefix + "_SUMMARY.json"
    )
    theorem_path = Path(
        prefix + "_NEXT_THEOREM.md"
    )

    transform_df.to_csv(
        transform_path,
        index=False,
    )
    gain_df.to_csv(
        gains_path,
        index=False,
    )
    pd.DataFrame(selberg_rows).to_csv(
        selberg_path,
        index=False,
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "exact_identities": {
            "centered_cumulative": (
                "sum_{n=2}^N q_n = psi(N)-N"
            ),
            "maximum_centered_cumulative_error": (
                max_cumulative_identity
            ),
            "Selberg_pointwise": (
                "Lambda log + Lambda*Lambda = mu*log^2"
            ),
            "maximum_sampled_Selberg_error": (
                max_selberg_error
            ),
            "recursive_decomposition": (
                "r=forcing+linear+quadratic"
            ),
            "maximum_recursive_pointwise_error": (
                max_recursion_error
            ),
            "maximum_Abel_summation_error": (
                max_abel_error
            ),
            "maximum_raw_Jacobian_row_sum_error": (
                max_raw_jacobian_identity
            ),
        },
        "natural_weight": {
            "sigma": float(args.natural_sigma),
            "tau": float(args.natural_tau),
            "meaning": (
                "r(n)/(sqrt(n)log n)"
                if (
                    abs(args.natural_sigma - 0.5) < 1e-12
                    and abs(args.natural_tau - 1.0) < 1e-12
                )
                else "custom"
            ),
            "holdout_max_absolute_Jacobian_gain": (
                natural_abs_hold_max
            ),
            "holdout_max_phase_aligned_gain": (
                natural_phase_hold_max
            ),
            "absolute_contraction_pass": (
                natural_abs_contraction
            ),
            "phase_contraction_pass": (
                natural_phase_contraction
            ),
        },
        "transform_decomposition": {
            "forcing_training_envelope": (
                forcing_envelope
            ),
            "forcing_holdout_pass": (
                forcing_holdout_pass
            ),
            "maximum_holdout_feedback_over_total_sine": (
                max_hold_feedback_ratio
            ),
            "feedback_holdout_pass": (
                feedback_holdout_pass
            ),
        },
        "absolute_Banach_candidates": (
            absolute_banach_candidates
        ),
        "direct_absolute_Banach_route": (
            direct_absolute_banach_route
        ),
        "interpretation": {
            "if_direct_absolute_Banach_route": (
                "A direct contraction proof may be possible because one tested "
                "weight both contracts and makes the Abel evaluation functional "
                "uniformly absolutely bounded."
            ),
            "if_only_natural_contraction": (
                "The exact Selberg recursion has a contractive critical-weight "
                "geometry, but absolute evaluation remains too singular. "
                "Oscillatory phase cancellation is then the missing theorem."
            ),
            "scope": (
                "Finite block gains and finite holdout transforms are evidence "
                "for a mechanism only. The one-anchor RH-strength boundedness "
                "lemma remains open until the corresponding inequalities are "
                "proved for all scales."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN — this script tests whether Selberg's exact recursive identity "
            "provides the right contractive geometry for the one-anchor Abel "
            "boundedness lemma."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            summary,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v275 — Selberg recursive contraction audit

## Exact recursion

Let `r(n)=Lambda(n)-1` for `n>=2`.  Selberg's pointwise identity gives

`r(n) log n + 2(b*r)(n) + (r*r)(n) = H(n)`,

with `b(1)=0`, `b(n)=1` for `n>=2`.

This is causal because all convolution inputs at `n` are proper divisors.

The exact derivative is

`dr(n)/dr(d) = -2 Lambda(n/d)/log n`

for proper `d|n`.

## Natural critical coefficient state

At the one-anchor Abel weight, the natural coefficient state is

`x_n = r(n)/(sqrt(n) log n)`.

On the tested holdout blocks:

- maximum absolute Jacobian gain:
  `{natural_abs_hold_max:.15g}`
- maximum phase-aligned Jacobian gain:
  `{natural_phase_hold_max:.15g}`

## Absolute Banach closure

A weighted l-infinity state can bound the Abel evaluation absolutely only for
`sigma<-1/2`, or the boundary `sigma=-1/2, tau<0`.

Direct absolutely-compatible contraction found:

`{direct_absolute_banach_route}`

## Interpretation

Mechanism:

`{mechanism}`

{next_theorem}

This does not prove the one-anchor boundedness lemma.  Its purpose is to decide
whether Selberg recursion supplies a genuine contraction geometry and whether
that geometry is strong enough for absolute evaluation, or whether the fixed
oscillatory phase must enter the final theorem.
""",
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # Console summary
    # --------------------------------------------------------------
    print()
    print("=" * 204)
    print("ROT-RH v275 — SELBERG RECURSIVE CONTRACTION SUMMARY")
    print("=" * 204)

    print("EXACT IDENTITIES")
    print("-" * 204)
    print(
        "centered cumulative max error        : "
        f"{max_cumulative_identity:.3e}"
    )
    print(
        "sampled Selberg max error            : "
        f"{max_selberg_error:.3e}"
    )
    print(
        "recursive pointwise max error        : "
        f"{max_recursion_error:.3e}"
    )
    print(
        "Abel summation max error             : "
        f"{max_abel_error:.3e}"
    )
    print(
        "raw Jacobian row-sum max error       : "
        f"{max_raw_jacobian_identity:.3e}"
    )

    print()
    print("NATURAL WEIGHT sigma=1/2, tau=1")
    print("-" * 204)
    print(
        "holdout max absolute Jacobian gain   : "
        f"{natural_abs_hold_max:.6f}"
    )
    print(
        "holdout max phase-aligned gain       : "
        f"{natural_phase_hold_max:.6f}"
    )
    print(
        "absolute contraction                 : "
        f"{natural_abs_contraction}"
    )
    print(
        "phase contraction                    : "
        f"{natural_phase_contraction}"
    )

    print()
    print("ABEL TRANSFORM DECOMPOSITION")
    print("-" * 204)
    print(
        "forcing training envelope            : "
        f"{forcing_envelope:.6e}"
    )
    print(
        "forcing holdout envelope pass        : "
        f"{forcing_holdout_pass}"
    )
    print(
        "max holdout |feedback|/|total| sine  : "
        f"{max_hold_feedback_ratio:.6f}"
    )
    print(
        "feedback ratio < gate                : "
        f"{feedback_holdout_pass}"
    )

    print()
    print("ABSOLUTE BANACH ROUTE")
    print("-" * 204)
    if absolute_banach_candidates:
        for r0 in absolute_banach_candidates:
            print(
                f"sigma={r0['sigma']:+.3f} "
                f"tau={r0['tau']:+.3f} "
                f"holdout q_abs={r0['holdout_abs_gain_max']:.6e} "
                f"contractive={r0['contractive']}"
            )
    else:
        print("no absolutely-compatible candidate weights supplied")

    print(
        "direct absolute Banach closure       : "
        f"{direct_absolute_banach_route}"
    )

    print()
    print("MECHANISM                            :", mechanism)
    print("=" * 204)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print("VERDICT                              :", verdict)
    print(
        "PROOF VERDICT                        : OPEN — "
        "ONE-ANCHOR SELBERG / PHASE-SENSITIVE BOUNDEDNESS THEOREM"
    )
    print("=" * 204)
    print("Files written:")
    print(" ", transform_path)
    print(" ", gains_path)
    print(" ", selberg_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
