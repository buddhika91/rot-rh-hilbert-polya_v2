#!/usr/bin/env python3
"""
ROT-RH v207 — PERTURBED ADVERSARY MULTI-HORIZON RUNAWAY AUDIT

Static Monte-Carlo geometry audit.
No root continuation. No Xi / zeta / known zeros.

WHY v207
--------
v206 classified sigma >= 0.001 as "not runaway-like" almost entirely because
it required the perturbed hull to retain >= 50% of the *baseline number of
segments*.  That is not the quantity needed for the divergence obstruction.

For the conditional divergence mechanism, the relevant finite-horizon signs
are instead:

  1. active ordinate grows as the observation horizon grows;
  2. active-gamma average grows;
  3. switches continue to occur at late fractions of the horizon;
  4. cumulative switch-error majorant remains small compared with active drive.

v207 perturbs the VK candidate gaps exactly as v206 did,

    gap_j' = gap_j * exp(sigma Z_j),

but uses the SAME perturbed realization across several tau horizons.  It then
tests growth across horizons rather than preservation of segment count.

For each trial and sigma it reports power fits

    gamma_max(T) ~ T^p_gamma,
    <gamma_active>_T ~ T^p_avg,

and the high-horizon switch-cost ratio

    C sum(Delta gamma/Delta a)
    ---------------------------
       integral gamma_active dtau.

This is a robustness test of the SYNTHETIC obstruction only.
It makes no claim about actual zeta-zero geometry.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


PI_OVER_2 = np.pi / 2.0


def upper_hull(lines):
    ordered = sorted(lines, key=lambda z: (z["m"], z["c"]))

    unique = []
    for z in ordered:
        if unique and abs(z["m"]-unique[-1]["m"]) <= 1e-18:
            if z["c"] > unique[-1]["c"]:
                unique[-1] = z
        else:
            unique.append(z)

    hull = []
    starts = []

    for z in unique:
        m = z["m"]
        c = z["c"]

        while hull:
            p = hull[-1]
            den = m-p["m"]
            x = np.inf if den <= 0 else (p["c"]-c)/den

            if len(hull) == 1 or x > starts[-1]:
                break

            hull.pop()
            starts.pop()

        if not hull:
            hull.append(z.copy())
            starts.append(-np.inf)
        else:
            p = hull[-1]
            x = (p["c"]-c)/(m-p["m"])
            hull.append(z.copy())
            starts.append(float(x))

    for z,s in zip(hull,starts):
        z["start"] = s

    return hull


def restrict_hull(hull, tau_min, tau_max):
    out = []

    for i,z in enumerate(hull):
        lo = max(float(z["start"]), tau_min)
        hi = tau_max

        if i+1 < len(hull):
            hi = min(float(hull[i+1]["start"]), tau_max)

        if hi <= tau_min or lo >= tau_max or hi <= lo:
            continue

        q = z.copy()
        q["seg_start"] = lo
        q["seg_end"] = hi
        out.append(q)

    return out


def metrics(segments, C, tau_min, tau_max):
    if not segments:
        return {
            "active_segments": 0,
            "switches": 0,
            "max_active_gamma": np.nan,
            "terminal_gamma": np.nan,
            "last_switch_tau": np.nan,
            "last_switch_fraction": np.nan,
            "active_average": np.nan,
            "majorant_ratio": np.nan,
        }

    active_integral = sum(
        abs(z["gamma"])*(z["seg_end"]-z["seg_start"])
        for z in segments
    )

    total_dt = tau_max-tau_min
    active_average = active_integral/max(total_dt,1e-300)

    raw = 0.0
    for i in range(len(segments)-1):
        da = segments[i+1]["m"]-segments[i]["m"]
        dg = abs(segments[i+1]["gamma"])-abs(segments[i]["gamma"])

        if da <= 0:
            raw = np.inf
            break

        raw += abs(dg/da)

    ratio = C*raw/max(active_integral,1e-300)

    gammas = np.array([abs(z["gamma"]) for z in segments],float)

    if len(segments) >= 2:
        last_switch = float(segments[-1]["seg_start"])
        last_frac = last_switch/tau_max
    else:
        last_switch = np.nan
        last_frac = np.nan

    return {
        "active_segments": len(segments),
        "switches": max(0,len(segments)-1),
        "max_active_gamma": float(np.max(gammas)),
        "terminal_gamma": float(gammas[-1]),
        "last_switch_tau": last_switch,
        "last_switch_fraction": last_frac,
        "active_average": float(active_average),
        "majorant_ratio": float(ratio),
    }


def build_lines(beta,gamma):
    return [
        {
            "idx": i,
            "beta": float(b),
            "gamma": float(g),
            "m": float(b-0.5),
            "c": float(-PI_OVER_2*abs(g)),
        }
        for i,(b,g) in enumerate(zip(beta,gamma))
    ]


def power_fit(x,y):
    x=np.asarray(x,float)
    y=np.asarray(y,float)

    ok=np.isfinite(x)&np.isfinite(y)&(x>0)&(y>0)
    x=x[ok]
    y=y[ok]

    if len(x)<3:
        return np.nan,np.nan

    lx=np.log(x)
    ly=np.log(y)

    coef=np.polyfit(lx,ly,1)
    pred=np.polyval(coef,lx)

    den=np.sum((ly-ly.mean())**2)
    r2=1-np.sum((ly-pred)**2)/den if den>0 else np.nan

    return float(coef[0]),float(r2)


def main():
    ap=argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument("--candidates-csv",required=True)
    ap.add_argument("--beta-sup",type=float,default=1.0)
    ap.add_argument("--tau-min",type=float,default=100.0)

    ap.add_argument(
        "--horizons",
        default="1e4,3e4,1e5,3e5,1e6,3e6,1e7,3e7,1e8",
    )

    ap.add_argument(
        "--sigmas",
        default="0,0.0003,0.001,0.003,0.01,0.03,0.05",
    )

    ap.add_argument("--trials",type=int,default=200)
    ap.add_argument("--seed",type=int,default=20260819)
    ap.add_argument("--majorant-C",type=float,default=1.284148)

    ap.add_argument(
        "--gamma-growth-gate",
        type=float,
        default=20.0,
        help="Required high/low-horizon max-active-gamma growth factor.",
    )
    ap.add_argument(
        "--average-growth-gate",
        type=float,
        default=10.0,
        help="Required high/low-horizon active-average growth factor.",
    )
    ap.add_argument(
        "--gamma-power-gate",
        type=float,
        default=0.20,
    )
    ap.add_argument(
        "--late-switch-fraction-gate",
        type=float,
        default=0.10,
    )
    ap.add_argument(
        "--majorant-ratio-gate",
        type=float,
        default=0.02,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_perturbed_multihorizon_runaway_v207",
    )

    args=ap.parse_args()

    df=pd.read_csv(args.candidates_csv)

    if not {"beta","gamma"}.issubset(df.columns):
        raise RuntimeError("Candidates CSV must contain beta and gamma.")

    beta0=df["beta"].to_numpy(float)
    gamma0=df["gamma"].to_numpy(float)

    keep=(
        np.isfinite(beta0)
        & np.isfinite(gamma0)
        & (gamma0>0)
        & (beta0>0.5)
        & (beta0<args.beta_sup)
    )

    beta0=beta0[keep]
    gamma0=gamma0[keep]

    if len(beta0)<10:
        raise RuntimeError("Too few candidates.")

    gap0=args.beta_sup-beta0

    horizons=sorted([
        float(x.strip())
        for x in args.horizons.split(",")
        if x.strip()
    ])

    sigmas=[
        float(x.strip())
        for x in args.sigmas.split(",")
        if x.strip()
    ]

    if horizons[0] <= args.tau_min:
        raise RuntimeError("All horizons must exceed tau_min.")

    rng=np.random.default_rng(args.seed)

    horizon_rows=[]
    trial_rows=[]

    print("="*194)
    print("ROT-RH v207 — PERTURBED ADVERSARY MULTI-HORIZON RUNAWAY AUDIT")
    print("="*194)
    print("Xi / zeta / known zeros          : NONE")
    print(f"positive candidates               : {len(beta0)}")
    print(f"tau min                           : {args.tau_min:.3e}")
    print(f"horizons                          : {horizons}")
    print(f"majorant C                        : {args.majorant_C:.6f}")
    print("="*194)

    for sigma in sigmas:
        ntr=1 if sigma==0 else args.trials

        for t in range(ntr):
            if sigma==0:
                gap=gap0.copy()
            else:
                gap=gap0*np.exp(
                    sigma*rng.standard_normal(len(gap0))
                )

            beta=args.beta_sup-gap
            hull=upper_hull(build_lines(beta,gamma0))

            mets=[]

            for T in horizons:
                seg=restrict_hull(hull,args.tau_min,T)
                m=metrics(seg,args.majorant_C,args.tau_min,T)
                mets.append(m)

                horizon_rows.append({
                    "sigma":sigma,
                    "trial":t,
                    "tau_max":T,
                    **m,
                })

            gamma_series=np.array(
                [m["max_active_gamma"] for m in mets],float
            )
            avg_series=np.array(
                [m["active_average"] for m in mets],float
            )

            pg,rg=power_fit(horizons,gamma_series)
            pa,ra=power_fit(horizons,avg_series)

            gamma_growth=(
                gamma_series[-1]/max(gamma_series[0],1e-300)
            )
            avg_growth=(
                avg_series[-1]/max(avg_series[0],1e-300)
            )

            high=mets[-1]

            gamma_monotone=bool(
                np.all(np.diff(gamma_series)>=-1e-12)
            )
            avg_monotone_fraction=(
                float(np.mean(np.diff(avg_series)>0))
                if len(avg_series)>1 else np.nan
            )

            runaway_like=bool(
                gamma_growth>=args.gamma_growth_gate
                and avg_growth>=args.average_growth_gate
                and np.isfinite(pg)
                and pg>=args.gamma_power_gate
                and gamma_monotone
                and avg_monotone_fraction>=0.75
                and np.isfinite(high["last_switch_fraction"])
                and high["last_switch_fraction"]
                    >= args.late_switch_fraction_gate
                and np.isfinite(high["majorant_ratio"])
                and high["majorant_ratio"]
                    <= args.majorant_ratio_gate
            )

            trial_rows.append({
                "sigma":sigma,
                "trial":t,
                "gamma_growth_factor":float(gamma_growth),
                "active_average_growth_factor":float(avg_growth),
                "gamma_power":pg,
                "gamma_power_R2":rg,
                "active_average_power":pa,
                "active_average_power_R2":ra,
                "gamma_monotone":gamma_monotone,
                "active_average_monotone_fraction":
                    avg_monotone_fraction,
                "high_terminal_gamma":
                    high["terminal_gamma"],
                "high_max_active_gamma":
                    high["max_active_gamma"],
                "high_last_switch_tau":
                    high["last_switch_tau"],
                "high_last_switch_fraction":
                    high["last_switch_fraction"],
                "high_majorant_ratio":
                    high["majorant_ratio"],
                "high_active_segments":
                    high["active_segments"],
                "runaway_like":runaway_like,
            })

    hdf=pd.DataFrame(horizon_rows)
    tdf=pd.DataFrame(trial_rows)

    summary_rows=[]

    for sigma,g in tdf.groupby("sigma",sort=True):
        summary_rows.append({
            "sigma":float(sigma),
            "trials":len(g),
            "runaway_fraction":float(np.mean(g["runaway_like"])),
            "gamma_growth_median":
                float(np.nanmedian(g["gamma_growth_factor"])),
            "gamma_growth_q10":
                float(np.nanquantile(g["gamma_growth_factor"],0.10)),
            "gamma_power_median":
                float(np.nanmedian(g["gamma_power"])),
            "gamma_power_R2_median":
                float(np.nanmedian(g["gamma_power_R2"])),
            "active_average_growth_median":
                float(np.nanmedian(g["active_average_growth_factor"])),
            "active_average_power_median":
                float(np.nanmedian(g["active_average_power"])),
            "high_gamma_median":
                float(np.nanmedian(g["high_max_active_gamma"])),
            "high_last_switch_fraction_median":
                float(np.nanmedian(g["high_last_switch_fraction"])),
            "high_majorant_ratio_median":
                float(np.nanmedian(g["high_majorant_ratio"])),
            "high_segments_median":
                float(np.nanmedian(g["high_active_segments"])),
        })

    sdf=pd.DataFrame(summary_rows).sort_values("sigma")

    positive=sdf[sdf["sigma"]>0]

    r90=positive[positive["runaway_fraction"]>=0.90]
    sigma90=float(r90["sigma"].max()) if len(r90) else 0.0

    r50=positive[positive["runaway_fraction"]>=0.50]
    sigma50=float(r50["sigma"].max()) if len(r50) else 0.0

    if sigma90>=0.01:
        verdict="MULTIHORIZON_SYNTHETIC_RUNAWAY_PERCENT_LEVEL_ROBUST"
    elif sigma50>=0.01:
        verdict="MULTIHORIZON_SYNTHETIC_RUNAWAY_MODERATELY_ROBUST"
    elif sigma90>=0.001:
        verdict="MULTIHORIZON_SYNTHETIC_RUNAWAY_SMALL_PERTURBATION_ROBUST"
    else:
        verdict="MULTIHORIZON_SYNTHETIC_RUNAWAY_ROBUSTNESS_UNRESOLVED"

    hdf.to_csv(args.prefix+"_HORIZONS.csv",index=False)
    tdf.to_csv(args.prefix+"_TRIALS.csv",index=False)
    sdf.to_csv(args.prefix+"_SUMMARY_TABLE.csv",index=False)

    summary={
        "version":207,
        "candidate_count":len(beta0),
        "tau_min":args.tau_min,
        "horizons":horizons,
        "largest_sigma_with_90pct_runaway_survival":sigma90,
        "largest_sigma_with_50pct_runaway_survival":sigma50,
        "verdict":verdict,
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    for _,r in sdf.iterrows():
        print(
            f"sigma={r['sigma']:.4f} "
            f"runaway={r['runaway_fraction']:.3f} "
            f"gammaGrowMed={r['gamma_growth_median']:.2f}x "
            f"pGammaMed={r['gamma_power_median']:.3f} "
            f"avgGrowMed={r['active_average_growth_median']:.2f}x "
            f"lastFracMed={r['high_last_switch_fraction_median']:.3f} "
            f"costMed={r['high_majorant_ratio_median']:.3e} "
            f"segmentsMed={r['high_segments_median']:.1f}"
        )

    print()
    print(f"largest sigma with >=90% survival : {sigma90:.6e}")
    print(f"largest sigma with >=50% survival : {sigma50:.6e}")
    print(f"VERDICT                            : {verdict}")
    print("="*194)


if __name__=="__main__":
    main()
