#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v272 — RIGOROUS ANCHOR GAP / CRITICAL-RESIDUE MAJORANT
==============================================================

Purpose
-------
v271 isolated a genuine issue in the Abel-Fejer cutoff-removal route:

    A2(i omega,U) -> 0 for every fixed omega != 0,

but this convergence is not uniform as omega -> 0.

For the ONE fixed v263 anchor E*, however, the dangerous near-zero frequencies
have a concrete meaning.  In the sine-shifted Dirichlet combination they come
from nontrivial zeta zeros whose ordinate gamma is close to E*.

v272 closes this fixed-anchor kernel-side issue using rigorous POST-FREEZE
zero counting, without importing any zero ordinate into the operator
construction.

Rigorous ingredients
--------------------
1. python-flint / Arb ball arithmetic:
       arb(t).zeta_nzeros()
   rigorously counts nontrivial zeta zeros with 0 < Im rho <= t.

2. We certify an explicit gap
       |gamma-E*| >= delta
   by proving
       N(E*-delta) = N(E*+delta).

3. For a critical-line residue with frequency omega, the Abel-Fejer multiplier
   obeys
       |A2(i omega,U)|
         <= 2/(|omega|U) + 4/(|omega|^2 U^2).

4. The Mellin residue also carries Gamma(i omega), with
       |Gamma(i t)|^2 = pi / (t sinh(pi t)).

   Therefore, after an explicit local gap, the entire critical-line residue
   family admits an absolutely summable majorant

       Rcrit(U) <= 2 K1/U + 4 K2/U^2,

   where
       K1 = sum |Gamma(i omega)|/|omega|,
       K2 = sum |Gamma(i omega)|/|omega|^2.

5. Exact Arb zero counts are used in finite frequency shells around E*.
   Beyond the exact shell radius, the v69 explicit N(T) upper bound plus the
   exponential Gamma envelope controls the infinite remainder.

6. The second sine-shift family has frequencies gamma+E*, which are already
   enormous; it is included by an infinite Stieltjes majorant.

Interpretation
--------------
A successful run closes the NEAR-ZERO CRITICAL-FREQUENCY issue for the fixed
v263 anchor, conditional only on rigorous zero counting and the standard
residue representation.

It does NOT prove RH.  Off-critical singularities remain the RH-strength
obstruction: they either survive and force Fejer growth or must cancel through
the vertical-period mechanism of v261/v263.

Dependency
----------
    pip install python-flint

python-flint wraps FLINT/Arb rigorous ball arithmetic.

No Xi values are used.  Zeta is used only POST-FREEZE through rigorous Arb
zero counting and an optional rigorous nonvanishing evaluation at the fixed
anchor.  No known zero ordinate is supplied.

Version: 272
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import quad
from tqdm import tqdm

VERSION = 272
EPS = np.finfo(float).eps


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def gamma_i_abs(t: float) -> float:
    """
    |Gamma(i t)|^2 = pi / (t sinh(pi t)).
    Stable exponential form for large t.
    """
    t = abs(float(t))
    if t <= 0.0:
        return float("inf")

    x = math.pi * t
    if x < 500.0:
        return math.sqrt(math.pi / (t * math.sinh(x)))

    # sinh(pi t) = .5 exp(pi t)(1-exp(-2pi t))
    den = max(1.0 - math.exp(-2.0 * x), 1e-300)
    return (
        math.sqrt(2.0 * math.pi / t)
        * math.exp(-0.5 * x)
        / math.sqrt(den)
    )


def gamma_envelope_constant(W: float) -> float:
    """
    For t>=W:
      |Gamma(i t)|
      <= C0 exp(-pi t/2) t^-1/2,
    C0 = sqrt(2pi) / sqrt(1-exp(-2pi W)).
    """
    W = float(W)
    return (
        math.sqrt(2.0 * math.pi)
        / math.sqrt(max(1.0 - math.exp(-2.0 * math.pi * W), 1e-300))
    )


def f_env(w: float, p: float, W: float) -> float:
    """
    Envelope
      C0 exp(-a w) w^-p,
    where p=3/2 bounds |Gamma(iw)|/w
          p=5/2 bounds |Gamma(iw)|/w^2.
    """
    w = float(w)
    if w < float(W):
        raise ValueError("f_env called below W")
    a = 0.5 * math.pi
    C0 = gamma_envelope_constant(W)
    return C0 * math.exp(-a * w) * (w ** (-float(p)))


def minus_f_env_derivative(w: float, p: float, W: float) -> float:
    """
    For f=C exp(-a w) w^-p,
      -f' = f (a + p/w).
    """
    f = f_env(w, p, W)
    return f * (0.5 * math.pi + float(p) / float(w))


def n_upper(v69, T: float) -> float:
    """
    Explicit upper bound N(T) <= F_main(T)+N_error(T), clipped at zero.
    """
    T = float(T)
    if T <= math.e:
        return 0.0
    return max(0.0, float(v69.F_main(T) + v69.N_error(T)))


def right_infinite_tail(v69, E, W, p):
    """
    Bound
      sum_{gamma >= E+W} f(gamma-E)
    by Stieltjes integration:

      int_{E+W}^inf f(t-E) dN(t)
      <= int_{E+W}^inf N_upper(t) (-f'(t-E)) dt.

    The negative lower endpoint term from integration by parts is dropped.
    """
    lower = float(E) + float(W)

    def integrand(t):
        w = t - float(E)
        return n_upper(v69, t) * minus_f_env_derivative(w, p, W)

    val, err = quad(
        integrand,
        lower,
        np.inf,
        epsabs=1e-18,
        epsrel=1e-10,
        limit=500,
    )
    return float(val), float(err)


def left_finite_tail(N_left: int, W: float, p: float) -> float:
    """
    For every gamma <= E-W, w=E-gamma >= W and f is decreasing:
       sum f(E-gamma) <= N(E-W) f(W).
    """
    return float(N_left) * f_env(float(W), float(p), float(W))


def plus_shift_infinite_tail(v69, E, W, p):
    """
    Bound the second sine-shift family with frequency w=gamma+E.

    Since E is large, this is astronomically small.  Use Stieltjes integration
    directly with the same Gamma envelope.

      sum_gamma f(gamma+E)
      <= int_e^inf N_upper(t)(-d/dt f(t+E)) dt.
    """
    E = float(E)
    lower = math.e

    # Envelope is valid because t+E >> W.
    def integrand(t):
        w = t + E
        return n_upper(v69, t) * minus_f_env_derivative(w, p, W)

    val, err = quad(
        integrand,
        lower,
        np.inf,
        epsabs=1e-18,
        epsrel=1e-10,
        limit=500,
    )
    return float(val), float(err)


def exact_count(nzeros_fn, a: float, b: float) -> int:
    """
    Exact count in (a,b] from rigorous cumulative counts.
    """
    if b <= a:
        return 0
    na = nzeros_fn(a)
    nb = nzeros_fn(b)
    d = int(nb - na)
    if d < 0:
        raise RuntimeError("zeta_nzeros count decreased")
    return d


def critical_bound(K1, K2, U):
    U = float(U)
    return 2.0 * float(K1) / U + 4.0 * float(K2) / (U * U)


def U_for_bound(K1, K2, target):
    """
    Solve
       2K1/U + 4K2/U^2 <= target.
    """
    target = float(target)
    if target <= 0:
        return float("inf")
    return (
        float(K1)
        + math.sqrt(float(K1) ** 2 + 4.0 * target * float(K2))
    ) / target


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)
    ap.add_argument(
        "--v69-module",
        default="rot_rh_fixed_height_contour_shift_regularized_v69",
    )

    ap.add_argument(
        "--gap-candidates",
        default="0.005,0.01,0.02,0.03",
        help="Increasing candidate half-gaps around E to certify with Arb zero counts.",
    )
    ap.add_argument(
        "--exact-shell-edges",
        default="0.03,0.05,0.1,0.25,0.5,1,2,4,8,12,20",
        help="Frequency shells around E using exact Arb zero counts.",
    )
    ap.add_argument(
        "--flint-dps",
        type=int,
        default=60,
    )

    ap.add_argument(
        "--U-values",
        default="1e3,1e4,1e5,1e6,1e7",
    )
    ap.add_argument(
        "--target-critical-residue-bound",
        type=float,
        default=1e-3,
    )

    ap.add_argument(
        "--anchor-zeta-nonzero",
        action="store_true",
        help="Also rigorously evaluate zeta(1/2+iE) with Arb and require abs lower bound >0.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_anchor_gap_critical_residue_v272",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()

    # --------------------------------------------------------------
    # Rigorous Arb dependency.
    # --------------------------------------------------------------
    try:
        from flint import arb, acb, ctx
    except Exception as exc:
        raise RuntimeError(
            "v272 requires python-flint / Arb rigorous ball arithmetic.\n"
            "Install it with:\n\n"
            "    pip install python-flint\n\n"
            f"Import error: {exc}"
        )

    ctx.dps = int(args.flint_dps)

    anchors = pd.read_csv(args.anchors)
    if not {"k", "E_anchor"}.issubset(anchors.columns):
        raise KeyError("anchors file must contain k,E_anchor")
    anchors["k"] = anchors["k"].astype(int)
    hit = anchors[anchors["k"] == int(args.anchor_k)]
    if len(hit) != 1:
        raise RuntimeError(f"Expected exactly one anchor k={args.anchor_k}")
    E = float(hit["E_anchor"].iloc[0])

    v69 = importlib.import_module(args.v69_module)

    gaps = sorted(set(parse_floats(args.gap_candidates)))
    if not gaps or min(gaps) <= 0:
        raise ValueError("gap candidates must be positive")

    U_values = parse_floats(args.U_values)

    # Cache exact zero counts because many shell endpoints repeat.
    count_cache = {}

    def rigorous_nzeros(t):
        t = float(t)
        if t <= 0:
            return 0
        key = format(t, ".15g")
        if key in count_cache:
            return count_cache[key]

        ball = arb(key).zeta_nzeros()
        n = ball.unique_fmpz()
        if n is None:
            raise RuntimeError(
                f"Arb could not certify a unique integer N({key}); "
                "increase --flint-dps or move the endpoint."
            )
        val = int(n)
        count_cache[key] = val
        return val

    print("=" * 202)
    print("ROT-RH v272 — RIGOROUS ANCHOR GAP / CRITICAL-RESIDUE MAJORANT")
    print("=" * 202)
    print("operator construction zeta use      : NONE")
    print("post-freeze rigorous Arb zeta count : YES")
    print("known zero ordinates supplied        : NONE")
    print(f"anchor k                             : {args.anchor_k}")
    print(f"anchor E                             : {E:.15f}")
    print(f"Arb precision                        : {args.flint_dps} dps")
    print(f"gap candidates                       : {gaps}")
    print("=" * 202)

    # --------------------------------------------------------------
    # 1. Rigorous local zero-free ordinate gap.
    # --------------------------------------------------------------
    print("[1] Rigorous Arb zero-count gap certification")

    gap_rows = []
    certified_gaps = []

    for delta in tqdm(gaps, desc="Arb gap candidates", unit="gap"):
        lo = E - float(delta)
        hi = E + float(delta)

        Nlo = rigorous_nzeros(lo)
        Nhi = rigorous_nzeros(hi)
        local_count = int(Nhi - Nlo)
        passed = bool(local_count == 0)

        if passed:
            certified_gaps.append(float(delta))

        gap_rows.append({
            "delta": float(delta),
            "low": lo,
            "high": hi,
            "N_low": Nlo,
            "N_high": Nhi,
            "zeros_in_openclosed_interval": local_count,
            "certified_zero_free": passed,
        })

    if not certified_gaps:
        selected_gap = float("nan")
    else:
        selected_gap = max(certified_gaps)

    # Optional rigorous nonvanishing at the exact anchor.
    anchor_zeta_abs_lower = float("nan")
    anchor_zeta_nonzero_pass = True

    if args.anchor_zeta_nonzero:
        s = acb(arb("0.5"), arb(format(E, ".17g")))
        z = s.zeta()
        lower = z.abs_lower()
        anchor_zeta_abs_lower = float(lower)
        anchor_zeta_nonzero_pass = bool(anchor_zeta_abs_lower > 0.0)

    if not np.isfinite(selected_gap):
        # Still write gap table, then fail gracefully below.
        selected_gap = 0.0

    # --------------------------------------------------------------
    # 2. Exact local frequency shells.
    # --------------------------------------------------------------
    print("[2] Exact local residue-shell counts")

    raw_edges = parse_floats(args.exact_shell_edges)
    edges = sorted(set(
        [selected_gap]
        + [x for x in raw_edges if x > selected_gap]
    ))

    if selected_gap <= 0 or len(edges) < 2:
        shell_rows = []
        K1_local = float("inf")
        K2_local = float("inf")
        W = float("nan")
    else:
        shell_rows = []
        K1_local = 0.0
        K2_local = 0.0

        for a, b in tqdm(
            list(zip(edges[:-1], edges[1:])),
            desc="exact frequency shells",
            unit="shell",
        ):
            # Right of E: gamma in (E+a, E+b].
            nr = exact_count(
                rigorous_nzeros,
                E + float(a),
                E + float(b),
            )

            # Left of E: gamma in [E-b, E-a).  Boundary conventions are
            # harmless because the endpoints are certified count points.
            lo = max(0.0, E - float(b))
            hi = max(0.0, E - float(a))
            nl = exact_count(rigorous_nzeros, lo, hi)

            n = int(nr + nl)
            ga = gamma_i_abs(float(a))

            k1 = float(n) * ga / float(a)
            k2 = float(n) * ga / (float(a) ** 2)

            K1_local += k1
            K2_local += k2

            shell_rows.append({
                "omega_lo": float(a),
                "omega_hi": float(b),
                "zeros_right_of_E": int(nr),
                "zeros_left_of_E": int(nl),
                "total_zero_count": n,
                "gamma_abs_at_lo": ga,
                "K1_shell_bound": k1,
                "K2_shell_bound": k2,
            })

        W = float(edges[-1])

    # --------------------------------------------------------------
    # 3. Infinite tails beyond exact shell radius.
    # --------------------------------------------------------------
    print("[3] Infinite Gamma-weighted critical-residue tails")

    if selected_gap > 0:
        N_left_W = rigorous_nzeros(max(0.0, E - W))

        K1_left = left_finite_tail(N_left_W, W, 1.5)
        K2_left = left_finite_tail(N_left_W, W, 2.5)

        K1_right, K1_right_err = right_infinite_tail(
            v69, E, W, 1.5
        )
        K2_right, K2_right_err = right_infinite_tail(
            v69, E, W, 2.5
        )

        K1_plus, K1_plus_err = plus_shift_infinite_tail(
            v69, E, W, 1.5
        )
        K2_plus, K2_plus_err = plus_shift_infinite_tail(
            v69, E, W, 2.5
        )

        K1_total = K1_local + K1_left + K1_right + K1_plus
        K2_total = K2_local + K2_left + K2_right + K2_plus
    else:
        N_left_W = 0
        K1_left = K2_left = float("inf")
        K1_right = K2_right = float("inf")
        K1_plus = K2_plus = float("inf")
        K1_right_err = K2_right_err = float("nan")
        K1_plus_err = K2_plus_err = float("nan")
        K1_total = K2_total = float("inf")

    # --------------------------------------------------------------
    # 4. Fejer critical residue majorant.
    # --------------------------------------------------------------
    bound_rows = []
    if np.isfinite(K1_total) and np.isfinite(K2_total):
        for U in U_values:
            bound_rows.append({
                "U": float(U),
                "critical_residue_majorant": critical_bound(
                    K1_total, K2_total, U
                ),
            })

        U_target = U_for_bound(
            K1_total,
            K2_total,
            float(args.target_critical_residue_bound),
        )
    else:
        for U in U_values:
            bound_rows.append({
                "U": float(U),
                "critical_residue_majorant": float("inf"),
            })
        U_target = float("inf")

    gap_df = pd.DataFrame(gap_rows)
    shell_df = pd.DataFrame(shell_rows)
    bound_df = pd.DataFrame(bound_rows)

    gates = {
        "rigorous_positive_anchor_gap": bool(selected_gap > 0),
        "optional_anchor_zeta_nonzero": bool(anchor_zeta_nonzero_pass),
        "critical_K1_finite": bool(np.isfinite(K1_total)),
        "critical_K2_finite": bool(np.isfinite(K2_total)),
        "critical_majorant_tends_to_zero": bool(
            np.isfinite(K1_total)
            and np.isfinite(K2_total)
            and K1_total >= 0
            and K2_total >= 0
        ),
    }

    failed = [name for name, ok in gates.items() if not ok]

    if not failed:
        mechanism = (
            "FIXED_ANCHOR_NEAR_ZERO_CRITICAL_RESIDUE_CONTROL_CERTIFIED"
        )
        next_theorem = (
            "The fixed-anchor near-zero critical-frequency issue is closed "
            "for the v263 hybrid route. Proceed to the analytic continuation "
            "and off-critical singularity cancellation dichotomy: surviving "
            "Re z>0 singularity => Fejer growth; cancellation => vertical "
            "period 2E*, contradicted by the finite-height RH theorem."
        )
    else:
        mechanism = (
            "FIXED_ANCHOR_CRITICAL_RESIDUE_GAP_NOT_CERTIFIED"
        )
        next_theorem = (
            "Do not proceed to the off-critical contour theorem until a "
            "rigorous positive zero-count gap around the anchor is certified."
        )

    verdict = (
        "ANCHOR_GAP_CRITICAL_RESIDUE_AUDIT_VERIFIED"
        if not failed
        else "ANCHOR_GAP_CRITICAL_RESIDUE_AUDIT_GATE_FAILURE"
    )

    prefix = args.prefix
    gap_path = Path(prefix + "_GAP_CERTIFICATE.csv")
    shells_path = Path(prefix + "_CRITICAL_SHELLS.csv")
    bounds_path = Path(prefix + "_CRITICAL_MAJORANT.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM_AUDIT.md")

    gap_df.to_csv(gap_path, index=False)
    shell_df.to_csv(shells_path, index=False)
    bound_df.to_csv(bounds_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "zeta_in_operator_construction": False,
            "known_zero_ordinates_supplied": False,
            "postfreeze_rigorous_Arb_zero_counting": True,
            "Xi_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
            "rigorous_selected_ordinate_gap": selected_gap,
            "optional_zeta_abs_lower_at_anchor": anchor_zeta_abs_lower,
        },
        "rigorous_gap": {
            "candidate_gaps": gaps,
            "largest_certified_gap": selected_gap,
            "meaning": (
                "Arb certified N(E-delta)=N(E+delta), so there is no "
                "nontrivial zeta zero with ordinate in that interval."
            ),
        },
        "critical_residue_majorant": {
            "exact_shell_radius_W": W,
            "K1_local": K1_local,
            "K2_local": K2_local,
            "K1_left_finite_tail": K1_left,
            "K2_left_finite_tail": K2_left,
            "K1_right_infinite_tail": K1_right,
            "K2_right_infinite_tail": K2_right,
            "K1_plus_shift_infinite_tail": K1_plus,
            "K2_plus_shift_infinite_tail": K2_plus,
            "K1_total": K1_total,
            "K2_total": K2_total,
            "Fejer_bound": (
                "Rcrit(U) <= 2 K1/U + 4 K2/U^2"
            ),
            "target_bound": float(args.target_critical_residue_bound),
            "U_sufficient_for_target_by_majorant": U_target,
        },
        "tail_method": {
            "finite_local_shells": "exact rigorous Arb zero counts",
            "infinite_right_tail": (
                "v69 explicit N(T) upper bound + Gamma exponential envelope "
                "+ Stieltjes integration by parts"
            ),
            "left_tail": (
                "finite cumulative zero count times decreasing Gamma envelope"
            ),
            "plus_shift_family": (
                "infinite Stieltjes majorant at frequencies gamma+E"
            ),
        },
        "proof_ledger": {
            "v271_fixed_nonzero_kernel_suppression": "CLOSED",
            "fixed_anchor_zero_frequency_gap": (
                "CLOSED BY RIGOROUS ARB ZERO COUNT" if selected_gap > 0 else "OPEN"
            ),
            "critical_residue_absolute_majorant": (
                "FINITE AND DECAYS LIKE O(1/U)" if np.isfinite(K1_total) else "OPEN"
            ),
            "remaining_obligation": (
                "Analytic continuation / residue formula and off-critical "
                "singularity dichotomy."
            ),
            "important_scope": (
                "This closes near-zero critical-frequency control only for the "
                "fixed one-anchor v263 hybrid route. It is not a uniform-in-k "
                "gap theorem for the full infinite operator."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN overall. The fixed-anchor critical residue filtering can be "
            "made rigorous with Arb zero counts and Gamma summability. The "
            "remaining RH-strength step is continuation and off-critical "
            "singularity cancellation/exclusion."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }

    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v272 — fixed-anchor near-zero critical residue audit

## Rigorous local gap

Anchor:

`E* = {E:.15f}`.

Largest certified half-gap:

`delta = {selected_gap:.15g}`.

The certification is by rigorous Arb zero counting:

`N(E*-delta) = N(E*+delta)`.

No zero ordinate is supplied to the construction.

## Critical residue majorant

For critical frequency `omega`,

`|A2(i omega,U)| <= 2/(|omega|U)+4/(|omega|^2 U^2)`.

The local Arb gap removes `omega=0`.

With the Gamma residue weight,

`|Gamma(i omega)|^2 = pi/(|omega|sinh(pi|omega|))`.

Hence

`Rcrit(U) <= 2 K1/U + 4 K2/U^2`

with finite constants

`K1 <= {K1_total:.15g}`

`K2 <= {K2_total:.15g}`.

Therefore the complete critical-line residue majorant tends to zero for this
fixed anchor.

## Scope

This closes the near-zero CRITICAL-frequency issue for the v263 one-anchor
hybrid route. It does not provide a uniform gap over all operator modes.

The remaining theorem is the contour/analytic-continuation statement for
off-critical singularities:

1. if an off-critical singularity survives in the sine combination, the
   Abel-Fejer factor grows exponentially;
2. if it cancels, the companion singularity imposes the vertical period
   `2E*`;
3. v263 combines that period with the rigorous finite-height RH verification
   to obtain a contradiction.

Making that continuation/residue dichotomy rigorous is the remaining
RH-strength step.
""",
        encoding="utf-8",
    )

    print()
    print("=" * 202)
    print("ROT-RH v272 — ANCHOR GAP / CRITICAL RESIDUE SUMMARY")
    print("=" * 202)
    print(f"anchor E                             : {E:.15f}")
    print(f"largest rigorous zero-free half-gap  : {selected_gap:.9e}")
    if args.anchor_zeta_nonzero:
        print(
            "rigorous |zeta(1/2+iE)| lower bound: "
            f"{anchor_zeta_abs_lower:.9e}"
        )

    print()
    print("CRITICAL RESIDUE CONSTANTS")
    print("-" * 202)
    print(f"exact shell radius W                 : {W:.6f}")
    print(f"K1 local                             : {K1_local:.9e}")
    print(f"K2 local                             : {K2_local:.9e}")
    print(f"K1 total                             : {K1_total:.9e}")
    print(f"K2 total                             : {K2_total:.9e}")
    print(
        "majorant                            : "
        "Rcrit(U) <= 2 K1/U + 4 K2/U^2"
    )
    print(
        "U sufficient for target             : "
        f"{U_target:.9e}"
    )

    print()
    print("MAJORANT PANEL")
    print("-" * 202)
    for r in bound_rows:
        print(
            f"U={r['U']:>12.3e} "
            f"Rcrit<={r['critical_residue_majorant']:.9e}"
        )

    print()
    print("THEOREM LEDGER")
    print("-" * 202)
    print("fixed nonzero kernel suppression     : CLOSED (v271)")
    print(
        "fixed-anchor zero-frequency gap      : "
        + ("RIGOROUSLY CERTIFIED" if selected_gap > 0 else "OPEN")
    )
    print(
        "critical residue summability         : "
        + ("FINITE / O(1/U)" if np.isfinite(K1_total) else "OPEN")
    )
    print(
        "remaining barrier                    : "
        "CONTINUATION + OFF-CRITICAL SINGULARITY DICHOTOMY"
    )

    print()
    print(f"MECHANISM                            : {mechanism}")
    print("=" * 202)
    print("FAILED GATES                         :", failed if failed else "none")
    print("VERDICT                              :", verdict)
    print(
        "PROOF VERDICT                        : OPEN — "
        "OFF-CRITICAL CONTINUATION / CANCELLATION THEOREM"
    )
    print("=" * 202)
    print("Files written:")
    print(" ", gap_path)
    print(" ", shells_path)
    print(" ", bounds_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
