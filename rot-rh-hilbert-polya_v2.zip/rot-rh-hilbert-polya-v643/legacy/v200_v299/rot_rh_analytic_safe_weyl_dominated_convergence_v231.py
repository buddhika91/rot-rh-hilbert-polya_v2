#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v231 — ANALYTIC-SAFE WEYL CONSTANT / DOMINATED-CONVERGENCE BRIDGE
=======================================================================

Purpose
-------
Repair the one misleading aspect of v230.

v230 froze a very strong empirical Weyl coefficient

    c_emp ~ min E_k(L) log(k+e)/k

from finite data.  But the true Riemann-von-Mangoldt scale has

    E_k ~ 2*pi*k/log k,

so c_{L,k} is expected to drift downward toward 2*pi.  A finite-data constant
near 9 is therefore NOT a suitable all-k theorem constant.

For a global theorem candidate, start instead from the root-local decomposition

    k - 1/2
      = theta(E)/pi + 1 + R_L(E),

and assume the two inequalities

    theta(E)/pi + 1 <= A_theta + B_theta E log(E+e),

    |R_L(E)| <= C_R log(E+e).

For E>=1,

    log(E+e) <= E log(E+e),

so

    k <= A + B E log(E+e),

with

    A = A_theta + 1/2,
    B = B_theta + C_R.

For k>=2A, a standard two-case argument gives

    E_k(L) >= c_theorem * k/log(k+e),

where

    c_theorem = 1/(2B).

This script:
  * derives c_theorem from the conservative analytic-bridge constants,
  * proves the elementary algebraic implication symbolically/numerically,
  * checks the resulting lower bound against all available zero-blind roots,
  * computes the corresponding infinite trace-tail majorant,
  * removes the artificial 2e9 search cap from v230 and resolves arbitrary
    practical epsilon targets using Python integers,
  * reads v229/v230 summaries and separates substantive theorem gates from the
    v230 implementation-only epsilon cap.

NO Xi / zeta values / known-zero ordinates are used.

Important
---------
This script does NOT prove the two assumed inequalities.  It makes the theorem
constant honest: once those inequalities are proved, the Weyl domination and
dominated-convergence trace-norm conclusion follow by elementary analysis.

Version: 231
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v231 requires tqdm") from exc


VERSION = 231
EE = math.e


def csv_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def csv_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def load_json(path):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    return json.loads(p.read_text(encoding="utf-8"))


def h(E):
    E = float(E)
    return E * math.log(E + EE)


def trace_tail_majorant(c, N):
    """
    For N>=3,

      sum_{k>N} [log(k+e)/k]^2
        <= [(log N+d)^2 + 2(log N+d)+2]/N,

      d=log(1+e/N).

    Multiply by c^-2.
    """
    N = int(N)
    if N < 3 or c <= 0:
        return float("inf")
    d = math.log1p(EE / N)
    u = math.log(N) + d
    return (u*u + 2*u + 2) / (N * c*c)


def minimum_N_for_single_tail(c, target):
    """
    Unbounded Python-integer search.  No arbitrary 2e9 ceiling.
    """
    if c <= 0 or target <= 0:
        return -1

    hi = 3
    while trace_tail_majorant(c, hi) > target:
        hi *= 2

    lo = 3
    while lo < hi:
        mid = (lo + hi) // 2
        if trace_tail_majorant(c, mid) <= target:
            hi = mid
        else:
            lo = mid + 1
    return int(lo)


def minimum_k_log_condition(c):
    k = 1
    while math.log(k + EE) < c:
        k += 1
    return k


def derive_constants(A_theta, B_theta, C_R):
    # For E>=1, C_R log(E+e) <= C_R E log(E+e).
    A = float(A_theta) + 0.5
    B = float(B_theta) + float(C_R)
    c = 1.0 / (2.0 * B)

    # Exclude E<=1 roots using the same assumed envelopes.
    # If E<=1:
    #   k-1/2 <= A_theta + B_theta*h(1) + C_R*log(1+e).
    k_bound_E_le_1 = (
        0.5
        + float(A_theta)
        + float(B_theta) * h(1.0)
        + float(C_R) * math.log(1.0 + EE)
    )
    k0_energy = int(math.floor(k_bound_E_le_1)) + 1

    # Need k-A >= k/2.
    k0_A = int(math.ceil(2.0 * A))

    # In the branch E>=k, require k >= c*k/log(k+e).
    k0_log = minimum_k_log_condition(c)

    k0 = max(3, k0_energy, k0_A, k0_log)

    return {
        "A_theta": float(A_theta),
        "B_theta": float(B_theta),
        "C_R": float(C_R),
        "A_total": A,
        "B_total": B,
        "c_theorem": c,
        "k_bound_if_E_le_1": k_bound_E_le_1,
        "k0_energy": k0_energy,
        "k0_A": k0_A,
        "k0_log": k0_log,
        "k0": k0,
    }


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--canonical-roots",
        default="rot_rh_dominated_convergence_cutoff_independence_v230_CANONICAL_ROOTS.csv.gz",
    )
    ap.add_argument(
        "--v229-summary",
        default="rot_rh_taylor_enclosed_cutoff_independence_v229_SUMMARY.json",
    )
    ap.add_argument(
        "--v230-summary",
        default="rot_rh_dominated_convergence_cutoff_independence_v230_SUMMARY.json",
    )

    # Conservative bridge constants from the prior v224 theorem-target audit.
    ap.add_argument("--theta-A", type=float, default=2.25)
    ap.add_argument("--theta-B", type=float, default=0.25)
    ap.add_argument("--remainder-C", type=float, default=0.116520)

    ap.add_argument(
        "--epsilon-values",
        default="1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10",
    )
    ap.add_argument(
        "--tail-N-values",
        default="32,64,128,256,512,1024,4096,16384,65536,262144,1048576",
    )

    ap.add_argument("--minimum-root-margin", type=float, default=1.0)
    ap.add_argument(
        "--prefix",
        default="rot_rh_analytic_safe_weyl_dominated_convergence_v231",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    const = derive_constants(args.theta_A, args.theta_B, args.remainder_C)
    c = const["c_theorem"]
    k0 = const["k0"]

    roots = pd.read_csv(args.canonical_roots)
    need = {"L", "k", "E"}
    miss = need - set(roots.columns)
    if miss:
        raise KeyError(f"canonical roots missing {sorted(miss)}")
    roots = roots[
        np.isfinite(roots["L"])
        & np.isfinite(roots["k"])
        & np.isfinite(roots["E"])
        & (roots["E"] > 0)
    ].copy()
    roots["k"] = roots["k"].astype(int)

    v229 = load_json(args.v229_summary)
    v230 = load_json(args.v230_summary)

    # ---------------------------------------------------------------
    # Check the conservative theorem lower bound against every root.
    # ---------------------------------------------------------------
    test = roots[roots["k"] >= k0].copy()
    if test.empty:
        raise RuntimeError("No roots at/above derived k0")

    test["theorem_lower_bound"] = (
        c * test["k"].to_numpy(float)
        / np.log(test["k"].to_numpy(float) + EE)
    )
    test["E_over_bound"] = (
        test["E"].to_numpy(float)
        / test["theorem_lower_bound"].to_numpy(float)
    )
    test["margin"] = (
        test["E"].to_numpy(float)
        - test["theorem_lower_bound"].to_numpy(float)
    )

    worst = test.loc[test["E_over_bound"].idxmin()]

    # Cutoffwise and modewise minimum ratios.
    cutoff_rows = []
    for L, g in tqdm(test.groupby("L", sort=True), desc="Cutoff theorem margins", unit="L"):
        cutoff_rows.append({
            "L": int(L),
            "rows": int(len(g)),
            "k_max": int(g["k"].max()),
            "minimum_E_over_theorem_bound": float(g["E_over_bound"].min()),
            "minimum_absolute_margin": float(g["margin"].min()),
        })
    cutoff_df = pd.DataFrame(cutoff_rows)

    mode_rows = []
    for k, g in tqdm(test.groupby("k", sort=True), desc="Mode theorem margins", unit="k"):
        mode_rows.append({
            "k": int(k),
            "cutoffs": int(g["L"].nunique()),
            "minimum_E_over_theorem_bound": float(g["E_over_bound"].min()),
            "minimum_absolute_margin": float(g["margin"].min()),
        })
    mode_df = pd.DataFrame(mode_rows)

    # ---------------------------------------------------------------
    # Tail majorants.
    # ---------------------------------------------------------------
    tail_rows = []
    for N in sorted(set(csv_ints(args.tail_N_values))):
        single = trace_tail_majorant(c, N)
        tail_rows.append({
            "N": int(N),
            "single_operator_tail_bound": single,
            "two_operator_tail_bound": 2.0 * single,
        })
    tail_df = pd.DataFrame(tail_rows)

    eps_rows = []
    for eps in sorted(set(csv_floats(args.epsilon_values)), reverse=True):
        # For a Cauchy epsilon proof allocate eps/2 to the high tail:
        # two-operator high tail <= eps/2
        # => single tail <= eps/4.
        N = minimum_N_for_single_tail(c, eps / 4.0)
        single = trace_tail_majorant(c, N)
        eps_rows.append({
            "epsilon": eps,
            "N_required": N,
            "single_tail_bound": single,
            "two_operator_tail_bound": 2.0 * single,
            "target_two_operator_tail": eps / 2.0,
            "pass": 2.0 * single <= eps / 2.0,
        })
    eps_df = pd.DataFrame(eps_rows)

    # ---------------------------------------------------------------
    # Substantive v230 gates: explicitly exclude implementation cap gate.
    # ---------------------------------------------------------------
    v230_gates = dict(v230.get("gates", {}))
    substantive_v230 = {
        k: bool(v)
        for k, v in v230_gates.items()
        if k != "epsilon_tail_cutoffs_resolved"
    }
    substantive_v230_pass = all(substantive_v230.values())

    v229_gates = dict(v229.get("gates", {}))
    v229_pass = all(bool(v) for v in v229_gates.values())

    gates = {
        "derived_B_positive": const["B_total"] > 0,
        "derived_c_positive": c > 0,
        "derived_k0_finite": k0 >= 3,
        "all_available_roots_above_theorem_bound": bool(
            np.all(test["E_over_bound"].to_numpy(float) >= args.minimum_root_margin)
        ),
        "all_epsilon_tail_targets_resolved": bool(eps_df["pass"].all()),
        "v229_all_recorded_gates_pass": v229_pass,
        "v230_all_substantive_gates_pass": substantive_v230_pass,
    }

    failed = [k for k, v in gates.items() if not v]
    verdict = (
        "ANALYTIC_SAFE_WEYL_DOMINATED_CONVERGENCE_BRIDGE_STRONGLY_SUPPORTED"
        if not failed
        else
        "ANALYTIC_SAFE_WEYL_DOMINATED_CONVERGENCE_BRIDGE_UNRESOLVED"
    )

    prefix = args.prefix
    test_path = Path(prefix + "_ROOT_CHECK.csv.gz")
    cutoff_path = Path(prefix + "_CUTOFF_MARGINS.csv")
    mode_path = Path(prefix + "_MODE_MARGINS.csv")
    tail_path = Path(prefix + "_TAIL_MAJORANTS.csv")
    eps_path = Path(prefix + "_EPSILON_CUTOFFS.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM.md")

    test.to_csv(test_path, index=False, compression="gzip")
    cutoff_df.to_csv(cutoff_path, index=False)
    mode_df.to_csv(mode_path, index=False)
    tail_df.to_csv(tail_path, index=False)
    eps_df.to_csv(eps_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
        },
        "constants": const,
        "worst_available_root_check": {
            "L": int(worst["L"]),
            "k": int(worst["k"]),
            "E": float(worst["E"]),
            "theorem_lower_bound": float(worst["theorem_lower_bound"]),
            "E_over_bound": float(worst["E_over_bound"]),
            "absolute_margin": float(worst["margin"]),
        },
        "epsilon_cutoffs": eps_rows,
        "v229_verdict": v229.get("verdict"),
        "v230_verdict": v230.get("verdict"),
        "v230_failed_gates_original": v230.get("failed_gates", []),
        "v230_substantive_gates": substantive_v230,
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "proof_status": {
            "theta_envelope": (
                "CANDIDATE CONSTANT USED HERE. Must be proved analytically "
                "with an explicit Stirling inequality."
            ),
            "root_local_remainder": (
                "CANDIDATE CONSTANT USED HERE. This is the main arithmetic lemma: "
                "|R_L(E_{k,L})| <= C_R log(E_{k,L}+e) uniformly in large L and k."
            ),
            "weyl_lower_bound": (
                "ELEMENTARY CONSEQUENCE once the two inequalities above are proved."
            ),
            "trace_norm_cutoff_removal": (
                "ELEMENTARY dominated-convergence consequence once fixed-k convergence "
                "and the uniform Weyl lower bound are proved."
            ),
        },
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    theorem = f"""# ROT-RH v231 analytic-safe cutoff-independence bridge

Assume, uniformly at the selected secular roots,

`theta(E)/pi + 1 <= {const['A_theta']:.12g} + {const['B_theta']:.12g} E log(E+e)`

and

`|R_L(E)| <= {const['C_R']:.12g} log(E+e)`.

For `E>=1`,

`log(E+e) <= E log(E+e)`,

hence

`k <= {const['A_total']:.12g} + {const['B_total']:.12g} E log(E+e)`.

For `k >= {const['k0']}` the standard two-case argument yields

`E_k(L) >= {const['c_theorem']:.12g} k/log(k+e)`.

Therefore

`E_k(L)^(-2) <= {1/(const['c_theorem']**2):.12g} [log(k+e)/k]^2`,

and the right-hand side is summable.

Combined with fixed-mode convergence `E_k(L)->E_k`, dominated convergence gives

`||K_L-K_infinity||_1 -> 0`.

This implication is rigorous algebra.  What remains open is proving the two
assumed uniform inequalities and fixed-mode convergence for all fixed k.
"""
    theorem_path.write_text(theorem, encoding="utf-8")

    print("=" * 176)
    print("ROT-RH v231 — ANALYTIC-SAFE WEYL / DOMINATED-CONVERGENCE BRIDGE")
    print("=" * 176)
    print("Xi / zeta / known-zero data        : NONE")
    print(f"A_theta                             : {const['A_theta']:.12f}")
    print(f"B_theta                             : {const['B_theta']:.12f}")
    print(f"C_R                                 : {const['C_R']:.12f}")
    print(f"B_total                             : {const['B_total']:.12f}")
    print(f"THEOREM CANDIDATE c                 : {c:.12f}")
    print(f"derived k0                          : {k0}")
    print()
    print("AVAILABLE ROOT CHECK")
    print("-" * 176)
    print(f"tested rows                         : {len(test)}")
    print(f"worst L / k                         : {int(worst['L'])} / {int(worst['k'])}")
    print(f"worst E / theorem lower bound       : {float(worst['E_over_bound']):.9f}")
    print(f"worst absolute margin               : {float(worst['margin']):.9f}")
    print()
    print("EPSILON HIGH-TAIL SCALE")
    print("-" * 176)
    for r in eps_rows:
        print(
            f"eps={r['epsilon']:.1e}  "
            f"N>={r['N_required']:>14d}  "
            f"two-tail<={r['two_operator_tail_bound']:.6e}  "
            f"pass={r['pass']}"
        )
    print()
    print("v230 original failed gates          :", v230.get("failed_gates", []))
    print("v230 substantive gates pass         :", substantive_v230_pass)
    print("v229 recorded gates pass             :", v229_pass)
    print("=" * 176)
    print("FAILED v231 GATES                   :", failed if failed else "none")
    print("NUMERICAL / ALGEBRAIC VERDICT       :", verdict)
    print("PROOF VERDICT                       : OPEN — TWO UNIFORM ANALYTIC LEMMAS + FIXED-k LIMIT")
    print("=" * 176)
    print("Files written:")
    for p in [test_path, cutoff_path, mode_path, tail_path, eps_path, summary_path, theorem_path]:
        print(" ", p)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
