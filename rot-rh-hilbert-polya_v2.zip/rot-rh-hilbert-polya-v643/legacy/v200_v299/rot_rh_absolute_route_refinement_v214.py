#!/usr/bin/env python3
"""
ROT-RH v214 — FULL-SUPPORT SCALED-SHELL REFINEMENT / ABSOLUTE-ROUTE CERTIFICATION

Zero-blind prime-side audit.
No Xi / zeta evaluations / known-zero ordinates.

MOTIVATION
----------
v213 found

    L1(L,E) = sum_j |D_j(L,E)|

decreasing across L, with max-energy slope about -0.118 and every sampled
energy having a negative slope.  Since

    |Delta A_L(E)| <= L1(L,E),

this could give a radically simpler cutoff-removal mechanism.

Before treating that as a serious route, v214 removes two numerical loopholes:

1. FULL LOW-u SUPPORT
   v213 used u=n/L >= 5e-4.  For large L this omitted a growing set of small n.
   v214 sets the finest-grid lower edge to

       u_min = 2 / max(L),

   so every prime power n>=2 is represented at every requested L.

2. NESTED SHELL REFINEMENT
   L1 depends monotonically on partition refinement.  v214 computes one finest
   geometric u-grid and EXACTLY aggregates adjacent fine shells to several
   coarser nested resolutions.

The question is therefore not whether L1 has the same magnitude at every
resolution.  It cannot: refinement can only increase the triangle bound.

The theorem-relevant question is whether its CUTOFF DECAY survives refinement:

    L1_N(L) -> 0 for a fixed, genuinely local partition N,

with stable negative slopes as N increases.

For each requested resolution N, v214 reports:
  * max_E L1_N slope over all L;
  * RMS_E L1_N slope;
  * last-window/holdout slope;
  * fraction of energies with negative slope;
  * worst per-energy slope;
  * final L1_N;
  * monotonicity under refinement.

It also reports individual fine-shell RMS slopes.  If most fine shells contract
and the finest-partition L1 has a robust negative prospective slope, the
absolute local-discrepancy route is strongly supported.

This is still finite-range numerical evidence, not a proof.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


def parse_float_list(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def parse_int_list(text):
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def power_slope(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)

    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    x = x[ok]
    y = y[ok]

    if len(x) < 3:
        return np.nan, np.nan

    lx = np.log(x)
    ly = np.log(y)

    c = np.polyfit(lx, ly, 1)
    pred = np.polyval(c, lx)

    den = np.sum((ly - ly.mean()) ** 2)
    r2 = (
        1.0 - np.sum((ly - pred) ** 2) / den
        if den > 0 else np.nan
    )

    return float(c[0]), float(r2)


def robust_norm_rel_diff(a, b, floor=1e-30):
    num = np.linalg.norm(a-b)
    den = max(
        np.linalg.norm(a),
        np.linalg.norm(b),
        floor,
    )
    return float(num/den)


def prime_scaled_shell_matrix(
    n,
    coeff,
    logn,
    energies,
    L,
    ratio,
    u_edges,
    chunk,
):
    shells = len(u_edges)-1
    out = np.zeros((shells, len(energies)), dtype=np.complex128)

    nf = n.astype(np.float64)
    u = nf/L

    valid = (u >= u_edges[0]) & (u <= u_edges[-1])
    idx = np.flatnonzero(valid)

    if len(idx) == 0:
        return out

    sid = np.searchsorted(
        u_edges,
        u[idx],
        side="right",
    ) - 1
    sid = np.clip(sid, 0, shells-1)

    amp = coeff[idx] * (
        np.exp(-nf[idx]/(ratio*L))
        - np.exp(-nf[idx]/L)
    )

    t = logn[idx]

    for lo in range(0, len(idx), chunk):
        hi = min(len(idx), lo+chunk)

        tt = t[lo:hi]
        aa = amp[lo:hi]
        ss = sid[lo:hi]

        phase = np.exp(
            1j * tt[:, None] * energies[None, :]
        )
        z = aa[:, None]*phase

        for k in range(len(energies)):
            re = np.bincount(
                ss,
                weights=z[:, k].real,
                minlength=shells,
            )
            im = np.bincount(
                ss,
                weights=z[:, k].imag,
                minlength=shells,
            )
            out[:, k] += re + 1j*im

    return out


def continuum_scaled_shell_matrix(
    u_edges,
    energies,
    L,
    ratio,
    nodes_per_shell,
):
    shells = len(u_edges)-1
    out = np.zeros((shells, len(energies)), dtype=np.complex128)

    gx, gw = np.polynomial.legendre.leggauss(nodes_per_shell)

    t_edges = np.log(L*u_edges)
    t_global_min = math.log(2.0)

    for j in range(shells):
        a = max(float(t_edges[j]), t_global_min)
        b = float(t_edges[j+1])

        if b <= a:
            continue

        mid = 0.5*(a+b)
        half = 0.5*(b-a)

        t = mid + half*gx
        w = half*gw
        x = np.exp(t)

        dw = (
            np.exp(-x/(ratio*L))
            - np.exp(-x/L)
        )

        base = (
            w
            * np.exp(0.5*t)
            * dw
            / t
        )

        phase = np.exp(
            1j*t[:, None]*energies[None, :]
        )

        out[j, :] = np.sum(
            base[:, None]*phase,
            axis=0,
        )

    return out


def aggregate_shells(Dfine, target_shells):
    fine_shells = Dfine.shape[0]

    if fine_shells % target_shells != 0:
        raise ValueError(
            f"fine_shells={fine_shells} not divisible by target={target_shells}"
        )

    group = fine_shells//target_shells

    return Dfine.reshape(
        target_shells,
        group,
        Dfine.shape[1],
    ).sum(axis=1)


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v212-module",
        default="rot_rh_euler_product_coupling_v212",
    )

    ap.add_argument(
        "--L-list",
        default="4000,8000,16000,32000,64000,128000,256000",
    )
    ap.add_argument("--ratio", type=float, default=2.0)

    ap.add_argument("--emin", type=float, default=10.0)
    ap.add_argument("--emax", type=float, default=80.0)
    ap.add_argument("--energy-count", type=int, default=29)
    ap.add_argument("--energy-values", default="")

    ap.add_argument(
        "--u-max",
        type=float,
        default=48.0,
        help="Scaled high cutoff; long exponential weight ~ exp(-u_max/ratio).",
    )

    ap.add_argument(
        "--finest-shells",
        type=int,
        default=640,
    )
    ap.add_argument(
        "--resolutions",
        default="40,80,160,320,640",
    )

    ap.add_argument(
        "--quad-nodes-per-shell",
        type=int,
        default=10,
    )
    ap.add_argument(
        "--quad-check-factor",
        type=int,
        default=2,
    )
    ap.add_argument(
        "--quad-norm-rel-gate",
        type=float,
        default=1e-8,
    )

    ap.add_argument(
        "--prime-chunk",
        type=int,
        default=65536,
    )

    ap.add_argument(
        "--holdout-points",
        type=int,
        default=4,
        help="Number of largest-L points used for prospective-tail slope.",
    )

    ap.add_argument(
        "--finest-all-slope-gate",
        type=float,
        default=-0.02,
    )
    ap.add_argument(
        "--finest-holdout-slope-gate",
        type=float,
        default=-0.01,
    )
    ap.add_argument(
        "--negative-energy-fraction-gate",
        type=float,
        default=0.90,
    )
    ap.add_argument(
        "--resolution-slope-spread-gate",
        type=float,
        default=0.05,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_absolute_route_refinement_v214",
    )

    args = ap.parse_args()

    v212 = importlib.import_module(args.v212_module)

    Ls = np.asarray(parse_float_list(args.L_list), dtype=float)

    if len(Ls) < max(4, args.holdout_points):
        raise RuntimeError("Not enough L values.")

    if np.any(np.diff(Ls) <= 0):
        raise RuntimeError("L-list must increase.")

    if args.energy_values.strip():
        energies = np.asarray(
            parse_float_list(args.energy_values),
            dtype=float,
        )
    else:
        energies = np.linspace(
            args.emin,
            args.emax,
            args.energy_count,
        )

    resolutions = sorted(set(parse_int_list(args.resolutions)))

    if args.finest_shells not in resolutions:
        resolutions.append(args.finest_shells)
        resolutions = sorted(resolutions)

    for N in resolutions:
        if args.finest_shells % N != 0:
            raise RuntimeError(
                f"resolution {N} must divide finest-shells {args.finest_shells}"
            )

    Lmax = float(np.max(Ls))

    # Full support for every n>=2 at every L:
    # at Lmax, n=2 corresponds to this minimum u.
    u_min = 2.0/Lmax
    u_max = args.u_max

    if u_max <= u_min:
        raise RuntimeError("u-max too small.")

    u_edges = np.geomspace(
        u_min,
        u_max,
        args.finest_shells+1,
    )

    nmax = int(math.ceil(u_max*Lmax))

    nominal_high_tail = math.exp(-u_max/args.ratio)

    print("="*200)
    print("ROT-RH v214 — FULL-SUPPORT SCALED-SHELL REFINEMENT / ABSOLUTE-ROUTE CERTIFICATION")
    print("="*200)
    print("Xi / zeta / known zeros          : NONE")
    print(f"L values                          : {Ls.tolist()}")
    print(f"energies                          : {len(energies)}")
    print(f"full-support u_min=2/Lmax         : {u_min:.12e}")
    print(f"u_max                             : {u_max:.6e}")
    print(f"finest shells                     : {args.finest_shells}")
    print(f"nested resolutions                : {resolutions}")
    print(f"nmax                              : {nmax}")
    print(f"nominal high-tail weight          : {nominal_high_tail:.6e}")
    print("="*200)

    n, exponents, coeff, primes = v212.build_prime_powers(nmax)
    logn = np.log(n.astype(np.float64))

    print(f"primes <= nmax                    : {len(primes)}")
    print(f"prime powers incl primes          : {len(n)}")

    # Storage: resolution -> [L,E]
    L1 = {
        N: np.zeros((len(Ls), len(energies)), dtype=float)
        for N in resolutions
    }

    fine_shell_rms = np.zeros(
        (len(Ls), args.finest_shells),
        dtype=float,
    )

    actual = np.zeros(
        (len(Ls), len(energies)),
        dtype=float,
    )

    quad_norm_rels = []

    L_rows = []

    for i,L in enumerate(Ls):
        P = prime_scaled_shell_matrix(
            n=n,
            coeff=coeff,
            logn=logn,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            u_edges=u_edges,
            chunk=args.prime_chunk,
        )

        M1 = continuum_scaled_shell_matrix(
            u_edges=u_edges,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            nodes_per_shell=args.quad_nodes_per_shell,
        )

        M2 = continuum_scaled_shell_matrix(
            u_edges=u_edges,
            energies=energies,
            L=float(L),
            ratio=args.ratio,
            nodes_per_shell=(
                args.quad_nodes_per_shell
                * args.quad_check_factor
            ),
        )

        qnorm = robust_norm_rel_diff(M1, M2)
        quad_norm_rels.append(qnorm)

        Dfine = P-M2

        fine_shell_rms[i, :] = np.sqrt(
            np.mean(np.abs(Dfine)**2, axis=1)
        )

        actual[i, :] = np.abs(np.sum(Dfine, axis=0))

        vals = {}

        for N in resolutions:
            DN = aggregate_shells(Dfine, N)
            L1N = np.sum(np.abs(DN), axis=0)
            L1[N][i, :] = L1N

            vals[N] = float(np.max(L1N))

        row = {
            "L": float(L),
            "quad_norm_rel": qnorm,
            "actual_max": float(np.max(actual[i, :])),
        }

        for N in resolutions:
            row[f"L1max_N{N}"] = vals[N]

        L_rows.append(row)

        compact = " ".join(
            f"N{N}={vals[N]:.3e}"
            for N in resolutions
        )

        print(
            f"L={L:10.0f} "
            f"{compact} "
            f"Amax={np.max(actual[i,:]):.3e} "
            f"qNorm={qnorm:.3e}"
        )

    # Resolution diagnostics.
    resolution_rows = []

    hp = args.holdout_points
    hold_L = Ls[-hp:]

    for N in resolutions:
        max_series = np.max(L1[N], axis=1)
        rms_series = np.sqrt(np.mean(L1[N]**2, axis=1))

        pmax, rmax = power_slope(Ls, max_series)
        prms, rrms = power_slope(Ls, rms_series)

        phold, rhold = power_slope(
            hold_L,
            max_series[-hp:],
        )

        energy_slopes = []
        energy_hold_slopes = []

        for k in range(len(energies)):
            p,_ = power_slope(Ls, L1[N][:,k])
            q,_ = power_slope(
                hold_L,
                L1[N][-hp:,k],
            )
            energy_slopes.append(p)
            energy_hold_slopes.append(q)

        energy_slopes = np.asarray(energy_slopes,float)
        energy_hold_slopes = np.asarray(energy_hold_slopes,float)

        resolution_rows.append({
            "shells": N,
            "L1_max_slope_all": pmax,
            "L1_max_log_R2_all": rmax,
            "L1_RMS_slope_all": prms,
            "L1_RMS_log_R2_all": rrms,
            "L1_max_slope_holdout": phold,
            "L1_max_log_R2_holdout": rhold,
            "negative_energy_fraction_all": float(
                np.mean(energy_slopes < 0)
            ),
            "negative_energy_fraction_holdout": float(
                np.mean(energy_hold_slopes < 0)
            ),
            "worst_energy_slope_all": float(
                np.nanmax(energy_slopes)
            ),
            "median_energy_slope_all": float(
                np.nanmedian(energy_slopes)
            ),
            "worst_energy_slope_holdout": float(
                np.nanmax(energy_hold_slopes)
            ),
            "median_energy_slope_holdout": float(
                np.nanmedian(energy_hold_slopes)
            ),
            "final_L1_max": float(max_series[-1]),
            "final_L1_RMS": float(rms_series[-1]),
        })

    rdf = pd.DataFrame(resolution_rows)

    # Fine-shell slopes.
    shell_rows = []
    centers = np.sqrt(u_edges[:-1]*u_edges[1:])

    for j,uc in enumerate(centers):
        p,r2 = power_slope(
            Ls,
            fine_shell_rms[:,j],
        )

        ph,rh = power_slope(
            hold_L,
            fine_shell_rms[-hp:,j],
        )

        shell_rows.append({
            "shell": j,
            "u_center": float(uc),
            "u_lo": float(u_edges[j]),
            "u_hi": float(u_edges[j+1]),
            "RMS_slope_all": p,
            "RMS_log_R2_all": r2,
            "RMS_slope_holdout": ph,
            "RMS_log_R2_holdout": rh,
            "final_RMS": float(fine_shell_rms[-1,j]),
        })

    sdf = pd.DataFrame(shell_rows)

    active_shell = sdf["final_RMS"].to_numpy(float) > (
        1e-8 * max(float(sdf["final_RMS"].max()), 1e-300)
    )

    fine_negative_fraction = float(
        np.mean(
            sdf.loc[
                active_shell,
                "RMS_slope_all"
            ].to_numpy(float) < 0
        )
    ) if np.any(active_shell) else np.nan

    fine_hold_negative_fraction = float(
        np.mean(
            sdf.loc[
                active_shell,
                "RMS_slope_holdout"
            ].to_numpy(float) < 0
        )
    ) if np.any(active_shell) else np.nan

    # Check refinement monotonicity numerically at every L,E.
    refinement_failures = 0

    for a,b in zip(resolutions[:-1], resolutions[1:]):
        # Finer L1 must be >= coarser L1 up to float noise.
        if np.any(L1[b] + 1e-12 < L1[a]):
            refinement_failures += 1

    finest_row = rdf[rdf["shells"] == args.finest_shells].iloc[0]

    max_slopes = rdf["L1_max_slope_all"].to_numpy(float)
    slope_spread = float(np.max(max_slopes)-np.min(max_slopes))

    quad_pass = bool(
        max(quad_norm_rels) <= args.quad_norm_rel_gate
    )

    finest_all_pass = bool(
        finest_row["L1_max_slope_all"]
        <= args.finest_all_slope_gate
        and finest_row["negative_energy_fraction_all"]
        >= args.negative_energy_fraction_gate
    )

    finest_holdout_pass = bool(
        finest_row["L1_max_slope_holdout"]
        <= args.finest_holdout_slope_gate
        and finest_row["negative_energy_fraction_holdout"]
        >= args.negative_energy_fraction_gate
    )

    resolution_stable = bool(
        slope_spread <= args.resolution_slope_spread_gate
        and refinement_failures == 0
    )

    if (
        quad_pass
        and finest_all_pass
        and finest_holdout_pass
        and resolution_stable
    ):
        verdict = "ABSOLUTE_LOCAL_DISCREPANCY_ROUTE_REFINEMENT_STRONGLY_SUPPORTED"
    elif (
        quad_pass
        and finest_all_pass
        and resolution_stable
    ):
        verdict = "ABSOLUTE_ROUTE_SUPPORTED_HOLDOUT_PARTIAL"
    elif quad_pass:
        verdict = "ABSOLUTE_ROUTE_REFINEMENT_UNRESOLVED"
    else:
        verdict = "NUMERICAL_QUADRATURE_UNRESOLVED"

    ldf = pd.DataFrame(L_rows)

    ldf.to_csv(args.prefix+"_L_VALUES.csv",index=False)
    rdf.to_csv(args.prefix+"_RESOLUTIONS.csv",index=False)
    sdf.to_csv(args.prefix+"_FINE_SHELLS.csv",index=False)

    summary = {
        "version":214,
        "firewall":"Xi / zeta / known zeros: NONE",
        "L_values":Ls.tolist(),
        "energies":energies.tolist(),
        "u_min_full_support":u_min,
        "u_max":u_max,
        "finest_shells":args.finest_shells,
        "resolutions":resolutions,
        "nmax":nmax,
        "nominal_high_tail_weight":nominal_high_tail,
        "max_continuum_quadrature_norm_relative_discrepancy":
            float(max(quad_norm_rels)),
        "refinement_monotonicity_failures":refinement_failures,
        "resolution_L1_max_slope_spread":slope_spread,
        "finest":{
            k: (
                float(v)
                if isinstance(v,(float,np.floating))
                else int(v)
            )
            for k,v in finest_row.to_dict().items()
        },
        "fine_active_shell_negative_fraction_all":
            fine_negative_fraction,
        "fine_active_shell_negative_fraction_holdout":
            fine_hold_negative_fraction,
        "quad_pass":quad_pass,
        "finest_all_pass":finest_all_pass,
        "finest_holdout_pass":finest_holdout_pass,
        "resolution_stable":resolution_stable,
        "verdict":verdict,
        "interpretation":(
            "A strong pass means the absolute L1 shell bound still contracts "
            "when the omitted low-u region is restored and the scaled shell "
            "partition is refined substantially. This supports, but does not "
            "prove, an analytic route based on bounding a finite collection "
            "of locally centered prime-minus-continuum discrepancies."
        ),
    }

    Path(args.prefix+"_SUMMARY.json").write_text(
        json.dumps(summary,indent=2,allow_nan=True),
        encoding="utf-8",
    )

    print()
    print("="*200)
    print("REFINEMENT CERTIFICATION")
    for _,r in rdf.iterrows():
        print(
            f"N={int(r['shells']):4d} "
            f"pAll={r['L1_max_slope_all']:.6f} "
            f"R2={r['L1_max_log_R2_all']:.6f} "
            f"pHold={r['L1_max_slope_holdout']:.6f} "
            f"negAll={r['negative_energy_fraction_all']:.3f} "
            f"negHold={r['negative_energy_fraction_holdout']:.3f} "
            f"final={r['final_L1_max']:.6e}"
        )

    print()
    print(f"quadrature norm-relative max      : {max(quad_norm_rels):.6e}")
    print(f"refinement monotonicity failures  : {refinement_failures}")
    print(f"resolution slope spread           : {slope_spread:.6e}")
    print(f"fine active shell neg fraction    : {fine_negative_fraction:.6f}")
    print(f"fine holdout shell neg fraction   : {fine_hold_negative_fraction:.6f}")
    print(f"VERDICT                           : {verdict}")
    print("="*200)


if __name__ == "__main__":
    main()
