#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v260 — OPERATOR ABEL-TAIL / TRUNCATION-CIRCULARITY AUDIT
===============================================================

Purpose
-------
The v102.1 arithmetic phase uses the exponentially regulated centered prime
transform with a finite arithmetic cutoff

    N_L = c L,

where the standard computational choice is c=18.

Earlier v254-v256 introduced the stronger global prefix object

    A_E(N)
      = sum_{n=2}^N q_n n^{iE}/(sqrt(n) log n),

q_2=Lambda(2)-2, q_n=Lambda(n)-1 for n>=3.

If

    sup_N |A_E(N)| <= C,

then discrete Abel summation gives, for the full exponential transform

    B_E,L(infinity)
      = sum_{n>=2} q_n e^{-n/L} n^{iE}/(sqrt(n)log n),

the tail estimate

    |B(infinity)-B(cL)| <= 2 C exp(-c).

Crucially this is UNIFORM IN L.

v260 has two roles:

1. numerical truncation audit
   Compare c=18 against deeper c=36 and c=72 at fixed zero-free arithmetic
   anchors and several L values.

2. theorem/circularity audit
   Record that:
     * prefix boundedness implies a uniformly controlled c=18 -> full-Abel tail;
     * a uniformly bounded FULL Abel transform at one critical anchor is itself
       RH-implying by Mellin continuation:
           Gamma(delta) D(s0+delta)
             = integral_0^infinity B_E(t) t^(delta-1) dt,
       Re(delta)>0,
       where t=1/L and s0=1/2-iE.

Thus the prefix theorem is NOT the only possible proof route. One may instead
prove the operator's Abel-smoothed bound directly. But that direct full-Abel
bound is still an RH-strength analytic statement.

No Xi, zeta values, or actual zeta zero ordinates are used by the numerical
part of this script.

Version: 260
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 260
EPS = np.finfo(float).eps


def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def centered_weighted_sum(
    energies,
    L,
    cutoff_factor,
    Nmax_available,
    numbers,
    lambdas,
    integer_chunk,
):
    """
    Exact finite centered complex transform

      sum_{2<=n<=floor(cL)}
        q_n exp(-n/L) n^{iE}/(sqrt(n)log n),

    q_2=Lambda(2)-2, q_n=Lambda(n)-1 for n>=3.
    """
    energies = np.asarray(energies, float)
    N = min(
        int(math.floor(float(cutoff_factor) * float(L))),
        int(Nmax_available),
    )

    out = np.zeros(len(energies), dtype=np.complex128)

    chunk = max(4096, int(integer_chunk))
    start = 2

    while start <= N:
        stop = min(start + chunk - 1, N)

        n_int = np.arange(start, stop + 1, dtype=int)
        n = n_int.astype(float)

        q = -np.ones(len(n), float)

        left = int(np.searchsorted(numbers, start, side="left"))
        right = int(np.searchsorted(numbers, stop, side="right"))

        if right > left:
            idx = numbers[left:right] - start
            q[idx] += lambdas[left:right]

        if start <= 2 <= stop:
            q[2 - start] -= 1.0

        logn = np.log(n)
        coeff = (
            q
            * np.exp(-n / float(L))
            / (np.sqrt(n) * logn)
        )

        phase = np.exp(1j * np.outer(energies, logn))
        out += phase @ coeff

        start = stop + 1

    return out, N


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--v256-anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument(
        "--v254-summary",
        default="rot_rh_global_centered_mangoldt_prefix_v254_SUMMARY.json",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--k-values",
        default="4608,7168,8192",
    )
    ap.add_argument(
        "--L-values",
        default="4000,8000,16000,32000,64000,128000,256000",
    )
    ap.add_argument(
        "--cutoff-factors",
        default="18,36,72",
    )

    ap.add_argument("--integer-chunk", type=int, default=131072)
    ap.add_argument(
        "--factor18-to-deep-tol",
        type=float,
        default=2e-6,
        help="Engineering diagnostic gate, not theorem constant.",
    )
    ap.add_argument(
        "--conditional-tail-slack",
        type=float,
        default=1.10,
        help="Allowance relative to 2*C*exp(-18).",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_operator_abel_tail_audit_v260",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()

    ks = parse_ints(args.k_values)
    L_values = parse_ints(args.L_values)
    factors = parse_floats(args.cutoff_factors)

    if 18.0 not in factors:
        raise ValueError("--cutoff-factors must include 18")
    if len(factors) < 2:
        raise ValueError("Need at least two cutoff factors")
    if args.integer_chunk < 4096:
        raise ValueError("--integer-chunk must be >=4096")

    factors = sorted(set(float(x) for x in factors))
    deepest = max(factors)

    anchors = pd.read_csv(args.v256_anchors)
    need = {"k", "E_anchor"}
    miss = need - set(anchors.columns)
    if miss:
        raise KeyError(f"v256 anchors missing {sorted(miss)}")

    anchors["k"] = anchors["k"].astype(int)
    chosen = anchors[anchors["k"].isin(ks)].sort_values("k").copy()

    if sorted(chosen["k"].tolist()) != sorted(ks):
        missing = sorted(set(ks) - set(chosen["k"].tolist()))
        raise RuntimeError(f"Missing anchors for k={missing}")

    energies = chosen["E_anchor"].to_numpy(float)
    ks = chosen["k"].astype(int).tolist()

    v254 = load_json(args.v254_summary)
    if int(v254.get("version", -1)) != 254:
        raise ValueError("Expected v254 summary")

    C = float(v254["prospective_bound"]["frozen_global_C"])
    conditional_tail_18 = 2.0 * C * math.exp(-18.0)

    Nmax = int(
        math.ceil(float(deepest) * float(max(L_values)))
    )

    base = importlib.import_module(args.base_module)

    print("=" * 194)
    print("ROT-RH v260 — OPERATOR ABEL-TAIL / TRUNCATION-CIRCULARITY AUDIT")
    print("=" * 194)
    print("Xi / zeta / actual zero data       : NONE")
    print(f"anchors                             : {ks}")
    print(f"L values                            : {L_values}")
    print(f"cutoff factors                      : {factors}")
    print(f"largest arithmetic N               : {Nmax}")
    print(f"frozen v254 C                       : {C:.12e}")
    print(
        "conditional 18L->infinity bound    : "
        f"{conditional_tail_18:.12e}"
    )
    print("=" * 194)

    print(f"[1] Shared Mangoldt sieve through N={Nmax}")
    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(numbers, int)
    lambdas = np.asarray(lambdas, float)

    rows = []

    print("[2] Exact centered Abel sums at multiple cutoff factors")
    for L in tqdm(L_values, desc="Abel cutoff audit", unit="L"):
        sums = {}
        Ns = {}

        for c in factors:
            z, N = centered_weighted_sum(
                energies=energies,
                L=int(L),
                cutoff_factor=float(c),
                Nmax_available=Nmax,
                numbers=numbers,
                lambdas=lambdas,
                integer_chunk=int(args.integer_chunk),
            )
            sums[float(c)] = z
            Ns[float(c)] = int(N)

        z18 = sums[18.0]
        zdeep = sums[deepest]

        for i, k in enumerate(ks):
            deep_diff = zdeep[i] - z18[i]

            rows.append({
                "k": int(k),
                "E_anchor": float(energies[i]),
                "L": int(L),
                "factor_18_N": int(Ns[18.0]),
                "deep_factor": float(deepest),
                "deep_N": int(Ns[deepest]),
                "B18_real": float(np.real(z18[i])),
                "B18_imag": float(np.imag(z18[i])),
                "B18_abs": float(abs(z18[i])),
                "Bdeep_real": float(np.real(zdeep[i])),
                "Bdeep_imag": float(np.imag(zdeep[i])),
                "Bdeep_abs": float(abs(zdeep[i])),
                "deep_minus_18_real": float(np.real(deep_diff)),
                "deep_minus_18_imag": float(np.imag(deep_diff)),
                "deep_minus_18_abs": float(abs(deep_diff)),
                "conditional_full_tail_bound_from_C": float(
                    conditional_tail_18
                ),
                "deep_difference_over_conditional_bound": float(
                    abs(deep_diff)
                    / max(conditional_tail_18, EPS)
                ),
            })

            for c0, c1 in zip(factors[:-1], factors[1:]):
                dz = sums[c1][i] - sums[c0][i]
                rows[-1][
                    f"factor_{c0:g}_to_{c1:g}_increment_abs"
                ] = float(abs(dz))

    df = pd.DataFrame(rows)

    max_deep_diff = float(df["deep_minus_18_abs"].max())
    max_ratio_conditional = float(
        df["deep_difference_over_conditional_bound"].max()
    )

    # Per-mode summaries.
    mode_rows = []
    for k, g in df.groupby("k", sort=True):
        mode_rows.append({
            "k": int(k),
            "maximum_18_to_deep_difference": float(
                g["deep_minus_18_abs"].max()
            ),
            "median_18_to_deep_difference": float(
                g["deep_minus_18_abs"].median()
            ),
            "maximum_difference_over_conditional_bound": float(
                g["deep_difference_over_conditional_bound"].max()
            ),
            "maximum_B18_abs": float(g["B18_abs"].max()),
            "maximum_Bdeep_abs": float(g["Bdeep_abs"].max()),
        })
    modes = pd.DataFrame(mode_rows)

    gates = {
        "factor18_numerically_close_to_deep_cutoff": bool(
            max_deep_diff <= args.factor18_to_deep_tol
        ),
        "deep_difference_below_conditional_prefix_tail_bound": bool(
            max_ratio_conditional
            <= float(args.conditional_tail_slack)
        ),
    }
    failed = [name for name, ok in gates.items() if not ok]

    if gates["factor18_numerically_close_to_deep_cutoff"]:
        mechanism = "FACTOR18_ALREADY_NUMERICALLY_FULL_ABEL_ON_TESTED_PANEL"
    else:
        mechanism = "FACTOR18_TRUNCATION_REQUIRES_FURTHER_TAIL_CONTROL"

    verdict = (
        "OPERATOR_ABEL_TAIL_AUDIT_VERIFIED"
        if not failed
        else
        "OPERATOR_ABEL_TAIL_AUDIT_GATE_FAILURE"
    )

    prefix = args.prefix
    detail_path = Path(prefix + "_DETAIL.csv")
    modes_path = Path(prefix + "_MODES.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM_AUDIT.md")

    df.to_csv(detail_path, index=False)
    modes.to_csv(modes_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "actual_zero_ordinates_used": False,
        },
        "panel": {
            "k_values": ks,
            "L_values": L_values,
            "cutoff_factors": factors,
            "Nmax": Nmax,
        },
        "frozen_prefix_packet": {
            "C": C,
            "conditional_factor18_full_tail_bound": conditional_tail_18,
            "formula": "2*C*exp(-18)",
        },
        "numerical": {
            "maximum_factor18_to_deep_difference": max_deep_diff,
            "maximum_difference_over_conditional_bound": (
                max_ratio_conditional
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "analytic_audit": {
            "prefix_to_tail": (
                "If sup_N|A_E(N)|<=C, then for w(n)=exp(-n/L), "
                "|sum_{n>cL} a_n w(n)| <= 2 C exp(-c), uniformly in L."
            ),
            "full_Abel_definition": (
                "B_E(t)=sum a_n exp(-n t), t=1/L."
            ),
            "Mellin_bridge": (
                "Gamma(delta) D(s0+delta)="
                "integral_0^infinity B_E(t)t^(delta-1)dt."
            ),
            "classification": (
                "A uniform full-Abel bound as t->0 at one critical anchor "
                "is RH-implying by analytic continuation of D into Re(s)>1/2."
            ),
            "operator_consequence": (
                "The raw global-prefix theorem is sufficient but not necessary. "
                "A direct proof of the operator's Abel-smoothed cutoff bound, "
                "plus rigorous fixed-factor tail control, is the weaker and "
                "more operator-native target."
            ),
        },
        "proof_status": (
            "OPEN. Numerical agreement of factor 18 with deeper cutoffs does "
            "not prove the infinite tail estimate. The conditional 2Ce^-18 "
            "bound depends on the still-open global prefix theorem. A direct "
            "operator-native tail argument could avoid that stronger hypothesis."
        ),
        "runtime_seconds": time.perf_counter() - started,
    }

    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_text = f"""# ROT-RH v260 — operator Abel-tail theorem audit

## Implemented cutoff

The arithmetic phase uses the finite exponential regulator

`B_E,L^(c)=sum_(n<=cL) q_n exp(-n/L)n^(iE)/(sqrt(n)log n)`,

with the standard computational choice `c=18`.

## Conditional prefix-to-tail bridge

If

`sup_N |A_E(N)| <= C`,

then discrete Abel summation gives

`|B_E,L^(infinity)-B_E,L^(c)| <= 2 C exp(-c)`.

For the frozen v254 constant

`C={C:.12g}`

and `c=18`, this gives

`2 C exp(-18) = {conditional_tail_18:.12e}`,

uniformly in `L`.

## More operator-native target

The prefix theorem is stronger than necessary.

Define the full Abel transform

`B_E(t)=sum_n a_n exp(-nt)`, `t=1/L`.

If `B_E(t)` is uniformly bounded as `t->0+`, then for `Re(delta)>0`

`Gamma(delta)D(s0+delta)=integral_0^infinity B_E(t)t^(delta-1)dt`

defines an analytic continuation of the centered Dirichlet series to
`Re(s)>1/2`.

By the v257 Dirichlet-series audit, this excludes zeta zeros to the right of
the critical line and is therefore RH-implying.

## Consequence

For the Hilbert-Polya program, the right theorem target is not necessarily the
raw global-prefix bound. It may be enough to prove directly:

1. a uniform bound for the operator-native Abel-smoothed arithmetic defect;
2. a rigorous fixed-factor truncation tail estimate;
3. the secant transversality already isolated numerically by v250.

That route is weaker than proving bounded raw prefixes, but it is still an
RH-strength analytic theorem.
"""
    theorem_path.write_text(theorem_text, encoding="utf-8")

    print()
    print("=" * 194)
    print("ROT-RH v260 — OPERATOR ABEL-TAIL SUMMARY")
    print("=" * 194)

    for r in mode_rows:
        print(
            f"k={r['k']:>5d} "
            f"max|Bdeep-B18|={r['maximum_18_to_deep_difference']:.3e} "
            f"median={r['median_18_to_deep_difference']:.3e} "
            f"max/condBound={r['maximum_difference_over_conditional_bound']:.3f}"
        )

    print()
    print("AGGREGATE")
    print("-" * 194)
    print(
        "conditional 18L -> infinity bound  : "
        f"{conditional_tail_18:.12e}"
    )
    print(
        "maximum observed 18 -> deep diff   : "
        f"{max_deep_diff:.12e}"
    )
    print(
        "maximum observed / conditional     : "
        f"{max_ratio_conditional:.6f}"
    )
    print(f"MECHANISM                           : {mechanism}")

    print()
    print("=" * 194)
    print("FAILED GATES                        :", failed if failed else "none")
    print("VERDICT                             :", verdict)
    print(
        "PROOF VERDICT                       : OPEN — "
        "DIRECT OPERATOR ABEL-BOUND / TAIL THEOREM"
    )
    print("=" * 194)
    print("Files written:")
    for path in (
        detail_path,
        modes_path,
        summary_path,
        theorem_path,
    ):
        print(" ", path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
