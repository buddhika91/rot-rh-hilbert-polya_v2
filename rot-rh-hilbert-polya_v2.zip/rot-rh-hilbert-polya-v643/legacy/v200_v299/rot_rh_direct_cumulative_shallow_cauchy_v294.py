#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v294 — DIRECT CUMULATIVE SHALLOW ABEL / DYADIC CAUCHY AUDIT
===================================================================

Purpose
-------
v291 rigorously closed the sigma=3 DEEP Abel tail beyond

    J(L) = ceil(log_2 L),

leaving the phase-sensitive shallow block

    S_shallow(L)
      = sum_{0 <= j < J(L)} A_L(R^j F0).

v292 showed that absolute summability of the INDIVIDUAL phase-prefix layer
norms is too strong.  v293 then tested three-layer packets and, if that
packet envelope fails, the correct next object is the WHOLE cumulative
shallow block.

This script therefore does NOT take norms before summing layers.

Exact cumulative identity
-------------------------
For the exact smooth-preconditioned Selberg fixed point

    x = F0 + R x,

we have for every integer m >= 0

    x - R^m x
      = sum_{0 <= j < m} R^j F0.

At dyadic Abel scale

    L_m = 2^m,

J(L_m)=m exactly, hence

    S_m
      := S_shallow(2^m)
       = A_(2^m)(x - R^m x).

This identity captures cancellation across ALL shallow layers at once.

The central new quantity is the dyadic increment

    Delta_m = S_m - S_(m-1).

If one can prove

    |Delta_m| <= B q^(m-m0),   0 < q < 1,

for every sufficiently large m, then

    sum_m |Delta_m| < infinity,

so the dyadic shallow sequence is Cauchy and therefore bounded/convergent.
That is substantially closer to the required shallow bridge than absolute
packet summability.

What this finite script tests
-----------------------------
1. Exact one-step Selberg/preconditioned fixed-point identity x=F0+Rx.
2. Direct cumulative shallow state x-R^m x; no layerwise absolute values.
3. Dyadic shallow Abel values S_m at L=2^m.
4. Two arithmetic truncations per L to test numerical cutoff stability.
5. Unweighted phase-prefix norm of x-R^m x as a stronger Abel diagnostic.
6. DEVELOPMENT-only geometric envelope for |Delta_m|.
7. Prospective HOLDOUT of that frozen increment envelope.
8. DEVELOPMENT-only frozen constants for |S_m| and the shallow prefix norm,
   followed by prospective HOLDOUT tests.
9. Optional comparison with the already-certified v291 deep-tail bound.

Interpretation
--------------
PASS:
    Prospectively supports a direct cumulative shallow Cauchy mechanism.
    It identifies the next analytic theorem: prove the all-m increment
    estimate, then extend from dyadic L to all L.

FAIL:
    Do not retune the same holdout.  The direct dyadic Cauchy law is not
    established by this panel.  Inspect the signed increments and prefix
    table before choosing a different analytic decomposition.

Important proof status
----------------------
A finite numerical PASS is NOT a proof of the all-m/all-L shallow theorem,
cutoff independence, the Fredholm-Xi identity, or RH.

No Xi, zeta values, zeta'/zeta values, or known zero ordinates are used.

Dependencies:
    numpy, pandas, tqdm, numba

Version: 294
"""

from __future__ import annotations

import argparse
import gc
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 294


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    # L=2^m.  m=19 with check-tail-factor=24 reaches N=12,582,912.
    ap.add_argument("--m-start", type=int, default=10)
    ap.add_argument("--m-end", type=int, default=19)
    ap.add_argument("--development-m-max", type=int, default=17)

    # Two finite arithmetic cutoffs are evaluated for each Abel scale.
    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--check-tail-factor", type=float, default=24.0)

    # DEVELOPMENT-only increment envelope.
    ap.add_argument("--minimum-envelope-m", type=int, default=12)
    ap.add_argument("--increment-envelope-safety", type=float, default=1.35)
    ap.add_argument("--minimum-increment-r2", type=float, default=0.60)
    ap.add_argument("--maximum-increment-q", type=float, default=0.95)

    # Direct boundedness / prefix holdout safety factors.
    ap.add_argument("--shallow-bound-safety", type=float, default=1.35)
    ap.add_argument("--prefix-bound-safety", type=float, default=1.35)

    # Numerical truncation stability.
    ap.add_argument("--cutoff-abs-tol", type=float, default=2e-7)
    ap.add_argument("--cutoff-rel-tol", type=float, default=2e-6)

    ap.add_argument("--support-tol", type=float, default=1e-15)
    ap.add_argument("--identity-tol", type=float, default=3e-10)

    ap.add_argument(
        "--v291-summary",
        default="rot_rh_sigma3_deep_abel_tail_v291_SUMMARY.json",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_direct_cumulative_shallow_cauchy_v294",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    if args.m_start < 2:
        raise ValueError("--m-start must be >=2")
    if args.m_end <= args.m_start:
        raise ValueError("--m-end must exceed --m-start")
    if not (args.m_start <= args.development_m_max < args.m_end):
        raise ValueError(
            "--development-m-max must lie in [m-start, m-end)"
        )
    if args.check_tail_factor <= args.tail_factor:
        raise ValueError(
            "--check-tail-factor must exceed --tail-factor"
        )
    if not (0.0 < args.maximum_increment_q < 1.0):
        raise ValueError("--maximum-increment-q must lie in (0,1)")

    try:
        from numba import njit
    except Exception as exc:
        raise RuntimeError(
            "v294 requires numba.\n"
            "Install with:\n\n"
            "    pip install numba\n\n"
            f"Import error: {exc}"
        )

    # ------------------------------------------------------------------
    # Fixed dyadic design
    # ------------------------------------------------------------------

    m_values = list(range(int(args.m_start), int(args.m_end) + 1))
    development = [
        m for m in m_values
        if m <= int(args.development_m_max)
    ]
    holdout = [
        m for m in m_values
        if m > int(args.development_m_max)
    ]

    L_values = {m: int(2 ** m) for m in m_values}
    N_main = {
        m: int(math.ceil(float(args.tail_factor) * L_values[m]))
        for m in m_values
    }
    N_check = {
        m: int(math.ceil(float(args.check_tail_factor) * L_values[m]))
        for m in m_values
    }
    Nmax = max(N_check.values())

    # ------------------------------------------------------------------
    # Zero-free arithmetic anchor
    # ------------------------------------------------------------------

    anchors = pd.read_csv(args.anchors)
    if not {"k", "E_anchor"}.issubset(anchors.columns):
        raise KeyError("anchors file must contain k,E_anchor")

    anchors["k"] = anchors["k"].astype(int)
    hit = anchors[anchors["k"] == int(args.anchor_k)]

    if len(hit) != 1:
        raise RuntimeError(
            f"Expected exactly one anchor k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])
    base = importlib.import_module(args.base_module)

    # ------------------------------------------------------------------
    # Numba arithmetic / transfer helpers
    # ------------------------------------------------------------------

    @njit(cache=True)
    def build_spf(N):
        spf = np.arange(N + 1, dtype=np.int32)
        spf[0] = 0
        if N >= 1:
            spf[1] = 1

        r = int(math.sqrt(N))
        for p in range(2, r + 1):
            if spf[p] != p:
                continue
            for n in range(p * p, N + 1, p):
                if spf[n] == n:
                    spf[n] = p
        return spf

    @njit(cache=True)
    def selberg_tau_g(spf):
        N = len(spf) - 1
        tau = np.ones(N + 1, dtype=np.int32)
        omega = np.zeros(N + 1, dtype=np.uint8)
        exponent = np.zeros(N + 1, dtype=np.uint8)
        distinct_log_sum = np.zeros(N + 1, dtype=np.float64)
        g = np.zeros(N + 1, dtype=np.float64)

        for n in range(2, N + 1):
            p = int(spf[n])
            m = n // p
            lp = math.log(p)

            if m > 1 and m % p == 0:
                old_e = int(exponent[m])
                new_e = old_e + 1

                exponent[n] = new_e
                omega[n] = omega[m]
                distinct_log_sum[n] = distinct_log_sum[m]

                tau[n] = (
                    tau[m]
                    // (old_e + 1)
                    * (new_e + 1)
                )

                if omega[n] == 1:
                    g[n] = (
                        (2 * new_e - 1)
                        * lp
                        * lp
                    )
                else:
                    g[n] = g[m]
            else:
                exponent[n] = 1
                omega[n] = omega[m] + 1
                distinct_log_sum[n] = (
                    distinct_log_sum[m] + lp
                )
                tau[n] = tau[m] * 2

                if omega[m] == 0:
                    g[n] = lp * lp
                elif omega[m] == 1:
                    g[n] = (
                        2.0
                        * lp
                        * distinct_log_sum[m]
                    )
                else:
                    g[n] = 0.0

        return tau, g

    @njit(cache=True)
    def apply_Klambda_from(u, lam, logs, N, d_start):
        out = np.zeros(N + 1, dtype=np.float64)
        lo = d_start
        if lo < 2:
            lo = 2

        for d in range(lo, N // 2 + 1):
            ud = u[d]
            if ud == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                lk = lam[k]
                if lk == 0.0:
                    continue

                n = k * d
                out[n] -= (
                    (lk / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * ud
                )

        return out

    @njit(cache=True)
    def solve_I_minus_Kb_from(v, logs, N, d_start):
        y = v.copy()
        lo = d_start
        if lo < 2:
            lo = 2

        for d in range(lo, N // 2 + 1):
            yd = y[d]
            if yd == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                n = k * d
                y[n] -= (
                    (1.0 / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * yd
                )

        return y

    @njit(cache=True)
    def apply_R_from(u, lam, logs, N, d_start):
        tmp = apply_Klambda_from(
            u,
            lam,
            logs,
            N,
            d_start,
        )

        # K_Lambda doubles support; (I-K_b)^(-1) does not lower it.
        out_start = 2 * d_start
        if out_start < 2:
            out_start = 2

        return solve_I_minus_Kb_from(
            tmp,
            logs,
            N,
            out_start,
        )

    @njit(cache=True)
    def abel_two_cutoffs(
        u,
        phase_re,
        phase_im,
        L,
        N1,
        N2,
    ):
        sr = 0.0
        si = 0.0
        a1r = 0.0
        a1i = 0.0

        for n in range(2, N2 + 1):
            un = u[n]
            if un != 0.0:
                w = math.exp(-float(n) / L)
                sr += un * w * phase_re[n]
                si += un * w * phase_im[n]

            if n == N1:
                a1r = sr
                a1i = si

        return a1r, a1i, sr, si

    @njit(cache=True)
    def abel_diff_two_cutoffs(
        x,
        tail,
        phase_re,
        phase_im,
        L,
        N1,
        N2,
    ):
        sr = 0.0
        si = 0.0
        a1r = 0.0
        a1i = 0.0

        for n in range(2, N2 + 1):
            un = x[n] - tail[n]
            if un != 0.0:
                w = math.exp(-float(n) / L)
                sr += un * w * phase_re[n]
                si += un * w * phase_im[n]

            if n == N1:
                a1r = sr
                a1i = si

        return a1r, a1i, sr, si

    @njit(cache=True)
    def prefix_sup_diff_two_cutoffs(
        x,
        tail,
        phase_re,
        phase_im,
        N1,
        N2,
    ):
        zr = 0.0
        zi = 0.0
        smax = 0.0
        p1 = 0.0

        for n in range(2, N2 + 1):
            un = x[n] - tail[n]
            if un != 0.0:
                zr += un * phase_re[n]
                zi += un * phase_im[n]

            a = math.sqrt(zr * zr + zi * zi)
            if a > smax:
                smax = a

            if n == N1:
                p1 = smax

        return p1, smax

    @njit(cache=True)
    def first_support_from(u, tol, start):
        N = len(u) - 1
        lo = start
        if lo < 2:
            lo = 2

        for n in range(lo, N + 1):
            if abs(u[n]) > tol:
                return n
        return -1

    # ------------------------------------------------------------------
    # Banner
    # ------------------------------------------------------------------

    print("=" * 214)
    print("ROT-RH v294 — DIRECT CUMULATIVE SHALLOW ABEL / DYADIC CAUCHY AUDIT")
    print("=" * 214)
    print("Xi / zeta / known-zero data         : NONE")
    print(f"anchor k                             : {args.anchor_k}")
    print(f"anchor E                             : {E:.15f}")
    print(f"dyadic m range                       : {args.m_start}..{args.m_end}")
    print(f"DEVELOPMENT m                        : {development}")
    print(f"NEW QUANTITY HOLDOUT m               : {holdout}")
    print(f"main/check tail factors              : {args.tail_factor} / {args.check_tail_factor}")
    print(f"maximum arithmetic N                 : {Nmax:,}")
    print("=" * 214)

    # ------------------------------------------------------------------
    # Arithmetic and exact physical fixed point
    # ------------------------------------------------------------------

    print(f"[1] Arithmetic through N={Nmax:,}")

    numbers, lambdas, _ = base.mangoldt_terms(Nmax)
    numbers = np.asarray(numbers, dtype=np.int64)
    lambdas = np.asarray(lambdas, dtype=np.float64)

    lam = np.zeros(Nmax + 1, dtype=np.float64)
    lam[numbers] = lambdas
    del numbers, lambdas

    logs = np.zeros(Nmax + 1, dtype=np.float64)
    nf = np.arange(2, Nmax + 1, dtype=np.float64)
    logs[2:] = np.log(nf)

    phase_re = np.ones(Nmax + 1, dtype=np.float64)
    phase_im = np.zeros(Nmax + 1, dtype=np.float64)

    theta = np.remainder(
        E * logs[2:],
        2.0 * math.pi,
    )
    phase_re[2:] = np.cos(theta)
    phase_im[2:] = np.sin(theta)
    del theta

    print("[2] Exact Selberg forcing / preconditioned fixed point")

    spf = build_spf(Nmax)
    tau, g = selberg_tau_g(spf)
    del spf
    gc.collect()

    sqrt_n = np.ones(Nmax + 1, dtype=np.float64)
    sqrt_n[2:] = np.sqrt(nf)

    F = np.zeros(Nmax + 1, dtype=np.float64)
    F[2:] = (
        (
            g[2:]
            - logs[2:]
            - (
                tau[2:].astype(np.float64)
                - 2.0
            )
        )
        / (
            sqrt_n[2:]
            * logs[2:]
            * logs[2:]
        )
    )

    x_true = np.zeros(Nmax + 1, dtype=np.float64)
    x_true[2:] = (
        (lam[2:] - 1.0)
        / (
            sqrt_n[2:]
            * logs[2:]
        )
    )

    del tau, g, sqrt_n, nf
    gc.collect()

    # JIT warmup on a tiny range.
    warmN = min(Nmax, 64)
    _ = solve_I_minus_Kb_from(
        F[:warmN + 1],
        logs[:warmN + 1],
        warmN,
        2,
    )

    F0 = solve_I_minus_Kb_from(
        F,
        logs,
        Nmax,
        2,
    )
    del F
    gc.collect()

    print("[3] One-step fixed-point identity x = F0 + R x")

    Rx = apply_R_from(
        x_true,
        lam,
        logs,
        Nmax,
        2,
    )

    fixed_point_error = float(
        np.max(
            np.abs(
                x_true[2:]
                - (
                    F0[2:]
                    + Rx[2:]
                )
            )
        )
    )

    del F0
    gc.collect()

    # ------------------------------------------------------------------
    # Optional v291 certified deep bound
    # ------------------------------------------------------------------

    v291 = load_json(args.v291_summary)
    v291_ok = False
    v291_C = float("nan")
    v291_delta = float("nan")

    if v291 is not None and int(v291.get("version", -1)) == 291:
        deep = v291.get("deep_tail", {})
        try:
            v291_C = float(deep["constant_upper"])
            v291_delta = float(deep["decay_exponent_lower_proxy"])
            v291_ok = (
                np.isfinite(v291_C)
                and np.isfinite(v291_delta)
                and v291_C >= 0.0
                and v291_delta > 0.0
            )
        except Exception:
            v291_ok = False

    # ------------------------------------------------------------------
    # Direct cumulative shallow states
    # ------------------------------------------------------------------

    print("[4] Direct cumulative shallow states x - R^m x")

    rows = []
    support_rows = []
    support_pass_all = True

    # m=0 tail is x; m=1 tail is Rx already computed above.
    tail = Rx
    tail_support_lower = 4

    pbar = tqdm(
        range(1, int(args.m_end) + 1),
        desc="R-depth / shallow block",
        unit="depth",
    )

    for m in pbar:
        if m > 1:
            tail = apply_R_from(
                tail,
                lam,
                logs,
                Nmax,
                tail_support_lower,
            )
            tail_support_lower *= 2

        # Only evaluate target m values.
        if m < int(args.m_start):
            continue

        L = float(L_values[m])
        n1 = int(N_main[m])
        n2 = int(N_check[m])

        # Direct whole shallow block A_L(x - R^m x).
        s1r, s1i, s2r, s2i = abel_diff_two_cutoffs(
            x_true,
            tail,
            phase_re,
            phase_im,
            L,
            n1,
            n2,
        )

        # Full and tail terms, to verify the cumulative identity numerically.
        f1r, f1i, f2r, f2i = abel_two_cutoffs(
            x_true,
            phase_re,
            phase_im,
            L,
            n1,
            n2,
        )

        t1r, t1i, t2r, t2i = abel_two_cutoffs(
            tail,
            phase_re,
            phase_im,
            L,
            n1,
            n2,
        )

        identity_main = math.hypot(
            s1r - (f1r - t1r),
            s1i - (f1i - t1i),
        )
        identity_check = math.hypot(
            s2r - (f2r - t2r),
            s2i - (f2i - t2i),
        )

        s1abs = math.hypot(s1r, s1i)
        s2abs = math.hypot(s2r, s2i)
        f2abs = math.hypot(f2r, f2i)
        t2abs = math.hypot(t2r, t2i)

        cutoff_delta = math.hypot(
            s2r - s1r,
            s2i - s1i,
        )
        cutoff_tol = (
            float(args.cutoff_abs_tol)
            + float(args.cutoff_rel_tol)
            * max(1.0, s2abs)
        )
        cutoff_pass = bool(
            cutoff_delta <= cutoff_tol
        )

        p1, p2 = prefix_sup_diff_two_cutoffs(
            x_true,
            tail,
            phase_re,
            phase_im,
            n1,
            n2,
        )

        expected_support = int(2 ** (m + 1))
        actual_support = first_support_from(
            tail,
            float(args.support_tol),
            min(expected_support, Nmax),
        )

        support_pass = bool(
            actual_support < 0
            or actual_support >= expected_support
        )
        support_pass_all = (
            support_pass_all
            and support_pass
        )

        deep_bound = (
            v291_C * (L ** (-v291_delta))
            if v291_ok
            else float("nan")
        )

        region = (
            "DEVELOPMENT"
            if m <= int(args.development_m_max)
            else "HOLDOUT"
        )

        rows.append({
            "m": int(m),
            "L": int(L_values[m]),
            "J_L": int(m),
            "region": region,
            "N_main": n1,
            "N_check": n2,
            "shallow_main_re": float(s1r),
            "shallow_main_im": float(s1i),
            "shallow_main_abs": float(s1abs),
            "shallow_check_re": float(s2r),
            "shallow_check_im": float(s2i),
            "shallow_check_abs": float(s2abs),
            "cutoff_delta_abs": float(cutoff_delta),
            "cutoff_tolerance": float(cutoff_tol),
            "cutoff_pass": bool(cutoff_pass),
            "full_check_abs": float(f2abs),
            "deep_numeric_check_abs": float(t2abs),
            "v291_deep_bound": float(deep_bound),
            "deep_over_v291_bound": float(
                t2abs / max(deep_bound, 1e-300)
                if np.isfinite(deep_bound)
                else float("nan")
            ),
            "shallow_prefix_sup_main": float(p1),
            "shallow_prefix_sup_check": float(p2),
            "abel_over_prefix_check": float(
                s2abs / max(p2, 1e-300)
            ),
            "cumulative_identity_main_error": float(identity_main),
            "cumulative_identity_check_error": float(identity_check),
        })

        support_rows.append({
            "m": int(m),
            "L": int(L_values[m]),
            "region": region,
            "expected_tail_support_min": expected_support,
            "actual_tail_support_min": int(actual_support),
            "support_pass": bool(support_pass),
        })

    shallow_df = pd.DataFrame(rows).sort_values("m").reset_index(drop=True)
    support_df = pd.DataFrame(support_rows).sort_values("m").reset_index(drop=True)

    if len(shallow_df) != len(m_values):
        raise RuntimeError(
            "Internal error: not all requested dyadic m values were evaluated"
        )

    max_cumulative_identity_error = float(
        max(
            shallow_df["cumulative_identity_main_error"].max(),
            shallow_df["cumulative_identity_check_error"].max(),
        )
    )

    # ------------------------------------------------------------------
    # Dyadic increments of the WHOLE shallow block
    # ------------------------------------------------------------------

    print("[5] Dyadic increments Delta_m = S_m - S_(m-1)")

    increment_rows = []

    by_m = {
        int(r.m): r
        for r in shallow_df.itertuples(index=False)
    }

    for m in range(int(args.m_start) + 1, int(args.m_end) + 1):
        a = by_m[m - 1]
        b = by_m[m]

        dr = float(
            b.shallow_check_re
            - a.shallow_check_re
        )
        di = float(
            b.shallow_check_im
            - a.shallow_check_im
        )
        da = float(math.hypot(dr, di))

        region = (
            "DEVELOPMENT"
            if m <= int(args.development_m_max)
            else "HOLDOUT"
        )

        increment_rows.append({
            "m_prev": int(m - 1),
            "m": int(m),
            "L_prev": int(2 ** (m - 1)),
            "L": int(2 ** m),
            "region": region,
            "delta_re": dr,
            "delta_im": di,
            "delta_abs": da,
            "shallow_prev_abs": float(
                a.shallow_check_abs
            ),
            "shallow_abs": float(
                b.shallow_check_abs
            ),
        })

    increments_df = pd.DataFrame(increment_rows)

    # ------------------------------------------------------------------
    # Freeze DEVELOPMENT-only increment envelope
    # ------------------------------------------------------------------

    print("[6] Freeze DEVELOPMENT dyadic-increment envelope")

    m0 = int(args.minimum_envelope_m)

    fit_df = increments_df[
        (increments_df["region"] == "DEVELOPMENT")
        & (increments_df["m"] >= m0)
        & (increments_df["delta_abs"] > 1e-300)
    ].copy()

    if len(fit_df) >= 3:
        xfit = (
            fit_df["m"].to_numpy(dtype=float)
            - float(m0)
        )
        yfit = np.log(
            fit_df["delta_abs"].to_numpy(dtype=float)
        )

        slope, intercept = np.polyfit(
            xfit,
            yfit,
            1,
        )
        pred = intercept + slope * xfit

        ss_res = float(
            np.sum((yfit - pred) ** 2)
        )
        ss_tot = float(
            np.sum(
                (yfit - np.mean(yfit)) ** 2
            )
        )
        r2 = (
            1.0 - ss_res / ss_tot
            if ss_tot > 0.0
            else 1.0
        )

        q = float(math.exp(slope))

        if q > 0.0 and np.isfinite(q):
            raw_B = float(
                np.max(
                    fit_df["delta_abs"].to_numpy(dtype=float)
                    / (
                        q
                        ** (
                            fit_df["m"].to_numpy(dtype=float)
                            - float(m0)
                        )
                    )
                )
            )
            Bsafe = (
                float(args.increment_envelope_safety)
                * raw_B
            )
        else:
            Bsafe = float("inf")
    else:
        q = float("inf")
        r2 = float("nan")
        Bsafe = float("inf")

    eta = (
        -math.log(q, 2.0)
        if np.isfinite(q) and q > 0.0
        else float("nan")
    )

    increment_model_valid = bool(
        np.isfinite(q)
        and 0.0 < q < float(args.maximum_increment_q)
        and np.isfinite(r2)
        and r2 >= float(args.minimum_increment_r2)
        and np.isfinite(Bsafe)
    )

    # ------------------------------------------------------------------
    # Prospective HOLDOUT of frozen increment envelope
    # ------------------------------------------------------------------

    print("[7] Frozen dyadic-increment HOLDOUT")

    hold_rows = []
    hold_increment_pass = True
    min_increment_margin = float("inf")

    for row in increments_df[
        increments_df["region"] == "HOLDOUT"
    ].itertuples(index=False):
        if increment_model_valid:
            bound = (
                Bsafe
                * q ** (int(row.m) - m0)
            )
            passed = bool(
                float(row.delta_abs) <= bound
            )
            margin = float(
                bound
                / max(float(row.delta_abs), 1e-300)
            )
        else:
            bound = float("nan")
            passed = False
            margin = 0.0

        hold_increment_pass = (
            hold_increment_pass
            and passed
        )
        min_increment_margin = min(
            min_increment_margin,
            margin,
        )

        hold_rows.append({
            "m": int(row.m),
            "L": int(row.L),
            "delta_abs": float(row.delta_abs),
            "frozen_increment_bound": float(bound),
            "margin": float(margin),
            "pass": bool(passed),
        })

    hold_df = pd.DataFrame(hold_rows)

    # ------------------------------------------------------------------
    # Direct shallow and prefix boundedness holdouts
    # ------------------------------------------------------------------

    print("[8] Frozen direct shallow / prefix bounds")

    dev_shallow = shallow_df[
        shallow_df["region"] == "DEVELOPMENT"
    ]
    ho_shallow = shallow_df[
        shallow_df["region"] == "HOLDOUT"
    ]

    frozen_shallow_C = float(
        args.shallow_bound_safety
        * dev_shallow["shallow_check_abs"].max()
    )
    frozen_prefix_C = float(
        args.prefix_bound_safety
        * dev_shallow["shallow_prefix_sup_check"].max()
    )

    shallow_holdout_pass = bool(
        len(ho_shallow)
        and np.all(
            ho_shallow["shallow_check_abs"].to_numpy(dtype=float)
            <= frozen_shallow_C
        )
    )
    prefix_holdout_pass = bool(
        len(ho_shallow)
        and np.all(
            ho_shallow[
                "shallow_prefix_sup_check"
            ].to_numpy(dtype=float)
            <= frozen_prefix_C
        )
    )

    minimum_shallow_margin = (
        float(
            np.min(
                frozen_shallow_C
                / np.maximum(
                    ho_shallow[
                        "shallow_check_abs"
                    ].to_numpy(dtype=float),
                    1e-300,
                )
            )
        )
        if len(ho_shallow)
        else 0.0
    )

    minimum_prefix_margin = (
        float(
            np.min(
                frozen_prefix_C
                / np.maximum(
                    ho_shallow[
                        "shallow_prefix_sup_check"
                    ].to_numpy(dtype=float),
                    1e-300,
                )
            )
        )
        if len(ho_shallow)
        else 0.0
    )

    cutoff_stability_pass = bool(
        shallow_df["cutoff_pass"].all()
    )

    identity_pass = bool(
        fixed_point_error <= float(args.identity_tol)
        and max_cumulative_identity_error
        <= float(args.identity_tol)
    )

    # Candidate all-future dyadic Cauchy remainder, conditional on an
    # all-m theorem extending the fitted envelope.
    candidate_tail_after_mend = (
        Bsafe
        * q ** (
            (int(args.m_end) + 1) - m0
        )
        / (1.0 - q)
        if increment_model_valid
        else float("inf")
    )

    # ------------------------------------------------------------------
    # Gates / verdict
    # ------------------------------------------------------------------

    gates = {
        "exact_preconditioned_fixed_point": bool(
            fixed_point_error
            <= float(args.identity_tol)
        ),
        "exact_cumulative_shallow_identity": bool(
            max_cumulative_identity_error
            <= float(args.identity_tol)
        ),
        "tail_support_doubling": bool(
            support_pass_all
        ),
        "finite_cutoff_stability": (
            cutoff_stability_pass
        ),
        "development_increment_model_valid": (
            increment_model_valid
        ),
        "holdout_dyadic_increment_envelope": (
            hold_increment_pass
        ),
        "holdout_direct_shallow_bound": (
            shallow_holdout_pass
        ),
        "holdout_shallow_prefix_bound": (
            prefix_holdout_pass
        ),
    }

    failed = [
        name
        for name, ok in gates.items()
        if not ok
    ]

    if not failed:
        mechanism = (
            "DIRECT_CUMULATIVE_SHALLOW_DYADIC_CAUCHY_PROSPECTIVELY_SUPPORTED"
        )
        verdict = (
            "DIRECT_SHALLOW_CAUCHY_AUDIT_VERIFIED"
        )
        next_theorem = (
            "Prove for all sufficiently large dyadic m that "
            "|S_m-S_(m-1)| <= B q^(m-m0) with the frozen q<1, using the "
            "exact identity S_m=A_(2^m)(x-R^m x). Then prove an interpolation "
            "bound for 2^m <= L <= 2^(m+1). Together with the already-certified "
            "v291 deep tail, that would close the one-anchor shallow Abel bridge."
        )
    else:
        mechanism = (
            "DIRECT_CUMULATIVE_SHALLOW_DYADIC_CAUCHY_NOT_ESTABLISHED"
        )
        verdict = (
            "DIRECT_SHALLOW_CAUCHY_AUDIT_GATE_FAILURE"
        )
        next_theorem = (
            "Do not retune this holdout. Inspect the signed dyadic increments, "
            "cutoff differences, and shallow-prefix table. A failure of the "
            "geometric increment envelope means the whole shallow block may be "
            "bounded without converging geometrically, or a different exact "
            "summation-by-parts/renormalization identity is required."
        )

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------

    out = args.prefix

    shallow_path = Path(
        out + "_SHALLOW.csv"
    )
    increment_path = Path(
        out + "_INCREMENTS.csv"
    )
    support_path = Path(
        out + "_SUPPORT.csv"
    )
    holdout_path = Path(
        out + "_HOLDOUT.csv"
    )
    summary_path = Path(
        out + "_SUMMARY.json"
    )
    theorem_path = Path(
        out + "_NEXT_THEOREM.md"
    )

    shallow_df.to_csv(
        shallow_path,
        index=False,
    )
    increments_df.to_csv(
        increment_path,
        index=False,
    )
    support_df.to_csv(
        support_path,
        index=False,
    )
    hold_df.to_csv(
        holdout_path,
        index=False,
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "zeta_log_derivative_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "exact_identity": {
            "fixed_point": "x=F0+R x",
            "cumulative_shallow": (
                "x-R^m x=sum_(0<=j<m)R^jF0"
            ),
            "dyadic_observable": (
                "S_m=A_(2^m)(x-R^m x)"
            ),
            "one_step_fixed_point_error": (
                fixed_point_error
            ),
            "max_cumulative_observable_identity_error": (
                max_cumulative_identity_error
            ),
        },
        "prospective_design": {
            "m_values": m_values,
            "development_m": development,
            "holdout_m": holdout,
            "tail_factor": float(
                args.tail_factor
            ),
            "check_tail_factor": float(
                args.check_tail_factor
            ),
            "maximum_arithmetic_N": int(Nmax),
            "note": (
                "The direct cumulative shallow/dyadic-increment quantity is new "
                "after v293. The arithmetic range itself is not claimed to be "
                "globally unseen."
            ),
        },
        "development_increment_envelope": {
            "m0": m0,
            "q": q,
            "eta_power_of_L": eta,
            "R2": r2,
            "Bsafe": Bsafe,
            "model_valid": (
                increment_model_valid
            ),
            "candidate_future_dyadic_tail_after_m_end": (
                candidate_tail_after_mend
            ),
            "candidate_tail_note": (
                "Conditional only: valid if the fitted envelope is later proved "
                "for every future dyadic m."
            ),
        },
        "direct_bounds": {
            "frozen_shallow_C": (
                frozen_shallow_C
            ),
            "frozen_prefix_C": (
                frozen_prefix_C
            ),
            "holdout_shallow_pass": (
                shallow_holdout_pass
            ),
            "minimum_shallow_margin": (
                minimum_shallow_margin
            ),
            "holdout_prefix_pass": (
                prefix_holdout_pass
            ),
            "minimum_prefix_margin": (
                minimum_prefix_margin
            ),
        },
        "holdout_increment": {
            "pass": hold_increment_pass,
            "minimum_margin": (
                min_increment_margin
            ),
        },
        "v291_reference": {
            "summary_loaded": bool(v291_ok),
            "deep_constant_upper": (
                v291_C
            ),
            "deep_decay_exponent": (
                v291_delta
            ),
            "note": (
                "Numerical truncated deep values are diagnostics only; the v291 "
                "full infinite-tail certificate is the rigorous statement."
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN. A finite PASS supplies prospective evidence for the direct "
            "cumulative shallow Cauchy mechanism. It does not prove the required "
            "all-m/all-L theorem, cutoff independence, Fredholm-Xi, or RH."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v294 — direct cumulative shallow Cauchy target

The exact fixed-point identity is

`x = F0 + R x`.

Therefore

`x - R^m x = sum_(0<=j<m) R^j F0`.

At the dyadic Abel scale `L=2^m`, `J(L)=m`, so the complete shallow block is

`S_m = A_(2^m)(x - R^m x)`.

This is the key difference from v292/v293: **all shallow layers are added
before taking the absolute value**.

Define

`Delta_m = S_m - S_(m-1)`.

The DEVELOPMENT-only candidate envelope is

`|Delta_m| <= B q^(m-m0)`

with

`m0 = {m0}`

`q = {q}`

`eta = -log_2(q) = {eta}`

`R2 = {r2}`

`B = {Bsafe}`.

If an analytic proof establishes `0<q<1` for every sufficiently large `m`,
then the dyadic shallow block is Cauchy because

`sum_m |Delta_m| < infinity`.

The remaining non-dyadic step would be an interpolation estimate for

`2^m <= L <= 2^(m+1)`.

v291 already controls the complementary deep tail.

Prospective mechanism:

`{mechanism}`

{next_theorem}

**Proof status:** OPEN.  The finite audit is not itself an all-scale theorem.
""",
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Console summary
    # ------------------------------------------------------------------

    print()
    print("=" * 214)
    print("ROT-RH v294 — DIRECT CUMULATIVE SHALLOW SUMMARY")
    print("=" * 214)

    print("EXACT STRUCTURE")
    print("-" * 214)
    print(
        "max x-(F0+Rx) error                 : "
        f"{fixed_point_error:.3e}"
    )
    print(
        "max cumulative observable identity  : "
        f"{max_cumulative_identity_error:.3e}"
    )
    print(
        "tail support doubling               : "
        f"{support_pass_all}"
    )

    print()
    print("DIRECT SHALLOW BLOCK")
    print("-" * 214)

    for row in shallow_df.itertuples(index=False):
        print(
            f"{row.region[:4]:4s} "
            f"m={int(row.m):>2d} "
            f"L={int(row.L):>7d} "
            f"|S|={float(row.shallow_check_abs):.9e} "
            f"prefix={float(row.shallow_prefix_sup_check):.9e} "
            f"cutΔ={float(row.cutoff_delta_abs):.3e} "
            f"deep={float(row.deep_numeric_check_abs):.3e}"
        )

    print()
    print("DYADIC INCREMENTS")
    print("-" * 214)

    for row in increments_df.itertuples(index=False):
        print(
            f"{row.region[:4]:4s} "
            f"m={int(row.m):>2d} "
            f"|Delta|={float(row.delta_abs):.9e}"
        )

    print()
    print("FROZEN DEVELOPMENT INCREMENT ENVELOPE")
    print("-" * 214)
    print(
        "minimum envelope m                  : "
        f"{m0}"
    )
    print(
        "dyadic q                            : "
        f"{q:.9f}"
    )
    print(
        "equivalent L exponent eta           : "
        f"{eta:.9f}"
    )
    print(
        "fit R2                              : "
        f"{r2:.9f}"
    )
    print(
        "Bsafe                               : "
        f"{Bsafe:.9e}"
    )
    print(
        "increment model valid               : "
        f"{increment_model_valid}"
    )
    print(
        "holdout increment pass              : "
        f"{hold_increment_pass}"
    )
    print(
        "minimum increment margin            : "
        f"{min_increment_margin:.6f}"
    )

    print()
    print("DIRECT BOUNDEDNESS HOLDOUT")
    print("-" * 214)
    print(
        "frozen shallow C                    : "
        f"{frozen_shallow_C:.9e}"
    )
    print(
        "holdout shallow pass                : "
        f"{shallow_holdout_pass}"
    )
    print(
        "minimum shallow margin              : "
        f"{minimum_shallow_margin:.6f}"
    )
    print(
        "frozen prefix C                     : "
        f"{frozen_prefix_C:.9e}"
    )
    print(
        "holdout prefix pass                 : "
        f"{prefix_holdout_pass}"
    )
    print(
        "minimum prefix margin               : "
        f"{minimum_prefix_margin:.6f}"
    )
    print(
        "finite cutoff stability             : "
        f"{cutoff_stability_pass}"
    )

    if v291_ok:
        print()
        print("v291 CERTIFIED DEEP-TAIL REFERENCE")
        print("-" * 214)
        print(
            "C_deep                              : "
            f"{v291_C:.12e}"
        )
        print(
            "delta                               : "
            f"{v291_delta:.12f}"
        )

    print()
    print(
        "MECHANISM                            :",
        mechanism,
    )
    print("=" * 214)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print(
        "VERDICT                              :",
        verdict,
    )
    print(
        "PROOF VERDICT                        : OPEN — "
        "DIRECT CUMULATIVE SHALLOW ALL-m/ALL-L THEOREM"
    )
    print("=" * 214)

    print("Files written:")
    print(" ", shallow_path)
    print(" ", increment_path)
    print(" ", support_path)
    print(" ", holdout_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
