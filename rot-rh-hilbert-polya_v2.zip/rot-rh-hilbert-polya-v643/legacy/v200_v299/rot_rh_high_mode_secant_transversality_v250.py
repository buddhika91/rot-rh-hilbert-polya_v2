#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v250 — TAYLOR-ENCLOSED HIGH-MODE ENDPOINT SECANT TRANSVERSALITY
======================================================================

Purpose
-------
v249 reduced uniform high-mode cutoff displacement to the exact two-endpoint
identity

    (E_k(M)-E_k(L0)) D*_{k}(L0,M)
      = -[F_M(E_k(L0))-F_L0(E_k(L0))].

The two theorem factors are:

  A. frozen endpoint defect boundedness;
  B. a uniform positive endpoint secant slope.

v250 attacks the easier factor B.

For every prospective high-mode pair from v249 it continuously encloses

    F'_M(E)

on the whole interval joining E_k(L0) and E_k(M), using the v229 Taylor
enclosure machinery:

    F'(E) >=
      f0 - guard0
      - (|f1|+guard1) r
      - 1/2 (|f2|+guard2) r^2
      - M3 r^3/6
      - omitted_derivative_tail.

Here M3 is an explicit fourth-derivative majorant built from:
  * Hurwitz-zeta control of the Archimedean theta term;
  * l1 prime and counterterm frequency moments;
  * an explicit E1 analytic-continuation derivative bound.

If the continuous floor is positive, then by the mean value theorem

    D* >= inf_interval F'_M > 0.

This is a finite prospective certificate, NOT an all-k/all-M proof.  It is
designed to determine whether secant transversality is a routine analytic
factor, leaving the frozen critical PNT endpoint defect as the deep arithmetic
barrier.

No Xi, zeta values, known zero ordinates, or root solves are used.

Version: 250
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 250
EPS = np.finfo(float).eps


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument(
        "--v249-pairs",
        default="rot_rh_direct_endpoint_secant_v249_PAIRS.csv",
    )
    ap.add_argument(
        "--v229-module",
        default="rot_rh_taylor_enclosed_cutoff_independence_v229",
    )
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--segment-samples", type=int, default=17)
    ap.add_argument("--point-chunk", type=int, default=64)
    ap.add_argument("--term-chunk", type=int, default=20000)
    ap.add_argument("--interval-padding-fraction", type=float, default=0.05)
    ap.add_argument("--interval-padding-absolute", type=float, default=1e-10)
    ap.add_argument("--mp-dps", type=int, default=70)
    ap.add_argument("--trig-abs-error", type=float, default=1e-12)
    ap.add_argument("--roundoff-factor", type=float, default=32.0)

    ap.add_argument(
        "--center-consistency-tol",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--taylor-vs-sampled-tol",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--secant-floor-consistency-tol",
        type=float,
        default=2e-8,
    )
    ap.add_argument(
        "--minimum-safe-fprime",
        type=float,
        default=0.25,
        help="Prospective numerical gate only; not the theorem constant.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_high_mode_secant_transversality_v250",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    if args.segment_samples < 3:
        raise ValueError("--segment-samples must be >=3")
    if args.point_chunk < 1:
        raise ValueError("--point-chunk must be >=1")
    if args.term_chunk < 128:
        raise ValueError("--term-chunk must be >=128")
    if args.interval_padding_fraction < 0:
        raise ValueError("--interval-padding-fraction must be >=0")
    if args.interval_padding_absolute < 0:
        raise ValueError("--interval-padding-absolute must be >=0")

    pairs = pd.read_csv(args.v249_pairs)
    need = {
        "k", "L0", "M", "E0", "EM",
        "deltaE", "secant_Dstar",
        "abs_secant_Dstar",
        "frozen_phase_defect",
    }
    miss = need - set(pairs.columns)
    if miss:
        raise KeyError(f"v249 pairs missing {sorted(miss)}")

    for c in ("k", "L0", "M"):
        pairs[c] = pairs[c].astype(int)

    pairs = pairs.sort_values(["M", "k"]).reset_index(drop=True)

    if pairs.empty:
        raise RuntimeError("v249 pair table is empty")

    # We expect one fixed reference cutoff.
    L0_values = sorted(pairs["L0"].unique().tolist())
    if len(L0_values) != 1:
        raise RuntimeError(
            f"Expected one reference cutoff, found {L0_values}"
        )
    L0 = int(L0_values[0])

    v229 = importlib.import_module(args.v229_module)
    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)

    required_v229 = [
        "build_phase_closed_tail",
        "derivative_F_tail_bound",
        "taylor_center_data",
        "eval_chunked",
        "mode_segment_points",
    ]
    for name in required_v229:
        if not hasattr(v229, name):
            raise AttributeError(
                f"{args.v229_module} is missing required helper {name}"
            )

    # taylor_center_data reads these attributes from its args object.
    targs = SimpleNamespace(
        term_chunk=int(args.term_chunk),
        trig_abs_error=float(args.trig_abs_error),
        roundoff_factor=float(args.roundoff_factor),
        mp_dps=int(args.mp_dps),
    )

    endpoint_rows = []
    mode_rows = []

    Ms = sorted(pairs["M"].unique().tolist())

    print("=" * 184)
    print(
        "ROT-RH v250 — TAYLOR-ENCLOSED HIGH-MODE "
        "ENDPOINT SECANT TRANSVERSALITY"
    )
    print("=" * 184)
    print("Xi / zeta / known-zero data        : NONE")
    print("root solves                         : NONE")
    print(f"reference cutoff                    : {L0}")
    print(f"endpoint cutoffs                    : {Ms}")
    print(
        "derivative-floor method             : "
        "CONTINUOUS TAYLOR ENCLOSURE"
    )
    print("=" * 184)

    outer = tqdm(Ms, desc="endpoint cutoffs", unit="M")
    for M in outer:
        g = pairs[pairs["M"] == int(M)].sort_values("k").copy()

        phase = v229.build_phase_closed_tail(
            v102,
            base,
            int(M),
            float(args.tail_factor),
            int(args.counter_q),
        )

        E0 = g["E0"].to_numpy(float)
        EM = g["EM"].to_numpy(float)

        centers = 0.5 * (E0 + EM)
        half_motion = 0.5 * np.abs(EM - E0)
        radii = (
            half_motion
            * (1.0 + float(args.interval_padding_fraction))
            + float(args.interval_padding_absolute)
        )
        left_edges = np.maximum(7.0, centers - radii)

        taylor = v229.taylor_center_data(
            phase,
            centers=centers,
            interval_left=left_edges,
            args=targs,
        )

        direct_center = v229.eval_chunked(
            phase,
            "Fprime",
            centers,
            int(args.point_chunk),
        )
        center_err = np.abs(
            direct_center - np.asarray(taylor["f0"], float)
        )

        deriv_tail = float(
            v229.derivative_F_tail_bound(phase)
        )

        inner = tqdm(
            range(len(g)),
            desc=f"M={M} secants",
            unit="mode",
            leave=False,
        )

        for i in inner:
            row = g.iloc[i]
            k = int(row["k"])
            Ea = float(row["E0"])
            Eb = float(row["EM"])
            Dstar = float(row["secant_Dstar"])

            f0 = float(taylor["f0"][i])
            f1 = float(taylor["f1"][i])
            f2 = float(taylor["f2"][i])
            guard0 = float(taylor["guard0"][i])
            guard1 = float(taylor["guard1"][i])
            guard2 = float(taylor["guard2"][i])
            M3 = float(taylor["M3"][i])
            radius = float(radii[i])

            truncated_floor = (
                f0
                - guard0
                - (abs(f1) + guard1) * radius
                - 0.5 * (abs(f2) + guard2) * radius ** 2
                - (M3 / 6.0) * radius ** 3
            )
            safe_floor = truncated_floor - deriv_tail

            seg = v229.mode_segment_points(
                Ea,
                Eb,
                samples=int(args.segment_samples),
                min_width=max(
                    2.0 * float(args.interval_padding_absolute),
                    2e-5,
                ),
            )
            sampled = v229.eval_chunked(
                phase,
                "Fprime",
                seg,
                int(args.point_chunk),
            )
            sampled_min = float(np.min(sampled))
            sampled_proxy = sampled_min - deriv_tail

            # A positive interval floor implies a positive secant.
            secant_margin_over_floor = (
                Dstar - safe_floor
            )

            endpoint_rows.append({
                "k": k,
                "L0": L0,
                "M": int(M),
                "E0": Ea,
                "EM": Eb,
                "abs_deltaE": abs(Eb - Ea),
                "secant_Dstar": Dstar,
                "abs_secant_Dstar": abs(Dstar),
                "frozen_phase_defect": float(
                    row["frozen_phase_defect"]
                ),
                "center": float(centers[i]),
                "radius": radius,
                "left_edge": float(left_edges[i]),
                "Fprime_center_direct": float(direct_center[i]),
                "Fprime_center_taylor": f0,
                "center_reconstruction_error": float(center_err[i]),
                "Fprime_first_derivative_center": f1,
                "Fprime_second_derivative_center": f2,
                "Fprime_fourth_majorant": M3,
                "guard0": guard0,
                "guard1": guard1,
                "guard2": guard2,
                "omitted_derivative_tail": deriv_tail,
                "truncated_taylor_floor": truncated_floor,
                "safe_min_Fprime": safe_floor,
                "sampled_min_Fprime": sampled_min,
                "sampled_true_proxy": sampled_proxy,
                "safe_floor_over_sampled_proxy": float(
                    safe_floor / max(sampled_proxy, EPS)
                ),
                "secant_minus_safe_floor": secant_margin_over_floor,
                "safe_floor_positive": bool(safe_floor > 0.0),
                "safe_floor_gate_pass": bool(
                    safe_floor >= args.minimum_safe_fprime
                ),
                "center_consistency_pass": bool(
                    center_err[i]
                    <= args.center_consistency_tol
                ),
                "taylor_below_sampled_pass": bool(
                    safe_floor
                    <= sampled_proxy + args.taylor_vs_sampled_tol
                ),
                "floor_below_secant_pass": bool(
                    safe_floor
                    <= Dstar + args.secant_floor_consistency_tol
                ),
            })

    df = pd.DataFrame(endpoint_rows)

    if df.empty:
        raise RuntimeError("No endpoint secant rows were produced")

    for k, g in df.groupby("k", sort=True):
        mode_rows.append({
            "k": int(k),
            "endpoint_pairs": int(len(g)),
            "minimum_secant_Dstar": float(
                g["secant_Dstar"].min()
            ),
            "minimum_safe_Fprime": float(
                g["safe_min_Fprime"].min()
            ),
            "minimum_sampled_Fprime": float(
                g["sampled_min_Fprime"].min()
            ),
            "maximum_abs_deltaE": float(
                g["abs_deltaE"].max()
            ),
            "maximum_frozen_defect": float(
                np.max(np.abs(
                    g["frozen_phase_defect"].to_numpy(float)
                ))
            ),
            "minimum_secant_margin_over_floor": float(
                g["secant_minus_safe_floor"].min()
            ),
        })

    modes = pd.DataFrame(mode_rows)

    min_safe = float(df["safe_min_Fprime"].min())
    min_sampled = float(df["sampled_min_Fprime"].min())
    min_secant = float(df["secant_Dstar"].min())
    max_center_err = float(
        df["center_reconstruction_error"].max()
    )
    min_floor_sampled_gap = float(
        (df["sampled_true_proxy"] - df["safe_min_Fprime"]).min()
    )
    min_secant_floor_gap = float(
        df["secant_minus_safe_floor"].min()
    )

    gates = {
        "all_safe_derivative_floors_positive": bool(
            (df["safe_min_Fprime"] > 0.0).all()
        ),
        "all_safe_derivative_floors_pass_gate": bool(
            df["safe_floor_gate_pass"].all()
        ),
        "all_center_reconstructions_consistent": bool(
            df["center_consistency_pass"].all()
        ),
        "all_taylor_floors_below_sampled_proxy": bool(
            df["taylor_below_sampled_pass"].all()
        ),
        "all_taylor_floors_below_secants": bool(
            df["floor_below_secant_pass"].all()
        ),
        "all_direct_secants_positive": bool(
            (df["secant_Dstar"] > 0.0).all()
        ),
    }
    failed = [name for name, ok in gates.items() if not ok]

    verdict = (
        "HIGH_MODE_SECANT_TRANSVERSALITY_TAYLOR_ENCLOSED"
        if not failed
        else
        "HIGH_MODE_SECANT_TRANSVERSALITY_GATE_FAILURE"
    )

    prefix = args.prefix
    detail_path = Path(prefix + "_DETAIL.csv")
    modes_path = Path(prefix + "_MODES.csv")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_THEOREM_REDUCTION.md")

    df.to_csv(detail_path, index=False)
    modes.to_csv(modes_path, index=False)

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "root_solves": False,
        },
        "method": {
            "source": "v229 Taylor-enclosed Fprime machinery",
            "continuous_interval_enclosure": True,
            "formal_outward_rounded_interval_arithmetic": False,
            "diagnostic_sampling_used_for_floor": False,
            "sampling_role": "consistency diagnostic only",
        },
        "panel": {
            "reference_cutoff": L0,
            "endpoint_cutoffs": Ms,
            "k_values": sorted(df["k"].unique().astype(int).tolist()),
        },
        "aggregate": {
            "minimum_safe_Fprime": min_safe,
            "minimum_sampled_Fprime": min_sampled,
            "minimum_direct_secant": min_secant,
            "maximum_center_reconstruction_error": max_center_err,
            "minimum_sampled_proxy_minus_safe_floor": (
                min_floor_sampled_gap
            ),
            "minimum_secant_minus_safe_floor": (
                min_secant_floor_gap
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "analytic_reduction": {
            "finite_panel_statement": (
                "For every tested direct endpoint interval, "
                "F'_M(E) has a positive continuous Taylor-enclosed floor, "
                "hence the endpoint secant D* is positive by MVT."
            ),
            "remaining_all_tail_theorem": (
                "Promote the positive derivative floor to all "
                "M>=L0 and k>=K0. Given the large finite-panel margin, "
                "this is separated from the critical frozen PNT endpoint "
                "bound but is not yet analytically closed."
            ),
        },
        "proof_status": (
            "NOT A COMPLETE PROOF. The continuous finite-panel Taylor "
            "enclosure uses explicit derivative majorants but ordinary "
            "floating arithmetic with inflated guards rather than formal "
            "outward-rounded intervals, and it does not cover all k,M."
        ),
    }
    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    theorem_text = "\n".join([
        "# ROT-RH v250 — endpoint secant transversality reduction",
        "",
        "For each endpoint pair `(L0,M,k)`, v250 encloses `F'_M(E)`",
        "continuously on the full interval joining `E_k(L0)` and `E_k(M)`.",
        "",
        "If the enclosed floor is `d0>0`, then by the mean value theorem",
        "",
        "`D*_{k}(L0,M) >= d0 > 0`.",
        "",
        "Thus the direct v249 displacement identity",
        "",
        "`(E_k(M)-E_k(L0)) D* = -DeltaF_frozen`",
        "",
        "reduces high-mode displacement to the frozen endpoint defect once",
        "a uniform all-tail derivative floor is proved.",
        "",
        "The finite-panel calculation is a theorem diagnostic, not the",
        "all-k/all-M theorem itself.",
    ]) + "\n"
    theorem_path.write_text(theorem_text, encoding="utf-8")

    print()
    print("=" * 184)
    print("ROT-RH v250 — HIGH-MODE SECANT TRANSVERSALITY SUMMARY")
    print("=" * 184)
    for r in mode_rows:
        print(
            f"k={r['k']:>4d} "
            f"minD*={r['minimum_secant_Dstar']:.6e} "
            f"minSafeF'={r['minimum_safe_Fprime']:.6e} "
            f"minSampleF'={r['minimum_sampled_Fprime']:.6e} "
            f"max|dE|={r['maximum_abs_deltaE']:.3e}"
        )
    print()
    print(f"minimum Taylor-enclosed Fprime      : {min_safe:.12e}")
    print(f"minimum sampled Fprime              : {min_sampled:.12e}")
    print(f"minimum direct endpoint secant      : {min_secant:.12e}")
    print(f"max center reconstruction error     : {max_center_err:.3e}")
    print(
        "minimum sampled-proxy floor margin : "
        f"{min_floor_sampled_gap:.3e}"
    )
    print(
        "minimum secant-floor margin         : "
        f"{min_secant_floor_gap:.3e}"
    )
    print()
    print("FAILED GATES                        :", failed if failed else "none")
    print("NUMERICAL VERDICT                   :", verdict)
    print(
        "PROOF VERDICT                       : OPEN — "
        "PROMOTE DERIVATIVE FLOOR TO ALL HIGH MODES/CUTOFFS"
    )
    print("=" * 184)
    print("Files written:")
    for path in (
        detail_path, modes_path, summary_path, theorem_path
    ):
        print(" ", path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
