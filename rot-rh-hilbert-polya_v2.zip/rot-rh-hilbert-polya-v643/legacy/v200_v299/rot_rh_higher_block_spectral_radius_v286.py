#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v286 — HIGHER-BLOCK SPECTRAL-RADIUS PROSPECTIVE AUDIT
======================================================

Purpose
-------
v282 decisively showed that the exact smooth-preconditioned Selberg transfer

    R = (I-K_b)^(-1) K_Lambda

is NOT a contraction in the real phase-prefix norm at one step:

    ||R||_(pref,real) > 1

already at small finite N.

That does not exclude contraction of a BLOCK POWER R^m.

Because R is strongly non-normal and support-doubling,

    supp(R^m u) starts at least 2^m times farther out,

it is possible in principle that

    ||R^m||_(pref,real) < 1

even though ||R||_(pref,real)>1.

If such an m exists, the exact fixed point

    x = F0 + R x

can be regrouped as

    x = G_m + R^m x,

    G_m = (I + R + ... + R^(m-1)) F0.

Then

    ||x||_pref
      <= ||G_m||_pref / (1-||R^m||_pref)

whenever ||R^m||_pref<1.

This is the last direct Banach-style loophole after v282.

Real-state norm bracket
-----------------------
For each output prefix N and block power m, set

    D=floor(N/2^m).

Only real input coefficients u_2,...,u_D can reach output <=N under R^m.

The true input norm is

    ||u||_pref
      = max_{k<=D} |sum_{d<=k}u_d e^(iE*log d)|.

As in v282, v286 uses:

1. a circumscribed polygon for every prefix disk -> rigorous-form LP UPPER
   relaxation (subject to floating LP accuracy);

2. exact real-increment direction constraints;

3. sampled output support directions with the angular covering factor
       sec(pi/M_out);

4. rescaled LP optimizers -> feasible TRUE-DISK LOWER bounds.

Hence each finite problem returns

    q_lower(N,m)
      <= ||R^m||_(pref,real,N)
      <= q_upper(N,m).

Interpretation
--------------
* q_upper<1:
    finite-N block-power contraction supported.

* q_lower>1:
    that block power is decisively noncontractive.

* bracket crosses 1:
    inconclusive; refine polygon/output angles at the SAME N,m.

The script also computes the exact block forcing

    G_m=(I+R+...+R^(m-1))F0

and its real phase-prefix norm.

Prospective design
------------------
The block-power norm is new after v282.

Prospective continuation:
    m = 3 only
    DEVELOPMENT N = 8192,16384
    NEW HOLDOUT N = 32768,65536

v284 showed m=2 remained below one but had already risen to about 0.904,
whereas m=3 remained near 0.207.  v286 therefore freezes m=3 as the leading
block architecture and tests a further four-fold output-prefix extension under
the SAME 16-angle LP geometry.

The preregistered gate is stronger than contraction:
    q_upper(N,3) < 0.50
on every new holdout.

No Xi, zeta values, zeta'/zeta values, or zero ordinates are used.

Dependencies:
    numpy, scipy, pandas, tqdm, numba

Version: 286
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from tqdm import tqdm

VERSION = 286


def parse_ints(text):
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


# ---------------------------------------------------------------------------
# Selberg forcing
# ---------------------------------------------------------------------------

def smallest_prime_factor(N):
    spf = np.arange(N + 1, dtype=np.int32)
    spf[0] = 0
    if N >= 1:
        spf[1] = 1

    root = int(math.isqrt(N))
    for p in range(2, root + 1):
        if spf[p] != p:
            continue
        idx = np.arange(p * p, N + 1, p, dtype=np.int64)
        if len(idx):
            mask = spf[idx] == idx
            spf[idx[mask]] = p
    return spf


def selberg_factor_statistics(spf):
    N = len(spf) - 1

    tau = np.ones(N + 1, dtype=np.int32)
    omega = np.zeros(N + 1, dtype=np.uint8)
    exponent = np.zeros(N + 1, dtype=np.uint8)
    distinct_log_sum = np.zeros(N + 1, dtype=np.float64)
    g = np.zeros(N + 1, dtype=np.float64)

    for n in range(2, N + 1):
        p = int(spf[n])
        m = n // p
        lp = math.log(p)

        if m > 1 and m % p == 0:
            old_e = int(exponent[m])
            new_e = old_e + 1

            exponent[n] = new_e
            omega[n] = omega[m]
            distinct_log_sum[n] = distinct_log_sum[m]

            tau[n] = (
                tau[m] // (old_e + 1) * (new_e + 1)
            )

            if omega[n] == 1:
                g[n] = (2 * new_e - 1) * lp * lp
            else:
                g[n] = g[m]
        else:
            exponent[n] = 1
            omega[n] = omega[m] + 1
            distinct_log_sum[n] = distinct_log_sum[m] + lp
            tau[n] = tau[m] * 2

            if omega[m] == 0:
                g[n] = lp * lp
            elif omega[m] == 1:
                g[n] = 2.0 * lp * distinct_log_sum[m]
            else:
                g[n] = 0.0

    return tau, g


# ---------------------------------------------------------------------------
# Real phase-prefix LP geometry
# ---------------------------------------------------------------------------

def state_indices(D):
    m = D - 1

    def ix(k):
        return k - 2

    def iy(k):
        return m + (k - 2)

    return m, ix, iy


def build_prefix_geometry(D, theta, polygon_angles):
    m, ix, iy = state_indices(D)
    nvar = 2 * m
    M = len(polygon_angles)

    rows = []
    cols = []
    vals = []

    ca = np.cos(polygon_angles)
    sa = np.sin(polygon_angles)

    row = 0

    for k in range(2, D + 1):
        for j in range(M):
            rows.extend([row, row])
            cols.extend([ix(k), iy(k)])
            vals.extend([ca[j], sa[j]])
            row += 1

    A_ub = coo_matrix(
        (
            np.asarray(vals, dtype=float),
            (
                np.asarray(rows, dtype=np.int64),
                np.asarray(cols, dtype=np.int64),
            ),
        ),
        shape=(m * M, nvar),
    ).tocsr()

    b_ub = np.ones(m * M, dtype=float)

    eq_rows = []
    eq_cols = []
    eq_vals = []

    row = 0

    for k in range(2, D + 1):
        s = math.sin(theta[k])
        c = math.cos(theta[k])

        eq_rows.extend([row, row])
        eq_cols.extend([ix(k), iy(k)])
        eq_vals.extend([-s, c])

        if k > 2:
            eq_rows.extend([row, row])
            eq_cols.extend([ix(k - 1), iy(k - 1)])
            eq_vals.extend([s, -c])

        row += 1

    A_eq = coo_matrix(
        (
            np.asarray(eq_vals, dtype=float),
            (
                np.asarray(eq_rows, dtype=np.int64),
                np.asarray(eq_cols, dtype=np.int64),
            ),
        ),
        shape=(m, nvar),
    ).tocsr()

    b_eq = np.zeros(m, dtype=float)

    return A_ub, b_ub, A_eq, b_eq


def objective_from_output_coefficients(c_out, theta, phi, D):
    m, ix, iy = state_indices(D)
    g = np.zeros(2 * m, dtype=float)

    rot = np.exp(-1.0j * float(phi))

    for d in range(2, D + 1):
        a = float(np.real(rot * c_out[d]))

        ct = math.cos(theta[d])
        st = math.sin(theta[d])

        g[ix(d)] += a * ct
        g[iy(d)] += a * st

        if d > 2:
            g[ix(d - 1)] -= a * ct
            g[iy(d - 1)] -= a * st

    return g


def true_prefix_norm_from_state(z, D):
    m, ix, iy = state_indices(D)
    out = 0.0

    for d in range(2, D + 1):
        out = max(
            out,
            math.hypot(
                z[ix(d)],
                z[iy(d)],
            ),
        )

    return out


def reconstruct_u_from_state(z, theta, D):
    m, ix, iy = state_indices(D)

    u = np.zeros(D + 1, dtype=float)

    xprev = 0.0
    yprev = 0.0

    for d in range(2, D + 1):
        x = z[ix(d)]
        y = z[iy(d)]

        dx = x - xprev
        dy = y - yprev

        u[d] = (
            math.cos(theta[d]) * dx
            + math.sin(theta[d]) * dy
        )

        xprev = x
        yprev = y

    return u


def phase_prefix_sup(u, phase, N):
    z = 0.0 + 0.0j
    s = 0.0

    for n in range(2, N + 1):
        z += u[n] * phase[n]
        s = max(s, abs(z))

    return float(s)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--N-checkpoints",
        default="16384,32768,65536,131072",
    )
    ap.add_argument(
        "--development-N-max",
        type=int,
        default=32768,
    )
    ap.add_argument(
        "--block-powers",
        default="4,5",
    )

    ap.add_argument(
        "--prefix-polygon-angles",
        type=int,
        default=16,
    )
    ap.add_argument(
        "--output-angles",
        type=int,
        default=16,
    )

    ap.add_argument(
        "--maximum-block-q",
        type=float,
        default=0.30,
    )
    ap.add_argument(
        "--forcing-safety",
        type=float,
        default=1.35,
    )

    ap.add_argument(
        "--highs-time-limit",
        type=float,
        default=120.0,
    )

    ap.add_argument(
        "--identity-tol",
        type=float,
        default=2e-10,
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_real_state_block_power_v286",
    )
    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    try:
        from numba import njit
    except Exception as exc:
        raise RuntimeError(
            "v286 requires numba.\n"
            "Install with:\n\n"
            "    pip install numba\n\n"
            f"Import error: {exc}"
        )

    # --------------------------------------------------------------
    # Exact operator
    # --------------------------------------------------------------

    @njit(cache=True)
    def apply_Klambda(u, lam, logs, N):
        out = np.zeros(N + 1, dtype=np.float64)

        for d in range(2, N // 2 + 1):
            ud = u[d]
            if ud == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                lk = lam[k]
                if lk == 0.0:
                    continue

                n = k * d

                out[n] -= (
                    (lk / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * ud
                )

        return out

    @njit(cache=True)
    def solve_I_minus_Kb(v, logs, N):
        y = v.copy()

        for d in range(2, N // 2 + 1):
            yd = y[d]
            if yd == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                n = k * d

                y[n] -= (
                    (1.0 / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * yd
                )

        return y

    @njit(cache=True)
    def solve_I_minus_Kb_transpose(v, logs, N):
        y = v.copy()

        for d in range(N // 2, 1, -1):
            ld = logs[d]
            dmax = N // d
            acc = 0.0 + 0.0j

            for k in range(2, dmax + 1):
                n = k * d

                acc -= (
                    (1.0 / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * y[n]
                )

            y[d] += acc

        return y

    @njit(cache=True)
    def apply_Klambda_transpose(v, lam, logs, N):
        out = np.zeros(N + 1, dtype=np.complex128)

        for d in range(2, N // 2 + 1):
            ld = logs[d]
            dmax = N // d
            acc = 0.0 + 0.0j

            for k in range(2, dmax + 1):
                lk = lam[k]
                if lk == 0.0:
                    continue

                n = k * d

                acc -= (
                    (lk / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * v[n]
                )

            out[d] = acc

        return out

    @njit(cache=True)
    def apply_R_real(u, lam, logs, N):
        tmp = apply_Klambda(
            u,
            lam,
            logs,
            N,
        )
        return solve_I_minus_Kb(
            tmp,
            logs,
            N,
        )

    @njit(cache=True)
    def apply_RT_complex(v, lam, logs, N):
        tmp = solve_I_minus_Kb_transpose(
            v,
            logs,
            N,
        )
        return apply_Klambda_transpose(
            tmp,
            lam,
            logs,
            N,
        )

    checkpoints = sorted(set(
        parse_ints(args.N_checkpoints)
    ))

    powers = sorted(set(
        parse_ints(args.block_powers)
    ))

    if not checkpoints or not powers:
        raise ValueError("Need checkpoints and block powers")

    if any(m < 1 for m in powers):
        raise ValueError("Block powers must be >=1")

    development = [
        N
        for N in checkpoints
        if N <= int(args.development_N_max)
    ]

    holdout = [
        N
        for N in checkpoints
        if N > int(args.development_N_max)
    ]

    if not development or not holdout:
        raise ValueError(
            "Need DEVELOPMENT and HOLDOUT checkpoints"
        )

    if args.prefix_polygon_angles < 8:
        raise ValueError("prefix polygon angles must be >=8")

    if args.output_angles < 8:
        raise ValueError("output angles must be >=8")

    Nmax = max(checkpoints)

    anchors = pd.read_csv(args.anchors)

    anchors["k"] = anchors["k"].astype(int)
    hit = anchors[
        anchors["k"] == int(args.anchor_k)
    ]

    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one anchor k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])

    base = importlib.import_module(
        args.base_module
    )

    print("=" * 210)
    print("ROT-RH v286 — HIGHER-BLOCK SPECTRAL-RADIUS PROSPECTIVE AUDIT")
    print("=" * 210)
    print("Xi / zeta / known-zero data         : NONE")
    print(f"anchor k                             : {args.anchor_k}")
    print(f"anchor E                             : {E:.15f}")
    print(f"DEVELOPMENT N                        : {development}")
    print(f"HOLDOUT N                            : {holdout}")
    print(f"block powers                         : {powers}")
    print(f"prefix polygon angles               : {args.prefix_polygon_angles}")
    print(f"output support angles               : {args.output_angles}")
    print("=" * 210)

    # --------------------------------------------------------------
    # 1. Arithmetic
    # --------------------------------------------------------------
    print(f"[1] Arithmetic through N={Nmax:,}")

    numbers, lambdas, _ = base.mangoldt_terms(Nmax)

    numbers = np.asarray(numbers, dtype=np.int64)
    lambdas = np.asarray(lambdas, dtype=np.float64)

    lam = np.zeros(Nmax + 1, dtype=np.float64)
    lam[numbers] = lambdas

    logs = np.zeros(Nmax + 1, dtype=np.float64)
    nfloat = np.arange(2, Nmax + 1, dtype=np.float64)
    logs[2:] = np.log(nfloat)

    sqrt_n = np.ones(Nmax + 1, dtype=np.float64)
    sqrt_n[2:] = np.sqrt(nfloat)

    theta = np.zeros(Nmax + 1, dtype=np.float64)
    theta[2:] = np.remainder(
        E * logs[2:],
        2.0 * math.pi,
    )

    phase = np.ones(Nmax + 1, dtype=np.complex128)
    phase[2:] = np.exp(1.0j * theta[2:])

    # --------------------------------------------------------------
    # 2. Exact F0
    # --------------------------------------------------------------
    print("[2] Exact preconditioned forcing F0")

    spf = smallest_prime_factor(Nmax)
    tau, g = selberg_factor_statistics(spf)
    del spf

    H = np.zeros(Nmax + 1, dtype=np.float64)
    H[2:] = (
        g[2:]
        - logs[2:]
        - (
            tau[2:].astype(np.float64)
            - 2.0
        )
    )

    F = np.zeros(Nmax + 1, dtype=np.float64)
    F[2:] = (
        H[2:]
        / (
            sqrt_n[2:]
            * logs[2:]
            * logs[2:]
        )
    )

    del H, tau, g, sqrt_n, nfloat

    # JIT warmup.
    warmN = min(Nmax, 64)

    _ = solve_I_minus_Kb(
        F[:warmN + 1],
        logs[:warmN + 1],
        warmN,
    )

    vc = np.zeros(
        warmN + 1,
        dtype=np.complex128,
    )

    _ = apply_RT_complex(
        vc,
        lam[:warmN + 1],
        logs[:warmN + 1],
        warmN,
    )

    F0 = solve_I_minus_Kb(
        F,
        logs,
        Nmax,
    )

    # --------------------------------------------------------------
    # 3. Block forcing G_m
    # --------------------------------------------------------------
    print("[3] Exact block forcing G_m")

    max_power = max(powers)

    orbit = [F0.copy()]

    for j in range(1, max_power):
        orbit.append(
            apply_R_real(
                orbit[-1],
                lam,
                logs,
                Nmax,
            )
        )

    Gmap = {}

    running = np.zeros_like(F0)

    for j in range(max_power):
        running = running + orbit[j]

        m = j + 1

        if m in powers:
            Gmap[m] = running.copy()

    forcing_rows = []

    for m in powers:
        Gm = Gmap[m]

        for N in checkpoints:
            forcing_rows.append({
                "m": int(m),
                "N": int(N),
                "region": (
                    "DEVELOPMENT"
                    if N <= int(args.development_N_max)
                    else "HOLDOUT"
                ),
                "Gm_prefix_sup": phase_prefix_sup(
                    Gm,
                    phase,
                    int(N),
                ),
            })

    forcing_df = pd.DataFrame(forcing_rows)

    # --------------------------------------------------------------
    # 4. LP block-power norm brackets
    # --------------------------------------------------------------
    print("[4] Real-state block-power norm brackets")

    polygon_angles = (
        2.0
        * math.pi
        * np.arange(
            int(args.prefix_polygon_angles),
            dtype=float,
        )
        / float(args.prefix_polygon_angles)
    )

    output_angles = (
        2.0
        * math.pi
        * np.arange(
            int(args.output_angles),
            dtype=float,
        )
        / float(args.output_angles)
    )

    polygon_radial_factor = (
        1.0
        / math.cos(
            math.pi
            / float(args.prefix_polygon_angles)
        )
    )

    output_angle_factor = (
        1.0
        / math.cos(
            math.pi
            / float(args.output_angles)
        )
    )

    norm_rows = []
    angle_rows = []

    for N in checkpoints:
        ell0 = np.zeros(
            N + 1,
            dtype=np.complex128,
        )
        ell0[2:] = phase[2:N + 1]

        # Build all transpose powers once:
        # c_m=(R^T)^m ell_N.
        c = ell0

        c_map = {}

        for m in range(1, max_power + 1):
            c = apply_RT_complex(
                c,
                lam[:N + 1],
                logs[:N + 1],
                int(N),
            )

            if m in powers:
                c_map[m] = c.copy()

        for m in powers:
            D = N // (2 ** m)

            if D < 2:
                norm_rows.append({
                    "m": int(m),
                    "N": int(N),
                    "region": (
                        "DEVELOPMENT"
                        if N <= int(args.development_N_max)
                        else "HOLDOUT"
                    ),
                    "D_input": int(D),
                    "all_LP_solves_success": True,
                    "q_real_lower": 0.0,
                    "q_real_upper": 0.0,
                    "classification": "TRIVIAL_ZERO_SUPPORT",
                })
                continue

            print(
                f"  N={N:,}, m={m}, real input dimension={D-1:,}",
                flush=True,
            )

            c_out = c_map[m]

            A_ub, b_ub, A_eq, b_eq = (
                build_prefix_geometry(
                    D,
                    theta,
                    polygon_angles,
                )
            )

            rad = polygon_radial_factor

            bounds = [
                (-rad, rad)
                for _ in range(
                    A_ub.shape[1]
                )
            ]

            sampled_upper = []
            feasible_lower = []

            for phi in tqdm(
                output_angles,
                desc=f"LP N={N},m={m}",
                unit="angle",
                leave=False,
            ):
                gobj = objective_from_output_coefficients(
                    c_out,
                    theta,
                    float(phi),
                    D,
                )

                res = linprog(
                    -gobj,
                    A_ub=A_ub,
                    b_ub=b_ub,
                    A_eq=A_eq,
                    b_eq=b_eq,
                    bounds=bounds,
                    method="highs",
                    options={
                        "time_limit": float(
                            args.highs_time_limit
                        ),
                        "presolve": True,
                    },
                )

                if not res.success:
                    angle_rows.append({
                        "N": int(N),
                        "m": int(m),
                        "phi": float(phi),
                        "success": False,
                        "status": int(res.status),
                        "polygon_support_upper": float("nan"),
                        "true_prefix_norm_optimizer": float("nan"),
                        "feasible_lower": float("nan"),
                        "max_ub_violation": float("nan"),
                        "max_eq_residual": float("nan"),
                    })
                    continue

                poly_upper = float(-res.fun)

                z = np.asarray(
                    res.x,
                    dtype=float,
                )

                true_pref = (
                    true_prefix_norm_from_state(
                        z,
                        D,
                    )
                )

                scale = max(
                    1.0,
                    true_pref,
                )

                u = reconstruct_u_from_state(
                    z / scale,
                    theta,
                    D,
                )

                actual = complex(
                    np.dot(
                        c_out[2:D + 1],
                        u[2:D + 1],
                    )
                )

                lower = float(abs(actual))

                sampled_upper.append(
                    poly_upper
                )

                feasible_lower.append(
                    lower
                )

                # Solver-quality diagnostics.
                zvec = np.asarray(res.x, dtype=float)
                ub_slack = b_ub - A_ub.dot(zvec)
                eq_resid = A_eq.dot(zvec) - b_eq
                max_ub_violation = float(max(0.0, -np.min(ub_slack)))
                max_eq_residual = float(np.max(np.abs(eq_resid))) if len(eq_resid) else 0.0

                angle_rows.append({
                    "N": int(N),
                    "m": int(m),
                    "phi": float(phi),
                    "success": True,
                    "status": int(res.status),
                    "polygon_support_upper": poly_upper,
                    "true_prefix_norm_optimizer": true_pref,
                    "feasible_lower": lower,
                    "max_ub_violation": max_ub_violation,
                    "max_eq_residual": max_eq_residual,
                })

            all_success = bool(
                len(sampled_upper)
                == len(output_angles)
            )

            if all_success:
                qlower = float(
                    max(feasible_lower)
                )

                qupper = float(
                    max(sampled_upper)
                    * output_angle_factor
                )
            else:
                qlower = (
                    float(max(feasible_lower))
                    if feasible_lower
                    else float("nan")
                )

                qupper = float("inf")

            if qupper < 1.0:
                classification = (
                    "BLOCK_POWER_CONTRACTION_UPPER_BELOW_ONE"
                )
            elif qlower > 1.0:
                classification = (
                    "BLOCK_POWER_CONTRACTION_FALSE_LOWER_ABOVE_ONE"
                )
            else:
                classification = (
                    "BLOCK_POWER_BRACKET_INCONCLUSIVE"
                )

            norm_rows.append({
                "m": int(m),
                "N": int(N),
                "region": (
                    "DEVELOPMENT"
                    if N <= int(args.development_N_max)
                    else "HOLDOUT"
                ),
                "D_input": int(D),
                "all_LP_solves_success": all_success,
                "q_real_lower": qlower,
                "q_real_upper": qupper,
                "classification": classification,
            })

    norm_df = pd.DataFrame(norm_rows)
    angle_df = pd.DataFrame(angle_rows)

    # --------------------------------------------------------------
    # 5. Primal/transpose block identity controls
    # --------------------------------------------------------------
    print("[5] Block-power primal/transpose controls")

    rng = np.random.default_rng(20260820)

    identity_rows = []
    max_identity_error = 0.0

    for N in checkpoints:
        ell0 = np.zeros(
            N + 1,
            dtype=np.complex128,
        )
        ell0[2:] = phase[2:N + 1]

        for m in powers:
            D = N // (2 ** m)

            if D < 2:
                continue

            u = np.zeros(
                N + 1,
                dtype=np.float64,
            )

            u[2:D + 1] = (
                rng.standard_normal(
                    D - 1
                )
                / np.sqrt(
                    np.arange(
                        2,
                        D + 1,
                        dtype=float,
                    )
                )
            )

            primal = u.copy()

            for _ in range(m):
                primal = apply_R_real(
                    primal,
                    lam[:N + 1],
                    logs[:N + 1],
                    int(N),
                )

            dual = ell0.copy()

            for _ in range(m):
                dual = apply_RT_complex(
                    dual,
                    lam[:N + 1],
                    logs[:N + 1],
                    int(N),
                )

            lhs = complex(
                np.dot(
                    ell0[2:],
                    primal[2:],
                )
            )

            rhs = complex(
                np.dot(
                    dual[2:D + 1],
                    u[2:D + 1],
                )
            )

            err = abs(lhs - rhs)

            max_identity_error = max(
                max_identity_error,
                float(err),
            )

            identity_rows.append({
                "N": int(N),
                "m": int(m),
                "lhs_real": float(np.real(lhs)),
                "lhs_imag": float(np.imag(lhs)),
                "rhs_real": float(np.real(rhs)),
                "rhs_imag": float(np.imag(rhs)),
                "absolute_error": float(err),
            })

    identity_df = pd.DataFrame(identity_rows)

    successful_angles = angle_df[angle_df["success"] == True] if len(angle_df) else pd.DataFrame()
    max_lp_ub_violation = (
        float(successful_angles["max_ub_violation"].max())
        if len(successful_angles) else float("nan")
    )
    max_lp_eq_residual = (
        float(successful_angles["max_eq_residual"].max())
        if len(successful_angles) else float("nan")
    )

    identity_pass = bool(
        max_identity_error
        <= float(args.identity_tol)
    )

    # --------------------------------------------------------------
    # 6. Per-power prospective classification
    # --------------------------------------------------------------
    power_rows = []

    positive_powers = []

    for m in powers:
        sub = norm_df[
            norm_df["m"] == int(m)
        ]

        dev = sub[
            sub["region"] == "DEVELOPMENT"
        ]

        hold = sub[
            sub["region"] == "HOLDOUT"
        ]

        all_lp = bool(
            sub[
                "all_LP_solves_success"
            ].all()
        )

        dev_upper = (
            float(
                dev["q_real_upper"].max()
            )
            if len(dev)
            else float("inf")
        )

        hold_upper = (
            float(
                hold["q_real_upper"].max()
            )
            if len(hold)
            else float("inf")
        )

        hold_lower = (
            float(
                hold["q_real_lower"].max()
            )
            if len(hold)
            else float("nan")
        )

        contraction_supported = bool(
            all_lp
            and dev_upper
                < float(args.maximum_block_q)
            and hold_upper < 1.0
        )

        contraction_false = bool(
            len(hold)
            and np.any(
                hold[
                    "q_real_lower"
                ].to_numpy()
                > 1.0
            )
        )

        fsub = forcing_df[
            forcing_df["m"] == int(m)
        ]

        fdev = fsub[
            fsub["region"] == "DEVELOPMENT"
        ]

        fhold = fsub[
            fsub["region"] == "HOLDOUT"
        ]

        frozen_G = (
            float(args.forcing_safety)
            * float(
                fdev[
                    "Gm_prefix_sup"
                ].max()
            )
            if len(fdev)
            else float("inf")
        )

        forcing_hold_pass = bool(
            len(fhold)
            and np.all(
                fhold[
                    "Gm_prefix_sup"
                ].to_numpy()
                <= frozen_G
            )
        )

        qpanel = max(
            dev_upper,
            hold_upper,
        )

        fixed_point_bound = (
            frozen_G
            / (1.0 - qpanel)
            if qpanel < 1.0
            else float("inf")
        )

        if (
            m >= 2
            and contraction_supported
            and forcing_hold_pass
        ):
            positive_powers.append(int(m))

        power_rows.append({
            "m": int(m),
            "all_LP_success": all_lp,
            "development_max_upper": dev_upper,
            "holdout_max_upper": hold_upper,
            "holdout_max_lower": hold_lower,
            "contraction_supported": contraction_supported,
            "contraction_false_on_holdout": contraction_false,
            "frozen_Gm_prefix_bound": frozen_G,
            "forcing_holdout_pass": forcing_hold_pass,
            "candidate_fixed_point_bound": fixed_point_bound,
        })

    power_df = pd.DataFrame(power_rows)

    # Diagnostics only: per-doubling growth and m-th roots for each tested
    # block power. These are NOT used as gates or asymptotic fits.
    growth_rows = []
    for mpow in powers:
        curve = norm_df[norm_df["m"] == int(mpow)].sort_values("N").copy()
        prev = None
        for row in curve.itertuples(index=False):
            upper_root = (
                float(row.q_real_upper ** (1.0 / mpow))
                if np.isfinite(row.q_real_upper) and row.q_real_upper >= 0.0
                else float("nan")
            )
            lower_root = (
                float(row.q_real_lower ** (1.0 / mpow))
                if np.isfinite(row.q_real_lower) and row.q_real_lower >= 0.0
                else float("nan")
            )

            if prev is None:
                upper_ratio = float("nan")
                upper_delta = float("nan")
            else:
                upper_ratio = float(row.q_real_upper / prev.q_real_upper)
                upper_delta = float(row.q_real_upper - prev.q_real_upper)

            growth_rows.append({
                "m": int(mpow),
                "N": int(row.N),
                "region": row.region,
                "q_real_lower": float(row.q_real_lower),
                "q_real_upper": float(row.q_real_upper),
                "lower_mth_root": lower_root,
                "upper_mth_root": upper_root,
                "upper_ratio_vs_previous": upper_ratio,
                "upper_delta_vs_previous": upper_delta,
            })
            prev = row

    growth_df = pd.DataFrame(growth_rows)

    if positive_powers:
        best_m = min(
            positive_powers,
            key=lambda m: float(
                power_df[
                    power_df["m"] == m
                ][
                    "holdout_max_upper"
                ].iloc[0]
            ),
        )

        mechanism = (
            "HIGHER_BLOCK_CONTRACTION_PROSPECTIVELY_SURVIVES"
        )

        verdict = (
            "HIGHER_BLOCK_SPECTRAL_RADIUS_AUDIT_VERIFIED"
        )

        next_theorem = (
            f"R^{best_m} has survived the higher-block prospective panel. "
            f"Compare the m-th-root bounds across powers before choosing the "
            f"analytic target. If the roots remain uniformly below one, attack "
            f"a spectral-radius / block-power theorem for R together with a "
            f"finite prefix norm for G_{best_m}=(I+...+R^{best_m-1})F0."
        )

    else:
        all_false = bool(
            len(power_df[
                power_df["m"] >= 2
            ])
            and np.all(
                power_df[
                    power_df["m"] >= 2
                ][
                    "contraction_false_on_holdout"
                ].to_numpy()
            )
        )

        if all_false:
            mechanism = (
                "HIGHER_BLOCK_CONTRACTION_FAILS"
            )

            verdict = (
                "HIGHER_BLOCK_SPECTRAL_RADIUS_AUDIT_GATE_FAILURE"
            )

            next_theorem = (
                "Every tested block power m>=2 has a feasible real prefix-bounded "
                "input amplified above one on holdout. Retire direct Banach "
                "contraction of R and its small powers."
            )
        else:
            mechanism = (
                "HIGHER_BLOCK_CONTRACTION_INCONCLUSIVE"
            )

            verdict = (
                "HIGHER_BLOCK_SPECTRAL_RADIUS_AUDIT_INCONCLUSIVE"
            )

            next_theorem = (
                "At least one block-power bracket crosses one. Refine polygon "
                "and output-angle resolution at the same N,m before extending N."
            )

    gates = {
        "block_primal_transpose_identity": identity_pass,
        "all_LP_solves_success": bool(
            norm_df[
                "all_LP_solves_success"
            ].all()
        ),
        "some_m_ge_2_contraction_supported": bool(
            len(positive_powers) > 0
        ),
    }

    failed = [
        k
        for k, v in gates.items()
        if not v
    ]

    # --------------------------------------------------------------
    # Outputs
    # --------------------------------------------------------------
    out = args.prefix

    norm_path = Path(
        out + "_NORM_BRACKETS.csv"
    )
    angle_path = Path(
        out + "_ANGLE_SOLVES.csv"
    )
    forcing_path = Path(
        out + "_BLOCK_FORCING.csv"
    )
    power_path = Path(
        out + "_POWER_SUMMARY.csv"
    )
    growth_path = Path(
        out + "_POWER_ROOTS_GROWTH.csv"
    )
    identity_path = Path(
        out + "_TRANSPOSE_IDENTITY.csv"
    )
    summary_path = Path(
        out + "_SUMMARY.json"
    )
    theorem_path = Path(
        out + "_NEXT_THEOREM.md"
    )

    norm_df.to_csv(
        norm_path,
        index=False,
    )

    angle_df.to_csv(
        angle_path,
        index=False,
    )

    forcing_df.to_csv(
        forcing_path,
        index=False,
    )

    power_df.to_csv(
        power_path,
        index=False,
    )

    growth_df.to_csv(
        growth_path,
        index=False,
    )

    identity_df.to_csv(
        identity_path,
        index=False,
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "block_fixed_point": {
            "identity": (
                "x=G_m+R^m x, "
                "G_m=(I+R+...+R^(m-1))F0"
            ),
            "powers": powers,
        },
        "real_norm_bracket": {
            "prefix_polygon_angles": int(
                args.prefix_polygon_angles
            ),
            "output_angles": int(
                args.output_angles
            ),
            "polygon_radial_factor": (
                polygon_radial_factor
            ),
            "output_angle_factor": (
                output_angle_factor
            ),
        },
        "prospective_design": {
            "development_N": development,
            "holdout_N": holdout,
            "note": (
                "The block-power norm is new after v282. "
                "m=1 is retained as a control."
            ),
        },
        "power_summary": power_rows,
        "positive_powers": positive_powers,
        "power_root_growth_diagnostic": growth_rows,
        "identity": {
            "maximum_primal_transpose_error": (
                max_identity_error
            ),
            "pass": identity_pass,
        },
        "solver_quality": {
            "maximum_LP_inequality_violation": max_lp_ub_violation,
            "maximum_LP_equality_residual": max_lp_eq_residual,
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN. A finite block-power contraction pass would identify a "
            "direct fixed-point architecture but still require an all-N proof."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            summary,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v286 — higher-block spectral-radius prospective audit

## Exact regrouping

For every integer `m>=1`,

`x=G_m+R^m x`

with

`G_m=(I+R+...+R^(m-1))F0`.

Therefore a single power with

`||R^m||_(pref,real)<1`

is sufficient for the direct fixed-point estimate

`||x||_pref <= ||G_m||_pref/(1-||R^m||)`.

## Finite real-state brackets

The script computes

`q_lower(N,m) <= ||R^m||_(pref,real,N) <= q_upper(N,m)`.

The lower number is a feasible real input.
The upper number uses the circumscribed prefix polygon and angular output
covering.

## Result

Mechanism:

`{mechanism}`

Positive powers:

`{positive_powers}`

{next_theorem}
""",
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # Console
    # --------------------------------------------------------------
    print()
    print("=" * 210)
    print("ROT-RH v286 — HIGHER-BLOCK SPECTRAL-RADIUS SUMMARY")
    print("=" * 210)

    print("POWER SUMMARY")
    print("-" * 210)

    for row in power_rows:
        print(
            f"m={row['m']} "
            f"dev upper={row['development_max_upper']:.6f} "
            f"hold lower={row['holdout_max_lower']:.6f} "
            f"hold upper={row['holdout_max_upper']:.6f} "
            f"contract={row['contraction_supported']} "
            f"forcing={row['forcing_holdout_pass']}"
        )

    print()
    print("POWER ROOT / GROWTH DIAGNOSTIC — NOT A GATE")
    print("-" * 210)
    for row in growth_rows:
        if np.isfinite(row["upper_ratio_vs_previous"]):
            extra = (
                f" ratio={row['upper_ratio_vs_previous']:.6f}"
                f" delta={row['upper_delta_vs_previous']:+.6f}"
            )
        else:
            extra = ""
        print(
            f"m={row['m']} {row['region'][:4]:4s} N={row['N']:>7d} "
            f"lower={row['q_real_lower']:.6f} "
            f"upper={row['q_real_upper']:.6f} "
            f"roots=[{row['lower_mth_root']:.6f},{row['upper_mth_root']:.6f}]"
            f"{extra}"
        )
    print()
    print("IDENTITY")
    print("-" * 210)
    print(
        "max block primal/transpose error    : "
        f"{max_identity_error:.3e}"
    )
    print(
        "identity pass                       : "
        f"{identity_pass}"
    )
    print(
        "max LP inequality violation         : "
        f"{max_lp_ub_violation:.3e}"
    )
    print(
        "max LP equality residual            : "
        f"{max_lp_eq_residual:.3e}"
    )

    print()
    print("MECHANISM                            :", mechanism)
    print("=" * 210)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print("VERDICT                              :", verdict)
    print(
        "PROOF VERDICT                        : OPEN — "
        "BLOCK-POWER REAL PREFIX FIXED-POINT THEOREM"
    )
    print("=" * 210)

    print("Files written:")
    print(" ", norm_path)
    print(" ", angle_path)
    print(" ", forcing_path)
    print(" ", power_path)
    print(" ", growth_path)
    print(" ", identity_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and verdict != "HIGHER_BLOCK_SPECTRAL_RADIUS_AUDIT_VERIFIED":
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
