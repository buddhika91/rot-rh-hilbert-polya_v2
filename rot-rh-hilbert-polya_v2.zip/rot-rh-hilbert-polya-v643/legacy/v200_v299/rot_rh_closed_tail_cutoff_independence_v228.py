#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v228 — CLOSED-TAIL LOW-MODE CUTOFF-INDEPENDENCE CERTIFICATE AUDIT

Purpose
-------
Attack the unresolved low-mode part of the trace-norm cutoff-removal problem for

    H_L e_k = E_k(L) e_k,
    K_L     = H_L^{-2},

using the finite-part counting phase

    F_L(E_k(L)) = k - 1/2.

For a cutoff pair L_a < L_b and the same canonical mode k,

    F_a(E_a) = target,
    F_b(E_b) = target.

Therefore, by the mean value theorem,

    |E_b-E_a|
      <= ( |F_b(E_a)-F_a(E_a)| + numerical/tail allowance )
         / inf_{segment(E_a,E_b)} F_b'(E).

This script:
  * merges already-computed ROOTS.npz files by (L,k),
  * uses NO Xi, zeta, or known-zero ordinates,
  * builds only the finite-part arithmetic phases needed for selected cutoffs,
  * tests the root-motion inequality mode-by-mode,
  * propagates it to lambda_k(L)=E_k(L)^(-2),
  * sums the troublesome low-mode contribution,
  * fits dyadic summability B(L) ~ L^(-p),
  * freezes an early envelope and tests it prospectively on later pairs,
  * estimates the remaining dyadic variation if p>0.

The audit is deliberately focused on the v132/v133 bottleneck: low-mode absolute
variation. Cross-mode cancellation is NEVER used.

Important proof status
----------------------
This is a closed-tail theorem-bridge numerical audit, not a proof.  The derivative minimum is
sampled on each root-motion segment, with a configurable safety factor.  A final
analytic theorem still needs a rigorous lower bound for F_L' on those intervals
(or another certified monotonicity argument) and a rigorous high-k tail bound.

No Xi / zeta / known-zero information is used anywhere.

Recommended inputs
------------------
  rot_rh_trace_norm_cutoff_removal_v132_ROOTS.npz
  rot_rh_prospective_dyadic_holdout_v167_ROOTS.npz

Version: 228
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

try:
    import pandas as pd
except Exception as exc:
    raise RuntimeError("v228 requires pandas") from exc

try:
    from scipy.special import erfc, gamma, gammaincc
except Exception as exc:
    raise RuntimeError("v228 requires scipy.special") from exc

try:
    from tqdm import tqdm
except Exception as exc:
    raise RuntimeError("v227 requires tqdm") from exc


VERSION = 228
EPS = np.finfo(float).eps


def csv_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, float) and not math.isfinite(x):
        return None
    return x


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


@dataclass
class RootTable:
    # L -> roots indexed k=1,2,...
    roots: Dict[int, np.ndarray]
    duplicate_max_spread: float
    duplicate_count: int


def load_and_merge_root_files(
    paths: List[str],
    duplicate_tol: float,
) -> RootTable:
    values: Dict[Tuple[int, int], List[float]] = {}
    max_spread = 0.0
    duplicate_count = 0

    for p in paths:
        z = np.load(p)
        if "L" not in z or "roots" not in z:
            raise ValueError(f"{p}: expected arrays L and roots")
        Ls = np.asarray(z["L"], int).reshape(-1)
        rr = np.asarray(z["roots"], float)
        if rr.ndim != 2 or rr.shape[0] != len(Ls):
            raise ValueError(
                f"{p}: roots shape {rr.shape} incompatible with {len(Ls)} cutoffs"
            )
        for i, L in enumerate(Ls):
            row = rr[i]
            for j, E in enumerate(row):
                if np.isfinite(E) and E > 0:
                    values.setdefault((int(L), j + 1), []).append(float(E))

    by_L: Dict[int, Dict[int, float]] = {}
    bad = []
    for (L, k), vals in values.items():
        arr = np.asarray(vals, float)
        if len(arr) > 1:
            duplicate_count += 1
            spread = float(np.ptp(arr))
            max_spread = max(max_spread, spread)
            if spread > duplicate_tol:
                bad.append((L, k, spread, arr.tolist()))
        by_L.setdefault(L, {})[k] = float(np.median(arr))

    if bad:
        preview = "\n".join(
            f"  L={L}, k={k}, spread={s:.3e}, values={v}"
            for L, k, s, v in bad[:12]
        )
        raise RuntimeError(
            "Duplicate root inconsistency exceeds tolerance "
            f"{duplicate_tol:.3e}:\n{preview}"
        )

    roots: Dict[int, np.ndarray] = {}
    for L, modes in by_L.items():
        n = max(modes)
        arr = np.full(n, np.nan, float)
        for k, E in modes.items():
            arr[k - 1] = E
        # Keep only the contiguous canonical prefix; later logic relies on k labels.
        finite = np.flatnonzero(np.isfinite(arr))
        if len(finite) == 0:
            continue
        first_gap = next((j for j in range(len(arr)) if not np.isfinite(arr[j])), len(arr))
        arr = arr[:first_gap]
        if len(arr):
            if np.any(np.diff(arr) <= 0):
                raise RuntimeError(f"L={L}: canonical roots are not strictly increasing")
            roots[int(L)] = arr

    if len(roots) < 2:
        raise RuntimeError("Need at least two usable cutoff supports")

    return RootTable(
        roots=roots,
        duplicate_max_spread=max_spread,
        duplicate_count=duplicate_count,
    )


def choose_chain(
    available: Iterable[int],
    explicit: List[int],
    cutoff_min: int,
    cutoff_max: int,
    ratio_target: float,
    ratio_tol: float,
) -> List[int]:
    av = sorted(
        int(x)
        for x in available
        if int(x) >= cutoff_min and (cutoff_max <= 0 or int(x) <= cutoff_max)
    )
    if explicit:
        missing = [L for L in explicit if L not in av]
        if missing:
            raise ValueError(f"Requested cutoffs missing from root files: {missing}")
        return explicit

    if len(av) < 2:
        raise RuntimeError("Not enough cutoffs after cutoff filters")

    # Prefer a longest approximately geometric chain.
    best: List[int] = []
    for start in av:
        chain = [start]
        cur = start
        while True:
            target = cur * ratio_target
            candidates = [
                x for x in av
                if x > cur and abs(x / target - 1.0) <= ratio_tol
            ]
            if not candidates:
                break
            nxt = min(candidates, key=lambda x: abs(x / target - 1.0))
            chain.append(nxt)
            cur = nxt
        if len(chain) > len(best):
            best = chain

    if len(best) < 2:
        # Fall back to all available supports.  Fits will use actual L ratios.
        best = av
    return best



def upper_gamma(s: float, a: float) -> float:
    """Upper incomplete gamma Γ(s,a), using scipy's regularized gammaincc."""
    return float(gamma(s) * gammaincc(s, a))


def raw_exp_sqrt_tail(L: float, N: float) -> float:
    """
    Exact:
        ∫_N^∞ x^(-1/2) exp(-x/L) dx
        = sqrt(pi L) erfc(sqrt(N/L)).
    """
    L = float(L)
    N = float(N)
    if L <= 0 or N <= 0:
        raise ValueError("L,N must be positive")
    return float(math.sqrt(math.pi * L) * erfc(math.sqrt(N / L)))


def log_weighted_exp_sqrt_tail_upper(L: float, N: float) -> float:
    """
    Rigorous elementary upper bound for

        ∫_N^∞ log(x) x^(-1/2) exp(-x/L) dx.

    Concavity of log gives, for x>=N,

        log x <= log N + (x-N)/N.

    Hence the integral is bounded by closed incomplete-gamma terms only.
    """
    L = float(L)
    N = float(N)
    a = N / L
    I0 = (L ** 0.5) * upper_gamma(0.5, a)
    I1 = (L ** 1.5) * upper_gamma(1.5, a)
    return float(math.log(N) * I0 + (I1 - N * I0) / N)


def build_phase_closed_tail(v102, base, L: int, tail_factor: float, q: int):
    """
    Rebuild the v102.1 RenormalizedPhase with IDENTICAL finite arithmetic and
    counterterm coefficients, but replace the two improper-tail quad() calls
    by exact/closed-form tails.

    This changes no prime/Mangoldt terms, no roots, and no phase formula.
    It only removes the IntegrationWarning-prone numerical tail integrals.
    """
    L = int(L)
    q = int(q)

    # ---- Prime/Mangoldt finite part: same as v102.1 ----
    nmax = max(8, int(math.ceil(float(tail_factor) * float(L))))
    numbers, lambdas, _ = base.mangoldt_terms(nmax)
    nums = numbers.astype(float)
    logs = np.log(nums)
    phase_w = (
        lambdas
        / (logs * np.sqrt(nums))
        * np.exp(-nums / float(L))
    )

    N = float(nmax)
    prime_tail_integral = raw_exp_sqrt_tail(L, N)
    prime_tail_lattice = (
        math.exp(-(N + 1.0) / float(L))
        / math.sqrt(N + 1.0)
    )
    # Same units as v102.1 phase.prime_tail_abs_bound: F-value units.
    prime_F_tail = (prime_tail_integral + prime_tail_lattice) / math.pi

    # ---- PNT counterterm finite grid: same as v102.1 ----
    ppc = max(16, int(round(q / 16.0)))
    design_emax = 220.0
    xmax_factor = 36.0
    ymin = math.log(2.0)
    xmax = xmax_factor * float(L)
    ymax = math.log(xmax)

    dy_target = 2.0 * math.pi / (ppc * design_emax)
    n = max(2049, int(math.ceil((ymax - ymin) / dy_target)) + 1)
    if n % 2 == 0:
        n += 1

    y = np.linspace(ymin, ymax, n)
    dy = float(y[1] - y[0])
    x = np.exp(y)

    quad_w = np.ones(n, float)
    quad_w[1:-1:2] = 4.0
    quad_w[2:-1:2] = 2.0
    quad_w *= dy / 3.0

    common = np.exp(0.5 * y - x / float(L))
    phase_coeff = quad_w * common / y
    deriv_coeff = quad_w * common

    raw_counter_tail = raw_exp_sqrt_tail(L, xmax)
    counter_phase_tail = raw_counter_tail / math.log(xmax)
    counter_deriv_tail = raw_counter_tail

    counter = v102.PNTCounterterm(
        L=L,
        q=q,
        ppc=ppc,
        xmax_factor=xmax_factor,
        y=x,
        logy=y,
        phase_coeff=np.asarray(phase_coeff, float),
        deriv_coeff=np.asarray(deriv_coeff, float),
        phase_tail_abs_bound=float(counter_phase_tail),
        deriv_tail_abs_bound=float(counter_deriv_tail),
    )

    return v102.RenormalizedPhase(
        base=base,
        L=L,
        nmax=nmax,
        logs=logs,
        phase_w=np.asarray(phase_w, float),
        counter=counter,
        prime_tail_abs_bound=float(prime_F_tail),
    )


def eval_chunked(phase, method: str, points: np.ndarray, point_chunk: int) -> np.ndarray:
    points = np.asarray(points, float)
    out = np.empty(len(points), float)
    fn = getattr(phase, method)
    for j in range(0, len(points), point_chunk):
        sl = slice(j, min(j + point_chunk, len(points)))
        out[sl] = np.asarray(fn(points[sl]), float)
    return out


def omitted_prime_derivative_F_bound(L: int, nmax: int) -> float:
    """
    Conservative closed-form F'-tail bound.

    Since Lambda(n) <= log n,

        |P'_tail(E)| <= sum_{n>N} log(n)/sqrt(n) exp(-n/L).

    The continuum part is bounded with concavity of log; the first omitted
    lattice term is added explicitly. No improper numerical quadrature.
    """
    N = float(nmax)
    Lf = float(L)
    integral_upper = log_weighted_exp_sqrt_tail_upper(Lf, N)
    lattice = (
        math.log(N + 1.0)
        * math.exp(-(N + 1.0) / Lf)
        / math.sqrt(N + 1.0)
    )
    return float((integral_upper + lattice) / math.pi)


def phase_F_tail_bound(phase) -> float:
    """
    Conservative F-value uncertainty allowance from finite arithmetic and
    counterterm tails. pnt_ac is cutoff-independent and exact here.
    """
    prime = float(getattr(phase, "prime_tail_abs_bound", 0.0))
    counter = float(getattr(phase.counter, "phase_tail_abs_bound", 0.0)) / math.pi
    return max(prime, 0.0) + max(counter, 0.0)


def derivative_F_tail_bound(phase) -> float:
    prime = omitted_prime_derivative_F_bound(int(phase.L), int(phase.nmax))
    counter = float(getattr(phase.counter, "deriv_tail_abs_bound", 0.0)) / math.pi
    return max(prime, 0.0) + max(counter, 0.0)


def fit_power(L: np.ndarray, B: np.ndarray) -> dict:
    L = np.asarray(L, float)
    B = np.asarray(B, float)
    m = np.isfinite(L) & np.isfinite(B) & (L > 0) & (B > 0)
    L, B = L[m], B[m]
    if len(L) < 3:
        return dict(n=len(L), p=np.nan, r2=np.nan, A=np.nan)
    x = np.log(L)
    y = np.log(B)
    X = np.column_stack([np.ones(len(x)), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    sse = float(np.sum((y - pred) ** 2))
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - sse / sst if sst > 0 else 1.0
    return dict(
        n=len(L),
        p=float(-beta[1]),
        r2=float(r2),
        A=float(math.exp(beta[0])),
    )


def prospective_envelope(
    L: np.ndarray,
    B: np.ndarray,
    holdout_pairs: int,
    envelope_safety: float,
) -> dict:
    L = np.asarray(L, float)
    B = np.asarray(B, float)
    n = len(L)
    if n < 4:
        return dict(
            available=False,
            reason="need at least four cutoff pairs",
        )
    ho = min(max(1, int(holdout_pairs)), n - 3)
    ntr = n - ho
    fit = fit_power(L[:ntr], B[:ntr])
    p = float(fit["p"])
    if not np.isfinite(p):
        return dict(available=False, reason="training power fit unavailable")
    # Freeze an upper envelope using the fitted p, then inflate it.
    A = float(np.max(B[:ntr] * (L[:ntr] ** p))) * float(envelope_safety)
    pred = A * (L[ntr:] ** (-p))
    pass_each = B[ntr:] <= pred
    return dict(
        available=True,
        training_pairs=ntr,
        holdout_pairs=ho,
        frozen_p=p,
        frozen_A=A,
        envelope_safety=float(envelope_safety),
        holdout_L=L[ntr:].tolist(),
        holdout_observed=B[ntr:].tolist(),
        holdout_upper=pred.tolist(),
        holdout_pass=pass_each.tolist(),
        all_holdouts_pass=bool(np.all(pass_each)),
    )


def mode_segment_points(Ea: float, Eb: float, samples: int, min_width: float) -> np.ndarray:
    lo = min(Ea, Eb)
    hi = max(Ea, Eb)
    if hi - lo < min_width:
        mid = 0.5 * (lo + hi)
        lo = mid - 0.5 * min_width
        hi = mid + 0.5 * min_width
    lo = max(7.0, lo)
    return np.linspace(lo, hi, int(samples), dtype=float)


def main() -> int:
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--root-files", nargs="+", required=True)
    ap.add_argument(
        "--v102-module",
        default="rot_rh_pnt_finite_part_full_pipeline_v102_1",
    )
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument("--cutoffs", default="")
    ap.add_argument("--cutoff-min", type=int, default=64000)
    ap.add_argument("--cutoff-max", type=int, default=0)
    ap.add_argument("--ratio-target", type=float, default=2.0)
    ap.add_argument("--ratio-tol", type=float, default=0.03)

    ap.add_argument("--low-mode-end", type=int, default=32)
    ap.add_argument("--segment-samples", type=int, default=17)
    ap.add_argument("--segment-min-width", type=float, default=2e-5)
    ap.add_argument("--point-chunk", type=int, default=64)

    ap.add_argument("--tail-factor", type=float, default=18.0)
    ap.add_argument("--counter-q", type=int, default=8192)

    ap.add_argument("--duplicate-root-tol", type=float, default=2e-7)
    ap.add_argument(
        "--derivative-floor-safety",
        type=float,
        default=0.90,
        help="Multiply sampled derivative floor by this before using MVT bound.",
    )
    ap.add_argument(
        "--bound-slack",
        type=float,
        default=1.05,
        help="Final multiplicative numerical allowance on root/lambda MVT bounds.",
    )
    ap.add_argument("--holdout-pairs", type=int, default=2)
    ap.add_argument("--envelope-safety", type=float, default=1.25)
    ap.add_argument("--power-p-gate", type=float, default=0.05)
    ap.add_argument("--fit-r2-gate", type=float, default=0.80)
    ap.add_argument(
        "--require-prospective-envelope",
        action="store_true",
        help="Require the frozen early power envelope to contain every holdout pair.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_closed_tail_cutoff_independence_v228",
    )
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    started = time.perf_counter()

    if args.low_mode_end < 1:
        raise ValueError("--low-mode-end must be >=1")
    if args.segment_samples < 3:
        raise ValueError("--segment-samples must be >=3")
    if not (0 < args.derivative_floor_safety <= 1):
        raise ValueError("--derivative-floor-safety must be in (0,1]")
    if args.bound_slack < 1:
        raise ValueError("--bound-slack must be >=1")

    roots_info = load_and_merge_root_files(
        args.root_files,
        duplicate_tol=float(args.duplicate_root_tol),
    )
    explicit = csv_ints(args.cutoffs)
    chain = choose_chain(
        roots_info.roots.keys(),
        explicit=explicit,
        cutoff_min=int(args.cutoff_min),
        cutoff_max=int(args.cutoff_max),
        ratio_target=float(args.ratio_target),
        ratio_tol=float(args.ratio_tol),
    )
    if len(chain) < 2:
        raise RuntimeError("Need at least two cutoffs in selected chain")

    # Common available prefix depth across selected supports.
    common_modes = min(len(roots_info.roots[L]) for L in chain)
    mode_end = min(int(args.low_mode_end), common_modes)
    if mode_end < 1:
        raise RuntimeError("No common modes across selected cutoffs")

    print("=" * 150)
    print("ROT-RH v228 — CLOSED-TAIL LOW-MODE CUTOFF-INDEPENDENCE CERTIFICATE")
    print("=" * 150)
    print("Xi / zeta / known-zero data       : NONE")
    print("operator                           : K_L = H_L^{-2}")
    print("selected cutoff chain              :", chain)
    print("common modes                       :", common_modes)
    print("low modes tested                   : 1..%d" % mode_end)
    print("segment derivative samples         :", args.segment_samples)
    print("tail factor / counter q            :", args.tail_factor, "/", args.counter_q)
    print("tail-bound method                   : CLOSED FORM / NO IMPROPER QUAD")
    print("duplicate root max spread          : %.3e" % roots_info.duplicate_max_spread)
    print("=" * 150)

    v102 = importlib.import_module(args.v102_module)
    base = importlib.import_module(args.base_module)
    if not hasattr(v102, "RenormalizedPhase"):
        raise AttributeError(f"{args.v102_module} has no RenormalizedPhase")

    mode_rows: List[dict] = []
    pair_rows: List[dict] = []

    prev_phase = None
    prev_L = None

    outer = tqdm(range(len(chain) - 1), desc="cutoff pairs", unit="pair")
    for pair_index in outer:
        La = int(chain[pair_index])
        Lb = int(chain[pair_index + 1])

        if prev_phase is None or prev_L != La:
            phase_a = build_phase_closed_tail(
                v102, base, La, float(args.tail_factor), int(args.counter_q)
            )
        else:
            phase_a = prev_phase

        phase_b = build_phase_closed_tail(
            v102, base, Lb, float(args.tail_factor), int(args.counter_q)
        )

        ra_vec = np.asarray(roots_info.roots[La][:mode_end], float)
        rb_vec = np.asarray(roots_info.roots[Lb][:mode_end], float)

        # Batch all scalar root evaluations.
        target = np.arange(1, mode_end + 1, dtype=float) - 0.5
        Fa_Ea = eval_chunked(phase_a, "F", ra_vec, args.point_chunk)
        Fb_Ea = eval_chunked(phase_b, "F", ra_vec, args.point_chunk)
        Fb_Eb = eval_chunked(phase_b, "F", rb_vec, args.point_chunk)

        F_tail_a = phase_F_tail_bound(phase_a)
        F_tail_b = phase_F_tail_bound(phase_b)
        F_delta_tail = F_tail_a + F_tail_b
        deriv_tail_b = derivative_F_tail_bound(phase_b)

        pair_mode_rows = []
        inner = tqdm(
            range(mode_end),
            desc=f"L {La}->{Lb} modes",
            unit="mode",
            leave=False,
        )
        for idx in inner:
            k = idx + 1
            Ea = float(ra_vec[idx])
            Eb = float(rb_vec[idx])

            seg = mode_segment_points(
                Ea,
                Eb,
                samples=int(args.segment_samples),
                min_width=float(args.segment_min_width),
            )
            fp_b = eval_chunked(phase_b, "Fprime", seg, args.point_chunk)
            sampled_min_fp = float(np.min(fp_b))
            certifiedish_min_fp = (
                sampled_min_fp - deriv_tail_b
            ) * float(args.derivative_floor_safety)

            deltaF_at_Ea = float(abs(Fb_Ea[idx] - Fa_Ea[idx]))
            root_res_a = float(abs(Fa_Ea[idx] - target[idx]))
            root_res_b = float(abs(Fb_Eb[idx] - target[idx]))

            numerator = (
                deltaF_at_Ea
                + root_res_a
                + root_res_b
                + F_delta_tail
            )

            actual_dE = float(abs(Eb - Ea))
            actual_dlambda = float(abs(Eb ** -2 - Ea ** -2))

            if certifiedish_min_fp > 0:
                dE_bound = (
                    float(args.bound_slack)
                    * numerator
                    / certifiedish_min_fp
                )
                Emin = min(Ea, Eb)
                dlambda_bound = (
                    float(args.bound_slack)
                    * 2.0
                    * dE_bound
                    / (Emin ** 3)
                )
                root_bound_pass = actual_dE <= dE_bound
                lambda_bound_pass = actual_dlambda <= dlambda_bound
            else:
                dE_bound = np.inf
                dlambda_bound = np.inf
                root_bound_pass = False
                lambda_bound_pass = False

            row = dict(
                pair_index=pair_index,
                L_a=La,
                L_b=Lb,
                ratio_L=float(Lb / La),
                k=k,
                E_a=Ea,
                E_b=Eb,
                signed_dE=float(Eb - Ea),
                abs_dE=actual_dE,
                lambda_a=float(Ea ** -2),
                lambda_b=float(Eb ** -2),
                abs_dlambda=actual_dlambda,
                deltaF_at_Ea=deltaF_at_Ea,
                root_residual_a=root_res_a,
                root_residual_b=root_res_b,
                F_tail_allowance_a=F_tail_a,
                F_tail_allowance_b=F_tail_b,
                F_difference_tail_allowance=F_delta_tail,
                sampled_min_Fprime_b=sampled_min_fp,
                derivative_tail_allowance_b=deriv_tail_b,
                safe_min_Fprime_b=certifiedish_min_fp,
                dE_MVT_bound=float(dE_bound),
                dlambda_MVT_bound=float(dlambda_bound),
                root_bound_pass=bool(root_bound_pass),
                lambda_bound_pass=bool(lambda_bound_pass),
            )
            mode_rows.append(row)
            pair_mode_rows.append(row)

        d = pd.DataFrame(pair_mode_rows)
        low_trace_actual = float(d["abs_dlambda"].sum())
        finite_bounds = np.isfinite(d["dlambda_MVT_bound"].to_numpy(float))
        low_trace_bound = (
            float(d["dlambda_MVT_bound"].sum())
            if bool(np.all(finite_bounds))
            else np.inf
        )
        all_root_bounds = bool(d["root_bound_pass"].all())
        all_lambda_bounds = bool(d["lambda_bound_pass"].all())
        all_derivative_floors_positive = bool(
            np.all(d["safe_min_Fprime_b"].to_numpy(float) > 0)
        )

        pair_rows.append(
            dict(
                pair_index=pair_index,
                L_a=La,
                L_b=Lb,
                ratio_L=float(Lb / La),
                modes=mode_end,
                low_trace_actual=low_trace_actual,
                low_trace_MVT_bound=low_trace_bound,
                bound_over_actual=(
                    low_trace_bound / low_trace_actual
                    if np.isfinite(low_trace_bound) and low_trace_actual > 0
                    else np.inf
                ),
                maximum_abs_dE=float(d["abs_dE"].max()),
                maximum_abs_dlambda=float(d["abs_dlambda"].max()),
                maximum_deltaF_at_Ea=float(d["deltaF_at_Ea"].max()),
                minimum_sampled_Fprime=float(d["sampled_min_Fprime_b"].min()),
                minimum_safe_Fprime=float(d["safe_min_Fprime_b"].min()),
                F_difference_tail_allowance=float(F_delta_tail),
                derivative_tail_allowance_b=float(deriv_tail_b),
                all_root_MVT_bounds_pass=all_root_bounds,
                all_lambda_MVT_bounds_pass=all_lambda_bounds,
                all_safe_derivative_floors_positive=all_derivative_floors_positive,
            )
        )

        outer.set_postfix(
            trace=f"{low_trace_actual:.3e}",
            bound=(
                f"{low_trace_bound:.3e}"
                if np.isfinite(low_trace_bound)
                else "inf"
            ),
        )

        # Keep only one large arithmetic phase in memory between pairs.
        prev_phase = phase_b
        prev_L = Lb
        del phase_a

    mode_df = pd.DataFrame(mode_rows)
    pair_df = pd.DataFrame(pair_rows)

    Lfit = pair_df["L_a"].to_numpy(float)
    B_actual = pair_df["low_trace_actual"].to_numpy(float)
    B_bound = pair_df["low_trace_MVT_bound"].to_numpy(float)

    actual_fit = fit_power(Lfit, B_actual)
    bound_fit = fit_power(Lfit, B_bound)

    prospective_actual = prospective_envelope(
        Lfit,
        B_actual,
        holdout_pairs=int(args.holdout_pairs),
        envelope_safety=float(args.envelope_safety),
    )
    prospective_bound = prospective_envelope(
        Lfit,
        B_bound,
        holdout_pairs=int(args.holdout_pairs),
        envelope_safety=float(args.envelope_safety),
    )

    # Modewise decay fits.
    mode_fit_rows = []
    for k, g in mode_df.groupby("k"):
        fit_a = fit_power(
            g["L_a"].to_numpy(float),
            g["abs_dlambda"].to_numpy(float),
        )
        fit_b = fit_power(
            g["L_a"].to_numpy(float),
            g["dlambda_MVT_bound"].to_numpy(float),
        )
        mode_fit_rows.append(
            dict(
                k=int(k),
                actual_p=fit_a["p"],
                actual_r2=fit_a["r2"],
                bound_p=fit_b["p"],
                bound_r2=fit_b["r2"],
                latest_abs_dlambda=float(g.iloc[-1]["abs_dlambda"]),
                latest_dlambda_bound=float(g.iloc[-1]["dlambda_MVT_bound"]),
                signed_step_reversals=int(
                    np.sum(
                        np.sign(g["signed_dE"].to_numpy(float)[1:])
                        * np.sign(g["signed_dE"].to_numpy(float)[:-1])
                        < 0
                    )
                ),
            )
        )
    mode_fit_df = pd.DataFrame(mode_fit_rows)

    p_bound = float(bound_fit["p"])
    r2_bound = float(bound_fit["r2"])
    if np.isfinite(p_bound) and p_bound > 0 and np.isfinite(B_bound[-1]):
        ratio = float((chain[-1] / chain[-2]) ** (-p_bound))
        future_tail_est = (
            float(B_bound[-1] * ratio / (1.0 - ratio))
            if 0 < ratio < 1
            else np.inf
        )
    else:
        ratio = np.nan
        future_tail_est = np.inf

    gates = {
        "duplicate_roots_consistent": bool(
            roots_info.duplicate_max_spread <= args.duplicate_root_tol
        ),
        "all_safe_derivative_floors_positive": bool(
            pair_df["all_safe_derivative_floors_positive"].all()
        ),
        "all_root_MVT_bounds_pass": bool(
            pair_df["all_root_MVT_bounds_pass"].all()
        ),
        "all_lambda_MVT_bounds_pass": bool(
            pair_df["all_lambda_MVT_bounds_pass"].all()
        ),
        "low_mode_bound_power_positive": bool(
            np.isfinite(p_bound) and p_bound > args.power_p_gate
        ),
        "low_mode_bound_power_fit_stable": bool(
            np.isfinite(r2_bound) and r2_bound >= args.fit_r2_gate
        ),
    }

    if args.require_prospective_envelope:
        gates["prospective_bound_envelope_pass"] = bool(
            prospective_bound.get("available", False)
            and prospective_bound.get("all_holdouts_pass", False)
        )

    failed = [k for k, v in gates.items() if not v]
    verdict = (
        "LOW_MODE_CUTOFF_VARIATION_SUMMABILITY_STRONGLY_SUPPORTED"
        if not failed
        else "LOW_MODE_CUTOFF_VARIATION_THEOREM_TARGET_UNRESOLVED"
    )

    prefix = str(args.prefix)
    mode_path = Path(prefix + "_MODE_DETAIL.csv")
    pair_path = Path(prefix + "_PAIR_SUMMARY.csv")
    fit_path = Path(prefix + "_MODE_FITS.csv")
    summary_path = Path(prefix + "_SUMMARY.json")

    mode_df.to_csv(mode_path, index=False)
    pair_df.to_csv(pair_path, index=False)
    mode_fit_df.to_csv(fit_path, index=False)

    summary = {
        "version": VERSION,
        "verdict": verdict,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
        },
        "input_files": [
            {
                "path": str(p),
                "sha256": sha256_file(p),
            }
            for p in args.root_files
        ],
        "modules": {
            "v102_module": args.v102_module,
            "base_module": args.base_module,
        },
        "tail_method": {
            "prime_phase_tail": "exact sqrt(pi L) erfc(sqrt(N/L)) plus lattice, divided by pi",
            "counterterm_tail": "exact sqrt(pi L) erfc(sqrt(xmax/L))",
            "prime_derivative_tail": "closed concavity upper bound with upper incomplete gamma plus lattice",
            "improper_numerical_quad_used_for_tail_bounds": False,
        },
        "cutoff_chain": chain,
        "low_mode_end": mode_end,
        "duplicate_root_count": roots_info.duplicate_count,
        "duplicate_root_max_spread": roots_info.duplicate_max_spread,
        "parameters": {
            "tail_factor": args.tail_factor,
            "counter_q": args.counter_q,
            "segment_samples": args.segment_samples,
            "segment_min_width": args.segment_min_width,
            "derivative_floor_safety": args.derivative_floor_safety,
            "bound_slack": args.bound_slack,
            "power_p_gate": args.power_p_gate,
            "fit_r2_gate": args.fit_r2_gate,
            "holdout_pairs": args.holdout_pairs,
            "envelope_safety": args.envelope_safety,
        },
        "low_mode_trace_actual_fit": actual_fit,
        "low_mode_trace_MVT_bound_fit": bound_fit,
        "prospective_actual_envelope": prospective_actual,
        "prospective_bound_envelope": prospective_bound,
        "latest_pair": json_safe(pair_rows[-1]),
        "fitted_next_block_ratio_from_bound": ratio,
        "estimated_remaining_dyadic_low_mode_variation_after_latest_cutoff": future_tail_est,
        "gates": gates,
        "failed_gates": failed,
        "theorem_target": (
            "For a fixed finite low-mode block k<=K0, prove a summable dyadic "
            "bound on root motion from the finite-part phase remainder and a "
            "uniform positive derivative floor. Combine this with a rigorous "
            "high-k trace tail to obtain sum_j ||K_{2L_j}-K_{L_j}||_1 < infinity."
        ),
        "proof_status": (
            "NOT A PROOF. The sampled derivative floor and empirical L-decay "
            "still require analytic certification. A PASS isolates the remaining "
            "mathematics: rigorous derivative monotonicity plus a high-k tail theorem."
        ),
        "runtime_seconds": time.perf_counter() - started,
        "outputs": {
            "mode_detail": str(mode_path),
            "pair_summary": str(pair_path),
            "mode_fits": str(fit_path),
            "summary": str(summary_path),
        },
    }
    summary_path.write_text(
        json.dumps(json_safe(summary), indent=2),
        encoding="utf-8",
    )

    print()
    print("=" * 150)
    print("v228 CLOSED-TAIL CUTOFF-INDEPENDENCE SUMMARY")
    print("=" * 150)
    print("cutoff chain                       :", chain)
    print("low modes                          : 1..%d" % mode_end)
    print("all MVT root bounds pass           :", gates["all_root_MVT_bounds_pass"])
    print("all MVT lambda bounds pass         :", gates["all_lambda_MVT_bounds_pass"])
    print("safe derivative floors positive    :", gates["all_safe_derivative_floors_positive"])
    print()
    print(
        "actual low-mode trace fit          : "
        f"p={actual_fit['p']:.6g}, R2={actual_fit['r2']:.6g}"
    )
    print(
        "MVT-bound low-mode trace fit       : "
        f"p={bound_fit['p']:.6g}, R2={bound_fit['r2']:.6g}"
    )
    print(
        "fitted next-block bound ratio      : "
        + (f"{ratio:.6g}" if np.isfinite(ratio) else "n/a")
    )
    print(
        "remaining dyadic low-mode variation: "
        + (
            f"{future_tail_est:.6e}"
            if np.isfinite(future_tail_est)
            else "UNRESOLVED"
        )
    )
    if prospective_bound.get("available", False):
        print(
            "prospective bound envelope         : "
            + ("PASS" if prospective_bound["all_holdouts_pass"] else "FAIL")
        )
    else:
        print("prospective bound envelope         : unavailable")
    print()
    print("FAILED GATES                       :", failed if failed else "none")
    print("NUMERICAL VERDICT                  :", verdict)
    print("PROOF VERDICT                      : OPEN")
    print("=" * 150)
    print("Files written:")
    for p in [mode_path, pair_path, fit_path, summary_path]:
        print(" ", p)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
