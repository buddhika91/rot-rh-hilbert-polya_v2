#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v243 — ENERGY-TRANSPORT TOTAL-VARIATION / LOCAL-MVT AUTOPSY
==================================================================

Zero-cost postprocessor of v242.

v242 found that the total energy-transport correction is small, but the sum of
sampled absolute MVT bounds can overestimate that correction badly.

v243 distinguishes two mechanisms:

A) LOCAL MVT LOSS
   The actual transport terms themselves have little cancellation:
       sum |tau_j| ~ max_n |sum_{r<=n} tau_r|.
   Then the signed transport theorem is unnecessary. The problem is merely to
   sharpen each local interval estimate.

B) GLOBAL SIGNED TRANSPORT
   The actual transport terms have large total variation but a small primitive:
       sum |tau_j| >> max_n |sum_{r<=n} tau_r|.
   Then a second summation-by-parts / Dirichlet lemma is genuinely needed.

Inputs
------
* v242 TRANSPORT_TERMS.csv
* v242 MODES.csv

No Xi, zeta values, known zero ordinates, prime sums, or root solves.

Version: 243
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 243
EPS = np.finfo(float).eps


def sign_changes(x, tol=1e-15):
    x = np.asarray(x, float)
    s = np.sign(x[np.abs(x) > tol])
    if len(s) < 2:
        return 0
    return int(np.sum(s[1:] * s[:-1] < 0))


def main():
    p = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    p.add_argument(
        "--transport-terms",
        default="rot_rh_single_regulator_pnt_transport_v242_TRANSPORT_TERMS.csv",
    )
    p.add_argument(
        "--v242-modes",
        default="rot_rh_single_regulator_pnt_transport_v242_MODES.csv",
    )
    p.add_argument(
        "--v242-summary",
        default="rot_rh_single_regulator_pnt_transport_v242_SUMMARY.json",
    )

    # Descriptive mechanism thresholds.
    p.add_argument(
        "--local-variation-ratio-gate",
        type=float,
        default=1.50,
        help="sum|tau| / max|cumulative tau| below this means little global cancellation.",
    )
    p.add_argument(
        "--strong-signed-ratio-gate",
        type=float,
        default=3.00,
        help="ratio above this signals strong global signed cancellation.",
    )
    p.add_argument(
        "--absolute-transport-over-moving-gate",
        type=float,
        default=0.50,
        help="Whether actual total variation is still perturbative relative to moving PNT primitive.",
    )
    p.add_argument(
        "--prefix",
        default="rot_rh_energy_transport_variation_autopsy_v243",
    )
    p.add_argument("--strict", action="store_true")
    args = p.parse_args()

    terms = pd.read_csv(args.transport_terms)
    modes242 = pd.read_csv(args.v242_modes)

    need_t = {
        "k", "step_index", "L",
        "delta_E", "actual_transport_term",
        "sampled_MVT_bound", "actual_over_MVT",
    }
    need_m = {
        "k",
        "max_abs_moving_PNT_primitive",
        "max_abs_total_transport",
        "max_sampled_absolute_MVT_transport_sum",
    }
    mt = need_t - set(terms.columns)
    mm = need_m - set(modes242.columns)
    if mt:
        raise KeyError(f"transport terms missing {sorted(mt)}")
    if mm:
        raise KeyError(f"v242 modes missing {sorted(mm)}")

    for c in ("k", "step_index", "L"):
        terms[c] = terms[c].astype(int)
    modes242["k"] = modes242["k"].astype(int)

    rows = []
    prefix_rows = []

    for k, g in tqdm(
        list(terms.groupby("k", sort=True)),
        desc="Transport variation by mode",
        unit="k",
    ):
        g = g.sort_values("step_index").copy()

        tau = g["actual_transport_term"].to_numpy(float)
        mvt = g["sampled_MVT_bound"].to_numpy(float)
        dE = g["delta_E"].to_numpy(float)

        cumulative = np.cumsum(tau)
        cumulative_abs_mvt = np.cumsum(mvt)
        cumulative_abs_tau = np.cumsum(np.abs(tau))

        total_var = float(np.sum(np.abs(tau)))
        max_exc = float(np.max(np.abs(cumulative))) if len(tau) else 0.0
        final_net = float(cumulative[-1]) if len(tau) else 0.0
        mvt_total = float(np.sum(mvt))

        variation_ratio = total_var / max(max_exc, EPS)
        mvt_over_total_var = mvt_total / max(total_var, EPS)

        mrow = modes242[modes242["k"] == int(k)]
        if len(mrow) != 1:
            raise RuntimeError(f"k={k}: expected one v242 mode row")
        moving_scale = float(
            mrow["max_abs_moving_PNT_primitive"].iloc[0]
        )

        abs_transport_over_moving = (
            total_var / max(moving_scale, EPS)
        )
        max_exc_over_moving = (
            max_exc / max(moving_scale, EPS)
        )

        # How much of the MVT loss is local?
        term_ratios = (
            mvt / np.maximum(np.abs(tau), EPS)
        )
        finite_ratio = term_ratios[np.isfinite(term_ratios)]

        rows.append({
            "k": int(k),
            "terms": int(len(g)),
            "L_start": int(g["L"].iloc[0]) if len(g) else -1,
            "L_end": int(g["L"].iloc[-1]) if len(g) else -1,
            "sum_abs_actual_transport": total_var,
            "max_abs_transport_primitive": max_exc,
            "final_signed_transport": final_net,
            "actual_total_variation_over_excursion": variation_ratio,
            "sum_sampled_MVT_bounds": mvt_total,
            "MVT_sum_over_actual_total_variation": mvt_over_total_var,
            "median_term_MVT_over_actual": (
                float(np.median(finite_ratio))
                if len(finite_ratio) else np.nan
            ),
            "maximum_term_MVT_over_actual": (
                float(np.max(finite_ratio))
                if len(finite_ratio) else np.nan
            ),
            "transport_sign_changes": sign_changes(tau),
            "deltaE_sign_changes": sign_changes(dE),
            "actual_total_variation_over_moving_PNT": (
                abs_transport_over_moving
            ),
            "max_transport_excursion_over_moving_PNT": (
                max_exc_over_moving
            ),
        })

        for i, r in enumerate(g.itertuples(index=False)):
            prefix_rows.append({
                "k": int(k),
                "step_index": int(r.step_index),
                "L": int(r.L),
                "delta_E": float(r.delta_E),
                "transport_term": float(tau[i]),
                "transport_primitive": float(cumulative[i]),
                "absolute_transport_variation_prefix": float(
                    cumulative_abs_tau[i]
                ),
                "absolute_MVT_prefix": float(
                    cumulative_abs_mvt[i]
                ),
                "MVT_over_actual_term": float(
                    mvt[i] / max(abs(tau[i]), EPS)
                ),
            })

    modes = pd.DataFrame(rows)
    prefixes = pd.DataFrame(prefix_rows)

    ratios = modes[
        "actual_total_variation_over_excursion"
    ].to_numpy(float)
    abs_over_moving = modes[
        "actual_total_variation_over_moving_PNT"
    ].to_numpy(float)

    max_variation_ratio = float(np.max(ratios))
    median_variation_ratio = float(np.median(ratios))
    max_abs_over_moving = float(np.max(abs_over_moving))
    median_local_mvt_loss = float(
        modes["MVT_sum_over_actual_total_variation"].median()
    )

    if (
        max_variation_ratio <= args.local_variation_ratio_gate
        and max_abs_over_moving
        <= args.absolute_transport_over_moving_gate
    ):
        mechanism = (
            "TRANSPORT_ABSOLUTELY_PERTURBATIVE_LOCAL_MVT_LOSS_DOMINATES"
        )
    elif (
        median_variation_ratio
        >= args.strong_signed_ratio_gate
    ):
        mechanism = "TRANSPORT_REQUIRES_GLOBAL_SIGNED_CANCELLATION"
    else:
        mechanism = "TRANSPORT_VARIATION_MECHANISM_MIXED"

    # Identity-style sanity check: v242's stored max transport excursion should
    # agree with our cumulative transport on the interior correction to the
    # extent that the same quantity is represented. This is diagnostic only,
    # because v242 total transport also included terminal energy shift.
    v242_summary = None
    if Path(args.v242_summary).exists():
        v242_summary = json.loads(
            Path(args.v242_summary).read_text(encoding="utf-8")
        )

    gates = {
        "all_transport_terms_finite": bool(
            np.all(np.isfinite(
                terms["actual_transport_term"].to_numpy(float)
            ))
        ),
        "all_MVT_bounds_finite": bool(
            np.all(np.isfinite(
                terms["sampled_MVT_bound"].to_numpy(float)
            ))
        ),
    }
    failed = [name for name, ok in gates.items() if not ok]

    verdict = (
        "ENERGY_TRANSPORT_VARIATION_ANATOMY_VERIFIED"
        if not failed
        else
        "ENERGY_TRANSPORT_VARIATION_DATA_FAILURE"
    )

    prefix = args.prefix
    modes_path = Path(prefix + "_MODES.csv")
    prefixes_path = Path(prefix + "_PREFIXES.csv.gz")
    summary_path = Path(prefix + "_SUMMARY.json")
    theorem_path = Path(prefix + "_NEXT_THEOREM.md")

    modes.to_csv(modes_path, index=False)
    prefixes.to_csv(
        prefixes_path, index=False, compression="gzip"
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_values_used": False,
            "known_zero_ordinates_used": False,
            "prime_rebuild": False,
            "root_solves": False,
        },
        "aggregate": {
            "maximum_total_variation_over_excursion": (
                max_variation_ratio
            ),
            "median_total_variation_over_excursion": (
                median_variation_ratio
            ),
            "maximum_actual_total_variation_over_moving_PNT": (
                max_abs_over_moving
            ),
            "median_MVT_sum_over_actual_total_variation": (
                median_local_mvt_loss
            ),
            "mechanism": mechanism,
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "proof_status": (
            "OPEN. v243 determines whether the small energy-transport "
            "correction needs a global signed theorem or only sharper "
            "local interval bounds."
        ),
    }
    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    if mechanism == (
        "TRANSPORT_ABSOLUTELY_PERTURBATIVE_LOCAL_MVT_LOSS_DOMINATES"
    ):
        next_text = (
            "# v243 next theorem target\n\n"
            "The actual transport terms have little global cancellation and "
            "their total variation is perturbative relative to the main PNT "
            "primitive. No second Dirichlet theorem is indicated. Replace the "
            "coarse sampled MVT bound by a local Taylor enclosure for each "
            "`T_L(E_prev)-T_L(E_cur)`, then focus the hard analysis on the "
            "fixed-frequency endpoint PNT transform.\n"
        )
    elif mechanism == "TRANSPORT_REQUIRES_GLOBAL_SIGNED_CANCELLATION":
        next_text = (
            "# v243 next theorem target\n\n"
            "The actual transport terms have large total variation but a small "
            "signed primitive. A second summation-by-parts/Dirichlet lemma is "
            "genuinely needed for the energy-transport sequence before the "
            "fixed-frequency endpoint theorem can stand alone.\n"
        )
    else:
        next_text = (
            "# v243 next theorem target\n\n"
            "Transport behavior is mixed across modes. Inspect the mode table "
            "before choosing between local Taylor enclosure and a global signed "
            "transport theorem.\n"
        )
    theorem_path.write_text(next_text, encoding="utf-8")

    print("=" * 184)
    print(
        "ROT-RH v243 — ENERGY-TRANSPORT TOTAL-VARIATION / "
        "LOCAL-MVT AUTOPSY"
    )
    print("=" * 184)
    print("Xi / zeta / known-zero data        : NONE")
    print("prime rebuild / root solves         : NONE / NONE")
    print()
    print("MODE ANATOMY")
    print("-" * 184)
    for r in rows:
        print(
            f"k={r['k']:>4d} "
            f"TV={r['sum_abs_actual_transport']:.3e} "
            f"exc={r['max_abs_transport_primitive']:.3e} "
            f"TV/exc={r['actual_total_variation_over_excursion']:.3f} "
            f"MVT/TV={r['MVT_sum_over_actual_total_variation']:.3f} "
            f"TV/Pmov={r['actual_total_variation_over_moving_PNT']:.3f} "
            f"signChanges={r['transport_sign_changes']}"
        )
    print()
    print("AGGREGATE")
    print("-" * 184)
    print(
        "maximum actual TV / excursion      : "
        f"{max_variation_ratio:.6f}"
    )
    print(
        "median actual TV / excursion       : "
        f"{median_variation_ratio:.6f}"
    )
    print(
        "maximum actual TV / moving PNT     : "
        f"{max_abs_over_moving:.6f}"
    )
    print(
        "median MVT sum / actual TV         : "
        f"{median_local_mvt_loss:.6f}"
    )
    print(f"MECHANISM                           : {mechanism}")
    print()
    print("=" * 184)
    print("FAILED GATES                        :", failed if failed else "none")
    print("VERDICT                             :", verdict)
    print("PROOF VERDICT                       : OPEN")
    print("=" * 184)
    print("Files written:")
    for path in (
        modes_path, prefixes_path, summary_path, theorem_path
    ):
        print(" ", path)

    if args.strict and failed:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
