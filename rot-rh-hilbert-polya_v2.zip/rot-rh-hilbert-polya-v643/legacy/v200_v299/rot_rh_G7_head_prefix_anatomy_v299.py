#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v299 — G7 FINITE-HEAD PHASE-PREFIX ANATOMY AUDIT
========================================================

Purpose
-------
v298 prospectively supported the renormalized block-7 packet mechanism

    P_r = R^(7r) G7,

with scale-covariant ratios

    Q_r(lambda)
      = ||P_(r+1)||_(pref,lambda*s_(r+1))
        / ||P_r||_(pref,lambda*s_r)

well below 1 on both new scale and new depth holdouts.

That result suggests the infinite recursive tail is not the dominant numerical
obstruction.  The head packet

    G7 = F0 + R F0 + ... + R^6 F0

carries essentially the whole observed physical prefix.

The next theorem question is therefore:

    Is G7 prefix bounded because each of its seven layers is separately
    tame, or because large layer prefixes cancel only after summation?

This script dissects that finite head exactly.

Definitions
-----------
Let

    u_j = R^j F0,     j=0,...,6,

and cumulative heads

    H_h = sum_(j=0)^h u_j,     h=0,...,6.

Then H_6=G7.

For the fixed arithmetic anchor E*, define

    S_j(N)
      = max_(M<=N) |sum_(n<=M) u_j(n)e^(iE*log n)|,

and

    C_h(N)
      = max_(M<=N) |sum_(n<=M) H_h(n)e^(iE*log n)|.

The script also finds the actual prefix location M*(N) where G7 attains its
maximum and resolves the seven complex layer vectors at that SAME M*.  This
distinguishes genuine inter-layer cancellation from merely different maxima
occurring at different M.

Prospective design
------------------
No arithmetic frontier extension is used.

Default:
    DEVELOPMENT N = 524288,1048576,2097152
    HOLDOUT     N = 4194304,8388608

For each individual layer and each cumulative head, freeze a DEVELOPMENT
constant

    bound = safety * max_DEVELOPMENT prefix_sup

and test it on the new N holdouts.

These finite bounds are diagnostic only.  A holdout pass does not prove an
all-N theorem.

Interpretation
--------------
A. If F0 alone carries nearly all of G7 and passes the holdout:
       the analytic target collapses toward a prefix theorem for F0, with
       R F0,...,R^6F0 treated as finite corrections.

B. If individual layers are large but cumulative G7 is small:
       the final theorem must preserve exact cancellation among the seven
       layers; triangle-inequality proofs will be too weak.

C. If every individual layer has a stable small prefix:
       a seven-term finite-head theorem is plausible, after which v298 gives
       the recursive-tail architecture.

No Xi, zeta values, zeta'/zeta values, or known zero ordinates are used.

Dependencies:
    numpy, pandas, tqdm, numba

Version: 299
"""

from __future__ import annotations

import argparse
import gc
import importlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 299


def parse_ints(text):
    return [
        int(x.strip())
        for x in str(text).split(",")
        if x.strip()
    ]


def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--anchors",
        default="rot_rh_joint_kN_global_prefix_holdout_v256_ANCHORS.csv",
    )
    ap.add_argument("--anchor-k", type=int, default=8192)

    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )

    ap.add_argument(
        "--N-checkpoints",
        default="524288,1048576,2097152,4194304,8388608",
    )
    ap.add_argument(
        "--development-N-max",
        type=int,
        default=2097152,
    )

    ap.add_argument(
        "--head-layers",
        type=int,
        default=7,
    )

    ap.add_argument(
        "--layer-bound-safety",
        type=float,
        default=1.35,
    )
    ap.add_argument(
        "--cumulative-bound-safety",
        type=float,
        default=1.35,
    )

    ap.add_argument(
        "--support-tol",
        type=float,
        default=1e-15,
    )
    ap.add_argument(
        "--identity-tol",
        type=float,
        default=3e-10,
    )

    ap.add_argument(
        "--v298-summary",
        default="rot_rh_R7_renormalized_packet_scale_v298_SUMMARY.json",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_G7_head_prefix_anatomy_v299",
    )

    ap.add_argument("--strict", action="store_true")

    args = ap.parse_args()
    started = time.perf_counter()

    if int(args.head_layers) != 7:
        raise ValueError(
            "v299 freezes the seven-layer head G7."
        )

    if not (
        float(args.layer_bound_safety) > 1.0
        and float(args.cumulative_bound_safety) > 1.0
    ):
        raise ValueError("Safety factors must exceed 1.")

    checkpoints = sorted(
        set(parse_ints(args.N_checkpoints))
    )

    development = [
        N for N in checkpoints
        if N <= int(args.development_N_max)
    ]

    holdout = [
        N for N in checkpoints
        if N > int(args.development_N_max)
    ]

    if not development or not holdout:
        raise ValueError(
            "Need DEVELOPMENT and HOLDOUT checkpoints"
        )

    Nmax = max(checkpoints)

    try:
        from numba import njit
    except Exception as exc:
        raise RuntimeError(
            "v299 requires numba.\n"
            "Install with:\n\n"
            "    pip install numba\n\n"
            f"Import error: {exc}"
        )

    # ------------------------------------------------------------------
    # Anchor
    # ------------------------------------------------------------------

    anchors = pd.read_csv(args.anchors)

    if not {"k", "E_anchor"}.issubset(anchors.columns):
        raise KeyError(
            "anchors file must contain k,E_anchor"
        )

    anchors["k"] = anchors["k"].astype(int)

    hit = anchors[
        anchors["k"] == int(args.anchor_k)
    ]

    if len(hit) != 1:
        raise RuntimeError(
            f"Expected one anchor k={args.anchor_k}"
        )

    E = float(hit["E_anchor"].iloc[0])

    base = importlib.import_module(
        args.base_module
    )

    # ------------------------------------------------------------------
    # JIT helpers
    # ------------------------------------------------------------------

    @njit(cache=True)
    def build_spf(N):
        spf = np.arange(N + 1, dtype=np.int32)
        spf[0] = 0

        if N >= 1:
            spf[1] = 1

        root = int(math.sqrt(N))

        for p in range(2, root + 1):
            if spf[p] != p:
                continue

            for n in range(p * p, N + 1, p):
                if spf[n] == n:
                    spf[n] = p

        return spf

    @njit(cache=True)
    def selberg_factor_stats(spf):
        N = len(spf) - 1

        tau = np.ones(N + 1, dtype=np.int32)
        omega = np.zeros(N + 1, dtype=np.uint8)
        exponent = np.zeros(N + 1, dtype=np.uint8)
        distinct_log_sum = np.zeros(
            N + 1,
            dtype=np.float64,
        )
        g = np.zeros(N + 1, dtype=np.float64)

        for n in range(2, N + 1):
            p = int(spf[n])
            r = n // p
            lp = math.log(p)

            if r > 1 and r % p == 0:
                old_e = int(exponent[r])
                new_e = old_e + 1

                exponent[n] = new_e
                omega[n] = omega[r]
                distinct_log_sum[n] = (
                    distinct_log_sum[r]
                )

                tau[n] = (
                    tau[r]
                    // (old_e + 1)
                    * (new_e + 1)
                )

                if omega[n] == 1:
                    g[n] = (
                        (2 * new_e - 1)
                        * lp
                        * lp
                    )
                else:
                    g[n] = g[r]
            else:
                exponent[n] = 1
                omega[n] = omega[r] + 1
                distinct_log_sum[n] = (
                    distinct_log_sum[r] + lp
                )
                tau[n] = tau[r] * 2

                if omega[r] == 0:
                    g[n] = lp * lp
                elif omega[r] == 1:
                    g[n] = (
                        2.0
                        * lp
                        * distinct_log_sum[r]
                    )
                else:
                    g[n] = 0.0

        return tau, g

    @njit(cache=True)
    def apply_Klambda_from(
        u,
        lam,
        logs,
        N,
        d_start,
    ):
        out = np.zeros(N + 1, dtype=np.float64)

        lo = max(2, int(d_start))

        for d in range(lo, N // 2 + 1):
            ud = u[d]

            if ud == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                lk = lam[k]

                if lk == 0.0:
                    continue

                n = k * d

                out[n] -= (
                    (lk / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * ud
                )

        return out

    @njit(cache=True)
    def solve_I_minus_Kb_from(
        v,
        logs,
        N,
        d_start,
    ):
        y = v.copy()

        lo = max(2, int(d_start))

        for d in range(lo, N // 2 + 1):
            yd = y[d]

            if yd == 0.0:
                continue

            ld = logs[d]
            dmax = N // d

            for k in range(2, dmax + 1):
                n = k * d

                y[n] -= (
                    (1.0 / math.sqrt(k))
                    * ld
                    / (logs[n] * logs[n])
                    * yd
                )

        return y

    @njit(cache=True)
    def apply_R_from(
        u,
        lam,
        logs,
        N,
        d_start,
    ):
        tmp = apply_Klambda_from(
            u,
            lam,
            logs,
            N,
            d_start,
        )

        return solve_I_minus_Kb_from(
            tmp,
            logs,
            N,
            max(2, 2 * int(d_start)),
        )

    @njit(cache=True)
    def prefix_summary_checkpoints(
        u,
        phase_re,
        phase_im,
        checkpoints,
        N,
    ):
        """
        For each checkpoint return:
          prefix sup,
          location of prefix sup,
          complex prefix at the checkpoint.
        """
        count = len(checkpoints)

        sup_out = np.zeros(count, dtype=np.float64)
        argmax_out = np.zeros(count, dtype=np.int64)
        end_re = np.zeros(count, dtype=np.float64)
        end_im = np.zeros(count, dtype=np.float64)

        zr = 0.0
        zi = 0.0
        smax = 0.0
        imax = 1
        ci = 0

        for n in range(2, N + 1):
            un = u[n]

            if un != 0.0:
                zr += un * phase_re[n]
                zi += un * phase_im[n]

            a = math.sqrt(zr * zr + zi * zi)

            if a > smax:
                smax = a
                imax = n

            while (
                ci < count
                and n >= checkpoints[ci]
            ):
                sup_out[ci] = smax
                argmax_out[ci] = imax
                end_re[ci] = zr
                end_im[ci] = zi
                ci += 1

        while ci < count:
            sup_out[ci] = smax
            argmax_out[ci] = imax
            end_re[ci] = zr
            end_im[ci] = zi
            ci += 1

        return (
            sup_out,
            argmax_out,
            end_re,
            end_im,
        )

    @njit(cache=True)
    def complex_prefix_at_queries(
        u,
        phase_re,
        phase_im,
        queries,
        N,
    ):
        out_re = np.zeros(
            len(queries),
            dtype=np.float64,
        )
        out_im = np.zeros(
            len(queries),
            dtype=np.float64,
        )

        zr = 0.0
        zi = 0.0
        qi = 0

        for n in range(2, N + 1):
            un = u[n]

            if un != 0.0:
                zr += un * phase_re[n]
                zi += un * phase_im[n]

            while (
                qi < len(queries)
                and n >= queries[qi]
            ):
                out_re[qi] = zr
                out_im[qi] = zi
                qi += 1

        while qi < len(queries):
            out_re[qi] = zr
            out_im[qi] = zi
            qi += 1

        return out_re, out_im

    @njit(cache=True)
    def first_support_from(
        u,
        tol,
        start,
    ):
        N = len(u) - 1

        for n in range(max(2, int(start)), N + 1):
            if abs(u[n]) > tol:
                return n

        return -1

    # ------------------------------------------------------------------
    # Banner
    # ------------------------------------------------------------------

    print("=" * 216)
    print(
        "ROT-RH v299 — G7 FINITE-HEAD PHASE-PREFIX ANATOMY AUDIT"
    )
    print("=" * 216)
    print(
        "Xi / zeta / known-zero data         : NONE"
    )
    print(
        f"anchor k                             : {args.anchor_k}"
    )
    print(
        f"anchor E                             : {E:.15f}"
    )
    print(
        "head                                 : G7=sum_(j=0)^6 R^j F0"
    )
    print(
        f"DEVELOPMENT N                        : {development}"
    )
    print(
        f"NEW HOLDOUT N                        : {holdout}"
    )
    print(
        f"maximum arithmetic N                 : {Nmax:,}"
    )
    print("=" * 216)

    # ------------------------------------------------------------------
    # Arithmetic
    # ------------------------------------------------------------------

    print(f"[1] Arithmetic through N={Nmax:,}")

    numbers, lambdas, _ = base.mangoldt_terms(Nmax)

    numbers = np.asarray(numbers, dtype=np.int64)
    lambdas = np.asarray(lambdas, dtype=np.float64)

    lam = np.zeros(Nmax + 1, dtype=np.float64)
    lam[numbers] = lambdas

    del numbers, lambdas
    gc.collect()

    logs = np.zeros(Nmax + 1, dtype=np.float64)

    nf = np.arange(
        2,
        Nmax + 1,
        dtype=np.float64,
    )

    logs[2:] = np.log(nf)

    sqrt_n = np.ones(
        Nmax + 1,
        dtype=np.float64,
    )
    sqrt_n[2:] = np.sqrt(nf)

    phase_re = np.ones(
        Nmax + 1,
        dtype=np.float64,
    )
    phase_im = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    theta = np.remainder(
        E * logs[2:],
        2.0 * math.pi,
    )

    phase_re[2:] = np.cos(theta)
    phase_im[2:] = np.sin(theta)

    del theta

    # ------------------------------------------------------------------
    # F0 / x
    # ------------------------------------------------------------------

    print("[2] Exact Selberg forcing / preconditioner")

    spf = build_spf(Nmax)
    tau, g = selberg_factor_stats(spf)

    del spf
    gc.collect()

    F = np.zeros(Nmax + 1, dtype=np.float64)

    F[2:] = (
        (
            g[2:]
            - logs[2:]
            - (
                tau[2:].astype(np.float64)
                - 2.0
            )
        )
        / (
            sqrt_n[2:]
            * logs[2:]
            * logs[2:]
        )
    )

    x_true = np.zeros(
        Nmax + 1,
        dtype=np.float64,
    )

    x_true[2:] = (
        (lam[2:] - 1.0)
        / (
            sqrt_n[2:]
            * logs[2:]
        )
    )

    del tau, g
    del sqrt_n, nf
    gc.collect()

    warmN = min(Nmax, 64)

    _ = solve_I_minus_Kb_from(
        F[:warmN + 1],
        logs[:warmN + 1],
        warmN,
        2,
    )

    F0 = solve_I_minus_Kb_from(
        F,
        logs,
        Nmax,
        2,
    )

    del F
    gc.collect()

    Rx = apply_R_from(
        x_true,
        lam,
        logs,
        Nmax,
        2,
    )

    fixed_point_error = float(
        np.max(
            np.abs(
                x_true[2:]
                - (
                    F0[2:]
                    + Rx[2:]
                )
            )
        )
    )

    del Rx
    gc.collect()

    # ------------------------------------------------------------------
    # Seven exact layers
    # ------------------------------------------------------------------

    print("[3] Build u_j=R^j F0, j=0..6")

    layers = []
    support_rows = []

    u = F0.copy()
    support_start = 2

    for j in tqdm(
        range(7),
        desc="G7 head layers",
        unit="layer",
    ):
        layers.append(u.copy())

        expected = int(
            2 ** (j + 1)
        )

        actual = first_support_from(
            u,
            float(args.support_tol),
            min(expected, Nmax),
        )

        support_rows.append({
            "layer": int(j),
            "expected_support_min": expected,
            "actual_support_min": int(actual),
            "support_pass": bool(
                actual < 0
                or actual >= expected
            ),
        })

        if j < 6:
            u = apply_R_from(
                u,
                lam,
                logs,
                Nmax,
                support_start,
            )
            support_start *= 2

    del u, F0
    gc.collect()

    support_df = pd.DataFrame(support_rows)
    support_pass = bool(
        support_df["support_pass"].all()
    )

    # ------------------------------------------------------------------
    # Cumulative heads
    # ------------------------------------------------------------------

    print("[4] Build cumulative H_h and verify G7 identity")

    cumulative = []
    run = np.zeros_like(x_true)

    for j in range(7):
        run = run + layers[j]
        cumulative.append(run.copy())

    G7 = cumulative[-1]

    # Verify block identity x=G7+R^7x.
    R7x = x_true.copy()
    support_start = 2

    for _ in tqdm(
        range(7),
        desc="R^7 x identity",
        unit="power",
    ):
        R7x = apply_R_from(
            R7x,
            lam,
            logs,
            Nmax,
            support_start,
        )
        support_start *= 2

    block_identity_error = float(
        np.max(
            np.abs(
                x_true[2:]
                - (
                    G7[2:]
                    + R7x[2:]
                )
            )
        )
    )

    del R7x
    gc.collect()

    # ------------------------------------------------------------------
    # Prefix summaries
    # ------------------------------------------------------------------

    print("[5] Individual / cumulative prefix scans")

    checkpoint_arr = np.asarray(
        checkpoints,
        dtype=np.int64,
    )

    layer_rows = []
    cumulative_rows = []

    layer_summaries = {}
    cumulative_summaries = {}

    for j in tqdm(
        range(7),
        desc="individual layer prefixes",
        unit="layer",
    ):
        vals = prefix_summary_checkpoints(
            layers[j],
            phase_re,
            phase_im,
            checkpoint_arr,
            Nmax,
        )

        layer_summaries[j] = vals

        supv, argv, endr, endi = vals

        for i, N in enumerate(checkpoints):
            layer_rows.append({
                "layer": int(j),
                "N": int(N),
                "region": (
                    "DEVELOPMENT"
                    if N <= int(args.development_N_max)
                    else "HOLDOUT"
                ),
                "prefix_sup": float(supv[i]),
                "argmax_M": int(argv[i]),
                "endpoint_real": float(endr[i]),
                "endpoint_imag": float(endi[i]),
                "endpoint_abs": float(
                    math.hypot(endr[i], endi[i])
                ),
            })

    for h in tqdm(
        range(7),
        desc="cumulative head prefixes",
        unit="head",
    ):
        vals = prefix_summary_checkpoints(
            cumulative[h],
            phase_re,
            phase_im,
            checkpoint_arr,
            Nmax,
        )

        cumulative_summaries[h] = vals

        supv, argv, endr, endi = vals

        for i, N in enumerate(checkpoints):
            cumulative_rows.append({
                "head_depth": int(h),
                "N": int(N),
                "region": (
                    "DEVELOPMENT"
                    if N <= int(args.development_N_max)
                    else "HOLDOUT"
                ),
                "prefix_sup": float(supv[i]),
                "argmax_M": int(argv[i]),
                "endpoint_real": float(endr[i]),
                "endpoint_imag": float(endi[i]),
                "endpoint_abs": float(
                    math.hypot(endr[i], endi[i])
                ),
            })

    layer_df = pd.DataFrame(layer_rows)
    cumulative_df = pd.DataFrame(cumulative_rows)

    # ------------------------------------------------------------------
    # Same-M vector attribution at G7 maximum
    # ------------------------------------------------------------------

    print("[6] Same-M complex vector attribution at G7 maxima")

    Gsup, Garg, _, _ = cumulative_summaries[6]

    query_M = sorted(
        set(
            int(x)
            for x in Garg.tolist()
        )
    )

    query_arr = np.asarray(
        query_M,
        dtype=np.int64,
    )

    query_index = {
        int(M): i
        for i, M in enumerate(query_M)
    }

    layer_query_vectors = {}

    for j in tqdm(
        range(7),
        desc="same-M layer vectors",
        unit="layer",
    ):
        rr, ii = complex_prefix_at_queries(
            layers[j],
            phase_re,
            phase_im,
            query_arr,
            Nmax,
        )

        layer_query_vectors[j] = (
            rr,
            ii,
        )

    attribution_rows = []

    for i, N in enumerate(checkpoints):
        M = int(Garg[i])
        qi = query_index[M]

        vecs = []

        zr = 0.0
        zi = 0.0
        abs_budget = 0.0

        for j in range(7):
            rr, ii = layer_query_vectors[j]
            zjr = float(rr[qi])
            zji = float(ii[qi])
            zja = float(math.hypot(zjr, zji))

            zr += zjr
            zi += zji
            abs_budget += zja

            vecs.append(
                (zjr, zji, zja)
            )

        total_abs = float(
            math.hypot(zr, zi)
        )

        cancellation_factor = float(
            abs_budget
            / max(total_abs, 1e-300)
        )

        f0_fraction = float(
            vecs[0][2]
            / max(total_abs, 1e-300)
        )

        later_budget_fraction = float(
            sum(v[2] for v in vecs[1:])
            / max(total_abs, 1e-300)
        )

        for j, (zjr, zji, zja) in enumerate(vecs):
            attribution_rows.append({
                "N": int(N),
                "region": (
                    "DEVELOPMENT"
                    if N <= int(args.development_N_max)
                    else "HOLDOUT"
                ),
                "G7_argmax_M": M,
                "G7_prefix_sup": float(Gsup[i]),
                "layer": int(j),
                "layer_vector_real_at_G7_argmax": zjr,
                "layer_vector_imag_at_G7_argmax": zji,
                "layer_vector_abs_at_G7_argmax": zja,
                "same_M_absolute_budget": abs_budget,
                "same_M_cancellation_factor": cancellation_factor,
                "F0_abs_over_G7": f0_fraction,
                "later_layers_abs_budget_over_G7": later_budget_fraction,
            })

    attribution_df = pd.DataFrame(
        attribution_rows
    )

    # ------------------------------------------------------------------
    # Freeze per-layer / per-cumulative bounds
    # ------------------------------------------------------------------

    print("[7] Freeze DEVELOPMENT head bounds and test HOLDOUT")

    layer_bound_rows = []
    cumulative_bound_rows = []

    all_layer_holdout_pass = True
    all_cumulative_holdout_pass = True

    min_layer_margin = float("inf")
    min_cumulative_margin = float("inf")

    for j in range(7):
        grp = layer_df[
            layer_df["layer"] == j
        ]

        dev = grp[
            grp["region"] == "DEVELOPMENT"
        ]

        hold = grp[
            grp["region"] == "HOLDOUT"
        ]

        frozen = float(
            args.layer_bound_safety
            * dev["prefix_sup"].max()
        )

        hmax = float(
            hold["prefix_sup"].max()
        )

        passed = bool(
            hmax <= frozen
        )

        margin = float(
            frozen
            / max(hmax, 1e-300)
        )

        all_layer_holdout_pass = (
            all_layer_holdout_pass
            and passed
        )

        min_layer_margin = min(
            min_layer_margin,
            margin,
        )

        layer_bound_rows.append({
            "layer": int(j),
            "frozen_bound": frozen,
            "holdout_max": hmax,
            "margin": margin,
            "pass": passed,
        })

    for h in range(7):
        grp = cumulative_df[
            cumulative_df["head_depth"] == h
        ]

        dev = grp[
            grp["region"] == "DEVELOPMENT"
        ]

        hold = grp[
            grp["region"] == "HOLDOUT"
        ]

        frozen = float(
            args.cumulative_bound_safety
            * dev["prefix_sup"].max()
        )

        hmax = float(
            hold["prefix_sup"].max()
        )

        passed = bool(
            hmax <= frozen
        )

        margin = float(
            frozen
            / max(hmax, 1e-300)
        )

        all_cumulative_holdout_pass = (
            all_cumulative_holdout_pass
            and passed
        )

        min_cumulative_margin = min(
            min_cumulative_margin,
            margin,
        )

        cumulative_bound_rows.append({
            "head_depth": int(h),
            "frozen_bound": frozen,
            "holdout_max": hmax,
            "margin": margin,
            "pass": passed,
        })

    layer_bounds_df = pd.DataFrame(
        layer_bound_rows
    )

    cumulative_bounds_df = pd.DataFrame(
        cumulative_bound_rows
    )

    # ------------------------------------------------------------------
    # Head structure classification
    # ------------------------------------------------------------------

    G7_rows = cumulative_df[
        cumulative_df["head_depth"] == 6
    ]

    F0_rows = layer_df[
        layer_df["layer"] == 0
    ]

    merged = pd.merge(
        G7_rows[
            [
                "N",
                "region",
                "prefix_sup",
            ]
        ].rename(
            columns={
                "prefix_sup": "G7_prefix_sup",
            }
        ),
        F0_rows[
            [
                "N",
                "prefix_sup",
            ]
        ].rename(
            columns={
                "prefix_sup": "F0_prefix_sup",
            }
        ),
        on="N",
        how="inner",
    )

    merged["F0_over_G7_prefix_sup"] = (
        merged["F0_prefix_sup"]
        / np.maximum(
            merged["G7_prefix_sup"],
            1e-300,
        )
    )

    # Sum of individual layer prefix norms / G7 prefix norm.
    budgets = []

    for N in checkpoints:
        indiv = layer_df[
            layer_df["N"] == int(N)
        ]["prefix_sup"].to_numpy(float)

        Gv = float(
            G7_rows[
                G7_rows["N"] == int(N)
            ]["prefix_sup"].iloc[0]
        )

        budgets.append({
            "N": int(N),
            "region": (
                "DEVELOPMENT"
                if N <= int(args.development_N_max)
                else "HOLDOUT"
            ),
            "sum_individual_layer_prefix_sup": float(
                np.sum(indiv)
            ),
            "G7_prefix_sup": Gv,
            "triangle_budget_over_G7": float(
                np.sum(indiv)
                / max(Gv, 1e-300)
            ),
        })

    budget_df = pd.DataFrame(budgets)

    hold_attr = attribution_df[
        attribution_df["region"] == "HOLDOUT"
    ]

    hold_budget = budget_df[
        budget_df["region"] == "HOLDOUT"
    ]

    max_sameM_cancel = float(
        hold_attr[
            "same_M_cancellation_factor"
        ].max()
    )

    max_triangle_cancel = float(
        hold_budget[
            "triangle_budget_over_G7"
        ].max()
    )

    hold_F0_ratio = merged[
        merged["region"] == "HOLDOUT"
    ]["F0_over_G7_prefix_sup"].to_numpy(float)

    median_F0_ratio = float(
        np.median(hold_F0_ratio)
    )

    if (
        all_layer_holdout_pass
        and max_triangle_cancel <= 2.0
    ):
        head_classification = (
            "FINITE_HEAD_LAYERS_INDIVIDUALLY_TAME"
        )
        next_theorem = (
            "Attack the seven fixed layer prefixes separately. "
            "Because the triangle budget is modest, an all-N bound for each "
            "u_j=R^jF0, j=0..6, would bound G7 without requiring delicate "
            "inter-layer cancellation. Start with F0 and propagate through the "
            "six fixed R applications."
        )
    elif median_F0_ratio >= 0.80 and max_sameM_cancel <= 2.0:
        head_classification = (
            "G7_HEAD_DOMINATED_BY_F0"
        )
        next_theorem = (
            "The head is numerically dominated by F0. Reduce the analytic problem "
            "to a fixed-anchor all-N prefix bound for F0=(I-K_b)^(-1)F, then treat "
            "R F0,...,R^6F0 as finite corrections using the already-certified "
            "preconditioned transfer structure."
        )
    else:
        head_classification = (
            "G7_REQUIRES_INTERLAYER_CANCELLATION"
        )
        next_theorem = (
            "Triangle inequalities lose substantial cancellation. Do not try to "
            "prove seven independent absolute prefix bounds. Derive a direct "
            "closed expression or summation-by-parts identity for G7 as a whole."
        )

    # ------------------------------------------------------------------
    # v298 lineage
    # ------------------------------------------------------------------

    v298_loaded = False
    v298_pass = False

    p298 = Path(args.v298_summary)

    if p298.exists():
        try:
            v298 = json.loads(
                p298.read_text(
                    encoding="utf-8"
                )
            )

            v298_loaded = bool(
                int(v298.get("version", -1))
                == 298
            )

            if v298_loaded:
                v298_pass = bool(
                    not v298.get(
                        "failed_gates",
                        ["missing"],
                    )
                )
        except Exception:
            v298_loaded = False
            v298_pass = False

    # ------------------------------------------------------------------
    # Gates
    # ------------------------------------------------------------------

    gates = {
        "exact_one_step_fixed_point": bool(
            fixed_point_error
            <= float(args.identity_tol)
        ),
        "exact_G7_block_identity": bool(
            block_identity_error
            <= float(args.identity_tol)
        ),
        "layer_support_growth": support_pass,
        "individual_layer_holdouts": (
            all_layer_holdout_pass
        ),
        "cumulative_head_holdouts": (
            all_cumulative_holdout_pass
        ),
    }

    failed = [
        k for k, v in gates.items()
        if not v
    ]

    if not failed:
        verdict = (
            "G7_FINITE_HEAD_ANATOMY_AUDIT_VERIFIED"
        )
    else:
        verdict = (
            "G7_FINITE_HEAD_ANATOMY_GATE_FAILURE"
        )

    # ------------------------------------------------------------------
    # Outputs
    # ------------------------------------------------------------------

    out = args.prefix

    layer_path = Path(
        out + "_LAYERS.csv"
    )
    cumulative_path = Path(
        out + "_CUMULATIVE.csv"
    )
    attribution_path = Path(
        out + "_SAME_M_ATTRIBUTION.csv"
    )
    budget_path = Path(
        out + "_BUDGET.csv"
    )
    bounds_path = Path(
        out + "_BOUNDS.csv"
    )
    summary_path = Path(
        out + "_SUMMARY.json"
    )
    theorem_path = Path(
        out + "_NEXT_THEOREM.md"
    )

    layer_df.to_csv(layer_path, index=False)
    cumulative_df.to_csv(
        cumulative_path,
        index=False,
    )
    attribution_df.to_csv(
        attribution_path,
        index=False,
    )
    budget_df.to_csv(
        budget_path,
        index=False,
    )

    pd.concat(
        [
            layer_bounds_df.assign(
                kind="INDIVIDUAL_LAYER"
            ).rename(
                columns={
                    "layer": "index",
                }
            ),
            cumulative_bounds_df.assign(
                kind="CUMULATIVE_HEAD"
            ).rename(
                columns={
                    "head_depth": "index",
                }
            ),
        ],
        ignore_index=True,
    ).to_csv(
        bounds_path,
        index=False,
    )

    payload = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "zeta_log_derivative_used": False,
            "known_zero_ordinates_used": False,
        },
        "anchor": {
            "k": int(args.anchor_k),
            "E": E,
        },
        "exact_structure": {
            "fixed_point_error": fixed_point_error,
            "G7_block_identity_error": (
                block_identity_error
            ),
            "support_pass": support_pass,
        },
        "prospective_design": {
            "N_values": checkpoints,
            "development_N": development,
            "holdout_N": holdout,
            "head_layers": 7,
            "note": (
                "No arithmetic frontier extension; the finite-head attribution "
                "and same-M cancellation diagnostics are new after v298."
            ),
        },
        "holdout": {
            "all_individual_layers_pass": (
                all_layer_holdout_pass
            ),
            "minimum_individual_margin": (
                min_layer_margin
            ),
            "all_cumulative_heads_pass": (
                all_cumulative_holdout_pass
            ),
            "minimum_cumulative_margin": (
                min_cumulative_margin
            ),
        },
        "head_anatomy": {
            "median_holdout_F0_over_G7_prefix_sup": (
                median_F0_ratio
            ),
            "maximum_holdout_same_M_cancellation_factor": (
                max_sameM_cancel
            ),
            "maximum_holdout_triangle_budget_over_G7": (
                max_triangle_cancel
            ),
            "classification": (
                head_classification
            ),
        },
        "v298_lineage": {
            "loaded": v298_loaded,
            "v298_all_gates_pass": v298_pass,
        },
        "gates": gates,
        "failed_gates": failed,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN. This audit only identifies the finite-head structure. "
            "An all-N analytic prefix theorem for the selected head representation "
            "is still required."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v299 — G7 finite-head theorem target

The exact seven-layer head is

`G7=sum_(j=0)^6 R^jF0`.

v298 prospectively supports a renormalized recursive packet mechanism after
this head.  v299 asks whether G7 itself can be bounded layer-by-layer or must
be treated as one cancellation-preserving object.

Finite classification:

`{head_classification}`

Median HOLDOUT `F0_prefix/G7_prefix`:

`{median_F0_ratio}`

Maximum HOLDOUT same-M cancellation factor:

`{max_sameM_cancel}`

Maximum HOLDOUT sum-of-layer-prefix / G7-prefix factor:

`{max_triangle_cancel}`

Next theorem:

{next_theorem}

A finite holdout pass is not an all-N proof.
""",
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Console
    # ------------------------------------------------------------------

    print()
    print("=" * 216)
    print(
        "ROT-RH v299 — G7 FINITE-HEAD ANATOMY SUMMARY"
    )
    print("=" * 216)

    print("EXACT STRUCTURE")
    print("-" * 216)
    print(
        "max x-(F0+Rx) error                 : "
        f"{fixed_point_error:.3e}"
    )
    print(
        "max x-(G7+R^7x) error               : "
        f"{block_identity_error:.3e}"
    )
    print(
        "layer support growth                 : "
        f"{support_pass}"
    )

    print()
    print("INDIVIDUAL LAYER PREFIX NORMS")
    print("-" * 216)

    for N in checkpoints:
        region = (
            "DEVE"
            if N <= int(args.development_N_max)
            else "HOLD"
        )

        vals = []

        for j in range(7):
            z = layer_df[
                (layer_df["N"] == N)
                & (layer_df["layer"] == j)
            ].iloc[0]

            vals.append(
                f"u{j}={float(z.prefix_sup):.6e}"
            )

        print(
            f"{region:4s} N={N:>8d} "
            + " ".join(vals)
        )

    print()
    print("CUMULATIVE HEAD PREFIX NORMS")
    print("-" * 216)

    for N in checkpoints:
        region = (
            "DEVE"
            if N <= int(args.development_N_max)
            else "HOLD"
        )

        vals = []

        for h in range(7):
            z = cumulative_df[
                (cumulative_df["N"] == N)
                & (
                    cumulative_df["head_depth"]
                    == h
                )
            ].iloc[0]

            vals.append(
                f"H{h}={float(z.prefix_sup):.6e}"
            )

        print(
            f"{region:4s} N={N:>8d} "
            + " ".join(vals)
        )

    print()
    print("G7 SAME-M CANCELLATION")
    print("-" * 216)

    one_per_N = (
        attribution_df[
            attribution_df["layer"] == 0
        ]
        .sort_values("N")
    )

    for row in one_per_N.itertuples(index=False):
        print(
            f"{str(row.region)[:4]:4s} "
            f"N={int(row.N):>8d} "
            f"M*={int(row.G7_argmax_M):>8d} "
            f"G7={float(row.G7_prefix_sup):.6e} "
            f"sameM_cancel={float(row.same_M_cancellation_factor):.6f} "
            f"F0/G7={float(row.F0_abs_over_G7):.6f} "
            f"later/G7={float(row.later_layers_abs_budget_over_G7):.6f}"
        )

    print()
    print("PROSPECTIVE HOLDOUT")
    print("-" * 216)
    print(
        "all individual layers pass          : "
        f"{all_layer_holdout_pass}"
    )
    print(
        "minimum individual margin            : "
        f"{min_layer_margin:.6f}"
    )
    print(
        "all cumulative heads pass            : "
        f"{all_cumulative_holdout_pass}"
    )
    print(
        "minimum cumulative margin            : "
        f"{min_cumulative_margin:.6f}"
    )

    print()
    print("HEAD CLASSIFICATION")
    print("-" * 216)
    print(
        "median holdout F0/G7 prefix           : "
        f"{median_F0_ratio:.6f}"
    )
    print(
        "max holdout same-M cancellation       : "
        f"{max_sameM_cancel:.6f}"
    )
    print(
        "max holdout triangle/G7               : "
        f"{max_triangle_cancel:.6f}"
    )
    print(
        "classification                        : "
        f"{head_classification}"
    )

    print()
    print(
        "VERDICT                              :",
        verdict,
    )
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print(
        "PROOF VERDICT                        : OPEN — "
        "ALL-N G7 FINITE-HEAD PREFIX THEOREM"
    )
    print("=" * 216)

    print("Files written:")
    print(" ", layer_path)
    print(" ", cumulative_path)
    print(" ", attribution_path)
    print(" ", budget_path)
    print(" ", bounds_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
