#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v276 — GLOBAL SELBERG JACOBIAN CONTRACTION CERTIFICATE
==============================================================

Purpose
-------
v275 found, on untouched dyadic blocks, that the exact Selberg-recursion
Jacobian is contractive in the natural critical coefficient norm

    x_n = r(n)/(sqrt(n) log n),

with holdout maximum absolute gain about 0.667.

v276 removes the finite-block extrapolation from this particular statement.
It reduces the GLOBAL bound

    sup_{n>=2} G(n) < 1

to a finite factor-pattern search and certifies every remaining candidate
with Arb interval arithmetic.

Exact natural-weight gain
-------------------------
For the Selberg recursion

    dr(n)/dr(d) = -2 Lambda(n/d)/log n

and the natural state

    x_n = r(n)/(sqrt(n) log n),

the weighted l-infinity row gain is

    G(n)
      = sum_{p^a | n, p^a < n}
          2 log(p)/log(n)
          p^(-a/2)
          [log(n/p^a)/log(n)]

      = 2/(log n)^2
        sum_{p^a | n, p^a<n}
          log(p) p^(-a/2)
          [log n-a log p].

This is independent of E and is an exact positive quantity.

Global finite reduction
-----------------------
Define

    S(P)=sum_{p in P} log p/(sqrt(p)-1),

where P is the set of distinct prime divisors of n.

Because

    log(n)-a log p <= log(n)

and

    sum_{a=1}^v p^(-a/2) <= 1/(sqrt(p)-1),

we have

    G(n) <= B(n)
         := 2 S(P)/log n.

Therefore B(n)>=1 can occur only if

    log n <= 2 S(P).

Since log n >= sum_{p in P} log p, a necessary condition is

    sum_{p in P} c(p) >= 0,

where

    c(p)=log p [2/(sqrt(p)-1)-1].

For p>=11, c(p)<0 and c(x) is strictly decreasing for x>9 because both
factors in

    c'(x)
      = [2/(sqrt(x)-1)-1]/x
        + log(x) d/dx[2/(sqrt(x)-1)]

are negative.

Only p=2,3,5,7 have positive c(p).  Their total positive budget is finite.
Once a prime p0 satisfies

    c(p0) + sum_{p in {2,3,5,7}} c(p) < 0,

no prime >=p0 can occur in a dangerous set.

v276 certifies p0=673, so every potentially dangerous prime set is drawn from
primes <673.

For each such prime set P satisfying sum c(p)>=0, B(n)>=1 further forces

    sum_p v_p log p <= 2 S(P),

so only finitely many exponent vectors v_p>=1 remain.

v276 enumerates ALL of them.

Arb certification
-----------------
Every candidate G(n) is recomputed with python-flint/Arb ball arithmetic.
The script certifies an explicit global q<1 such that

    G(n) <= q < 1

for every integer n>=2.

This closes the NATURAL SELBERG JACOBIAN CONTRACTION theorem, not the RH proof.

What remains
------------
Even a global coefficient contraction does not by itself bound the Abel
evaluation

    sum x_n e^{-n/L} n^{iE},

because the evaluation functional is not absolutely summable in this norm.
v275 already showed that norms strong enough for absolute evaluation are
wildly noncontractive.

Thus, if v276 passes, the next theorem is precisely phase-sensitive:
combine the globally contractive Selberg coefficient dynamics with the fixed
multiplicative phase e^{iE*log n} to obtain a bounded Abel observable.

No Xi, zeta values, or zero ordinates are used.

Dependency
----------
    pip install python-flint

Version: 276
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

VERSION = 276


# ---------------------------------------------------------------------------
# Elementary prime utilities
# ---------------------------------------------------------------------------

def primes_below(N: int):
    N = int(N)
    if N <= 2:
        return []

    s = np.ones(N, dtype=bool)
    s[:2] = False

    root = int(math.isqrt(N - 1))
    for p in range(2, root + 1):
        if s[p]:
            s[p * p:N:p] = False

    return np.flatnonzero(s).astype(int).tolist()


# ---------------------------------------------------------------------------
# Float screening formulas
# ---------------------------------------------------------------------------

def c_float(p: int) -> float:
    p = float(p)
    return math.log(p) * (
        2.0 / (math.sqrt(p) - 1.0) - 1.0
    )


def S_float(prime_set) -> float:
    return sum(
        math.log(p) / (math.sqrt(p) - 1.0)
        for p in prime_set
    )


def log_rad_float(prime_set) -> float:
    return sum(math.log(p) for p in prime_set)


def G_float(prime_set, exponents) -> float:
    """
    Exact mathematical formula evaluated in float.
    Used only for fast candidate ranking/screening.
    """
    L = sum(
        int(v) * math.log(int(p))
        for p, v in zip(prime_set, exponents)
    )

    total = 0.0
    one_prime = len(prime_set) == 1

    for p, v in zip(prime_set, exponents):
        lp = math.log(int(p))

        for a in range(1, int(v) + 1):
            # p^v=n only in the one-prime case; d=1 is not a proper state.
            if one_prime and a == int(v):
                continue

            total += (
                2.0
                * lp
                / L
                * (float(p) ** (-0.5 * a))
                * (1.0 - a * lp / L)
            )

    return total


# ---------------------------------------------------------------------------
# Dangerous prime-set enumeration
# ---------------------------------------------------------------------------

def enumerate_negative_subsets(
    negative_primes,
    deficits,
    budget,
    slack,
):
    """
    Enumerate all subsets whose total deficit <= budget+slack.

    deficits are positive and increasing with prime because c(p) is decreasing
    for p>=11.
    """
    out = [tuple()]
    current = []

    def dfs(start, remaining):
        for j in range(start, len(negative_primes)):
            d = deficits[j]

            if d > remaining + slack:
                break

            current.append(negative_primes[j])
            out.append(tuple(current))
            dfs(
                j + 1,
                remaining - d,
            )
            current.pop()

    dfs(0, float(budget))
    return out


def dangerous_prime_sets(prime_cutoff, screening_slack):
    positive_primes = [2, 3, 5, 7]

    negative_primes = [
        p
        for p in primes_below(prime_cutoff)
        if p >= 11
    ]

    cvals = {
        p: c_float(p)
        for p in positive_primes + negative_primes
    }

    deficits = [
        -cvals[p]
        for p in negative_primes
    ]

    sets = set()

    for r in range(1, len(positive_primes) + 1):
        for pos_tuple in itertools.combinations(
            positive_primes,
            r,
        ):
            budget = sum(
                cvals[p]
                for p in pos_tuple
            )

            neg_subsets = enumerate_negative_subsets(
                negative_primes,
                deficits,
                budget,
                screening_slack,
            )

            for neg_tuple in neg_subsets:
                P = tuple(sorted(
                    pos_tuple + neg_tuple
                ))

                # Conservative screening: retain anything near the boundary.
                csum = sum(
                    cvals[p]
                    for p in P
                )

                if csum >= -screening_slack:
                    sets.add(P)

    return sorted(
        sets,
        key=lambda x: (len(x), x),
    )


# ---------------------------------------------------------------------------
# Exponent enumeration
# ---------------------------------------------------------------------------

def exponent_patterns(
    prime_set,
    screening_slack,
):
    """
    Enumerate all v_p>=1 satisfying

        sum v_p log p <= 2 S(P) + slack.

    Outside this region the crude bound B(n)<1 already certifies contraction.
    """
    logs = [
        math.log(p)
        for p in prime_set
    ]

    Lmax = (
        2.0 * S_float(prime_set)
        + screening_slack
    )

    v = [1] * len(prime_set)

    out = []

    suffix_min = np.zeros(
        len(prime_set) + 1,
        dtype=float,
    )

    for i in range(
        len(prime_set) - 1,
        -1,
        -1,
    ):
        suffix_min[i] = (
            suffix_min[i + 1]
            + logs[i]
        )

    def rec(i, Lcur):
        if i == len(prime_set):
            out.append(tuple(v))
            return

        lp = logs[i]
        remaining_min = suffix_min[i + 1]

        vmax = int(math.floor(
            (
                Lmax
                - Lcur
                - remaining_min
            ) / lp
        ))

        if vmax < 1:
            return

        for vi in range(1, vmax + 1):
            newL = Lcur + vi * lp

            if (
                newL
                + remaining_min
                > Lmax
                + screening_slack
            ):
                break

            v[i] = vi
            rec(
                i + 1,
                newL,
            )

    rec(0, 0.0)
    return out


# ---------------------------------------------------------------------------
# Arb interval helpers
# ---------------------------------------------------------------------------

def arb_upper_float(x):
    """
    Convert rigorous upper endpoint to float.

    python-flint arb.upper() returns an arf-like exact endpoint convertible to
    float.  We intentionally round the returned float upward by one ulp.
    """
    y = float(x.upper())
    return float(np.nextafter(y, math.inf))


def arb_lower_float(x):
    y = float(x.lower())
    return float(np.nextafter(y, -math.inf))


def G_arb(arb, prime_set, exponents):
    logs = [
        arb(int(p)).log()
        for p in prime_set
    ]

    L = arb(0)
    for lp, v in zip(logs, exponents):
        L += int(v) * lp

    total = arb(0)
    one_prime = len(prime_set) == 1

    for p, v, lp in zip(
        prime_set,
        exponents,
        logs,
    ):
        sqrtp = arb(int(p)).sqrt()

        # p^(-a/2) = sqrt(p)^(-a)
        for a in range(1, int(v) + 1):
            if one_prime and a == int(v):
                continue

            pa_half_inv = sqrtp ** (-a)

            term = (
                arb(2)
                * lp
                / L
                * pa_half_inv
                * (
                    arb(1)
                    - arb(a) * lp / L
                )
            )
            total += term

    return total


def c_arb(arb, p):
    x = arb(int(p))
    return x.log() * (
        arb(2) / (x.sqrt() - 1)
        - 1
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    ap.add_argument(
        "--prime-cutoff",
        type=int,
        default=673,
        help=(
            "First prime excluded from dangerous sets. "
            "v276 analytically checks this cutoff."
        ),
    )

    ap.add_argument(
        "--arb-dps",
        type=int,
        default=80,
    )

    ap.add_argument(
        "--screening-slack",
        type=float,
        default=1e-10,
        help=(
            "Positive conservative slack used only in float enumeration. "
            "All retained candidates are rigorously certified with Arb."
        ),
    )

    ap.add_argument(
        "--global-q-gate",
        type=float,
        default=0.80,
        help=(
            "Require the certified global natural Jacobian contraction "
            "constant to be below this value."
        ),
    )

    ap.add_argument(
        "--expected-max-n",
        type=int,
        default=60,
        help="Diagnostic only; does not affect certification.",
    )

    ap.add_argument(
        "--prefix",
        default="rot_rh_global_selberg_jacobian_certificate_v276",
    )

    ap.add_argument(
        "--strict",
        action="store_true",
    )

    args = ap.parse_args()
    started = time.perf_counter()

    try:
        from flint import arb, ctx
    except Exception as exc:
        raise RuntimeError(
            "v276 requires python-flint / Arb.\n"
            "Install it with:\n\n"
            "    pip install python-flint\n\n"
            f"Import error: {exc}"
        )

    ctx.dps = int(args.arb_dps)

    p0 = int(args.prime_cutoff)

    print("=" * 206)
    print("ROT-RH v276 — GLOBAL SELBERG JACOBIAN CONTRACTION CERTIFICATE")
    print("=" * 206)
    print("Xi / zeta / known-zero data         : NONE")
    print(f"Arb precision                        : {args.arb_dps} dps")
    print(f"dangerous-prime cutoff p0            : {p0}")
    print(f"global q gate                        : {args.global_q_gate}")
    print("=" * 206)

    # --------------------------------------------------------------
    # 1. Analytic prime cutoff
    # --------------------------------------------------------------
    print("[1] Analytic dangerous-prime cutoff")

    positive_primes = [2, 3, 5, 7]

    Cplus_ball = arb(0)
    for p in positive_primes:
        Cplus_ball += c_arb(arb, p)

    c_p0_ball = c_arb(arb, p0)
    cutoff_margin_ball = (
        -Cplus_ball
        - c_p0_ball
    )

    Cplus_upper = arb_upper_float(Cplus_ball)
    c_p0_upper = arb_upper_float(c_p0_ball)
    cutoff_margin_lower = arb_lower_float(
        cutoff_margin_ball
    )

    # c'(x)<0 for x>9 analytically:
    #
    # h(x)=2/(sqrt x-1)-1 <0,
    # h'(x)<0,
    # c'(x)=h(x)/x+log(x)h'(x)<0.
    derivative_sign_closed = bool(p0 > 9)

    prime_cutoff_certified = bool(
        derivative_sign_closed
        and cutoff_margin_lower > 0.0
    )

    print(
        "positive c-budget upper             : "
        f"{Cplus_upper:.12e}"
    )
    print(
        f"c({p0}) upper                        : "
        f"{c_p0_upper:.12e}"
    )
    print(
        "rigorous cutoff margin lower        : "
        f"{cutoff_margin_lower:.12e}"
    )
    print(
        "c'(x)<0 for x>9                    : "
        f"{derivative_sign_closed}"
    )
    print(
        f"all primes >= {p0} excluded          : "
        f"{prime_cutoff_certified}"
    )

    # --------------------------------------------------------------
    # 2. Enumerate every dangerous prime set
    # --------------------------------------------------------------
    print("[2] Finite dangerous prime-set enumeration")

    Psets = dangerous_prime_sets(
        p0,
        float(args.screening_slack),
    )

    print(
        "dangerous prime sets                : "
        f"{len(Psets):,}"
    )

    # --------------------------------------------------------------
    # 3. Enumerate every remaining exponent pattern
    # --------------------------------------------------------------
    print("[3] Finite exponent-pattern enumeration")

    candidate_rows = []
    total_patterns = 0

    float_best = (
        -math.inf,
        None,
        None,
    )

    patterns_by_set = []

    for P in tqdm(
        Psets,
        desc="factor patterns",
        unit="prime-set",
    ):
        patterns = exponent_patterns(
            P,
            float(args.screening_slack),
        )

        patterns_by_set.append(
            (P, patterns)
        )

        total_patterns += len(patterns)

        for v in patterns:
            g = G_float(P, v)

            if g > float_best[0]:
                float_best = (
                    g,
                    P,
                    v,
                )

    print(
        "candidate exponent patterns         : "
        f"{total_patterns:,}"
    )
    print(
        "float-screen maximum                : "
        f"{float_best[0]:.15f}"
    )
    print(
        "float-screen prime set              : "
        f"{float_best[1]}"
    )
    print(
        "float-screen exponents              : "
        f"{float_best[2]}"
    )

    # --------------------------------------------------------------
    # 4. Rigorous Arb certification of ALL candidates
    # --------------------------------------------------------------
    print("[4] Arb certification of every candidate")

    arb_global_upper = -math.inf
    arb_global_lower = -math.inf
    arb_best_P = None
    arb_best_v = None

    # Save all patterns close enough to the maximum to make the certificate
    # inspectable without generating a huge CSV.
    near_rows = []

    for P, patterns in tqdm(
        patterns_by_set,
        desc="Arb candidate certification",
        unit="prime-set",
    ):
        for v in patterns:
            gb = G_arb(
                arb,
                P,
                v,
            )

            lo = arb_lower_float(gb)
            hi = arb_upper_float(gb)

            if hi > arb_global_upper:
                arb_global_upper = hi
                arb_global_lower = lo
                arb_best_P = P
                arb_best_v = v

            if hi >= 0.70:
                n_exact = 1
                for p, e in zip(P, v):
                    n_exact *= int(p) ** int(e)

                near_rows.append({
                    "n": int(n_exact),
                    "prime_set": "*".join(
                        str(p)
                        for p in P
                    ),
                    "exponents": ",".join(
                        str(x)
                        for x in v
                    ),
                    "G_lower": lo,
                    "G_upper": hi,
                })

    global_margin_lower = (
        1.0
        - arb_global_upper
    )

    certified_global_contraction = bool(
        prime_cutoff_certified
        and arb_global_upper < 1.0
    )

    q_gate_pass = bool(
        arb_global_upper
        < float(args.global_q_gate)
    )

    best_n = 1
    if arb_best_P is not None:
        for p, e in zip(
            arb_best_P,
            arb_best_v,
        ):
            best_n *= int(p) ** int(e)

    expected_max_match = bool(
        best_n == int(args.expected_max_n)
    )

    # --------------------------------------------------------------
    # 5. Proof ledger
    # --------------------------------------------------------------
    gates = {
        "analytic_prime_cutoff_certified": (
            prime_cutoff_certified
        ),
        "finite_reduction_nonempty": bool(
            len(Psets) > 0
            and total_patterns > 0
        ),
        "global_Arb_contraction": (
            certified_global_contraction
        ),
        "global_q_gate": q_gate_pass,
    }

    failed = [
        k
        for k, v in gates.items()
        if not v
    ]

    if not failed:
        mechanism = (
            "GLOBAL_NATURAL_SELBERG_JACOBIAN_CONTRACTION_CERTIFIED"
        )
        next_theorem = (
            "The natural coefficient recursion is now globally contractive, "
            "not merely numerically so. The remaining one-anchor lemma cannot "
            "be closed by coefficient l-infinity contraction alone because "
            "the Abel evaluation functional is not absolutely summable. "
            "Next derive a phase-sensitive dual/transfer estimate for the "
            "fixed multiplicative character n^(iE*)."
        )
    else:
        mechanism = (
            "GLOBAL_SELBERG_JACOBIAN_CERTIFICATE_FAILED"
        )
        next_theorem = (
            "Inspect the failed finite-reduction or Arb certificate before "
            "using Selberg contraction in any theorem argument."
        )

    verdict = (
        "GLOBAL_SELBERG_JACOBIAN_CERTIFICATE_VERIFIED"
        if not failed
        else
        "GLOBAL_SELBERG_JACOBIAN_CERTIFICATE_GATE_FAILURE"
    )

    # --------------------------------------------------------------
    # Outputs
    # --------------------------------------------------------------
    prefix = args.prefix

    near_path = Path(
        prefix + "_NEAR_MAX_PATTERNS.csv"
    )
    summary_path = Path(
        prefix + "_SUMMARY.json"
    )
    theorem_path = Path(
        prefix + "_THEOREM.md"
    )

    near_df = pd.DataFrame(
        sorted(
            near_rows,
            key=lambda r: -r["G_upper"],
        )
    )
    near_df.to_csv(
        near_path,
        index=False,
    )

    summary = {
        "version": VERSION,
        "firewall": {
            "Xi_used": False,
            "zeta_used": False,
            "known_zero_ordinates_used": False,
        },
        "natural_gain": {
            "formula": (
                "G(n)=2/(log n)^2 sum_{p^a|n,p^a<n} "
                "log(p)p^(-a/2)(log n-a log p)"
            ),
            "crude_majorant": (
                "G(n)<=2/log(n) sum_{p|n} log(p)/(sqrt(p)-1)"
            ),
        },
        "finite_reduction": {
            "c_function": (
                "c(p)=log(p)[2/(sqrt(p)-1)-1]"
            ),
            "positive_primes": positive_primes,
            "positive_budget_upper": Cplus_upper,
            "prime_cutoff": p0,
            "c_prime_cutoff_upper": c_p0_upper,
            "prime_cutoff_margin_lower": (
                cutoff_margin_lower
            ),
            "monotonicity": (
                "c'(x)<0 for x>9 because h(x)<0 and h'(x)<0"
            ),
            "dangerous_prime_sets": len(Psets),
            "candidate_exponent_patterns": total_patterns,
        },
        "global_certificate": {
            "best_n": int(best_n),
            "best_prime_set": list(
                arb_best_P
                if arb_best_P is not None
                else []
            ),
            "best_exponents": list(
                arb_best_v
                if arb_best_v is not None
                else []
            ),
            "certified_G_lower": (
                arb_global_lower
            ),
            "certified_G_upper": (
                arb_global_upper
            ),
            "certified_margin_to_one_lower": (
                global_margin_lower
            ),
            "global_contraction": (
                certified_global_contraction
            ),
            "expected_max_n_diagnostic_match": (
                expected_max_match
            ),
        },
        "theorem_scope": {
            "closed_if_pass": (
                "For every integer n>=2, the natural weighted Selberg "
                "Jacobian l-infinity row gain is <= q<1."
            ),
            "not_closed": (
                "The Abel observable is not a bounded functional on this "
                "coefficient l-infinity space, so this theorem alone does not "
                "prove sup_L |Q(L;E*)|<infinity."
            ),
            "next_required_structure": (
                "phase-sensitive dual/transfer estimate for n^(iE*)"
            ),
        },
        "gates": gates,
        "failed_gates": failed,
        "mechanism": mechanism,
        "verdict": verdict,
        "next_theorem": next_theorem,
        "proof_status": (
            "OPEN overall. v276 certifies a global Selberg coefficient "
            "contraction if all gates pass; the remaining RH-strength step is "
            "to control the fixed oscillatory Abel evaluation."
        ),
        "runtime_seconds": (
            time.perf_counter() - started
        ),
    }

    summary_path.write_text(
        json.dumps(
            summary,
            indent=2,
        ),
        encoding="utf-8",
    )

    theorem_path.write_text(
        f"""# ROT-RH v276 — global Selberg Jacobian certificate

## Exact gain

For the natural state

`x_n=r(n)/(sqrt(n)log n)`,

the exact Selberg Jacobian row gain is

`G(n)=2/(log n)^2 sum_{{p^a|n,p^a<n}}
log(p)p^(-a/2)(log n-a log p)`.

## Global majorant

`G(n) <= 2 S(P)/log n`,

where

`S(P)=sum_{{p|n}} log p/(sqrt(p)-1)`.

Potential failure of contraction therefore requires

`sum_{{p|n}} c(p)>=0`

with

`c(p)=log p[2/(sqrt p-1)-1]`.

Only `2,3,5,7` have positive `c(p)`, and `c(x)` is strictly decreasing for
`x>9`.

The Arb-certified cutoff shows that no prime `p>={p0}` can occur in a
potentially dangerous prime set.

This leaves:

- dangerous prime sets: `{len(Psets)}`
- finite exponent patterns: `{total_patterns}`

Every pattern was certified with Arb.

## Certified global contraction

Best factorization:

`n = {best_n}`

Prime set:

`{arb_best_P}`

Exponents:

`{arb_best_v}`

Certified interval:

`{arb_global_lower:.17g} <= G(n) <= {arb_global_upper:.17g}`.

Therefore

`G(n) <= {arb_global_upper:.17g} < 1`

for every integer `n>=2`.

Certified lower margin to one:

`1-q >= {global_margin_lower:.17g}`.

## What this closes

This proves the natural Selberg coefficient recursion is globally contractive
in its weighted l-infinity geometry.

It does NOT yet prove the one-anchor Abel phase is bounded. The functional

`sum x_n e^(-n/L)n^(iE*)`

is not absolutely bounded on this space.

The remaining theorem must exploit the fixed multiplicative phase
`n^(iE*)` (or an equivalent phase-sensitive dual norm).
""",
        encoding="utf-8",
    )

    # --------------------------------------------------------------
    # Console
    # --------------------------------------------------------------
    print()
    print("=" * 206)
    print("ROT-RH v276 — GLOBAL SELBERG JACOBIAN CERTIFICATE SUMMARY")
    print("=" * 206)

    print("FINITE REDUCTION")
    print("-" * 206)
    print(
        f"all primes >= {p0} excluded          : "
        f"{prime_cutoff_certified}"
    )
    print(
        "dangerous prime sets                : "
        f"{len(Psets):,}"
    )
    print(
        "candidate exponent patterns         : "
        f"{total_patterns:,}"
    )

    print()
    print("ARB GLOBAL CERTIFICATE")
    print("-" * 206)
    print(
        "global maximizing n                 : "
        f"{best_n}"
    )
    print(
        "prime set                           : "
        f"{arb_best_P}"
    )
    print(
        "exponents                           : "
        f"{arb_best_v}"
    )
    print(
        "certified G lower                   : "
        f"{arb_global_lower:.15f}"
    )
    print(
        "certified G upper                   : "
        f"{arb_global_upper:.15f}"
    )
    print(
        "certified 1-G margin                : "
        f"{global_margin_lower:.15f}"
    )
    print(
        "global natural contraction          : "
        f"{certified_global_contraction}"
    )

    print()
    print("THEOREM LEDGER")
    print("-" * 206)
    print(
        "finite factor-pattern reduction     : "
        + (
            "CLOSED"
            if prime_cutoff_certified
            else "OPEN"
        )
    )
    print(
        "global natural Jacobian q<1         : "
        + (
            "CERTIFIED"
            if certified_global_contraction
            else "NOT CERTIFIED"
        )
    )
    print(
        "absolute Abel evaluation            : "
        "NOT BOUNDED IN THIS NORM"
    )
    print(
        "remaining step                      : "
        "PHASE-SENSITIVE DUAL / TRANSFER THEOREM"
    )

    print()
    print("MECHANISM                            :", mechanism)
    print("=" * 206)
    print(
        "FAILED GATES                         :",
        failed if failed else "none",
    )
    print("VERDICT                              :", verdict)
    print(
        "PROOF VERDICT                        : OPEN — "
        "PHASE-SENSITIVE ONE-ANCHOR ABEL BOUNDEDNESS"
    )
    print("=" * 206)

    print("Files written:")
    print(" ", near_path)
    print(" ", summary_path)
    print(" ", theorem_path)

    if args.strict and failed:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
