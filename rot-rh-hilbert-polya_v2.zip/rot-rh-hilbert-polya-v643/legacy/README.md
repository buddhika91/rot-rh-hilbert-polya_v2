# Legacy research archive

This directory preserves the available pre-v600 ROT–RH research programs and
their associated CSV, JSON, Markdown, compressed, and archive artifacts.

Files are grouped by numeric version ranges. They remain intentionally close
to their original form so that historical calculations can be audited. They
are not imported by the packaged v643 implementation and are not all expected
to run in isolation: many consume outputs from earlier stages.

| Directory | Version range |
|---|---:|
| `v001_v099/` | v1–v99, including the reset infinite-form/Weil-kernel line |
| `v100_v199/` | v100–v199 |
| `v200_v299/` | v200–v299 |
| `v300_v399/` | v300–v399 |
| `v400_v499/` | v400–v499 |
| `v500_v599/` | v500–v599 |
| `original_archives/` | Earlier packaged releases and unversioned theory files |

See `../docs/HISTORY.md` for the conceptual map and
`../docs/LEGACY_INDEX.md` for the exact inventory.
