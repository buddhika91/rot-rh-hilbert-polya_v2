# ROT-RH v571 — exact selector-clock / Volterra-Fock U(1) intertwiner

Let `H_clock=H^2(S^1)` be the nonnegative-frequency Hardy clock space with
`psi_k(theta)=(2pi)^(-1/2)e^(ik theta)`, `k>=0`.

v557 identifies selector label `k` with exactly this compact-clock character.

Let `F` be the Bargmann-Fock space with normalized monomial basis
`e_k(z)=z^k/sqrt(k!)`.

v569 gives the universal Volterra transfer
`J e_k=1/sqrt(k+1)e_(k+1)`.

Define the unitary `W psi_k=e_k`. Let
`N_clock=-i partial_theta` and `N_F e_k=k e_k`.
Then exactly `W N_clock W^(-1)=N_F`.

Define
`J_clock=M_(e^(i theta))(N_clock+1)^(-1/2)`.
It obeys
`J_clock psi_k=1/sqrt(k+1) psi_(k+1)`,
hence
`boxed{W J_clock W^(-1)=J}`.

Therefore the compact selector clock and the universal Volterra Fock ladder
have exactly intertwined U(1) charge decomposition and weighted raising
dynamics.

The v570 capacity kernel becomes
`K_clock=(J_clock^2)^*J_clock^2=[(N_clock+1)(N_clock+2)]^(-1)`,
so
`K_clock psi_k=1/[(k+1)(k+2)] psi_k`
and `Tr K_clock=1`.

## Important correction

This does not prove the v556 novelty floor.
For selector label `k`,
`lambda_k=1/[(k+1)(k+2)]`.

If an off-critical zero produces
`k=exp(cL^2+o(L^2))`,
then
`lambda_k=exp(-2cL^2+o(L^2))`,
which is exponentially smaller than the required `exp[-o(L^2)]` floor.

So the representation bridge is exact, but the fixed trace-one kernel is too
soft at very high winding.

**Verdict:** `SELECTOR_CLOCK_AND_VOLterra_FOCK_ARE_EXACTLY_U1_INTERTWINED_PASS`.

Remaining theorem: derive a scale/energy-dependent accessibility law that
prevents exponentially high selector charge from being physically loaded at
fixed energy.
