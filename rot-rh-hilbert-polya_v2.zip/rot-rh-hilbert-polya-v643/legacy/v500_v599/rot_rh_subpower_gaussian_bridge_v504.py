#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v504 — SUBPOWER PREFIX -> ZERO GAUSSIAN BACKWARD TYPE
============================================================
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v504-subpower-to-gaussian-zero-type"

def continuum_weight(eps,L):
    a=eps*L
    return 1.0 + a*math.sqrt(math.pi)/2.0*math.exp(a*a/4.0)*(1.0+math.erf(a/2.0))

def panel(eps):
    rows=[]
    for L in (10.,20.,40.,80.):
        cont=continuum_weight(eps,L)
        rows.append({"L":float(L),"continuum_weight":float(cont),
                     "log_weight_over_L2":float(math.log(max(cont,1.0))/(L*L))})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v504 — subpower prefix implies zero Gaussian backward type

Let

`A_u(N,E)=sum_(2<=n<=N)u_n exp(iElog n)`,

and let `I` be compact. Assume for every fixed `eps in (0,1)`

`sup_(E in I)|A_u(N,E)| <= C_(eps,I) N^eps`.

For

`b_L(n)=exp[-(log n/L)^2]`

and

`G_L(E)=sum_(n>=2)u_n b_L(n)exp(iElog n)`,

discrete Abel summation gives

`G_L(E)=sum_(m>=2)A_u(m,E)[b_L(m)-b_L(m+1)]`.

Hence

`|G_L(E)|
 <=C_(eps,I) sum_(m>=2)m^eps[b_L(m)-b_L(m+1)]`.

The associated Stieltjes majorant is

`int_1^infty t^eps[-db_L(t)]`.

With `y=log t`, `z=y/L`, this is

`int_0^infty 2z exp(-z^2+eps L z)dz`

`=1+(eps L sqrt(pi)/2)
 exp(eps^2L^2/4)[1+erf(eps L/2)]`.

Thus, up to an eps-dependent absolute discrete/continuous constant,

`sup_(E in I)|G_L(E)|
 <=C'_(eps,I)(1+eps L)exp(eps^2L^2/4)`.

Therefore

`limsup_(L->infty)
 L^-2 log^+ sup_(E in I)|G_L(E)|
 <=eps^2/4`.

Since `eps>0` is arbitrary,

`L^-2 log^+ sup_(E in I)|G_L(E)| -> 0`.

So the Gaussian route needs only a **subpower** critical prefix theorem, not a
bounded one.

**Verdict:** `SUBPOWER_PREFIX_IMPLIES_ZERO_GAUSSIAN_TYPE_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_SUBPOWER_GAUSSIAN_ZERO_TYPE_V1",
        "hypothesis":"for every eps>0, sup_{E in I}|A_u(N,E)|=O_eps,I(N^eps)",
        "conclusion":"L^-2 log^+ sup_{E in I}|G_L(E)| -> 0"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--epsilon",type=float,default=.1)
    ap.add_argument("--prefix",default="rot_rh_subpower_gaussian_bridge_v504")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    if not 0<args.epsilon<1: raise ValueError("epsilon must be in (0,1)")
    t0=time.perf_counter()
    with tqdm(total=1,desc="v504 Abel",unit="step") as bar:
        rows=panel(args.epsilon);bar.update(1)
    target=args.epsilon**2/4
    ok=bool(rows[-1]["log_weight_over_L2"] <= target+0.01)
    verdict="SUBPOWER_PREFIX_IMPLIES_ZERO_GAUSSIAN_TYPE_PASS" if ok else "DIAGNOSTIC_FAILED"
    payload={"version":VERSION,"verdict":verdict,
             "epsilon":float(args.epsilon),"asymptotic_rate_upper":float(target),
             "panel":rows,"runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
