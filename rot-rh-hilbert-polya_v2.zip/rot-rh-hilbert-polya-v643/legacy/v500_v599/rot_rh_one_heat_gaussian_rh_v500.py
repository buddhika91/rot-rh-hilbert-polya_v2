#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v500 — ONE-HEAT-TIME GAUSSIAN RH CRITERION
==================================================

For h_L(u)=Tr exp(-u H_L^2)=sum_k exp(-u E_k(L)^2), any fixed E_*>0 obeys
  h_L(u) >= N_L(E_*) exp(-u E_*^2).

v497: an off-critical zero implies some fixed E_* with N_L(E_*) -> infinity.
Therefore for EVERY fixed u>0,
  h_L(u)->infinity along the corresponding late cutoffs.

Consequently, boundedness at just ONE heat time
  sup_L h_L(u0)<infinity
implies RH for the Gaussian-regulated ordered-support operator.

In particular, convergence or Cauchy behavior of h_L(u0) at one u0>0 implies RH.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v500-one-heat-rh"

def lower(N,E,u):
    return N*math.exp(-u*E*E)

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v500 — one-heat-time Gaussian RH criterion

For the Gaussian-regulated ordered support define the ordinary spectral heat
trace

`h_L(u)=Tr exp(-u H_L^2)`
`      =sum_(k>=1) exp(-u E_k(L)^2)`,
`u>0`.

For any fixed finite `E_*>0`, every level below `E_*` contributes at least
`exp(-uE_*^2)`.  Therefore

`h_L(u)`
` >= N_L(E_*) exp(-uE_*^2)`,

where

`N_L(E_*)=#{k:E_k(L)<=E_*}`.

v497 shows that if a nontrivial zero with `beta>1/2` exists, there is a **fixed**
finite `E_*` such that

`N_L(E_*) -> infinity`.

Hence, under an off-critical zero,

`h_L(u)->infinity`

for **every fixed `u>0`**.

It follows that the extremely weak operator estimate

`sup_(L>=L0) h_L(u0)<infinity`

at just **one** heat time `u0>0` excludes every `beta>1/2` zero.  Functional
equation reflection then excludes `beta<1/2`, so all nontrivial zeros lie on the
critical line.

Therefore

`ONE FIXED-u GAUSSIAN HEAT-TRACE BOUND => RH`.

A fortiori, any of the following at one `u0>0` implies RH:

* `h_L(u0)` converges as `L->infinity`;
* `h_L(u0)` is Cauchy on a cofinal cutoff sequence;
* `sup_L h_L(u0)<infinity`.

This is strictly less than the v450 target of uniform convergence on a whole
compact heat tube.  It is also less than trace-norm convergence of `H_L^-2`.

The v447/v450 arithmetic clock branch already uses exactly the unweighted
spectral trace

`sum_k exp(-uE_k(L)^2)`.

Thus the next RH-bearing analytic theorem can be reduced to proving boundedness
or Cauchy behavior at **one preregistered positive heat time**, without Xi,
known zero ordinates, the full Stieltjes hierarchy, or the Fredholm identity.

**Verdict:** `ONE_HEAT_TIME_GAUSSIAN_BOUND_IMPLIES_RH_PASS`.

Scientific boundary: this is an implication theorem.  The one-time uniform
Gaussian heat bound itself remains open analytically.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_ONE_HEAT_GAUSSIAN_RH_V1",
        "closed":{
            "occupancy_heat_lower":"h_L(u)>=N_L(E_*) exp(-uE_*^2)",
            "v497_input":"offcritical => N_L(E_*) -> infinity for fixed E_*",
            "offcritical_heat_divergence":"h_L(u)->infinity for every fixed u>0",
            "main_implication":"bounded h_L(u0) at one u0>0 => RH",
            "Cauchy_sufficient":True,
            "convergence_sufficient":True
        },
        "next_attack":{
            "target":"prove zero-blind boundedness/Cauchy of h_L(u0) for one fixed preregistered u0",
            "suggested_bridge":"adapt v450 from finite prospective heat-tube evidence to an analytic one-u shell-increment theorem"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--u0",type=float,default=.01)
    ap.add_argument("--E-star",type=float,default=20.)
    ap.add_argument("--prefix",default="rot_rh_one_heat_gaussian_rh_v500")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v500 heat",unit="step") as bar:
        vals=[{"N":N,"heat_lower":lower(N,args.E_star,args.u0)}
              for N in (10,100,1000,10000)];bar.update(1)
        positive=args.u0>0 and args.E_star>0;bar.update(1)
    ok=bool(positive and vals[-1]["heat_lower"]>vals[0]["heat_lower"])
    verdict="ONE_HEAT_TIME_GAUSSIAN_BOUND_IMPLIES_RH_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-t0,
             "u0":args.u0,"E_star":args.E_star,"lower_bound_demo":vals,
             "proof_status":"Exact positivity implication given v497; one-u uniform heat bound remains open."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
