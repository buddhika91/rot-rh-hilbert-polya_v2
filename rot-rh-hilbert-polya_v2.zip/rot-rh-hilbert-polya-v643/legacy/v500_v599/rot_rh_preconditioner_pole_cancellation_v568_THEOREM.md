# ROT-RH v568 — exact smooth preconditioner removes the zeta pole at one

Use the v383 exact Mellin representation of the preconditioned prime transfer

`R[A](s)`
` =mu(s)^(-1)`
`   int_s^infty`
`   mu(w)[zeta'(w)/zeta(w)]A(w)dw`,

where

`mu(s)`
` =exp(int_s^infty(zeta(w)-1)dw)`.

Let

`t=s-1`.

The classical Laurent expansion at the pole of zeta gives

`zeta(s)-1`
` =1/t+O(1)`,

and therefore

`log mu(s)`
` =-log t+O(1)`.

Hence

`mu(s)=C t^(-1)[1+O(t)]`,
`C!=0`.

Also

`zeta'(s)/zeta(s)`
` =-1/t+O(1)`.

If the input generator `A(s)` is analytic at `s=1`, then

`mu(s)[zeta'/zeta](s)A(s)`
` =-C A(1)t^(-2)+O(t^(-1))`.

Integrating from `s` to a fixed safe point gives

`int_s^infty mu(w)(zeta'/zeta)(w)A(w)dw`
` =-C A(1)t^(-1)+O(log t)`,

up to a branch-independent analytic constant.

Multiplication by

`mu(s)^(-1)=C^(-1)t[1+O(t)]`

therefore yields

`boxed{R[A](s)`
` =-A(1)+O(t log t)}`.

In particular the preconditioned transfer has **no pole at `s=1`**.

## Meaning for the Gaussian route

v567 shows that the raw positive Mangoldt Jacobian has an unavoidable
`exp(L^2/16)` Gaussian norm because it still contains the PNT/pole-at-one
channel.

v568 shows that the exact smooth resummation removes that pole at the operator
level before the Gaussian observable is taken.

Therefore the correct post-v534/v567 target is not the raw Frechet Jacobian.
It is the centered/preconditioned transfer

`R=(I-K_b)^(-1)K_Lambda`

(or the equivalent v559 centered determinant field).

The next singularities of `R[A]` are associated with zeta zeros, so a
zero-blind subexponential Gaussian-Gram theorem for this preconditioned
operator would attack the RH-sensitive scale rather than the universal PNT
background.

**Verdict:** `SMOOTH_PRECONDITIONER_CANCELS_POLE_AT_ONE_EXACTLY_PASS`.

This does not bound `R` at off-critical zero singularities and is not an RH
proof.
