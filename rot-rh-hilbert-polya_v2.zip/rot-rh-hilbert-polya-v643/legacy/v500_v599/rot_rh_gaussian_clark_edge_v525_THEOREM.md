# ROT-RH v525 — Gaussian Clark edge-resonance small-measure theorem

Continue the v524 local exposed-mode model. Let the amplitude be smooth and
eventually increasing with

`A'(L)>=c_A L A(L)`

and let the phase frequency satisfy

`omega(L)>=c_omega L^2`.

These are the natural Gaussian saddle scales when the exposed score is
strictly positive.

Between successive crossings of a half-integer amplitude target, write

`delta(L)=A(L)-(K+1/2)`,
`0<delta<1`.

The antinode-nearest root has

`sqrt(A^2-y^2)`
` =sqrt[(A-y)(A+y)]`
` >=sqrt(A delta)`

up to an absolute late-scale constant.

Thus its raw Clark weight obeys

`w_edge`
` <=C/[omega sqrt(A delta)]`.

If the collision normalization satisfies

`c_L<=C_0L`,

then

`alpha_edge`
` <=C/[L sqrt(A delta)]`.

Fix `eps>0`. The event

`alpha_edge>eps`

requires

`delta<C/(eps^2L^2A)`.

But, away from the reset point,

`d delta/dL=A'(L)>=c_A L A`.

Hence the width in `L` of one bad interval is at most

`C/(eps^2 L^3 A^2)`.

The number of half-integer amplitude crossings per unit `L` is `O(A'(L))`,
hence `O(LA)`. Therefore the total bad-set measure per unit scale is

`O(1/(eps^2 L^2 A(L)))`.

For the Gaussian exposed amplitude

`A(L)=exp(cL^2)/poly(L)`,

this is integrable on every late ray.

Consequently, for each fixed `eps>0`,

`measure{L>=L0: alpha_edge(L)>eps}<infinity`,

and the late repeated-resonance limsup has Lebesgue measure zero.

So the exceptional Clark channel from v524 is a sparse-in-cutoff resonance:
it prevents a uniform-in-all-real-L Herglotz bound, but it does not prevent
almost-everywhere/cofinal weak-measure collapse of the off-critical cluster.

**Verdict:** `GAUSSIAN_CLARK_EDGE_RESONANCE_HAS_FINITE_BAD_CUTOFF_MEASURE_PASS`.

This statement is conditional on the stated monotone exposed-amplitude and
collision-normalization inequalities; those should be supplied by a
publication-grade v497/v496 Gaussian saddle theorem.
