#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v524 — GAUSSIAN CLARK-MASS / COUNTING-MASS TOPOLOGY BIFURCATION
======================================================================

Local exposed offcritical model on one monotone half-wave:

    F(E) = A sin(omega E),   A>>1.

Quantization levels are y_k=k+1/2 with |y_k|<A. At the upward crossing,

    F'(E_k)=omega sqrt(A^2-y_k^2),

so the raw Clark weight is

    w_k = 1/[omega sqrt(A^2-y_k^2)].

The number of roots is ~2A, but away from the single level nearest each
antinode,

    sum_k w_k = pi/omega + O(1/(omega sqrt(A))).

Thus for the Gaussian offcritical exposed mode
    A_L ~ exp(cL^2)/L,
    omega_L ~ a L^2/2,
the root counting mass explodes exponentially while the raw Clark mass is
O(L^-2). Under a collision normalization c_L=O(L), the normalized Clark mass is
O(L^-1).

One exceptional edge level can spike if A lies extremely close to a
half-integer; v525 isolates that resonance.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v524-clark-counting-bifurcation"

def cluster(A,omega):
    import numpy as np
    # half-integer target values y=j+1/2 inside (-A,A)
    j0=math.ceil(-A-.5)
    j1=math.floor(A-.5)
    ys=np.arange(j0,j1+1,dtype=float)+.5
    gaps=A*A-ys*ys
    good=gaps>0
    ys=ys[good]
    w=1.0/(omega*np.sqrt(gaps[good]))
    if len(w)==0:
        return {"A":A,"omega":omega,"count":0}
    edge=int(np.argmax(w))
    trimmed=float(np.sum(np.delete(w,edge))) if len(w)>1 else 0.0
    return {
        "A":float(A),"omega":float(omega),"count":int(len(w)),
        "raw_mass":float(np.sum(w)),
        "trimmed_one_edge_mass":trimmed,
        "pi_over_omega":float(math.pi/omega),
        "trimmed_ratio_to_pi":float(trimmed/(math.pi/omega)),
        "largest_weight":float(w[edge]),
        "edge_y":float(ys[edge]),
    }

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v524 — Gaussian Clark-mass / counting-mass topology bifurcation

Consider one monotone half-wave of the exposed Gaussian secular mode

`F(E)=A sin(omega E)`,
`A>>1`.

For each half-integer quantization value

`y_k=k+1/2`,
`|y_k|<A`,

the upward crossing has slope

`F'(E_k)=omega sqrt(A^2-y_k^2)`.

The raw atomic Clark/Herglotz norming weight is therefore

`w_k=1/F'(E_k)`
`   =1/[omega sqrt(A^2-y_k^2)]`.

The number of crossings is

`N_A=2A+O(1)`.

By contrast, the continuum density satisfies

`int_(-A)^A dy/[omega sqrt(A^2-y^2)]`
` =pi/omega`.

The half-integer Riemann sum has the same limit. More precisely, after removing
the one target value nearest an antinode,

`sum_trim w_k`
` =pi/omega+O(1/(omega sqrt(A)))`.

(The same statement may be written with two endpoint cells removed if one
wants a symmetric elementary Riemann-sum proof.)

Hence an exponentially large number of secular roots can carry only
`O(omega^-1)` total raw Herglotz mass.

For the v497 Gaussian exposed mode,

`A_L=exp[(c/4+o(1))L^2]/L`

on a fixed positive-score interval, while

`omega_L=Theta(L^2)`.

Therefore

`counting mass = exp[Theta(L^2)]`

but

`trimmed raw Clark mass = O(L^-2)`.

The natural critical collision normalization is proportional to `L`; under any
normalization `c_L=O(L)`,

`trimmed normalized Clark mass = O(L^-1)->0`.

## Consequence

There are two genuinely different cutoff topologies:

1. **spectral counting / trace topology** sees the off-critical cluster as an
   explosion and is the topology used by v497-v500;
2. **weak Clark/Herglotz measure topology** can make the same cluster disappear
   because its individual norming weights collapse.

Thus convergence of the v82/v83 Herglotz transforms is not by itself strong
enough to imply the uniform inverse-square trace bound or RH.

The only unresolved local Herglotz channel is the target value nearest an
antinode, where the slope can be anomalously small if `A` is exceptionally
close to a half-integer.

**Verdict:** `GAUSSIAN_COUNTING_EXPLOSION_CLARK_MASS_COLLAPSE_PASS`.

This theorem concerns the local sinusoidal asymptotic model supplied by the
v497 exposed-mode reduction; publication use requires the same uniform saddle
remainder already listed for v497.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_CLARK_BIFURCATION_V1",
        "model":{
            "count":"2A+O(1)",
            "raw_clark_mass":"pi/omega+O(1/(omega sqrt(A))) after edge trim",
            "gaussian_omega":"Theta(L^2)",
            "gaussian_amplitude":"exp(Theta(L^2))/L"
        },
        "conclusion":"counting topology explodes while normalized Clark mass vanishes",
        "remaining":"single antinode-nearest edge resonance + v497 uniform remainder"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_gaussian_clark_bifurcation_v524")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    rows=[]
    with tqdm(total=4,desc="v524 Clark cluster",unit="A") as bar:
        for A in (100.13,1000.27,10000.31,100000.37):
            rows.append(cluster(A,10.0));bar.update(1)
    # Trimmed ratio should approach one.
    ok=abs(rows[-1]["trimmed_ratio_to_pi"]-1)<0.02
    verdict="GAUSSIAN_COUNTING_EXPLOSION_CLARK_MASS_COLLAPSE_PASS" if ok else "DIAGNOSTIC_FAILED"
    payload={"version":VERSION,"verdict":verdict,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Riemann-sum theorem for local sinusoidal model; edge channel isolated."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
