#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v502 — GAUSSIAN CUTOFF AS EXACT HEAT FLOW / OFF-CRITICAL BACKWARD INSTABILITY
====================================================================================

Set tau=L^-2 and define
  Q_tau(E)=∫ exp(-tau y^2) exp(-y/2+iEy) dmu(y)/y.

Then exactly
  partial_tau Q_tau = partial_E^2 Q_tau.

Thus the Gaussian regulator is the spectral heat semigroup.

For a zero-side mode lambda=a+i(gamma-E), the Gaussian transform has
  K_tau(lambda) ~ C(lambda,tau) exp(lambda^2/(4tau)),
so
  log |K_tau| = [a^2-(gamma-E)^2]/(4tau)+O(log(1/tau)).

If a>0, on |E-gamma|<a the mode grows like exp(c/tau) as tau->0.
Critical-line modes a=0 have no positive backward-heat exponent.

Hence off-critical zeros are precisely positive backward-heat instability
directions of the Gaussian arithmetic phase.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v502-gaussian-heat-pde"

def symbolic():
    import sympy as sp
    tau,y,E=sp.symbols("tau y E",positive=True,real=True)
    f=sp.exp(-tau*y*y)*sp.exp(sp.I*E*y)/y
    dt=sp.diff(f,tau)
    dee=sp.diff(f,E,2)
    r=sp.simplify(dt-dee)
    return {"integrand_residual":str(r),"pass":bool(r==0)}

def instability_panel(a):
    rows=[]
    for tau in (.1,.05,.025,.0125):
        exponent=a*a/(4*tau)
        rows.append({"tau":tau,"center_growth_exponent":exponent,
                     "exp_exponent":math.exp(min(exponent,700))})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v502 — Gaussian cutoff as exact heat flow / off-critical backward instability

Introduce the Gaussian smoothing time

`tau=L^-2`

and define the centered complex arithmetic primitive

`Q_tau(E)
 =int exp(-tau y^2) exp(-y/2+iEy) dmu(y)/y`.

At the integrand level,

`partial_tau [e^(-tau y^2)e^(iEy)/y]
 =-y e^(-tau y^2)e^(iEy)`

and

`partial_E^2 [e^(-tau y^2)e^(iEy)/y]
 =-y e^(-tau y^2)e^(iEy)`.

Therefore, wherever the regularized integral is interpreted,

`partial_tau Q_tau(E)=partial_E^2 Q_tau(E)`.

So the analytic Gaussian cutoff is **exactly the heat semigroup in spectral
energy**.

For one zero-side exponential mode put

`lambda=a+i(gamma-E)`.

The Gaussian transform has the standard saddle form

`K_tau(lambda)
 =C(lambda,tau) exp(lambda^2/(4tau))`

with only algebraic prefactor variation in the right-half saddle sector.
Consequently

`log|K_tau|`
` =[a^2-(gamma-E)^2]/(4tau)`
`  +O(log(1/tau))`.

If `a>0`, then on every compact subinterval

`|E-gamma|<=a-delta`

the exponent is strictly positive, and

`|K_tau|>=exp(c_delta/tau)`

up to algebraic factors as `tau->0+`.

By contrast, for a critical-line mode `a=0`,

`Re(lambda^2)=-(gamma-E)^2<=0`;

there is no positive backward-heat exponential.

Thus:

> **Off-critical right-half zeros are exactly positive backward-heat instability
> directions of the Gaussian-regulated arithmetic phase.**

This recasts v497's occupancy explosion in PDE language.  The cutoff limit
`L->infinity` is the boundary limit `tau->0+` of a forward heat extension.
A right-half zero produces a mode that is exponentially ill-conditioned in the
backward direction.

### RH-bearing boundary criteria

Any zero-blind theorem strong enough to show, on every fixed compact energy
interval,

`log^+ sup_E |Q_tau(E)| = o(1/tau)`

as `tau->0+` excludes all positive `a`.

Even more directly, the v501 weighted running-max bound or v500 one-time heat
trace bound excludes the same instability.

This suggests a ROT-native target:

> prove that the recursive-clock arithmetic heat extension has a boundary value
> of **zero backward exponential type** as `tau->0+`.

That statement is weaker than uniform pointwise convergence but strong enough
to rule out every off-critical exponential mode.

**Verdict:** `EXACT_GAUSSIAN_ARITHMETIC_HEAT_PDE_AND_BACKWARD_INSTABILITY_PASS`.

This theorem identifies the instability mechanism; it does not prove the
zero-type boundary estimate.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_HEAT_PDE_V1",
        "closed":{
            "heat_equation":"partial_tau Q_tau=partial_E^2 Q_tau",
            "tau":"L^-2",
            "zero_mode_growth":"exp([a^2-(gamma-E)^2]/(4tau))",
            "critical_line":"a=0 has no positive backward exponent",
            "offcritical":"a>0 gives exp(c/tau) growth on a local energy interval"
        },
        "next_attack":{
            "target":"prove zero backward exponential type for the zero-blind recursive arithmetic heat extension",
            "sufficient":"tau log^+ sup_{E in compact}|Q_tau(E)| -> 0",
            "alternative":"prove v501 weighted running-max bound or v500 one-u heat bound"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--a",type=float,default=.2)
    ap.add_argument("--prefix",default="rot_rh_gaussian_heat_pde_v502")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v502 heat PDE",unit="step") as bar:
        sym=symbolic();bar.update(1)
        pan=instability_panel(args.a);bar.update(1)
    ok=bool(sym["pass"] and pan[-1]["center_growth_exponent"]>pan[0]["center_growth_exponent"])
    verdict="EXACT_GAUSSIAN_ARITHMETIC_HEAT_PDE_AND_BACKWARD_INSTABILITY_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"runtime_seconds":time.perf_counter()-t0,
             "symbolic":sym,"instability_demo":pan,
             "proof_status":"Exact heat PDE plus standard Gaussian zero-mode saddle; zero backward type remains open."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
