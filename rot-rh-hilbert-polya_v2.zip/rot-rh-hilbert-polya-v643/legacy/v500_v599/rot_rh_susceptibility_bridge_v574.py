#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v574-susceptibility-bridge-audit"
THEOREM=r"""# ROT-RH v574 — the ROT susceptibility dictionary is not yet an operator identity

Two distinct response objects are currently present.

## Arithmetic response

The sigma-flow / Gaussian secular construction uses a phase

`Phi(E)`

and its local spectral response

`S_arith(E)=partial_E Phi(E)`.

For the centered Gaussian field this is a first derivative of the argument of
the determinant, equivalently the real part of a logarithmic derivative.

## Compact-phase ROT response

The compact winding ensemble introduces a source-coupled partition function

`Z_ROT(alpha,J)`

and defines connected Ward responses by derivatives with respect to the source
`J`.  Its susceptibility is a source-response quantity built from normalized
winding moments.

These are not automatically the same object:
- they differentiate with respect to different variables;
- one is a one-point logarithmic phase derivative;
- the other is a connected source response / moment functional.

Calling both quantities "susceptibility" is a physical dictionary, not yet a
mathematical equality.

## Exact bridge required

A sufficient non-circular bridge would be an identity or domination theorem of
the form

`|partial_E Phi_L(E)|`
` <=exp[o(L^2)]`
`   R_ROT(alpha_L,J_L(E))`

on every fixed energy chamber, where:
- `R_ROT` is built from a finite-order source response of the compact winding
  ensemble;
- `log^+(1/alpha_L)=o(L^2)`;
- the source map and normalization are zero-blind and themselves have
  `exp[o(L^2)]` conditioning.

Then v573 makes the right-hand side subexponential, whereas v530 shows that an
off-critical zero produces a chamber with

`|partial_E Phi_L|`
` >=exp(cL^2+o(L^2))`.

Contradiction, hence RH.

But deriving that response identity/domination is still open.

## Correct quadratic target

The most natural object for such a Ward identification is not the raw
one-point derivative.  It is the positive two-point Gaussian response

`Q_L(u)`
` =int exp(-uE^2)|P_L(E)|^2 dE`,

because v519/v536 already show:
- `Q_L(u)=exp(o(L^2))` at one fixed `u>0` implies RH;
- its diagonal part is polynomial;
- the off-diagonal centered Mangoldt covariance is the exact RH-sensitive
  order parameter.

So the next ROT bridge should target the **quadratic connected response**
`Q_L`, not identify a scalar phase derivative with a thermodynamic
susceptibility by terminology alone.

**Verdict:** `ROT_ARITHMETIC_AND_COMPACT_SUSCEPTIBILITIES_REQUIRE_EXPLICIT_RESPONSE_BRIDGE_PASS`.
"""
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--prefix",default="rot_rh_susceptibility_bridge_v574");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v574 ledger",unit="step") as bar:bar.update(1)
    verdict="ROT_ARITHMETIC_AND_COMPACT_SUSCEPTIBILITIES_REQUIRE_EXPLICIT_RESPONSE_BRIDGE_PASS"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"preferred_target":"v518/v536 positive two-point Gaussian covariance Q_L","runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({
        "schema":"ROT_RH_SUSCEPTIBILITY_BRIDGE_V1",
        "do_not_assume":"partial_E Phi == compact source susceptibility",
        "preferred_bridge":"ROT connected quadratic response -> v518/v536 Q_L",
        "remaining":"derive zero-blind covariance identity or domination"
    },indent=2))
    print("verdict:",verdict)
if __name__=="__main__":main()
