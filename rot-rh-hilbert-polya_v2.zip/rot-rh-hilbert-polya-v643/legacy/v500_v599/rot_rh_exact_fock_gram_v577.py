#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v577-exact-fock-gram"

THEOREM=r"""# ROT-RH v577 — exact Bargmann-Fock realization of the Gaussian RH covariance

Fix `u>0`. For every real log-frequency `y`, define the normalized
one-mode Bargmann coherent vector

`phi_u(y)`
` =exp[-y^2/(4u)]`
`  sum_(m=0)^infinity`
`  (y/sqrt(2u))^m/sqrt(m!) |m>`.

Its norm is exactly one because

`||phi_u(y)||^2`
` =exp[-y^2/(2u)]`
`  exp[y^2/(2u)]`
` =1`.

The coherent-state overlap is

`<phi_u(y'),phi_u(y)>`
` =exp[-(y^2+y'^2)/(4u)]`
`  exp[yy'/(2u)]`

` =boxed{exp[-(y-y')^2/(4u)}`.

This is exactly the line Gaussian kernel in v518.

Let

`a_(n,L)`
` =(Lambda(n)-1)n^(-1/2)`
`  exp[-(log n/L)^2]`

and define the raw arithmetic Fock state

`Psi_(L,u)`
` =sum_(n>=2) a_(n,L) phi_u(log n)`.

Then, with the same harmless finite convention correction as v518,

`boxed{Q_L(u)`
` =sqrt(pi/u) ||Psi_(L,u)||_F^2}`.

Thus the RH order parameter is exactly a raw Fock-state norm.  There is:
- no adaptive-circle approximation;
- no periodization error;
- no normalization of the state;
- no known-zero input.

## Fock coordinates

The `m`-th coordinate is

`Psi_m`
` =1/sqrt(m!)(2u)^(-m/2)`
`  sum_n a_(n,L)`
`  (log n)^m exp[-(log n)^2/(4u)]`.

Hence the Gaussian RH covariance is a positive sum of squared centered
log-moment amplitudes:

`Q_L(u)`
` =sqrt(pi/u) sum_(m>=0)|Psi_m|^2`.

The original off-diagonal covariance is therefore encoded in coherent
interference **inside each Fock coordinate**, not between different Fock
degrees.

## Finite polynomial effective depth

If the arithmetic source is restricted to the Gaussian-active band

`0<=log n<=B_L=C L^2`,

then every individual coherent vector has Poisson Fock-number distribution
with mean

`lambda(y)=y^2/(2u)`
` <=C^2 L^4/(2u)`.

Standard Poisson Chernoff bounds show that truncating the coherent-state
features at

`M_L=A L^4`

with fixed `A>C^2/(2u)` loses `exp[-c_A L^4]` from each normalized feature.
After multiplying by the worst elementary arithmetic absolute mass
`exp[O(L^2)]`, the full feature truncation error remains superexponentially
small on the RH `L^2` scale.

So the exact Gaussian covariance has a polynomial-dimensional Fock
approximation of dimension `O(L^4)` with superexponentially small error.

## Relation to v569

v569 also uses the normalized monomial Bargmann basis

`e_m(z)=z^m/sqrt(m!)`

for the Volterra operator.

This is an exact common Hilbert-space *model*. It does **not** yet identify:
- Gaussian log-moment degree `m`;
- Volterra recursion depth `m`.

A unitary identification of the abstract bases is trivial, but an arithmetic
intertwining theorem is not.

**Verdict:** `GAUSSIAN_RH_COVARIANCE_IS_EXACT_RAW_BARGMANN_FOCK_NORM_PASS`.

The remaining RH theorem is a zero-blind subexponential bound on this raw
Fock norm, or an exact coercive intertwiner with the preconditioned Selberg
recursion.
"""

def overlap(y,z,u,M):
    s=0.0
    for m in range(M+1):
        s+=(y*z/(2*u))**m/math.factorial(m)
    approx=math.exp(-(y*y+z*z)/(4*u))*s
    exact=math.exp(-((y-z)**2)/(4*u))
    return {"y":y,"z":z,"u":u,"M":M,"approx":approx,"exact":exact,"error":abs(approx-exact)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--y",type=float,default=2.0);ap.add_argument("--z",type=float,default=2.5);ap.add_argument("--u",type=float,default=1.0);ap.add_argument("--M",type=int,default=40);ap.add_argument("--prefix",default="rot_rh_exact_fock_gram_v577");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v577 Fock Gram",unit="step") as bar:
        chk=overlap(a.y,a.z,a.u,a.M);bar.update(1)
    ok=chk["error"]<1e-12
    verdict="GAUSSIAN_RH_COVARIANCE_IS_EXACT_RAW_BARGMANN_FOCK_NORM_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"check":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_EXACT_FOCK_GRAM_V1","identity":"Q_L=sqrt(pi/u)||sum a_n phi_u(logn)||^2","feature_dimension":"O(L^4) with superexp truncation on logn<=CL^2","remaining":"coercive arithmetic intertwiner / raw norm bound"},indent=2))
    print("verdict:",verdict);print(chk)
    if a.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
