#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,cmath,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v564-gaussian-wick-selberg"

THEOREM=r"""# ROT-RH v564 — exact Gaussian heat/Wick Selberg algebra

For an arithmetic coefficient sequence `c_n`, define

`H_tau[c](E)`
` =sum_(n>=1)c_n n^(-1/2)`
`   exp[-tau(log n)^2] exp(iElog n)`,

with `c_1` included when convenient.

Let `c*d` denote Dirichlet convolution.

Define a bilinear product `star_tau` on positive-frequency exponential
polynomials by its action on frequency atoms,

`e_y(E)=exp(iEy)`,

`e_y star_tau e_z`
` :=exp[-2tau yz] e_(y+z)`.

Then, coefficient by coefficient,

`boxed{H_tau[c*d]=H_tau[c] star_tau H_tau[d]}`.

Indeed for `n=ab`, with `y=log a`, `z=log b`,

`exp[-tau(y+z)^2]`
` =exp[-tau y^2]exp[-tau z^2]exp[-2tau yz]`.

The product is commutative and associative because the accumulated factor for
three frequencies is

`exp[-2tau(yz+yw+zw)]`

independently of bracketing.

Equivalently, if `S_tau=exp(tau partial_E^2)` is the heat operator, then

`f star_tau g`
` =S_tau[(S_tau^-1 f)(S_tau^-1 g)]`

on finite positive-frequency sums.

## Exact Gaussian-regulated Selberg equation

Put

`b(1)=0`, `b(n)=1` for `n>=2`,
`r(n)=Lambda(n)-b(n)`.

Selberg's pointwise identity is

`r(n)log n+2(b*r)(n)+(r*r)(n)=H(n)`.

Define

`R_tau=H_tau[r]`,
`B_tau=H_tau[b]`,
`Hcal_tau=H_tau[H]`.

Since

`partial_E R_tau`
` =i H_tau[r log](E)`,

the exact regulated equation is

`boxed{-i partial_E R_tau`
` +2 B_tau star_tau R_tau`
` +R_tau star_tau R_tau`
` =Hcal_tau}`.

No limiting argument is used.

## Why this is structurally useful

For positive log-frequencies `y,z>=0`,

`0<exp[-2tau yz]<=1`.

Thus every multiplicative interaction acquires a **genuine Gaussian
cross-damping**.  At the logarithmic saddle scale
`y=(beta/2)tau^-1`, a quotient frequency `z=log q` contributes

`exp[-beta z]=q^(-beta)`,

exactly the beta-conjugation mechanism appearing in v531, with the additional
self-damping `exp[-tau z^2]` supplied by the one-particle heat factors.

Therefore v531's scale-dependent beta is not an artificial norm choice: it is
the local interaction weight of the exact Gaussian Wick algebra.

**Verdict:** `EXACT_GAUSSIAN_REGULATOR_TURNS_SELBERG_CONVOLUTION_INTO_DAMPED_WICK_PRODUCT_PASS`.

This is an algebraic theorem.  A Gaussian-L2 energy inequality for `star_tau`
strong enough to control v523 remains open.
"""

def check(tau,y,z,w):
    # associativity and heat factor identities on atoms
    f=math.exp(-2*tau*y*z)
    left=f*math.exp(-2*tau*(y+z)*w)
    right=math.exp(-2*tau*z*w)*math.exp(-2*tau*y*(z+w))
    heat=math.exp(-tau*(y+z)**2)
    fact=math.exp(-tau*y*y)*math.exp(-tau*z*z)*f
    return {"tau":tau,"heat_factor_error":abs(heat-fact),
            "associativity_error":abs(left-right),
            "cross_factor":f}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tau",type=float,default=.01)
    ap.add_argument("--y",type=float,default=2.3)
    ap.add_argument("--z",type=float,default=3.1)
    ap.add_argument("--w",type=float,default=1.7)
    ap.add_argument("--prefix",default="rot_rh_gaussian_wick_selberg_v564")
    ap.add_argument("--strict",action="store_true")
    a=ap.parse_args(); t0=time.perf_counter()
    with tqdm(total=1,desc="v564 Wick",unit="step") as bar:
        chk=check(a.tau,a.y,a.z,a.w); bar.update(1)
    ok=chk["heat_factor_error"]<1e-14 and chk["associativity_error"]<1e-14 and 0<chk["cross_factor"]<=1
    verdict="EXACT_GAUSSIAN_REGULATOR_TURNS_SELBERG_CONVOLUTION_INTO_DAMPED_WICK_PRODUCT_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"demo":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_WICK_SELBERG_V1",
        "identity":"H_tau[c*d]=H_tau[c] star_tau H_tau[d]",
        "atom_factor":"exp(-2 tau y z)",
        "regulated_selberg":"-i dE R +2 B star R+R star R=H",
        "next":"prove weighted Gaussian-L2/Wick energy inequality"
    },indent=2))
    print("verdict:",verdict); print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
