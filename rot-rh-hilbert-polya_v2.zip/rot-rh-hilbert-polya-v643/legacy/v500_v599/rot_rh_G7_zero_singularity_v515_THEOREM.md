# ROT-RH v515 — G7 preserves every off-critical zero as a nonremovable singularity

Use the exact v511 gauge

`B_X=mu X`

and coordinate

`z=-log zeta`.

Then `R` becomes

`Jg(z)=int_0^z g(eta)deta`.

The fixed-point identities become

`B_X=(I-J)^(-1)f0`

and

`g7:=U G7`
` =(I+J+...+J^6)f0`
` =(I-J^7)B_X`.

Let `rho` be a zero of multiplicity `m` and put `t=s-rho`. Locally

`zeta(s)=t^m h(s)`,
`h(rho)!=0`,

so

`z=-m log t-log h(s)`.

Moreover

`X(s)
 =-zeta'(s)/zeta(s)-(zeta(s)-1)
 =-m/t+O(1)`.

Since `mu(rho)` is finite and nonzero,

`B_X=mu X`

has a nonzero simple-pole leading term. In the `z` coordinate it has the form

`C exp(z/m)`,
`C!=0`,

times a locally analytic nonzero correction.

## Multiple zero, `m>1`

For the leading exponential,

`J exp(z/m)
 =m[exp(z/m)-1]`.

Hence

`(I-J)exp(z/m)
 =(1-m)exp(z/m)+m`.

Because `m>1`, `1-m!=0`. Thus `f0=(I-J)B_X` already retains the pole
exponential, and the finite polynomial `I+...+J^6` cannot remove it.

So `G7hat` has a pole-type nonremovable singularity at `rho`.

## Simple zero, `m=1`

Now the pole term is `C exp(z)` and

`(I-J)exp(z)=1`.

Thus the simple pole is converted into a **nonzero constant** `C` in the gauged
forcing. Applying the seven-layer head gives

`(I+J+...+J^6)C`
` =C sum_(j=0)^6 z^j/j!`.

The coefficient of `z^6` is

`C/6! !=0`.

Since

`z=-log(s-rho)+O(1)`,

this is a non-removable logarithmic branch singularity at the same zero.

Therefore:

`every zeta zero rho`
` => G7hat has a nonremovable singularity at rho`.

For simple zeros the seven-layer construction removes the **pole order**, but
it does **not** remove the zero location; it leaves a sixth-degree logarithmic
singularity.

**Verdict:** `G7_RETAINS_EVERY_ZERO_AS_NONREMOVABLE_SINGULARITY_PASS`.

This is a local exact theorem on a punctured branch neighborhood, not an RH
proof.
