# ROT-RH v588 — exact Gaussian-lens dissipation identity

Let `P_tau(E)` solve the heat equation

`partial_tau P=partial_E^2 P`

and define

`Q_tau(u)=int_R e^(-uE^2)|P_tau(E)|^2dE`.

For fixed `u`, integration by parts gives

`partial_tau Q`
` =-2 int e^(-uE^2)|P_E|^2dE`
`   +int (4u^2E^2-2u)e^(-uE^2)|P|^2dE`.

Also

`partial_u Q`
` =-int E^2e^(-uE^2)|P|^2dE`.

Now choose a running Gaussian weight satisfying

`boxed{du/dtau=4u^2}`.

Along this curve the `E^2` terms cancel:

`dQ/dtau`
` =-2A_tau(u)-2uQ`,

where

`A_tau(u)`
` :=int e^(-uE^2)|P_E|^2dE`.

Since

`d(sqrt(u))/dtau=2u sqrt(u)`,

we obtain the exact dissipation law

`boxed{`
` d/dtau [sqrt(u)Q_tau(u)]`
` =-2sqrt(u) A_tau(u)`
` <=0}`.

## Finite-time lens endpoint

Start at `(tau_0,u_0)` and solve

`u(tau)`
` =u_0/[1-4u_0(tau-tau_0)]`.

The weight blows up at

`T=tau_0+1/(4u_0)`.

For a smooth heat solution,

`sqrt(u)Q_tau(u)`
` ->sqrt(pi)|P_T(0)|^2`

as `tau->T-`.

Integrating the dissipation identity gives

`boxed{`
` sqrt(u_0)Q_(tau_0)(u_0)`
` =sqrt(pi)|P_T(0)|^2`
`  +2 int_(tau_0)^T`
`    sqrt[u(tau)]`
`    int e^[-u(tau)E^2]|P_E|^2 dE dtau`
`}`.

Apply this to

`P_tau=partial_E log Delta_tau(1/2+iE)`.

The terminal time tends to the fixed positive value `1/(4u_0)` as
`tau_0=L^-2->0`; therefore the terminal field is strongly Gaussian-smoothed
and is not the backward-heat instability.

All possible positive `L^2` exponential type of the small-cutoff RH order
parameter is concentrated in the **accumulated lens dissipation**.

Thus a sufficient RH theorem is the zero-blind bound

`int_(L^-2)^(L^-2+1/(4u_0))`
` sqrt[u(tau)]`
` int e^[-u(tau)E^2]|P_E|^2 dE dtau`
` =exp[o(L^2)]`.

By v519 this would force RH.

## Interpretation

Ordinary forward heat contractivity was the wrong-direction statement.
The lens identity is stronger: it gives an exact positive accounting formula
for the amount of high-frequency/logarithmic-metric energy erased between the
RH boundary and one safe smoothed scale.

**Verdict:** `EXACT_GAUSSIAN_LENS_DISSIPATION_IDENTITY_PASS`.

The dissipation upper bound remains open.
