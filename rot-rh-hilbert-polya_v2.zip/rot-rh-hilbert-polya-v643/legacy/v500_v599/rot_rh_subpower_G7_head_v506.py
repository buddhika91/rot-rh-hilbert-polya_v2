#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v506 — SUBPOWER FINITE-G7 HEAD REDUCTION
===============================================
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v506-subpower-G7-head"

def budget(eta):
    return [{"j":j,"allocated_each":eta/(j+1),
             "total_exponent":(j+1)*(eta/(j+1))} for j in range(7)]

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v506 — subpower finite-G7 head reduction

v300 used the exact dual inequality

`||Ru||_(pref,N,I)<=V_N(I)||u||_(pref,N,I)`

and asked for bounded `V_N` and bounded forcing prefix.

For the Gaussian route it suffices to assume, for every `eps>0`,

`||F0||_(pref,N,I)<=C_(eps,I)N^eps`

and

`V_N(I)<=D_(eps,I)N^eps`.

Fix `eta>0`. For `R^jF0`, `0<=j<=6`, use exponent

`eta/(j+1)`

for the forcing and for each of the `j` R-factors. Then

`||R^jF0||_(pref,N,I)<=C_(j,eta,I)N^eta`.

Summing seven terms,

`G7=(I+R+...+R^6)F0`

satisfies

`||G7||_(pref,N,I)=O_(eta,I)(N^eta)`

for every `eta>0`.

Thus G7 is subpower. By v504 its Gaussian contribution has zero backward
exponential type.

This is strictly weaker than v300's bounded-prefix pair.

**Verdict:** `SUBPOWER_F0_AND_R_DUAL_IMPLY_SUBPOWER_G7_PASS`.

The full fixed point `x=G7+R^7x` still requires a packet-cascade theorem.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_SUBPOWER_G7_V1",
        "old_v300":"bounded F0 + bounded R dual",
        "new":"subpower F0 + subpower R dual",
        "conclusion":"G7=N^o(1); v504 => zero Gaussian type for G7",
        "remaining":"R7 packet cascade in full x"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--eta",type=float,default=.05)
    ap.add_argument("--prefix",default="rot_rh_subpower_G7_head_v506")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v506 budget",unit="step") as bar:
        rows=budget(args.eta);bar.update(1)
    ok=all(abs(r["total_exponent"]-args.eta)<1e-14 for r in rows)
    verdict="SUBPOWER_F0_AND_R_DUAL_IMPLY_SUBPOWER_G7_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"eta":float(args.eta),
             "budget":rows,"runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
