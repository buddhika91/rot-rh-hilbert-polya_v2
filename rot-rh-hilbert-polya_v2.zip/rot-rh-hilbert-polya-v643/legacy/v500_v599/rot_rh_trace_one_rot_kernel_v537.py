#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v537 — EXACT TRACE-ONE ROT KERNEL / UNIFORM COUNTING THEOREM
==================================================================

For the v87/v88 ROT-native kernel:
- every instantaneous response R_n is PSD and trace-normalized;
- K_0=0;
- eta_n=1/(n+1), with n starting at 0;
- K_{n+1}=(1-eta_n)K_n+eta_n R_n.

Therefore K_1=R_0 has trace one and, inductively,
  K_n>=0, Tr K_n=1
for every n>=1.

For scale s>0 define supported energies
  eps_j=s/sqrt(lambda_j(K_n)).
Then
  N_ROT(E) <= E^2/s^2
for every finite stage, because each eps_j<=E implies
lambda_j>=s^2/E^2 and sum lambda_j=1.

Any trace-norm limit K_ROT remains PSD trace class with Tr=1, so
Tr H_ROT^-2=1/s^2 and the same counting bound holds in the limit.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v537-trace-one-rot-kernel"

def scalar_trace_recursion(steps):
    tr=0.0
    rows=[]
    for n in range(steps):
        eta=1.0/(n+1)
        tr=(1-eta)*tr+eta*1.0
        rows.append({"step":n+1,"eta":eta,"trace":tr})
    return rows

def counting_demo(s,E):
    # Worst possible number of eigenvalues >= s^2/E^2 with total mass 1.
    threshold=s*s/(E*E)
    max_count=math.floor(1.0/threshold+1e-12)
    return {"scale_s":s,"energy_E":E,"lambda_threshold":threshold,
            "integer_count_upper":max_count,
            "analytic_count_upper":E*E/(s*s)}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v537 — exact trace-one ROT kernel / uniform counting theorem

The v87/v88 ROT-native construction has three exact structural properties.

1. Every instantaneous response operator is positive semidefinite.
2. Every nonzero response channel is divided by its trace, the channel weights
   are normalized, and the final response is again trace-normalized. Therefore

`R_n>=0`,
`Tr R_n=1`.

3. The recursive kernel starts from

`K_0=0`

and the shell loop is indexed from `n=0` with the parameter-free Cesaro step

`eta_n=1/(n+1)`,

`K_(n+1)=K_n+eta_n(R_n-K_n)`.

At the first shell, `eta_0=1`, so

`K_1=R_0`.

Hence

`K_1>=0`,
`Tr K_1=1`.

If `K_n>=0` and `Tr K_n=1`, then

`K_(n+1)`
` =(1-eta_n)K_n+eta_n R_n`

is a convex combination of PSD trace-one operators. Therefore by induction

`boxed{K_n>=0, Tr K_n=1}`

for every finite stage `n>=1`.

## Exact inverse-square trace

Let the supported positive eigenvalues of `K_n` be `lambda_j>0` and define the
canonical ROT energies exactly as in v86-v88:

`epsilon_j=s/sqrt(lambda_j)`.

Then on the support,

`H_ROT=s K_n^(-1/2)`

and

`H_ROT^(-2)=K_n/s^2`.

Therefore

`boxed{Tr H_ROT^(-2)=1/s^2}`

at every finite stage.

## Uniform fixed-energy counting

If

`epsilon_j<=E`,

then

`lambda_j>=s^2/E^2`.

Hence

`N_ROT(E) s^2/E^2`
` <=sum_(epsilon_j<=E)lambda_j`
` <=Tr K_n=1`.

Thus

`boxed{N_ROT(E)<=E^2/s^2}`

for every finite stage, every winding dimension, and every number/order of
prime shells.

This is a genuine zero-blind spectral-counting theorem.

## Infinite limit

If a joint prime-shell/winding limit exists in trace norm,

`K_n -> K_ROT`,

then trace is continuous:

`Tr K_ROT=1`.

If the limit is positive, compact and injective, then

`H_ROT=sK_ROT^(-1/2)`

is the usual unbounded positive self-adjoint operator and still

`Tr H_ROT^(-2)=1/s^2`,
`N_ROT(E)<=E^2/s^2`.

**Verdict:** `EXACT_TRACE_ONE_ROT_KERNEL_UNIFORM_COUNTING_PASS`.

No Xi, zeta values, zero ordinates, or secular roots enter this theorem.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_TRACE_ONE_KERNEL_V1",
        "closed":{
            "finite_K":"PSD, trace exactly 1 after first shell",
            "finite_inverse_square_trace":"1/s^2",
            "finite_counting":"N_ROT(E)<=E^2/s^2",
            "trace_norm_limit":"preserves trace 1"
        },
        "next":"one-sided spectral domination bridge from Gaussian secular spectrum to ROT spectrum"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--steps",type=int,default=20)
    ap.add_argument("--scale",type=float,default=2*math.pi)
    ap.add_argument("--energy",type=float,default=100.0)
    ap.add_argument("--prefix",default="rot_rh_trace_one_rot_kernel_v537")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v537 invariants",unit="step") as bar:
        rows=scalar_trace_recursion(args.steps);bar.update(1)
        cnt=counting_demo(args.scale,args.energy);bar.update(1)
    ok=all(abs(r["trace"]-1.0)<1e-15 for r in rows)
    verdict="EXACT_TRACE_ONE_ROT_KERNEL_UNIFORM_COUNTING_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"trace_recursion":rows,
             "counting_demo":cnt,"runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact induction/counting theorem; scalar recursion is diagnostic."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("counting:",cnt)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
