# ROT-RH v546 — per-shell normalization amplitude-erasure no-go

The v86 arithmetic source first forms the raw winding moment vector

`a_j(m)`
` =sum_(p in shell j)`
`  w_p exp(i m log p)`

and then explicitly returns

`u_j=a_j/||a_j||_2`.

The source matrix passed to the recursive observer dynamics is

`Q_j=|u_j><u_j|-I/d`

(up to the trace-zero helper convention).

Now rescale the complete raw forcing in one shell by any scalar

`c_j>0`.

Then exactly

`a_j -> c_j a_j`

but

`u_j -> c_j a_j/||c_j a_j||=u_j`.

Therefore

`Q_j -> Q_j`.

Since the v87/v88 downstream active/shadow/observer/kappa/response recursions
are deterministic functions of these source matrices and the previous state,
the final response kernel `K` is invariant under arbitrary positive
shell-by-shell rescalings.

By contrast, the arithmetic secular prime phase is **linear in the raw shell
weights**. The same transformation changes the shell contribution by `c_j`.

Hence the current normalized source representation discards radial arithmetic
information that the secular construction retains.

This gives an exact representation-level obstruction:

`boxed{the unchanged v86-v88 kernel cannot generically determine the raw secular phase from its stored source state alone}`.

For the actual Mangoldt weights there is of course one fixed arithmetic
rescaling, so this is not a counterexample to a possible accidental theorem
for that single sequence. It shows that such a theorem cannot follow merely
from the normalized representation and its generic operator identities.

A redesigned independent ROT operator must retain both:
- prime-phase direction;
- shell amplitude/coherence.

**Verdict:** `V86_V88_SHELL_NORMALIZATION_ERASES_SECULAR_AMPLITUDE_PASS`.
