# ROT-RH v514 — Lyapunov / logarithmic-derivative circularity audit

v511 proves that the recursive transfer `R` is, after an exact gauge and
coordinate change, ordinary Volterra integration in

`z=-log zeta(s)`.

Thus a packet-depth Lyapunov law built only from the horizontal real part of
the zeta/xi logarithmic connection must be checked for circularity.

For the completed Riemann function

`xi(s)=1/2 s(s-1) pi^(-s/2) Gamma(s/2) zeta(s)`,

the classical Hinkkanen/Lagarias criterion states

`RH`

if and only if

`Re[xi'(s)/xi(s)]>0`

throughout

`Re(s)>1/2`.

So the following proposed closure is **RH-equivalent**, not a smaller lemma:

`prove Re[xi'/xi]>0 on the entire right critical half-plane`
` => conclude packet-flow contractivity`
` => conclude RH`.

Likewise, proving global horizontal monotonicity of `|xi(s)|` in that entire
half-plane is not an independent ROT mechanism.

## What remains non-circular

A valid new closure must establish the v510 subexponential mesoscopic cascade
from structure that is already defined without knowing the zero set, for
example:

1. a self-adjoint/canonical-system realization whose Weyl function is
   Herglotz by operator theory;
2. a genuine positive/passive transfer determinant derived from the ROT
   recursion before identifying it with zeta;
3. a quadratic form or energy inequality for the G7-generated cyclic orbit
   whose proof uses only coefficient/operator identities and not the sign of
   `xi'/xi`;
4. an exact Fredholm perturbation determinant identification with a
   self-adjoint operator.

**Verdict:** `LOG_DERIVATIVE_POINTWISE_LYAPUNOV_ROUTE_IS_RH_EQUIVALENT_NOGO_PASS`.

This removes a circular next step; it does not prove RH.
