# ROT-RH v520 — beta=1/2 finite-horizon positive resolvent polylog theorem

At the endpoint `beta=1/2`, the beta-conjugated positive `K_b` scalar kernel is

`phi_k(d)=k^(-1) log d/log(kd)^2`.

Fix a finite horizon `M` and `2<=d<=M/2`. Put

`t=log d`,
`c=log2`,
`H=log M`,
`K=floor(M/d)`.

Because

`x -> x^(-1)t/log(xd)^2`

is positive decreasing,

`sum_(k=2)^K phi_k(d)`
` <=phi_2(d)+int_2^K t/[x log(xd)^2]dx`

` <=t/[2(t+c)^2]`
`   +t/(t+c)-t/H`.

Call the right side `B(d,M)`.

Then

`1-B`
` =[(c-1/2)t+c^2]/(t+c)^2+t/H`.

Use the elementary inequalities

`c=log2>2/3`,
`t>=c`,
`t+c<=2t`.

Therefore

`1-B`
` >=1/(24t)+t/H`
` >=1/sqrt(6H)`,

by AM-GM.

Hence every finite-horizon positive resolvent satisfies

`||(I-K_b)^(-1)||_(infty->infty)`
` <=sqrt(6 log M)`.

So the apparent divergence at `beta=1/2` is only **polylogarithmic** in the
finite horizon. The endpoint is not exponentially unstable.

With an unconditional Chebyshev bound `psi(x)<=C x`, the corresponding
`K_Lambda` row mass is also `O(1)` at beta=1/2 by partial summation, so any
fixed finite number of `R=(I-K_b)^(-1 K_Lambda)` applications has at most a
fixed power of `log M` growth.

This provides a genuine unconditional square-root-boundary theorem.

It does **not** control `beta<1/2`; that is precisely where an off-critical
singularity may live.

**Verdict:** `BETA_HALF_FINITE_HORIZON_POSITIVE_RESOLVENT_POLYLOG_PASS`.
