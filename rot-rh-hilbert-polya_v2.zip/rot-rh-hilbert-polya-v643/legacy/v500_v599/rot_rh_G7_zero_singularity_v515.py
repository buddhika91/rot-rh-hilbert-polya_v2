#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v515 — G7 PRESERVES EVERY OFF-CRITICAL ZERO AS A NONREMOVABLE SINGULARITY
=================================================================================

Use v511's gauge/coordinate:
  B_X = mu X,
  J g(z)=int_0^z g,
  z=-log zeta,
and the exact fixed point
  B_X=(I-J)^(-1) f0,
  g7=(I+...+J^6)f0=(I-J^7)B_X.

Let rho be a zeta zero of multiplicity m.

Locally zeta=t^m h, t=s-rho, h(rho)!=0, so
  z=-m log t - log h.

Also
  X=-zeta'/zeta-(zeta-1)=-m/t+O(1),
hence B_X has a nonzero simple-pole leading term, which in z-coordinate is
  C exp(z/m), C!=0.

If m>1:
  (I-J) exp(z/m)=(1-m)exp(z/m)+m,
so f0 retains the exponential pole and therefore g7 does too.

If m=1:
  (I-J) exp(z)=1.
The pole is converted into a nonzero constant C in f0. Applying
  I+J+...+J^6
gives
  C sum_{j=0}^6 z^j/j!,
so g7 has a nonzero log^6 singularity.

Thus every zero of zeta remains a nonremovable singularity of G7hat:
pole for m>1, logarithmic branch for m=1.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v515-G7-zero-singularity"

def model_check(m,z):
    # Leading model B=exp(z/m); f0=(I-J)B.
    # For m=1, exact g7 from leading pole is sum z^j/j!.
    if m==1:
        g=sum(z**j/math.factorial(j) for j in range(7))
        return {"m":m,"z":z,"model_G7":g,
                "leading_kind":"log_polynomial_degree_6",
                "nonzero":abs(g)>0}
    # For m>1, leading exponential coefficient after I-J is (1-m).
    coeff=(1-m)
    return {"m":m,"z":z,"leading_exponential_coeff":coeff,
            "leading_kind":"simple_pole_retained",
            "nonzero":coeff!=0}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v515 — G7 preserves every off-critical zero as a nonremovable singularity

Use the exact v511 gauge

`B_X=mu X`

and coordinate

`z=-log zeta`.

Then `R` becomes

`Jg(z)=int_0^z g(eta)deta`.

The fixed-point identities become

`B_X=(I-J)^(-1)f0`

and

`g7:=U G7`
` =(I+J+...+J^6)f0`
` =(I-J^7)B_X`.

Let `rho` be a zero of multiplicity `m` and put `t=s-rho`. Locally

`zeta(s)=t^m h(s)`,
`h(rho)!=0`,

so

`z=-m log t-log h(s)`.

Moreover

`X(s)
 =-zeta'(s)/zeta(s)-(zeta(s)-1)
 =-m/t+O(1)`.

Since `mu(rho)` is finite and nonzero,

`B_X=mu X`

has a nonzero simple-pole leading term. In the `z` coordinate it has the form

`C exp(z/m)`,
`C!=0`,

times a locally analytic nonzero correction.

## Multiple zero, `m>1`

For the leading exponential,

`J exp(z/m)
 =m[exp(z/m)-1]`.

Hence

`(I-J)exp(z/m)
 =(1-m)exp(z/m)+m`.

Because `m>1`, `1-m!=0`. Thus `f0=(I-J)B_X` already retains the pole
exponential, and the finite polynomial `I+...+J^6` cannot remove it.

So `G7hat` has a pole-type nonremovable singularity at `rho`.

## Simple zero, `m=1`

Now the pole term is `C exp(z)` and

`(I-J)exp(z)=1`.

Thus the simple pole is converted into a **nonzero constant** `C` in the gauged
forcing. Applying the seven-layer head gives

`(I+J+...+J^6)C`
` =C sum_(j=0)^6 z^j/j!`.

The coefficient of `z^6` is

`C/6! !=0`.

Since

`z=-log(s-rho)+O(1)`,

this is a non-removable logarithmic branch singularity at the same zero.

Therefore:

`every zeta zero rho`
` => G7hat has a nonremovable singularity at rho`.

For simple zeros the seven-layer construction removes the **pole order**, but
it does **not** remove the zero location; it leaves a sixth-degree logarithmic
singularity.

**Verdict:** `G7_RETAINS_EVERY_ZERO_AS_NONREMOVABLE_SINGULARITY_PASS`.

This is a local exact theorem on a punctured branch neighborhood, not an RH
proof.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_G7_ZERO_SINGULARITY_V1",
        "closed":{
            "m_gt_1":"pole exponential survives because 1-m != 0",
            "m_eq_1":"pole cancels under I-J but G7 gets C sum_{j=0}^6 z^j/j!, C!=0",
            "conclusion":"every zero remains a nonremovable G7hat singularity"
        },
        "implication":"subpower global G7 prefix is itself RH-strength"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--z",type=float,default=10.0)
    ap.add_argument("--prefix",default="rot_rh_G7_zero_singularity_v515")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=2,desc="v515 local models",unit="case") as bar:
        a=model_check(1,args.z);bar.update(1)
        b=model_check(2,args.z);bar.update(1)
    ok=bool(a["nonzero"] and b["nonzero"])
    verdict="G7_RETAINS_EVERY_ZERO_AS_NONREMOVABLE_SINGULARITY_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"simple_model":a,
             "multiple_model":b,"runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
