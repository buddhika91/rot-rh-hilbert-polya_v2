# ROT-RH v544 — exact Cesaro response-accessibility identity

The v87/v88 observer kernel obeys

`K_0=0`

and

`K_(n+1)`
` =K_n+[R_n-K_n]/(n+1)`.

Then, for every `N>=1`,

`boxed{K_N=(1/N)sum_(j=0)^(N-1)R_j}`.

Proof is immediate by induction. For `N=1`, `K_1=R_0`. If the identity holds
at `N`, then

`K_(N+1)`
` =N/(N+1)K_N+1/(N+1)R_N`

` =1/(N+1)sum_(j=0)^N R_j`.

Consequently, for every observer-space vector `v`,

`boxed{`
` <v,K_Nv>`
` =(1/N)sum_j <v,R_jv>`
`}`.

Thus the accessibility quantity in v543 has an exact physical/arithmetic
meaning: it is the mean response of that state across the causal prime-shell
observation history.

A sufficient v543 hypothesis can therefore be written without diagonalizing
`K_N`:

For every secular level in a fixed energy window, construct a response vector
`v_(k,L)` such that

`(1/N_L^shell)sum_j`
` <v_(k,L),R_(j,L)v_(k,L)>`
` >=a_E(L)`,

while the collection of response vectors has Bessel constant `B_E(L)` and

`log[B_E(L)/a_E(L)]=o(L^2)`.

Then v543 and v530 imply RH.

**Verdict:** `EXACT_ROT_CESARO_MEAN_ACCESSIBILITY_IDENTITY_PASS`.

This identity is exact for the existing v87/v88 recursion. The secular-state
response lower bound is still open.
