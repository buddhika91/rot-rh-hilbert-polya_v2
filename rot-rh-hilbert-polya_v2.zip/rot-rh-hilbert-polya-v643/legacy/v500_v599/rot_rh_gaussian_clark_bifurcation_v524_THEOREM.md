# ROT-RH v524 — Gaussian Clark-mass / counting-mass topology bifurcation

Consider one monotone half-wave of the exposed Gaussian secular mode

`F(E)=A sin(omega E)`,
`A>>1`.

For each half-integer quantization value

`y_k=k+1/2`,
`|y_k|<A`,

the upward crossing has slope

`F'(E_k)=omega sqrt(A^2-y_k^2)`.

The raw atomic Clark/Herglotz norming weight is therefore

`w_k=1/F'(E_k)`
`   =1/[omega sqrt(A^2-y_k^2)]`.

The number of crossings is

`N_A=2A+O(1)`.

By contrast, the continuum density satisfies

`int_(-A)^A dy/[omega sqrt(A^2-y^2)]`
` =pi/omega`.

The half-integer Riemann sum has the same limit. More precisely, after removing
the one target value nearest an antinode,

`sum_trim w_k`
` =pi/omega+O(1/(omega sqrt(A)))`.

(The same statement may be written with two endpoint cells removed if one
wants a symmetric elementary Riemann-sum proof.)

Hence an exponentially large number of secular roots can carry only
`O(omega^-1)` total raw Herglotz mass.

For the v497 Gaussian exposed mode,

`A_L=exp[(c/4+o(1))L^2]/L`

on a fixed positive-score interval, while

`omega_L=Theta(L^2)`.

Therefore

`counting mass = exp[Theta(L^2)]`

but

`trimmed raw Clark mass = O(L^-2)`.

The natural critical collision normalization is proportional to `L`; under any
normalization `c_L=O(L)`,

`trimmed normalized Clark mass = O(L^-1)->0`.

## Consequence

There are two genuinely different cutoff topologies:

1. **spectral counting / trace topology** sees the off-critical cluster as an
   explosion and is the topology used by v497-v500;
2. **weak Clark/Herglotz measure topology** can make the same cluster disappear
   because its individual norming weights collapse.

Thus convergence of the v82/v83 Herglotz transforms is not by itself strong
enough to imply the uniform inverse-square trace bound or RH.

The only unresolved local Herglotz channel is the target value nearest an
antinode, where the slope can be anomalously small if `A` is exceptionally
close to a half-integer.

**Verdict:** `GAUSSIAN_COUNTING_EXPLOSION_CLARK_MASS_COLLAPSE_PASS`.

This theorem concerns the local sinusoidal asymptotic model supplied by the
v497 exposed-mode reduction; publication use requires the same uniform saddle
remainder already listed for v497.
