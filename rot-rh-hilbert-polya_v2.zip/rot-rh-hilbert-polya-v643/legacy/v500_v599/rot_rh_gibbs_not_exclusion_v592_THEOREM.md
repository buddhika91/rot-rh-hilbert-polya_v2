# ROT-RH v592 — Gaussian winding suppression is not spectral exclusion

Consider the compact winding Gibbs ensemble

`p_k=Z(alpha)^(-1)e^(-alpha k^2)`,
`alpha>0`.

For every finite integer `k`,

`boxed{p_k>0}`.

Therefore the Gaussian spectral weight suppresses large winding but does not
remove any winding sector from the Hilbert space.

Even if

`p_k<=exp[-exp(cL^2)]`

for a very large label `k`, that sector still exists spectrally.

Consequently a thermodynamic statement such as

`<N^2><=poly(L)`

or

`Prob(|N|>=K)<=exp[-alpha K^2]`

does not imply a hard counting statement

`#{k:E_k<=E}<=poly(L)`

unless there is an additional energy/accessibility relation tying physical
secular energy to winding charge.

This distinction is crucial for v530:
the contradiction concerns the **existence and multiplicity of spectral
levels**, not their Gibbs probability.

Thus the maximum-entropy/Euclidean weighting in the current ROT compact phase
construction cannot replace the v591 one-sided rotor Hamiltonian inequality.

**Verdict:** `ROT_GAUSSIAN_WINDING_WEIGHT_ALONE_DOES_NOT_EXCLUDE_HIGH_SPECTRAL_SECTORS_PASS`.
