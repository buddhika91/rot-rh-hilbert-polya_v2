#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v567-raw-jacobian-pnt-barrier"
THEOREM=r"""# ROT-RH v567 — raw Selberg Jacobian has the universal 1/16 Gaussian PNT barrier

Use the exact v523 Jacobian

`(J delta r)(n)`
` =-2/log n`
`   sum_(d|n,d<n)Lambda(n/d)delta r(d)`.

Take `delta r=e_2`.

For every prime `p`,

`(Je_2)_(2p)`
` =-2logp/log(2p)`.

Its v523 Gaussian observable therefore contains

`P_L(E)`
` =sum_p`
`   [-2logp/log(2p)]`
`   (2p)^(-1/2)`
`   exp[-(log(2p)/L)^2]`
`   exp[iElog(2p)]`

plus same-sign prime-power terms.

Let

`Y_L=L^2/4`

and restrict to primes with

`|log(2p)-Y_L|<=L`.

For `|E|<=c/L^2` with one sufficiently small fixed `c>0`, all phases in this
packet lie in a fixed acute sector, so there is no destructive cancellation.

By the prime number theorem, partial summation on this logarithmic band gives

`sum_(band primes)`
` p^(-1/2) exp[-(log(2p)/L)^2]`

` =exp[(1/16+o(1))L^2]`.

The exponent is the elementary Laplace maximum of

`f(y)=y/2-y^2/L^2`

at

`y=L^2/4`,

where

`f(Y_L)=L^2/16`.

Hence uniformly on the small energy interval,

`|P_L(E)|`
` >=exp[(1/16-o(1))L^2]`.

The interval has only polynomially small width `Theta(L^-2)`, so for every
fixed Gaussian energy weight parameter `u>0`,

`boxed{||Je_2||_(L,u)^2`
` >=exp[(1/8-o(1))L^2]}`

and therefore

`boxed{||J||_(L,u->L,u)`
` >=exp[(1/16-o(1))L^2]}`.

## Consequence

The raw Frechet Jacobian contains the uncentered positive Mangoldt channel and
therefore sees the universal pole-at-one/PNT saddle **before** the centered
arithmetic cancellation.

For a hypothetical off-critical displacement `0<a<1/2`, the dangerous
Gaussian norm rate is only

`a^2/4 <1/16`.

Thus raw-Jacobian operator-norm control is exponentially too expensive to
prove the RH contradiction.

The correct Gaussian operator must first resum/cancel the smooth `+1`
background—namely the exact preconditioned transfer

`R=(I-K_b)^(-1)K_Lambda`

or an equivalent centered formulation.

**Verdict:** `RAW_GAUSSIAN_GRAM_JACOBIAN_HAS_1OVER16_PNT_BARRIER_PASS`.

External input: the classical prime number theorem only.  No zero ordinates or
numerical zeta values are used.
"""
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_raw_jacobian_pnt_barrier_v567")
    ap.add_argument("--strict",action="store_true")
    a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v567 exponent",unit="step") as bar:
        saddle=.25
        amp_rate=1/16
        gram_rate=1/8
        ok=abs((saddle/2-saddle*saddle)-amp_rate)<1e-15
        bar.update(1)
    verdict="RAW_GAUSSIAN_GRAM_JACOBIAN_HAS_1OVER16_PNT_BARRIER_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({
        "version":VERSION,"verdict":verdict,
        "log_frequency_saddle_over_L2":saddle,
        "norm_exponent_lower":amp_rate,
        "squared_norm_exponent_lower":gram_rate,
        "runtime_seconds":time.perf_counter()-t0
    },indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({
        "schema":"ROT_RH_RAW_J_PNT_BARRIER_V1",
        "rejected":"raw J Gaussian-Gram operator norm route",
        "barrier":"1/16 in norm",
        "reason":"uncentered positive Lambda/PNT main term",
        "next":"Gaussian Gram theorem for smooth-preconditioned/centered transfer R"
    },indent=2))
    print("verdict:",verdict)
    print("norm exponent lower:",amp_rate)
    if a.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
