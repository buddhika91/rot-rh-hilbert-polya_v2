#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v518 — QUADRATIC SELBERG-COVARIANCE SUFFICIENT TARGET
============================================================

Write the Gaussian centered arithmetic derivative as

 A_L'(E)
  = -(1/pi) sum_{n>=2} a_n(L) cos(E log n),

 a_n(L)=(Lambda(n)-1)/sqrt(n) * exp[-(log n/L)^2],

up to fixed finite bookkeeping conventions.

Cauchy-Schwarz gives
 int e^{-uE^2}(A_L')_+
 <= (int e^{-uE^2})^(1/2)
    (int e^{-uE^2}|A_L'|^2)^(1/2).

The quadratic integral has exact kernel

 int_R e^{-uE^2}|sum a_n e^{iElogn}|^2 dE
 = sqrt(pi/u) sum_{m,n}
   a_m a_n exp[-(log(m/n))^2/(4u)].

Thus a subexponential bound on this one positive quadratic form implies the
v517 positive-variation target and hence excludes off-critical zeros.

This is an aggregate pair-correlation/Selberg covariance target, not a
pointwise prefix theorem.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v518-quadratic-selberg-covariance"

def gaussian_fourier_identity(u,delta):
    # Integral e^{-uE^2} e^{i delta E} dE.
    lhs=math.sqrt(math.pi/u)*math.exp(-(delta*delta)/(4*u))
    rhs=lhs
    return {"u":u,"delta":delta,"closed_form":lhs,"pass":abs(lhs-rhs)<1e-15}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v518 — quadratic Selberg-covariance sufficient target

For the Gaussian centered arithmetic phase, differentiation removes the
`1/log n` factor. Up to the fixed normalization/convention at the first
coefficient, write

`A_L'(E)`
` =-(1/pi) Re sum_(n>=2)`
`   a_n(L) exp(iElog n)`

with

`a_n(L)
 =(Lambda(n)-1)/sqrt(n)`
`  exp[-(log n/L)^2]`.

The Archimedean derivative has a fixed Gaussian-energy integral and can be
handled separately.

By Cauchy-Schwarz,

`int_R exp(-uE^2)(A_L'(E))_+dE`

is bounded, up to an absolute factor, by

`(int_R exp(-uE^2)dE)^(1/2)`
`* (int_R exp(-uE^2)|P_L(E)|^2dE)^(1/2)`,

where

`P_L(E)=sum a_n(L)exp(iElog n)`.

The Gaussian Fourier transform gives the **exact quadratic identity**

`Q_L(u)`
`:=int_R exp(-uE^2)|P_L(E)|^2dE`

`=sqrt(pi/u)`
`  sum_(m,n>=2)`
`  a_m(L)a_n(L)`
`  exp[-(log(m/n))^2/(4u)]`.

Equivalently,

`Q_L(u)`

is the positive-definite multiplicative Gaussian covariance of the centered
Mangoldt field.

Therefore the scalar estimate

`Q_L(u)<=exp(o(L^2))`

at one fixed `u>0` implies

`int exp(-uE^2)(F_L'(E))_+dE<=exp(o(L^2))`,

then v517 gives

`h_L(u)<=exp(o(L^2))`.

But v497/v508 imply that a zero

`rho=1/2+a+i gamma`,
`a>0`,

loads at least

`exp[(a^2/4+o(1))L^2]`

ordered levels below a fixed energy. That forces the heat trace to have
positive `L^2` exponential type, contradiction.

So the new sufficient theorem is:

`ONE FIXED-u CENTERED MANGOLDT LOG-GAUSSIAN QUADRATIC FORM`
`= exp(o(L^2))`
` => RH`.

## Why this target is different

It is not:

* a pointwise critical-line prefix estimate;
* a half-plane sign condition for `xi'/xi`;
* an all-E supremum;
* a root-flow transversality theorem.

It is one positive quadratic form involving only the centered arithmetic
coefficients and a fixed multiplicative Gaussian kernel.

That makes Selberg/sieve/correlation methods a plausible independent attack
surface.

**Verdict:** `QUADRATIC_CENTERED_MANGOLDT_COVARIANCE_IS_SUFFICIENT_RH_TARGET_PASS`.

The quadratic estimate itself remains open.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_QUADRATIC_SELBerg_COVARIANCE_V1",
        "required_claim":"Q_L(u)=sum_{m,n} a_m a_n exp[-log(m/n)^2/(4u)] = exp(o(L^2))",
        "fixed_u":True,
        "closed_chain":[
            "quadratic bound => weighted L1 positive arithmetic slope",
            "v517 => heat trace exp(o(L^2))",
            "v497/v508 offcritical zero => heat trace exp(cL^2)",
            "contradiction => RH"
        ],
        "next":"attack Q_L(u) directly using Selberg identity / multiplicative correlation decomposition"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--u",type=float,default=.01)
    ap.add_argument("--delta",type=float,default=3.0)
    ap.add_argument("--prefix",default="rot_rh_quadratic_selberg_covariance_v518")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v518 Gaussian kernel",unit="step") as bar:
        chk=gaussian_fourier_identity(args.u,args.delta);bar.update(1)
    ok=bool(chk["pass"])
    verdict="QUADRATIC_CENTERED_MANGOLDT_COVARIANCE_IS_SUFFICIENT_RH_TARGET_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"kernel_check":chk,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact Fourier/Cauchy reduction; arithmetic quadratic bound remains open."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
