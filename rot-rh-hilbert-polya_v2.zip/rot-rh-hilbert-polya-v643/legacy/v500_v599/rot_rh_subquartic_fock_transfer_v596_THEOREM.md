# ROT-RH v596 — unconditional subquartic physical-Fock transfer

Fix `u>0`, put

`tau=L^-2`,  `sigma=tau+1/(4u)`,

and let

`D_sigma(s)=sum_(n>=2) (Lambda(n)-1)n^(-s) exp[-sigma(log n)^2]`.

By the exact v580/v577 Bargmann-Fock identity, the physical Fock coordinates are

`psi_m(L,u)
 =D_sigma^(m)(1/2)/[sqrt(m!)(2u)^(m/2)]`

and

`Q_L(u)/sqrt(pi/u)=sum_(m>=0)|psi_m(L,u)|^2`.

## 1. Uniform coefficient estimate

Since `Lambda(n)<=log n` for `n>=2`,

`|Lambda(n)-1|<=1+log n`.

Therefore

`|D_sigma^(m)(1/2)|
 <=sum_(n>=2)(1+log n)n^(-1/2)
   (log n)^m exp[-sigma(log n)^2]`.

The summand is unimodal up to a harmless finite initial segment, so the
sum-integral comparison reduces the right side, up to a fixed polynomial
factor, to

`I_m
 =int_0^infinity (1+y)y^m
   exp[y/2-y^2/(4u)]dy`,

because `sigma>=1/(4u)`.

For any `0<delta<1`,

`y/2 <= delta*y^2/(4u)+u/(4delta)`,

hence

`I_m
 <=exp[u/(4delta)]
   int_0^infinity (1+y)y^m
   exp[-(1-delta)y^2/(4u)]dy`.

Choose

`delta=(m+2)^(-1/2)`.

The two Gaussian moments are explicit:

`int_0^infinity y^k exp[-a y^2]dy
 =1/2 a^(-(k+1)/2) Gamma((k+1)/2)`.

After division by the Fock normalization
`sqrt(m!)(2u)^(m/2)`, the duplication formula / Stirling bounds give only a
polynomial factor at `delta=0`.  The replacement
`a=(1-delta)/(4u)` contributes

`(1-delta)^(-O(m))
 =exp[O(sqrt(m))]`,

while `exp[u/(4delta)]=exp[O_u(sqrt(m))]`.

Consequently there are constants `C_u,A_u<infinity`, depending only on the
fixed energy weight `u`, such that uniformly for every `L>=1` and `m>=0`,

`boxed{
 |psi_m(L,u)|
 <=C_u (m+2)^(A_u) exp[C_u sqrt(m+2)] .
}`

No PNT error estimate, zero-free region, zero ordinate, or RH input is used.

## 2. Subquartic projection

Let `P_<=M` be the Fock projection onto degrees `0,...,M`.  Summing the
preceding estimate gives

`boxed{
 ||P_<=M Psi_(L,u)||_F^2
 <=C_u (M+2)^(C_u) exp[C_u sqrt(M+2)] .
}`

Hence if

`M_L=o(L^4)`,

then

`L^-2 log^+ ||P_<=M_L Psi_(L,u)||_F^2 ->0`.

Equivalently,

`boxed{
 ||P_<=M_L Psi_(L,u)||_F^2=exp[o(L^2)]
 whenever M_L=o(L^4).
}`

This is an unconditional one-sided physical-Fock bound on every subquartic
sector.

## 3. Transfer interpretation

v579 proves in the same canonical Bargmann degree geometry that

`||(I-J)^(-1)||<4`

with no cutoff parameter.  Therefore the universal Volterra recursion is
uniformly stable, while the actual physical arithmetic Fock state is now
unconditionally zero-type on every subquartic projection.

Thus **positive `L^2` exponential Volterra-to-physical distortion cannot be
supported below quartic Fock degree**.

Together with v577, which gives a superexponentially small feature tail above
a sufficiently large constant multiple of `L^4`, all unresolved RH-sensitive
distortion is confined to the quartic shell

`m=Theta(L^4)`.

This localization is sharp in scale: v589 places the coherent packet forced by
an off-critical zero `rho=1/2+a+i gamma` at

`m_a~a^2 L^4/(8u)`.

So v596 is a genuine unconditional projected transfer theorem, but it is not
an RH proof: the remaining `Theta(L^4)` shell is exactly the RH-strength shell.

**Verdict:**
`SUBQUARTIC_VOLterra_TO_PHYSICAL_FOCK_ZERO_TYPE_TRANSFER_PASS`.
