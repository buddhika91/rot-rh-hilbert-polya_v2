# ROT-RH v532 — smooth preconditioner Hilbert coercivity reduction

For the beta-conjugated deterministic smooth channel write

`K_(b,beta)=-B_beta`,

where

`B_beta(kd,d)`
` =k^(-1/2-beta)log(d)/log(kd)^2`
` >=0`.

The exact Selberg preconditioner is

`S_beta=(I-K_b)^(-1)=(I+B_beta)^(-1)`.

The old positive majorants bounded `(I-|K_b|)^(-1)` and therefore discarded
the stabilizing minus sign.  In Hilbert space that sign can be retained.

## Coercivity theorem

Suppose

`Re <f,B_beta f> >= -eta ||f||_2^2`

for every finite support, every horizon, and all beta in the required range,
with one `eta<1`.

Then

`Re <f,(I+B_beta)f>`
` >=(1-eta)||f||_2^2`.

By Cauchy-Schwarz,

`||(I+B_beta)f||_2`
` >=(1-eta)||f||_2`.

Hence exactly

`||S_beta||_(2->2)<=1/(1-eta)`.

So the smooth-channel problem is reduced to a **numerical-range lower bound**
for a deterministic divisor operator.

## Exact squared-kernel geometry

For `d,e>=2`, put

`g=gcd(d,e)`,
`ell=lcm(d,e)`.

Common outputs have the form `n=ell m`.  If

`a=1/2+beta`,

then the product of the two quotient factors is

`[(ell/d)(ell/e)]^(-a)m^(-2a)`
` =(g^2/(de))^a m^(-1-2beta)`.

Consequently the positive Gram kernel of `B_beta^*B_beta` is controlled by

`G_beta(d,e)`
` =(g^2/(de))^(1/2+beta)`
`  logd loge`
`  sum_(m>=1)`
`   m^(-1-2beta)/log(ell m)^4`.

At the critical endpoint beta=0,

`sum_(m>=1)1/[m log(ell m)^4]`
` <=1/log(ell)^4+1/[3log(ell)^3]`.

Thus even beta=0 has a finite exact gcd/lcm Gram kernel; the divergence seen
by the old value majorants is not present at the squared-kernel level.

## Numerical scout

The finite matrices show a remarkably stable lower edge of the symmetric part:
the worst sampled value is around `-0.21`, while direct
`||(I+B)^(-1)||_2` is around `1.2-1.3` and does not grow across the sampled
horizons.  These numbers are diagnostics only.

**Verdict:** `SMOOTH_PRECONDITIONER_HILBERT_COERCIVITY_REDUCTION_PASS`.

The new theorem target is

`inf_N lambda_min[(B_0+B_0^*)/2] > -1`

preferably with an explicit elementary margin. Because increasing beta only
shrinks every quotient coefficient, beta=0 is the natural hardest endpoint.
