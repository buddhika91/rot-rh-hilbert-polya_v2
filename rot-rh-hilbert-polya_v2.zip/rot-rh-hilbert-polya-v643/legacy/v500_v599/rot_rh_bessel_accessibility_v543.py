#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v543 — TRACE-ONE BESSEL ACCESSIBILITY COUNTING CRITERION
===============================================================

Let K_L>=0, Tr K_L=1 (v537).

For the secular levels E_k(L)<=E suppose we can associate unit vectors v_k,L in
the ROT observer space such that:

  (Bessel)  sum_k |<f,v_k>|^2 <= B_E(L)||f||^2;
  (access)  <v_k,K_L v_k> >= a_E(L)>0.

Then with S=sum |v_k><v_k| <= B_E I,

 N_L(E) a_E
 <= sum_k <v_k,Kv_k>
 = Tr(K^(1/2) S K^(1/2))
 <= B_E Tr K = B_E.

Thus
  N_L(E)<=B_E/a_E.

If log(B_E/a_E)=o(L^2), this contradicts v530's exp(cL^2) occupancy from any
offcritical zero. Hence such a subexponentially conditioned accessibility frame
implies RH.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v543-bessel-accessibility"

def model(L,pB,pa):
    B=max(1.0,L**pB)
    a=L**(-pa)
    ratio=B/a
    return {"L":L,"B":B,"a":a,"count_upper":ratio,
            "log_ratio_over_L2":math.log(ratio)/(L*L)}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v543 — trace-one Bessel accessibility counting criterion

Let `K_L` be a positive ROT observer kernel satisfying the exact v537 invariant

`Tr K_L=1`.

Fix a finite secular energy window `[0,E]`. Associate to each selected secular
level

`E_k(L)<=E`

a unit observer-space vector `v_(k,L)`.

Assume two quantitative properties.

### 1. Bessel/frame upper bound

For every observer vector `f`,

`sum_(E_k<=E)|<f,v_(k,L)>|^2`
` <=B_E(L)||f||^2`.

Equivalently, the frame operator

`S_(E,L)=sum_(E_k<=E)|v_k><v_k|`

satisfies

`S_(E,L)<=B_E(L)I`.

Orthogonality is the special case `B_E=1`.

### 2. Nonvanishing ROT accessibility

Every secular state consumes at least

`a_E(L)>0`

of the trace-one observer covariance:

`<v_(k,L),K_L v_(k,L)>`
` >=a_E(L)`.

Then

`N_L(E)a_E(L)`
` <=sum_k <v_k,K_Lv_k>`

` =Tr[K_L^(1/2) S_(E,L) K_L^(1/2)]`

` <=B_E(L)Tr K_L`

` =B_E(L)`.

Hence the exact counting bound

`boxed{N_L(E)<=B_E(L)/a_E(L)}`.

## RH-bearing scale

v530 proves that an off-critical zero forces, for some fixed `E_*`,

`N_L(E_*)`
` >=C L^(-1)exp(cL^2/4)`.

Therefore it is **not necessary** that `B_E` and `a_E` remain constant.

It is sufficient that

`boxed{log[B_E(L)/a_E(L)]=o(L^2)}`.

Polynomial frame loss, polynomially decaying accessibility, or any other
sub-`L^2` exponential conditioning is harmless.

Under that condition the trace-one accessibility theorem contradicts v530 and,
after functional-equation reflection, implies RH.

## Interpretation

The remaining ROT statement is:

> A fixed finite secular energy window cannot generate exponentially many
> mutually near-redundant observer states while each retains exponentially
> significant recursive accessibility.

This is weaker than v539 full positive-operator domination and weaker than
one-sided eigenvalue-by-eigenvalue comparison.

**Verdict:** `SUBEXPONENTIAL_BESSEL_ACCESSIBILITY_BRIDGE_IMPLIES_RH_PASS`.

The Bessel/accessibility estimates themselves remain open.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_BESSEL_ACCESSIBILITY_V1",
        "hypotheses":{
            "frame":"S_E,L<=B_E(L) I",
            "accessibility":"<v_k,K_Lv_k>>=a_E(L)",
            "conditioning":"log(B_E/a_E)=o(L^2)"
        },
        "counting":"N_L(E)<=B_E/a_E",
        "already_closed":["v537 trace K=1","v530 offcritical occupancy explosion"],
        "consequence":"RH"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--B-power",type=float,default=3.0)
    ap.add_argument("--a-decay-power",type=float,default=4.0)
    ap.add_argument("--prefix",default="rot_rh_bessel_accessibility_v543")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter();rows=[]
    with tqdm(total=4,desc="v543 conditioning",unit="L") as bar:
        for L in (10.,20.,40.,80.):
            rows.append(model(L,args.B_power,args.a_decay_power));bar.update(1)
    ok=rows[-1]["log_ratio_over_L2"]<rows[0]["log_ratio_over_L2"]
    verdict="SUBEXPONENTIAL_BESSEL_ACCESSIBILITY_BRIDGE_IMPLIES_RH_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact trace/Bessel implication; polynomial panel is diagnostic."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    for r in rows:print(r)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
