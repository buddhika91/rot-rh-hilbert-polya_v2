# ROT-RH v566 — exact finite witness: one-step Gaussian-Gram Selberg contraction is impossible

Consider the exact v523 Frechet derivative

`(J delta r)(n)`
` =-2/log n`
`   sum_(d|n,d<n) Lambda(n/d) delta r(d)`.

Take the basis perturbation

`delta r=e_2`.

Then, among its outputs,

`(Je_2)_4=-1`

and

`(Je_2)_6=-2log3/log6`.

All these displayed coefficients have the same sign.

For the v523 Gaussian Gram norm

`||c||_(L,u)^2`
` =sqrt(pi/u) sum_(m,n)`
` c_m cbar_n /sqrt(mn)`
` exp[-(log^2m+log^2n)/L^2]`
` exp[-log^2(m/n)/(4u)]`,

let `L->infinity` with any fixed `u>0`.

The input diagonal contribution is

`||e_2||^2 ->sqrt(pi/u)/2`.

The output diagonal contributions from only `4` and `6` give

`||Je_2||^2`
` >=sqrt(pi/u)`
`   [1/4`
`    +(1/6)(2log3/log6)^2]`.

The omitted `4-6` cross term is **positive**, so this is a lower bound.

Hence

`liminf_(L->infinity)`
` ||Je_2||^2/||e_2||^2`

` >=1/2`
`   +(4/3)(log3/log6)^2`.

It remains to show

`log3/log6 >sqrt(3/8)`.

Write

`log3/log6=1/[1+log2/log3]`.

An exact integer comparison gives

`2^1000 < 3^631`,

hence

`log2/log3 <631/1000`.

Also, by exact rational squaring,

`1631/1000 < sqrt(8/3)`,

so

`631/1000 <sqrt(8/3)-1`.

Therefore

`log2/log3 <sqrt(8/3)-1`,

equivalently

`log3/log6 >sqrt(3/8)`.

Thus the lower ratio is strictly greater than one.

Consequently:

`boxed{there is no q<1 such that`
` ||J_r||_(L,u -> L,u)<=q`
` for all sufficiently large L}`

for **any fixed `u>0`**.

This already rejects the strongest one-step contraction option stated in v523.

## Stronger divergence

In fact keep **all prime outputs** `n=2p`. For every prime `p`,

`(Je_2)_(2p)=-2logp/log(2p)`.

All these coefficients have the same sign and every entry of the Gaussian
Gram kernel is positive. Hence the diagonal prime terms alone give

`||Je_2||_(L,u)^2/||e_2||_(L,u)^2`

` >=4 exp[2(log2/L)^2]`
`   sum_p p^(-1)`
`   [logp/log(2p)]^2`
`   exp[-2(log(2p)/L)^2]`.

For each fixed prime the Gaussian factor increases to one as `L->infinity`,
and

`[logp/log(2p)]^2 ->1`.

Euler's theorem

`sum_p 1/p=infinity`

therefore implies by monotone finite-subsum comparison

`boxed{||Je_2||_(L,u)/||e_2||_(L,u) -> infinity}`

for every fixed `u>0`.

So the one-step Gaussian-Gram Jacobian is not merely noncontractive; its
finite-cutoff operator norm is **not uniformly bounded in L**.

It does **not** reject a multi-step causal/resummed theorem. The Jacobian is
strictly causal in divisor order, and repeated denominators/support migration
can behave completely differently from the one-step norm.

**Verdict:** `ONE_STEP_GAUSSIAN_GRAM_JACOBIAN_UNIFORMLY_UNBOUNDED_PASS`.
