#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v579-volterra-resolvent"

THEOREM=r"""# ROT-RH v579 — universal Volterra Fock resolvent is uniformly bounded

In the canonical Bargmann basis from v569,

`e_m(z)=z^m/sqrt(m!)`

and

`J e_m=1/sqrt(m+1)e_(m+1)`.

For `k>=0`,

`J^k e_m`
` =sqrt[m!/(m+k)!] e_(m+k)`.

Therefore the formal inverse

`T=(I-J)^(-1)=sum_(k>=0)J^k`

has matrix entries

`T_(n,m)`
` =sqrt(m!/n!)`

for `n>=m`, and zero otherwise.

## Schur bound

For a fixed column `m`,

`sum_(n>=m)|T_(n,m)|`
` =sum_(k>=0)sqrt[m!/(m+k)!]`.

Since

`(m+1)(m+2)...(m+k)>=k!`,

each term is at most `1/sqrt(k!)`. Hence

`sup_m column_sum`
` <=sum_(k>=0)1/sqrt(k!)`
` <4`.

For a fixed row `n`, write `k=n-m`. Then

`n!/(n-k)!`
` =k! binom(n,k)`
` >=k!`,

so again

`|T_(n,n-k)|<=1/sqrt(k!)`.

Thus

`sup_n row_sum<4`.

The Schur test gives

`boxed{||(I-J)^(-1)||_(F->F)<4}`.

In particular the Volterra Neumann series converges to a bounded operator on
the canonical Fock space even though `||J||=1`.

This also proves directly that `I-J` is boundedly invertible; no cutoff or
spectral-gap parameter is involved.

## Consequence

For the gauged Selberg fixed point

`B_X=(I-J)^(-1)f_0`,

`boxed{||B_X||_F<=4||f_0||_F}`

whenever the gauged forcing belongs to this Fock space.

So the universal recursive resummation cannot itself generate an
`exp(cL^2)` norm instability in this geometry.

Any RH-sensitive exponential growth must come from:
- the forcing norm;
- the gauge/composition map back to physical arithmetic variables;
- or the mismatch between the canonical Volterra Fock norm and the physical
  Gaussian covariance norm.

**Verdict:** `UNIVERSAL_VOLterra_FOCK_RESOLVENT_HAS_CUTOFF_INDEPENDENT_BOUND_PASS`.
"""

def finite_matrix(N):
    import numpy as np
    T=np.zeros((N,N))
    for m in range(N):
        v=1.0
        T[m,m]=1.0
        for n in range(m+1,N):
            v/=math.sqrt(n)
            # starting at n=m+1 requires sqrt(m+1), but this recurrence currently
            # divides by sqrt(n), exactly right.
            T[n,m]=v
    s=np.linalg.svd(T,compute_uv=False)[0]
    rows=np.sum(abs(T),axis=1)
    cols=np.sum(abs(T),axis=0)
    return {"N":N,"operator_norm":float(s),"max_row_sum":float(rows.max()),"max_col_sum":float(cols.max())}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--N",type=int,default=300);ap.add_argument("--prefix",default="rot_rh_volterra_resolvent_v579");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v579 resolvent",unit="step") as bar:
        chk=finite_matrix(a.N);bar.update(1)
    ok=chk["operator_norm"]<4 and chk["max_row_sum"]<4 and chk["max_col_sum"]<4
    verdict="UNIVERSAL_VOLterra_FOCK_RESOLVENT_HAS_CUTOFF_INDEPENDENT_BOUND_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"finite_check":chk,"analytic_bound":"<4","runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_VOLterra_RESOLVENT_V1","resolvent_bound":"||(I-J)^-1||<4","remaining":"compare Volterra Fock forcing/solution norm to physical Gaussian Fock norm"},indent=2))
    print("verdict:",verdict);print(chk)
    if a.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
