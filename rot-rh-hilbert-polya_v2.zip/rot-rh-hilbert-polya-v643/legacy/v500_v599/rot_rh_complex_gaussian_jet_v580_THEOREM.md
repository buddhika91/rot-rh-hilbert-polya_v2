# ROT-RH v580 — exact complex-Gaussian jet representation of Q_L

Let

`tau=L^-2`

and define the centered Gaussian Dirichlet field

`D_sigma(s)`
` =sum_(n>=2)(Lambda(n)-1)`
`   n^(-s) exp[-sigma(log n)^2]`.

Fix the v518 energy weight `u>0` and put

`sigma=tau+1/(4u)`.

Let `Z` be a standard circular complex Gaussian with density

`pi^(-1)exp(-|Z|^2)dA(Z)`,

so

`E[Z^m conjugate(Z)^n]=delta_(mn)m!`.

Then

`boxed{`
` Q_L(u)/sqrt(pi/u)`
` =E |D_sigma(1/2+Z/sqrt(2u))|^2`
`}`.

## Proof

Expand the square.  The complex-Gaussian moment-generating identity gives

`E exp[-Z y/sqrt(2u)-conj(Z)y'/sqrt(2u)]`
` =exp[yy'/(2u)]`.

Multiplying by the two `sigma` Gaussian factors yields

`exp[-tau(y^2+y'^2)]`
` exp[-(y-y')^2/(4u)]`,

which is exactly the v518 Gram kernel.

## Taylor/Fock form

Expanding `D_sigma` around `s=1/2` gives the equivalent Parseval identity

`boxed{`
` Q_L(u)/sqrt(pi/u)`
` =sum_(m>=0)`
` |D_sigma^(m)(1/2)|^2`
` /[m!(2u)^m]`
`}`.

This is exactly the v577 Fock coordinate formula.

## Critical-boundary interpretation

As `tau->0+`,

`sigma->1/(4u)`.

Every fixed Taylor coefficient has a finite limit, because `D_sigma` is entire
for positive `sigma`.  Any divergence of `Q_L` therefore comes from escape of
mass to higher and higher Taylor/Fock degrees.

The RH problem is thus a **critical Fock-boundary problem** for the fixed
Gaussian-smoothed entire centered field.

An off-critical zero produces positive `1/tau` exponential mass in those high
degrees; under RH the total growth is only polynomial.

**Verdict:** `GAUSSIAN_RH_ORDER_PARAMETER_IS_EXACT_COMPLEX_GAUSSIAN_JET_NORM_PASS`.
