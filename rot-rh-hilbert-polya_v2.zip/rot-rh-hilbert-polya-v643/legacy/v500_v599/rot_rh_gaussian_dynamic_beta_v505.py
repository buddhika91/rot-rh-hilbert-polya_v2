#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v505 — GAUSSIAN DYNAMIC-BETA DICTIONARY / R7 SAFE-REGION NO-GO
=====================================================================
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v505-gaussian-dynamic-beta"

def panel(a,L=100.0):
    y=a*L*L/2
    rows=[]
    for q in (2.,3.,5.,10.):
        lq=math.log(q)
        direct=math.exp(-(((y+lq)/L)**2-(y/L)**2))
        beta=2*y/(L*L)
        fact=math.exp(-beta*lq-(lq*lq)/(L*L))
        rows.append({"q":q,"direct":direct,"factorized":fact,
                     "relative_error":abs(direct-fact)/max(abs(direct),1e-300),
                     "beta_eff":beta})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v505 — Gaussian dynamic-beta dictionary / R7 safe-region no-go

For

`b_L(n)=exp[-(log n/L)^2]`

and a multiplicative transfer `d -> qd`,

`b_L(qd)/b_L(d)
 =q^(-beta_eff(d,L))exp[-(log q)^2/L^2]`

with

`beta_eff(d,L)=2log d/L^2`.

For a hypothetical zero

`rho=1/2+a+i gamma`, `0<a<1/2`,

the Gaussian saddle lies at

`log d ~ aL^2/2`.

Hence at the RH-bearing saddle

`beta_eff -> a in (0,1/2)`.

But the phase-free positive R7 conjugation has quotient exponent
`q^(-1/2-beta)` and crosses the absolute Dirichlet threshold only for
`beta>1/2`; the exact global theorem currently certified is at `beta=2`.

Therefore the existing beta=2/phase-free R7 theorem controls a safe deep-UV
region but cannot by itself control the off-critical Gaussian saddle.

**Verdict:** `GAUSSIAN_DYNAMIC_BETA_R7_THRESHOLD_DICTIONARY_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_DYNAMIC_BETA_V1",
        "closed":{
            "beta_eff":"2 log d/L^2",
            "offcritical_saddle":"log d~aL^2/2 => beta_eff~a",
            "RH_bearing_range":"0<a<1/2",
            "positive_R7_easy_range":"beta>1/2"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--a",type=float,default=.2)
    ap.add_argument("--prefix",default="rot_rh_gaussian_dynamic_beta_v505")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    if not 0<args.a<.5: raise ValueError("a must be in (0,1/2)")
    t0=time.perf_counter()
    with tqdm(total=1,desc="v505 beta",unit="step") as bar:
        rows=panel(args.a);bar.update(1)
    ok=max(r["relative_error"] for r in rows)<1e-12 and all(abs(r["beta_eff"]-args.a)<1e-12 for r in rows)
    verdict="GAUSSIAN_DYNAMIC_BETA_R7_THRESHOLD_DICTIONARY_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"a":float(args.a),
             "panel":rows,"runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
