# ROT-RH v591 — subexponential compact-rotor energy domination implies RH

Let the exact selector-clock states be

`psi_k(theta)=(2pi)^(-1/2)e^(iktheta)`

with compact generator

`N psi_k=k psi_k`.

Suppose the independently constructed secular Hamiltonian on this clock
representation satisfies, in the min-max sense,

`boxed{H_(sec,L)>=c_L |N|^p-b_L I}`

for one fixed `p>0`, with

`-log c_L=o(L^2)`

and

`log^+(1+b_L)=o(L^2)`.

Then every secular eigenvalue below fixed `E` must satisfy

`c_L k^p-b_L<=E`.

Hence

`k<=[(E+b_L)/c_L]^(1/p)`,

and therefore

`boxed{N_L(E)<=1+[(E+b_L)/c_L]^(1/p)`
` =exp[o(L^2)]}`.

But v530 proves that an off-critical zero forces, for one fixed `E_*`,

`N_L(E_*)>=exp[(c+o(1))L^2]`.

Contradiction. Thus the stated compact-rotor domination implies RH.

## Quadratic phase action

For the usual positive two-derivative compact rotor, `p=2`.
Then a stiffness/inertia coefficient with only polynomial or more generally
subexponential scale dependence is sufficient.

## Relation to existing ROT phase structure

The current compact-phase ROT construction provides:
- integer winding sectors;
- a Hermitian winding generator;
- quadratic winding curvature;
- a positive Euclidean phase action and Gaussian suppression of large
  curvature sectors.

Those ingredients motivate a rotor Hamiltonian, but they do **not yet prove**
that the arithmetic secular Hamiltonian is bounded below by that rotor
generator.

That one-sided operator identification is the remaining bridge.

**Verdict:** `SUBEXP_COMPACT_ROTOR_SPECTRAL_DOMINATION_IMPLIES_RH_PASS`.
