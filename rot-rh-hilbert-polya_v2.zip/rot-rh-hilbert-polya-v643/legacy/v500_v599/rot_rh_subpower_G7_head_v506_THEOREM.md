# ROT-RH v506 — subpower finite-G7 head reduction

v300 used the exact dual inequality

`||Ru||_(pref,N,I)<=V_N(I)||u||_(pref,N,I)`

and asked for bounded `V_N` and bounded forcing prefix.

For the Gaussian route it suffices to assume, for every `eps>0`,

`||F0||_(pref,N,I)<=C_(eps,I)N^eps`

and

`V_N(I)<=D_(eps,I)N^eps`.

Fix `eta>0`. For `R^jF0`, `0<=j<=6`, use exponent

`eta/(j+1)`

for the forcing and for each of the `j` R-factors. Then

`||R^jF0||_(pref,N,I)<=C_(j,eta,I)N^eta`.

Summing seven terms,

`G7=(I+R+...+R^6)F0`

satisfies

`||G7||_(pref,N,I)=O_(eta,I)(N^eta)`

for every `eta>0`.

Thus G7 is subpower. By v504 its Gaussian contribution has zero backward
exponential type.

This is strictly weaker than v300's bounded-prefix pair.

**Verdict:** `SUBPOWER_F0_AND_R_DUAL_IMPLY_SUBPOWER_G7_PASS`.

The full fixed point `x=G7+R^7x` still requires a packet-cascade theorem.
