# ROT-RH v503 — corrected first-later-crossing / anchored running maximum

The actual ordered-support rule is recursive:

`F_L(E_1)=1/2`,

and

`E_(k+1)=inf{E>E_k:F_L(E)=k+1/2}`.

For `E>=E_1` define

`M_(1,L)(E)=max_(E_1<=x<=E) F_L(x)`.

Then exactly

`N_L(E)=#{k:E_k(L)<=E}=floor(M_(1,L)(E)+1/2)`.

Proof:

* If `E_k<=E`, then `M_1(E)>=F(E_k)=k-1/2`.
* Conversely, if `M_1(E)>=K-1/2`, start from `F(E_1)=1/2`. If
  `E_j<=E`, then `F(E_j)=j-1/2<K-1/2` while some later point no later
  than `E` reaches `K-1/2`. Continuity therefore gives a crossing of
  `j+1/2` after `E_j` and before `E`; by definition the first such crossing is
  `E_(j+1)`. Induction yields `E_K<=E`.

Thus v501's running-max idea survives, but its auxiliary `F(0)=0` normalization
was not the actual ROT-RH selector and is superseded by this anchored theorem.

For

`h_L(u)=sum_k exp(-uE_k^2)`,

Stieltjes integration by parts gives

`h_L(u)=2u int_0^infty E exp(-uE^2)N_L(E)dE`.

Since `N_L(E)=0` before `E_1` and `N_L(E)<=M_1(E)+1/2` afterward,

`h_L(u)
 <=2u int_(E_1)^infty E exp(-uE^2)M_1(E)dE
   +(1/2)exp(-uE_1^2)`.

A running maximum beginning at any fixed lower floor `B<=E_1` is a sufficient
upper envelope, but not an exact counting identity.

**Verdict:** `EXACT_ANCHORED_FIRST_LATER_RUNNING_MAX_PASS`.
