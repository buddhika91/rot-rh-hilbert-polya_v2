# ROT-RH v551 — finite-dimensional Bessel capacity obstruction

Let `v_1,...,v_N` be unit vectors in a Hilbert space of dimension `d`.
The frame operator
`S=sum |v_k><v_k|`
has
`Tr S=N`
and
`rank S<=d`.
Hence its Bessel constant `B=||S||` satisfies
`N<=dB`, so
`boxed{B>=N/d}`.

For v543 this means a faithful observer representation of dimension
`d(L)=exp(o(L^2))` cannot by itself yield a subexponential Bessel constant
under the hypothetical v530 alternative
`N_L(E_*)=exp[(c+o(1))L^2]`.
Indeed
`L^-2 log B_E(L)>=c+o(1)`.

Thus faithful finite representation is not spectralization. The observer
dynamics must supply an additional mechanism that separates distinct
quantization levels into sufficiently independent degrees of freedom.

**Verdict:** `SUBEXP_DIMENSION_ALONE_CANNOT_SUPPLY_V543_BESSEL_BRIDGE_PASS`.
