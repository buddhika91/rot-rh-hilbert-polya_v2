#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,cmath,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v558-prime-blaschke-scattering"
THEOREM=r"""# ROT-RH v558 — exact prime Euler factor as relative Blaschke scattering

Fix a prime `p`, put
`r=p^(-1/2)` and `theta=E log p`.

Define
`S_p(E)`
` =(1-r e^(-i theta))/(1-r e^(i theta))`.

For real `E`, `|S_p(E)|=1`.

Equivalently, with the disk Blaschke factor
`b_r(z)=(z-r)/(1-rz)`,
`S_p(E)=b_r(e^(i theta))/e^(i theta)`.
So it is exactly a Blaschke channel relative to the free one-step winding.

Expanding the logarithm,
`log S_p(E)`
` =2i sum_(m>=1) r^m sin(m theta)/m`.

Therefore
`boxed{(1/2)arg S_p(E)`
` =sum_(m>=1) p^(-m/2) sin(mElogp)/m}`
with the continuous phase convention at `E=0`.

But for `n=p^m`,
`Lambda(n)/log n=1/m`.
Hence the right side is exactly the full prime-power contribution of `p` to
the unregularized arithmetic secular phase.

Differentiating,
`(1/2)d_E arg S_p`
` =sum_(m>=1)(log p)p^(-m/2)cos(mElogp)`.

Also
`d_theta arg S_p=P_r(theta)-1`,
where
`P_r=(1-r^2)/(1-2r cos theta+r^2)`
is the Poisson kernel.

Thus each prime-power channel is:
- a passive Blaschke phase;
- minus the free winding density `1`;
- with zero net relative winding over one prime period.

This explains the negative-delay obstruction found in v82: the arithmetic
channel is a **relative** scattering phase, not a single positive-delay inner
phase.

**Verdict:** `PRIME_POWER_SECULAR_PHASE_IS_EXACT_RELATIVE_BLASCHKE_SCATTERING_PASS`.
"""
def check(p,E,M):
    r=p**-.5; th=E*math.log(p)
    S=(1-r*cmath.exp(-1j*th))/(1-r*cmath.exp(1j*th))
    series=sum((r**m)*math.sin(m*th)/m for m in range(1,M+1))
    # use principal phase only when chosen panel is away from branch jump
    phase=.5*cmath.phase(S)
    deriv=sum(math.log(p)*(r**m)*math.cos(m*th) for m in range(1,M+1))
    P=(1-r*r)/(1-2*r*math.cos(th)+r*r)
    return {"p":p,"E":E,"modulus_error":abs(abs(S)-1),
            "half_phase":phase,"series":series,"phase_series_error":abs(phase-series),
            "derivative_series":deriv,"poisson_formula":.5*math.log(p)*(P-1),
            "derivative_error":abs(deriv-.5*math.log(p)*(P-1))}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--p",type=int,default=101); ap.add_argument("--E",type=float,default=.17); ap.add_argument("--modes",type=int,default=200); ap.add_argument("--prefix",default="rot_rh_prime_blaschke_v558"); ap.add_argument("--strict",action="store_true"); a=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v558 prime",unit="step") as bar: chk=check(a.p,a.E,a.modes); bar.update(1)
    ok=chk["modulus_error"]<1e-12 and chk["phase_series_error"]<1e-10 and chk["derivative_error"]<1e-10
    verdict="PRIME_POWER_SECULAR_PHASE_IS_EXACT_RELATIVE_BLASCHKE_SCATTERING_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"demo":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_PRIME_BLASCHKE_V1","identity":"half phase = prime-power secular phase","interpretation":"relative passive scattering","next":"centered Gaussian determinant/passivity"},indent=2))
    print("verdict:",verdict); print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
