# ROT-RH v529 — localized Gaussian contour / finite-rectangle residue theorem

Use the v527 centered function

`D(w)=-zeta'(w)/zeta(w)-(zeta(w)-1)`

and its exact Gaussian regularization

`D_tau(s)`
`=1/[i sqrt(4 pi tau)]`
` int_(c-i inf)^(c+i inf)`
` exp[(w-s)^2/(4tau)]D(w)dw`,

where `c>1`.

Fix a real energy `E` and set

`s=1/2+iE`.

Choose

`b=1/2+eta`,
`eta>0`,

and a height `T` satisfying

`T>c-1/2`.

Choose `b` so that the finite vertical segment

`{b+it: |t-E|<=T}`

contains no zero of zeta. This is always possible because the zeros in the
compact rectangle are finite.

Now deform **only** the central portion of the safe `c` contour. The new path
has four pieces:

1. the original `c`-line below `E-T`;
2. the finite horizontal/vertical/horizontal detour through `b`;
3. the original `c`-line above `E+T`.

The enclosed poles are exactly the finitely many zeta zeros satisfying

`b<Re(rho)<c`,
`|Im(rho)-E|<T`.

The pole at `1` is absent because it cancels in the centered `D`.

Therefore

`D_tau(1/2+iE)`
` =R_(b,T,tau)(E)`
`  -sqrt(pi/tau)`
`   sum_(rho in rectangle)`
`    m_rho exp[(rho-(1/2+iE))^2/(4tau)]`.

## Rigorous remainder exponent

On the finite `b` segment,

`Re[(w-s)^2]`
` =eta^2-(Im(w)-E)^2`
` <=eta^2`.

Since this segment is compact and pole-free, `D` is bounded there. Hence its
contribution is

`O(tau^(-1/2) exp[eta^2/(4tau)])`.

On either horizontal connector,

`Re[(w-s)^2]`
` =(Re(w)-1/2)^2-T^2`
` <=(c-1/2)^2-T^2`
` =:-delta<0`.

On the untouched `c` tails, `|Im(w)-E|>=T`, so the same inequality holds.
Moreover `D(c+it)` is represented by an absolutely convergent Dirichlet series
because `c>1`, hence is bounded on the entire safe line.

Thus

`R_(b,T,tau)(E)`
` =O(tau^(-1/2) exp[eta^2/(4tau)])`
`  +O(tau^(-1/2)exp[-delta/(4tau)])`.

No zero-separation theorem, no global bound for `1/zeta` near the critical
line, and no infinite near-critical contour is needed.

The residue set is finite and exact.

**Verdict:** `LOCALIZED_GAUSSIAN_FINITE_RECTANGLE_RESIDUE_THEOREM_PASS`.

This closes the contour-growth obligation left in v528.
