# ROT-RH v526 — Hilbert–Pólya topology selection theorem

v82/v83 construct positive atomic Herglotz/Clark realizations from the
arithmetic root-and-slope data. Their measure weights are proportional to the
inverse root slopes.

v497/v508 show that a hypothetical exposed Gaussian off-critical mode creates

`N_L(E_*)=exp[Theta(L^2)]`

ordered levels below one fixed finite energy.

v524 shows that the same local cluster has total collision-normalized Clark
mass

`O(L^-1)`

after removal of one antinode-nearest edge level, and v525 shows that the edge
level is large only on a finite-measure/sparse set of late cutoffs under the
natural Gaussian amplitude assumptions.

Therefore it is possible, at the level of the local asymptotic model, for

`nu_L(cluster) ->0`

in weak Herglotz/Clark measure while simultaneously

`# spectrum(cluster) ->infinity`.

Thus:

`weak Clark/Herglotz convergence`
` does NOT imply`
`uniform spectral counting tightness`.

In particular it does not imply

`sup_L Tr(H_L^-2)<infinity`

or trace-norm convergence of `H_L^-2`.

## Consequence for the ROT-RH program

If the goal is an RH-bearing Hilbert–Pólya theorem, the cutoff topology must
retain multiplicity/counting information. Sufficient choices include:

* direct trace-norm convergence of `H_L^-2`;
* a uniform inverse-square trace bound plus fixed-mode convergence;
* an independently defined compact-resolvent self-adjoint operator family with
  a convergence theorem strong enough to prevent spectral pollution/local
  multiplicity escape.

Convergence of one collision-normalized cyclic Herglotz measure is valuable
operator information, but it is too weak by itself.

**Verdict:** `RH_BEARING_CUTOFF_TOPOLOGY_MUST_CONTROL_SPECTRAL_COUNTING_PASS`.

This does not prove the required strong topology; it rules out treating weak
Clark convergence as a substitute for it.
