# ROT-RH v534 — coefficient-L2 to Gaussian-Gram embedding barrier

The natural Selberg state is

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`.

Its differentiated Gaussian secular observable is

`P_L(E)`
` =sum_(n>=2)x_n`
`   [log n exp(-(log n/L)^2)]`
`   exp(iElog n)`.

Regard this only as a linear functional on ordinary coefficient `ell^2`.
Its dual norm is

`W_L`
` =[sum_(n>=2)(log n)^2`
`   exp(-2(log n/L)^2)]^(1/2)`.

Integral comparison with `y=log n` gives

`W_L^2`
` ~int_0^infty`
`   y^2 exp[y-2y^2/L^2]dy`.

The exponent

`y-2y^2/L^2`

has its maximum at

`y=L^2/4`

with value

`L^2/8`.

Therefore

`log W_L=L^2/16+O(log L)`.

So even the hypothetical bound

`||x||_2=O(1)`

would only imply

`|P_L(E)|`
` <=exp[(1/16+o(1))L^2]`.

But for a nontrivial off-critical displacement

`0<a<1/2`,

v527-v530 give differentiated residue rate

`a^2/4<1/16`.

Thus ordinary coefficient `ell^2` is **too weak at the exponential scale** to
see the RH contradiction.

## Correction to v533

v531 remains a valid zero-blind theorem:

`K_Lambda`

is small in an ordinary beta-conjugated coefficient-Hilbert shadow.

v532 also remains a valid deterministic coercivity reduction for the smooth
preconditioner in that shadow.

However, those statements do **not** imply v519's Gaussian covariance bound
without an additional embedding estimate of zero backward exponential type.

Such an embedding is precisely where the off-diagonal Gaussian correlations
live.

Therefore v533's claimed RH closure is superseded.

The correct Hilbert target remains v523:

`estimate the exact Selberg transfer directly in the Gaussian Gram norm`.

**Verdict:** `ORDINARY_L2_EMBEDDING_HAS_1OVER16_EXPONENTIAL_BARRIER_PASS`.
