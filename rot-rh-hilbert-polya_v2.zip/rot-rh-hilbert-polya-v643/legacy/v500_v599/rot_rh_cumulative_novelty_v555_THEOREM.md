# ROT-RH v555 — exact cumulative novelty-capacity theorem

Let `K_0=0` on a finite-dimensional observer space and let each incoming
response satisfy

`0<=R_n<=I`.

Define the **unnormalized cumulative novelty update**

`K_(n+1)`
` =K_n+(I-K_n)^(1/2) R_n (I-K_n)^(1/2)`.

Assume `0<=K_n<=I`. Since `R_n<=I`,

`0<=(I-K_n)^(1/2)R_n(I-K_n)^(1/2)<=I-K_n`.

Therefore

`0<=K_(n+1)<=I`.

By induction this holds for every `n`.

Define the novelty cost

`nu_n`
` =Tr[(I-K_n)^(1/2)R_n(I-K_n)^(1/2)]`
` =Tr[(I-K_n)R_n]`
` >=0`.

Then exactly

`Tr K_(n+1)-Tr K_n=nu_n`.

Hence

`boxed{sum_(j=0)^(N-1) nu_j=Tr K_N<=d}`

where `d` is the observer-space dimension.

This is a genuine cumulative capacity law.

It differs critically from v88:
- no post-novelty trace renormalization;
- no Cesaro division by the number of shells;
- no replenished scalar reservoir is required.

Redundant responses automatically cost little; genuinely new directions consume
the finite spectral occupancy `I-K`.

For rank-one `R_n=|psi_n><psi_n|`,

`nu_n=<psi_n,(I-K_n)psi_n>`,

the unsaturated squared observer novelty.

**Verdict:** `EXACT_CUMULATIVE_NOVELTY_CAPACITY_TELESCOPES_PASS`.

This theorem does not say secular crossings have a lower novelty cost. That is
the next bridge.
