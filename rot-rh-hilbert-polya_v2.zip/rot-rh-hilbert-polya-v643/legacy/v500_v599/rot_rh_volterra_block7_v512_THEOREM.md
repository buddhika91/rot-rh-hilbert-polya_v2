# ROT-RH v512 — exact Volterra iterates / block-7 cascade collapse

By v511, after the exact scalar gauge and the coordinate

`z=-log zeta(s)`,

the ROT-RH transfer is

`Jg(z)=int_0^z g(eta)deta`.

For every integer `r>=1`,

`J^r g(z)
 =1/(r-1)!
  int_0^z (z-eta)^(r-1)g(eta)deta`.

This is the standard simplex/Volterra identity.

Consequently the generating function is exact:

`sum_(r>=0) q^r J^r g(z)`

`=g(z)
 +q int_0^z exp[q(z-eta)]g(eta)deta`.

Equivalently, before the `z` change of variable,

`sum_(r>=0)q^r R^r A(s)`

has the explicit log-zeta kernel

`U^(-1){`
` U A(s)`
` +q zeta(s)^(-q)`
`   int_s^infty [zeta'(w)/zeta(w)]`
`   zeta(w)^q U A(w)dw`
`}`,

on a chosen zero-free branch.

## Exact collapse of the seven-layer packets

Let

`f0=U F0`

and

`g7=(I+J+...+J^6)f0`.

Since

`T=R^7`

becomes

`J^7`,

we have for every integer `K>=1`

`sum_(r=0)^(K-1) T^r g7`

`=sum_(r=0)^(K-1)
  J^(7r)(I+J+...+J^6)f0`

`=sum_(n=0)^(7K-1)J^n f0`.

So the apparent `G7/R7` mesoscopic dynamics is **not a new independent
dynamical system**. It is exactly the ordinary Volterra Neumann series grouped
seven terms at a time.

At infinite depth, where the resolvent exists,

`sum_(n>=0)J^n=(I-J)^(-1)`,

which is the gauged fixed point.

**Verdict:** `EXACT_BLOCK7_CASCADE_IS_REGROUPED_VOLTERRA_SERIES_PASS`.

This substantially simplifies v510: the remaining `Theta(L^2)` packet problem
is a truncation problem for one scalar Volterra/Taylor series.
