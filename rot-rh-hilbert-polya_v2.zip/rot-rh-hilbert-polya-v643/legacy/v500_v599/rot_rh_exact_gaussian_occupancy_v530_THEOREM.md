# ROT-RH v530 — exact Gaussian off-critical occupancy theorem

Assume there exists a nontrivial zero

`rho_0=1/2+a_0+i gamma_0`,
`a_0>0`.

Choose

`0<eta<a_0`

and set the localized v529 contour at

`b=1/2+eta`.

Choose a fixed height `T>c_0-1/2`, where `c_0>1` is the original safe
Dirichlet line, large enough that `rho_0` lies in the finite contour rectangle.

v527-v529 give the **exact** differentiated centered Gaussian decomposition

`D_tau(E)`
`=R_tau(E)`
` -sqrt(pi/tau)`
`  sum_(rho in finite rectangle)`
`   m_rho exp{[a_rho+i(gamma_rho-E)]^2/(4tau)}`,

with

`R_tau(E)
 =O(tau^(-1/2)exp[eta^2/(4tau)])`

on a compact real-energy interval.

For the finite zero set define

`S_rho(E)=a_rho^2-(gamma_rho-E)^2`.

At `E=gamma_0`,

`S_(rho_0)=a_0^2>eta^2`.

After combining identical `(a,gamma)` multiplicities, pairwise score
differences are affine in `E`. Their ties are therefore isolated. Move, if
necessary, to a nearby compact chamber `J` on which one residue `*` is strictly
exposed:

`S_*(E)>=c>eta^2`

and

`S_*(E)-max_(rho!=*)S_rho(E)>=g>0`.

The exact winning differentiated term has amplitude

`sqrt(pi/tau)m_* exp[S_*(E)/(4tau)]`

and phase derivative

`-a_*/(2tau)`.

All competing residues are smaller by `exp[-g/(4tau)]`; the localized contour
remainder is smaller by `exp[-(c-eta^2)/(4tau)]`.

Hence, on each sufficiently late scale, a positive half-wave of the real
secular derivative lies inside `J` and has integrated rise

`Delta F_tau`
` >=C sqrt(tau)exp[c/(4tau)]`.

The fixed free/Archimedean derivative contributes only `O(1)` on `J` and is
negligible on this scale.

Set

`tau=L^(-2)`.

Then

`Delta F_L`
` >=C L^(-1)exp[cL^2/4]`.

Apply the exact recursive-selector swing-loading theorem v508 to that upward
swing. There is a fixed right endpoint `E_*` of `J` such that

`N_L(E_*)`
` >=C L^(-1)exp[cL^2/4]`
` ->infinity`.

Therefore

`EXISTENCE OF ANY ZERO WITH Re(rho)>1/2`
` => EXPONENTIAL LOCAL SPECTRAL OCCUPANCY EXPLOSION`.

No known zero ordinate is used; the theorem is conditional only on the
hypothetical existence of such a zero. No Gaussian steepest descent, zero
density estimate, global near-critical contour bound, or regulator-tail
heuristic is required.

By functional-equation reflection, excluding this occupancy explosion through
any cutoff-uniform spectral counting/trace theorem forces RH.

**Verdict:** `EXACT_GAUSSIAN_OFFCRITICAL_OCCUPANCY_THEOREM_PASS`.
