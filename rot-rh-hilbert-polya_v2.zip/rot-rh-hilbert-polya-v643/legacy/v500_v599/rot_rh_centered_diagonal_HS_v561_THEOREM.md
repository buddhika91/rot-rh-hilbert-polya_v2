# ROT-RH v561 — centered Gaussian log determinant is a first-order trace of a Hilbert–Schmidt operator

Let `B` be the diagonal log-number operator on `ell^2({2,3,...})`,

`B e_n=(log n)e_n`,

and let

`V e_n=-(Lambda(n)-1)/(log n) e_n`.

For `tau>0` define

`T_(tau,s)=V exp(-sB)exp(-tau B^2)`.

Its diagonal entries are

`-(Lambda(n)-1)/(log n) n^(-s)e^[-tau(log n)^2]`.

Therefore

`Tr T_(tau,s)`
` =-sum_(n>=2)(Lambda(n)-1)/(log n)`
`   n^(-s)e^[-tau(log n)^2]`.

With the normalization at `Re s -> infinity`, v559 gives exactly

`boxed{log Delta_tau(s)=Tr T_(tau,s)}`.

Differentiating in `s` recovers

`D_tau(s)=d_s log Delta_tau(s)`.

## Hilbert–Schmidt budget on the critical line

At `s=1/2+iE`,

`||T_(tau,s)||_2^2`
` =sum_(n>=2)`
`  (Lambda(n)-1)^2/[n log^2 n]`
`  e^[-2tau(log n)^2]`.

For every `n>=2`,

`0<=Lambda(n)/log n<=1`

(the ratio is `1/m` on `n=p^m`, zero otherwise), so

`|Lambda(n)-1|/log n`
` <=1+1/log2=:C_0`.

Hence

`||T||_2^2`
` <=C_0^2 sum_(n>=2)n^(-1)e^[-2(log n/L)^2]`

for `tau=L^-2`.

The integral test gives

`sum_(n>=2)n^(-1)e^[-2(log n/L)^2]`
` <=C + int_1^infty x^(-1)e^[-2(log x/L)^2]dx`

` =C + L sqrt(pi)/(2sqrt2)`.

Thus

`boxed{||T_(L)||_2^2=O(L)}`

uniformly in real `E`.

So the centered Gaussian arithmetic has a polynomial Hilbert–Schmidt
**channel-energy** representation.

## But the RH-sensitive quantity is the trace

The secular phase is

`Im log Delta_tau=Im Tr T_tau`.

Hilbert–Schmidt norm does not control the trace in an effective dimension that
grows without bound. Indeed the absolute trace norm has the familiar Gaussian
critical exponential scale.

Therefore polynomial `S_2` energy does not imply the required
`exp(o(L^2))` secular phase/action bound.

**Verdict:** `CENTERED_GAUSSIAN_LOGDET_HAS_POLYNOMIAL_HS_BUT_RH_SENSITIVE_TRACE_PASS`.

This is an exact representation and a no-go for a naive HS-norm proof.
