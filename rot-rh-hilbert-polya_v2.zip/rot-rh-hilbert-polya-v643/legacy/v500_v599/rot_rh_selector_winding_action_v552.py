#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v552-selector-winding-action"
THEOREM=r"""# ROT-RH v552 — exact selector winding / Dirichlet-action lower bound

For the ordered first-later-crossing support
`F_L(E_k)=k-1/2`,
we have exactly
`F_L(E_(k+1))-F_L(E_k)=1`.

Define
`U_L(E)=exp[2pi i F_L(E)]`.
The continuous lifted phase changes by `2pi` between every consecutive pair,
so each selector interval carries net winding `+1`.

If `[a,b]` spans `M` consecutive loaded increments, then
`int_a^b F_L'(E)dE=M`.
Cauchy-Schwarz gives
`boxed{int_a^b |F_L'|^2 >= M^2/(b-a)}`.
Since `|U_L'|=2pi|F_L'|`,
`boxed{int_a^b |U_L'|^2 >=4pi^2 M^2/(b-a)}`.

Thus v530's exponential fixed-energy occupancy forces positive `L^2`
exponential type in the compact-phase Dirichlet action. This identifies the
v518-v519 Gaussian quadratic covariance as the weighted compact-phase action
order parameter.

**Verdict:** `SELECTOR_LEVEL_COUNT_IS_COMPACT_PHASE_WINDING_ACTION_PASS`.
"""
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--M",type=int,default=100); ap.add_argument("--width",type=float,default=1.); ap.add_argument("--prefix",default="rot_rh_selector_winding_action_v552"); ap.add_argument("--strict",action="store_true"); a=ap.parse_args()
    if a.M<1 or a.width<=0: raise ValueError
    t0=time.perf_counter()
    with tqdm(total=1,desc="v552 action",unit="step") as bar:
        chk={"increments":a.M,"width":a.width,"F_dirichlet_lower":a.M*a.M/a.width,"U_dirichlet_lower":4*math.pi*math.pi*a.M*a.M/a.width}; bar.update(1)
    ok=chk["F_dirichlet_lower"]>0
    verdict="SELECTOR_LEVEL_COUNT_IS_COMPACT_PHASE_WINDING_ACTION_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"demo":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_SELECTOR_WINDING_ACTION_V1","remaining":"independent subexponential action upper budget"},indent=2))
    print("verdict:",verdict); print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
