#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v530 — EXACT GAUSSIAN OFFCRITICAL OCCUPANCY THEOREM
===========================================================

Combine v527 exact residues + v529 localized remainder + v508 selector.

If any rho0=1/2+a0+i gamma0 with a0>0 exists:
- choose eta<a0 and a finite rectangle centered near gamma0;
- finite residue scores S_j(E)=a_j^2-(gamma_j-E)^2;
- pick a nearby strict exposed chamber where winner score c>eta^2;
- derivative winner is exact with amplitude tau^-1/2 exp(c/4tau),
  frequency a*/(2tau);
- all other finite residues have fixed score gap; local-contour remainder has
  lower exponential type eta^2;
- one positive halfwave integrates to sqrt(tau)exp(c/4tau);
- v508 loads that many ordered levels below a fixed E*.

Thus offcritical => N_L(E*) >= C L^-1 exp(cL^2/4) with no saddle hypothesis.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v530-exact-offcritical-occupancy"

def rate_panel(c):
    rows=[]
    for L in (10.,15.,20.,25.,30.):
        val=math.exp(c*L*L/4)/L
        rows.append({"L":L,"occupancy_scale":val,
                     "log_scale_over_L2":math.log(val)/(L*L)})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    cfile=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v530 — exact Gaussian off-critical occupancy theorem

Assume there exists a nontrivial zero

`rho_0=1/2+a_0+i gamma_0`,
`a_0>0`.

Choose

`0<eta<a_0`

and set the localized v529 contour at

`b=1/2+eta`.

Choose a fixed height `T>c_0-1/2`, where `c_0>1` is the original safe
Dirichlet line, large enough that `rho_0` lies in the finite contour rectangle.

v527-v529 give the **exact** differentiated centered Gaussian decomposition

`D_tau(E)`
`=R_tau(E)`
` -sqrt(pi/tau)`
`  sum_(rho in finite rectangle)`
`   m_rho exp{[a_rho+i(gamma_rho-E)]^2/(4tau)}`,

with

`R_tau(E)
 =O(tau^(-1/2)exp[eta^2/(4tau)])`

on a compact real-energy interval.

For the finite zero set define

`S_rho(E)=a_rho^2-(gamma_rho-E)^2`.

At `E=gamma_0`,

`S_(rho_0)=a_0^2>eta^2`.

After combining identical `(a,gamma)` multiplicities, pairwise score
differences are affine in `E`. Their ties are therefore isolated. Move, if
necessary, to a nearby compact chamber `J` on which one residue `*` is strictly
exposed:

`S_*(E)>=c>eta^2`

and

`S_*(E)-max_(rho!=*)S_rho(E)>=g>0`.

The exact winning differentiated term has amplitude

`sqrt(pi/tau)m_* exp[S_*(E)/(4tau)]`

and phase derivative

`-a_*/(2tau)`.

All competing residues are smaller by `exp[-g/(4tau)]`; the localized contour
remainder is smaller by `exp[-(c-eta^2)/(4tau)]`.

Hence, on each sufficiently late scale, a positive half-wave of the real
secular derivative lies inside `J` and has integrated rise

`Delta F_tau`
` >=C sqrt(tau)exp[c/(4tau)]`.

The fixed free/Archimedean derivative contributes only `O(1)` on `J` and is
negligible on this scale.

Set

`tau=L^(-2)`.

Then

`Delta F_L`
` >=C L^(-1)exp[cL^2/4]`.

Apply the exact recursive-selector swing-loading theorem v508 to that upward
swing. There is a fixed right endpoint `E_*` of `J` such that

`N_L(E_*)`
` >=C L^(-1)exp[cL^2/4]`
` ->infinity`.

Therefore

`EXISTENCE OF ANY ZERO WITH Re(rho)>1/2`
` => EXPONENTIAL LOCAL SPECTRAL OCCUPANCY EXPLOSION`.

No known zero ordinate is used; the theorem is conditional only on the
hypothetical existence of such a zero. No Gaussian steepest descent, zero
density estimate, global near-critical contour bound, or regulator-tail
heuristic is required.

By functional-equation reflection, excluding this occupancy explosion through
any cutoff-uniform spectral counting/trace theorem forces RH.

**Verdict:** `EXACT_GAUSSIAN_OFFCRITICAL_OCCUPANCY_THEOREM_PASS`.
""",encoding="utf-8")
    cfile.write_text(json.dumps({
        "schema":"ROT_RH_EXACT_GAUSSIAN_OCCUPANCY_V2",
        "closed":{
            "Gaussian_zero_term":"exact contour residue",
            "line_remainder":"v529 finite-local contour",
            "finite_score_envelope":True,
            "selector_loading":"v508",
            "occupancy":"N_L(E*) >= C L^-1 exp(cL^2/4)"
        },
        "removed_obligations":[
            "complex saddle expansion",
            "global zero density for local dominance",
            "global near-critical vertical-line zeta bound"
        ],
        "consequence":"any uniform fixed-energy counting bound, heat bound, or inverse-square trace bound excludes offcritical zeros"
    },indent=2),encoding="utf-8")
    return s,t,cfile

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--score-c",type=float,default=.03)
    ap.add_argument("--prefix",default="rot_rh_exact_gaussian_occupancy_v530")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v530 occupancy",unit="step") as bar:
        rows=rate_panel(args.score_c);bar.update(1)
    target=args.score_c/4
    ok=rows[-1]["occupancy_scale"]>rows[0]["occupancy_scale"] and abs(rows[-1]["log_scale_over_L2"]-target)<.01
    verdict="EXACT_GAUSSIAN_OFFCRITICAL_OCCUPANCY_THEOREM_PASS" if ok else "DIAGNOSTIC_FAILED"
    payload={"version":VERSION,"verdict":verdict,"score_c":args.score_c,
             "rate_target":target,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact reduction theorem; diagnostic panel only."}
    prefix=Path(args.prefix).resolve()
    s,t,cfile=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",cfile)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
