# ROT-RH v518 — quadratic Selberg-covariance sufficient target

For the Gaussian centered arithmetic phase, differentiation removes the
`1/log n` factor. Up to the fixed normalization/convention at the first
coefficient, write

`A_L'(E)`
` =-(1/pi) Re sum_(n>=2)`
`   a_n(L) exp(iElog n)`

with

`a_n(L)
 =(Lambda(n)-1)/sqrt(n)`
`  exp[-(log n/L)^2]`.

The Archimedean derivative has a fixed Gaussian-energy integral and can be
handled separately.

By Cauchy-Schwarz,

`int_R exp(-uE^2)(A_L'(E))_+dE`

is bounded, up to an absolute factor, by

`(int_R exp(-uE^2)dE)^(1/2)`
`* (int_R exp(-uE^2)|P_L(E)|^2dE)^(1/2)`,

where

`P_L(E)=sum a_n(L)exp(iElog n)`.

The Gaussian Fourier transform gives the **exact quadratic identity**

`Q_L(u)`
`:=int_R exp(-uE^2)|P_L(E)|^2dE`

`=sqrt(pi/u)`
`  sum_(m,n>=2)`
`  a_m(L)a_n(L)`
`  exp[-(log(m/n))^2/(4u)]`.

Equivalently,

`Q_L(u)`

is the positive-definite multiplicative Gaussian covariance of the centered
Mangoldt field.

Therefore the scalar estimate

`Q_L(u)<=exp(o(L^2))`

at one fixed `u>0` implies

`int exp(-uE^2)(F_L'(E))_+dE<=exp(o(L^2))`,

then v517 gives

`h_L(u)<=exp(o(L^2))`.

But v497/v508 imply that a zero

`rho=1/2+a+i gamma`,
`a>0`,

loads at least

`exp[(a^2/4+o(1))L^2]`

ordered levels below a fixed energy. That forces the heat trace to have
positive `L^2` exponential type, contradiction.

So the new sufficient theorem is:

`ONE FIXED-u CENTERED MANGOLDT LOG-GAUSSIAN QUADRATIC FORM`
`= exp(o(L^2))`
` => RH`.

## Why this target is different

It is not:

* a pointwise critical-line prefix estimate;
* a half-plane sign condition for `xi'/xi`;
* an all-E supremum;
* a root-flow transversality theorem.

It is one positive quadratic form involving only the centered arithmetic
coefficients and a fixed multiplicative Gaussian kernel.

That makes Selberg/sieve/correlation methods a plausible independent attack
surface.

**Verdict:** `QUADRATIC_CENTERED_MANGOLDT_COVARIANCE_IS_SUFFICIENT_RH_TARGET_PASS`.

The quadratic estimate itself remains open.
