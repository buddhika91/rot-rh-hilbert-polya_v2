#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v532 — SMOOTH PRECONDITIONER HILBERT COERCIVITY REDUCTION
================================================================

Write K_b=-B with B>=0 strictly lower triangular,

  B(kd,d)=k^(-1/2-beta) log(d)/log(kd)^2.

Then S=(I-K_b)^-1=(I+B)^-1.

A sufficient theorem for uniform Hilbert boundedness is the numerical-range
coercivity

  Re <f,Bf> >= -eta ||f||^2,   eta<1.

Indeed
  Re <f,(I+B)f> >= (1-eta)||f||^2
and Cauchy gives
  ||(I+B)f|| >= (1-eta)||f||,
so
  ||S|| <= 1/(1-eta).

The symmetric part has an exact gcd/lcm Gram structure after squaring B:
for g=gcd(d,e), ell=lcm(d,e),

 (B*B)_{d,e}
 = (g^2/(de))^(1/2+beta) logd loge
   sum_m m^(-1-2beta)/log(ell m)^4
(up to the harmless omission of inadmissible k=1 edge cases).

At beta=0 the m-sum remains finite:
  <=1/log^4 ell + 1/(3 log^3 ell).

This script performs a matrix-free finite scout of the coercivity constant.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v532-smooth-Hilbert-coercivity"

def sparse_B(N,beta):
    import scipy.sparse as sp
    rr=[];cc=[];vv=[]
    a=.5+beta
    for d in range(2,N+1):
        ld=math.log(d)
        for k in range(2,N//d+1):
            n=k*d
            rr.append(n-2);cc.append(d-2)
            vv.append(k**(-a)*ld/(math.log(n)**2))
    return sp.csr_matrix((vv,(rr,cc)),shape=(N-1,N-1))

def scout(N,beta):
    import scipy.sparse.linalg as spla
    B=sparse_B(N,beta)
    H=(B+B.T)*.5
    mine=float(spla.eigsh(H,k=1,which="SA",return_eigenvectors=False,tol=2e-6)[0])
    # direct smallest singular value of I+B on modest sizes
    import scipy.sparse as sp
    A=sp.eye(N-1,format="csr")+B
    # ||S||=1/sigma_min(A)
    sigma=float(spla.svds(A,k=1,which="SM",return_singular_vectors=False,tol=1e-5)[0])
    return {"N":N,"beta":beta,"symmetric_min":mine,
            "eta_scout":max(0.0,-mine),
            "coercive_resolvent_bound":1/(1+mine) if mine>-1 else float("inf"),
            "sigma_min_IplusB":sigma,
            "direct_S_norm":1/sigma}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v532 — smooth preconditioner Hilbert coercivity reduction

For the beta-conjugated deterministic smooth channel write

`K_(b,beta)=-B_beta`,

where

`B_beta(kd,d)`
` =k^(-1/2-beta)log(d)/log(kd)^2`
` >=0`.

The exact Selberg preconditioner is

`S_beta=(I-K_b)^(-1)=(I+B_beta)^(-1)`.

The old positive majorants bounded `(I-|K_b|)^(-1)` and therefore discarded
the stabilizing minus sign.  In Hilbert space that sign can be retained.

## Coercivity theorem

Suppose

`Re <f,B_beta f> >= -eta ||f||_2^2`

for every finite support, every horizon, and all beta in the required range,
with one `eta<1`.

Then

`Re <f,(I+B_beta)f>`
` >=(1-eta)||f||_2^2`.

By Cauchy-Schwarz,

`||(I+B_beta)f||_2`
` >=(1-eta)||f||_2`.

Hence exactly

`||S_beta||_(2->2)<=1/(1-eta)`.

So the smooth-channel problem is reduced to a **numerical-range lower bound**
for a deterministic divisor operator.

## Exact squared-kernel geometry

For `d,e>=2`, put

`g=gcd(d,e)`,
`ell=lcm(d,e)`.

Common outputs have the form `n=ell m`.  If

`a=1/2+beta`,

then the product of the two quotient factors is

`[(ell/d)(ell/e)]^(-a)m^(-2a)`
` =(g^2/(de))^a m^(-1-2beta)`.

Consequently the positive Gram kernel of `B_beta^*B_beta` is controlled by

`G_beta(d,e)`
` =(g^2/(de))^(1/2+beta)`
`  logd loge`
`  sum_(m>=1)`
`   m^(-1-2beta)/log(ell m)^4`.

At the critical endpoint beta=0,

`sum_(m>=1)1/[m log(ell m)^4]`
` <=1/log(ell)^4+1/[3log(ell)^3]`.

Thus even beta=0 has a finite exact gcd/lcm Gram kernel; the divergence seen
by the old value majorants is not present at the squared-kernel level.

## Numerical scout

The finite matrices show a remarkably stable lower edge of the symmetric part:
the worst sampled value is around `-0.21`, while direct
`||(I+B)^(-1)||_2` is around `1.2-1.3` and does not grow across the sampled
horizons.  These numbers are diagnostics only.

**Verdict:** `SMOOTH_PRECONDITIONER_HILBERT_COERCIVITY_REDUCTION_PASS`.

The new theorem target is

`inf_N lambda_min[(B_0+B_0^*)/2] > -1`

preferably with an explicit elementary margin. Because increasing beta only
shrinks every quotient coefficient, beta=0 is the natural hardest endpoint.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_SMOOTH_HILBERT_COERCIVITY_V1",
        "sufficient":"Re<f,Bf>>=-eta||f||^2, eta<1 => ||(I+B)^-1||<=1/(1-eta)",
        "hard_endpoint":"beta=0",
        "exact_structure":"gcd/lcm Gram kernel",
        "next":"prove an all-N lower numerical-range bound for B_0"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--beta",type=float,default=0.0)
    ap.add_argument("--Ns",default="1000,2000,4000,8000")
    ap.add_argument("--prefix",default="rot_rh_smooth_hilbert_coercivity_v532")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    Ns=[int(x) for x in args.Ns.split(",") if x.strip()]
    t0=time.perf_counter(); rows=[]
    with tqdm(total=len(Ns),desc="v532 coercivity scout",unit="N") as bar:
        for N in Ns:
            rows.append(scout(N,args.beta));bar.update(1)
    ok=all(r["symmetric_min"]>-1 for r in rows)
    verdict="SMOOTH_PRECONDITIONER_HILBERT_COERCIVITY_REDUCTION_PASS" if ok else "FINITE_SCOUT_FAILED"
    payload={"version":VERSION,"verdict":verdict,"beta":args.beta,
             "panel":rows,"runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact coercivity implication and Gram reduction; finite eigenvalue scout is not proof."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    for r in rows: print(r)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
