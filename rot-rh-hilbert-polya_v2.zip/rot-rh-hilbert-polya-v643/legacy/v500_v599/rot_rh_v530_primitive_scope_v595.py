#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v595-v530-primitive-scope-audit"

THEOREM=r"""# ROT-RH v595 — v530 occupancy theorem requires an additional primitive-baseline certificate

The exact pieces already closed are:

1. v527-v529:
   an off-critical zero gives a strictly exposed differentiated Gaussian
   residue on a fixed chamber, exponentially larger than the differentiated
   remainder.

2. Integrating one positive derivative half-wave gives a phase **variation**

   `F(b)-F(a)>=A_tau`

   with

   `A_tau~sqrt(tau)exp[c/(4tau)]`.

3. v508:
   if one additionally knows

   `F(a)<1/2`

   and

   `F(b)>=K-1/2`,

   then all selector levels `1,...,K` are loaded by `b`.

## Missing logical step

A lower bound on the variation

`F(b)-F(a)`

alone does not imply the absolute endpoint inequalities required by v508.

The primitive may contain an `E`-independent (on the local chamber) baseline
coming from integration of the differentiated field outside the chamber.

To promote the derivative theorem to the claimed fixed-energy occupancy
explosion one needs one additional certificate, for example:

### Primitive contour route

Derive a localized contour decomposition for

`q_tau=log Delta_tau`

itself and prove that on an exposed chamber its oscillatory primitive residue

`~sqrt(tau) exp[S_*/(4tau)]`

dominates every primitive remainder/baseline term.

### Anchored-selector route

Alternatively prove a cutoff-uniform anchor before the chamber and show that
the large variation necessarily crosses the required consecutive positive
half-integer ladder from that anchor.

Until one of these is supplied, the safe status is:

`offcritical => exponentially large local derivative/phase variation`

is proved by the differentiated contour;

`offcritical => exponentially many actual first-later-crossing levels below a
fixed E_*`

still has a primitive-baseline obligation.

## Impact on the current RH route

None.

v594 proves directly that the quadratic Gaussian criterion

`Q_tau(u)=exp[o(1/tau)]`

implies RH from the differentiated residue field alone.

So all v577-v590 logarithmic/Fock/action reductions can use v594 and do not
need v530 occupancy.

**Verdict:** `V530_OCCUPANCY_NEEDS_PRIMITIVE_BASELINE_CERTIFICATE_BUT_QUADRATIC_RH_ROUTE_UNAFFECTED_PASS`.
"""

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--prefix",default="rot_rh_v530_primitive_scope_v595");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v595 audit",unit="step") as bar:bar.update(1)
    verdict="V530_OCCUPANCY_NEEDS_PRIMITIVE_BASELINE_CERTIFICATE_BUT_QUADRATIC_RH_ROUTE_UNAFFECTED_PASS"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"v530_safe_status":"primitive-baseline certificate still required","v594_selector_free_route":"valid reduction","runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_V530_SCOPE_V1","closed":"differentiated exposed residue + exponential phase variation","open":"absolute primitive endpoint/baseline control for v508","alternative":"use v594 quadratic route; no selector needed"},indent=2))
    print("verdict:",verdict)
if __name__=="__main__":main()
