# ROT-RH v517 — positive-variation heat-trace bound

Let the actual ordered support satisfy

`F_L(E_k)=k-1/2`

and

`E_1<E_2<...`.

Assume `F_L` is absolutely continuous on compact real intervals, which holds
for the Gaussian-regulated arithmetic phase.

For every `j`,

`F_L(E_(j+1))-F_L(E_j)=1`.

Hence the positive variation on that interval obeys

`int_(E_j)^(E_(j+1)) (F_L'(t))_+ dt >=1`.

The selector intervals are disjoint. Therefore for `E>=E_1`,

`N_L(E)-1`
` <=int_(E_1)^E (F_L'(t))_+dt`,

or

`N_L(E)
 <=1+int_(E_1)^E(F_L')_+`.

Now use the exact heat-counting identity

`h_L(u)
 =2u int_(E_1)^infty
    E exp(-uE^2)N_L(E)dE`.

The constant `1` contributes

`exp(-uE_1^2)`.

For the variation term, Tonelli gives

`2u int_(E_1)^infty E exp(-uE^2)
       int_(E_1)^E(F_L'(t))_+dt dE`

`=int_(E_1)^infty (F_L'(t))_+
    [int_t^infty2uE exp(-uE^2)dE]dt`

`=int_(E_1)^infty exp(-ut^2)(F_L'(t))_+dt`.

Thus

`h_L(u)`
` <=exp(-uE_1^2)`
`   +int_(E_1)^infty exp(-uE^2)(F_L'(E))_+dE`.

This is exact.

## New RH-bearing target

It is enough to prove, at one fixed `u>0`, a subexponential-in-`L^2` estimate

`int exp(-uE^2)(F_L'(E))_+dE`
` <=exp(o(L^2))`.

An off-critical Gaussian mode from v497/v502 produces exponentially large
alternating slopes with a positive-duty-cycle bounded away from zero, so its
positive variation has positive `L^2` exponential type.

Unlike v506, this criterion does **not** assert pointwise `N^o(1)` prefix
control and does not directly create an analytic Dirichlet continuation from
one frequency.

**Verdict:** `EXACT_POSITIVE_VARIATION_HEAT_BOUND_PASS`.
