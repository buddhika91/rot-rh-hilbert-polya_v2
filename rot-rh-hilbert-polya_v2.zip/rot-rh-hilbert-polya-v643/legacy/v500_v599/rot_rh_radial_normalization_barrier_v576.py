#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v576-radial-normalization-barrier"
THEOREM=r"""# ROT-RH v576 — normalized observer states erase the exact RH order parameter

By v575, the v518 Gaussian quadratic order parameter has the compact-clock
representation

`Q_L(u)=||Psi_L||^2+superexp.small`.

Suppose one replaces the raw arithmetic clock state by its normalized ray

`psi_L=Psi_L/||Psi_L||`

and then forms any projector/density state depending only on that ray, for
example

`rho_L=|psi_L><psi_L|`.

Then

`Tr rho_L=1`

identically, regardless of whether

`||Psi_L||`
is polynomial, subexponential, or
`exp(cL^2)`.

More generally, the map

`Psi ->Psi/||Psi||`

is invariant under every positive radial rescaling

`Psi ->A_L Psi`.

But v519/v536 show that the RH-sensitive datum is precisely the radial scale:

`Q_L=||Psi_L||^2`.

An off-critical zero changes this norm by positive `L^2` exponential type.
Normalization deletes that information exactly.

Therefore no theorem formulated purely in terms of:
- trace-one normalization,
- projective state geometry,
- normalized fidelity,
- normalized density matrices,

can by itself prove the required Gaussian quadratic bound unless the missing
normalization factor is separately controlled.

## Correct finish line

Write a zero-blind synthesis of the raw compact-clock state as

`Psi_L=T_L Omega_L`.

A sufficient ROT theorem is

`||Omega_L||<=exp[o(L^2)]`

and

`||T_L||<=exp[o(L^2)]`.

Equivalently, if using the preconditioned Selberg fixed point

`Psi_L=(I-R_L)^(-1)Omega_L`,

it suffices to prove

`||(I-R_L)^(-1)||<=exp[o(L^2)]`

together with a subexponential forcing norm.

Then v575 gives

`Q_L(u)=exp[o(L^2)]`,

and v519/v536 force RH.

**Verdict:** `NORMALIZATION_ERASES_GAUSSIAN_RH_RADIAL_ORDER_PARAMETER_PASS`.

The next theorem must be an unnormalized source/action/coercivity bound.
"""
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--prefix",default="rot_rh_radial_normalization_barrier_v576");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v576 ledger",unit="step") as bar:bar.update(1)
    verdict="NORMALIZATION_ERASES_GAUSSIAN_RH_RADIAL_ORDER_PARAMETER_PASS"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"correct_target":"unnormalized compact-clock source norm / Selberg resolvent coercivity","runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_RADIAL_NORMALIZATION_BARRIER_V1","order_parameter":"Q_L=||Psi_L||^2","rejected":"projective/trace-one-only closure","required":"subexponential raw source norm or preconditioned resolvent bound"},indent=2))
    print("verdict:",verdict)
if __name__=="__main__":main()
