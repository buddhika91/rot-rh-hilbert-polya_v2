# ROT-RH v519 — Gaussian quadratic covariance is an RH order parameter

Define

`P_L(E)=sum_(n>=2)(Lambda(n)-1)n^(-1/2)
         exp[-(log n/L)^2] exp(iElog n)`

(up to the fixed `n=2` convention correction), and

`Q_L(u)=int_R exp(-uE^2)|P_L(E)|^2dE`.

v518 proves, using v497/v508, that

`Q_L(u)=exp(o(L^2))`

for one fixed `u>0` is sufficient for RH.

## Converse under RH

RH gives the classical von Mangoldt error estimate

`R(x):=psi(x)-x=O(sqrt(x)log^2 x)`.

Write

`f_(L,E)(x)
 =x^(-1/2+iE)exp[-(log x/L)^2]`.

Stieltjes/partial summation gives

`P_L(E)
 =-int_2^infty R(x) f'_(L,E)(x)dx`

plus a harmless fixed endpoint term.

Now

`|f'_(L,E)(x)|`
` <=x^(-3/2) exp[-(log x/L)^2]`
`   [C(1+|E|)+2log x/L^2]`.

Multiplying by

`|R(x)|<=C sqrt(x)log^2x`

and putting `y=log x` yields Gaussian moments

`int_0^infty y^2 exp[-y^2/L^2]dy=O(L^3)`

and

`L^-2 int_0^infty y^3 exp[-y^2/L^2]dy=O(L^2)`.

Hence

`|P_L(E)|`
` <=C L^3(1+|E|)+O(L^2)`.

Therefore, for every fixed `u>0`,

`Q_L(u)=O_u(L^6)`.

In particular,

`L^-2 log^+Q_L(u)->0`.

Thus, modulo the v497 exposed-saddle/remainder theorem already isolated as a
publication-precision obligation,

`RH`
` <=>`
`Q_L(u)=exp(o(L^2))`

for any fixed `u>0`.

The quadratic covariance is therefore best regarded as a quantitative **RH
order parameter**, not as an independently weak Selberg lemma.

**Verdict:** `GAUSSIAN_QUADRATIC_COVARIANCE_IS_RH_EQUIVALENT_ORDER_PARAMETER_PASS`.
