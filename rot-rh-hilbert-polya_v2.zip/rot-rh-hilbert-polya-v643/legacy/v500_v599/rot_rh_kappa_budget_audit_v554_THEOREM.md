# ROT-RH v554 — current kappa law is not a cumulative action budget

The frozen law is
`pre=memory*prior+(1-memory)*instantaneous`,
`kappa_new=clip(pre-drain*curvature_load,0,1)`.

With constant instantaneous source `q` and load `l`, the unclipped fixed point
is
`k_*=q-drain*l/(1-memory)`.
Whenever this is positive, the same positive load can be paid forever while
`sum_(j<N)l=Nl -> infinity`.

Thus `0<=kappa<=1` does not imply a finite cumulative action/load budget.
The current kappa is a replenished leaky reservoir, not the upper budget
required by v553.

**Verdict:** `CURRENT_KAPPA_IS_REPLENISHED_NOT_FINITE_ACTION_BUDGET_PASS`.
