# ROT-RH v536 — off-diagonal Gaussian Mangoldt covariance is the exact RH order parameter

Write the v518 positive covariance as

`Q_L(u)=Q_diag(L,u)+Q_off(L,u)`,

where v535 proves unconditionally

`Q_diag(L,u)=O_u(L^2)`.

Explicitly,

`Q_off(L,u)`
`=sqrt(pi/u)`
` sum_(m!=n)`
` [(Lambda(m)-1)(Lambda(n)-1)/sqrt(mn)]`
` exp[-(log^2m+log^2n)/L^2]`
` exp[-log^2(m/n)/(4u)]`.

## Forward implication

Suppose, for one fixed `u>0`,

`Q_off(L,u)<=exp(o(L^2))`.

Since the diagonal is polynomial,

`Q_L(u)<=exp(o(L^2))`.

v519 together with the exact v527-v530 off-critical occupancy theorem then
gives RH.

## Reverse implication

Under RH, v519 gives

`Q_L(u)=O_u(L^6)`.

Together with v535,

`|Q_off(L,u)|`
` <=Q_L(u)+Q_diag(L,u)`
` =O_u(L^6)`.

Thus the off-diagonal term is polynomial under RH.

Therefore, at the exponential-type level,

`RH`
` <=>`
`Q_off(L,u) has zero positive L^2 exponential type`.

This is now the sharp arithmetic bottleneck.

It is a signed two-point multiplicative correlation theorem.  Any successful
Selberg/large-sieve/recursive proof must exploit cancellation in this object
directly; coefficient `ell^2`, positive majorants, weak Clark measures, and
brute energy orthogonalization have all been shown too weak.

**Verdict:** `OFFDIAGONAL_GAUSSIAN_MANGOLDT_COVARIANCE_IS_EXACT_RH_ORDER_PARAMETER_PASS`.
