#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v569-volterra-vacuum-orbit"
THEOREM=r"""# ROT-RH v569 — exact canonical Volterra vacuum orbit

Use the exact v511 conjugacy

`U R U^(-1)=J`,

where

`U[A]=mu A`,

`z=-log zeta(s)`,

and

`(Jg)(z)=int_0^z g(eta)deta`.

Choose the canonical smooth source

`A_0(s)=mu(s)^(-1)`.

This source is zero-blind: `mu` is built only from the deterministic smooth
channel `zeta-1`, and contains no zero ordinate input.

Then

`U A_0=1`.

Since

`J^m 1=z^m/m!`,

we obtain for every integer `m>=0`

`boxed{R^m A_0`
` =mu^(-1) z^m/m!`
` =mu^(-1)[-log zeta(s)]^m/m!}`.

Consequently, wherever the Volterra resolvent series is valid,

`sum_(m>=0) R^m A_0`
` =mu^(-1) e^z`
` =1/[mu(s) zeta(s)]`.

## Canonical weighted-shift representation

Introduce the formal Bargmann basis

`e_m(z)=z^m/sqrt(m!)`.

Then

`J e_m`
` =1/sqrt(m+1) e_(m+1)`.

Thus the preconditioned recursive transfer is, in its exact `z` coordinate, a
weighted unilateral shift with weights

`w_m=1/sqrt(m+1)`.

In particular:
- `J` is bounded with norm one in the canonical Fock norm;
- the weights tend to zero, so `J` is compact;
- `J^2` is Hilbert-Schmidt because
  `sum_m 1/[(m+1)(m+2)]<infinity`.

These are properties of the **universal Volterra recursion**, not of a fitted
zero spectrum.

## Zero interpretation

At a zeta zero `rho` of multiplicity `q`,

`z(s)=-q log(s-rho)+O(1)`,

so the zero is an infinite-distance end in the `z` coordinate.

Every fixed recursive depth is only polynomial in `z`; the singular
`1/zeta=e^z` appears only after the infinite Taylor/Volterra resummation.

Therefore the RH-sensitive question can be rephrased as a recursive-capacity
problem:

> can an off-critical physical chamber require occupation of an
> `Theta(L^2)`-depth portion of this Fock/Volterra ladder while the zero-blind
> ROT observer has only subexponential accessible novelty?

This does not answer that question, but it gives a canonical Hilbert geometry
for asking it.

**Verdict:** `PRECONDITIONED_ROT_TRANSFER_HAS_EXACT_FOCK_VOLterra_VACUUM_ORBIT_PASS`.
"""
def weights(M):
    rows=[]
    hs2=0.
    for m in range(M):
        w=1/math.sqrt(m+1)
        w2=1/math.sqrt((m+1)*(m+2))
        hs2+=w2*w2
        rows.append({"m":m,"J_weight":w,"J2_weight":w2})
    return rows,hs2
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--depth",type=int,default=1000);ap.add_argument("--prefix",default="rot_rh_volterra_vacuum_v569");ap.add_argument("--strict",action="store_true");a=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v569 Fock",unit="step") as bar:
        rows,hs2=weights(a.depth);bar.update(1)
    exact_partial=1-1/(a.depth+1) # sum_{m=0}^{M-1}1/((m+1)(m+2))
    ok=abs(hs2-exact_partial)<1e-12
    verdict="PRECONDITIONED_ROT_TRANSFER_HAS_EXACT_FOCK_VOLterra_VACUUM_ORBIT_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"J_norm":1.0,"J_compact_weights_to_zero":True,"J2_HS_squared_partial":hs2,"J2_HS_squared_limit":1.0,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_VOLterra_VACUUM_V1","source":"A0=mu^-1","orbit":"R^m A0=mu^-1(-log zeta)^m/m!","canonical_shift":"J e_m=(m+1)^-1/2 e_{m+1}","next":"relate Gaussian cutoff L to accessible Fock depth/novelty without using zero locations"},indent=2))
    print("verdict:",verdict)
    print("J2 HS partial / limit:",hs2,1.0)
    if a.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
