# ROT-RH v594 — direct Gaussian quadratic criterion implies RH without selector occupancy

Assume a nontrivial zero

`rho_0=1/2+a_0+i gamma_0`,
`a_0>0`.

Choose `0<eta<a_0` and use the exact localized v527-v529 contour.

On a fixed compact chamber `J`, one residue `*` is strictly exposed with

`S_*(E)`
` =a_*^2-(gamma_*-E)^2`
` >=c>eta^2`

and fixed score gap

`S_*(E)-max_(rho!=*)S_rho(E)>=g>0`.

The exact differentiated centered Gaussian field is

`D_tau(E)`
` =-sqrt(pi/tau)m_*`
`   exp{[a_*+i(gamma_*-E)]^2/(4tau)}`
`  +Rem_tau(E)`,

where uniformly on `J`

`|Rem_tau(E)|`
` <=exp[-delta/tau]`
`   sqrt(pi/tau)m_*`
`   exp[S_*(E)/(4tau)]`

for some `delta>0` after absorbing the finite residue gap and shifted-contour
type `eta^2<c`.

Therefore, for all sufficiently small `tau`,

`|D_tau(E)|`
` >=C tau^(-1/2)exp[c/(4tau)]`

uniformly on `J`.

For every fixed `u>0`, the Gaussian energy weight has a positive lower bound
on the fixed chamber:

`e^(-uE^2)>=w_J>0`.

Hence

`Q_tau(u)`
` :=int_R e^(-uE^2)|D_tau(E)|^2dE`

satisfies

`boxed{`
` Q_tau(u)`
` >=C_J tau^(-1) exp[c/(2tau)]`
`}`.

Thus any theorem

`boxed{Q_tau(u)=exp[o(1/tau)]}`

for one fixed `u>0` excludes every zero with `Re rho>1/2`.

By functional-equation reflection it excludes every `Re rho<1/2` nontrivial
zero as well, so all nontrivial zeros lie on the critical line.

Therefore

`boxed{Q_tau(u)=exp[o(1/tau)] => RH}`

using only the exact differentiated contour/residue theorem.

No:
- first-later-crossing selector;
- spectral occupancy theorem;
- primitive integration constant;
- root-flow branch argument

is required.

## Converse

Under RH, the standard
`psi(x)-x=O(sqrt(x)log^2x)`
estimate gives the v519 polynomial upper bound

`Q_tau(u)=O_u(tau^-3)`.

Thus, at positive `1/tau` exponential type,

`RH <=> Q_tau(u) has zero type`.

**Verdict:** `DIRECT_EXPOSED_GAUSSIAN_QUADRATIC_ZERO_TYPE_IS_RH_EQUIVALENT_PASS`.

Publication obligation: retain the v529 inequality-level localized contour
remainder estimate.
