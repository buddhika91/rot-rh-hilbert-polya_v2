#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v522 — ENERGY-AVERAGING DIAGONALIZATION EXPONENT BARRIER
===============================================================

A hypothetical offcritical zero displacement a in (0,1/2) has Gaussian saddle
  log n ~ a L^2/2,
so its coherent arithmetic scale is
  N_a ~ exp(aL^2/2).

Its quadratic energy signal has exponent
  Q_signal ~ exp(a^2 L^2/2)
(up to subexponential factors).

To diagonalize a Dirichlet polynomial by a brute Montgomery-Vaughan/spacing
mean-value window, one needs
  T >> inverse frequency spacing ~ N_a/polylog(N_a),
so
  log T / L^2 >= a/2 + o(1).

But an upper bound of diagonal size T*poly(L) can contradict the signal only if
  log T/L^2 < a^2/2.

For 0<a<1/2,
  a/2 > a^2/2.

Thus brute energy-window orthogonalization cannot simultaneously diagonalize
the dangerous scale and retain a contradiction.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v522-energy-window-barrier"

def panel():
    rows=[]
    for a in (.02,.05,.1,.2,.3,.4,.49):
        resolve=a/2
        signal=a*a/2
        rows.append({"a":a,"minimum_resolution_exponent":resolve,
                     "signal_exponent":signal,
                     "gap":resolve-signal,
                     "barrier":resolve>signal})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v522 — energy-averaging diagonalization exponent barrier

For an off-critical displacement

`a=Re(rho)-1/2`,
`0<a<1/2`,

the Gaussian saddle occurs at

`log N_a~aL^2/2`.

Hence

`N_a=exp[(a/2+o(1))L^2]`.

The corresponding v518 quadratic peak has size

`exp[(a^2/2+o(1))L^2]`.

Now try to prove the quadratic bound by enlarging the energy average until the
Dirichlet frequencies `log n` become essentially orthogonal.

Near scale `N_a`, neighboring integer frequencies have spacing

`log(n+1)-log n~1/N_a`

(and prime frequencies differ only by polylogarithmic factors at the exponent
level). A brute mean-value/large-sieve diagonalization therefore needs

`T >= N_a/polylog N_a`,

so

`liminf L^-2 log T >= a/2`.

But the resulting diagonal upper bound has at least the window-size cost

`T * poly(L)`.

For it to contradict the off-critical quadratic signal one would need

`limsup L^-2 log T < a^2/2`.

These inequalities are incompatible because

`a/2-a^2/2=a(1-a)/2>0`.

Therefore **brute frequency orthogonalization by a long E-window cannot close
the Gaussian RH criterion**.

Any successful quadratic proof must exploit arithmetic correlation/cancellation
before complete frequency resolution—e.g. the Selberg recursion in a
phase-sensitive Hilbert geometry.

**Verdict:** `ENERGY_WINDOW_DIAGONALIZATION_EXPONENT_BARRIER_PASS`.

This is an exponent-level no-go for the standard mean-value shortcut, not a
claim against more structured large-sieve/Selberg arguments.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_ENERGY_AVERAGING_BARRIER_V1",
        "resolution_cost":"a/2",
        "offcritical_Q_signal":"a^2/2",
        "gap":"a(1-a)/2>0",
        "next":"phase-sensitive arithmetic Hilbert-space transfer, not brute diagonalization"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_energy_window_barrier_v522")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v522 exponents",unit="step") as bar:
        rows=panel();bar.update(1)
    ok=all(r["barrier"] for r in rows)
    verdict="ENERGY_WINDOW_DIAGONALIZATION_EXPONENT_BARRIER_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
