# ROT-RH v516 — subpower G7 prefix is already RH-implying

Let the finite seven-layer coefficient head be `u_n=G7(n)` and define

`D_G(s)=sum_(n>=2)u_n n^(-s)`.

Fix one real frequency `E0`. Suppose that for **every** `eps>0`

`|sum_(n<=N)u_n exp(iE0log n)|`
` <=C_eps N^eps`.

For any complex shift `z` with `Re(z)>0`, choose `eps<Re(z)`. Ordinary Abel
summation then makes

`sum u_n exp(iE0log n)n^(-z)`

convergent. Hence `D_G(s)` is represented by an ordinary Dirichlet series and
is analytic throughout

`Re(s)>0`.

Now use the v383 normalization

`G7hat(w)
 =sum sqrt(n)log(n)u_n n^(-w)`.

Termwise integration in the safe half-plane gives

`D_G(s)
 =int_(s+1/2)^infty G7hat(w)dw`.

v515 proves that every zeta zero `rho` is a nonremovable singularity of
`G7hat(rho)`:

* a multiple zero leaves a pole-type singularity;
* a simple zero leaves a nonzero logarithmic branch.

Therefore an off-critical zero

`rho=1/2+a+i gamma`,
`a>0`,

forces a nonremovable singularity of the primitive `D_G` at

`s=rho-1/2=a+i gamma`,

which lies in `Re(s)>0`.

This contradicts the analyticity obtained from the subpower prefix assumption.

Hence

`ONE-ANCHOR GLOBAL SUBPOWER G7 PREFIX`
` => no zero with Re(rho)>1/2`
` => RH`

after functional-equation reflection.

So v506's subpower G7 target, although quantitatively weaker than bounded
prefix, is **still RH-strength**.

It must not be advertised as an independently easy lemma.

**Verdict:** `SUBPOWER_G7_PREFIX_IS_RH_IMPLYING_CIRCULARITY_PASS`.

The finite G7 head itself already carries the off-critical singularity; the
mesoscopic R7 cascade is not required for the logical RH obstruction.
