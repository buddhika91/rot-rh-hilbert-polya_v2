# ROT-RH v559 — exact centered determinant primitive and Gaussian phase flow

On `Re(s)>1`, define
`mu(s)=exp(int_s^infty (zeta(w)-1)dw)`.

The exact centered Dirichlet field from v383/v527 is
`D(s)=-zeta'(s)/zeta(s)-(zeta(s)-1)`.

Since
`d_s log mu(s)=-(zeta(s)-1)`,
we have the exact primitive identity
`boxed{D(s)=d_s log[mu(s)/zeta(s)]}`.

Thus
`Delta(s)=mu(s)/zeta(s)`
is the natural centered relative determinant on the safe half-plane.
The scalar gauge `mu` is exactly the smooth-channel factor already appearing
in the v383/v511 Selberg preconditioner.

## Gaussian regularization

For `tau>0`, define the entire centered Gaussian field
`D_tau(s)=sum_(n>=2)(Lambda(n)-1)n^(-s)e^[-tau(log n)^2]`.

Because the series is entire, it has a global entire primitive. Fix any
basepoint `s_0` and define
`Delta_tau(s)`
` =exp(int_(s_0)^s D_tau(w)dw)`.

Then:
- `Delta_tau` is entire;
- `Delta_tau` is zero-free;
- `d_s log Delta_tau=D_tau`.

On the critical energy line
`s=1/2+iE`,
put
`Phi_tau(E)=arg Delta_tau(1/2+iE)`
using the global logarithm. Since
`d_E log Delta_tau=iD_tau`,
`boxed{Phi_tau'(E)=Re D_tau(1/2+iE)}`.

Up to the fixed sign/pi convention, this is exactly the centered Gaussian
arithmetic derivative entering the secular phase.

Therefore the finite-cutoff ROT-RH arithmetic phase is already an exact
boundary phase of a zero-free relative determinant. The missing operator
theorem is not determinant existence; it is a passivity/self-adjointness or
action-budget classification of this determinant family.

**Verdict:** `CENTERED_GAUSSIAN_ARITHMETIC_IS_EXACT_ZERO_FREE_DETERMINANT_PHASE_PASS`.
