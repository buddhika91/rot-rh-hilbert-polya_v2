# ROT-RH v570 — exact trace-one capacity from the universal Volterra Fock ladder

From v569, in the canonical Bargmann basis

`e_m(z)=z^m/sqrt(m!)`,

the universal preconditioned transfer is

`J e_m`
` =1/sqrt(m+1) e_(m+1)`.

Therefore

`J^2 e_m`
` =1/sqrt[(m+1)(m+2)] e_(m+2)`.

Define the positive recursive capacity kernel

`K_F:=(J^2)^* J^2`.

It is diagonal:

`K_F e_m`
` =lambda_m e_m`,

with

`lambda_m`
` =1/[(m+1)(m+2)]`

` =1/(m+1)-1/(m+2)`.

Hence exactly

`boxed{Tr K_F`
` =sum_(m>=0)lambda_m`
` =1}`.

No trace normalization is imposed: trace one is a consequence of the
two-step Volterra weights.

The eigenvalues also define an exact telescoping novelty law. Put

`c_m=1/(m+1)`.

Then

`lambda_m=c_m-c_(m+1)`,

so

`sum_(m=0)^(M-1)lambda_m`
` =1-1/(M+1)`.

Thus the universal recursive ladder carries one finite unit of cumulative
capacity.

## Gaussian-active depth

Every multiplicative recursive step moves arithmetic support by at least a
factor two.  If the Gaussian-active arithmetic is truncated at

`log n<=C L^2`

with fixed `C`, then any support path in that band has depth

`m<=C L^2/log2+O(1)`.

Consequently every Fock-depth novelty inside the active band satisfies

`lambda_m`
` >=c_C L^(-4)`

for a fixed positive `c_C`.

This is exactly the subexponential novelty scale required by v556 **for Fock
depths**.

## Remaining bridge

A secular selector crossing has not been proved to occupy a distinct Fock
depth.

The phase can, in principle, wind many times while remaining in a coherent
superposition of the same recursive depths.

Therefore v570 supplies:
- a canonical trace-one ROT capacity;
- a polynomial novelty floor for active recursion depths;

but not yet:
- an injection from distinct first-later-crossing spectral levels to distinct
  unsaturated Fock novelty.

That crossing-to-depth/novelty theorem is now the precise missing operator
bridge.

**Verdict:** `UNIVERSAL_VOLterra_TWO_STEP_KERNEL_HAS_EXACT_TRACE_ONE_CAPACITY_PASS`.
