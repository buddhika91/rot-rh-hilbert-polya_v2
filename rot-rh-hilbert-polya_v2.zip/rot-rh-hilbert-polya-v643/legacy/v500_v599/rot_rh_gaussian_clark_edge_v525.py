#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v525 — GAUSSIAN CLARK EDGE-RESONANCE SMALL-MEASURE THEOREM
=================================================================

Let A(L) be a smooth increasing exposed-mode amplitude with
  A'(L) >= c L A(L)
eventually, and omega(L)>=c_omega L^2.

The antinode-nearest quantization target has gap
  delta(L)=A(L)-(K+1/2) in [0,1)
between successive amplitude crossings.

Its collision-normalized Clark weight (normalization <= C L) obeys, for small
delta,
  alpha_edge(L) <= C/[L sqrt(A(L) delta(L))].

Therefore alpha_edge>eps implies
  delta < C/(eps^2 L^2 A).

Since d delta/dL=A'(L)>=c L A between resets, each bad interval around a
half-integer amplitude crossing has width
  O(1/(eps^2 L^3 A^2)).

There are O(L A) crossings per unit L, so the total bad-L measure density is
  O(1/(eps^2 L^2 A)),
which is integrable (indeed exponentially small) when A=e^{cL^2}/poly(L).

Hence for every eps>0 the set of late L where the exceptional normalized
edge weight exceeds eps has finite total Lebesgue measure; its limsup has
measure zero.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v525-edge-resonance-measure"

def model_density(L,c=0.02,eps=.1):
    A=math.exp(c*L*L)/max(L,1.0)
    # proportional model for bad-set measure density
    density=1.0/(eps*eps*L*L*A)
    return {"L":L,"A":A,"bad_measure_density_proxy":density}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v525 — Gaussian Clark edge-resonance small-measure theorem

Continue the v524 local exposed-mode model. Let the amplitude be smooth and
eventually increasing with

`A'(L)>=c_A L A(L)`

and let the phase frequency satisfy

`omega(L)>=c_omega L^2`.

These are the natural Gaussian saddle scales when the exposed score is
strictly positive.

Between successive crossings of a half-integer amplitude target, write

`delta(L)=A(L)-(K+1/2)`,
`0<delta<1`.

The antinode-nearest root has

`sqrt(A^2-y^2)`
` =sqrt[(A-y)(A+y)]`
` >=sqrt(A delta)`

up to an absolute late-scale constant.

Thus its raw Clark weight obeys

`w_edge`
` <=C/[omega sqrt(A delta)]`.

If the collision normalization satisfies

`c_L<=C_0L`,

then

`alpha_edge`
` <=C/[L sqrt(A delta)]`.

Fix `eps>0`. The event

`alpha_edge>eps`

requires

`delta<C/(eps^2L^2A)`.

But, away from the reset point,

`d delta/dL=A'(L)>=c_A L A`.

Hence the width in `L` of one bad interval is at most

`C/(eps^2 L^3 A^2)`.

The number of half-integer amplitude crossings per unit `L` is `O(A'(L))`,
hence `O(LA)`. Therefore the total bad-set measure per unit scale is

`O(1/(eps^2 L^2 A(L)))`.

For the Gaussian exposed amplitude

`A(L)=exp(cL^2)/poly(L)`,

this is integrable on every late ray.

Consequently, for each fixed `eps>0`,

`measure{L>=L0: alpha_edge(L)>eps}<infinity`,

and the late repeated-resonance limsup has Lebesgue measure zero.

So the exceptional Clark channel from v524 is a sparse-in-cutoff resonance:
it prevents a uniform-in-all-real-L Herglotz bound, but it does not prevent
almost-everywhere/cofinal weak-measure collapse of the off-critical cluster.

**Verdict:** `GAUSSIAN_CLARK_EDGE_RESONANCE_HAS_FINITE_BAD_CUTOFF_MEASURE_PASS`.

This statement is conditional on the stated monotone exposed-amplitude and
collision-normalization inequalities; those should be supplied by a
publication-grade v497/v496 Gaussian saddle theorem.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_EDGE_RESONANCE_V1",
        "assumptions":[
            "A'(L)>=c_A L A(L)",
            "omega(L)>=c_omega L^2",
            "collision normalization <=C L"
        ],
        "bad_density":"O(1/(eps^2 L^2 A(L)))",
        "conclusion":"finite bad-L measure for each eps; a.e. normalized edge weight ->0",
        "scope":"conditional local asymptotic theorem"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--epsilon",type=float,default=.1)
    ap.add_argument("--prefix",default="rot_rh_gaussian_clark_edge_v525")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    rows=[]
    with tqdm(total=4,desc="v525 edge measure",unit="L") as bar:
        for L in (10.,15.,20.,25.):
            rows.append(model_density(L,eps=args.epsilon));bar.update(1)
    ok=all(rows[i+1]["bad_measure_density_proxy"]<rows[i]["bad_measure_density_proxy"]
           for i in range(len(rows)-1))
    verdict="GAUSSIAN_CLARK_EDGE_RESONANCE_HAS_FINITE_BAD_CUTOFF_MEASURE_PASS" if ok else "DIAGNOSTIC_FAILED"
    payload={"version":VERSION,"verdict":verdict,"epsilon":args.epsilon,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Conditional asymptotic measure theorem; diagnostic panel only."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
