# ROT-RH v537 — exact trace-one ROT kernel / uniform counting theorem

The v87/v88 ROT-native construction has three exact structural properties.

1. Every instantaneous response operator is positive semidefinite.
2. Every nonzero response channel is divided by its trace, the channel weights
   are normalized, and the final response is again trace-normalized. Therefore

`R_n>=0`,
`Tr R_n=1`.

3. The recursive kernel starts from

`K_0=0`

and the shell loop is indexed from `n=0` with the parameter-free Cesaro step

`eta_n=1/(n+1)`,

`K_(n+1)=K_n+eta_n(R_n-K_n)`.

At the first shell, `eta_0=1`, so

`K_1=R_0`.

Hence

`K_1>=0`,
`Tr K_1=1`.

If `K_n>=0` and `Tr K_n=1`, then

`K_(n+1)`
` =(1-eta_n)K_n+eta_n R_n`

is a convex combination of PSD trace-one operators. Therefore by induction

`boxed{K_n>=0, Tr K_n=1}`

for every finite stage `n>=1`.

## Exact inverse-square trace

Let the supported positive eigenvalues of `K_n` be `lambda_j>0` and define the
canonical ROT energies exactly as in v86-v88:

`epsilon_j=s/sqrt(lambda_j)`.

Then on the support,

`H_ROT=s K_n^(-1/2)`

and

`H_ROT^(-2)=K_n/s^2`.

Therefore

`boxed{Tr H_ROT^(-2)=1/s^2}`

at every finite stage.

## Uniform fixed-energy counting

If

`epsilon_j<=E`,

then

`lambda_j>=s^2/E^2`.

Hence

`N_ROT(E) s^2/E^2`
` <=sum_(epsilon_j<=E)lambda_j`
` <=Tr K_n=1`.

Thus

`boxed{N_ROT(E)<=E^2/s^2}`

for every finite stage, every winding dimension, and every number/order of
prime shells.

This is a genuine zero-blind spectral-counting theorem.

## Infinite limit

If a joint prime-shell/winding limit exists in trace norm,

`K_n -> K_ROT`,

then trace is continuous:

`Tr K_ROT=1`.

If the limit is positive, compact and injective, then

`H_ROT=sK_ROT^(-1/2)`

is the usual unbounded positive self-adjoint operator and still

`Tr H_ROT^(-2)=1/s^2`,
`N_ROT(E)<=E^2/s^2`.

**Verdict:** `EXACT_TRACE_ONE_ROT_KERNEL_UNIFORM_COUNTING_PASS`.

No Xi, zeta values, zero ordinates, or secular roots enter this theorem.
