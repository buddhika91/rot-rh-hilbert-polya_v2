# ROT-RH v552 — exact selector winding / Dirichlet-action lower bound

For the ordered first-later-crossing support
`F_L(E_k)=k-1/2`,
we have exactly
`F_L(E_(k+1))-F_L(E_k)=1`.

Define
`U_L(E)=exp[2pi i F_L(E)]`.
The continuous lifted phase changes by `2pi` between every consecutive pair,
so each selector interval carries net winding `+1`.

If `[a,b]` spans `M` consecutive loaded increments, then
`int_a^b F_L'(E)dE=M`.
Cauchy-Schwarz gives
`boxed{int_a^b |F_L'|^2 >= M^2/(b-a)}`.
Since `|U_L'|=2pi|F_L'|`,
`boxed{int_a^b |U_L'|^2 >=4pi^2 M^2/(b-a)}`.

Thus v530's exponential fixed-energy occupancy forces positive `L^2`
exponential type in the compact-phase Dirichlet action. This identifies the
v518-v519 Gaussian quadratic covariance as the weighted compact-phase action
order parameter.

**Verdict:** `SELECTOR_LEVEL_COUNT_IS_COMPACT_PHASE_WINDING_ACTION_PASS`.
