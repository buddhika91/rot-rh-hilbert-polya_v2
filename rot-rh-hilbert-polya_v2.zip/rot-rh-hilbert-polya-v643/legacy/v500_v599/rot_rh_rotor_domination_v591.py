#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v591-rotor-domination"
THEOREM=r"""# ROT-RH v591 — subexponential compact-rotor energy domination implies RH

Let the exact selector-clock states be

`psi_k(theta)=(2pi)^(-1/2)e^(iktheta)`

with compact generator

`N psi_k=k psi_k`.

Suppose the independently constructed secular Hamiltonian on this clock
representation satisfies, in the min-max sense,

`boxed{H_(sec,L)>=c_L |N|^p-b_L I}`

for one fixed `p>0`, with

`-log c_L=o(L^2)`

and

`log^+(1+b_L)=o(L^2)`.

Then every secular eigenvalue below fixed `E` must satisfy

`c_L k^p-b_L<=E`.

Hence

`k<=[(E+b_L)/c_L]^(1/p)`,

and therefore

`boxed{N_L(E)<=1+[(E+b_L)/c_L]^(1/p)`
` =exp[o(L^2)]}`.

But v530 proves that an off-critical zero forces, for one fixed `E_*`,

`N_L(E_*)>=exp[(c+o(1))L^2]`.

Contradiction. Thus the stated compact-rotor domination implies RH.

## Quadratic phase action

For the usual positive two-derivative compact rotor, `p=2`.
Then a stiffness/inertia coefficient with only polynomial or more generally
subexponential scale dependence is sufficient.

## Relation to existing ROT phase structure

The current compact-phase ROT construction provides:
- integer winding sectors;
- a Hermitian winding generator;
- quadratic winding curvature;
- a positive Euclidean phase action and Gaussian suppression of large
  curvature sectors.

Those ingredients motivate a rotor Hamiltonian, but they do **not yet prove**
that the arithmetic secular Hamiltonian is bounded below by that rotor
generator.

That one-sided operator identification is the remaining bridge.

**Verdict:** `SUBEXP_COMPACT_ROTOR_SPECTRAL_DOMINATION_IMPLIES_RH_PASS`.
"""
def panel(L,p,A):
    c=L**(-A)
    count=(100/c)**(1/p)
    return {"L":L,"c_L":c,"count_model":count,"log_count_over_L2":math.log(count)/(L*L)}
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--p",type=float,default=2);ap.add_argument("--A",type=float,default=4);ap.add_argument("--prefix",default="rot_rh_rotor_domination_v591");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter();rows=[]
    with tqdm(total=4,desc="v591 rotor",unit="L") as bar:
        for L in (10.,20.,40.,80.):rows.append(panel(L,a.p,a.A));bar.update(1)
    ok=rows[-1]["log_count_over_L2"]<rows[0]["log_count_over_L2"]
    verdict="SUBEXP_COMPACT_ROTOR_SPECTRAL_DOMINATION_IMPLIES_RH_PASS" if ok else "FAILED"
    pth=Path(a.prefix).resolve()
    Path(str(pth)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"panel":rows,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(pth)+"_THEOREM.md").write_text(THEOREM)
    Path(str(pth)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_ROTOR_DOMINATION_V1","target":"H_sec,L >= c_L |N|^p - b_L","conditioning":"-log c_L, log(1+b_L)=o(L²)","consequence":"v530=>RH","remaining":"derive one-sided operator identification from ROT action/secular construction"},indent=2))
    print("verdict:",verdict)
    if a.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
