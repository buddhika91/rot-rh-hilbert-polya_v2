# ROT-RH v501 — first-hitting running-max / heat-trace identity

Let `F_L(E)` be the continuous zero-blind secular count on `E>=0`, normalized by

`F_L(0)=0`.

The canonical support is defined by the existing **first later crossing** rule

`E_k(L)=inf{E>=0:F_L(E)=k-1/2}`,
`k=1,2,...`.

Define the running maximum

`M_L(E)=max_(0<=x<=E) F_L(x)`.

Because `F_L` is continuous and starts at zero, it reaches every level between
`0` and `M_L(E)`.  Therefore

`E_k(L)<=E`
iff
`k-1/2<=M_L(E)`.

Hence the selected counting function is exactly

`N_L(E)=#{k:E_k(L)<=E}`
`      =floor(M_L(E)+1/2)`,

with the right side understood as zero before the first half-integer is reached.

This identity remains true even if `F_L` has folds, negative derivative, repeated
crossings, or violent oscillations.  Those later crossings do not affect the
first-hitting spectrum.

For the ordinary spectral heat trace,

`h_L(u)=sum_k exp(-uE_k(L)^2)`
`      =int_0^infty exp(-uE^2)dN_L(E)`.

The fixed-cutoff Weyl asymptotic makes the boundary term vanish, so Stieltjes
integration by parts gives exactly

`h_L(u)=2u int_0^infty E exp(-uE^2) N_L(E)dE`.

Since

`N_L(E)<=M_L(E)+1/2`,

we obtain

`h_L(u)`
` <=2u int_0^infty E exp(-uE^2) M_L(E)dE + 1/2`.

Conversely,

`N_L(E)>=max(0,M_L(E)-1/2)`,

so divergence of the weighted running maximum forces heat-trace divergence.

Therefore v500's one-heat RH target can be replaced by a **pure scalar phase
theorem**:

`sup_L int_0^infty`
` E exp(-u0E^2) M_L(E)dE < infinity`

for one fixed `u0>0`.

No individual root flow, branch matching, no-fold estimate, transversality
lower bound, or zero ordinate is required for this implication.

### New analytic frontier

Write

`F_L(E)=F_free(E)+A_L(E)`

with `A_L` the zero-blind centered arithmetic phase.  It is enough to control
the **positive running excursions** of this scalar phase in one Gaussian energy
weight.  Absolute variation of `A_L`, pointwise derivative positivity, and
uniform control at every energy are all stronger than necessary.

Combined with v497-v500:

`WEIGHTED RUNNING-MAX BOUND`
` => ONE-u HEAT BOUND`
` => NO OFF-CRITICAL ZERO`
` => RH`.

**Verdict:** `EXACT_FIRST_HITTING_RUNNING_MAX_HEAT_IDENTITY_PASS`.
