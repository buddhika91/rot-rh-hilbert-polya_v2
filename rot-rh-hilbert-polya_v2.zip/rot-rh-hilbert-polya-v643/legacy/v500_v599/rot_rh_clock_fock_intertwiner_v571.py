#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v571-clock-fock-intertwiner"
THEOREM=r"""# ROT-RH v571 — exact selector-clock / Volterra-Fock U(1) intertwiner

Let `H_clock=H^2(S^1)` be the nonnegative-frequency Hardy clock space with
`psi_k(theta)=(2pi)^(-1/2)e^(ik theta)`, `k>=0`.

v557 identifies selector label `k` with exactly this compact-clock character.

Let `F` be the Bargmann-Fock space with normalized monomial basis
`e_k(z)=z^k/sqrt(k!)`.

v569 gives the universal Volterra transfer
`J e_k=1/sqrt(k+1)e_(k+1)`.

Define the unitary `W psi_k=e_k`. Let
`N_clock=-i partial_theta` and `N_F e_k=k e_k`.
Then exactly `W N_clock W^(-1)=N_F`.

Define
`J_clock=M_(e^(i theta))(N_clock+1)^(-1/2)`.
It obeys
`J_clock psi_k=1/sqrt(k+1) psi_(k+1)`,
hence
`boxed{W J_clock W^(-1)=J}`.

Therefore the compact selector clock and the universal Volterra Fock ladder
have exactly intertwined U(1) charge decomposition and weighted raising
dynamics.

The v570 capacity kernel becomes
`K_clock=(J_clock^2)^*J_clock^2=[(N_clock+1)(N_clock+2)]^(-1)`,
so
`K_clock psi_k=1/[(k+1)(k+2)] psi_k`
and `Tr K_clock=1`.

## Important correction

This does not prove the v556 novelty floor.
For selector label `k`,
`lambda_k=1/[(k+1)(k+2)]`.

If an off-critical zero produces
`k=exp(cL^2+o(L^2))`,
then
`lambda_k=exp(-2cL^2+o(L^2))`,
which is exponentially smaller than the required `exp[-o(L^2)]` floor.

So the representation bridge is exact, but the fixed trace-one kernel is too
soft at very high winding.

**Verdict:** `SELECTOR_CLOCK_AND_VOLterra_FOCK_ARE_EXACTLY_U1_INTERTWINED_PASS`.

Remaining theorem: derive a scale/energy-dependent accessibility law that
prevents exponentially high selector charge from being physically loaded at
fixed energy.
"""
def check(N):
    import numpy as np
    k=np.arange(N,dtype=float)
    j1=1/np.sqrt(k+1); j2=1/np.sqrt(k+1)
    lam=1/((k+1)*(k+2))
    return {"max_shift_weight_error":float(np.max(np.abs(j1-j2))),
            "partial_trace":float(lam.sum()),
            "exact_partial_trace":float(1-1/(N+1))}
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--N",type=int,default=100000);ap.add_argument("--prefix",default="rot_rh_clock_fock_intertwiner_v571");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v571 intertwiner",unit="step") as bar:
        chk=check(a.N);bar.update(1)
    ok=chk["max_shift_weight_error"]<1e-15 and abs(chk["partial_trace"]-chk["exact_partial_trace"])<1e-12
    verdict="SELECTOR_CLOCK_AND_VOLterra_FOCK_ARE_EXACTLY_U1_INTERTWINED_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"check":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_CLOCK_FOCK_INTERTWINER_V1","closed":"W psi_k=e_k intertwines U(1), number, and weighted raising J","capacity":"lambda_k=1/((k+1)(k+2))","barrier":"lambda_k exponentially small at exponentially large selector k","remaining":"scale/energy dependent accessibility"},indent=2))
    print("verdict:",verdict);print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
