#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v534 — COEFFICIENT-L2 TO GAUSSIAN-GRAM EMBEDDING BARRIER
===============================================================

Corrects/supersedes the overstrong implication stated in v533.

Natural Selberg coefficient:
  x_n=(Lambda(n)-1)/(sqrt(n) log n).

The differentiated Gaussian observable is
  P_L(E)=sum x_n [log n e^{-(logn/L)^2}] e^{iElogn}.

As a point evaluation on ordinary coefficient l2, its dual norm is
  W_L^2=sum (log n)^2 e^{-2(logn/L)^2}.

Integral comparison in y=log n gives
  log W_L = L^2/16 + O(log L).

Thus ordinary coefficient l2 permits the exponential type 1/16.

But an offcritical zero a in (0,1/2) has derivative exponent a^2/4<1/16.
Therefore even a uniform ordinary-l2 coefficient bound cannot contradict an
offcritical Gaussian residue.

The exact Gaussian Gram norm v523 is essential.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v534-l2-embedding-barrier"

def continuum_log_norm(L):
    # W^2 ~ ∫ e^y y^2 e^{-2y^2/L^2}dy.
    # dominant exponential rate max_y y-2y^2/L^2 = L^2/8 at y=L^2/4.
    return L*L/16.0

def panel():
    return [{"a":a,"offcritical_derivative_rate":a*a/4,
             "ordinary_l2_dual_rate":1/16,
             "l2_too_weak":a*a/4<1/16}
            for a in (.02,.05,.1,.2,.3,.4,.49)]

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v534 — coefficient-L2 to Gaussian-Gram embedding barrier

The natural Selberg state is

`x_n=(Lambda(n)-1)/(sqrt(n)log n)`.

Its differentiated Gaussian secular observable is

`P_L(E)`
` =sum_(n>=2)x_n`
`   [log n exp(-(log n/L)^2)]`
`   exp(iElog n)`.

Regard this only as a linear functional on ordinary coefficient `ell^2`.
Its dual norm is

`W_L`
` =[sum_(n>=2)(log n)^2`
`   exp(-2(log n/L)^2)]^(1/2)`.

Integral comparison with `y=log n` gives

`W_L^2`
` ~int_0^infty`
`   y^2 exp[y-2y^2/L^2]dy`.

The exponent

`y-2y^2/L^2`

has its maximum at

`y=L^2/4`

with value

`L^2/8`.

Therefore

`log W_L=L^2/16+O(log L)`.

So even the hypothetical bound

`||x||_2=O(1)`

would only imply

`|P_L(E)|`
` <=exp[(1/16+o(1))L^2]`.

But for a nontrivial off-critical displacement

`0<a<1/2`,

v527-v530 give differentiated residue rate

`a^2/4<1/16`.

Thus ordinary coefficient `ell^2` is **too weak at the exponential scale** to
see the RH contradiction.

## Correction to v533

v531 remains a valid zero-blind theorem:

`K_Lambda`

is small in an ordinary beta-conjugated coefficient-Hilbert shadow.

v532 also remains a valid deterministic coercivity reduction for the smooth
preconditioner in that shadow.

However, those statements do **not** imply v519's Gaussian covariance bound
without an additional embedding estimate of zero backward exponential type.

Such an embedding is precisely where the off-diagonal Gaussian correlations
live.

Therefore v533's claimed RH closure is superseded.

The correct Hilbert target remains v523:

`estimate the exact Selberg transfer directly in the Gaussian Gram norm`.

**Verdict:** `ORDINARY_L2_EMBEDDING_HAS_1OVER16_EXPONENTIAL_BARRIER_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_L2_GAUSSIAN_EMBEDDING_BARRIER_V1",
        "ordinary_l2_dual_type":"1/16",
        "offcritical_type":"a^2/4 < 1/16 for 0<a<1/2",
        "v531":"VALID coefficient-shadow theorem",
        "v532":"VALID coefficient-shadow coercivity reduction",
        "v533":"SUPERSEDED unless zero-type Gaussian-Gram embedding is added",
        "current_target":"v523 exact Gaussian-Gram Selberg transfer"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_l2_gaussian_embedding_barrier_v534")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v534 rates",unit="step") as bar:
        rows=panel();bar.update(1)
    ok=all(r["l2_too_weak"] for r in rows)
    verdict="ORDINARY_L2_EMBEDDING_HAS_1OVER16_EXPONENTIAL_BARRIER_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Laplace/integral-comparison exponent theorem."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
