# ROT-RH v547 — homogeneous trace-one amplitude-preserving source embedding

Let

`a=(a_1,...,a_d) in C^d`

be an **unnormalized** arithmetic source vector and choose a fixed,
zero-blind reference scale

`sigma>0`.

Define the homogeneous state

`psi_sigma(a)`
` =(sigma,a_1,...,a_d)`
`  /sqrt(sigma^2+||a||_2^2)`

and its response projector

`R_sigma(a)=|psi_sigma(a)><psi_sigma(a)|`.

Then immediately

`R_sigma(a)>=0`,
`rank R_sigma(a)=1`,
`Tr R_sigma(a)=1`.

Unlike the v86 normalization, this map retains the radial source magnitude.

Indeed,

`R_00`
` =sigma^2/(sigma^2+||a||^2)>0`

and

`R_(m0)`
` =sigma a_m/(sigma^2+||a||^2)`.

Therefore exactly

`boxed{a_m=sigma R_(m0)/R_00}`.

So

`a -> R_sigma(a)`

is injective.

The fixed positive reference coordinate removes the global-projective phase
ambiguity and lets the full complex source vector—including its magnitude—be
recovered from a PSD trace-one operator.

## Combined with the adaptive clock

Take the raw source to be the v541 adapted moments

`a_m(L)`
` =sum_p w_p`
`   exp(i m Delta_L log p)`

with

`Delta_L B_L<2pi`.

Then:

1. v541: the complete moment vector determines the active log-frequency
   measure on the non-aliased band;
2. v547: the trace-one projector determines that raw moment vector exactly.

Hence the trace-one source representation itself is **faithful** to the
band-limited arithmetic forcing.

Any convex/Cesaro recursion of such response operators continues to satisfy the
v537 trace budget.

## Boundary

Averaging many source projectors into one final kernel can still lose
time/shell information, and no secular spectral domination is proved here.

The theorem closes the two representation-level information losses:
- v540 fixed-clock aliasing, once adaptive `Delta_L` is used;
- v546 shell-amplitude erasure.

**Verdict:** `HOMOGENEOUS_TRACE_ONE_SOURCE_IS_AMPLITUDE_FAITHFUL_PASS`.

The next question is dynamical: which recursive covariance of these faithful
states has the v543 Bessel-accessibility property?
