#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v511 — EXACT R GAUGE / LOG-ZETA VOLTERRA LINEARIZATION
==============================================================

Starting from v383 on Re(s)>1,

  R[A](s)
   = mu(s)^(-1) int_s^infty mu(w) (zeta'/zeta)(w) A(w) dw,

  mu(s)=exp(int_s^infty (zeta(w)-1) dw).

Define U[A](s)=mu(s)A(s). Then exactly

  U R U^{-1} f = V f,

  (Vf)(s)=int_s^infty L(w)f(w)dw,
  L=zeta'/zeta.

On a simply connected zero-free domain with a branch of log zeta and a path
from s to a safe point at infinity, put

  z(s)=-log zeta(s).

Since dz=-(zeta'/zeta)ds,

  (Vf)(s)=int_0^{z(s)} f(s(eta)) d eta.

Thus in the z-coordinate R is conjugate to the universal Volterra primitive

  (Jg)(z)=int_0^z g(eta)deta.

This is an exact algebraic theorem on any zero-free branch domain.
"""
from __future__ import annotations
import argparse, json, time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v511-R-gauge-logzeta"

def symbolic_check():
    try:
        import sympy as sp
    except Exception as exc:
        return {"available":False,"pass":False,"error":str(exc)}
    mu,L,A = sp.symbols("mu L A", nonzero=True)
    # Pure algebraic gauge cancellation in the integral kernel:
    integrand_before = mu*L*(A/mu)
    residual = sp.simplify(integrand_before - L*A)
    return {"available":True,"pass":bool(residual==0),"residual":str(residual)}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v511 — exact R gauge / log-zeta Volterra linearization

v383 gives, for `Re(s)>1`,

`R[A](s)
 =mu(s)^(-1)
  int_s^infty mu(w)[zeta'(w)/zeta(w)]A(w)dw`

with

`mu(s)=exp(int_s^infty(zeta(w)-1)dw)`.

Define the invertible scalar gauge

`U[A](s)=mu(s)A(s)`.

Then

`U R U^(-1) f`
` =int_s^infty [zeta'(w)/zeta(w)] f(w)dw`.

So

`R ~ V`,

where

`(Vf)(s)=int_s^infty L(w)f(w)dw`,
`L=zeta'/zeta`.

Now work on a simply connected zero-free branch domain and choose a branch of
`log zeta`. Put

`z(s)=-log zeta(s)`.

Then

`dz=-(zeta'/zeta)(s)ds=-L(s)ds`.

If the path terminates in the safe right half-plane where `zeta -> 1`, hence
`z -> 0`, then

`(Vf)(s)
 =int_s^infty L(w)f(w)dw
 =int_0^(z(s)) f(s(eta))deta`.

Writing

`g(eta)=f(s(eta))`

gives the universal Volterra primitive

`(Jg)(z)=int_0^z g(eta)deta`.

Therefore, on every zero-free branch domain,

`R`

is **exactly gauge-and-coordinate conjugate** to ordinary integration.

No positivity estimate, asymptotic approximation, zero ordinate, or numerical
zeta value is used in this identity.

## Consequence

The complicated-looking recursive `R` dynamics does not possess an unknown
local generator: its generator is exactly the logarithmic connection
`d log zeta`.

A zero is precisely an obstruction to extending the coordinate

`z=-log zeta`

through the corresponding horizontal/complex path.

**Verdict:** `EXACT_R_GAUGE_LOGZETA_VOLTERRA_LINEARIZATION_PASS`.

This is a structural reduction, not an RH proof.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_R_GAUGE_LOGZETA_V1",
        "closed":{
            "gauge":"U[A]=mu A",
            "gauged_R":"Vf=int_s^inf (zeta'/zeta)f",
            "coordinate":"z=-log zeta",
            "coordinate_R":"Jg(z)=int_0^z g(eta)deta"
        },
        "domain":"simply connected zero-free branch domain",
        "next":"derive exact iterates and block-7 packet collapse"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_R_gauge_logzeta_v511")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v511 algebra",unit="step") as bar:
        chk=symbolic_check();bar.update(1)
    ok=bool(chk.get("pass"))
    verdict="EXACT_R_GAUGE_LOGZETA_VOLTERRA_LINEARIZATION_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"symbolic_check":chk,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact algebra on zero-free branch domains."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
