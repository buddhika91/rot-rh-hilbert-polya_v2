# ROT-RH v508 — recursive-selector swing-loading lemma

Use the **actual** ROT-RH selector from v503:

`E_1` is the first selected crossing of `F(E)=1/2` after the fixed lower search
floor `B`, and

`E_(k+1)=inf{E>E_k:F(E)=k+1/2}`.

Let

`B<=a<b`

and suppose

`F(a)<1/2`

and

`F(b)>=K-1/2`

for an integer `K>=1`.

Then

`E_k<=b`

for every `1<=k<=K`.

Indeed, continuity gives a `1/2` crossing between `a` and `b`, hence the first
selected `E_1` occurs no later than `b`. Inductively, if `E_j<=b`, then

`F(E_j)=j-1/2 < j+1/2 <= K-1/2 <= F(b)`.

Continuity on `[E_j,b]` gives a crossing of `j+1/2` after `E_j`; the first such
crossing is `E_(j+1)`, so `E_(j+1)<=b`.

Thus one upward secular swing loads an entire consecutive block of ordered
levels. No monotonicity, no-fold assumption, or root matching is required.

## Application to v497

On the exposed Gaussian off-critical interval, the dominant mode has

`A_L >= C L^-1 exp(cL^2/4)`

and phase frequency `Theta(L^2)`. Hence there are alternating antinodes inside
the same fixed interval. Since all other saddles and the static background are
`o(A_L)`, choose one negative antinode `a_L` followed by a positive antinode
`b_L`. Eventually

`F_L(a_L)<1/2`

and

`F_L(b_L)>=c' A_L`.

The swing-loading lemma gives

`N_L(b_L)>=floor(c'A_L+1/2)`.

Because `b_L` remains below the fixed right endpoint `E_*`,

`N_L(E_*) >= C' L^-1 exp(cL^2/4) -> infinity`.

Therefore v497's occupancy-explosion mechanism is compatible with the actual
recursive first-later-crossing selector.

**Verdict:** `EXACT_RECURSIVE_SELECTOR_SWING_LOADING_PASS`.

Publication precision still requires the uniform exposed-mode saddle/remainder
bounds from v497; the selector logic itself is now closed.
