#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v555-cumulative-novelty-budget"
THEOREM=r"""# ROT-RH v555 — exact cumulative novelty-capacity theorem

Let `K_0=0` on a finite-dimensional observer space and let each incoming
response satisfy

`0<=R_n<=I`.

Define the **unnormalized cumulative novelty update**

`K_(n+1)`
` =K_n+(I-K_n)^(1/2) R_n (I-K_n)^(1/2)`.

Assume `0<=K_n<=I`. Since `R_n<=I`,

`0<=(I-K_n)^(1/2)R_n(I-K_n)^(1/2)<=I-K_n`.

Therefore

`0<=K_(n+1)<=I`.

By induction this holds for every `n`.

Define the novelty cost

`nu_n`
` =Tr[(I-K_n)^(1/2)R_n(I-K_n)^(1/2)]`
` =Tr[(I-K_n)R_n]`
` >=0`.

Then exactly

`Tr K_(n+1)-Tr K_n=nu_n`.

Hence

`boxed{sum_(j=0)^(N-1) nu_j=Tr K_N<=d}`

where `d` is the observer-space dimension.

This is a genuine cumulative capacity law.

It differs critically from v88:
- no post-novelty trace renormalization;
- no Cesaro division by the number of shells;
- no replenished scalar reservoir is required.

Redundant responses automatically cost little; genuinely new directions consume
the finite spectral occupancy `I-K`.

For rank-one `R_n=|psi_n><psi_n|`,

`nu_n=<psi_n,(I-K_n)psi_n>`,

the unsaturated squared observer novelty.

**Verdict:** `EXACT_CUMULATIVE_NOVELTY_CAPACITY_TELESCOPES_PASS`.

This theorem does not say secular crossings have a lower novelty cost. That is
the next bridge.
"""
def demo(d,N):
    import numpy as np
    K=np.zeros((d,d),complex); total=0.; rows=[]
    for n in range(N):
        v=np.zeros(d,complex); v[n%d]=1
        R=np.outer(v,v.conj())
        w,U=np.linalg.eigh((K+K.conj().T)/2)
        sqrt_gap=U@np.diag(np.sqrt(np.maximum(1-w,0)))@U.conj().T
        A=sqrt_gap@R@sqrt_gap
        nu=float(np.trace(A).real); total+=nu
        K=K+A
        if n<d+2: rows.append({"step":n+1,"nu":nu,"traceK":float(np.trace(K).real)})
    eig=np.linalg.eigvalsh(K)
    return {"d":d,"N":N,"sum_novelty":total,"traceK":float(np.trace(K).real),
            "max_eig":float(eig.max()),"min_eig":float(eig.min()),"samples":rows}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--dimension",type=int,default=8); ap.add_argument("--steps",type=int,default=40); ap.add_argument("--prefix",default="rot_rh_cumulative_novelty_v555"); ap.add_argument("--strict",action="store_true"); a=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v555 novelty",unit="step") as bar: chk=demo(a.dimension,a.steps); bar.update(1)
    ok=abs(chk["sum_novelty"]-chk["traceK"])<1e-10 and chk["traceK"]<=a.dimension+1e-10 and chk["max_eig"]<=1+1e-10
    verdict="EXACT_CUMULATIVE_NOVELTY_CAPACITY_TELESCOPES_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"demo":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_CUMULATIVE_NOVELTY_V1","identity":"sum nu=Tr K<=d","next":"lower novelty per secular winding"},indent=2))
    print("verdict:",verdict); print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
