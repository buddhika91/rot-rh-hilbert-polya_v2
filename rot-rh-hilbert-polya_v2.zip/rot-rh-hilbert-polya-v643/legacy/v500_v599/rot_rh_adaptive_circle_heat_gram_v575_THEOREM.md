# ROT-RH v575 — v518 Gaussian Gram covariance is the adaptive compact-clock heat kernel

Fix the Gaussian energy weight parameter `u>0`.

For the v518 covariance, write log-frequencies

`y_n=log n`

and the line Gaussian kernel

`G_u(y,y')=exp[-(y-y')^2/(4u)]`.

Use the v549 adaptive compact clock on the active band

`0<=y<=B_L=C L^2`,

with

`alpha_L=L^(-r)`,
`Delta_L=alpha_L/B_L`.

Set

`theta=Delta_L y`

and choose compact-clock heat time

`t_L=u Delta_L^2`.

The circle heat kernel is

`K_t^(S1)(theta)`
` =1/sqrt(4pi t)`
`   sum_(ell in Z)`
`   exp[-(theta+2pi ell)^2/(4t)]`.

Normalize away the common prefactor and evaluate at the adaptive difference:

`G_circ,L(y,y')`
` :=sqrt(4pi t_L)`
`   K_(t_L)^(S1)(Delta_L(y-y'))`.

Then

`G_circ,L(y,y')`
` =sum_(ell in Z)`
` exp[-(Delta_L(y-y')+2pi ell)^2/(4u Delta_L^2)]`.

The principal image `ell=0` is exactly

`boxed{G_u(y,y')`
` =exp[-(y-y')^2/(4u)]}`.

## Periodization error

On the active band,

`|Delta_L(y-y')|<=alpha_L<1`.

Hence every nonzero image obeys

`|Delta_L(y-y')+2pi ell|`
` >=2pi|ell|-1`.

Therefore

`|G_circ,L-G_u|`
` <=2 sum_(ell>=1)`
` exp[-(2pi ell-1)^2/(4u Delta_L^2)]`

` <=C_u exp[-c_u/Delta_L^2]`.

Since

`Delta_L`
` =L^(-r)/(C L^2)`,

`1/Delta_L^2=C^2 L^(4+2r)`.

Thus

`boxed{|G_circ,L-G_u|`
` <=exp[-c L^(4+2r)]}`

up to a fixed prefactor.

The centered Gaussian arithmetic coefficient total variation has at most
`exp[(1/16+o(1))L^2]` growth (v549).  Therefore the full quadratic-form error,
even after two coefficient sums, remains

`exp[-c L^(4+2r)+O(L^2)]`,

hence is superexponentially small on the RH `L^2` scale.

## Hilbert-space form

The compact heat kernel has the Fourier feature representation

`2pi K_t^(S1)(theta-phi)`
` =sum_(k in Z)`
`   exp(-t k^2) exp[ik(theta-phi)]`.

Thus define compact-clock heat coherent states

`|theta>_t`
` =sum_(k in Z)`
`   exp(-t k^2/2)e^(-ik theta)|k>`.

Their Gram matrix is the circle heat kernel.

Consequently the v518 order parameter can be written, up to a fixed
normalization and superexponentially small adaptive-periodization error, as

`boxed{Q_L(u)=||Psi_L||_(clock,t_L)^2+superexp.small}`,

where `Psi_L` is the zero-blind centered arithmetic superposition of the
adaptive compact-clock coherent states labelled by `theta_n=Delta_L log n`.

The heat trace/effective winding dimension is

`sum_k exp(-t_L k^2)`
` =Theta(t_L^(-1/2))`
` =Theta(Delta_L^(-1))`
` =O(L^(2+r))`.

So the exact RH-sensitive quadratic covariance lives in a compact ROT clock
representation with only polynomial effective winding dimension.

## What remains

Polynomial dimension does not bound the norm of an unnormalized source vector.
The missing theorem is now an amplitude/coercivity statement:

`||Psi_L||^2=exp[o(L^2)]`.

By v519/v536, that statement is RH-strength.

**Verdict:** `GAUSSIAN_RH_COVARIANCE_HAS_ADAPTIVE_COMPACT_CLOCK_HEAT_KERNEL_REPRESENTATION_PASS`.
