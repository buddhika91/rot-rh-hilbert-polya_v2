# ROT-RH v576 — normalized observer states erase the exact RH order parameter

By v575, the v518 Gaussian quadratic order parameter has the compact-clock
representation

`Q_L(u)=||Psi_L||^2+superexp.small`.

Suppose one replaces the raw arithmetic clock state by its normalized ray

`psi_L=Psi_L/||Psi_L||`

and then forms any projector/density state depending only on that ray, for
example

`rho_L=|psi_L><psi_L|`.

Then

`Tr rho_L=1`

identically, regardless of whether

`||Psi_L||`
is polynomial, subexponential, or
`exp(cL^2)`.

More generally, the map

`Psi ->Psi/||Psi||`

is invariant under every positive radial rescaling

`Psi ->A_L Psi`.

But v519/v536 show that the RH-sensitive datum is precisely the radial scale:

`Q_L=||Psi_L||^2`.

An off-critical zero changes this norm by positive `L^2` exponential type.
Normalization deletes that information exactly.

Therefore no theorem formulated purely in terms of:
- trace-one normalization,
- projective state geometry,
- normalized fidelity,
- normalized density matrices,

can by itself prove the required Gaussian quadratic bound unless the missing
normalization factor is separately controlled.

## Correct finish line

Write a zero-blind synthesis of the raw compact-clock state as

`Psi_L=T_L Omega_L`.

A sufficient ROT theorem is

`||Omega_L||<=exp[o(L^2)]`

and

`||T_L||<=exp[o(L^2)]`.

Equivalently, if using the preconditioned Selberg fixed point

`Psi_L=(I-R_L)^(-1)Omega_L`,

it suffices to prove

`||(I-R_L)^(-1)||<=exp[o(L^2)]`

together with a subexponential forcing norm.

Then v575 gives

`Q_L(u)=exp[o(L^2)]`,

and v519/v536 force RH.

**Verdict:** `NORMALIZATION_ERASES_GAUSSIAN_RH_RADIAL_ORDER_PARAMETER_PASS`.

The next theorem must be an unnormalized source/action/coercivity bound.
