# ROT-RH v543 — trace-one Bessel accessibility counting criterion

Let `K_L` be a positive ROT observer kernel satisfying the exact v537 invariant

`Tr K_L=1`.

Fix a finite secular energy window `[0,E]`. Associate to each selected secular
level

`E_k(L)<=E`

a unit observer-space vector `v_(k,L)`.

Assume two quantitative properties.

### 1. Bessel/frame upper bound

For every observer vector `f`,

`sum_(E_k<=E)|<f,v_(k,L)>|^2`
` <=B_E(L)||f||^2`.

Equivalently, the frame operator

`S_(E,L)=sum_(E_k<=E)|v_k><v_k|`

satisfies

`S_(E,L)<=B_E(L)I`.

Orthogonality is the special case `B_E=1`.

### 2. Nonvanishing ROT accessibility

Every secular state consumes at least

`a_E(L)>0`

of the trace-one observer covariance:

`<v_(k,L),K_L v_(k,L)>`
` >=a_E(L)`.

Then

`N_L(E)a_E(L)`
` <=sum_k <v_k,K_Lv_k>`

` =Tr[K_L^(1/2) S_(E,L) K_L^(1/2)]`

` <=B_E(L)Tr K_L`

` =B_E(L)`.

Hence the exact counting bound

`boxed{N_L(E)<=B_E(L)/a_E(L)}`.

## RH-bearing scale

v530 proves that an off-critical zero forces, for some fixed `E_*`,

`N_L(E_*)`
` >=C L^(-1)exp(cL^2/4)`.

Therefore it is **not necessary** that `B_E` and `a_E` remain constant.

It is sufficient that

`boxed{log[B_E(L)/a_E(L)]=o(L^2)}`.

Polynomial frame loss, polynomially decaying accessibility, or any other
sub-`L^2` exponential conditioning is harmless.

Under that condition the trace-one accessibility theorem contradicts v530 and,
after functional-equation reflection, implies RH.

## Interpretation

The remaining ROT statement is:

> A fixed finite secular energy window cannot generate exponentially many
> mutually near-redundant observer states while each retains exponentially
> significant recursive accessibility.

This is weaker than v539 full positive-operator domination and weaker than
one-sided eigenvalue-by-eigenvalue comparison.

**Verdict:** `SUBEXPONENTIAL_BESSEL_ACCESSIBILITY_BRIDGE_IMPLIES_RH_PASS`.

The Bessel/accessibility estimates themselves remain open.
