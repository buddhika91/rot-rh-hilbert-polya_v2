#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v514 — LYAPUNOV / LOG-DERIVATIVE CIRCULARITY AUDIT
=========================================================

v511-v513 show that R packet evolution is the log-zeta connection in disguise.
A proposed pointwise contraction/monotonicity theorem based on the real part
of a completed logarithmic derivative must therefore be audited against known
RH-equivalent positivity criteria.

For xi(s), the classical criterion is:

  RH  <=>  Re[xi'(s)/xi(s)] > 0 for Re(s)>1/2.

Therefore a proof strategy whose decisive new assumption/theorem is exactly
that sign condition has not reduced RH.

The non-circular ROT target must instead derive a subexponential Gaussian
cascade bound from an independently proved operator property (self-adjoint
passivity, a positive Fredholm/transfer determinant, canonical-system
Herglotz property, etc.), without importing the xi'/xi half-plane sign.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v514-lyapunov-circularity"

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v514 — Lyapunov / logarithmic-derivative circularity audit

v511 proves that the recursive transfer `R` is, after an exact gauge and
coordinate change, ordinary Volterra integration in

`z=-log zeta(s)`.

Thus a packet-depth Lyapunov law built only from the horizontal real part of
the zeta/xi logarithmic connection must be checked for circularity.

For the completed Riemann function

`xi(s)=1/2 s(s-1) pi^(-s/2) Gamma(s/2) zeta(s)`,

the classical Hinkkanen/Lagarias criterion states

`RH`

if and only if

`Re[xi'(s)/xi(s)]>0`

throughout

`Re(s)>1/2`.

So the following proposed closure is **RH-equivalent**, not a smaller lemma:

`prove Re[xi'/xi]>0 on the entire right critical half-plane`
` => conclude packet-flow contractivity`
` => conclude RH`.

Likewise, proving global horizontal monotonicity of `|xi(s)|` in that entire
half-plane is not an independent ROT mechanism.

## What remains non-circular

A valid new closure must establish the v510 subexponential mesoscopic cascade
from structure that is already defined without knowing the zero set, for
example:

1. a self-adjoint/canonical-system realization whose Weyl function is
   Herglotz by operator theory;
2. a genuine positive/passive transfer determinant derived from the ROT
   recursion before identifying it with zeta;
3. a quadratic form or energy inequality for the G7-generated cyclic orbit
   whose proof uses only coefficient/operator identities and not the sign of
   `xi'/xi`;
4. an exact Fredholm perturbation determinant identification with a
   self-adjoint operator.

**Verdict:** `LOG_DERIVATIVE_POINTWISE_LYAPUNOV_ROUTE_IS_RH_EQUIVALENT_NOGO_PASS`.

This removes a circular next step; it does not prove RH.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_LYAPUNOV_CIRCULARITY_V1",
        "classification":{
            "Re_xi_log_derivative_positive_on_sigma_gt_half":"RH_EQUIVALENT",
            "horizontal_modulus_monotonicity":"RH_EQUIVALENT",
            "R_only_logzeta_connection":"NO_INDEPENDENT_CLOSURE"
        },
        "next":"derive an independent operator-theoretic passivity/Herglotz/Fredholm property before using zeta identification"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_lyapunov_circularity_v514")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v514 audit",unit="step") as bar:
        ok=True;bar.update(1)
    verdict="LOG_DERIVATIVE_POINTWISE_LYAPUNOV_ROUTE_IS_RH_EQUIVALENT_NOGO_PASS"
    payload={"version":VERSION,"verdict":verdict,
             "external_classical_fact":"RH iff Re(xi'/xi)>0 for Re(s)>1/2 (Hinkkanen/Lagarias)",
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Logical/circularity audit; classical equivalence is external theorem."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
if __name__=="__main__":main()
