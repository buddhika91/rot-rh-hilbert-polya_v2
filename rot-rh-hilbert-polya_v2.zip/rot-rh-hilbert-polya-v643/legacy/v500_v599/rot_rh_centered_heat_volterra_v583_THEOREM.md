# ROT-RH v583 — exact centered Gaussian determinant coordinate linearizes to Volterra

For `tau>0`, define

`q_tau(s)=log Delta_tau(s)`

` =-sum_(n>=2)`
`   (Lambda(n)-1)/(log n)`
`   n^(-s)exp[-tau(log n)^2]`.

Because of the Gaussian factor, `q_tau` is entire.

Its derivative is exactly

`q_tau'(s)`
` =sum_(n>=2)(Lambda(n)-1)n^(-s)e^[-tau(logn)^2]`

` =D_tau(s)`.

Also `q_tau(s)->0` as `Re s->+infinity`.

Define the zero-blind finite-cutoff transfer

`(R_tau A)(s)`
` :=-int_s^infinity D_tau(w)A(w)dw`

along any path on which the entire integrand is integrated to the safe right
half-plane.

Put

`eta=q_tau(w)`.

Since

`d eta=D_tau(w)dw`

and the endpoint at infinity has `eta=0`,

`(R_tau A)(s)`
` =-int_(q_tau(s))^0 A(w(eta))deta`

` =int_0^(q_tau(s)) A(w(eta))deta`.

Hence, after composition with the coordinate `q_tau`,

`boxed{R_tau ~ J}`,
`(Jg)(q)=int_0^q g(eta)deta`.

This is an exact Volterra linearization at every positive Gaussian cutoff:
- no branch of `log zeta`;
- no zero-free domain assumption;
- no known zero ordinate;
- no limiting contour argument.

For the constant source,

`(I-J)^(-1)1=e^q`.

Therefore

`boxed{(I-R_tau)^(-1)1`
` =exp[q_tau(s)]`
` =Delta_tau(s)}`.

So the exact centered Gaussian determinant is itself a universal Volterra
resolvent orbit.

## Physical metric distortion

On `s=1/2+iE`,

`d_E q_tau=iD_tau`.

Therefore the v518-v519 order parameter is

`boxed{Q_L(u)`
` =int_R e^(-uE^2)`
`   |d_E q_(L^-2)(1/2+iE)|^2 dE}`.

Thus RH is reduced to a metric statement about the zero-blind coordinate map

`E -> q_tau(1/2+iE)`:

`Q_L(u)=exp[o(L^2)]`

means its Gaussian-weighted Dirichlet/Jacobian energy has zero positive
`L^2` exponential type.

By v579 the universal Volterra resolvent in the **q-coordinate** is uniformly
bounded.  Hence all RH-sensitive instability sits in the coordinate Jacobian,
not in the abstract recursive integration operator.

**Verdict:** `CENTERED_GAUSSIAN_DETERMINANT_GIVES_EXACT_BRANCH_FREE_VOLterra_COORDINATE_PASS`.
