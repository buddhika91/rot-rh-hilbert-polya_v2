# ROT-RH v523 — exact Gaussian-Gram Selberg-transfer target

For coefficients `c_n`, define

`||c||_(L,u)^2`

`:=int_R e^(-uE^2)
 |sum_(n>=2)c_n n^(-1/2)
  e^[-(log n/L)^2]e^(iElog n)|^2dE`.

The exact Gaussian Fourier identity gives

`||c||_(L,u)^2`
`=sqrt(pi/u) sum_(m,n>=2)`
` c_m conjugate(c_n)/sqrt(mn)`
` exp[-(logm/L)^2-(logn/L)^2]`
` exp[-log^2(m/n)/(4u)]`.

This is a positive-semidefinite Gram norm.

For

`c_n=r(n)=Lambda(n)-1`,

it is exactly the v518 quadratic order parameter.

Now use Selberg's exact causal recursion

`r(n)log n+2(b*r)(n)+(r*r)(n)=H(n)`.

At the true arithmetic solution the Frechet derivative is

`(J_r delta r)(n)`
` =-2/log n`
`   sum_(d|n,d<n)Lambda(n/d)delta r(d)`,

the same exact Jacobian whose natural weighted `l-infinity` contraction was
globally certified in v276.

The new theorem target is to estimate **that same exact Jacobian in the
Gaussian Gram geometry itself**.

A sufficient closure is either

`||J_r||_(L,u -> L,u)<=q<1`

uniformly for large `L`, or the weaker block condition

`||J_r^m||_(L,u -> L,u)<=exp(o(L^2))`

combined with an `exp(o(L^2))` bound for the Selberg forcing solution.

Then the unique causal fixed point satisfies

`||r||_(L,u)^2=exp(o(L^2))`.

By v519 this forces RH.

### Why this target is genuinely different from earlier failures

* v276 proves contraction in a coefficient `l-infinity` norm but the critical
  evaluation functional is unbounded there.
* v518 puts the evaluation inside a quadratic norm but had no recursive
  mechanism.
* v523 combines the two: **Selberg recursion measured directly in the exact
  v518 Gaussian covariance geometry**.
* v522 shows brute long-window orthogonalization cannot substitute for this
  phase-sensitive transfer.

The next analytic calculation is the Schur/Carleson norm of the divisor-sparse
Jacobian against the Gaussian multiplicative Gram kernel.

**Verdict:** `GAUSSIAN_GRAM_SELBERG_TRANSFER_IS_CURRENT_NONTAUTOLOGICAL_TARGET_PASS`.
