#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v507 — GAUSSIAN DEEP-R7 REMAINDER EXPONENTIAL KILL
=========================================================
"""
from __future__ import annotations
import argparse,json,math,time
from fractions import Fraction
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v507-gaussian-deep-R7"
Q2=Fraction(82247680000000,617673396283947)
RHO=Q2/Fraction(128**2,1)

def exponents(kappa):
    q=float(Q2); rho=float(RHO)
    return {
        "Q2":q,"rho2":rho,
        "log_Q2":math.log(q),"log_rho2":math.log(rho),
        "first_L2_exponent":kappa*math.log(q),
        "second_L2_exponent":1+kappa*math.log(rho),
        "decays":bool(kappa*math.log(q)<0 and 1+kappa*math.log(rho)<0),
        "minimum_kappa_for_second":1/abs(math.log(rho))
    }

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v507 — Gaussian deep-R7 remainder exponential kill

Let `T=R^7`. v327 proves

`||Tu||_(2,128s)<=Q2||u||_(2,s)`

with

`Q2=82247680000000/617673396283947<1`.

For the centered state x, v328 gives a finite beta-2 input norm, so

`||T^Jx||_(2,s_J)<=C_x Q2^J`,
`s_J=2*128^J`.

For

`b_L(n)=exp[-(log n/L)^2]`,

beta-2 Abel summation on a sequence supported at `s` gives

`W_(2,G)(s,L)
 <=C[1+L exp(L^2)/s^2]`.

Therefore

`|<b_L e^(iElog n),T^Jx>|`

`<=C C_x [Q2^J
 +L exp(L^2)(Q2/128^2)^J]`.

Put

`rho2=Q2/128^2`.

Choose

`J(L)=ceil(kappa L^2)`

with

`kappa>1/|log rho2|`.

Then both terms decay like `exp(-cL^2)`.

Thus the genuinely deep recursive remainder is exponentially negligible in the
Gaussian geometry.

The exact packet identity

`x=sum_(r=0)^(J-1)T^rG7+T^Jx`

shows that the remaining object is the mesoscopic cascade

`sum_(r<Theta(L^2))T^rG7`.

This is now the sharp recursive bottleneck.

**Verdict:** `GAUSSIAN_DEEP_R7_REMAINDER_EXPONENTIAL_KILL_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_DEEP_R7_V1",
        "closed":{
            "Q2":str(Q2),"rho2":str(RHO),
            "choice":"J=ceil(kappa L^2), kappa>1/|log rho2|",
            "deep_remainder":"O(exp(-cL^2))"
        },
        "remaining":"mesoscopic sum r<Theta(L^2) of T^rG7"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--kappa",type=float,default=.1)
    ap.add_argument("--prefix",default="rot_rh_gaussian_deep_R7_v507")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v507 exponents",unit="step") as bar:
        ex=exponents(args.kappa);bar.update(1)
    ok=bool(ex["decays"])
    verdict="GAUSSIAN_DEEP_R7_REMAINDER_EXPONENTIAL_KILL_PASS" if ok else "KAPPA_TOO_SMALL"
    payload={"version":VERSION,"verdict":verdict,"kappa":float(args.kappa),
             "exponents":ex,"runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("exponents:",ex)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__":main()
