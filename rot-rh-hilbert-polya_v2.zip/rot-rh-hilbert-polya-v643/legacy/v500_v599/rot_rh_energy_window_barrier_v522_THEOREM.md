# ROT-RH v522 — energy-averaging diagonalization exponent barrier

For an off-critical displacement

`a=Re(rho)-1/2`,
`0<a<1/2`,

the Gaussian saddle occurs at

`log N_a~aL^2/2`.

Hence

`N_a=exp[(a/2+o(1))L^2]`.

The corresponding v518 quadratic peak has size

`exp[(a^2/2+o(1))L^2]`.

Now try to prove the quadratic bound by enlarging the energy average until the
Dirichlet frequencies `log n` become essentially orthogonal.

Near scale `N_a`, neighboring integer frequencies have spacing

`log(n+1)-log n~1/N_a`

(and prime frequencies differ only by polylogarithmic factors at the exponent
level). A brute mean-value/large-sieve diagonalization therefore needs

`T >= N_a/polylog N_a`,

so

`liminf L^-2 log T >= a/2`.

But the resulting diagonal upper bound has at least the window-size cost

`T * poly(L)`.

For it to contradict the off-critical quadratic signal one would need

`limsup L^-2 log T < a^2/2`.

These inequalities are incompatible because

`a/2-a^2/2=a(1-a)/2>0`.

Therefore **brute frequency orthogonalization by a long E-window cannot close
the Gaussian RH criterion**.

Any successful quadratic proof must exploit arithmetic correlation/cancellation
before complete frequency resolution—e.g. the Selberg recursion in a
phase-sensitive Hilbert geometry.

**Verdict:** `ENERGY_WINDOW_DIAGONALIZATION_EXPONENT_BARRIER_PASS`.

This is an exponent-level no-go for the standard mean-value shortcut, not a
claim against more structured large-sieve/Selberg arguments.
