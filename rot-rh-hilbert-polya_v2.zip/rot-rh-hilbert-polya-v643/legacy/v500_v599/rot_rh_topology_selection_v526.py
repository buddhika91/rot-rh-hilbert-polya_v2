#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v526 — HILBERT–POLYA TOPOLOGY SELECTION THEOREM
======================================================

Combine v497/v498 and v524/v525.

A hypothetical offcritical Gaussian exposed mode can simultaneously have:

  (A) N_L(E*) -> infinity exponentially in a fixed bounded interval;
  (B) collision-normalized Clark measure of the same bulk cluster ->0,
      with only sparse edge-resonance cutoffs.

Therefore weak convergence of the collision-normalized Herglotz/Clark measures
does NOT imply:
  - local spectral counting tightness,
  - a uniform inverse-square trace bound,
  - trace-norm convergence of H_L^-2.

For an RH-bearing Hilbert–Pólya cutoff theorem the topology must retain spectral
multiplicity/counting information: e.g. norm/strong-resolvent plus compact
resolvent with uniform counting control, or directly trace-norm convergence of
H_L^-2. Herglotz convergence of one cyclic measure is insufficient.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v526-topology-selection"

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v526 — Hilbert–Pólya topology selection theorem

v82/v83 construct positive atomic Herglotz/Clark realizations from the
arithmetic root-and-slope data. Their measure weights are proportional to the
inverse root slopes.

v497/v508 show that a hypothetical exposed Gaussian off-critical mode creates

`N_L(E_*)=exp[Theta(L^2)]`

ordered levels below one fixed finite energy.

v524 shows that the same local cluster has total collision-normalized Clark
mass

`O(L^-1)`

after removal of one antinode-nearest edge level, and v525 shows that the edge
level is large only on a finite-measure/sparse set of late cutoffs under the
natural Gaussian amplitude assumptions.

Therefore it is possible, at the level of the local asymptotic model, for

`nu_L(cluster) ->0`

in weak Herglotz/Clark measure while simultaneously

`# spectrum(cluster) ->infinity`.

Thus:

`weak Clark/Herglotz convergence`
` does NOT imply`
`uniform spectral counting tightness`.

In particular it does not imply

`sup_L Tr(H_L^-2)<infinity`

or trace-norm convergence of `H_L^-2`.

## Consequence for the ROT-RH program

If the goal is an RH-bearing Hilbert–Pólya theorem, the cutoff topology must
retain multiplicity/counting information. Sufficient choices include:

* direct trace-norm convergence of `H_L^-2`;
* a uniform inverse-square trace bound plus fixed-mode convergence;
* an independently defined compact-resolvent self-adjoint operator family with
  a convergence theorem strong enough to prevent spectral pollution/local
  multiplicity escape.

Convergence of one collision-normalized cyclic Herglotz measure is valuable
operator information, but it is too weak by itself.

**Verdict:** `RH_BEARING_CUTOFF_TOPOLOGY_MUST_CONTROL_SPECTRAL_COUNTING_PASS`.

This does not prove the required strong topology; it rules out treating weak
Clark convergence as a substitute for it.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_TOPOLOGY_SELECTION_V1",
        "weak_topology":"collision-normalized Clark/Herglotz measure",
        "countermechanism":"offcritical cluster can have vanishing Clark mass and exploding root count",
        "required_RH_topology":"trace/counting-sensitive operator convergence",
        "next":"return to uniform trace/Weyl/displacement theorem or build independent common-basis operator"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_topology_selection_v526")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v526 logic",unit="step") as bar:
        ok=True;bar.update(1)
    verdict="RH_BEARING_CUTOFF_TOPOLOGY_MUST_CONTROL_SPECTRAL_COUNTING_PASS"
    payload={"version":VERSION,"verdict":verdict,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Logical consequence of v497/v508 plus local Clark-mass theorem v524/v525."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
if __name__=="__main__":main()
