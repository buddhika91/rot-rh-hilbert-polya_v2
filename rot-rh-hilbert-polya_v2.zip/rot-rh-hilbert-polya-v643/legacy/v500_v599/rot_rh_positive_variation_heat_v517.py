#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v517 — POSITIVE-VARIATION HEAT-TRACE BOUND
==================================================

For the actual recursive selector E_k:
  F(E_k)=k-1/2,
  E_{k+1}>E_k.

On each interval [E_j,E_{j+1}], the net increase is exactly 1, hence the
positive variation of F is at least 1:
  int_{E_j}^{E_{j+1}} (F')_+ >= 1.

Therefore for E>=E1,
  N(E)<=1+int_{E1}^E (F'(t))_+ dt.

Insert into
  h(u)=2u int E e^{-uE^2}N(E)dE
and use Tonelli:
  h(u)
   <= e^{-uE1^2}
      + int_{E1}^infty e^{-ut^2}(F'(t))_+ dt.

This is an exact one-sided scalar criterion. It is weaker than controlling
running maxima, total variation, |F'|, or pointwise arithmetic prefixes.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v517-positive-variation-heat"

def toy():
    # A folded path with levels increasing one by one. Each interval net +1,
    # so positive variation >= number of loaded increments.
    increments=[1.0,1.0,1.0,1.0]
    positive_variations=[2.4,1.1,3.0,1.7]
    ok=all(v>=d for v,d in zip(positive_variations,increments))
    return {"increments":increments,"positive_variations":positive_variations,"pass":ok}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v517 — positive-variation heat-trace bound

Let the actual ordered support satisfy

`F_L(E_k)=k-1/2`

and

`E_1<E_2<...`.

Assume `F_L` is absolutely continuous on compact real intervals, which holds
for the Gaussian-regulated arithmetic phase.

For every `j`,

`F_L(E_(j+1))-F_L(E_j)=1`.

Hence the positive variation on that interval obeys

`int_(E_j)^(E_(j+1)) (F_L'(t))_+ dt >=1`.

The selector intervals are disjoint. Therefore for `E>=E_1`,

`N_L(E)-1`
` <=int_(E_1)^E (F_L'(t))_+dt`,

or

`N_L(E)
 <=1+int_(E_1)^E(F_L')_+`.

Now use the exact heat-counting identity

`h_L(u)
 =2u int_(E_1)^infty
    E exp(-uE^2)N_L(E)dE`.

The constant `1` contributes

`exp(-uE_1^2)`.

For the variation term, Tonelli gives

`2u int_(E_1)^infty E exp(-uE^2)
       int_(E_1)^E(F_L'(t))_+dt dE`

`=int_(E_1)^infty (F_L'(t))_+
    [int_t^infty2uE exp(-uE^2)dE]dt`

`=int_(E_1)^infty exp(-ut^2)(F_L'(t))_+dt`.

Thus

`h_L(u)`
` <=exp(-uE_1^2)`
`   +int_(E_1)^infty exp(-uE^2)(F_L'(E))_+dE`.

This is exact.

## New RH-bearing target

It is enough to prove, at one fixed `u>0`, a subexponential-in-`L^2` estimate

`int exp(-uE^2)(F_L'(E))_+dE`
` <=exp(o(L^2))`.

An off-critical Gaussian mode from v497/v502 produces exponentially large
alternating slopes with a positive-duty-cycle bounded away from zero, so its
positive variation has positive `L^2` exponential type.

Unlike v506, this criterion does **not** assert pointwise `N^o(1)` prefix
control and does not directly create an analytic Dirichlet continuation from
one frequency.

**Verdict:** `EXACT_POSITIVE_VARIATION_HEAT_BOUND_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_POSITIVE_VARIATION_HEAT_V1",
        "closed":{
            "selector_loading":"N(E)-1 <= int_E1^E (F')_+",
            "heat_bound":"h(u)<=e^-uE1^2 + int_E1^inf e^-uE^2(F')_+dE"
        },
        "next":"bound only Gaussian-weighted positive secular slope variation by exp(o(L^2))"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_positive_variation_heat_v517")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v517 variation",unit="step") as bar:
        chk=toy();bar.update(1)
    ok=bool(chk["pass"])
    verdict="EXACT_POSITIVE_VARIATION_HEAT_BOUND_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"toy":chk,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
