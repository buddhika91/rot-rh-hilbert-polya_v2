# ROT-RH v557 — selector labels are exact compact-phase winding characters

At the first-later-crossing levels,

`F_L(E_k)=k-1/2`.

Introduce an auxiliary compact clock angle `theta in [0,2pi)` and define the
lifted selector character

`psi_k(theta)`
` =(2pi)^(-1/2) exp[i(F_L(E_k)+1/2)theta]`.

Since `F_L(E_k)+1/2=k`,

`psi_k(theta)=(2pi)^(-1/2)e^(ik theta)`.

Therefore

`<psi_j,psi_k>`
` =(1/2pi)int_0^(2pi)e^(i(k-j)theta)dtheta`
` =delta_(jk)`.

Thus the quantization index already has a canonical interpretation as an
integer winding sector of a compact U(1) clock: distinct selector labels are
exactly orthogonal characters.

This removes the v551 coherence obstruction **if** the ROT observer Hilbert
space contains the unwrapped clock register rather than only a finite
band-limited evaluation vector.

However, the regular representation is infinite-dimensional. To use v555/v556
one still needs an independently derived finite/subexponential accessible
clock capacity at resolution `L`, or an action law that makes high winding
sectors inaccessible at subexponential cost.

So the new bridge is sharply split:

1. orthogonality of different selector windings — exact;
2. capacity/novelty cost of admitting winding `k` — open ROT theorem.

**Verdict:** `SELECTOR_INDEX_EQUALS_ORTHOGONAL_COMPACT_CLOCK_CHARACTER_PASS`.
