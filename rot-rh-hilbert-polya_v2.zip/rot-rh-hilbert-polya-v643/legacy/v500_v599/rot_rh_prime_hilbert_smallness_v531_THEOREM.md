# ROT-RH v531 — prime-channel Hilbert smallness for every beta>0

Use the exact beta-conjugated prime transition from v324:

`l_beta(k,d)`
` =Lambda(k) k^(-1/2-beta)`
`  log(d)/log(kd)^2`.

Let `K_(Lambda,beta)` act on a finite coefficient vector supported on

`s<=d<=M/2`.

For an output `n`, the sum is over factorizations

`n=kd`

with `Lambda(k)!=0`, hence `k` is a prime power.

The number of prime-power divisors of `n` is

`sum_(p^v||n) v=Omega(n)`

and therefore

`Omega(n)<=log n/log2<=log M/log2`.

Cauchy-Schwarz at each output gives

`|(K_Lambda f)(n)|^2`
` <=Omega(n)`
`   sum_(k d=n)`
`   Lambda(k)^2 k^(-1-2beta)`
`   [log(d)^2/log(n)^4]|f(d)|^2`.

Sum over `n` and interchange the positive sums:

`||K_Lambda f||_2^2`
` <=[log M/log2]`
`   sum_d |f(d)|^2`
`   sum_k Lambda(k)^2 k^(-1-2beta)`
`       log(d)^2/log(kd)^4`.

Because `log(kd)>=log d>=log s`,

`log(d)^2/log(kd)^4<=1/(log s)^2`.

Hence

`||K_(Lambda,beta)||_(2->2)^2`
` <=[log M/log2]`
`   C_Lambda(beta)/(log s)^2`,

where

`C_Lambda(beta)`
` =sum_(k>=2)Lambda(k)^2/k^(1+2beta)`.

For every `beta>0` this is finite. Using only

`Lambda(k)<=log k`

and the elementary unimodal sum-integral estimate,

`C_Lambda(beta)`
` <=1/(4 beta^3)`
`   +4e^(-2)/(1+2beta)^2`.

Therefore

`||K_(Lambda,beta)||_(2->2)`
` <= sqrt[C_Lambda(beta) log M/log2]/log s`.

## Gaussian dynamic sector

The Gaussian dictionary gives

`beta_eff=2log d/L^2`.

On the sector `beta_eff>=beta>0`,

`log s>=beta L^2/2`.

If the Gaussian arithmetic is truncated at any horizon satisfying

`log M<=C L^2`

(the omitted log-Gaussian tail is exponentially small after choosing fixed
`C`), then

`||K_(Lambda,beta)||_2`
` <=C_(beta,C)/L`.

Thus the genuinely arithmetic prime channel becomes **small in Hilbert norm**
for every fixed positive beta.

This moves the absolute threshold from the BV value `beta>1/2` to the full
off-critical region `beta>0`.

**Verdict:** `PRIME_CHANNEL_HILBERT_SMALLNESS_FOR_ALL_POSITIVE_BETA_PASS`.

This theorem is unconditional and zero-blind. It does not yet bound the smooth
preconditioner `S=(I-K_b)^(-1)`.
