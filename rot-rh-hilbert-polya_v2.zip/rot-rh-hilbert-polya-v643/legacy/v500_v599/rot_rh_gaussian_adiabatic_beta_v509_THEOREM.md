# ROT-RH v509 — Gaussian R7 adiabatic dynamic-beta flow reduction

Let

`T=R^7`

with support dilation

`Q=128`.

After `r` packets the support floor is

`s_r=2Q^r`.

For the Gaussian

`b_L(n)=exp[-(log n/L)^2]`

the local power exponent from v505 is

`beta_eff(n,L)=2log n/L^2`.

At the packet floor,

`beta_r(L)
 =2log(s_r)/L^2
 =2log2/L^2 + r Delta_beta(L)`

with the **exact packet step**

`Delta_beta(L)=2log128/L^2`.

Therefore packet depth `r=Theta(L^2)` is a continuum/adiabatic beta-flow.

A hypothetical off-critical displacement

`a=beta_rho-1/2 in (0,1/2)`

is encountered at

`r_a(L)
 =a L^2/(2log128)+O(1)`.

So the remaining v507 mesoscopic cascade is not an arbitrary collection of
`O(L^2)` packets: it is a slow traversal of

`0<beta<1/2`.

This identifies the exact missing theorem shape.

Suppose a **signed, phase-preserving** local packet bound can be established:

`||T u||_(beta+Delta_beta,E)
 <=q_L(beta,E)||u||_(beta,E)`,

with

`log q_L(beta,E)
 =-kappa(beta,E)Delta_beta+o(Delta_beta)`

uniformly on compact beta/E sets. Then products over packet depth converge to
the Lyapunov integral

`log Product q_L
 -> -int kappa(beta,E)dbeta`.

More generally, the Gaussian zero-type target only needs the accumulated
positive logarithmic gain through every compact subinterval of `0<beta<1/2`
to be `o(L^2)` after the Gaussian weight is included.

### Why this matters

* beta=2 is far outside the RH-bearing saddle and controls only the deep tail.
* the phase-free positive theorem has its natural threshold at beta>1/2.
* the unresolved Gaussian region is exactly the signed adiabatic flow
  `0<beta<1/2`.

Hence the next non-circular theorem is no longer "prove another fixed-beta
R7 contraction." It is:

> **derive the signed packet Lyapunov law along the actual arithmetic
> G7-generated cyclic orbit for the continuous beta-flow 0<beta<1/2.**

A negative/zero-enough Lyapunov exponent yields v502 zero backward type; a
positive exponent localized at beta=a would reproduce the off-critical
instability.

**Verdict:** `EXACT_GAUSSIAN_R7_ADIABATIC_BETA_FLOW_REDUCTION_PASS`.

This is a reduction, not the Lyapunov theorem itself.
