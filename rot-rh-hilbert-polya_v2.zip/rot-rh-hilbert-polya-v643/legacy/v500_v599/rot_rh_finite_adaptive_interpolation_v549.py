#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v549 — FINITE ADAPTIVE-CLOCK FRACTIONAL-MOMENT INTERPOLATION
===================================================================

Band y in [0,B_L], B_L=C L^2.
Choose alpha_L=L^-r and Delta_L=alpha_L/B_L.

For E/Delta=m+delta, delta in [0,1), z=e^{i Delta y} lies on
|z-1|<=alpha<1 and

 e^{iEy}=z^m z^delta.

Use the binomial expansion
 z^delta=sum_{j=0}^q binom(delta,j)(z-1)^j + R_q.

For delta in [0,1], |binom(delta,j)|<=1 and
 |R_q|<=alpha^(q+1)/(1-alpha).

After expanding (z-1)^j, only integer moments m,...,m+q are used and the l1
coefficient norm is <2^(q+1).

Take q=ceil(A L^2/log L):
 error <= exp[-A r L^2+o(L^2)],
 coefficient norm = exp[o(L^2)],
 max moment index = O(L^(2+r)) for fixed E window.

For the Gaussian centered Mangoldt derivative the absolute total variation has
unconditional exponent <=1/16. Hence choose A r>1/16+eta; interpolation error
after summation is exponentially small.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v549-finite-adaptive-interpolation"

def panel(L,r,A,C,Emax):
    alpha=L**(-r)
    B=C*L*L
    delta_clock=alpha/B
    q=math.ceil(A*L*L/max(math.log(L),1.0))
    mmax=math.ceil(Emax/delta_clock)
    log_rem=(q+1)*math.log(alpha)-math.log1p(-alpha)
    log_coeff=(q+1)*math.log(2)
    tv_rate=1/16
    log_weighted_error=log_rem+tv_rate*L*L
    return {
        "L":L,"alpha":alpha,"B":B,"Delta":delta_clock,
        "q":q,"max_integer_moment":mmax+q,
        "log_coeff_norm_over_L2":log_coeff/(L*L),
        "log_remainder_over_L2":log_rem/(L*L),
        "log_error_after_abs_mass_over_L2":log_weighted_error/(L*L)
    }

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v549 — finite adaptive-clock fractional-moment interpolation

Fix an active log-frequency band

`0<=y<=B_L`,
`B_L=C L^2`.

Choose a shrinking compact clock arc

`alpha_L=L^(-r)`,
`r>0`,

and

`Delta_L=alpha_L/B_L`.

Then

`0<=Delta_L y<=alpha_L<1`

for all sufficiently large `L`.

Fix a bounded secular energy window `0<=E<=E_*` and write

`E/Delta_L=m+delta`,
`m=floor(E/Delta_L)`,
`0<=delta<1`.

Set

`z=exp(iDelta_L y)`.

Then exactly

`exp(iEy)=z^m z^delta`.

Because the entire active arc lies inside the disk

`|z-1|<=alpha_L<1`,

use the principal binomial expansion

`z^delta`
` =sum_(j=0)^infty binom(delta,j)(z-1)^j`.

For `0<=delta<=1`,

`|binom(delta,j)|<=1`

for all `j`. Therefore after truncation at `q`,

`|R_q(z)|`
` <=sum_(j=q+1)^infty |z-1|^j`
` <=alpha_L^(q+1)/(1-alpha_L)`.

Each polynomial

`(z-1)^j`

has coefficient `ell^1` norm exactly `2^j`. Hence the complete truncated
interpolant uses only the integer adapted moments

`m,m+1,...,m+q`

and its coefficient norm obeys

`||c_(E,L)||_1`
` <=sum_(j=0)^q2^j`
` <2^(q+1)`.

Now choose

`q_L=ceil[A L^2/log L]`

with fixed `A>0`.

Then

`log ||c_(E,L)||_1`
` <=A(log2)L^2/log L+O(1)`
` =o(L^2)`,

while

`log |R_q|`
` <=-A r L^2+o(L^2)`.

Also

`m<=E_*/Delta_L`
` =O(L^(2+r))`,

so the required winding dimension is only polynomial:

`d(L)=O(L^(2+r))`.

## Absolute Gaussian error

For the differentiated centered Gaussian arithmetic measure, elementary

`Lambda(n)<=log n`

and an integral comparison give the total-variation exponent

`sum_(n>=2)`
` (Lambda(n)+1)n^(-1/2)`
` exp[-(log n/L)^2]`

` <=exp[(1/16+o(1))L^2]`.

Indeed in `y=log n` the exponential part is

`exp[y/2-y^2/L^2]`

whose maximum is `L^2/16`.

Therefore the interpolation error after summing against the full centered
measure is

`<=exp[-(Ar-1/16+o(1))L^2]`.

Choose

`Ar>1/16+eta`

for any fixed `eta>0`. Then the reconstruction error is exponentially small:

`boxed{error<=exp[-(eta+o(1))L^2]}`,

while the interpolation conditioning remains

`exp[o(L^2)]`

and the moment dimension remains polynomial.

The Gaussian tail beyond `B_L=C L^2` is also exponentially negligible for any
fixed `C>1/2`, since its elementary absolute exponent is

`C/2-C^2<0`.

## Consequence

The continuous Gaussian secular prime transform on every fixed energy window
can be recovered, to exponentially better accuracy than required by v530,
from a **finite polynomial-size adaptive winding vector**, with only
subexponential coefficient conditioning.

Thus v541's infinite-moment injectivity can be upgraded to a quantitative
finite representation suitable for the v543 accessibility program.

**Verdict:** `FINITE_ADAPTIVE_CLOCK_EXPONENTIAL_RECONSTRUCTION_SUBEXP_CONDITION_PASS`.

This solves representation/interpolation. It does not supply the observer
accessibility lower bound.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_FINITE_ADAPTIVE_INTERPOLATION_V1",
        "band":"B_L=C L^2, C>1/2",
        "clock":"Delta=L^-r/B_L",
        "degree":"q=A L^2/log L",
        "dimension":"O(L^(2+r))",
        "coefficient_condition":"exp(o(L^2))",
        "error":"exp[-(Ar-1/16+o(1))L^2]",
        "choose":"Ar>1/16+eta",
        "remaining":"observer accessibility/spectralization"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--r",type=float,default=1.0)
    ap.add_argument("--A",type=float,default=.10)
    ap.add_argument("--C",type=float,default=1.0)
    ap.add_argument("--Emax",type=float,default=100.0)
    ap.add_argument("--prefix",default="rot_rh_finite_adaptive_interpolation_v549")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    if args.r<=0 or args.A*args.r<=1/16 or args.C<=.5:
        raise ValueError("require r>0, A*r>1/16, C>1/2")
    t0=time.perf_counter();rows=[]
    with tqdm(total=4,desc="v549 interpolation",unit="L") as bar:
        for L in (20.,40.,80.,160.):
            rows.append(panel(L,args.r,args.A,args.C,args.Emax));bar.update(1)
    ok=(rows[-1]["log_coeff_norm_over_L2"]<rows[0]["log_coeff_norm_over_L2"]
        and all(x["log_error_after_abs_mass_over_L2"]<0 for x in rows))
    verdict="FINITE_ADAPTIVE_CLOCK_EXPONENTIAL_RECONSTRUCTION_SUBEXP_CONDITION_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"r":args.r,"A":args.A,
             "C":args.C,"Emax":args.Emax,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict)
    for x in rows:print(x)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
