#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v547 — HOMOGENEOUS TRACE-ONE AMPLITUDE-PRESERVING SOURCE EMBEDDING
=========================================================================

For any raw complex source a in C^d and fixed sigma>0 define
  psi(a)=(sigma,a)/sqrt(sigma^2+||a||^2),
  R(a)=|psi><psi|.

Then:
  R>=0, rank R=1, Tr R=1.
Moreover R_00>0 and exactly
  a_m/sigma = R_{m0}/R_{00}.
Thus a -> R(a) is injective and retains the full raw complex vector including
its radial magnitude, while remaining trace one.

If a is the scale-adapted winding moment vector from v541, this removes both
fixed-clock aliasing and v546 radial amplitude erasure at the source level.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v547-homogeneous-trace-one-source"

def encode_decode(sigma):
    import numpy as np
    a=np.array([1.2+.7j,-2.1+.4j,.3-1.7j],dtype=complex)
    psi=np.concatenate(([complex(sigma,0)],a))
    psi=psi/np.linalg.norm(psi)
    R=np.outer(psi,psi.conj())
    rec=np.array([R[m+1,0]/R[0,0]*sigma for m in range(len(a))])
    eig=np.linalg.eigvalsh(R)
    return {
        "sigma":sigma,
        "trace_real":float(np.trace(R).real),
        "min_eigenvalue":float(eig.min()),
        "max_eigenvalue":float(eig.max()),
        "decode_error":float(np.linalg.norm(rec-a)),
        "R00":float(R[0,0].real)
    }

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v547 — homogeneous trace-one amplitude-preserving source embedding

Let

`a=(a_1,...,a_d) in C^d`

be an **unnormalized** arithmetic source vector and choose a fixed,
zero-blind reference scale

`sigma>0`.

Define the homogeneous state

`psi_sigma(a)`
` =(sigma,a_1,...,a_d)`
`  /sqrt(sigma^2+||a||_2^2)`

and its response projector

`R_sigma(a)=|psi_sigma(a)><psi_sigma(a)|`.

Then immediately

`R_sigma(a)>=0`,
`rank R_sigma(a)=1`,
`Tr R_sigma(a)=1`.

Unlike the v86 normalization, this map retains the radial source magnitude.

Indeed,

`R_00`
` =sigma^2/(sigma^2+||a||^2)>0`

and

`R_(m0)`
` =sigma a_m/(sigma^2+||a||^2)`.

Therefore exactly

`boxed{a_m=sigma R_(m0)/R_00}`.

So

`a -> R_sigma(a)`

is injective.

The fixed positive reference coordinate removes the global-projective phase
ambiguity and lets the full complex source vector—including its magnitude—be
recovered from a PSD trace-one operator.

## Combined with the adaptive clock

Take the raw source to be the v541 adapted moments

`a_m(L)`
` =sum_p w_p`
`   exp(i m Delta_L log p)`

with

`Delta_L B_L<2pi`.

Then:

1. v541: the complete moment vector determines the active log-frequency
   measure on the non-aliased band;
2. v547: the trace-one projector determines that raw moment vector exactly.

Hence the trace-one source representation itself is **faithful** to the
band-limited arithmetic forcing.

Any convex/Cesaro recursion of such response operators continues to satisfy the
v537 trace budget.

## Boundary

Averaging many source projectors into one final kernel can still lose
time/shell information, and no secular spectral domination is proved here.

The theorem closes the two representation-level information losses:
- v540 fixed-clock aliasing, once adaptive `Delta_L` is used;
- v546 shell-amplitude erasure.

**Verdict:** `HOMOGENEOUS_TRACE_ONE_SOURCE_IS_AMPLITUDE_FAITHFUL_PASS`.

The next question is dynamical: which recursive covariance of these faithful
states has the v543 Bessel-accessibility property?
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_HOMOGENEOUS_TRACE_ONE_SOURCE_V1",
        "embedding":"psi=(sigma,a)/sqrt(sigma^2+||a||^2)",
        "properties":["PSD","rank one","trace one","injective"],
        "decoder":"a_m=sigma R_m0/R_00",
        "with_v541":"faithful active-band arithmetic representation",
        "remaining":"recursive covariance -> secular Bessel/accessibility bridge"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--sigma",type=float,default=1.0)
    ap.add_argument("--prefix",default="rot_rh_homogeneous_trace_one_source_v547")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    if args.sigma<=0:raise ValueError("sigma>0")
    t0=time.perf_counter()
    with tqdm(total=1,desc="v547 encode",unit="step") as bar:
        chk=encode_decode(args.sigma);bar.update(1)
    ok=(abs(chk["trace_real"]-1)<1e-12 and
        chk["min_eigenvalue"]>-1e-12 and chk["decode_error"]<1e-12)
    verdict="HOMOGENEOUS_TRACE_ONE_SOURCE_IS_AMPLITUDE_FAITHFUL_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"demo":chk,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print(chk)
    print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
