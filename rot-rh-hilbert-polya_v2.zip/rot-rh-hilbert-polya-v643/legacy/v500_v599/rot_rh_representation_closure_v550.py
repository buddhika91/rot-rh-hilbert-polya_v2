#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v550-representation-closure"
THEOREM=r"""# ROT-RH v550 — representation layer closure / accessibility is sole ROT bridge

The recent attack separates three logically distinct layers.

## 1. Off-critical contradiction

v527-v530 give an exact Gaussian contour-residue reduction:

`off-critical zero => fixed-energy secular occupancy exp(cL^2)`.

## 2. Arithmetic-to-observer representation

The original v86-v88 source cannot be used unchanged:

* v540: fixed integer winding aliases log frequency modulo `2pi`;
* v546: per-shell normalization erases radial arithmetic magnitude;
* v89 historically falsified the unchanged covariance/Fredholm realization.

The redesigned source removes these representation defects.

For `B_L=C L^2`, use a shrinking adaptive clock
`Delta_L=L^(-r)/B_L`. v549 proves that the continuous Gaussian transform on
each fixed energy window is reconstructed from only `O(L^(2+r))` integer
moments with exponentially small error and `exp(o(L^2))` conditioning.

v547 embeds each raw finite moment vector as
`psi=(sigma_L,a)/sqrt(sigma_L^2+||a||^2)`.
Its projector is PSD, trace one and injective because
`a_m=sigma_L Q_m0/Q_00`.

If subsequent ROT responses are PSD trace-one states under the Cesaro law,
v537/v544 give `Tr K_L=1` exactly.

## 3. Sole remaining bridge

For each fixed energy window, prove a response family with Bessel constant
`B_E(L)` and mean accessibility `a_E(L)` satisfying

`log[B_E(L)/a_E(L)]=o(L^2)`.

Then v543 gives `N_L(E)<=exp(o(L^2))`, contradicting v530 under any
off-critical zero.

Thus the remaining ROT-specific theorem is:

`prove subexponentially conditioned observer spectralization/accessibility for
the faithfully encoded arithmetic states`.

**Verdict:** `FINITE_FAITHFUL_REPRESENTATION_CLOSED_ACCESSIBILITY_REMAINS_PASS`.

This is not an RH proof.
"""
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--prefix",default="rot_rh_representation_closure_v550");ap.add_argument("--strict",action="store_true");args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v550 ledger",unit="step") as bar: bar.update(1)
    prefix=Path(args.prefix).resolve()
    (Path(str(prefix)+"_THEOREM.md")).write_text(THEOREM,encoding="utf-8")
    (Path(str(prefix)+"_SUMMARY.json")).write_text(json.dumps({"version":VERSION,"verdict":"FINITE_FAITHFUL_REPRESENTATION_CLOSED_ACCESSIBILITY_REMAINS_PASS","runtime_seconds":time.perf_counter()-t0},indent=2),encoding="utf-8")
    (Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")).write_text(json.dumps({"schema":"ROT_RH_REPRESENTATION_CLOSURE_V1","remaining":"v543 accessibility-frame inequality","scientific_status":"OPEN"},indent=2),encoding="utf-8")
    print("verdict: FINITE_FAITHFUL_REPRESENTATION_CLOSED_ACCESSIBILITY_REMAINS_PASS")
if __name__=="__main__":main()
