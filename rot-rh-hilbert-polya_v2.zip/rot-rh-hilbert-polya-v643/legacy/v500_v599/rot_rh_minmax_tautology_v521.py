#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v521 — ROOT-DIAGONAL BOUNDED-PERTURBATION / MIN-MAX TAUTOLOGY AUDIT
=========================================================================

Canonical current operator:
  H_L e_k = E_k(L)e_k.

Free comparison:
  H_0 e_k = A_k e_k.

Then in the same basis
  V_L:=H_L-H_0
is diagonal with
  V_L e_k=(E_k(L)-A_k)e_k,

so exactly
  ||V_L|| = sup_k |E_k(L)-A_k|.

Thus "prove H_L-H_0 uniformly bounded and use min-max" is literally the v235
uniform displacement theorem, not an independent route.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v521-minmax-tautology"

def finite_demo():
    E=[1.2,2.1,3.05,4.2]
    A=[1.0,2.0,3.0,4.0]
    disp=[e-a for e,a in zip(E,A)]
    norm=max(abs(x) for x in disp)
    return {"displacements":disp,"diagonal_operator_norm":norm,
            "sup_displacement":max(abs(x) for x in disp),
            "pass":norm==max(abs(x) for x in disp)}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v521 — root-diagonal bounded-perturbation / min-max tautology audit

The current canonical cutoff operator is defined in the common ordered basis by

`H_L e_k=E_k(L)e_k`.

The free Archimedean comparison operator is

`H_0e_k=A_ke_k`.

Therefore

`V_L:=H_L-H_0`

is already diagonal:

`V_Le_k=[E_k(L)-A_k]e_k`.

For a diagonal self-adjoint operator,

`||V_L||`
` =sup_k|E_k(L)-A_k|`.

Hence

`sup_L||H_L-H_0||<infinity`

is **exactly identical** to the v235 target

`sup_(L,k)|E_k(L)-A_k|<infinity`.

Applying min-max after assuming this norm bound merely returns the hypothesis.

The v82/v83 atomic Herglotz completion does not remove this issue: its
self-adjoint operator is still the diagonal operator on the selected arithmetic
roots; the additional data are the cyclic weights/residues.

Therefore a non-tautological min-max route requires a new independently defined
common-basis operator

`H_L^ind=H_0+B_L`

constructed from prime/ROT data **before** solving the secular roots, together
with a proof that its spectrum is the selected ROT-RH support.

**Verdict:** `ROOT_DIAGONAL_BOUNDED_PERTURBATION_MINMAX_ROUTE_TAUTOLOGICAL_NOGO_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_MINMAX_TAUTOLOGY_V1",
        "identity":"||H_L-H0||=sup_k|E_k(L)-A_k|",
        "classification":"same theorem as v235",
        "required_escape":"independent common-basis prime/ROT operator before root solving"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_minmax_tautology_v521")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v521 identity",unit="step") as bar:
        chk=finite_demo();bar.update(1)
    verdict="ROOT_DIAGONAL_BOUNDED_PERTURBATION_MINMAX_ROUTE_TAUTOLOGICAL_NOGO_PASS"
    payload={"version":VERSION,"verdict":verdict,"finite_demo":chk,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
if __name__=="__main__":main()
