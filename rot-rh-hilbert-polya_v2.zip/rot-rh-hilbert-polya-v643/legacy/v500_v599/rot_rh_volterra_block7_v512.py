#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v512 — EXACT VOLTERRA ITERATES / BLOCK-7 CASCADE COLLAPSE
================================================================

With v511, R is conjugate to

  Jg(z)=int_0^z g(eta)deta.

Then for r>=1,

  J^r g(z)
   = 1/(r-1)! int_0^z (z-eta)^(r-1) g(eta)deta.

The one-step generating function is

  sum_{r>=0} q^r J^r g
   = g(z) + q int_0^z exp[q(z-eta)] g(eta)deta.

Now let f0 be the gauged F0 forcing,
  g7=(I+J+...+J^6)f0,
  T=J^7.

Then exactly

  sum_{r=0}^{K-1} T^r g7
   = sum_{n=0}^{7K-1} J^n f0.

Thus the G7/R7 packet architecture is exactly a seven-at-a-time regrouping of
one universal Volterra Neumann/Taylor expansion.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v512-volterra-iterates-block7"

def polynomial_check(K):
    # Check exponents selected by the block identity.
    left=[]
    for r in range(K):
        left += [7*r+j for j in range(7)]
    right=list(range(7*K))
    return {"K":K,"left":left,"right":right,"pass":left==right}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v512 — exact Volterra iterates / block-7 cascade collapse

By v511, after the exact scalar gauge and the coordinate

`z=-log zeta(s)`,

the ROT-RH transfer is

`Jg(z)=int_0^z g(eta)deta`.

For every integer `r>=1`,

`J^r g(z)
 =1/(r-1)!
  int_0^z (z-eta)^(r-1)g(eta)deta`.

This is the standard simplex/Volterra identity.

Consequently the generating function is exact:

`sum_(r>=0) q^r J^r g(z)`

`=g(z)
 +q int_0^z exp[q(z-eta)]g(eta)deta`.

Equivalently, before the `z` change of variable,

`sum_(r>=0)q^r R^r A(s)`

has the explicit log-zeta kernel

`U^(-1){`
` U A(s)`
` +q zeta(s)^(-q)`
`   int_s^infty [zeta'(w)/zeta(w)]`
`   zeta(w)^q U A(w)dw`
`}`,

on a chosen zero-free branch.

## Exact collapse of the seven-layer packets

Let

`f0=U F0`

and

`g7=(I+J+...+J^6)f0`.

Since

`T=R^7`

becomes

`J^7`,

we have for every integer `K>=1`

`sum_(r=0)^(K-1) T^r g7`

`=sum_(r=0)^(K-1)
  J^(7r)(I+J+...+J^6)f0`

`=sum_(n=0)^(7K-1)J^n f0`.

So the apparent `G7/R7` mesoscopic dynamics is **not a new independent
dynamical system**. It is exactly the ordinary Volterra Neumann series grouped
seven terms at a time.

At infinite depth, where the resolvent exists,

`sum_(n>=0)J^n=(I-J)^(-1)`,

which is the gauged fixed point.

**Verdict:** `EXACT_BLOCK7_CASCADE_IS_REGROUPED_VOLTERRA_SERIES_PASS`.

This substantially simplifies v510: the remaining `Theta(L^2)` packet problem
is a truncation problem for one scalar Volterra/Taylor series.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_BLOCK7_VOLterra_V1",
        "closed":{
            "iterate":"J^r g = 1/(r-1)! int_0^z (z-eta)^(r-1)g(eta)deta",
            "resolvent":"sum q^r J^r g = g+q int exp(q(z-eta))g",
            "block_identity":"sum_{r<K}J^(7r)(I+...+J^6)=sum_{n<7K}J^n"
        },
        "next":"analyze zero singularity and required truncation depth"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--K",type=int,default=9)
    ap.add_argument("--prefix",default="rot_rh_volterra_block7_v512")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v512 block identity",unit="step") as bar:
        chk=polynomial_check(args.K);bar.update(1)
    ok=bool(chk["pass"])
    verdict="EXACT_BLOCK7_CASCADE_IS_REGROUPED_VOLTERRA_SERIES_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"check":chk,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
