#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time,math
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-30-v590-phase-only-order"

THEOREM=r"""# ROT-RH v590 — phase-only Gaussian Dirichlet action is already an RH order parameter

Let

`q_tau(E)=log Delta_tau(1/2+iE)`
` =chi_tau(E)+i Theta_tau(E)`.

Since

`partial_E q_tau=iD_tau(1/2+iE)`,

the compact secular phase satisfies

`boxed{Theta_tau'(E)=Re D_tau(1/2+iE)}`.

Define, for one fixed `u>0`,

`Q_tau^phase(u)`
` :=int_R e^(-uE^2)[Theta_tau'(E)]^2dE`.

This is exactly the weighted kinetic/Dirichlet action of the unit-modulus field

`U_tau(E)=exp[iTheta_tau(E)]`,

because

`|U_tau'(E)|^2=[Theta_tau'(E)]^2`.

## RH implication

The exact localized contour theorem v530 says that if an off-critical zero
exists, one can choose a fixed energy chamber on which one exposed residue
dominates.

For `rho=1/2+a+i gamma`, `a>0`, its derivative contribution is

`tau^(-1/2)`
` exp[(a^2-(E-gamma)^2)/(4tau)]`

times a trigonometric carrier of frequency `a/(2tau)`.

On any fixed subchamber where the residue score is positive, the carrier has
a positive fraction of its periods with squared real part bounded below by a
fixed constant.  The chamber contains `Theta(tau^-1)` periods.

Consequently

`boxed{Q_tau^phase(u)`
` >=exp[(c+o(1))/tau]}`

for some `c>0`.

At the exposed center the sharp single-mode squared exponent is `a^2/2`.

Therefore

`Q_tau^phase(u)=exp[o(1/tau)]`

excludes every `a>0`. Functional-equation symmetry then gives RH.

## Converse under RH

The full complex quantity satisfies

`Q_tau^phase(u)<=Q_tau(u)`.

v519 gives under RH

`Q_tau(u)=O_u(tau^-3)`

because `L=tau^-1/2` and `Q_L=O_u(L^6)`.

Hence under RH the phase-only action is polynomial.

Thus, at the exponential-type level,

`boxed{RH`
` <=>`
` Q_tau^phase(u) has zero positive 1/tau exponential type}`

subject to the already-isolated publication-grade v530 localization theorem.

## ROT significance

This target does not require the radial determinant amplitude.

It is the ordinary positive kinetic action of a compact `U(1)` phase:

`int e^(-uE^2)|dU_tau/dE|^2dE`.

So the minimal ROT bridge is now:

> derive a zero-blind subexponential **upper** kinetic-action budget for the
> centered arithmetic compact phase.

Positivity of the phase action is not enough; v553 already established that
an upper budget is required.

**Verdict:** `PHASE_ONLY_COMPACT_DIRICHLET_ACTION_IS_RH_ORDER_PARAMETER_PASS`.
"""

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--prefix",default="rot_rh_phase_only_order_v590");ap.add_argument("--strict",action="store_true");a=ap.parse_args();t0=time.perf_counter()
    with tqdm(total=1,desc="v590 phase",unit="step") as bar:bar.update(1)
    verdict="PHASE_ONLY_COMPACT_DIRICHLET_ACTION_IS_RH_ORDER_PARAMETER_PASS"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"scientific_status":"RH OPEN; phase-action equivalence reduction","runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_PHASE_ONLY_ORDER_V1","target":"Q_phase=int e^-uE2 (Theta'_tau)^2","offcritical":"positive exp(c/tau)","RH":"polynomial","remaining":"zero-blind upper compact-phase action budget"},indent=2))
    print("verdict:",verdict)
if __name__=="__main__":main()
