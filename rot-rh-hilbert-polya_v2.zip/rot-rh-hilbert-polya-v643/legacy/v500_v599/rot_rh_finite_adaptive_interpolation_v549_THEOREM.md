# ROT-RH v549 — finite adaptive-clock fractional-moment interpolation

Fix an active log-frequency band

`0<=y<=B_L`,
`B_L=C L^2`.

Choose a shrinking compact clock arc

`alpha_L=L^(-r)`,
`r>0`,

and

`Delta_L=alpha_L/B_L`.

Then

`0<=Delta_L y<=alpha_L<1`

for all sufficiently large `L`.

Fix a bounded secular energy window `0<=E<=E_*` and write

`E/Delta_L=m+delta`,
`m=floor(E/Delta_L)`,
`0<=delta<1`.

Set

`z=exp(iDelta_L y)`.

Then exactly

`exp(iEy)=z^m z^delta`.

Because the entire active arc lies inside the disk

`|z-1|<=alpha_L<1`,

use the principal binomial expansion

`z^delta`
` =sum_(j=0)^infty binom(delta,j)(z-1)^j`.

For `0<=delta<=1`,

`|binom(delta,j)|<=1`

for all `j`. Therefore after truncation at `q`,

`|R_q(z)|`
` <=sum_(j=q+1)^infty |z-1|^j`
` <=alpha_L^(q+1)/(1-alpha_L)`.

Each polynomial

`(z-1)^j`

has coefficient `ell^1` norm exactly `2^j`. Hence the complete truncated
interpolant uses only the integer adapted moments

`m,m+1,...,m+q`

and its coefficient norm obeys

`||c_(E,L)||_1`
` <=sum_(j=0)^q2^j`
` <2^(q+1)`.

Now choose

`q_L=ceil[A L^2/log L]`

with fixed `A>0`.

Then

`log ||c_(E,L)||_1`
` <=A(log2)L^2/log L+O(1)`
` =o(L^2)`,

while

`log |R_q|`
` <=-A r L^2+o(L^2)`.

Also

`m<=E_*/Delta_L`
` =O(L^(2+r))`,

so the required winding dimension is only polynomial:

`d(L)=O(L^(2+r))`.

## Absolute Gaussian error

For the differentiated centered Gaussian arithmetic measure, elementary

`Lambda(n)<=log n`

and an integral comparison give the total-variation exponent

`sum_(n>=2)`
` (Lambda(n)+1)n^(-1/2)`
` exp[-(log n/L)^2]`

` <=exp[(1/16+o(1))L^2]`.

Indeed in `y=log n` the exponential part is

`exp[y/2-y^2/L^2]`

whose maximum is `L^2/16`.

Therefore the interpolation error after summing against the full centered
measure is

`<=exp[-(Ar-1/16+o(1))L^2]`.

Choose

`Ar>1/16+eta`

for any fixed `eta>0`. Then the reconstruction error is exponentially small:

`boxed{error<=exp[-(eta+o(1))L^2]}`,

while the interpolation conditioning remains

`exp[o(L^2)]`

and the moment dimension remains polynomial.

The Gaussian tail beyond `B_L=C L^2` is also exponentially negligible for any
fixed `C>1/2`, since its elementary absolute exponent is

`C/2-C^2<0`.

## Consequence

The continuous Gaussian secular prime transform on every fixed energy window
can be recovered, to exponentially better accuracy than required by v530,
from a **finite polynomial-size adaptive winding vector**, with only
subexponential coefficient conditioning.

Thus v541's infinite-moment injectivity can be upgraded to a quantitative
finite representation suitable for the v543 accessibility program.

**Verdict:** `FINITE_ADAPTIVE_CLOCK_EXPONENTIAL_RECONSTRUCTION_SUBEXP_CONDITION_PASS`.

This solves representation/interpolation. It does not supply the observer
accessibility lower bound.
