# ROT-RH v500 — one-heat-time Gaussian RH criterion

For the Gaussian-regulated ordered support define the ordinary spectral heat
trace

`h_L(u)=Tr exp(-u H_L^2)`
`      =sum_(k>=1) exp(-u E_k(L)^2)`,
`u>0`.

For any fixed finite `E_*>0`, every level below `E_*` contributes at least
`exp(-uE_*^2)`.  Therefore

`h_L(u)`
` >= N_L(E_*) exp(-uE_*^2)`,

where

`N_L(E_*)=#{k:E_k(L)<=E_*}`.

v497 shows that if a nontrivial zero with `beta>1/2` exists, there is a **fixed**
finite `E_*` such that

`N_L(E_*) -> infinity`.

Hence, under an off-critical zero,

`h_L(u)->infinity`

for **every fixed `u>0`**.

It follows that the extremely weak operator estimate

`sup_(L>=L0) h_L(u0)<infinity`

at just **one** heat time `u0>0` excludes every `beta>1/2` zero.  Functional
equation reflection then excludes `beta<1/2`, so all nontrivial zeros lie on the
critical line.

Therefore

`ONE FIXED-u GAUSSIAN HEAT-TRACE BOUND => RH`.

A fortiori, any of the following at one `u0>0` implies RH:

* `h_L(u0)` converges as `L->infinity`;
* `h_L(u0)` is Cauchy on a cofinal cutoff sequence;
* `sup_L h_L(u0)<infinity`.

This is strictly less than the v450 target of uniform convergence on a whole
compact heat tube.  It is also less than trace-norm convergence of `H_L^-2`.

The v447/v450 arithmetic clock branch already uses exactly the unweighted
spectral trace

`sum_k exp(-uE_k(L)^2)`.

Thus the next RH-bearing analytic theorem can be reduced to proving boundedness
or Cauchy behavior at **one preregistered positive heat time**, without Xi,
known zero ordinates, the full Stieltjes hierarchy, or the Fredholm identity.

**Verdict:** `ONE_HEAT_TIME_GAUSSIAN_BOUND_IMPLIES_RH_PASS`.

Scientific boundary: this is an implication theorem.  The one-time uniform
Gaussian heat bound itself remains open analytically.
