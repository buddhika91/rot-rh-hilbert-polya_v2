# ROT-RH v527 — exact Gaussian centered-Dirichlet contour / zero-residue ledger

Put

`r(n)=Lambda(n)-1`

and for `tau>0`

`D_tau(s)
 =sum_(n>=2)r(n)n^(-s)exp[-tau(log n)^2]`.

Because the log-Gaussian beats every power of `n`, this series converges
absolutely and locally uniformly for every complex `s`. Hence `D_tau` is entire.

For `Re(w)>1`, the ordinary centered Dirichlet series is

`D(w)
 =sum_(n>=2)r(n)n^(-w)
 =-zeta'(w)/zeta(w)-(zeta(w)-1)`.

This is exactly the centered identity already isolated in the ROT-RH
Dirichlet-series audit.

Fix `c>1`. For every complex `s`,

`D_tau(s)`
`=1/[i sqrt(4 pi tau)]`
` int_(c-i inf)^(c+i inf)`
` exp[(w-s)^2/(4tau)] D(w)dw`.

Indeed, termwise integration is justified on `Re(w)=c`, and for one monomial
`n^(-w)` the Gaussian Fourier integral is exactly

`1/[i sqrt(4 pi tau)]`
` int_(c-i inf)^(c+i inf)`
` exp[(w-s)^2/(4tau)] n^(-w)dw`

`=n^(-s)exp[-tau(log n)^2]`.

## Singularities of the centered continuation

At `w=1`,

`-zeta'/zeta`

has residue `+1`, while

`-(zeta-1)`

has residue `-1`. Therefore the pole at `1` cancels exactly in `D`.

If `rho` is a zero of zeta of multiplicity `m_rho`, then

`Res_(w=rho) D(w)=-m_rho`.

Now choose a vertical line `Re(w)=b`, `1/2<b<c`, which contains no zeta zero.
Shift the Gaussian contour from `c` to `b`. The horizontal pieces vanish
because of the Gaussian vertical factor. The residue theorem gives

`D_tau(s)`
`=I_(b,tau)(s)`
` -sqrt(pi/tau)`
`  sum_(rho: b<Re(rho)<c)`
`   m_rho exp[(rho-s)^2/(4tau)]`,

where

`I_(b,tau)(s)`
`=1/[i sqrt(4 pi tau)]`
` int_(b-i inf)^(b+i inf)`
` exp[(w-s)^2/(4tau)]D(w)dw`.

The zero sum converges absolutely in ordinate because its modulus contains

`exp[-(Im(rho)-Im(s))^2/(4tau)]`

times at most `exp[(Re(rho)-Re(s))^2/(4tau)]`, while the zeta zeros have only
polynomial-logarithmic counting density.

## Critical-line evaluation

Use the convention

`s=1/2+iE`.

For

`rho=1/2+a+i gamma`,
`a>0`,

the exact residue is

`-sqrt(pi/tau)m_rho`
` exp{[a+i(gamma-E)]^2/(4tau)}`.

Its modulus is exactly

`sqrt(pi/tau)m_rho`
` exp{[a^2-(gamma-E)^2]/(4tau)}`,

and its phase derivative is exactly

`partial_E arg = -a/(2tau)`.

Thus the Gaussian growth score

`a^2-(gamma-E)^2`

and the `L^2` carrier frequency (`tau=L^-2`) are **exact residue geometry**,
not saddle approximations.

**Verdict:** `EXACT_GAUSSIAN_CENTERED_DIRICHLET_ZERO_RESIDUE_LEDGER_PASS`.

This supplies the missing Gaussian prime/zero ledger for the differentiated
centered arithmetic phase. It does not assume RH.
