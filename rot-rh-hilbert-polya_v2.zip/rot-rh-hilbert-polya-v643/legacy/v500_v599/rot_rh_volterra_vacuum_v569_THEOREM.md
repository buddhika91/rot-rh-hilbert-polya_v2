# ROT-RH v569 — exact canonical Volterra vacuum orbit

Use the exact v511 conjugacy

`U R U^(-1)=J`,

where

`U[A]=mu A`,

`z=-log zeta(s)`,

and

`(Jg)(z)=int_0^z g(eta)deta`.

Choose the canonical smooth source

`A_0(s)=mu(s)^(-1)`.

This source is zero-blind: `mu` is built only from the deterministic smooth
channel `zeta-1`, and contains no zero ordinate input.

Then

`U A_0=1`.

Since

`J^m 1=z^m/m!`,

we obtain for every integer `m>=0`

`boxed{R^m A_0`
` =mu^(-1) z^m/m!`
` =mu^(-1)[-log zeta(s)]^m/m!}`.

Consequently, wherever the Volterra resolvent series is valid,

`sum_(m>=0) R^m A_0`
` =mu^(-1) e^z`
` =1/[mu(s) zeta(s)]`.

## Canonical weighted-shift representation

Introduce the formal Bargmann basis

`e_m(z)=z^m/sqrt(m!)`.

Then

`J e_m`
` =1/sqrt(m+1) e_(m+1)`.

Thus the preconditioned recursive transfer is, in its exact `z` coordinate, a
weighted unilateral shift with weights

`w_m=1/sqrt(m+1)`.

In particular:
- `J` is bounded with norm one in the canonical Fock norm;
- the weights tend to zero, so `J` is compact;
- `J^2` is Hilbert-Schmidt because
  `sum_m 1/[(m+1)(m+2)]<infinity`.

These are properties of the **universal Volterra recursion**, not of a fitted
zero spectrum.

## Zero interpretation

At a zeta zero `rho` of multiplicity `q`,

`z(s)=-q log(s-rho)+O(1)`,

so the zero is an infinite-distance end in the `z` coordinate.

Every fixed recursive depth is only polynomial in `z`; the singular
`1/zeta=e^z` appears only after the infinite Taylor/Volterra resummation.

Therefore the RH-sensitive question can be rephrased as a recursive-capacity
problem:

> can an off-critical physical chamber require occupation of an
> `Theta(L^2)`-depth portion of this Fock/Volterra ladder while the zero-blind
> ROT observer has only subexponential accessible novelty?

This does not answer that question, but it gives a canonical Hilbert geometry
for asking it.

**Verdict:** `PRECONDITIONED_ROT_TRANSFER_HAS_EXACT_FOCK_VOLterra_VACUUM_ORBIT_PASS`.
