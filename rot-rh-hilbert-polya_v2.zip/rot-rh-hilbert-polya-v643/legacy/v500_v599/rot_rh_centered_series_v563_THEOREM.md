# ROT-RH v563 — exact centered determinant series equals the secular arithmetic phase

On `Re(s)>1`,

`log zeta(s)`
` =sum_(n>=2) Lambda(n)/(log n) n^(-s)`.

Also

`log mu(s)`
` =int_s^infty(zeta(w)-1)dw`
` =sum_(n>=2) n^(-s)/(log n)`.

Therefore for the v559 centered determinant

`Delta(s)=mu(s)/zeta(s)`,

`boxed{log Delta(s)`
` =-sum_(n>=2)(Lambda(n)-1)/(log n)n^(-s)}`.

At

`s=1/2-iE`,

the imaginary part is

`Im log Delta`
` =-sum_(n>=2)(Lambda(n)-1)/(sqrt(n)log n) sin(Elog n)`.

So, up to the fixed Archimedean phase and sign/pi convention, this is exactly
the centered arithmetic secular phase itself—not merely its derivative.

For Gaussian regularization the same identity is entire:

`log Delta_tau(s)`
` =-sum_(n>=2)(Lambda(n)-1)/(log n)`
`   n^(-s)e^[-tau(log n)^2]`.

Thus the finite Gaussian secular phase is the boundary argument of one exact
zero-free centered determinant.

**Verdict:** `CENTERED_DETERMINANT_LOG_IS_EXACT_SECULAR_ARITHMETIC_PHASE_PASS`.
