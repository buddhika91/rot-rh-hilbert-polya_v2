#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v508 — RECURSIVE SELECTOR SWING-LOADING LEMMA
=====================================================

For the actual first-later-crossing selector:
 E1 = first selected F=1/2 crossing after the fixed lower floor B,
 E_{k+1}=first F=k+1/2 crossing after E_k.

If B<=a<b and
 F(a)<1/2,   F(b)>=K-1/2,
then E_k<=b for every 1<=k<=K.

Reason:
- continuity gives some 1/2 crossing in [a,b], so selected E1<=b;
- inductively, if E_j<=b and F(E_j)=j-1/2, then either E_j<=a or E_j>a.
  In either case F(E_j)=j-1/2 < j+1/2 <= K-1/2 <= F(b);
  continuity on [E_j,b] gives a later crossing of j+1/2, so E_{j+1}<=b.

For v497, an exposed Gaussian off-critical mode has alternating antinodes of
height A_L~exp(cL^2/4)/L. Pick one negative-to-positive half-wave inside the
fixed exposed interval. Background/remainder are o(A_L), hence eventually
F(a)<1/2 and F(b)>=c'A_L. Therefore N_L(b)>=c'A_L.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v508-selector-swing-loading"

def toy():
    # Only level geometry matters.
    H=50.0
    K=int(math.floor(H+.5))
    return {
        "F_a":-20.0,"F_b":H,"K":K,
        "loaded_levels":K,
        "condition":bool(-20.0<.5 and H>=K-.5)
    }

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v508 — recursive-selector swing-loading lemma

Use the **actual** ROT-RH selector from v503:

`E_1` is the first selected crossing of `F(E)=1/2` after the fixed lower search
floor `B`, and

`E_(k+1)=inf{E>E_k:F(E)=k+1/2}`.

Let

`B<=a<b`

and suppose

`F(a)<1/2`

and

`F(b)>=K-1/2`

for an integer `K>=1`.

Then

`E_k<=b`

for every `1<=k<=K`.

Indeed, continuity gives a `1/2` crossing between `a` and `b`, hence the first
selected `E_1` occurs no later than `b`. Inductively, if `E_j<=b`, then

`F(E_j)=j-1/2 < j+1/2 <= K-1/2 <= F(b)`.

Continuity on `[E_j,b]` gives a crossing of `j+1/2` after `E_j`; the first such
crossing is `E_(j+1)`, so `E_(j+1)<=b`.

Thus one upward secular swing loads an entire consecutive block of ordered
levels. No monotonicity, no-fold assumption, or root matching is required.

## Application to v497

On the exposed Gaussian off-critical interval, the dominant mode has

`A_L >= C L^-1 exp(cL^2/4)`

and phase frequency `Theta(L^2)`. Hence there are alternating antinodes inside
the same fixed interval. Since all other saddles and the static background are
`o(A_L)`, choose one negative antinode `a_L` followed by a positive antinode
`b_L`. Eventually

`F_L(a_L)<1/2`

and

`F_L(b_L)>=c' A_L`.

The swing-loading lemma gives

`N_L(b_L)>=floor(c'A_L+1/2)`.

Because `b_L` remains below the fixed right endpoint `E_*`,

`N_L(E_*) >= C' L^-1 exp(cL^2/4) -> infinity`.

Therefore v497's occupancy-explosion mechanism is compatible with the actual
recursive first-later-crossing selector.

**Verdict:** `EXACT_RECURSIVE_SELECTOR_SWING_LOADING_PASS`.

Publication precision still requires the uniform exposed-mode saddle/remainder
bounds from v497; the selector logic itself is now closed.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_SELECTOR_SWING_LOADING_V1",
        "closed":{
            "hypothesis":"F(a)<1/2 and F(b)>=K-1/2",
            "selector":"actual recursive first-later crossing",
            "conclusion":"E_k<=b for all k<=K",
            "v497_application":"one exposed Gaussian up-swing loads exp(cL^2/4)/L levels"
        },
        "remaining":"uniform exposed Gaussian saddle and remainder inequalities"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_selector_swing_loading_v508")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v508 selector",unit="step") as bar:
        chk=toy();bar.update(1)
    ok=bool(chk["condition"])
    verdict="EXACT_RECURSIVE_SELECTOR_SWING_LOADING_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"toy":chk,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
