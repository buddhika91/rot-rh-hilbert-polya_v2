# ROT-RH v579 — universal Volterra Fock resolvent is uniformly bounded

In the canonical Bargmann basis from v569,

`e_m(z)=z^m/sqrt(m!)`

and

`J e_m=1/sqrt(m+1)e_(m+1)`.

For `k>=0`,

`J^k e_m`
` =sqrt[m!/(m+k)!] e_(m+k)`.

Therefore the formal inverse

`T=(I-J)^(-1)=sum_(k>=0)J^k`

has matrix entries

`T_(n,m)`
` =sqrt(m!/n!)`

for `n>=m`, and zero otherwise.

## Schur bound

For a fixed column `m`,

`sum_(n>=m)|T_(n,m)|`
` =sum_(k>=0)sqrt[m!/(m+k)!]`.

Since

`(m+1)(m+2)...(m+k)>=k!`,

each term is at most `1/sqrt(k!)`. Hence

`sup_m column_sum`
` <=sum_(k>=0)1/sqrt(k!)`
` <4`.

For a fixed row `n`, write `k=n-m`. Then

`n!/(n-k)!`
` =k! binom(n,k)`
` >=k!`,

so again

`|T_(n,n-k)|<=1/sqrt(k!)`.

Thus

`sup_n row_sum<4`.

The Schur test gives

`boxed{||(I-J)^(-1)||_(F->F)<4}`.

In particular the Volterra Neumann series converges to a bounded operator on
the canonical Fock space even though `||J||=1`.

This also proves directly that `I-J` is boundedly invertible; no cutoff or
spectral-gap parameter is involved.

## Consequence

For the gauged Selberg fixed point

`B_X=(I-J)^(-1)f_0`,

`boxed{||B_X||_F<=4||f_0||_F}`

whenever the gauged forcing belongs to this Fock space.

So the universal recursive resummation cannot itself generate an
`exp(cL^2)` norm instability in this geometry.

Any RH-sensitive exponential growth must come from:
- the forcing norm;
- the gauge/composition map back to physical arithmetic variables;
- or the mismatch between the canonical Volterra Fock norm and the physical
  Gaussian covariance norm.

**Verdict:** `UNIVERSAL_VOLterra_FOCK_RESOLVENT_HAS_CUTOFF_INDEPENDENT_BOUND_PASS`.
