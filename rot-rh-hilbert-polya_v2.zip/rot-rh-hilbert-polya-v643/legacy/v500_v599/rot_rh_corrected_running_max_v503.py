#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v503 — CORRECTED FIRST-LATER-CROSSING / ANCHORED RUNNING-MAX THEOREM
===========================================================================

Corrects v501's overly strong normalization F_L(0)=0.

Actual ROT-RH selector:
  E_1 is the selected first positive crossing of F(E)=1/2;
  E_{k+1}=inf{E>E_k : F(E)=k+1/2}.

For E>=E1 define M_1(E)=max_{E1<=x<=E} F(x). Then exactly

  N(E):=#{k:E_k<=E}=floor(M_1(E)+1/2).

The proof is continuity + induction.
"""
from __future__ import annotations
import argparse, json, math, time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v503-corrected-running-max"

def recursive_selector(F, max_k=30):
    import numpy as np
    roots=[]
    for k in range(1,max_k+1):
        target=k-.5
        start=0 if not roots else roots[-1]+1
        found=None
        for i in range(start,len(F)-1):
            a=float(F[i]-target); b=float(F[i+1]-target)
            if a==0.0 or a*b<=0.0:
                found=int(i)
                break
        if found is None:
            break
        roots.append(found)
    return roots

def toy_check():
    import numpy as np
    x=np.linspace(0,20,200001)
    # Deliberately F(0) != 0 and strongly folded.
    F=1.3+0.45*x+3.0*np.sin(2.7*x)
    roots=recursive_selector(F,max_k=20)
    if not roots:
        return {"pass":False}
    e1_idx=int(roots[0])
    rows=[]
    ok=True
    for j0 in np.linspace(e1_idx,len(x)-1,20,dtype=int):
        j=int(j0)
        M=float(np.max(F[e1_idx:j+1]))
        n_formula=max(1,int(math.floor(M+.5)))
        n_actual=int(sum(int(r)<=j for r in roots))
        if n_formula<=len(roots):
            ok = bool(ok and n_formula==n_actual)
        rows.append({
            "x":float(x[j]),"M1":M,
            "N_formula":int(n_formula),
            "N_actual_available":int(n_actual)
        })
    return {"pass":bool(ok),"E1_proxy":float(x[e1_idx]),"rows":rows}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v503 — corrected first-later-crossing / anchored running maximum

The actual ordered-support rule is recursive:

`F_L(E_1)=1/2`,

and

`E_(k+1)=inf{E>E_k:F_L(E)=k+1/2}`.

For `E>=E_1` define

`M_(1,L)(E)=max_(E_1<=x<=E) F_L(x)`.

Then exactly

`N_L(E)=#{k:E_k(L)<=E}=floor(M_(1,L)(E)+1/2)`.

Proof:

* If `E_k<=E`, then `M_1(E)>=F(E_k)=k-1/2`.
* Conversely, if `M_1(E)>=K-1/2`, start from `F(E_1)=1/2`. If
  `E_j<=E`, then `F(E_j)=j-1/2<K-1/2` while some later point no later
  than `E` reaches `K-1/2`. Continuity therefore gives a crossing of
  `j+1/2` after `E_j` and before `E`; by definition the first such crossing is
  `E_(j+1)`. Induction yields `E_K<=E`.

Thus v501's running-max idea survives, but its auxiliary `F(0)=0` normalization
was not the actual ROT-RH selector and is superseded by this anchored theorem.

For

`h_L(u)=sum_k exp(-uE_k^2)`,

Stieltjes integration by parts gives

`h_L(u)=2u int_0^infty E exp(-uE^2)N_L(E)dE`.

Since `N_L(E)=0` before `E_1` and `N_L(E)<=M_1(E)+1/2` afterward,

`h_L(u)
 <=2u int_(E_1)^infty E exp(-uE^2)M_1(E)dE
   +(1/2)exp(-uE_1^2)`.

A running maximum beginning at any fixed lower floor `B<=E_1` is a sufficient
upper envelope, but not an exact counting identity.

**Verdict:** `EXACT_ANCHORED_FIRST_LATER_RUNNING_MAX_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_ANCHORED_RUNNING_MAX_V1",
        "closed":{
            "actual_selector":"recursive first-later crossing",
            "exact_count":"E>=E1: N_L(E)=floor(M_1,L(E)+1/2)",
            "heat_upper":"h<=2u int_E1^inf E e^-uE2 M_1(E)dE + .5 e^-uE1^2",
            "v501_F0_normalization":"SUPERSEDED"
        }
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_corrected_running_max_v503")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v503 selector",unit="step") as bar:
        chk=toy_check();bar.update(1)
    ok=bool(chk["pass"])
    verdict="EXACT_ANCHORED_FIRST_LATER_RUNNING_MAX_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,
             "runtime_seconds":float(time.perf_counter()-t0),
             "toy_check":chk,
             "proof_status":"Exact continuity/induction theorem; toy grid is diagnostic only."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
