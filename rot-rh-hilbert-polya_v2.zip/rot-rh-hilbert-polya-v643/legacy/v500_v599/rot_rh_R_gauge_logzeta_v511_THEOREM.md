# ROT-RH v511 — exact R gauge / log-zeta Volterra linearization

v383 gives, for `Re(s)>1`,

`R[A](s)
 =mu(s)^(-1)
  int_s^infty mu(w)[zeta'(w)/zeta(w)]A(w)dw`

with

`mu(s)=exp(int_s^infty(zeta(w)-1)dw)`.

Define the invertible scalar gauge

`U[A](s)=mu(s)A(s)`.

Then

`U R U^(-1) f`
` =int_s^infty [zeta'(w)/zeta(w)] f(w)dw`.

So

`R ~ V`,

where

`(Vf)(s)=int_s^infty L(w)f(w)dw`,
`L=zeta'/zeta`.

Now work on a simply connected zero-free branch domain and choose a branch of
`log zeta`. Put

`z(s)=-log zeta(s)`.

Then

`dz=-(zeta'/zeta)(s)ds=-L(s)ds`.

If the path terminates in the safe right half-plane where `zeta -> 1`, hence
`z -> 0`, then

`(Vf)(s)
 =int_s^infty L(w)f(w)dw
 =int_0^(z(s)) f(s(eta))deta`.

Writing

`g(eta)=f(s(eta))`

gives the universal Volterra primitive

`(Jg)(z)=int_0^z g(eta)deta`.

Therefore, on every zero-free branch domain,

`R`

is **exactly gauge-and-coordinate conjugate** to ordinary integration.

No positivity estimate, asymptotic approximation, zero ordinate, or numerical
zeta value is used in this identity.

## Consequence

The complicated-looking recursive `R` dynamics does not possess an unknown
local generator: its generator is exactly the logarithmic connection
`d log zeta`.

A zero is precisely an obstruction to extending the coordinate

`z=-log zeta`

through the corresponding horizontal/complex path.

**Verdict:** `EXACT_R_GAUGE_LOGZETA_VOLTERRA_LINEARIZATION_PASS`.

This is a structural reduction, not an RH proof.
