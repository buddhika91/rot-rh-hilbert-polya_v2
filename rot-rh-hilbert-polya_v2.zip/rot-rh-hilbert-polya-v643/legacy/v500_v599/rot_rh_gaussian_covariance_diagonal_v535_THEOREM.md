# ROT-RH v535 — Gaussian covariance diagonal is unconditionally polynomial

The exact v518 covariance is

`Q_L(u)`
`=sqrt(pi/u) sum_(m,n>=2)`
` a_m(L)a_n(L)`
` exp[-log^2(m/n)/(4u)]`

with

`a_n(L)`
` =(Lambda(n)-1)n^(-1/2)`
`  exp[-(log n/L)^2]`.

Split

`Q_L=Q_diag+Q_off`.

The diagonal is

`Q_diag`
`=sqrt(pi/u)`
` sum_(n>=2)`
` (Lambda(n)-1)^2/n`
` exp[-2(log n/L)^2]`.

Use the elementary inequalities

`(Lambda-1)^2<=2Lambda^2+2`

and

`Lambda(n)^2<=Lambda(n)log n`.

The smooth term satisfies

`sum n^(-1)exp[-2(log n/L)^2]=O(L)`

by the integral test in `y=log n`.

For the Mangoldt term, the classical Chebyshev estimate

`psi(x)=sum_(n<=x)Lambda(n)<=C x`

is sufficient. Stieltjes partial summation applied to

`(log x)/x * exp[-2(log x/L)^2]`

gives

`sum Lambda(n)log n/n`
`    exp[-2(log n/L)^2]`
` =O(L^2)`.

Therefore, for every fixed `u>0`,

`Q_diag(L,u)=O_u(L^2)`.

In particular

`L^-2 log^+ Q_diag ->0`

unconditionally.

## Consequence

The RH-strength part of v519 is **entirely off diagonal**:

`Q_off`
`=sqrt(pi/u) sum_(m!=n)`
` a_m a_n exp[-log^2(m/n)/(4u)]`.

So the current arithmetic theorem is no longer "bound the whole quadratic
form." The diagonal is already harmless.

The remaining object is a signed multiplicative two-point covariance of the
centered Mangoldt field.

This is exactly the component that the v523 Gaussian-Gram Selberg transfer must
control.

**Verdict:** `GAUSSIAN_COVARIANCE_DIAGONAL_POLYNOMIAL_UNCONDITIONAL_PASS`.
