# ROT-RH v589 — lens dissipation equals the high Taylor/Fock jet tail

Fix an initial heat time `tau_0>0` and Gaussian energy weight `u_0>0`.
Let

`T=tau_0+1/(4u_0)`.

For the centered arithmetic field `D_tau`, v580 gives exactly

`Q_(tau_0)(u_0)/sqrt(pi/u_0)`
` =sum_(m>=0)`
` |D_T^(m)(1/2)|^2/[m!(2u_0)^m]`.

Multiplying by `sqrt(u_0)`,

`boxed{`
` sqrt(u_0)Q_(tau_0)(u_0)`
` =sqrt(pi) sum_(m>=0)`
`  |D_T^(m)(1/2)|^2/[m!(2u_0)^m]`
`}`.

On the other hand v588 gives

`sqrt(u_0)Q_(tau_0)(u_0)`
` =sqrt(pi)|P_T(0)|^2`
`  +2 int_(tau_0)^T sqrt[u(tau)] A_tau(u(tau))dtau`,

where `P_tau=partial_E q_tau=iD_tau` and

`u(tau)=u_0/[1-4u_0(tau-tau_0)]`.

Since

`|P_T(0)|=|D_T(1/2)|`,

the `m=0` Taylor term is exactly the terminal point term.

Subtracting it yields the exact identity

`boxed{`
` 2 int_(tau_0)^T sqrt[u(tau)] A_tau(u(tau))dtau`
` =sqrt(pi) sum_(m>=1)`
` |D_T^(m)(1/2)|^2/[m!(2u_0)^m]`
`}`.

Thus the positive lens dissipation is precisely the nonconstant
Bargmann/Taylor jet mass of the safely smoothed centered field.

## Boundary mechanism

As `tau_0->0`,

`T->T_*=1/(4u_0)>0`.

Every fixed derivative `D_T^(m)(1/2)` has a finite limit.
Therefore any divergence or positive `1/tau_0` exponential type of `Q` must
escape to degrees `m->infinity`.

For the off-critical Gaussian saddle, log frequency is

`y_a~a/(2tau_0)`.

The coherent-state degree associated with a log frequency `y` has Poisson mean

`m~y^2/(2u_0)`.

Hence the off-critical packet occupies

`boxed{m_a~a^2/[8u_0 tau_0^2]}`,

that is

`m_a=Theta(L^4)`.

So the RH instability is a **high-jet escape phenomenon at quartic Fock
degree**, even though the original multiplicative recursion depth is only
quadratic in `L`.

**Verdict:** `GAUSSIAN_LENS_DISSIPATION_EQUALS_HIGH_TAYLOR_JET_MASS_PASS`.

The remaining theorem is a zero-blind bound on this high-degree jet tail.
