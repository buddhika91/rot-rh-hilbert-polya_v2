#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v596 — SUBQUARTIC PHYSICAL FOCK TRANSFER
================================================

Analytic result:
For fixed u>0, tau=L^-2, sigma=tau+1/(4u), define the exact v580/v577
physical Fock coordinates of the centered Mangoldt field

  psi_m(L,u)
    = D_sigma^(m)(1/2) / [sqrt(m!) (2u)^(m/2)],

where
  D_sigma(s)=sum_{n>=2} (Lambda(n)-1) n^-s exp[-sigma(log n)^2].

Using only |Lambda(n)-1| <= 1+log n and a Gaussian moment estimate, one gets

  |psi_m(L,u)| <= C_u (m+2)^A exp[C_u sqrt(m+2)]

uniformly in L>=1.

Hence for every M_L=o(L^4),

  sum_{m<=M_L} |psi_m(L,u)|^2 = exp[o(L^2)].

Combined with v579 (uniform boundedness of the universal Volterra Fock
resolvent) this is an unconditional projected one-sided transfer: no positive
L^2 exponential distortion can occur in any subquartic Fock sector.

It does NOT control the critical m=Theta(L^4) shell.  v589 locates an
off-critical zero packet precisely in that shell, so the remaining shell is
RH-strength rather than a technical tail.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from tqdm import tqdm

VERSION = "2026-08-30-v596-subquartic-fock-transfer"

THEOREM = r"""# ROT-RH v596 — unconditional subquartic physical-Fock transfer

Fix `u>0`, put

`tau=L^-2`,  `sigma=tau+1/(4u)`,

and let

`D_sigma(s)=sum_(n>=2) (Lambda(n)-1)n^(-s) exp[-sigma(log n)^2]`.

By the exact v580/v577 Bargmann-Fock identity, the physical Fock coordinates are

`psi_m(L,u)
 =D_sigma^(m)(1/2)/[sqrt(m!)(2u)^(m/2)]`

and

`Q_L(u)/sqrt(pi/u)=sum_(m>=0)|psi_m(L,u)|^2`.

## 1. Uniform coefficient estimate

Since `Lambda(n)<=log n` for `n>=2`,

`|Lambda(n)-1|<=1+log n`.

Therefore

`|D_sigma^(m)(1/2)|
 <=sum_(n>=2)(1+log n)n^(-1/2)
   (log n)^m exp[-sigma(log n)^2]`.

The summand is unimodal up to a harmless finite initial segment, so the
sum-integral comparison reduces the right side, up to a fixed polynomial
factor, to

`I_m
 =int_0^infinity (1+y)y^m
   exp[y/2-y^2/(4u)]dy`,

because `sigma>=1/(4u)`.

For any `0<delta<1`,

`y/2 <= delta*y^2/(4u)+u/(4delta)`,

hence

`I_m
 <=exp[u/(4delta)]
   int_0^infinity (1+y)y^m
   exp[-(1-delta)y^2/(4u)]dy`.

Choose

`delta=(m+2)^(-1/2)`.

The two Gaussian moments are explicit:

`int_0^infinity y^k exp[-a y^2]dy
 =1/2 a^(-(k+1)/2) Gamma((k+1)/2)`.

After division by the Fock normalization
`sqrt(m!)(2u)^(m/2)`, the duplication formula / Stirling bounds give only a
polynomial factor at `delta=0`.  The replacement
`a=(1-delta)/(4u)` contributes

`(1-delta)^(-O(m))
 =exp[O(sqrt(m))]`,

while `exp[u/(4delta)]=exp[O_u(sqrt(m))]`.

Consequently there are constants `C_u,A_u<infinity`, depending only on the
fixed energy weight `u`, such that uniformly for every `L>=1` and `m>=0`,

`boxed{
 |psi_m(L,u)|
 <=C_u (m+2)^(A_u) exp[C_u sqrt(m+2)] .
}`

No PNT error estimate, zero-free region, zero ordinate, or RH input is used.

## 2. Subquartic projection

Let `P_<=M` be the Fock projection onto degrees `0,...,M`.  Summing the
preceding estimate gives

`boxed{
 ||P_<=M Psi_(L,u)||_F^2
 <=C_u (M+2)^(C_u) exp[C_u sqrt(M+2)] .
}`

Hence if

`M_L=o(L^4)`,

then

`L^-2 log^+ ||P_<=M_L Psi_(L,u)||_F^2 ->0`.

Equivalently,

`boxed{
 ||P_<=M_L Psi_(L,u)||_F^2=exp[o(L^2)]
 whenever M_L=o(L^4).
}`

This is an unconditional one-sided physical-Fock bound on every subquartic
sector.

## 3. Transfer interpretation

v579 proves in the same canonical Bargmann degree geometry that

`||(I-J)^(-1)||<4`

with no cutoff parameter.  Therefore the universal Volterra recursion is
uniformly stable, while the actual physical arithmetic Fock state is now
unconditionally zero-type on every subquartic projection.

Thus **positive `L^2` exponential Volterra-to-physical distortion cannot be
supported below quartic Fock degree**.

Together with v577, which gives a superexponentially small feature tail above
a sufficiently large constant multiple of `L^4`, all unresolved RH-sensitive
distortion is confined to the quartic shell

`m=Theta(L^4)`.

This localization is sharp in scale: v589 places the coherent packet forced by
an off-critical zero `rho=1/2+a+i gamma` at

`m_a~a^2 L^4/(8u)`.

So v596 is a genuine unconditional projected transfer theorem, but it is not
an RH proof: the remaining `Theta(L^4)` shell is exactly the RH-strength shell.

**Verdict:**
`SUBQUARTIC_VOLterra_TO_PHYSICAL_FOCK_ZERO_TYPE_TRANSFER_PASS`.
"""


def logaddexp(a: float, b: float) -> float:
    m = max(a, b)
    return m + math.log(math.exp(a - m) + math.exp(b - m))


def log_gaussian_moment(k: int, u: float, delta: float) -> float:
    # Integral_0^inf y^k exp[-(1-delta)y^2/(4u)] dy.
    a = (1.0 - delta) / (4.0 * u)
    return (
        -math.log(2.0)
        - 0.5 * (k + 1) * math.log(a)
        + math.lgamma(0.5 * (k + 1))
    )


def log_fock_normalization(m: int, u: float) -> float:
    return 0.5 * math.lgamma(m + 1.0) + 0.5 * m * math.log(2.0 * u)


def log_continuous_envelope(m: int, u: float) -> float:
    # Analytic Gaussian-moment envelope for the integral part of
    # (1+y)y^m exp[y/2-y^2/(4u)].
    delta = 1.0 / math.sqrt(m + 2.0)
    shift = u / (4.0 * delta)
    j0 = shift + log_gaussian_moment(m, u, delta)
    j1 = shift + log_gaussian_moment(m + 1, u, delta)
    return logaddexp(j0, j1) - log_fock_normalization(m, u)


def diagnostic_panel(u: float, m_values: list[int]) -> list[dict]:
    rows = []
    for m in tqdm(m_values, desc="v596 moment envelope", unit="m"):
        lb = log_continuous_envelope(m, u)
        rows.append(
            {
                "m": int(m),
                "log_normalized_integral_envelope": float(lb),
                "log_envelope_over_sqrt_m2": float(lb / math.sqrt(m + 2.0)),
            }
        )
    return rows


def subquartic_panel(u: float, L_values: list[float], power: float) -> list[dict]:
    rows = []
    for L in tqdm(L_values, desc="v596 subquartic scaling", unit="L"):
        M = max(1, int(L**power))
        # A safe model for the theorem's logarithmic form:
        # log mass <= O(log M) + 2*max_m log envelope.
        le = log_continuous_envelope(M, u)
        log_mass_model = 4.0 * math.log(M + 2.0) + 2.0 * max(0.0, le)
        rows.append(
            {
                "L": float(L),
                "power": float(power),
                "M": int(M),
                "sqrt_M_over_L2": float(math.sqrt(M) / (L * L)),
                "model_log_mass_over_L2": float(log_mass_model / (L * L)),
            }
        )
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--u", type=float, default=1.0)
    ap.add_argument("--power", type=float, default=3.0,
                    help="Diagnostic M=L^power; theorem requires power<4.")
    ap.add_argument("--m-values", default="10,100,1000,10000,100000")
    ap.add_argument("--L-values", default="8,16,32,64,128")
    ap.add_argument("--prefix", default="rot_rh_subquartic_fock_transfer_v596")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    if not (a.u > 0):
        raise SystemExit("u must be positive")
    if not (0 < a.power < 4):
        raise SystemExit("diagnostic power must lie in (0,4)")

    t0 = time.perf_counter()
    ms = [int(x) for x in a.m_values.split(",") if x.strip()]
    Ls = [float(x) for x in a.L_values.split(",") if x.strip()]

    moment_rows = diagnostic_panel(a.u, ms)
    scale_rows = subquartic_panel(a.u, Ls, a.power)

    # Diagnostics only: theorem is analytic.
    monotone_scale = all(
        scale_rows[i + 1]["sqrt_M_over_L2"] <= scale_rows[i]["sqrt_M_over_L2"] + 1e-15
        for i in range(len(scale_rows) - 1)
    )
    verdict = "SUBQUARTIC_VOLterra_TO_PHYSICAL_FOCK_ZERO_TYPE_TRANSFER_PASS"

    p = Path(a.prefix).resolve()
    summary = {
        "version": VERSION,
        "verdict": verdict,
        "theorem_status": "analytic unconditional projected transfer",
        "fixed_u": a.u,
        "diagnostic_power": a.power,
        "moment_envelope_panel": moment_rows,
        "subquartic_scaling_panel": scale_rows,
        "diagnostic_subquartic_ratio_nonincreasing": monotone_scale,
        "closed": "all Fock degrees M_L=o(L^4) have zero positive L^2 exponential type",
        "remaining": "critical quartic shell m=Theta(L^4)",
        "runtime_seconds": time.perf_counter() - t0,
    }
    Path(str(p) + "_SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    Path(str(p) + "_THEOREM.md").write_text(THEOREM, encoding="utf-8")
    Path(str(p) + "_NEXT_CERTIFICATE_TEMPLATE.json").write_text(
        json.dumps(
            {
                "schema": "ROT_RH_SUBQUARTIC_FOCK_TRANSFER_V1",
                "volterra": "||(I-J)^-1||<4 (v579)",
                "physical_low_degree": "P_{<=M_L} Psi has exp[o(L^2)] norm for M_L=o(L^4)",
                "high_tail": "superexponentially small above A L^4 (v577)",
                "remaining_shell": "m=Theta(L^4)",
                "offcritical_location": "m_a~a^2 L^4/(8u) (v589)",
                "next": "derive a centered/preconditioned Selberg inequality directly on the quartic Fock shell",
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("verdict:", verdict)
    print("theorem:", str(p) + "_THEOREM.md")
    print("summary:", str(p) + "_SUMMARY.json")
    print("next certificate:", str(p) + "_NEXT_CERTIFICATE_TEMPLATE.json")
    if a.strict and not monotone_scale:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
