# ROT-RH v565 — exact dynamic-beta identity inside the Gaussian Wick interaction

Set

`tau=L^-2`.

Take an input logarithmic location `y=log d` and a multiplicative quotient
`q`, with `h=log q`.

The one-particle Gaussian ratio is exactly

`exp[-tau(y+h)^2]/exp[-tau y^2]`
` =exp[-2tau yh] exp[-tau h^2]`.

Define the local Gaussian beta

`beta_L(d):=2tau log d=2log d/L^2`.

Then

`boxed{exp[-tau(log(qd))^2]/exp[-tau(log d)^2]`
` =q^(-beta_L(d)) exp[-(log q/L)^2]}`.

After including the critical factor `(qd)^(-1/2)/d^(-1/2)=q^-1/2`,

`boxed{w_L(qd)/w_L(d)`
` =q^(-1/2-beta_L(d))`
`  exp[-(log q/L)^2]}`,

where

`w_L(n)=n^-1/2 exp[-(log n/L)^2]`.

This is precisely the beta-conjugated prime-power factor used in v531, with
an additional favorable Gaussian quotient damping.

At the saddle location associated with an off-critical horizontal displacement
`a>0`,

`log d ~= aL^2/2`,

so

`beta_L(d) ~= a`.

Hence the same parameter `a` that measures horizontal displacement of a
hypothetical zero is the exact local damping exponent seen by the
Gaussian-regulated Selberg transfer at that saddle.

**Verdict:** `OFFCRITICAL_HORIZONTAL_DISPLACEMENT_EQUALS_LOCAL_GAUSSIAN_BETA_PASS`.

This identity strengthens the motivation for attacking v523 directly in its
Gaussian geometry.  It does not by itself control cross-quotient coherence.
