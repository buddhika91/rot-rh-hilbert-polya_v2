# ROT-RH v528 — exact residue-dominance / off-critical swing explosion

This replaces the steepest-descent part of v497 by the exact v527 contour
identity.

Assume that a nontrivial zero

`rho_0=1/2+a_0+i gamma_0`,
`a_0>0`

exists.

Choose

`0<eta<a_0`

and a zero-free vertical contour

`b=1/2+eta`.

For the differentiated centered Gaussian transform, v527 gives at

`s=1/2+iE`

an exact decomposition

`D_tau(E)=I_(b,tau)(E)+Z_(b,tau)(E)`,

where

`Z_(b,tau)(E)`
`=-sqrt(pi/tau)`
` sum_(rho: Re rho>b)`
` m_rho exp{[a_rho+i(gamma_rho-E)]^2/(4tau)}`.

## Shifted-line exponential type

On a fixed compact energy interval, the Gaussian kernel on `Re(w)=b` contributes
the common factor

`exp[eta^2/(4tau)]`.

The remaining vertical Gaussian localizes `Im(w)` to an `O(sqrt(tau))`
neighborhood of `E`; standard finite-order growth of zeta and its logarithmic
derivative contributes only `exp[o(1/tau)]`.

Hence

`I_(b,tau)(E)
 =exp[(eta^2/4+o(1))/tau]`

uniformly on a fixed compact interval, away from the chosen contour itself
passing through a zero.

## Exact finite score envelope

Each residue has real score

`S_rho(E)=a_rho^2-(gamma_rho-E)^2`.

For fixed compact `E`, the score tends to `-infinity` with `|gamma_rho|`.
Thus only finitely many residues can compete for the maximum.

Since

`S_j(E)-S_k(E)`

is affine in `E`, non-identical score ties are isolated. Because

`S_(rho_0)(gamma_0)=a_0^2>eta^2`,

there exists a compact strict-exposure chamber `J` and one winning residue `*`
such that

`S_*(E)>=c>eta^2`

and

`S_*(E)-sup_(rho!=*)S_rho(E)>=g>0`

throughout `J`.

Therefore the exact winning derivative has amplitude

`A'_tau(E)
 >=C tau^(-1/2) exp[c/(4tau)]`

while every other residue and the shifted-line remainder are exponentially
smaller.

Its phase frequency is exactly

`omega_tau=a_*/(2tau)`.

Choose a positive half-wave contained in `J`. Integrating the derivative over
a fixed fraction of that half-wave gives a secular rise

`Delta F_tau`
` >=C [tau^(-1/2)/omega_tau] exp[c/(4tau)]`

` =C sqrt(tau) exp[c/(4tau)]`.

With

`tau=L^(-2)`,

`Delta F_L`
` >=C L^(-1) exp[cL^2/4]`.

The free Archimedean contribution is only algebraic on the fixed energy
interval and cannot alter this exponential swing.

By the exact recursive-selector swing-loading lemma v508, one fixed bounded
energy endpoint `E_*` therefore satisfies

`N_L(E_*)`
` >=C L^(-1)exp[cL^2/4]`
` ->infinity`.

So:

`OFF-CRITICAL ZERO`
` => FIXED-ENERGY OCCUPANCY EXPLOSION`

by an **exact Gaussian residue argument**, with no complex saddle expansion.

**Verdict:** `EXACT_GAUSSIAN_RESIDUE_OFFCRITICAL_OCCUPANCY_EXPLOSION_PASS`.

Publication precision now reduces to routine contour-growth statements for the
shifted line; the former v497 uniform saddle/remainder obligation is removed.
