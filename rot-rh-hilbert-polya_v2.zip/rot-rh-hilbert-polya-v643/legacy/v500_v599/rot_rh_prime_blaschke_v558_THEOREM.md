# ROT-RH v558 — exact prime Euler factor as relative Blaschke scattering

Fix a prime `p`, put
`r=p^(-1/2)` and `theta=E log p`.

Define
`S_p(E)`
` =(1-r e^(-i theta))/(1-r e^(i theta))`.

For real `E`, `|S_p(E)|=1`.

Equivalently, with the disk Blaschke factor
`b_r(z)=(z-r)/(1-rz)`,
`S_p(E)=b_r(e^(i theta))/e^(i theta)`.
So it is exactly a Blaschke channel relative to the free one-step winding.

Expanding the logarithm,
`log S_p(E)`
` =2i sum_(m>=1) r^m sin(m theta)/m`.

Therefore
`boxed{(1/2)arg S_p(E)`
` =sum_(m>=1) p^(-m/2) sin(mElogp)/m}`
with the continuous phase convention at `E=0`.

But for `n=p^m`,
`Lambda(n)/log n=1/m`.
Hence the right side is exactly the full prime-power contribution of `p` to
the unregularized arithmetic secular phase.

Differentiating,
`(1/2)d_E arg S_p`
` =sum_(m>=1)(log p)p^(-m/2)cos(mElogp)`.

Also
`d_theta arg S_p=P_r(theta)-1`,
where
`P_r=(1-r^2)/(1-2r cos theta+r^2)`
is the Poisson kernel.

Thus each prime-power channel is:
- a passive Blaschke phase;
- minus the free winding density `1`;
- with zero net relative winding over one prime period.

This explains the negative-delay obstruction found in v82: the arithmetic
channel is a **relative** scattering phase, not a single positive-delay inner
phase.

**Verdict:** `PRIME_POWER_SECULAR_PHASE_IS_EXACT_RELATIVE_BLASCHKE_SCATTERING_PASS`.
