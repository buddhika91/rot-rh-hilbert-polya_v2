#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v509 — GAUSSIAN R7 ADIABATIC DYNAMIC-BETA FLOW REDUCTION
===============================================================

Let T=R^7, support dilation Q=128, Gaussian b_L(n)=exp[-(log n/L)^2].

At packet depth r the support floor is s_r=2 Q^r. Its local Gaussian power
exponent is
  beta_r(L)=2 log(s_r)/L^2
           =2log2/L^2 + r*(2logQ/L^2).

Thus one T-packet changes beta by the exact small step
  Delta beta = 2 log Q/L^2.

For r=Theta(L^2), packet depth becomes a continuum beta-flow.

Suppose a signed phase-preserving packet theorem supplies local gains
  ||T u||_{beta+Dbeta} <= q(beta,E,Dbeta)||u||_beta
with
  log q(beta,E,Dbeta) <= -kappa(beta,E) Dbeta + o(Dbeta)
uniformly on compact E, beta in [beta0,beta1], and
  integral kappa(beta,E) dbeta > 0.
Then the product over O(L^2) packets is bounded by
  exp[- integral kappa dbeta + o(1)]
in scale-covariant norm.

For Gaussian zero type one needs a stronger subexponential-in-L^2 control:
the cumulative positive Lyapunov cost along beta in [0,1/2) must be o(L^2), or
negative after combining Gaussian weight.

This script records the exact beta mesh and saddle packet index
  r_a(L) ~ a L^2/(2 log 128).
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v509-adiabatic-beta-flow"
Q=128.0

def panel(a):
    rows=[]
    for L in (20.,40.,80.,160.):
        db=2*math.log(Q)/(L*L)
        r=a/db
        beta_at=2*math.log(2)/(L*L)+math.floor(r)*db
        rows.append({"L":L,"Delta_beta":db,
                     "saddle_packet_real":r,
                     "saddle_packet_floor":int(math.floor(r)),
                     "beta_at_floor":beta_at,
                     "packet_fraction_of_L2":r/(L*L)})
    return rows

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v509 — Gaussian R7 adiabatic dynamic-beta flow reduction

Let

`T=R^7`

with support dilation

`Q=128`.

After `r` packets the support floor is

`s_r=2Q^r`.

For the Gaussian

`b_L(n)=exp[-(log n/L)^2]`

the local power exponent from v505 is

`beta_eff(n,L)=2log n/L^2`.

At the packet floor,

`beta_r(L)
 =2log(s_r)/L^2
 =2log2/L^2 + r Delta_beta(L)`

with the **exact packet step**

`Delta_beta(L)=2log128/L^2`.

Therefore packet depth `r=Theta(L^2)` is a continuum/adiabatic beta-flow.

A hypothetical off-critical displacement

`a=beta_rho-1/2 in (0,1/2)`

is encountered at

`r_a(L)
 =a L^2/(2log128)+O(1)`.

So the remaining v507 mesoscopic cascade is not an arbitrary collection of
`O(L^2)` packets: it is a slow traversal of

`0<beta<1/2`.

This identifies the exact missing theorem shape.

Suppose a **signed, phase-preserving** local packet bound can be established:

`||T u||_(beta+Delta_beta,E)
 <=q_L(beta,E)||u||_(beta,E)`,

with

`log q_L(beta,E)
 =-kappa(beta,E)Delta_beta+o(Delta_beta)`

uniformly on compact beta/E sets. Then products over packet depth converge to
the Lyapunov integral

`log Product q_L
 -> -int kappa(beta,E)dbeta`.

More generally, the Gaussian zero-type target only needs the accumulated
positive logarithmic gain through every compact subinterval of `0<beta<1/2`
to be `o(L^2)` after the Gaussian weight is included.

### Why this matters

* beta=2 is far outside the RH-bearing saddle and controls only the deep tail.
* the phase-free positive theorem has its natural threshold at beta>1/2.
* the unresolved Gaussian region is exactly the signed adiabatic flow
  `0<beta<1/2`.

Hence the next non-circular theorem is no longer "prove another fixed-beta
R7 contraction." It is:

> **derive the signed packet Lyapunov law along the actual arithmetic
> G7-generated cyclic orbit for the continuous beta-flow 0<beta<1/2.**

A negative/zero-enough Lyapunov exponent yields v502 zero backward type; a
positive exponent localized at beta=a would reproduce the off-critical
instability.

**Verdict:** `EXACT_GAUSSIAN_R7_ADIABATIC_BETA_FLOW_REDUCTION_PASS`.

This is a reduction, not the Lyapunov theorem itself.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_ADIABATIC_BETA_FLOW_V1",
        "closed":{
            "support_floor":"s_r=2*128^r",
            "beta_mesh":"beta_r=2log2/L^2+r*2log128/L^2",
            "Delta_beta":"2log128/L^2",
            "offcritical_packet":"r_a=aL^2/(2log128)+O(1)"
        },
        "next_theorem":"signed phase-preserving Lyapunov law on actual G7 cyclic orbit for beta in (0,1/2)"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--a",type=float,default=.2)
    ap.add_argument("--prefix",default="rot_rh_gaussian_adiabatic_beta_v509")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    if not 0<args.a<.5:raise ValueError("a in (0,1/2)")
    t0=time.perf_counter()
    with tqdm(total=1,desc="v509 beta flow",unit="step") as bar:
        rows=panel(args.a);bar.update(1)
    target=args.a/(2*math.log(Q))
    ok=all(abs(r["packet_fraction_of_L2"]-target)<1e-14 for r in rows)
    verdict="EXACT_GAUSSIAN_R7_ADIABATIC_BETA_FLOW_REDUCTION_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"a":float(args.a),
             "limit_r_over_L2":target,"panel":rows,
             "runtime_seconds":float(time.perf_counter()-t0)}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
