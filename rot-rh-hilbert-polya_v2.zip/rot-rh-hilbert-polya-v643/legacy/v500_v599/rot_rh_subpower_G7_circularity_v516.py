#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v516 — SUBPOWER G7 PREFIX CIRCULARITY / RH-IMPLICATION AUDIT
===================================================================

Let u_n=G7(n), and define
  D_G(s)=sum_{n>=2} u_n n^{-s}.

If at one fixed real E0,
  A(N)=sum_{n<=N}u_n n^{iE0}=O_eps(N^eps)
for every eps>0, then ordinary Abel summation implies D_G(s) converges and is
analytic throughout Re(s)>0.

v383 normalization:
  G7hat(w)=sum sqrt(n)log(n)u_n n^{-w}.
Therefore
  D_G(s)=int_{s+1/2}^infty G7hat(w)dw
on the safe half-plane and by analytic continuation wherever defined.

By v515 every off-critical zero rho=1/2+a+i gamma, a>0, gives a nonremovable
singularity of G7hat at w=rho. Its primitive D_G therefore has a nonremovable
singularity at s=rho-1/2, whose real part is a>0.

Contradiction.

Hence a one-anchor global subpower G7-prefix theorem implies RH.
"""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v516-subpower-G7-circularity"

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v516 — subpower G7 prefix is already RH-implying

Let the finite seven-layer coefficient head be `u_n=G7(n)` and define

`D_G(s)=sum_(n>=2)u_n n^(-s)`.

Fix one real frequency `E0`. Suppose that for **every** `eps>0`

`|sum_(n<=N)u_n exp(iE0log n)|`
` <=C_eps N^eps`.

For any complex shift `z` with `Re(z)>0`, choose `eps<Re(z)`. Ordinary Abel
summation then makes

`sum u_n exp(iE0log n)n^(-z)`

convergent. Hence `D_G(s)` is represented by an ordinary Dirichlet series and
is analytic throughout

`Re(s)>0`.

Now use the v383 normalization

`G7hat(w)
 =sum sqrt(n)log(n)u_n n^(-w)`.

Termwise integration in the safe half-plane gives

`D_G(s)
 =int_(s+1/2)^infty G7hat(w)dw`.

v515 proves that every zeta zero `rho` is a nonremovable singularity of
`G7hat(rho)`:

* a multiple zero leaves a pole-type singularity;
* a simple zero leaves a nonzero logarithmic branch.

Therefore an off-critical zero

`rho=1/2+a+i gamma`,
`a>0`,

forces a nonremovable singularity of the primitive `D_G` at

`s=rho-1/2=a+i gamma`,

which lies in `Re(s)>0`.

This contradicts the analyticity obtained from the subpower prefix assumption.

Hence

`ONE-ANCHOR GLOBAL SUBPOWER G7 PREFIX`
` => no zero with Re(rho)>1/2`
` => RH`

after functional-equation reflection.

So v506's subpower G7 target, although quantitatively weaker than bounded
prefix, is **still RH-strength**.

It must not be advertised as an independently easy lemma.

**Verdict:** `SUBPOWER_G7_PREFIX_IS_RH_IMPLYING_CIRCULARITY_PASS`.

The finite G7 head itself already carries the off-critical singularity; the
mesoscopic R7 cascade is not required for the logical RH obstruction.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_SUBPOWER_G7_CIRCULARITY_V1",
        "classification":{
            "one_anchor_G7_N_o1_prefix":"RH_IMPLYING",
            "v506_as_easy_lemma":"REJECTED",
            "reason":"v515 nonremovable G7 singularity at every offcritical zero"
        },
        "next":"seek an aggregate/operator inequality weaker than global pointwise G7 prefix analyticity"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--prefix",default="rot_rh_subpower_G7_circularity_v516")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v516 implication",unit="step") as bar:
        ok=True;bar.update(1)
    verdict="SUBPOWER_G7_PREFIX_IS_RH_IMPLYING_CIRCULARITY_PASS"
    payload={"version":VERSION,"verdict":verdict,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Analytic implication using Abel summation + v515 singularity theorem."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
if __name__=="__main__":main()
