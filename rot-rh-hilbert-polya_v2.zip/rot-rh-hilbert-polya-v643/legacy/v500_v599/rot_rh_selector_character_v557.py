#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm
VERSION="2026-08-29-v557-selector-character-orthogonality"
THEOREM=r"""# ROT-RH v557 — selector labels are exact compact-phase winding characters

At the first-later-crossing levels,

`F_L(E_k)=k-1/2`.

Introduce an auxiliary compact clock angle `theta in [0,2pi)` and define the
lifted selector character

`psi_k(theta)`
` =(2pi)^(-1/2) exp[i(F_L(E_k)+1/2)theta]`.

Since `F_L(E_k)+1/2=k`,

`psi_k(theta)=(2pi)^(-1/2)e^(ik theta)`.

Therefore

`<psi_j,psi_k>`
` =(1/2pi)int_0^(2pi)e^(i(k-j)theta)dtheta`
` =delta_(jk)`.

Thus the quantization index already has a canonical interpretation as an
integer winding sector of a compact U(1) clock: distinct selector labels are
exactly orthogonal characters.

This removes the v551 coherence obstruction **if** the ROT observer Hilbert
space contains the unwrapped clock register rather than only a finite
band-limited evaluation vector.

However, the regular representation is infinite-dimensional. To use v555/v556
one still needs an independently derived finite/subexponential accessible
clock capacity at resolution `L`, or an action law that makes high winding
sectors inaccessible at subexponential cost.

So the new bridge is sharply split:

1. orthogonality of different selector windings — exact;
2. capacity/novelty cost of admitting winding `k` — open ROT theorem.

**Verdict:** `SELECTOR_INDEX_EQUALS_ORTHOGONAL_COMPACT_CLOCK_CHARACTER_PASS`.
"""
def gram(N):
    import numpy as np
    # Discrete exact DFT quadrature with M>N resolves character orthogonality.
    M=max(2*N+1,8)
    th=2*np.pi*np.arange(M)/M
    V=np.exp(1j*np.outer(np.arange(N),th))/np.sqrt(M)
    G=V@V.conj().T
    return {"N":N,"grid":M,"max_gram_error":float(np.max(np.abs(G-np.eye(N))))}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--N",type=int,default=16); ap.add_argument("--prefix",default="rot_rh_selector_character_v557"); ap.add_argument("--strict",action="store_true"); a=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v557 characters",unit="step") as bar: chk=gram(a.N); bar.update(1)
    ok=chk["max_gram_error"]<1e-12
    verdict="SELECTOR_INDEX_EQUALS_ORTHOGONAL_COMPACT_CLOCK_CHARACTER_PASS" if ok else "FAILED"
    p=Path(a.prefix).resolve()
    Path(str(p)+"_SUMMARY.json").write_text(json.dumps({"version":VERSION,"verdict":verdict,"demo":chk,"runtime_seconds":time.perf_counter()-t0},indent=2))
    Path(str(p)+"_THEOREM.md").write_text(THEOREM)
    Path(str(p)+"_NEXT_CERTIFICATE_TEMPLATE.json").write_text(json.dumps({"schema":"ROT_RH_SELECTOR_CHARACTER_V1","closed":"selector labels -> orthogonal U(1) characters","remaining":"subexponential accessible winding capacity"},indent=2))
    print("verdict:",verdict); print(chk)
    if a.strict and not ok: raise SystemExit(2)
if __name__=="__main__": main()
