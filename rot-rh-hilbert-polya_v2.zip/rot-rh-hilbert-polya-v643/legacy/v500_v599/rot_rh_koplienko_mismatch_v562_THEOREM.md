# ROT-RH v562 — naive Koplienko/det2 shortcut does not control the centered trace

For a Hilbert–Schmidt operator `T`, the regularized determinant satisfies

`log det_2(I+T)`
` =Tr[log(I+T)-T]`

whenever the expansion is justified. Thus `det_2` explicitly removes the
first-order trace `Tr T`; its expansion begins at quadratic order:

`log det_2(I+T)`
` =-1/2 Tr T^2+1/3 Tr T^3-...`.

Koplienko's second-order spectral shift is exactly adapted to this
first-order-subtracted setting. For a self-adjoint Hilbert–Schmidt perturbation
`A-B`, its spectral-shift density is nonnegative and has total mass

`int eta(lambda)d lambda=1/2 ||A-B||_2^2`.

But v561 proves that the ROT-RH centered Gaussian quantity is

`boxed{log Delta_tau=Tr T_tau}`,

the very **first-order trace** that `det_2` removes.

Therefore the polynomial Hilbert–Schmidt bound

`||T_tau||_2^2=O(L)`

does not control the RH-bearing phase `Im Tr T_tau`.

This is not merely technical: the first-order trace can have positive `L^2`
exponential type in a very large effective dimension while the Hilbert–Schmidt
norm remains polynomial.

A valid Koplienko-style breakthrough would require a new exact operator
identity showing that Selberg's centered recursion rewrites this first-order
trace as a genuine second-order spectral-shift remainder plus an independently
subexponential term.

No such identity has yet been proved.

**Verdict:** `NAIVE_DET2_KOPLIENKO_DOES_NOT_CONTROL_CENTERED_FIRST_ORDER_TRACE_PASS`.
