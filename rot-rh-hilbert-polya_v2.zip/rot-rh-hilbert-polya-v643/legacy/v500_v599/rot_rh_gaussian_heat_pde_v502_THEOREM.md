# ROT-RH v502 — Gaussian cutoff as exact heat flow / off-critical backward instability

Introduce the Gaussian smoothing time

`tau=L^-2`

and define the centered complex arithmetic primitive

`Q_tau(E)
 =int exp(-tau y^2) exp(-y/2+iEy) dmu(y)/y`.

At the integrand level,

`partial_tau [e^(-tau y^2)e^(iEy)/y]
 =-y e^(-tau y^2)e^(iEy)`

and

`partial_E^2 [e^(-tau y^2)e^(iEy)/y]
 =-y e^(-tau y^2)e^(iEy)`.

Therefore, wherever the regularized integral is interpreted,

`partial_tau Q_tau(E)=partial_E^2 Q_tau(E)`.

So the analytic Gaussian cutoff is **exactly the heat semigroup in spectral
energy**.

For one zero-side exponential mode put

`lambda=a+i(gamma-E)`.

The Gaussian transform has the standard saddle form

`K_tau(lambda)
 =C(lambda,tau) exp(lambda^2/(4tau))`

with only algebraic prefactor variation in the right-half saddle sector.
Consequently

`log|K_tau|`
` =[a^2-(gamma-E)^2]/(4tau)`
`  +O(log(1/tau))`.

If `a>0`, then on every compact subinterval

`|E-gamma|<=a-delta`

the exponent is strictly positive, and

`|K_tau|>=exp(c_delta/tau)`

up to algebraic factors as `tau->0+`.

By contrast, for a critical-line mode `a=0`,

`Re(lambda^2)=-(gamma-E)^2<=0`;

there is no positive backward-heat exponential.

Thus:

> **Off-critical right-half zeros are exactly positive backward-heat instability
> directions of the Gaussian-regulated arithmetic phase.**

This recasts v497's occupancy explosion in PDE language.  The cutoff limit
`L->infinity` is the boundary limit `tau->0+` of a forward heat extension.
A right-half zero produces a mode that is exponentially ill-conditioned in the
backward direction.

### RH-bearing boundary criteria

Any zero-blind theorem strong enough to show, on every fixed compact energy
interval,

`log^+ sup_E |Q_tau(E)| = o(1/tau)`

as `tau->0+` excludes all positive `a`.

Even more directly, the v501 weighted running-max bound or v500 one-time heat
trace bound excludes the same instability.

This suggests a ROT-native target:

> prove that the recursive-clock arithmetic heat extension has a boundary value
> of **zero backward exponential type** as `tau->0+`.

That statement is weaker than uniform pointwise convergence but strong enough
to rule out every off-critical exponential mode.

**Verdict:** `EXACT_GAUSSIAN_ARITHMETIC_HEAT_PDE_AND_BACKWARD_INSTABILITY_PASS`.

This theorem identifies the instability mechanism; it does not prove the
zero-type boundary estimate.
