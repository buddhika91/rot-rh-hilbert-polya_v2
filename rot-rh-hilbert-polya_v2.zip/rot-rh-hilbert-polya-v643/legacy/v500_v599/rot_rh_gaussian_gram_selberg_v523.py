#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v523 — EXACT GAUSSIAN GRAM SELBERG-TRANSFER TARGET
=========================================================

Define for a coefficient sequence c_n

  ||c||_{L,u}^2
    := int_R e^{-uE^2}
       |sum c_n n^-1/2 e^{-(logn/L)^2} e^{iElogn}|^2 dE

    = sqrt(pi/u) sum_{m,n}
       c_m cbar_n /sqrt(mn)
       e^{-(logm/L)^2-(logn/L)^2}
       e^{-log(m/n)^2/(4u)}.

For c_n=Lambda(n)-1 this is exactly v518 Q_L(u).

Let S be the exact causal Selberg map
  r log +2(b*r)+(r*r)=H
and J_r its exact Frechet derivative
  (J_r delta r)(n)
   = -2/log n sum_{d|n,d<n} Lambda(n/d) delta r(d).

A sufficient independent theorem is:
  ||J_r||_{L,u -> L,u} <= q<1
(or an iterate/block version with exp(o(L^2)) gain)
together with an exp(o(L^2)) forcing norm.

Then the actual centered solution has Q_L(u)=exp(o(L^2)), and v519 gives RH.

This is the exact quadratic geometry to attack; unlike v276 l-infinity,
the v518 evaluation is built into the norm itself.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
from tqdm import tqdm

VERSION="2026-08-29-v523-gaussian-gram-selberg"

def gram_kernel(m,n,L,u):
    return math.sqrt(math.pi/u)/math.sqrt(m*n)*math.exp(
        -(math.log(m)/L)**2-(math.log(n)/L)**2
        -(math.log(m/n)**2)/(4*u)
    )

def psd_demo(L,u):
    import numpy as np
    ns=np.array([2.,3.,5.,7.,11.,13.])
    G=np.array([[gram_kernel(m,n,L,u) for n in ns] for m in ns])
    eig=np.linalg.eigvalsh(G)
    return {"minimum_eigenvalue":float(eig.min()),
            "maximum_eigenvalue":float(eig.max()),
            "pass":bool(eig.min()>-1e-10)}

def write(prefix,payload):
    s=Path(str(prefix)+"_SUMMARY.json")
    t=Path(str(prefix)+"_THEOREM.md")
    c=Path(str(prefix)+"_NEXT_CERTIFICATE_TEMPLATE.json")
    s.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    t.write_text(r"""# ROT-RH v523 — exact Gaussian-Gram Selberg-transfer target

For coefficients `c_n`, define

`||c||_(L,u)^2`

`:=int_R e^(-uE^2)
 |sum_(n>=2)c_n n^(-1/2)
  e^[-(log n/L)^2]e^(iElog n)|^2dE`.

The exact Gaussian Fourier identity gives

`||c||_(L,u)^2`
`=sqrt(pi/u) sum_(m,n>=2)`
` c_m conjugate(c_n)/sqrt(mn)`
` exp[-(logm/L)^2-(logn/L)^2]`
` exp[-log^2(m/n)/(4u)]`.

This is a positive-semidefinite Gram norm.

For

`c_n=r(n)=Lambda(n)-1`,

it is exactly the v518 quadratic order parameter.

Now use Selberg's exact causal recursion

`r(n)log n+2(b*r)(n)+(r*r)(n)=H(n)`.

At the true arithmetic solution the Frechet derivative is

`(J_r delta r)(n)`
` =-2/log n`
`   sum_(d|n,d<n)Lambda(n/d)delta r(d)`,

the same exact Jacobian whose natural weighted `l-infinity` contraction was
globally certified in v276.

The new theorem target is to estimate **that same exact Jacobian in the
Gaussian Gram geometry itself**.

A sufficient closure is either

`||J_r||_(L,u -> L,u)<=q<1`

uniformly for large `L`, or the weaker block condition

`||J_r^m||_(L,u -> L,u)<=exp(o(L^2))`

combined with an `exp(o(L^2))` bound for the Selberg forcing solution.

Then the unique causal fixed point satisfies

`||r||_(L,u)^2=exp(o(L^2))`.

By v519 this forces RH.

### Why this target is genuinely different from earlier failures

* v276 proves contraction in a coefficient `l-infinity` norm but the critical
  evaluation functional is unbounded there.
* v518 puts the evaluation inside a quadratic norm but had no recursive
  mechanism.
* v523 combines the two: **Selberg recursion measured directly in the exact
  v518 Gaussian covariance geometry**.
* v522 shows brute long-window orthogonalization cannot substitute for this
  phase-sensitive transfer.

The next analytic calculation is the Schur/Carleson norm of the divisor-sparse
Jacobian against the Gaussian multiplicative Gram kernel.

**Verdict:** `GAUSSIAN_GRAM_SELBERG_TRANSFER_IS_CURRENT_NONTAUTOLOGICAL_TARGET_PASS`.
""",encoding="utf-8")
    c.write_text(json.dumps({
        "schema":"ROT_RH_GAUSSIAN_GRAM_SELBERG_V1",
        "norm":"exact v518 Gaussian covariance",
        "operator":"exact v276 Selberg Frechet Jacobian",
        "required":"uniform contraction or exp(o(L^2)) block gain + subexponential forcing",
        "consequence":"v519 => RH",
        "next_calculation":"Schur/Carleson bound exploiting divisor-sparse Lambda kernel"
    },indent=2),encoding="utf-8")
    return s,t,c

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--L",type=float,default=20.)
    ap.add_argument("--u",type=float,default=.01)
    ap.add_argument("--prefix",default="rot_rh_gaussian_gram_selberg_v523")
    ap.add_argument("--strict",action="store_true")
    args=ap.parse_args()
    t0=time.perf_counter()
    with tqdm(total=1,desc="v523 Gram PSD",unit="step") as bar:
        chk=psd_demo(args.L,args.u);bar.update(1)
    ok=bool(chk["pass"])
    verdict="GAUSSIAN_GRAM_SELBERG_TRANSFER_IS_CURRENT_NONTAUTOLOGICAL_TARGET_PASS" if ok else "FAILED"
    payload={"version":VERSION,"verdict":verdict,"gram_demo":chk,
             "runtime_seconds":float(time.perf_counter()-t0),
             "proof_status":"Exact norm/reduction; Selberg Jacobian Gram-norm bound remains open."}
    prefix=Path(args.prefix).resolve()
    s,t,c=write(prefix,payload)
    print("verdict:",verdict);print("summary:",s);print("theorem:",t);print("certificate:",c)
    if args.strict and not ok:raise SystemExit(2)
if __name__=="__main__":main()
