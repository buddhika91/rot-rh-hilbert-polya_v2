# ROT-RH v504 — subpower prefix implies zero Gaussian backward type

Let

`A_u(N,E)=sum_(2<=n<=N)u_n exp(iElog n)`,

and let `I` be compact. Assume for every fixed `eps in (0,1)`

`sup_(E in I)|A_u(N,E)| <= C_(eps,I) N^eps`.

For

`b_L(n)=exp[-(log n/L)^2]`

and

`G_L(E)=sum_(n>=2)u_n b_L(n)exp(iElog n)`,

discrete Abel summation gives

`G_L(E)=sum_(m>=2)A_u(m,E)[b_L(m)-b_L(m+1)]`.

Hence

`|G_L(E)|
 <=C_(eps,I) sum_(m>=2)m^eps[b_L(m)-b_L(m+1)]`.

The associated Stieltjes majorant is

`int_1^infty t^eps[-db_L(t)]`.

With `y=log t`, `z=y/L`, this is

`int_0^infty 2z exp(-z^2+eps L z)dz`

`=1+(eps L sqrt(pi)/2)
 exp(eps^2L^2/4)[1+erf(eps L/2)]`.

Thus, up to an eps-dependent absolute discrete/continuous constant,

`sup_(E in I)|G_L(E)|
 <=C'_(eps,I)(1+eps L)exp(eps^2L^2/4)`.

Therefore

`limsup_(L->infty)
 L^-2 log^+ sup_(E in I)|G_L(E)|
 <=eps^2/4`.

Since `eps>0` is arbitrary,

`L^-2 log^+ sup_(E in I)|G_L(E)| -> 0`.

So the Gaussian route needs only a **subpower** critical prefix theorem, not a
bounded one.

**Verdict:** `SUBPOWER_PREFIX_IMPLIES_ZERO_GAUSSIAN_TYPE_PASS`.
