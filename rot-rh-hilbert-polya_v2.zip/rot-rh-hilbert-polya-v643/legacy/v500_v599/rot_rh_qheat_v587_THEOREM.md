# ROT-RH v587 — centered determinant coordinate itself obeys the heat equation

For `tau>0`,

`q_tau(s)=log Delta_tau(s)`
` =-sum_(n>=2)(Lambda(n)-1)/(log n)`
`   n^(-s)e^[-tau(log n)^2]`.

On the critical-energy parametrization

`q_tau(E):=q_tau(1/2+iE)`,

differentiate each entire Gaussian term:

`partial_tau`
` [-r_n/logn * n^(-1/2-iE)e^(-tau log^2n)]`

` =r_n logn * n^(-1/2-iE)e^(-tau log^2n)`,

while two E derivatives give the same expression.

Hence exactly

`boxed{partial_tau q_tau=partial_E^2 q_tau}`.

Therefore

`P_tau:=partial_E q_tau`

also obeys

`boxed{partial_tau P_tau=partial_E^2 P_tau}`.

By v583,

`Q_tau(u)=int e^(-uE^2)|P_tau(E)|^2dE`

is the RH-sensitive logarithmic-metric energy.

Thus the centered determinant coordinate is itself a complex heat-map whose
boundary Dirichlet energy is the RH order parameter.

**Verdict:** `CENTERED_DETERMINANT_LOG_COORDINATE_IS_EXACT_COMPLEX_HEAT_FLOW_PASS`.
