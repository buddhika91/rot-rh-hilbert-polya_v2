# ROT-RH v564 — exact Gaussian heat/Wick Selberg algebra

For an arithmetic coefficient sequence `c_n`, define

`H_tau[c](E)`
` =sum_(n>=1)c_n n^(-1/2)`
`   exp[-tau(log n)^2] exp(iElog n)`,

with `c_1` included when convenient.

Let `c*d` denote Dirichlet convolution.

Define a bilinear product `star_tau` on positive-frequency exponential
polynomials by its action on frequency atoms,

`e_y(E)=exp(iEy)`,

`e_y star_tau e_z`
` :=exp[-2tau yz] e_(y+z)`.

Then, coefficient by coefficient,

`boxed{H_tau[c*d]=H_tau[c] star_tau H_tau[d]}`.

Indeed for `n=ab`, with `y=log a`, `z=log b`,

`exp[-tau(y+z)^2]`
` =exp[-tau y^2]exp[-tau z^2]exp[-2tau yz]`.

The product is commutative and associative because the accumulated factor for
three frequencies is

`exp[-2tau(yz+yw+zw)]`

independently of bracketing.

Equivalently, if `S_tau=exp(tau partial_E^2)` is the heat operator, then

`f star_tau g`
` =S_tau[(S_tau^-1 f)(S_tau^-1 g)]`

on finite positive-frequency sums.

## Exact Gaussian-regulated Selberg equation

Put

`b(1)=0`, `b(n)=1` for `n>=2`,
`r(n)=Lambda(n)-b(n)`.

Selberg's pointwise identity is

`r(n)log n+2(b*r)(n)+(r*r)(n)=H(n)`.

Define

`R_tau=H_tau[r]`,
`B_tau=H_tau[b]`,
`Hcal_tau=H_tau[H]`.

Since

`partial_E R_tau`
` =i H_tau[r log](E)`,

the exact regulated equation is

`boxed{-i partial_E R_tau`
` +2 B_tau star_tau R_tau`
` +R_tau star_tau R_tau`
` =Hcal_tau}`.

No limiting argument is used.

## Why this is structurally useful

For positive log-frequencies `y,z>=0`,

`0<exp[-2tau yz]<=1`.

Thus every multiplicative interaction acquires a **genuine Gaussian
cross-damping**.  At the logarithmic saddle scale
`y=(beta/2)tau^-1`, a quotient frequency `z=log q` contributes

`exp[-beta z]=q^(-beta)`,

exactly the beta-conjugation mechanism appearing in v531, with the additional
self-damping `exp[-tau z^2]` supplied by the one-particle heat factors.

Therefore v531's scale-dependent beta is not an artificial norm choice: it is
the local interaction weight of the exact Gaussian Wick algebra.

**Verdict:** `EXACT_GAUSSIAN_REGULATOR_TURNS_SELBERG_CONVOLUTION_INTO_DAMPED_WICK_PRODUCT_PASS`.

This is an algebraic theorem.  A Gaussian-L2 energy inequality for `star_tau`
strong enough to control v523 remains open.
