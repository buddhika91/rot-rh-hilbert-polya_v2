#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v90 — Fisher-Metric Covariant Hilbert–Pólya Operator / Xi Identity Audit
===============================================================================

MOTIVATION
----------
v89 falsified the v86-v88 covariance/Fredholm realization:
  * frozen v88 truncations were not nested/stable;
  * zero-sequence relative RMSE was ~36%;
  * low-t Xi agreement was beaten by a generic isotropic kernel.

We therefore STOP that representation.

An earlier zero-free ROT branch found that Fisher/Hellinger recursive stiffness
improved arithmetic spectral prediction, while direct multiplication of the
prime source by kappa destroyed the spectrum.  Its explicit next hypothesis was:

    keep the raw arithmetic source;
    put recursive stiffness into the operator metric/measure/Jacobi geometry.

v90 implements that hypothesis as a genuine generalized self-adjoint operator
in ONE FIXED spectral-index basis.

ZERO-FREE RAW STATE
-------------------
For arithmetic cutoff X, compute the prime/Gamma quantized levels

    E_k(X)

using the existing pure-Mangoldt Abel prime-phase law.  Let E_k^(0) be the free
Gamma levels and define the signed arithmetic displacement state

    q_k(X) = E_k(X) - E_k^(0),
    psi(X) = q(X) / ||q(X)||_2.

No Xi, zeta or zero ordinates are used.

ROT FISHER METRIC
-----------------
From successive cutoffs X_{j-1}->X_j with logarithmic step dL,

    p_k = psi_k^2,

and the local Hellinger/Fisher velocity is

    I_k = [sqrt(p_k(X_j))-sqrt(p_k(X_{j-1}))]^2 / dL^2.

The mode-resolved recursive stiffness is the direct local extension of the
earlier scalar Fisher clock:

    d log g_k / dL = sqrt(I_k / median_dev(I)).

The log metric is gauge-fixed at every step by subtracting its mean, so

    prod_k g_k = 1.

This preserves the overall energy scale and introduces no Xi-fitted scalar.

ROT INFORMATION CONNECTION
--------------------------
The signed projective state also carries an antisymmetric connection

    A = psi dpsi^T - dpsi psi^T.

Only nearest-neighbor matrix elements are retained in the level-index basis.
They are converted to energy units using the local raw level spacing.

The raw covariant Hermitian operator is

    B = diag(E_k) + i A_E,

where A_E is real antisymmetric.

The Fisher-metric Hilbert–Pólya candidate is

    H_ROT = G^(-1/2) B G^(-1/2),
    G = diag(g_k) > 0.

Equivalently, B v = lambda G v.  Hence H_ROT is Hermitian in the ordinary
Hilbert space and B is self-adjoint in the recursive Fisher metric.

This is NOT diagonal root packaging: the metric and connection change the
eigenvectors and, generically, the eigenvalues.

CONTROLS
--------
  raw_diagonal       : diag(E_k)
  metric_only        : G^(-1/2) diag(E_k) G^(-1/2)
  connection_only    : B
  shuffled_metric    : same g_k, permuted before dressing
  signless_metric    : metric from |q|, no signed connection

SELECTION / FIREWALL
--------------------
There is NO Xi-based model selection.
All models are built from the same fixed formulas.
Every operator is serialized and SHA256 hashed before Xi is evaluated.

POST-FREEZE TEST
----------------
For the positive eigenvalues lambda_n of H_ROT,

    D_H(t) = product_n (1 - t^2/lambda_n^2)

is compared with

    Xi(t)/Xi(0).

The test includes:
  * cutoff convergence in the common level-index basis;
  * Hermiticity and positivity;
  * Herglotz resolvent positivity;
  * post-freeze Xi Taylor trace moments;
  * direct determinant comparison through multiple Xi crossings;
  * post-freeze zero-sequence comparison.

No Riemann zero ordinates are supplied or used in construction.

SCIENTIFIC BOUNDARY
-------------------
This is a falsification audit of a specific ROT-native operator hypothesis, not
an RH proof.  A proof would still require an infinite-cutoff/infinite-level
operator theorem and an exact Xi identity.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import mpmath as mp
import numpy as np

VERSION = "v90"
BUILD = "2026-08-17-fisher-metric-covariant-hp-v90"
EPS = 1.0e-14


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (complex, np.complexfloating)):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, mp.mpf):
        return mp.nstr(x, 50)
    if isinstance(x, mp.mpc):
        return {"real": mp.nstr(mp.re(x), 50), "imag": mp.nstr(mp.im(x), 50)}
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for k in row:
            if k not in seen:
                seen.add(k)
                fields.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def hermitian(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=np.complex128)
    return 0.5 * (X + X.conj().T)


def rel_fro(A: np.ndarray, B: np.ndarray) -> float:
    return float(
        np.linalg.norm(A-B, "fro") /
        max(np.linalg.norm(B, "fro"), EPS)
    )


def normalize_signed(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=float)
    n = float(np.linalg.norm(q))
    if n <= EPS:
        return np.zeros_like(q)
    return q/n


def probability_from_state(psi: np.ndarray) -> np.ndarray:
    p = np.asarray(psi, float)**2
    s = float(np.sum(p))
    if s <= EPS:
        return np.full(len(p), 1.0/max(len(p),1))
    return p/s


def local_fisher_density(p0: np.ndarray, p1: np.ndarray, dL: float) -> np.ndarray:
    a = np.sqrt(np.maximum(np.asarray(p0,float), 0.0))
    b = np.sqrt(np.maximum(np.asarray(p1,float), 0.0))
    return ((b-a)/max(float(dL), EPS))**2


def projective_connection(psi0: np.ndarray, psi1: np.ndarray, dL: float) -> np.ndarray:
    """
    Real antisymmetric projective transport generator:
        C = psi dpsi^T - dpsi psi^T.
    """
    p0 = np.asarray(psi0, float)
    p1 = np.asarray(psi1, float)
    v = (p1-p0)/max(float(dL), EPS)
    C = np.outer(p1, v) - np.outer(v, p1)
    return 0.5*(C-C.T)


def median_positive(x: np.ndarray) -> float:
    z = np.asarray(x,float)
    z = z[np.isfinite(z) & (z > 1e-18)]
    return float(np.median(z)) if len(z) else 1.0


def exp_det_one(logg: np.ndarray) -> np.ndarray:
    z = np.asarray(logg,float)
    z = z - float(np.mean(z))
    # Numerical safety only; with the tested cutoffs this should normally be inactive.
    z = np.clip(z, -40.0, 40.0)
    z = z - float(np.mean(z))
    return np.exp(z)


def build_connection_energy(C: np.ndarray, roots: np.ndarray) -> np.ndarray:
    """
    Restrict information connection to neighboring level-index channels.
    The local raw level spacing supplies the only energy unit.
    """
    d = len(roots)
    A = np.zeros((d,d), dtype=float)
    spacing = np.diff(np.asarray(roots,float))
    for k in range(d-1):
        e = float(spacing[k]) * float(C[k,k+1])
        A[k,k+1] = e
        A[k+1,k] = -e
    return A


def build_models(
    roots: np.ndarray,
    g: np.ndarray,
    Cavg: np.ndarray,
    rng: np.random.Generator,
) -> Dict[str,np.ndarray]:
    roots = np.asarray(roots,float)
    d = len(roots)
    D = np.diag(roots).astype(np.complex128)

    A_E = build_connection_energy(Cavg, roots)
    B = hermitian(D + 1j*A_E)

    invsqrt = np.diag(1.0/np.sqrt(np.maximum(g, 1e-300)))
    full = hermitian(invsqrt @ B @ invsqrt)
    metric_only = hermitian(invsqrt @ D @ invsqrt)
    connection_only = B

    perm = rng.permutation(d)
    gp = g[perm]
    Pinv = np.diag(1.0/np.sqrt(np.maximum(gp, 1e-300)))
    shuffled_metric = hermitian(Pinv @ B @ Pinv)

    return {
        "full": full,
        "raw_diagonal": D,
        "metric_only": metric_only,
        "connection_only": connection_only,
        "shuffled_metric": shuffled_metric,
    }


def h_resolvent_min_imag(H: np.ndarray, probes_real, probes_imag) -> float:
    H = hermitian(H)
    # Fixed cyclic vector; no Xi data.
    v = np.ones(H.shape[0], dtype=np.complex128)
    v /= np.linalg.norm(v)
    I = np.eye(H.shape[0], dtype=np.complex128)
    out = float("inf")
    for y in probes_imag:
        if y <= 0:
            continue
        for x in probes_real:
            z = complex(x,y)
            m = np.vdot(v, np.linalg.solve(H-z*I, v))
            out = min(out, float(np.imag(m)))
    return out


def determinant_from_energies(E: np.ndarray, t: complex) -> complex:
    E = np.asarray(E,float)
    E = E[E > 1e-12]
    z = complex(t)
    return complex(np.prod(1.0 - (z*z)/(E*E)))


def symmetric_error(a: complex, b: complex) -> float:
    return abs(a-b)/max(1.0,abs(a),abs(b))


def rms(x: Sequence[float]) -> float:
    z=np.asarray(x,float)
    z=z[np.isfinite(z)]
    return float(np.sqrt(np.mean(z*z))) if len(z) else float("nan")


def bisect_xi_zero(v86, a: float, b: float, iters: int=80) -> float:
    aa,bb=mp.mpf(a),mp.mpf(b)
    fa=mp.re(v86.Xi_t(aa)); fb=mp.re(v86.Xi_t(bb))
    if fa*fb>0:
        raise ValueError("not bracketed")
    for _ in range(iters):
        m=(aa+bb)/2
        fm=mp.re(v86.Xi_t(m))
        if fa*fm<=0:
            bb=m; fb=fm
        else:
            aa=m; fa=fm
    return float((aa+bb)/2)


def xi_sign_change_zeros(v86, tmax: float, step: float) -> List[float]:
    out=[]
    x0=0.0
    f0=mp.re(v86.Xi_t(0))
    x=step
    while x<=tmax+1e-12:
        f=mp.re(v86.Xi_t(mp.mpf(x)))
        if f==0 or f0*f<0:
            out.append(bisect_xi_zero(v86,x0,x))
        x0,f0=x,f
        x+=step
    return out


def zero_metrics(pred: np.ndarray, truth: Sequence[float], count: int) -> Dict[str,float]:
    p=np.sort(np.asarray(pred,float))
    q=np.asarray(truth,float)
    n=min(count,len(p),len(q))
    if n==0:
        return {"count":0,"rmse":float("nan"),"relative_rmse":float("nan"),"mae":float("nan")}
    e=p[:n]-q[:n]
    return {
        "count":int(n),
        "rmse":float(np.sqrt(np.mean(e*e))),
        "relative_rmse":float(np.sqrt(np.mean((e/q[:n])**2))),
        "mae":float(np.mean(np.abs(e))),
        "max_abs":float(np.max(np.abs(e))),
    }


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v86-module",
        default="rot_rh_rot_native_recursive_hp_xi_identity_v86",
    )
    ap.add_argument("--cutoffs",default="20000,30000,45000,67500,100000,150000,200000")
    ap.add_argument("--development-last",type=int,default=4,
                    help="Last cutoff index used to freeze Fisher normalization; later cutoffs are blind.")
    ap.add_argument("--depth",type=int,default=32)
    ap.add_argument("--grid-points",type=int,default=128)
    ap.add_argument("--seed",type=int,default=20260817)

    ap.add_argument("--herglotz-real",default="0,10,25,50,100")
    ap.add_argument("--herglotz-imag",default="0.5,1.0,2.0")

    ap.add_argument("--xi-dps",type=int,default=100)
    ap.add_argument("--xi-radius",default="4")
    ap.add_argument("--xi-samples",type=int,default=2048)
    ap.add_argument("--moment-order",type=int,default=8)
    ap.add_argument("--identity-max",type=float,default=50.0)
    ap.add_argument("--identity-step",type=float,default=0.25)
    ap.add_argument("--zero-scan-step",type=float,default=0.10)
    ap.add_argument("--zero-match-count",type=int,default=12)

    # Diagnostic gates; no parameter selection uses Xi.
    ap.add_argument("--blind-operator-drift-gate",type=float,default=0.10)
    ap.add_argument("--zero-relative-rmse-gate",type=float,default=0.02)
    ap.add_argument("--identity-symmetric-rms-gate",type=float,default=0.15)

    ap.add_argument("--prefix",default="rot_rh_fisher_metric_covariant_hp_v90")
    args=ap.parse_args()

    t0=time.time()
    cutoffs=parse_ints(args.cutoffs)
    if cutoffs!=sorted(cutoffs) or len(cutoffs)<5:
        raise ValueError("Use >=5 increasing cutoffs.")
    if not (1 <= args.development_last < len(cutoffs)-1):
        raise ValueError("--development-last must leave at least one blind cutoff.")

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)

    base=importlib.import_module(args.base_module)

    print("="*154)
    print("ROT-RH v90 — FISHER-METRIC COVARIANT HILBERT–PÓLYA / Xi IDENTITY AUDIT")
    print("="*154)
    print("build                         :",BUILD)
    print("cutoffs                       :",cutoffs)
    print("development indices           :",f"0..{args.development_last}")
    print("blind indices                 :",f"{args.development_last+1}..{len(cutoffs)-1}")
    print("depth                         :",args.depth)
    print("operator basis                : fixed spectral-level index basis")
    print("raw arithmetic source         : unchanged pure Mangoldt/Gamma phase")
    print("ROT metric                    : mode-resolved recursive Fisher stiffness")
    print("ROT connection                : signed projective information transport")
    print("Xi/zeta during construction   : NONE")
    print("zero ordinates supplied       : NONE")
    print("="*154)

    # ------------------------------------------------------------------
    # STAGE A: raw zero-free arithmetic trajectories.
    # ------------------------------------------------------------------
    records=[]
    free=None
    roots_by_X={}
    psi_by_X={}
    p_by_X={}

    for X in cutoffs:
        print(f"[construct/raw] X={X}",flush=True)
        roots,resid,counts,free_local,meta=base.quantize_levels(
            depth=args.depth,
            cutoff=X,
            family="signal",
            seed=args.seed+X,
            grid_points=args.grid_points,
        )
        if free is None:
            free=np.asarray(free_local,float)
        shift=np.asarray(roots,float)-free
        psi=normalize_signed(shift)
        p=probability_from_state(psi)
        roots_by_X[X]=np.asarray(roots,float)
        psi_by_X[X]=psi
        p_by_X[X]=p
        records.append({
            "cutoff":X,
            "max_quantization_residual":float(np.max(resid)),
            "minimum_level":float(roots[0]),
            "maximum_level":float(roots[-1]),
            "shift_l2":float(np.linalg.norm(shift)),
            "state_entropy":float(-np.sum(p[p>0]*np.log(p[p>0]))),
        })

    # ------------------------------------------------------------------
    # STAGE B: recursive Fisher metric + connection, still Xi-blind.
    # ------------------------------------------------------------------
    fisher_steps=[]
    local_I=[]
    local_C=[]
    dLs=[]
    for i in range(1,len(cutoffs)):
        Xa,Xb=cutoffs[i-1],cutoffs[i]
        dL=math.log(float(Xb)/float(Xa))
        I=local_fisher_density(p_by_X[Xa],p_by_X[Xb],dL)
        C=projective_connection(psi_by_X[Xa],psi_by_X[Xb],dL)
        local_I.append(I)
        local_C.append(C)
        dLs.append(dL)

    # Development-only normalization.
    dev_I=np.concatenate([
        local_I[i-1]
        for i in range(1,args.development_last+1)
    ])
    fisher_median=median_positive(dev_I)

    logg=np.zeros(args.depth,float)
    C_integral=np.zeros((args.depth,args.depth),float)
    L_total=0.0
    models_by_X={}
    metric_rows=[]
    rng=np.random.default_rng(args.seed+9173)

    # First cutoff: identity metric / zero connection.
    g=exp_det_one(logg)
    models_by_X[cutoffs[0]]=build_models(
        roots_by_X[cutoffs[0]],g,C_integral,rng
    )

    for i in range(1,len(cutoffs)):
        X=cutoffs[i]
        dL=dLs[i-1]
        I=local_I[i-1]
        C=local_C[i-1]

        response=np.sqrt(np.maximum(I,0.0)/max(fisher_median,EPS))
        logg += response*dL
        logg -= float(np.mean(logg))
        g=exp_det_one(logg)

        C_integral += C*dL
        L_total += dL
        Cavg=C_integral/max(L_total,EPS)

        models=build_models(roots_by_X[X],g,Cavg,rng)
        models_by_X[X]=models

        for k in range(args.depth):
            metric_rows.append({
                "cutoff":X,
                "mode":k+1,
                "local_fisher_density":float(I[k]),
                "recursive_response":float(response[k]),
                "metric_g":float(g[k]),
                "log_metric_g":float(math.log(g[k])),
                "psi":float(psi_by_X[X][k]),
            })

        fisher_steps.append({
            "cutoff_a":cutoffs[i-1],
            "cutoff_b":X,
            "delta_log_cutoff":dL,
            "fisher_density_mean":float(np.mean(I)),
            "fisher_density_median_positive":median_positive(I),
            "metric_min":float(np.min(g)),
            "metric_max":float(np.max(g)),
            "metric_geometric_mean":float(np.exp(np.mean(np.log(g)))),
            "connection_fro":float(np.linalg.norm(Cavg,"fro")),
        })

    # Signless metric control: same G but zero connection is metric_only.
    # ------------------------------------------------------------------
    # STAGE C: pre-Xi operator diagnostics/convergence in SAME basis.
    # ------------------------------------------------------------------
    model_names=list(models_by_X[cutoffs[-1]].keys())
    operator_rows=[]
    drift_rows=[]
    frozen_payload={}

    for X in cutoffs:
        for name,H in models_by_X[X].items():
            H=hermitian(H)
            eig=np.linalg.eigvalsh(H).real
            frozen_payload[f"H_{name}_X{X}"]=H
            frozen_payload[f"eig_{name}_X{X}"]=eig
            operator_rows.append({
                "cutoff":X,
                "model":name,
                "hermitian_residual":float(np.linalg.norm(H-H.conj().T,"fro")),
                "minimum_eigenvalue":float(np.min(eig)),
                "maximum_eigenvalue":float(np.max(eig)),
                "minimum_spacing":float(np.min(np.diff(np.sort(eig)))),
                "herglotz_min_imag":h_resolvent_min_imag(
                    H,
                    parse_floats(args.herglotz_real),
                    parse_floats(args.herglotz_imag),
                ),
            })

    for Xa,Xb in zip(cutoffs[:-1],cutoffs[1:]):
        split="dev" if cutoffs.index(Xb)<=args.development_last else "blind"
        for name in model_names:
            A=models_by_X[Xa][name]
            B=models_by_X[Xb][name]
            ea=np.linalg.eigvalsh(A).real
            eb=np.linalg.eigvalsh(B).real
            drift_rows.append({
                "cutoff_a":Xa,
                "cutoff_b":Xb,
                "split":split,
                "model":name,
                "matrix_relative_fro_drift":rel_fro(A,B),
                "spectrum_relative_l2_drift":float(
                    np.linalg.norm(eb-ea)/max(np.linalg.norm(ea),EPS)
                ),
            })

    finalX=cutoffs[-1]
    final_models=models_by_X[finalX]
    final_full=final_models["full"]
    final_eigs=np.linalg.eigvalsh(final_full).real
    prexi_gates={
        "full_hermitian":float(np.linalg.norm(final_full-final_full.conj().T,"fro"))<=1e-10,
        "full_positive":float(np.min(final_eigs))>0.0,
        "full_ordered_simple":float(np.min(np.diff(np.sort(final_eigs))))>0.0,
        "full_herglotz":h_resolvent_min_imag(
            final_full,
            parse_floats(args.herglotz_real),
            parse_floats(args.herglotz_imag),
        )>0.0,
    }

    blind_full=[
        r for r in drift_rows
        if r["split"]=="blind" and r["model"]=="full"
    ]
    latest_blind_spectral=float(blind_full[-1]["spectrum_relative_l2_drift"])
    prexi_gates["latest_blind_spectrum_drift"] = (
        latest_blind_spectral <= args.blind_operator_drift_gate
    )

    # HARD FREEZE.
    frozen_payload["cutoffs"]=np.asarray(cutoffs,int)
    frozen_payload["free_levels"]=np.asarray(free,float)
    frozen_payload["fisher_median_dev"]=np.asarray([fisher_median],float)
    frozen_payload["xi_accessed_during_freeze"]=np.asarray([False])
    frozen_payload["zero_ordinates_used"]=np.asarray([False])

    frozen_npz=Path(str(prefix)+"_FROZEN_PRE_XI.npz")
    np.savez_compressed(frozen_npz,**frozen_payload)
    fhash=sha256_file(frozen_npz)

    manifest_path=Path(str(prefix)+"_FROZEN_MANIFEST.json")
    manifest={
        "version":VERSION,
        "build":BUILD,
        "sha256":fhash,
        "frozen_npz":str(frozen_npz),
        "firewall":{
            "Xi_during_construction":False,
            "zeta_during_construction":False,
            "known_zero_ordinates":False,
            "zero_fitted_parameters":False,
        },
        "raw_source":"unchanged pure Mangoldt/Gamma Abel prime-phase quantization",
        "metric_law":"d log g_k / d log X = sqrt(I_k / development_median_I); det G=1 gauge",
        "connection_law":"C=psi dpsi^T-dpsi psi^T; nearest-neighbor energy-scaled covariant connection",
        "prexi_gates":prexi_gates,
        "parameters":vars(args),
    }
    manifest_path.write_text(json.dumps(json_safe(manifest),indent=2),encoding="utf-8")

    print("[pre-Xi] latest blind spectrum drift :",f"{latest_blind_spectral:.9e}")
    print("[pre-Xi] gates                       :",prexi_gates)
    print("[freeze] SHA256                     :",fhash)
    print("[freeze] Xi firewall CLOSED.")

    # ------------------------------------------------------------------
    # STAGE D: post-freeze Xi identity.
    # ------------------------------------------------------------------
    v86=importlib.import_module(args.v86_module)
    mp.mp.dps=args.xi_dps
    xi0=v86.Xi_t(0)

    # Xi Taylor power sums for H^{-2n}.
    xi_sums,odd_max=v86.xi_power_sums(
        args.moment_order,mp.mpf(args.xi_radius),args.xi_samples
    )

    # Xi crossings extracted only now.
    xi_zeros=xi_sign_change_zeros(v86,args.identity_max,args.zero_scan_step)

    score_rows=[]
    zero_rows=[]
    identity_rows=[]
    scores={}

    # real identity grid through multiple crossings
    tgrid=[]
    t=0.0
    while t<=args.identity_max+1e-12:
        tgrid.append(round(t,12))
        t+=args.identity_step

    for name,H in final_models.items():
        eig=np.sort(np.linalg.eigvalsh(hermitian(H)).real)
        pos=eig[eig>1e-10]

        # No post-freeze scale fit: energies are used exactly as frozen.
        mom_errs=[]
        for n in range(1,args.moment_order+1):
            pred=float(np.sum(pos**(-2*n)))
            target=float(xi_sums[n-1])
            rel=abs(pred-target)/max(abs(target),1e-300)
            mom_errs.append(rel)
            score_rows.append({
                "model":name,
                "moment_n":n,
                "operator_inverse_power_trace":pred,
                "xi_power_sum":target,
                "relative_error":rel,
            })

        zm=zero_metrics(pos,xi_zeros,args.zero_match_count)
        for j in range(int(zm["count"])):
            zero_rows.append({
                "model":name,
                "index":j+1,
                "operator_energy":float(pos[j]),
                "xi_crossing_postfreeze":float(xi_zeros[j]),
                "error":float(pos[j]-xi_zeros[j]),
                "relative_error":float((pos[j]-xi_zeros[j])/xi_zeros[j]),
            })

        errs=[]
        for tt in tgrid:
            xt=v86.Xi_t(mp.mpf(tt))/xi0
            target=complex(float(mp.re(xt)),float(mp.im(xt)))
            D=determinant_from_energies(pos,complex(tt,0.0))
            e=symmetric_error(D,target)
            errs.append(e)
            identity_rows.append({
                "model":name,
                "t":tt,
                "xi_norm_real":target.real,
                "xi_norm_imag":target.imag,
                "D_real":D.real,
                "D_imag":D.imag,
                "symmetric_error":e,
            })

        scores[name]={
            "moment_relative_rms":rms(mom_errs),
            "zero_metrics":zm,
            "identity_symmetric_rms":rms(errs),
            "minimum_energy":float(pos[0]) if len(pos) else float("nan"),
            "maximum_energy":float(pos[-1]) if len(pos) else float("nan"),
        }

    full=scores["full"]
    controls={k:v for k,v in scores.items() if k!="full"}
    best_control_zero=min(
        controls.items(),
        key=lambda kv: kv[1]["zero_metrics"]["relative_rmse"]
        if math.isfinite(kv[1]["zero_metrics"]["relative_rmse"])
        else float("inf")
    )
    best_control_identity=min(
        controls.items(),
        key=lambda kv: kv[1]["identity_symmetric_rms"]
    )

    post_gates={
        "zero_relative_rmse":(
            math.isfinite(full["zero_metrics"]["relative_rmse"])
            and full["zero_metrics"]["relative_rmse"]<=args.zero_relative_rmse_gate
        ),
        "identity_symmetric_rms":(
            full["identity_symmetric_rms"]<=args.identity_symmetric_rms_gate
        ),
        "full_beats_zero_controls":(
            full["zero_metrics"]["relative_rmse"]
            < best_control_zero[1]["zero_metrics"]["relative_rmse"]
        ),
        "full_beats_identity_controls":(
            full["identity_symmetric_rms"]
            < best_control_identity[1]["identity_symmetric_rms"]
        ),
    }

    if all(prexi_gates.values()) and all(post_gates.values()):
        verdict="PASS_V90_FISHER_METRIC_COVARIANT_OPERATOR_SIGNAL__NEXT_INFINITE_LIMIT_THEOREM"
    elif all(prexi_gates.values()):
        verdict="PARTIAL_V90_WELL_DEFINED_ROT_OPERATOR__XI_IDENTITY_FAILS"
    else:
        verdict="FAIL_V90_ROT_FISHER_METRIC_OPERATOR_NOT_CUTOFF_STABLE"

    # outputs
    raw_csv=Path(str(prefix)+"_RAW_STATES.csv")
    fisher_csv=Path(str(prefix)+"_FISHER_STEPS.csv")
    metric_csv=Path(str(prefix)+"_METRIC_MODES.csv")
    op_csv=Path(str(prefix)+"_OPERATORS.csv")
    drift_csv=Path(str(prefix)+"_CUTOFF_DRIFT.csv")
    moments_csv=Path(str(prefix)+"_XI_MOMENTS.csv")
    zeros_csv=Path(str(prefix)+"_XI_ZERO_MATCH.csv")
    identity_csv=Path(str(prefix)+"_XI_IDENTITY.csv")
    verdict_json=Path(str(prefix)+"_VERDICT.json")
    theorem_md=Path(str(prefix)+"_THEOREM_TARGET.md")

    write_csv(raw_csv,records)
    write_csv(fisher_csv,fisher_steps)
    write_csv(metric_csv,metric_rows)
    write_csv(op_csv,operator_rows)
    write_csv(drift_csv,drift_rows)
    write_csv(moments_csv,score_rows)
    write_csv(zeros_csv,zero_rows)
    write_csv(identity_csv,identity_rows)

    packet={
        "version":VERSION,
        "build":BUILD,
        "verdict":verdict,
        "RH_proof":False,
        "complete_Hilbert_Polya_theorem":False,
        "operator_is_non_diagonal":True,
        "operator_is_ROT_recursive_metric_connection":True,
        "Xi_used_during_construction":False,
        "known_zero_ordinates_used_during_construction":False,
        "fisher_median_development":fisher_median,
        "prexi_gates":prexi_gates,
        "postfreeze_gates":post_gates,
        "full_score":full,
        "best_control_zero":best_control_zero[0],
        "best_control_zero_score":best_control_zero[1],
        "best_control_identity":best_control_identity[0],
        "best_control_identity_score":best_control_identity[1],
        "xi_crossings_found_postfreeze":len(xi_zeros),
        "odd_log_xi_coefficient_max":mp.nstr(odd_max,40),
        "frozen_sha256":fhash,
        "outputs":{
            "frozen_npz":str(frozen_npz),
            "manifest":str(manifest_path),
            "raw_states":str(raw_csv),
            "fisher_steps":str(fisher_csv),
            "metric_modes":str(metric_csv),
            "operators":str(op_csv),
            "cutoff_drift":str(drift_csv),
            "xi_moments":str(moments_csv),
            "xi_zero_match":str(zeros_csv),
            "xi_identity":str(identity_csv),
            "theorem_target":str(theorem_md),
            "verdict":str(verdict_json),
        },
        "runtime_seconds":time.time()-t0,
    }
    verdict_json.write_text(json.dumps(json_safe(packet),indent=2),encoding="utf-8")

    theorem_md.write_text(r"""# ROT-RH v90 theorem target

For arithmetic resolution \(X\), let \(D_X=\operatorname{diag}(E_k(X))\) be
the raw zero-free prime/Gamma level operator in the fixed level-index basis.

Let \(\psi_X\) be the normalized signed arithmetic displacement state and let
the mode-resolved Fisher metric satisfy

\[
\frac{d\log g_k}{d\log X}
=
\sqrt{\frac{I_k(X)}{I_{\rm dev}}},
\qquad
\prod_k g_k=1.
\]

Let the projective recursive connection be

\[
C_X=\psi_X\dot\psi_X^T-\dot\psi_X\psi_X^T
\]

and let \(A_X\) be its nearest-neighbor energy-scaled antisymmetric realization.

The finite covariant operator is

\[
H_X
=
G_X^{-1/2}
\left(D_X+iA_X\right)
G_X^{-1/2}.
\]

The analytic target is to show that these finite operators converge, on a
single level-index Hilbert space and with a well-defined infinite recursive
metric/connection, to a self-adjoint unbounded \(H_{\rm ROT}\), and then prove

\[
\det\nolimits_2\!\left(I-t^2 H_{\rm ROT}^{-2}\right)
=
\frac{\Xi(t)}{\Xi(0)}
\]

(or the correctly regularized determinant variant dictated by the proven
Schatten class).

No post-freeze numerical agreement can replace those theorems.
""",encoding="utf-8")

    print("\n"+"="*154)
    print("FINAL CONSERVATIVE VERDICT")
    print("="*154)
    print("verdict                         :",verdict)
    print("latest blind spectral drift     :",f"{latest_blind_spectral:.9e}")
    print("pre-Xi gates                    :",prexi_gates)
    print("Xi crossings found post-freeze  :",len(xi_zeros))
    print("full zero relative RMSE         :",f"{full['zero_metrics']['relative_rmse']:.9e}")
    print("full Xi determinant RMS         :",f"{full['identity_symmetric_rms']:.9e}")
    print("full inverse-moment RMS         :",f"{full['moment_relative_rms']:.9e}")
    print("best zero control               :",best_control_zero[0],
          f"{best_control_zero[1]['zero_metrics']['relative_rmse']:.9e}")
    print("best identity control           :",best_control_identity[0],
          f"{best_control_identity[1]['identity_symmetric_rms']:.9e}")
    print("post-freeze gates               :",post_gates)
    print("Xi used during construction     : FALSE")
    print("zero ordinates supplied         : FALSE")
    print("RH proof                        : FALSE")
    print("complete HP theorem             : FALSE")
    print("frozen manifest                 :",manifest_path)
    print("verdict file                    :",verdict_json)
    print("runtime seconds                 :",f"{time.time()-t0:.2f}")
    print("="*154)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
