#!/usr/bin/env python3
"""
rot_rh_suzuki_halfshift_sign_v3.py

Fresh ROT–RH half-shift attack using Suzuki's weighted summatory criterion.

No Riemann zero ordinates are used.
No zeta/xi evaluations are required.

For omega > 0 define

    c_omega(n) = n^omega * prod_{p|n} (1 - p^(-2 omega))

and Suzuki's integrated kernel g_omega^{<1>}(r), 0 < r <= 1.

Then

    h_omega^{<1>}(x)
        = (1/x) sum_{n<=x} c_omega(n) g_omega^{<1>}(n/x),

and we audit

    Y_omega(x) = sqrt(x) h_omega^{<1>}(x).

Suzuki proves:
  * eventual one-sign behavior of h_omega^{<1>} is sufficient for
    Theta_omega to be inner in C_+;
  * existence of lim_{x->infty} Y_omega(x) is also sufficient;
  * under RH, Y_omega(x) -> 1 for every omega > 0.

Thus the subcritical range 0 < omega < 1/2 is a direct arithmetic
half-shift target.

The computation is arithmetic-only:
  - prime sieve
  - c_omega(n)
  - incomplete beta functions

Outputs:
  <prefix>_TRACK.csv
  <prefix>_OMEGA_SUMMARY.csv
  <prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm

try:
    from scipy.special import beta as beta_fn
    from scipy.special import betaincc, gamma
except Exception as exc:
    raise SystemExit(
        "This script requires scipy. Install with: python -m pip install scipy"
    ) from exc


def parse_floats(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    root = int(math.isqrt(nmax))
    for p in tqdm(range(2, root + 1), desc="Sieve", unit="p"):
        if sieve[p]:
            sieve[p * p : nmax + 1 : p] = False
    return np.flatnonzero(sieve)


def c_omega_array(nmax, omega, primes):
    n = np.arange(nmax + 1, dtype=np.float64)
    c = np.zeros(nmax + 1, dtype=np.float64)
    c[1:] = np.power(n[1:], omega)

    for p in primes:
        factor = 1.0 - float(p) ** (-2.0 * omega)
        c[p::p] *= factor

    return c


def upper_beta(z, a, b):
    # scipy.betaincc is the complemented regularized incomplete beta.
    # Multiplying by B(a,b) gives integral_z^1 t^(a-1)(1-t)^(b-1) dt.
    return beta_fn(a, b) * betaincc(a, b, z)


def g_integrated(r, omega):
    """
    Suzuki g_omega^{<1>}(r), vectorized for 0 < r <= 1.
    """
    r = np.asarray(r, dtype=np.float64)
    r = np.clip(r, np.finfo(float).tiny, 1.0)

    if abs(omega - 0.5) < 1e-13:
        sq = np.sqrt(np.maximum(0.0, 1.0 - r * r))
        return (
            2.0
            / np.sqrt(r)
            * (
                2.0 * sq
                + np.log(r)
                - np.log1p(sq)
            )
        )

    a1 = (3.0 - 2.0 * omega) / 2.0
    a2 = (5.0 - 2.0 * omega) / 4.0

    ub1 = upper_beta(r * r, a1, omega)
    ub2 = upper_beta(r * r, a2, omega)

    pref = (
        (4.0 * omega / (2.0 * omega - 1.0))
        * (math.pi ** omega)
        / gamma(omega)
    )

    return pref * (
        np.power(r, omega - 1.0) * ub1
        - ((2.0 * omega + 1.0) / (4.0 * omega))
        * np.power(r, -0.5)
        * ub2
    )


def make_checkpoints(xmin, xmax, points):
    vals = np.geomspace(float(xmin), float(xmax), int(points))
    vals = np.unique(np.rint(vals).astype(np.int64))
    vals = vals[(vals >= xmin) & (vals <= xmax)]
    if vals[-1] != xmax:
        vals = np.append(vals, xmax)
    return vals


def compute_track_for_omega(c, omega, checkpoints, chunk_terms):
    rows = []

    for x in tqdm(
        checkpoints,
        desc=f"omega={omega:g}",
        unit="x",
        leave=False,
    ):
        x = int(x)
        total = 0.0

        for start in range(1, x + 1, chunk_terms):
            stop = min(x + 1, start + chunk_terms)
            n = np.arange(start, stop, dtype=np.float64)
            r = n / float(x)
            g = g_integrated(r, omega)
            total += float(np.dot(c[start:stop], g))

        h1 = total / float(x)
        y = math.sqrt(float(x)) * h1

        rows.append((omega, x, h1, y, y - 1.0, abs(y - 1.0)))

    return rows


def tail_metrics(rows, tail_fraction):
    arr = np.asarray(rows, dtype=float)
    n = len(arr)
    i0 = max(0, min(n - 1, int(math.floor(tail_fraction * n))))
    tail = arr[i0:]

    h = tail[:, 2]
    y = tail[:, 3]
    x = tail[:, 1]

    pos_fraction = float(np.mean(h > 0.0))
    neg_fraction = float(np.mean(h < 0.0))
    nonzero = h[np.abs(h) > 0.0]

    if len(nonzero) == 0:
        single_sign = False
        sign = 0
    else:
        signs = np.sign(nonzero)
        single_sign = bool(np.all(signs == signs[0]))
        sign = int(signs[0]) if single_sign else 0

    # Crude tail slope in log x for Y-1. This is diagnostic only.
    # Use absolute residual where nonzero.
    resid = np.abs(y - 1.0)
    mask = resid > 1e-15
    slope = None
    slope_r2 = None
    if np.count_nonzero(mask) >= 3:
        lx = np.log(x[mask])
        lr = np.log(resid[mask])
        A = np.column_stack([np.ones_like(lx), lx])
        coef, *_ = np.linalg.lstsq(A, lr, rcond=None)
        fit = A @ coef
        ss_res = float(np.sum((lr - fit) ** 2))
        ss_tot = float(np.sum((lr - np.mean(lr)) ** 2))
        slope = float(coef[1])
        slope_r2 = None if ss_tot == 0 else float(1.0 - ss_res / ss_tot)

    return {
        "tail_start_x": int(tail[0, 1]),
        "tail_points": int(len(tail)),
        "positive_fraction": pos_fraction,
        "negative_fraction": neg_fraction,
        "single_sign": single_sign,
        "single_sign_value": sign,
        "Y_last": float(y[-1]),
        "Y_tail_min": float(np.min(y)),
        "Y_tail_max": float(np.max(y)),
        "Y_tail_mean": float(np.mean(y)),
        "Y_tail_rms_deviation_from_1": float(
            np.sqrt(np.mean((y - 1.0) ** 2))
        ),
        "Y_tail_max_abs_deviation_from_1": float(np.max(np.abs(y - 1.0))),
        "log_abs_residual_slope": slope,
        "log_abs_residual_slope_r2": slope_r2,
    }


def main():
    ap = argparse.ArgumentParser(
        description="Arithmetic-only Suzuki half-shift sign/limit audit."
    )
    ap.add_argument(
        "--omegas",
        default="0.5,0.4,0.3,0.2,0.1,0.05",
        help="Comma-separated positive omega values.",
    )
    ap.add_argument("--x-min", type=int, default=100)
    ap.add_argument("--x-max", type=int, default=200000)
    ap.add_argument("--checkpoints", type=int, default=70)
    ap.add_argument("--chunk-terms", type=int, default=100000)
    ap.add_argument(
        "--tail-fraction",
        type=float,
        default=0.55,
        help="Fraction of track discarded before tail diagnostics.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_suzuki_halfshift_sign_v3",
    )
    args = ap.parse_args()

    omegas = parse_floats(args.omegas)

    if any(w <= 0 for w in omegas):
        raise SystemExit("Every omega must be > 0.")
    if args.x_min < 2 or args.x_max < args.x_min:
        raise SystemExit("Require 2 <= x-min <= x-max.")
    if not (0.0 <= args.tail_fraction < 1.0):
        raise SystemExit("--tail-fraction must lie in [0,1).")

    checkpoints = make_checkpoints(
        args.x_min, args.x_max, args.checkpoints
    )

    print("=" * 118)
    print("ROT-RH SUZUKI HALF-SHIFT / WEIGHTED-SUMMATORY SIGN AUDIT v3")
    print("=" * 118)
    print(f"omegas                         : {omegas}")
    print(f"x range                        : [{args.x_min:,}, {args.x_max:,}]")
    print(f"checkpoints                    : {len(checkpoints)}")
    print(f"chunk terms                    : {args.chunk_terms:,}")
    print(f"tail fraction                  : {args.tail_fraction}")
    print("Riemann zero ordinates used    : NO")
    print("zeta / xi evaluations used     : NO")
    print()

    primes = prime_sieve(args.x_max)
    print(f"primes <= x_max                : {len(primes):,}")

    all_rows = []
    summaries = []

    for omega in omegas:
        print(f"\nBuilding c_omega(n) for omega={omega:g} ...")
        c = c_omega_array(args.x_max, omega, primes)

        rows = compute_track_for_omega(
            c,
            omega,
            checkpoints,
            args.chunk_terms,
        )
        all_rows.extend(rows)

        metrics = tail_metrics(rows, args.tail_fraction)
        metrics["omega"] = omega
        summaries.append(metrics)

        print(
            f"omega={omega:g}: "
            f"Y_last={metrics['Y_last']:.9f}, "
            f"tail=[{metrics['Y_tail_min']:.9f}, "
            f"{metrics['Y_tail_max']:.9f}], "
            f"single_sign={metrics['single_sign']}, "
            f"positive_fraction={metrics['positive_fraction']:.3f}"
        )

    track_arr = np.asarray(all_rows, dtype=float)
    track_csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        track_csv,
        track_arr,
        delimiter=",",
        header="omega,x,h1,Y_sqrtx_h1,Y_minus_1,abs_Y_minus_1",
        comments="",
    )

    summary_csv = Path(f"{args.prefix}_OMEGA_SUMMARY.csv")
    with summary_csv.open("w", encoding="utf-8") as f:
        f.write(
            "omega,tail_start_x,tail_points,positive_fraction,"
            "negative_fraction,single_sign,single_sign_value,"
            "Y_last,Y_tail_min,Y_tail_max,Y_tail_mean,"
            "Y_tail_rms_deviation_from_1,"
            "Y_tail_max_abs_deviation_from_1,"
            "log_abs_residual_slope,log_abs_residual_slope_r2\n"
        )
        for s in summaries:
            f.write(
                f"{s['omega']},{s['tail_start_x']},{s['tail_points']},"
                f"{s['positive_fraction']},{s['negative_fraction']},"
                f"{int(s['single_sign'])},{s['single_sign_value']},"
                f"{s['Y_last']},{s['Y_tail_min']},{s['Y_tail_max']},"
                f"{s['Y_tail_mean']},"
                f"{s['Y_tail_rms_deviation_from_1']},"
                f"{s['Y_tail_max_abs_deviation_from_1']},"
                f"{'' if s['log_abs_residual_slope'] is None else s['log_abs_residual_slope']},"
                f"{'' if s['log_abs_residual_slope_r2'] is None else s['log_abs_residual_slope_r2']}\n"
            )

    result = {
        "version": 3,
        "construction": "Suzuki weighted summatory half-shift criterion",
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "omegas": omegas,
        "x_min": args.x_min,
        "x_max": args.x_max,
        "checkpoints": [int(x) for x in checkpoints],
        "tail_fraction": args.tail_fraction,
        "omega_summaries": summaries,
        "interpretation": {
            "theorem_target": (
                "For each fixed omega>0, eventual single-sign behavior of "
                "h_omega^{<1>}(x), or existence of lim sqrt(x) h_omega^{<1>}(x), "
                "is sufficient for Theta_omega to be inner. Extending this through "
                "all omega>0 would imply RH."
            ),
            "expected_under_RH": (
                "sqrt(x) h_omega^{<1>}(x) -> 1 for each omega>0."
            ),
            "warning": (
                "Finite numerical positivity is evidence only. It does not prove "
                "eventual sign constancy or existence of the infinite-x limit."
            ),
        },
        "files": {
            "track": str(track_csv),
            "omega_summary": str(summary_csv),
        },
    }

    summary_json = Path(f"{args.prefix}_SUMMARY.json")
    summary_json.write_text(json.dumps(result, indent=2))

    print("\n" + "-" * 118)
    print("SUMMARY")
    print("-" * 118)
    for s in summaries:
        print(
            f"omega={s['omega']:<7g} "
            f"Y_last={s['Y_last']:+.9f}  "
            f"tail_min={s['Y_tail_min']:+.9f}  "
            f"tail_max={s['Y_tail_max']:+.9f}  "
            f"single_sign={s['single_sign']}  "
            f"pos_frac={s['positive_fraction']:.3f}"
        )
    print(f"\ntrack CSV                       : {track_csv}")
    print(f"omega summary CSV               : {summary_csv}")
    print(f"summary JSON                    : {summary_json}")
    print()
    print("Primary attack signature:")
    print("  1. For subcritical omega<1/2, h^{<1>}_omega stays one sign on increasingly late holdouts.")
    print("  2. Y_omega(x)=sqrt(x)h^{<1>}_omega(x) remains bounded and stabilizes.")
    print("  3. Ideally Y_omega(x) contracts toward 1 as x_max is increased.")
    print("  4. The real theorem still requires an all-x tail proof, not finite computation.")
    print("=" * 118)


if __name__ == "__main__":
    main()
