#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v88 — Recursive Novelty-Filtered Transport Kernel / Xi Fredholm Audit
============================================================================

MOTIVATION FROM v87 (PRE-Xi STRUCTURAL FAILURE)
-----------------------------------------------
v87 repaired literal rank collapse (49/49 supported directions) but the spectral
mass still collapsed:

    effective rank ~ 1.66 at d=49,
    lambda_max(K) ~ 0.85 while Tr(K)=1.

The post-freeze ablation "no_curvature" also beat the full model strongly.
This suggests two Xi-blind corrections:

1) CURVATURE IS TRANSPORT, NOT POSITIVE SPECTRAL MASS.
   Keep C=i[A,S] in the ROT observer dynamics, projector torque, chi loading and
   H_obs construction, but do NOT inject (C P)(C P)^* as an independent PSD
   atom into K.

2) RECURSIVE OBSERVATION SHOULD SUPPRESS REDUNDANT DIRECTIONS.
   Before a new response R_n enters K, remove the part already saturated by the
   current recursive kernel.  With

       Khat = K / ||K||_op,
       N    = (I - Khat)^(1/2),

   define the novelty-filtered response

       R_n^nov = N R_n N / Tr(N R_n N).

   This is Xi-blind, basis-independent and causal.  It operationalizes the ROT
   idea that recursive observation removes informational redundancy rather than
   repeatedly counting the same observer mode.

RAW TRANSPORT RESPONSE
----------------------
Using G=A-S, Q=I-P:

    R_core = P / Tr(P)
    R_gap  = (G P)(G P)^* / Tr(...)
    R_if   = (Q H_obs P)(Q H_obs P)^* / Tr(...)

with endogenous weights proportional to

    kappa, 1-chi, ||Q H_obs P||_F/(1+||Q H_obs P||_F).

Curvature remains active in the actual ROT dynamics but is not counted as an
independent positive-mass channel.

RECURSION
---------
Use the parameter-free causal Cesaro flow

    K_{n+1} = K_n + (R_n^nov - K_n)/(n+1).

HILBERT-POLYA CANDIDATE
-----------------------
    H_ROT = s K_ROT^(-1/2)

on supp(K_ROT).

POST-FREEZE TARGET
------------------
Only after every candidate/control operator is serialized and SHA256 hashed:

    det(I - t^2 K_ROT/s^2) ?= Xi(t)/Xi(0).

No Riemann zero ordinates are used.

CONTROLS
--------
    no_novelty_filter       same transport response without redundancy removal
    direct_curvature_mass   restores the v87 direct curvature PSD channel
    no_curvature            removes curvature from the ROT dynamics
    no_observer_feedback
    shuffled_prime_shells

A numerical PASS is not an RH proof.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import mpmath as mp
import numpy as np

VERSION = "v88"
BUILD = "2026-08-17-rot-novelty-filtered-transport-kernel-v88"
EPS = 1.0e-13


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (complex, np.complexfloating)):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, mp.mpf):
        return mp.nstr(x, 50)
    if isinstance(x, mp.mpc):
        return {"real": mp.nstr(mp.re(x), 50), "imag": mp.nstr(mp.im(x), 50)}
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for k in row:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fro(x: np.ndarray) -> float:
    return float(np.linalg.norm(x, "fro"))


def trace_normalize_psd(R: np.ndarray) -> Optional[np.ndarray]:
    R = 0.5 * (R + R.conj().T)
    tr = float(np.trace(R).real)
    if tr <= EPS:
        return None
    return R / tr


def spectral_stats(K: np.ndarray, support_tol: float) -> Dict[str, float]:
    K = 0.5 * (K + K.conj().T)
    lam = np.linalg.eigvalsh(K).real
    lam_pos = np.maximum(lam, 0.0)
    tr = float(np.sum(lam_pos))
    if tr <= EPS:
        return {
            "support_rank": 0,
            "effective_rank": 0.0,
            "top_fraction": float("nan"),
            "min_eig": float(np.min(lam)),
            "max_eig": float(np.max(lam)),
        }
    p = lam_pos / tr
    pp = p[p > 1e-15]
    erank = float(np.exp(-np.sum(pp * np.log(pp))))
    maxlam = float(np.max(lam_pos))
    support = int(np.sum(lam_pos > support_tol * max(maxlam, EPS)))
    return {
        "support_rank": support,
        "effective_rank": erank,
        "top_fraction": float(np.max(p)),
        "min_eig": float(np.min(lam)),
        "max_eig": float(np.max(lam)),
    }


def novelty_filter(K: np.ndarray, R: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    """
    Canonical causal redundancy-complement filter:
        Khat = K/lambda_max(K)
        N = sqrt(I-Khat)
        Rout = N R N / Tr(N R N)

    No Xi information and no adjustable gain.
    """
    d = K.shape[0]
    K = 0.5 * (K + K.conj().T)
    R = 0.5 * (R + R.conj().T)

    lam, U = np.linalg.eigh(K)
    lam = np.maximum(np.real(lam), 0.0)
    lmax = float(np.max(lam)) if len(lam) else 0.0
    if lmax <= EPS:
        out = trace_normalize_psd(R)
        if out is None:
            out = np.eye(d, dtype=np.complex128) / d
        return out, {
            "redundancy_top": 0.0,
            "novelty_trace_before_norm": float(np.trace(R).real),
            "novelty_fallback": 0.0,
        }

    khat = np.clip(lam / lmax, 0.0, 1.0)
    nsqrt = np.sqrt(np.maximum(1.0 - khat, 0.0))
    N = U @ np.diag(nsqrt) @ U.conj().T
    Rn = 0.5 * (N @ R @ N + (N @ R @ N).conj().T)
    trn = float(np.trace(Rn).real)

    if trn <= EPS:
        out = trace_normalize_psd(R)
        if out is None:
            out = np.eye(d, dtype=np.complex128) / d
        return out, {
            "redundancy_top": 1.0,
            "novelty_trace_before_norm": trn,
            "novelty_fallback": 1.0,
        }

    return Rn / trn, {
        "redundancy_top": 1.0,
        "novelty_trace_before_norm": trn,
        "novelty_fallback": 0.0,
    }


@dataclass(frozen=True)
class ModelSpec:
    name: str
    no_novelty: bool = False
    direct_curvature_mass: bool = False
    no_curvature: bool = False
    no_observer_feedback: bool = False
    shuffle_shells: bool = False


@dataclass
class FrozenModel:
    name: str
    d: int
    K: np.ndarray
    H_observer: np.ndarray
    seed: np.ndarray
    support_rank: int
    effective_rank: float
    top_eigen_fraction: float
    min_K_eig: float
    max_K_eig: float
    K_hermitian_residual: float
    H_hermitian_residual: float
    Herglotz_min_imag: float
    recursion_rows: List[Dict[str, object]]
    canonical_H: np.ndarray
    canonical_energies: np.ndarray


def response_operator(
    base,
    A: np.ndarray,
    S: np.ndarray,
    P: np.ndarray,
    Hobs: np.ndarray,
    kappa: float,
    chi: float,
    include_direct_curvature_mass: bool,
) -> Tuple[np.ndarray, Dict[str, float]]:
    d = A.shape[0]
    I = np.eye(d, dtype=np.complex128)
    Q = I - P
    G = base.trace_zero(A - S)
    C = base.trace_zero(1j * (A @ S - S @ A))

    items: List[Tuple[str, Optional[np.ndarray], float]] = []

    Rcore = trace_normalize_psd(P)
    items.append(("core", Rcore, max(float(kappa), 0.0)))

    Bgap = G @ P
    Rgap = trace_normalize_psd(Bgap @ Bgap.conj().T)
    items.append(("gap", Rgap, max(1.0 - float(chi), 0.0)))

    Bif = Q @ Hobs @ P
    Rif = trace_normalize_psd(Bif @ Bif.conj().T)
    coupling = fro(Bif)
    wif = coupling / (1.0 + coupling)
    items.append(("interface", Rif, max(wif, 0.0)))

    if include_direct_curvature_mass:
        Bcurv = C @ P
        Rcurv = trace_normalize_psd(Bcurv @ Bcurv.conj().T)
        items.append(("curvature", Rcurv, max(float(chi), 0.0)))

    good = [(n, R, w) for n, R, w in items if R is not None and w > 0.0]
    if not good:
        R = trace_normalize_psd(P)
        if R is None:
            R = np.eye(d, dtype=np.complex128) / d
        return R, {
            "w_core": 1.0,
            "w_gap": 0.0,
            "w_interface": 0.0,
            "w_curvature_mass": 0.0,
            "active_channels": 1.0,
        }

    sw = sum(w for _, _, w in good)
    weights = {"core": 0.0, "gap": 0.0, "interface": 0.0, "curvature": 0.0}
    Rtot = np.zeros((d, d), dtype=np.complex128)
    for name, R, w in good:
        wn = w / sw
        Rtot += wn * R
        weights[name] = wn

    Rtot = trace_normalize_psd(Rtot)
    if Rtot is None:
        Rtot = np.eye(d, dtype=np.complex128) / d

    return Rtot, {
        "w_core": float(weights["core"]),
        "w_gap": float(weights["gap"]),
        "w_interface": float(weights["interface"]),
        "w_curvature_mass": float(weights["curvature"]),
        "active_channels": float(len(good)),
    }


def run_model(base, v86, shells, X: int, d: int, args, spec: ModelSpec) -> FrozenModel:
    rng = np.random.default_rng(args.seed + 6151 * d + sum(ord(c) for c in spec.name))
    order = np.arange(len(shells))
    if spec.shuffle_shells:
        order = rng.permutation(order)

    A = np.zeros((d, d), dtype=np.complex128)
    S = np.zeros((d, d), dtype=np.complex128)
    K = np.zeros((d, d), dtype=np.complex128)
    prev_A = A.copy()
    prev_P: Optional[np.ndarray] = None
    prev_kappa: Optional[float] = None

    final_H = np.zeros((d, d), dtype=np.complex128)
    final_seed = np.zeros(d, dtype=np.complex128)
    final_seed[0] = 1.0
    rows: List[Dict[str, object]] = []

    for seq, shell_idx in enumerate(order):
        shell = shells[int(shell_idx)]

        # Compact recursive phase forcing; arithmetic is not the operator law.
        u = v86.winding_source_vector(shell, d, X)
        Qsrc = v86.source_matrix_from_vector(u, base)

        Cprev = base.trace_zero(1j * (A @ S - S @ A))
        Cmatch, _ = base.norm_match(Cprev, Qsrc)
        Anew = base.trace_zero(
            args.active_memory * A
            + (1.0 - args.active_memory) * Qsrc
            + args.drive_curvature * Cmatch
        )
        Snew = base.trace_zero(
            args.shadow_memory * S
            + (1.0 - args.shadow_memory) * prev_A
        )
        prev_A = A.copy()
        A, S = Anew, Snew

        target = base.observer_target_projector(
            A, S,
            args.observer_target,
            args.observer_rank,
            args.observer_curvature_penalty,
        )
        P, obs_diag = base.evolve_observer_projector(
            A, S, target, prev_P,
            args.observer_memory,
            0.0 if spec.no_curvature else args.curvature_torque,
            args.mismatch_torque,
        )

        instantaneous, _ = base.kappa_instantaneous_source(
            A, S, P, args.kappa_source
        )

        if spec.no_curvature:
            load = 0.0
        else:
            load, _ = base.bounded_curvature_load(A, S, P, prev_P)

        kappa = base.evolve_kappa(
            instantaneous,
            prev_kappa,
            args.kappa_memory,
            load,
            args.kappa_curvature_drain,
        )
        chi = float(load / (load + kappa + EPS)) if not spec.no_curvature else 0.0

        Hobs, hdiag = base.build_observer_operator(
            A, S, P, kappa, chi,
            args.source_gain,
            args.curvature_mix,
            use_curvature_source=not spec.no_curvature,
            use_kappa_feedback=True,
            observer_feedback=not spec.no_observer_feedback,
        )

        Rraw, rdiag = response_operator(
            base, A, S, P, Hobs, kappa, chi,
            include_direct_curvature_mass=spec.direct_curvature_mass,
        )

        if spec.no_novelty:
            R = Rraw
            ndiag = {
                "redundancy_top": float("nan"),
                "novelty_trace_before_norm": float(np.trace(Rraw).real),
                "novelty_fallback": 0.0,
            }
        else:
            R, ndiag = novelty_filter(K, Rraw)

        # Parameter-free causal Cesaro recursion.
        eta = 1.0 / float(seq + 1)
        Kprev = K.copy()
        K = K + eta * (R - K)
        K = 0.5 * (K + K.conj().T)

        stats = spectral_stats(K, args.support_tol)
        drift = fro(K - Kprev) / max(fro(K), EPS)
        seed, interface = base.observer_interface_vector(P, Hobs)

        rows.append({
            "model": spec.name,
            "dimension": d,
            "sequence_step": seq,
            "shell_index": int(shell_idx),
            "shell_prime_min": int(shell[0]),
            "shell_prime_max": int(shell[-1]),
            "shell_prime_count": int(len(shell)),
            "cesaro_eta": eta,
            "kappa_instantaneous": float(instantaneous),
            "kappa": float(kappa),
            "curvature_load": float(load),
            "chi": float(chi),
            "observer_motion": float(obs_diag.get("observer_motion", 0.0)),
            "interface_coupling": float(interface),
            "w_core": rdiag["w_core"],
            "w_gap": rdiag["w_gap"],
            "w_interface": rdiag["w_interface"],
            "w_curvature_mass": rdiag["w_curvature_mass"],
            "active_channels": rdiag["active_channels"],
            "novelty_trace_before_norm": ndiag["novelty_trace_before_norm"],
            "novelty_fallback": ndiag["novelty_fallback"],
            "kernel_trace": float(np.trace(K).real),
            "kernel_effective_rank": stats["effective_rank"],
            "kernel_top_eigen_fraction": stats["top_fraction"],
            "kernel_step_relative_drift": drift,
            "core_scale": float(hdiag.get("core_scale", 1.0)),
            "coupling_scale": float(hdiag.get("coupling_scale", 1.0)),
            "transverse_scale": float(hdiag.get("transverse_scale", 1.0)),
        })

        prev_P = P.copy()
        prev_kappa = float(kappa)
        final_H = Hobs.copy()
        final_seed = seed.copy()

    stats = spectral_stats(K, args.support_tol)
    kres = fro(K - K.conj().T) / max(fro(K), EPS)
    Hcan, energies, _ = v86.build_hp_from_kernel(
        K, 2.0 * math.pi, args.support_tol
    )
    hres = fro(Hcan - Hcan.conj().T) / max(fro(Hcan), EPS)
    him = v86.herglotz_min_imag(
        Hcan,
        final_seed,
        parse_floats(args.herglotz_real),
        parse_floats(args.herglotz_imag),
    )

    return FrozenModel(
        name=spec.name,
        d=d,
        K=K,
        H_observer=final_H,
        seed=final_seed,
        support_rank=int(stats["support_rank"]),
        effective_rank=float(stats["effective_rank"]),
        top_eigen_fraction=float(stats["top_fraction"]),
        min_K_eig=float(stats["min_eig"]),
        max_K_eig=float(stats["max_eig"]),
        K_hermitian_residual=float(kres),
        H_hermitian_residual=float(hres),
        Herglotz_min_imag=float(him),
        recursion_rows=rows,
        canonical_H=Hcan,
        canonical_energies=np.sort(energies),
    )


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="v88 novelty-filtered ROT transport kernel -> post-freeze Xi Fredholm audit"
    )
    p.add_argument(
        "--rot-module",
        default="rot_rh_recursive_observer_jacobi_convergence_audit_v2_2",
    )
    p.add_argument(
        "--v86-module",
        default="rot_rh_rot_native_recursive_hp_xi_identity_v86",
    )

    p.add_argument("--prime-cutoff", type=int, default=200000)
    p.add_argument("--prime-shells", type=int, default=96)
    p.add_argument("--dimensions", default="17,25,33,49")

    p.add_argument("--active-memory", type=float, default=0.88)
    p.add_argument("--shadow-memory", type=float, default=0.94)
    p.add_argument("--drive-curvature", type=float, default=0.10)

    p.add_argument(
        "--observer-target",
        choices=["midpoint_principal", "gap_extremal", "curvature_minimizing"],
        default="gap_extremal",
    )
    p.add_argument("--observer-rank", type=int, default=1)
    p.add_argument("--observer-memory", type=float, default=0.90)
    p.add_argument("--curvature-torque", type=float, default=0.50)
    p.add_argument("--mismatch-torque", type=float, default=0.50)
    p.add_argument("--observer-curvature-penalty", type=float, default=0.50)
    p.add_argument(
        "--kappa-source",
        choices=["occupancy", "combined", "observer_world"],
        default="combined",
    )
    p.add_argument("--kappa-memory", type=float, default=0.90)
    p.add_argument("--kappa-curvature-drain", type=float, default=0.25)
    p.add_argument("--curvature-mix", type=float, default=0.25)
    p.add_argument("--source-gain", type=float, default=0.50)

    p.add_argument("--support-tol", type=float, default=1e-12)
    p.add_argument("--herglotz-real", default="0,10,25,50,100")
    p.add_argument("--herglotz-imag", default="0.5,1.0,2.0")

    p.add_argument("--xi-dps", type=int, default=90)
    p.add_argument("--xi-radius", default="4")
    p.add_argument("--xi-samples", type=int, default=1024)
    p.add_argument("--moment-order", type=int, default=6)
    p.add_argument("--identity-real", default="0,2,4,6,8,10,12")
    p.add_argument("--identity-imag", default="0,0.5,1.0")

    # Pre-Xi structural gates.
    p.add_argument("--dimension-drift-gate", type=float, default=0.15)
    p.add_argument("--support-fraction-gate", type=float, default=0.90)
    p.add_argument("--effective-rank-fraction-gate", type=float, default=0.15)
    p.add_argument("--top-eigen-fraction-gate", type=float, default=0.50)

    # Post-freeze exploratory gates.
    p.add_argument("--moment-rms-gate", type=float, default=0.25)
    p.add_argument("--identity-rms-gate", type=float, default=0.25)
    p.add_argument("--control-margin", type=float, default=0.05)

    p.add_argument("--seed", type=int, default=20260817)
    p.add_argument("--strict", action="store_true")
    p.add_argument("--prefix", default="rot_rh_novelty_filtered_transport_kernel_v88")
    return p


def main() -> int:
    args = parser().parse_args()
    t0 = time.time()

    dims = sorted(set(parse_ints(args.dimensions)))
    if len(dims) < 2:
        raise ValueError("Need at least two dimensions.")
    if min(dims) < 5:
        raise ValueError("All dimensions must be >=5.")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    base = importlib.import_module(args.rot_module)
    v86 = importlib.import_module(args.v86_module)

    print("=" * 152)
    print("ROT-RH v88 — RECURSIVE NOVELTY-FILTERED TRANSPORT KERNEL / Xi FREDHOLM AUDIT")
    print("=" * 152)
    print("build                         :", BUILD)
    print("prime cutoff / shells         :", args.prime_cutoff, args.prime_shells)
    print("dimensions                    :", dims)
    print("curvature role                : transport/torque only (no direct PSD mass)")
    print("redundancy rule               : N=sqrt(I-K/||K||op), R->NRN/Tr")
    print("kernel recursion              : causal Cesaro average")
    print("Xi used during construction   : FALSE")
    print("zero ordinates used           : FALSE")
    print("=" * 152)

    primes = v86.sieve_primes(args.prime_cutoff)
    shells = v86.prime_shells(primes, args.prime_cutoff, args.prime_shells)
    print(f"[forcing] primes={len(primes)} nonempty_shells={len(shells)}")

    full_models: Dict[int, FrozenModel] = {}
    recursion_rows: List[Dict[str, object]] = []

    for d in dims:
        print(f"[freeze/full] d={d}", flush=True)
        fm = run_model(base, v86, shells, args.prime_cutoff, d, args, ModelSpec("full"))
        full_models[d] = fm
        recursion_rows.extend(fm.recursion_rows)
        print(
            f"  support={fm.support_rank:2d}/{d} "
            f"erank={fm.effective_rank:.4f} "
            f"top={fm.top_eigen_fraction:.4f} "
            f"minK={fm.min_K_eig:+.3e} "
            f"min Im m={fm.Herglotz_min_imag:.3e}"
        )

    dmax = dims[-1]
    control_specs = [
        ModelSpec("no_novelty_filter", no_novelty=True),
        ModelSpec("direct_curvature_mass", direct_curvature_mass=True),
        ModelSpec("no_curvature", no_curvature=True),
        ModelSpec("no_observer_feedback", no_observer_feedback=True),
        ModelSpec("shuffled_prime_shells", shuffle_shells=True),
    ]
    controls: Dict[str, FrozenModel] = {}
    for spec in control_specs:
        print(f"[freeze/control] {spec.name}", flush=True)
        fm = run_model(base, v86, shells, args.prime_cutoff, dmax, args, spec)
        controls[spec.name] = fm
        recursion_rows.extend(fm.recursion_rows)

    # Pre-Xi dimension convergence by trace-normalized power moments.
    dim_rows = []
    norm_mom: Dict[int, np.ndarray] = {}
    for d, fm in full_models.items():
        lam = np.maximum(np.linalg.eigvalsh(fm.K).real, 0.0)
        x = lam / max(float(np.sum(lam)), EPS)
        nm = np.asarray(
            [np.sum(x ** n) for n in range(1, args.moment_order + 1)],
            dtype=float,
        )
        norm_mom[d] = nm
        dim_rows.append({
            "dimension": d,
            "support_rank": fm.support_rank,
            "support_fraction": fm.support_rank / d,
            "effective_rank": fm.effective_rank,
            "effective_rank_fraction": fm.effective_rank / d,
            "top_eigen_fraction": fm.top_eigen_fraction,
            "K_trace": float(np.trace(fm.K).real),
            "K_min_eig": fm.min_K_eig,
            "K_max_eig": fm.max_K_eig,
            "K_hermitian_residual": fm.K_hermitian_residual,
            "H_hermitian_residual": fm.H_hermitian_residual,
            "Herglotz_min_imag": fm.Herglotz_min_imag,
            "canonical_energy_min": float(np.min(fm.canonical_energies)),
            "canonical_energy_max": float(np.max(fm.canonical_energies)),
        })

    pair_rows = []
    drifts = []
    for da, db in zip(dims[:-1], dims[1:]):
        a, b = norm_mom[da], norm_mom[db]
        drift = float(np.sqrt(np.mean(
            ((b[1:] - a[1:]) / np.maximum(np.abs(a[1:]), 1e-15)) ** 2
        )))
        drifts.append(drift)
        pair_rows.append({
            "dimension_a": da,
            "dimension_b": db,
            "normalized_power_moment_relative_rms_drift": drift,
        })

    latest_drift = drifts[-1]
    full = full_models[dmax]
    structural_gates = {
        "K_hermitian": full.K_hermitian_residual <= 1e-11,
        "K_positive_semidefinite": full.min_K_eig >= -1e-11,
        "H_hermitian": full.H_hermitian_residual <= 1e-11,
        "Herglotz_positive": full.Herglotz_min_imag > 0.0,
        "support_fraction": (full.support_rank / dmax) >= args.support_fraction_gate,
        "effective_rank_fraction": (full.effective_rank / dmax) >= args.effective_rank_fraction_gate,
        "top_eigen_not_dominant": full.top_eigen_fraction <= args.top_eigen_fraction_gate,
        "dimension_shape_stabilizes": latest_drift <= args.dimension_drift_gate,
    }

    print("[pre-Xi] latest dimension drift       :", f"{latest_drift:.6e}")
    print("[pre-Xi] support fraction             :", f"{full.support_rank/dmax:.6f}")
    print("[pre-Xi] effective-rank fraction      :", f"{full.effective_rank/dmax:.6f}")
    print("[pre-Xi] top eigen fraction           :", f"{full.top_eigen_fraction:.6f}")
    print("[pre-Xi] structural gates             :", structural_gates)

    # HARD FREEZE
    frozen_npz = Path(str(prefix) + "_FROZEN_PRE_XI.npz")
    payload = {
        "dimensions": np.asarray(dims, dtype=int),
        "prime_cutoff": np.asarray([args.prime_cutoff], dtype=int),
        "xi_accessed_during_freeze": np.asarray([False]),
        "zero_ordinates_used": np.asarray([False]),
    }
    for d, fm in full_models.items():
        payload[f"K_full_d{d}"] = fm.K
        payload[f"seed_full_d{d}"] = fm.seed
    for name, fm in controls.items():
        payload[f"K_{name}_d{dmax}"] = fm.K
        payload[f"seed_{name}_d{dmax}"] = fm.seed
    np.savez_compressed(frozen_npz, **payload)
    fhash = sha256_file(frozen_npz)

    manifest_path = Path(str(prefix) + "_FROZEN_MANIFEST.json")
    manifest_path.write_text(
        json.dumps(json_safe({
            "version": VERSION,
            "build": BUILD,
            "sha256": fhash,
            "frozen_npz": str(frozen_npz),
            "firewall": {
                "Xi_during_construction": False,
                "zeta_during_construction": False,
                "zero_ordinates_anywhere": False,
                "parameters_tuned_to_Xi": False,
            },
            "pre_Xi_structural_gates": structural_gates,
            "parameters": vars(args),
        }), indent=2),
        encoding="utf-8",
    )
    print("[freeze] sha256                      :", fhash)
    print("[freeze] Xi firewall CLOSED.")

    # POST-FREEZE Xi
    mp.mp.dps = args.xi_dps
    xi_sums, odd_max = v86.xi_power_sums(
        args.moment_order,
        mp.mpf(args.xi_radius),
        args.xi_samples,
    )
    points = [
        complex(x, y)
        for y in parse_floats(args.identity_imag)
        for x in parse_floats(args.identity_real)
    ]

    score_models = {"full": full, **controls}
    scores: Dict[str, Dict[str, object]] = {}
    moment_rows: List[Dict[str, object]] = []
    grid_rows: List[Dict[str, object]] = []

    for name, fm in score_models.items():
        print(f"[post-freeze/score] {name}", flush=True)
        sc = v86.score_model_against_xi(
            fm, xi_sums, points, args.moment_order
        )
        scores[name] = sc
        moment_rows.extend(sc["moment_rows"])
        grid_rows.extend(sc["grid_rows"])
        print(
            f"  scale*={sc['scale_star']:.9g} "
            f"moment_holdout={sc['holdout_moment_rel_rms']:.6e} "
            f"identity={sc['one_constant_identity_rel_rms']:.6e}"
        )

    full_sc = scores["full"]
    identity_gates = {
        "heldout_power_moments": float(full_sc["holdout_moment_rel_rms"]) <= args.moment_rms_gate,
        "direct_Xi_determinant_grid": float(full_sc["one_constant_identity_rel_rms"]) <= args.identity_rms_gate,
    }

    full_shape = (
        float(full_sc["holdout_moment_rel_rms"])
        + float(full_sc["one_constant_identity_rel_rms"])
    )
    control_scores = []
    for name, sc in scores.items():
        if name == "full":
            continue
        val = (
            float(sc["holdout_moment_rel_rms"])
            + float(sc["one_constant_identity_rel_rms"])
        )
        if math.isfinite(val):
            control_scores.append((val, name))
    if control_scores:
        best_control_value, best_control_name = min(control_scores)
        control_pass = full_shape <= (1.0 - args.control_margin) * best_control_value
    else:
        best_control_value, best_control_name, control_pass = float("nan"), None, False

    structural_pass = all(structural_gates.values())
    identity_pass = all(identity_gates.values())

    if structural_pass and identity_pass and control_pass:
        verdict = (
            "PASS_V88_ROT_NOVELTY_KERNEL_AND_POSTFREEZE_XI_SHAPE__"
            "NEXT_TARGET_INFINITE_TRACE_NORM_THEOREM"
        )
    elif structural_pass and identity_pass:
        verdict = (
            "PARTIAL_V88_OPERATOR_AND_XI_SHAPE_PASS__"
            "BUT_FULL_ROT_DOES_NOT_BEAT_CONTROLS"
        )
    elif structural_pass:
        verdict = (
            "PARTIAL_V88_PRE_XI_OPERATOR_HEALTHY__"
            "XI_FREDHOLM_IDENTITY_STILL_FAILS"
        )
    else:
        verdict = "FAIL_V88_PRE_XI_OPERATOR_STILL_NOT_IN_INFINITE_HP_REGIME"

    recursion_csv = Path(str(prefix) + "_RECURSION.csv")
    dimensions_csv = Path(str(prefix) + "_DIMENSIONS.csv")
    drift_csv = Path(str(prefix) + "_DIMENSION_DRIFT.csv")
    moments_csv = Path(str(prefix) + "_XI_POWER_MOMENTS.csv")
    identity_csv = Path(str(prefix) + "_XI_IDENTITY_GRID.csv")
    verdict_json = Path(str(prefix) + "_VERDICT.json")
    theorem_md = Path(str(prefix) + "_THEOREM_TARGET.md")

    write_csv(recursion_csv, recursion_rows)
    write_csv(dimensions_csv, dim_rows)
    write_csv(drift_csv, pair_rows)
    write_csv(moments_csv, moment_rows)
    write_csv(identity_csv, grid_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "complete_Hilbert_Polya_theorem": False,
        "operator_is_ROT_recursive": True,
        "operator_is_diagonal_root_packaging": False,
        "Xi_used_during_construction": False,
        "zero_ordinates_used": False,
        "pre_Xi_structural_gates": structural_gates,
        "postfreeze_identity_gates": identity_gates,
        "full": {
            "dimension": dmax,
            "support_rank": full.support_rank,
            "support_fraction": full.support_rank/dmax,
            "effective_rank": full.effective_rank,
            "effective_rank_fraction": full.effective_rank/dmax,
            "top_eigen_fraction": full.top_eigen_fraction,
            "latest_dimension_drift": latest_drift,
            "K_min_eigenvalue": full.min_K_eig,
            "Herglotz_min_imag": full.Herglotz_min_imag,
            "scale_star_postfreeze": float(full_sc["scale_star"]),
            "heldout_moment_relative_rms": float(full_sc["holdout_moment_rel_rms"]),
            "raw_2pi_identity_relative_rms": float(full_sc["raw_identity_rel_rms"]),
            "one_constant_identity_relative_rms": float(full_sc["one_constant_identity_rel_rms"]),
        },
        "control_test": {
            "full_shape_score": full_shape,
            "best_control_name": best_control_name,
            "best_control_shape_score": best_control_value,
            "required_margin": args.control_margin,
            "pass": control_pass,
        },
        "odd_log_Xi_coefficient_max": mp.nstr(odd_max, 40),
        "frozen_sha256": fhash,
        "outputs": {
            "frozen_npz": str(frozen_npz),
            "manifest": str(manifest_path),
            "recursion": str(recursion_csv),
            "dimensions": str(dimensions_csv),
            "dimension_drift": str(drift_csv),
            "xi_power_moments": str(moments_csv),
            "xi_identity_grid": str(identity_csv),
            "theorem_target": str(theorem_md),
            "verdict": str(verdict_json),
        },
        "runtime_seconds": time.time() - t0,
    }
    verdict_json.write_text(
        json.dumps(json_safe(packet), indent=2),
        encoding="utf-8",
    )

    theorem_md.write_text(r"""# ROT-RH v88 theorem target

The finite model defines the raw ROT transport response

\[
R_n=w_cR_{\rm core}+w_gR_{\rm gap}+w_iR_{\rm interface},
\]

while recursive curvature remains in the causal observer dynamics rather than
being inserted as an independent positive spectral-mass atom.

Recursive redundancy is removed causally by

\[
\widehat K_n=K_n/\|K_n\|_{\rm op},\qquad
N_n=(I-\widehat K_n)^{1/2},
\]

\[
\widetilde R_n=
\frac{N_nR_nN_n}{\operatorname{Tr}(N_nR_nN_n)},
\]

followed by the Cesaro recursion

\[
K_{n+1}=K_n+\frac{\widetilde R_{n+1}-K_n}{n+1}.
\]

The analytic target is to prove that, in the joint infinite prime-shell and
winding-space limit,

\[
K_N\to K_{\rm ROT}
\]

in trace norm, with \(K_{\rm ROT}\) positive, compact, trace-class and
injective; then

\[
H_{\rm ROT}=sK_{\rm ROT}^{-1/2}
\]

should be self-adjoint on its natural domain and satisfy

\[
\det\!\left(I-\frac{t^2}{s^2}K_{\rm ROT}\right)
=
\frac{\Xi(t)}{\Xi(0)}
\]

for all complex \(t\).

The post-freeze one-constant scale is only a falsification diagnostic.  A proof
must derive \(s\) independently from ROT/arithmetic physics.
""", encoding="utf-8")

    print("\n" + "=" * 152)
    print("FINAL CONSERVATIVE VERDICT")
    print("=" * 152)
    print("verdict                         :", verdict)
    print("support rank                    :", f"{full.support_rank}/{dmax}")
    print("effective rank                  :", f"{full.effective_rank:.9g}")
    print("effective-rank fraction         :", f"{full.effective_rank/dmax:.9g}")
    print("top eigen fraction              :", f"{full.top_eigen_fraction:.9g}")
    print("latest dimension drift          :", f"{latest_drift:.9e}")
    print("min K eigenvalue                :", f"{full.min_K_eig:+.9e}")
    print("Herglotz min Im                 :", f"{full.Herglotz_min_imag:+.9e}")
    print("scale* post-freeze              :", f"{float(full_sc['scale_star']):.12g}")
    print("heldout moment relative RMS     :", f"{float(full_sc['holdout_moment_rel_rms']):.9e}")
    print("raw 2pi Xi identity rel RMS     :", f"{float(full_sc['raw_identity_rel_rms']):.9e}")
    print("1-constant Xi identity rel RMS  :", f"{float(full_sc['one_constant_identity_rel_rms']):.9e}")
    print("best control                    :", best_control_name, best_control_value)
    print("control margin pass             :", control_pass)
    print("Xi used during construction     : FALSE")
    print("zero ordinates used             : FALSE")
    print("RH proof                        : FALSE")
    print("complete HP theorem             : FALSE")
    print("frozen manifest                 :", manifest_path)
    print("verdict file                    :", verdict_json)
    print("runtime seconds                 :", f"{time.time()-t0:.2f}")
    print("=" * 152)

    if args.strict and not structural_pass:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
