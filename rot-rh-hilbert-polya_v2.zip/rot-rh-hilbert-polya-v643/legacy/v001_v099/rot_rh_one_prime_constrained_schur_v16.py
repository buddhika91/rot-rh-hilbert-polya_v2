#!/usr/bin/env python3
"""
rot_rh_one_prime_constrained_schur_v16.py

ROT-RH v16 — exact one-prime constrained Schur / bonding-channel reduction.

No Riemann zero ordinates.
No zeta / xi evaluations.

Window
------
Let tau = log 2 and

    tau/2 < L < (log 3)/2.

Then the only active prime power in the compact-support Weil form is n=2.

Split [-L,L] into

    Z1 = [-L, L-tau]          left boundary strip
    Z2 = [L-tau, tau-L]       prime-free center
    Z3 = [tau-L, L]           right boundary strip.

The left/right strip width is

    h = 2L-tau,

and the center half-width is tau-L < tau/2.

Compressed prime translation
----------------------------
S = P_L T_tau P_L is a partial isometry

    Z1 -> Z3,

with
    S^2=0,
    S^*S=P_Z1,
    SS^*=P_Z3.

Thus J=S+S^* is an involution on Z1⊕Z3.  In matched translated
orthonormal bases it is exactly

        J_B = [[0,I],
               [I,0]].

The prime-2 Weil contribution is

    -w2 J_B,       w2=log(2)/sqrt(2).

Bonding/antibonding coordinates diagonalize it:

    U^* J_B U = diag(+I,-I),

so the prime contributes
    -w2 I  on the bonding channel,
    +w2 I  on the antibonding channel.

Pole constraints and the correct Schur complement
-------------------------------------------------
The two admissibility constraints are

    ∫ f(x)e^(+x/2) dx = 0,
    ∫ f(x)e^(-x/2) dx = 0.

They couple boundary and center.  Therefore the naive Schur complement
using M_CC^{-1} is WRONG.

Let M be the compressed Archimedean operator Omega(D), partitioned into
boundary B=Z1⊕Z3 and center C=Z2.  Write constraints as

    C_B b + C_C c = 0.

The exact constrained center elimination is the KKT saddle system

        K_C = [[M_CC, C_C^*],
               [C_C,   0   ]].

The effective Archimedean boundary operator is

    S_arch =
        M_BB
        - [M_BC, C_B^*] K_C^{-1} [M_CB; C_B].

The full one-prime effective boundary operator is

    S_full = S_arch - w2 J_B.

After bonding/antibonding transformation:

    U^* S_full U =
      [[A_++ - w2 I, A_+-],
       [A_-+,        A_-- + w2 I]].

If A_--+w2 I > 0, positivity is equivalent to the final single-channel
Schur complement

    S_bond =
       A_++ - w2 I
       - A_+- (A_--+w2 I)^(-1) A_-+  >= 0.

Thus the entire one-prime problem reduces to ONE boundary channel living
on an interval of width

    0 < h < log(3/2).

Numerics
--------
Use orthonormal Legendre bases separately on Z1,Z2,Z3.  The Z3 basis is
the exact translate of the Z1 basis, so the prime block is algebraically
the identity.  The Archimedean matrix is assembled from

    Omega(r)=Re digamma(1/4+i r/2)-log(pi)

using Fourier transforms of the compactly supported Legendre basis.

The script independently checks:
  * direct full constrained Galerkin minimum;
  * constrained-center KKT Schur inertia;
  * exact J_B involution;
  * bonding/antibonding reduction;
  * final bonding Schur sign.

Finite Galerkin positivity remains an audit, not a proof.

Outputs
-------
<prefix>_SCAN.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma, spherical_jn
from scipy.linalg import null_space


TAU = math.log(2.0)
W2 = math.log(2.0) / math.sqrt(2.0)


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def legendre_ft(r, left, right, degree):
    """
    Fourier transform ∫ phi_n(x) exp(i r x) dx of the normalized
    Legendre basis on [left,right].

    phi_n(x)=sqrt((2n+1)/ell) P_n((x-c)/d),
    ell=right-left, d=ell/2, c=(left+right)/2.

    ∫_{-1}^1 P_n(u)e^{izu}du = 2 i^n j_n(z).
    """
    r = np.asarray(r, dtype=float)
    ell = right - left
    d = 0.5 * ell
    c = 0.5 * (left + right)

    z = r * d
    # scipy spherical_jn on negative real z has parity built in for integer n
    jn = spherical_jn(degree, z)
    pref = math.sqrt(ell * (2*degree + 1))
    return pref * (1j ** degree) * jn * np.exp(1j * r * c)


def zone_ft_matrix(r, left, right, ndeg):
    F = np.empty((len(r), ndeg), dtype=np.complex128)
    for n in range(ndeg):
        F[:, n] = legendre_ft(r, left, right, n)
    return F


def pole_vector(left, right, ndeg, sign, qpoints=220):
    """
    C_n = ∫ phi_n(x) exp(sign*x/2) dx,
    sign = +1 or -1.
    """
    nodes, weights = np.polynomial.legendre.leggauss(qpoints)
    ell = right-left
    d = 0.5*ell
    c = 0.5*(left+right)
    x = c + d*nodes

    # recurrence via numpy.polynomial.legendre.legval
    out = np.empty(ndeg, dtype=np.float64)
    ex = np.exp(sign*0.5*x)

    for n in range(ndeg):
        coeff = np.zeros(n+1)
        coeff[-1] = 1.0
        Pn = np.polynomial.legendre.legval(nodes, coeff)
        phi = math.sqrt((2*n+1)/ell) * Pn
        out[n] = d * np.dot(weights, phi*ex)

    return out.astype(np.complex128)


def arch_matrix(L, ndeg, rmax, rpoints):
    """
    Build Archimedean matrix in zone order [Z1,Z2,Z3].
    """
    z1 = (-L, L-TAU)
    z2 = (L-TAU, TAU-L)
    z3 = (TAU-L, L)

    nodes, weights = np.polynomial.legendre.leggauss(rpoints)
    r = rmax * nodes
    wr = rmax * weights

    F1 = zone_ft_matrix(r, *z1, ndeg)
    F2 = zone_ft_matrix(r, *z2, ndeg)
    F3 = zone_ft_matrix(r, *z3, ndeg)
    F = np.hstack([F1,F2,F3])

    Om = np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)
    WF = (wr*Om)[:,None] * F
    M = (F.conj().T @ WF)/(2.0*math.pi)
    return 0.5*(M+M.conj().T), (z1,z2,z3)


def constraint_matrix(zones, ndeg):
    rows = []
    for sign in (+1,-1):
        pieces = [pole_vector(*z, ndeg, sign) for z in zones]
        rows.append(np.concatenate(pieces))
    return np.vstack(rows)


def prime_J(ndeg):
    Z = np.zeros((ndeg,ndeg), dtype=np.complex128)
    I = np.eye(ndeg, dtype=np.complex128)
    # zone order [left,center,right]
    return np.block([
        [Z, Z, I],
        [Z, Z, Z],
        [I, Z, Z],
    ])


def boundary_J(ndeg):
    Z=np.zeros((ndeg,ndeg),complex)
    I=np.eye(ndeg,dtype=complex)
    return np.block([[Z,I],[I,Z]])


def bonding_unitary(ndeg):
    I=np.eye(ndeg,dtype=np.complex128)
    return (1.0/math.sqrt(2.0))*np.block([[I,I],[I,-I]])


def herm(A):
    return 0.5*(A+A.conj().T)


def inertia(A, tol=1e-9):
    e=np.linalg.eigvalsh(herm(A))
    return {
        "min": float(e[0]),
        "max": float(e[-1]),
        "neg": int(np.sum(e < -tol)),
        "zero": int(np.sum(np.abs(e) <= tol)),
        "pos": int(np.sum(e > tol)),
    }, e


def one_case(L, ndeg, rmax, rpoints, check_factor):
    M, zones = arch_matrix(L, ndeg, rmax, rpoints)
    M2, _ = arch_matrix(
        L, ndeg, rmax*check_factor,
        max(rpoints+200, int(rpoints*check_factor))
    )
    arch_delta=float(np.linalg.norm(M2-M,ord=2))
    M=M2

    C=constraint_matrix(zones, ndeg)
    J=prime_J(ndeg)
    H=herm(M-W2*J)

    # Direct constrained full matrix.
    Zfull=null_space(C)
    HN=herm(Zfull.conj().T@H@Zfull)
    direct,e_direct=inertia(HN)

    # Partition B=[left,right], Cn=center.
    il=np.arange(0,ndeg)
    ic=np.arange(ndeg,2*ndeg)
    ir=np.arange(2*ndeg,3*ndeg)
    ib=np.concatenate([il,ir])

    Mbb=M[np.ix_(ib,ib)]
    Mbc=M[np.ix_(ib,ic)]
    Mcb=M[np.ix_(ic,ib)]
    Mcc=M[np.ix_(ic,ic)]

    Cb=C[:,ib]
    Cc=C[:,ic]

    # Verify center positivity on its own pole-neutral subspace.
    Zc=null_space(Cc)
    center_con=herm(Zc.conj().T@Mcc@Zc)
    center_info,e_center=inertia(center_con)

    # KKT constrained Schur complement.
    KKT=np.block([
        [Mcc, Cc.conj().T],
        [Cc, np.zeros((2,2),dtype=np.complex128)]
    ])
    RHS=np.vstack([Mcb,Cb])
    LEFT=np.hstack([Mbc,Cb.conj().T])

    # solve instead of explicit inverse
    X=np.linalg.solve(KKT,RHS)
    Sarch=herm(Mbb-LEFT@X)

    Jb=boundary_J(ndeg)
    j_res=float(np.linalg.norm(Jb@Jb-np.eye(2*ndeg),ord=2))
    Sfull=herm(Sarch-W2*Jb)
    bfull,e_bfull=inertia(Sfull)

    # Bonding/antibonding.
    U=bonding_unitary(ndeg)
    Ab=herm(U.conj().T@Sarch@U)
    App=Ab[:ndeg,:ndeg]
    Apm=Ab[:ndeg,ndeg:]
    Amp=Ab[ndeg:,:ndeg]
    Amm=Ab[ndeg:,ndeg:]

    Kminus=herm(Amm+W2*np.eye(ndeg))
    minus_info,e_minus=inertia(Kminus)

    if e_minus[0] > 1e-10:
        Y=np.linalg.solve(Kminus,Amp)
        Sbond=herm(App-W2*np.eye(ndeg)-Apm@Y)
        bond_info,e_bond=inertia(Sbond)
    else:
        Sbond=None
        bond_info={"min":float("nan"),"max":float("nan"),"neg":-1,"zero":-1,"pos":-1}

    # Inertia should match between Sfull and the final Schur if Kminus positive.
    return {
        "L":L,
        "h_boundary":2*L-TAU,
        "center_halfwidth":TAU-L,
        "direct":direct,
        "center":center_info,
        "boundary_full":bfull,
        "minus":minus_info,
        "bond":bond_info,
        "arch_delta":arch_delta,
        "J_involution_residual":j_res,
        "constraint_rank":int(np.linalg.matrix_rank(C)),
        "center_constraint_rank":int(np.linalg.matrix_rank(Cc)),
        "dims":{
            "full":3*ndeg,
            "admissible":Zfull.shape[1],
            "center_null":Zc.shape[1],
            "boundary":2*ndeg,
            "bond":ndeg,
        },
        "inertia_match_direct_boundary": (
            direct["neg"]==bfull["neg"] and direct["zero"]==bfull["zero"]
        ),
        "inertia_match_boundary_bond": (
            minus_info["neg"]==0 and minus_info["zero"]==0
            and bfull["neg"]==bond_info["neg"]
            and bfull["zero"]==bond_info["zero"]
        ),
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--L-values",
        default="0.35,0.37,0.40,0.45,0.50,0.545,0.5490",
    )
    ap.add_argument("--degrees",type=int,default=18)
    ap.add_argument("--rmax",type=float,default=260.0)
    ap.add_argument("--rpoints",type=int,default=2000)
    ap.add_argument("--check-factor",type=float,default=1.30)
    ap.add_argument(
        "--prefix",
        default="rot_rh_one_prime_constrained_schur_v16",
    )
    A=ap.parse_args()

    Lvals=parse_floats(A.L_values)
    lo=TAU/2
    hi=math.log(3.0)/2
    for L in Lvals:
        if not (lo < L < hi):
            raise SystemExit(
                f"L={L} outside one-prime window ({lo},{hi})."
            )

    print("="*126)
    print("ROT-RH v16 — ONE-PRIME CONSTRAINED SCHUR / BONDING REDUCTION")
    print("="*126)
    print(f"one-prime window             : ({lo:.12f},{hi:.12f})")
    print(f"tau=log2                     : {TAU:.12f}")
    print(f"w2=log2/sqrt2                : {W2:.12f}")
    print(f"L values                     : {Lvals}")
    print(f"Legendre degrees / zone      : {A.degrees}")
    print("zero ordinates used          : NO")
    print("zeta / xi used               : NO")
    print()

    cases=[]
    rows=[]

    for L in tqdm(Lvals,desc="L scan",unit="L"):
        c=one_case(L,A.degrees,A.rmax,A.rpoints,A.check_factor)
        cases.append(c)
        rows.append([
            c["L"],c["h_boundary"],c["center_halfwidth"],
            c["direct"]["min"],c["direct"]["neg"],
            c["center"]["min"],c["center"]["neg"],
            c["boundary_full"]["min"],c["boundary_full"]["neg"],
            c["minus"]["min"],c["minus"]["neg"],
            c["bond"]["min"],c["bond"]["neg"],
            c["arch_delta"],c["J_involution_residual"],
            int(c["inertia_match_direct_boundary"]),
            int(c["inertia_match_boundary_bond"]),
        ])

    csv=Path(f"{A.prefix}_SCAN.csv")
    np.savetxt(
        csv,np.asarray(rows,float),delimiter=",",
        header=(
            "L,boundary_width,center_halfwidth,"
            "direct_min,direct_neg,"
            "center_constrained_min,center_neg,"
            "effective_boundary_min,effective_boundary_neg,"
            "antibonding_min,antibonding_neg,"
            "final_bond_min,final_bond_neg,"
            "arch_crosscheck,J_involution_residual,"
            "inertia_direct_boundary_match,inertia_boundary_bond_match"
        ),comments=""
    )

    summary={
        "version":16,
        "zero_ordinates_used":False,
        "zeta_xi_evaluations_used":False,
        "window":{
            "lower":lo,"upper":hi,
            "only_active_prime_power":2,
            "tau":TAU,"w2":W2,
        },
        "exact_geometry":{
            "zones":[
                "Z1=[-L,L-log2]",
                "Z2=[L-log2,log2-L]",
                "Z3=[log2-L,L]",
            ],
            "partial_shift":"S=P_L T_log2 P_L",
            "identities":"S^2=0, S* S=P_Z1, S S*=P_Z3",
            "boundary_J":"J=S+S*, J^2=I on Z1+Z3",
            "bonding":"U*JU=diag(+I,-I)",
        },
        "constraint_correction":{
            "naive_schur":"M_CC^{-1} is not valid because pole constraints couple B and C.",
            "KKT":"[[M_CC,C_C*],[C_C,0]]",
            "effective_arch":"M_BB-[M_BC,C_B*]KKT^{-1}[M_CB;C_B]",
        },
        "final_reduction":{
            "antibonding":"A_--+w2 I is stabilizing.",
            "bonding_schur":"A_++-w2 I-A_+-(A_--+w2 I)^(-1)A_-+",
            "dimension":"one boundary strip of width h=2L-log2 < log(3/2)",
            "meaning":"Full one-prime positivity is equivalent to nonnegativity of this final bonding channel, provided the center constrained block and antibonding block are positive.",
        },
        "cases":cases,
        "files":{"scan":str(csv)},
        "warning":"Finite Legendre/Gauss quadrature is a structural audit, not an analytic proof. The next theorem target is a certified lower bound for the final bonding Schur operator uniformly over the whole one-prime window.",
    }
    js=Path(f"{A.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary,indent=2))

    print("\n"+"-"*126)
    print("SCAN")
    print("-"*126)
    for c in cases:
        print(
            f"L={c['L']:.6f} h={c['h_boundary']:.6f}  "
            f"direct={c['direct']['min']:+.3e}  "
            f"center={c['center']['min']:+.3e}  "
            f"anti={c['minus']['min']:+.3e}  "
            f"bond={c['bond']['min']:+.3e}  "
            f"inertia={c['inertia_match_direct_boundary']}/{c['inertia_match_boundary_bond']} "
            f"archΔ={c['arch_delta']:.1e}"
        )

    print()
    print("Structural verdict:")
    print("  * Gemini's three-zone geometry is correct.")
    print("  * The naive M22^{-1} Schur complement is NOT correct under global pole constraints.")
    print("  * The KKT-constrained center elimination is exact.")
    print("  * Prime 2 is an exact partial-isometry involution on the two boundary strips.")
    print("  * Bonding/antibonding diagonalization leaves one potentially dangerous channel.")
    print("  * The final hard operator lives on width h<log(3/2), not on the full window.")
    print(f"\nscan    : {csv}")
    print(f"summary : {js}")
    print("="*126)


if __name__=="__main__":
    main()
