#!/usr/bin/env python3
"""
rot_rh_pnt_centered_infinite_form_v1.py

Clean-sheet ROT–RH cutoff-removal audit.

No dependency on any previous ROT-RH script or summary file.

Mathematical object
-------------------
Let gamma_E be the Euler–Mascheroni constant and define the centered log-prime
measure on t >= 0,

    dnu(t) = gamma_E delta_0
             + sum_{n>=2} Lambda(n)/n delta_{log n}(t)
             - dt.

Its cumulative primitive is

    C(T) = gamma_E + sum_{n <= exp(T)} Lambda(n)/n - T.

Classical PNT error estimates imply C(T) -> 0.  The cutoff-free arithmetic
quadratic form on H^1(R_+) is

    v_ar[u] = int |u|^2 dnu
            = - int C(t) d|u(t)|^2
            = -2 Re int C(t) conj(u(t)) u'(t) dt.

This script numerically audits:

  1. The centered primitive C(T), using only Lambda(n).
  2. The cutoff-free scalar transform

         A_inf(E) = E int_0^inf C(t) sin(E t) dt

     against the consistently centered exponential cutoff

         A_L(E) =
             gamma_E exp(-1/L)
             + sum Lambda(n)/n exp(-n/L) cos(E log n)
             - int_1^inf exp(-x/L)/x cos(E log x) dx.

  3. Regulator independence of v_ar[u] for smooth H^1 probe functions, using
     exponential, Gaussian, and rational regulators.

  4. Optional analytic audit (NO zero ordinates) of

         A_inf(E) = gamma_E - Re[zeta'(1-iE)/zeta(1-iE)]

     via mpmath.  This is validation only; the arithmetic construction does not
     require zeta evaluations.

The script deliberately does NOT compare against Riemann zero ordinates.  It is
a cutoff-independence test, not a zero-fitting test.

Outputs
-------
<prefix>_C_PRIMITIVE.csv
<prefix>_SCALAR_CUTOFF.csv
<prefix>_FORM_CUTOFF.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm

try:
    import mpmath as mp
except Exception:
    mp = None


GAMMA_E = 0.577215664901532860606512090082402431


def parse_float_list(text):
    if text is None or str(text).strip() == "":
        return []
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def build_prime_power_atoms(nmax):
    """Return sorted arrays (n, Lambda(n), Lambda(n)/n, log n)."""
    nmax = int(nmax)
    if nmax < 2:
        return (
            np.empty(0, dtype=np.int64),
            np.empty(0, dtype=np.float64),
            np.empty(0, dtype=np.float64),
            np.empty(0, dtype=np.float64),
        )

    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    root = int(math.isqrt(nmax))

    for p in tqdm(range(2, root + 1), desc="Sieve", unit="p"):
        if sieve[p]:
            sieve[p * p : nmax + 1 : p] = False

    primes = np.flatnonzero(sieve)
    ns = []
    lams = []

    for p in tqdm(primes, desc="Prime powers", unit="prime"):
        lp = math.log(int(p))
        q = int(p)
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // int(p):
                break
            q *= int(p)

    order = np.argsort(np.asarray(ns, dtype=np.int64))
    n_arr = np.asarray(ns, dtype=np.int64)[order]
    lam_arr = np.asarray(lams, dtype=np.float64)[order]

    # Prime powers are unique as integers: p^k cannot equal q^j for distinct primes.
    w_arr = lam_arr / n_arr.astype(np.float64)
    logn_arr = np.log(n_arr.astype(np.float64))
    return n_arr, lam_arr, w_arr, logn_arr


def primitive_on_grid(t_grid, n_arr, weight_arr):
    cum = np.cumsum(weight_arr, dtype=np.float64)
    x = np.exp(t_grid)
    # searchsorted on integer n; floor is the correct cutoff n <= exp(t)
    idx = np.searchsorted(n_arr, np.floor(x).astype(np.int64), side="right")
    sums = np.zeros_like(t_grid)
    mask = idx > 0
    sums[mask] = cum[idx[mask] - 1]
    return GAMMA_E + sums - t_grid


def trapz(y, x):
    if hasattr(np, "trapezoid"):
        return np.trapezoid(y, x)
    return np.trapz(y, x)


def continuum_exp_cutoff(L, E, dps=50):
    """
    I_L(E) = int_1^inf exp(-x/L) x^{-1} cos(E log x) dx
           = Re[L^(iE) Gamma(iE, 1/L)]   for E != 0.
    """
    if mp is None:
        raise RuntimeError("mpmath is required for the continuum integral.")
    mp.mp.dps = int(dps)
    Lm = mp.mpf(L)
    Em = mp.mpf(E)
    if abs(E) < 1e-15:
        return float(mp.e1(1 / Lm))
    z = 1j * Em
    val = (Lm ** z) * mp.gammainc(z, 1 / Lm, mp.inf)
    return float(mp.re(val))


def scalar_A_from_C(E, t_grid, C_grid):
    if abs(E) < 1e-15:
        return 0.0
    return float(E * trapz(C_grid * np.sin(E * t_grid), t_grid))


def scalar_exp_cutoff(L, E, weight_arr, logn_arr, n_arr, dps=50):
    h_atoms = np.exp(-n_arr.astype(np.float64) / float(L))
    prime_part = float(np.dot(weight_arr * h_atoms, np.cos(E * logn_arr)))
    continuum = continuum_exp_cutoff(L, E, dps=dps)
    boundary = GAMMA_E * math.exp(-1.0 / float(L))
    return boundary + prime_part - continuum


def zeta_boundary_A(E, dps=60):
    if mp is None:
        raise RuntimeError("mpmath is required for --zeta-audit.")
    mp.mp.dps = int(dps)
    E = mp.mpf(E)
    if abs(E) < mp.mpf("1e-30"):
        return 0.0
    s = 1 - 1j * E
    zp = mp.diff(mp.zeta, s)
    return float(GAMMA_E - mp.re(zp / mp.zeta(s)))


def h_profile(profile, t, L):
    r = np.exp(t) / float(L)
    if profile == "exp":
        return np.exp(-r)
    if profile == "gauss":
        return np.exp(-(r * r))
    if profile == "rational":
        return 1.0 / (1.0 + r) ** 2
    raise ValueError(profile)


def h_profile_atoms(profile, n_arr, L):
    r = n_arr.astype(np.float64) / float(L)
    if profile == "exp":
        return np.exp(-r)
    if profile == "gauss":
        return np.exp(-(r * r))
    if profile == "rational":
        return 1.0 / (1.0 + r) ** 2
    raise ValueError(profile)


def probe_g_and_derivative(t, decay, center):
    """
    u(t) = exp[-decay * (t-center)^2 / 2]
    g=|u|^2=exp[-decay*(t-center)^2]
    g'=-2 decay (t-center) g
    """
    g = np.exp(-decay * (t - center) ** 2)
    gp = -2.0 * decay * (t - center) * g
    return g, gp


def direct_form_cutoff(profile, L, decay, center, t_grid, n_arr, weight_arr, logn_arr):
    g0 = math.exp(-decay * center * center)
    g_atoms = np.exp(-decay * (logn_arr - center) ** 2)
    h_atoms = h_profile_atoms(profile, n_arr, L)
    atom_part = float(np.dot(weight_arr * h_atoms, g_atoms))

    h_grid = h_profile(profile, t_grid, L)
    g_grid, _ = probe_g_and_derivative(t_grid, decay, center)
    continuum = float(trapz(h_grid * g_grid, t_grid))

    # For the delta at t=0, x=e^0=1, so the regulator argument is 1/L.
    if profile == "exp":
        h0 = math.exp(-1.0 / float(L))
    elif profile == "gauss":
        h0 = math.exp(-(1.0 / float(L)) ** 2)
    elif profile == "rational":
        h0 = 1.0 / (1.0 + 1.0 / float(L)) ** 2
    else:
        raise ValueError(profile)

    return GAMMA_E * h0 * g0 + atom_part - continuum


def main():
    ap = argparse.ArgumentParser(
        description="Clean-sheet PNT-centered infinite-form / cutoff-independence audit."
    )
    ap.add_argument("--L-values", default="2000,4000,8000,16000,32000,64000")
    ap.add_argument("--tail-factor", type=float, default=24.0)
    ap.add_argument("--N-max", type=int, default=0,
                    help="Prime-power ceiling. 0 => ceil(tail_factor * max(L)).")
    ap.add_argument("--energies", default="5,10,20,30,50,80",
                    help="Arbitrary audit energies; do not supply zero ordinates if running a zero-free audit.")
    ap.add_argument("--t-grid-points", type=int, default=12001)
    ap.add_argument("--probe-decays", default="0.15,0.35,0.75")
    ap.add_argument("--probe-centers", default="1.0,3.0,6.0")
    ap.add_argument("--profiles", default="exp,gauss,rational")
    ap.add_argument("--mp-dps", type=int, default=60)
    ap.add_argument("--zeta-audit", action="store_true",
                    help="Optional validation on Re(s)=1. Does not use zero ordinates.")
    ap.add_argument("--prefix", default="rot_rh_pnt_centered_infinite_form_v1")
    args = ap.parse_args()

    L_values = parse_float_list(args.L_values)
    energies = parse_float_list(args.energies)
    probe_decays = parse_float_list(args.probe_decays)
    probe_centers = parse_float_list(args.probe_centers)
    profiles = [x.strip() for x in args.profiles.split(",") if x.strip()]

    if not L_values:
        raise SystemExit("No L-values supplied.")
    if not energies:
        raise SystemExit("No energies supplied.")

    Lmax = max(L_values)
    nmax = int(args.N_max) if args.N_max > 0 else int(math.ceil(args.tail_factor * Lmax))
    nmax = max(nmax, 100)

    print("=" * 110)
    print("ROT-RH CLEAN-SHEET PNT-CENTERED INFINITE FORM / RESOLVENT AUDIT v1")
    print("=" * 110)
    print(f"L values                  : {L_values}")
    print(f"N max                     : {nmax:,}")
    print(f"tail factor vs max L      : {nmax / Lmax:.3f}")
    print(f"energies                   : {energies}")
    print(f"t-grid points              : {args.t_grid_points}")
    print(f"zeta audit                 : {args.zeta_audit}")
    print("zero ordinates used        : NO")
    print()

    n_arr, lam_arr, weight_arr, logn_arr = build_prime_power_atoms(nmax)
    print(f"prime-power atoms          : {len(n_arr):,}")

    Tmax = math.log(nmax)
    t_grid = np.linspace(0.0, Tmax, int(args.t_grid_points), dtype=np.float64)
    C_grid = primitive_on_grid(t_grid, n_arr, weight_arr)

    primitive_csv = Path(f"{args.prefix}_C_PRIMITIVE.csv")
    np.savetxt(
        primitive_csv,
        np.column_stack([t_grid, np.exp(t_grid), C_grid]),
        delimiter=",",
        header="t,x,C_t",
        comments="",
    )

    # Tail diagnostics of the primitive.
    tail_fracs = [0.50, 0.65, 0.80, 0.90]
    primitive_tail = {}
    for frac in tail_fracs:
        i0 = int(frac * (len(t_grid) - 1))
        primitive_tail[str(frac)] = {
            "t_start": float(t_grid[i0]),
            "max_abs_C": float(np.max(np.abs(C_grid[i0:]))),
            "rms_C": float(np.sqrt(np.mean(C_grid[i0:] ** 2))),
        }

    # Scalar cutoff audit.
    scalar_rows = []
    Ainf_grid = {}
    Azeta = {}
    print("\nScalar centered-transform audit")
    for E in tqdm(energies, desc="Energies", unit="E"):
        Ainf = scalar_A_from_C(E, t_grid, C_grid)
        Ainf_grid[E] = Ainf
        if args.zeta_audit:
            Azeta[E] = zeta_boundary_A(E, dps=args.mp_dps)
        for L in L_values:
            AL = scalar_exp_cutoff(
                L, E, weight_arr, logn_arr, n_arr, dps=args.mp_dps
            )
            scalar_rows.append(
                [
                    E,
                    L,
                    AL,
                    Ainf,
                    AL - Ainf,
                    abs(AL - Ainf),
                    Azeta.get(E, float("nan")),
                    abs(Ainf - Azeta[E]) if E in Azeta else float("nan"),
                ]
            )

    scalar_csv = Path(f"{args.prefix}_SCALAR_CUTOFF.csv")
    np.savetxt(
        scalar_csv,
        np.asarray(scalar_rows, dtype=float),
        delimiter=",",
        header="E,L,A_L_exp,A_inf_from_C,error,signed_abs_placeholder,A_zeta_optional,Ainf_minus_Azeta_abs",
        comments="",
    )
    # Correct the slightly awkward header field name by rewriting it cleanly.
    txt = scalar_csv.read_text()
    txt = txt.replace(
        "error,signed_abs_placeholder",
        "signed_error,abs_error"
    )
    scalar_csv.write_text(txt)

    # Form regulator audit.
    form_rows = []
    print("\nQuadratic-form regulator audit")
    probe_pairs = [(a, c) for a in probe_decays for c in probe_centers]
    for decay, center in tqdm(probe_pairs, desc="Probes", unit="probe"):
        g_grid, gp_grid = probe_g_and_derivative(t_grid, decay, center)
        v_inf = float(-trapz(C_grid * gp_grid, t_grid))

        for profile in profiles:
            for L in L_values:
                vL = direct_form_cutoff(
                    profile,
                    L,
                    decay,
                    center,
                    t_grid,
                    n_arr,
                    weight_arr,
                    logn_arr,
                )
                form_rows.append(
                    [
                        decay,
                        center,
                        {"exp": 0.0, "gauss": 1.0, "rational": 2.0}[profile],
                        L,
                        vL,
                        v_inf,
                        vL - v_inf,
                        abs(vL - v_inf),
                    ]
                )

    form_csv = Path(f"{args.prefix}_FORM_CUTOFF.csv")
    np.savetxt(
        form_csv,
        np.asarray(form_rows, dtype=float),
        delimiter=",",
        header="probe_decay,probe_center,profile_code,L,v_L,v_inf,signed_error,abs_error",
        comments="",
    )

    # Summary metrics.
    scalar_arr = np.asarray(scalar_rows, dtype=float)
    form_arr = np.asarray(form_rows, dtype=float)

    largest_L = max(L_values)
    scalar_last = scalar_arr[np.isclose(scalar_arr[:, 1], largest_L)]
    form_last = form_arr[np.isclose(form_arr[:, 3], largest_L)]

    zeta_max = None
    if args.zeta_audit and Azeta:
        zeta_max = max(abs(Ainf_grid[E] - Azeta[E]) for E in energies)

    # Per-energy error contraction from first L to last L.
    scalar_contract = {}
    for E in energies:
        rows = scalar_arr[np.isclose(scalar_arr[:, 0], E)]
        rows = rows[np.argsort(rows[:, 1])]
        e0 = abs(rows[0, 4])
        e1 = abs(rows[-1, 4])
        scalar_contract[str(E)] = {
            "first_abs_error": float(e0),
            "last_abs_error": float(e1),
            "ratio_last_over_first": float(e1 / e0) if e0 > 0 else None,
        }

    summary = {
        "construction": "PNT-centered log-prime measure",
        "zero_ordinates_used": False,
        "nmax": int(nmax),
        "prime_power_atoms": int(len(n_arr)),
        "L_values": L_values,
        "energies": energies,
        "Tmax": float(Tmax),
        "primitive_C_at_Tmax": float(C_grid[-1]),
        "primitive_tail": primitive_tail,
        "scalar_largest_L_max_abs_error_vs_C_integral": float(np.max(scalar_last[:, 5])),
        "scalar_largest_L_rms_error_vs_C_integral": float(np.sqrt(np.mean(scalar_last[:, 5] ** 2))),
        "scalar_error_contraction": scalar_contract,
        "form_largest_L_max_abs_error": float(np.max(form_last[:, 7])),
        "form_largest_L_rms_abs_error": float(np.sqrt(np.mean(form_last[:, 7] ** 2))),
        "zeta_audit_enabled": bool(args.zeta_audit),
        "zeta_boundary_max_abs_error": None if zeta_max is None else float(zeta_max),
        "profile_codes": {"exp": 0, "gauss": 1, "rational": 2},
        "files": {
            "primitive": str(primitive_csv),
            "scalar": str(scalar_csv),
            "form": str(form_csv),
        },
        "interpretation": {
            "pass_target": (
                "As L increases, centered scalar and form values should approach regulator-independent limits. "
                "The three form regulators should coalesce. Optional zeta audit should agree with "
                "gamma_E - Re[zeta'(1-iE)/zeta(1-iE)] up to arithmetic/grid truncation."
            ),
            "not_tested": (
                "This script does not claim the resulting self-adjoint arithmetic form has the Riemann zeros "
                "as its discrete spectrum. Archimedean confinement and an exact Xi/Fredholm identity remain separate."
            ),
        },
    }

    summary_json = Path(f"{args.prefix}_SUMMARY.json")
    summary_json.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 110)
    print("SUMMARY")
    print("-" * 110)
    print(f"C(Tmax)                                  : {C_grid[-1]: .6e}")
    print(f"scalar max |A_L-A_inf| at largest L      : {summary['scalar_largest_L_max_abs_error_vs_C_integral']:.6e}")
    print(f"form max |v_L-v_inf| at largest L        : {summary['form_largest_L_max_abs_error']:.6e}")
    if args.zeta_audit:
        print(f"max |A_inf-A_zeta|                       : {zeta_max:.6e}")
    print(f"primitive CSV                            : {primitive_csv}")
    print(f"scalar CSV                               : {scalar_csv}")
    print(f"form CSV                                 : {form_csv}")
    print(f"summary JSON                             : {summary_json}")
    print()
    print("Interpretation:")
    print("  - Coalescence across L and across regulator profiles supports the centered cutoff-removal theorem.")
    print("  - Failure to coalesce means the numerical truncation/grid is insufficient OR the implementation is wrong.")
    print("  - Even a perfect pass does NOT yet prove a Hilbert–Polya spectrum; it establishes the infinite arithmetic sector.")
    print("=" * 110)


if __name__ == "__main__":
    main()
