#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v93 — Mode-Resolved Recursive Counterflow Identification Audit
=====================================================================

PURPOSE
-------
v92 produced a striking but internally inconsistent result:

  * every fixed scalar beta lost to persistence on DEVELOPMENT;
  * the selected beta=-0.5 nevertheless gained on 3/4 blind shells;
  * mean blind gain was positive;
  * the real arithmetic trajectory strongly beat scrambled prime controls.

This suggests that the arithmetic Jacobi flow may contain a real recursive
signal, but a SINGLE GLOBAL scalar beta is the wrong compression.

v93 does NOT evaluate Xi, zeta, or Riemann zeros at all.

It asks a narrower question:

    Is the missing recursive response mode-resolved and causally persistent?

For each target transition, using the v92 Jacobi coefficient state

    c_s = [a_1,...,a_d, log b_1,...,log b_{d-1}],

we form the same covariant transport baseline and correction direction

    v_base = R_s v_s,
    d_s    = R_s [g_s A_s].

The actual next velocity satisfies

    v_true = v_base + beta_s d_s + residual.

We identify, ARITHMETICALLY ONLY:

1. scalar oracle beta_s;
2. six blockwise oracle beta values:
       diagonal low / mid / high
       log-offdiagonal low / mid / high;
3. how much blockwise beta reduces residual versus scalar beta;
4. whether beta values persist from one shell to the next.

CAUSAL TEST
-----------
To predict target s, v93 is allowed to use only oracle beta values from
PREVIOUSLY OBSERVED arithmetic transitions.

The parameter-free causal law is

    beta_hat_s(block) = beta_oracle_{s-1}(block).

This is compared with:
    persistence of c_s,
    pure covariant transport beta=0,
    fixed beta=-0.5 from v92,
    previous scalar oracle beta,
    previous blockwise oracle beta.

The same procedure is run on independently scrambled prime-weight trajectories.
If the real arithmetic flow has a genuine recursive mode-resolved law, causal
block-beta transport should improve more consistently than on scrambled
controls.

No Xi scoring is performed in this audit by design.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

VERSION = "v93"
BUILD = "2026-08-17-mode-resolved-recursive-counterflow-identification-v93"
EPS = 1e-14


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def blocks_for_depth(d: int) -> List[Tuple[str, np.ndarray]]:
    """
    Six fixed mode blocks in c=[a(0:d), logb(0:d-1)].
    """
    def thirds(n):
        cuts = [0, n//3, (2*n)//3, n]
        return [(cuts[i], cuts[i+1]) for i in range(3)]

    names = ["low", "mid", "high"]
    out = []
    for name, (lo, hi) in zip(names, thirds(d)):
        idx = np.arange(lo, hi, dtype=int)
        out.append((f"diag_{name}", idx))
    for name, (lo, hi) in zip(names, thirds(d-1)):
        idx = d + np.arange(lo, hi, dtype=int)
        out.append((f"logb_{name}", idx))
    return out


def fit_beta(y: np.ndarray, direction: np.ndarray, idx: np.ndarray | None = None) -> float:
    if idx is not None:
        y = y[idx]
        direction = direction[idx]
    den = float(np.dot(direction, direction))
    if den <= EPS:
        return 0.0
    return float(np.dot(y, direction) / den)


def transition_geometry(v92, states, probs, cutoffs, target_idx, fisher_med):
    i = target_idx
    c0, c1, c2 = states[i-3], states[i-2], states[i-1]
    dl1 = math.log(float(cutoffs[i-2]) / float(cutoffs[i-3]))
    dl2 = math.log(float(cutoffs[i-1]) / float(cutoffs[i-2]))
    dln = math.log(float(cutoffs[i]) / float(cutoffs[i-1]))

    v1 = (c1-c0)/dl1
    v2 = (c2-c1)/dl2
    vtrue = (states[i]-c2)/dln

    R = v92.minimal_rotation(v1, v2)
    transported = R @ v1
    A = v2 - transported

    fcur = v92.hellinger_angle(probs[i-2], probs[i-1]) / dl2
    gate = 1.0 / math.sqrt(1.0 + max(fcur,0.0)/max(fisher_med,EPS))

    base = R @ v2
    direction = R @ (gate*A)
    y = vtrue-base

    return {
        "vtrue": vtrue,
        "base": base,
        "direction": direction,
        "dln": dln,
        "gate": gate,
        "fisher_action": fcur,
        "v1": v1,
        "v2": v2,
        "A": A,
    }


def oracle_betas(geom, blocks):
    y = geom["vtrue"] - geom["base"]
    dvec = geom["direction"]
    scalar = fit_beta(y, dvec)
    by_block = {name: fit_beta(y, dvec, idx) for name, idx in blocks}
    return scalar, by_block


def velocity_from_beta(geom, scalar_beta=None, block_beta=None, blocks=None):
    base = geom["base"].copy()
    dvec = geom["direction"]
    if block_beta is not None:
        out = base.copy()
        for name, idx in blocks:
            out[idx] += float(block_beta.get(name,0.0))*dvec[idx]
        return out
    return base + float(scalar_beta)*dvec


def predict_state_from_velocity(v92, states, target_idx, geom, vhat, lo, hi):
    c2 = states[target_idx-1]
    raw = c2 + geom["dln"]*vhat
    pred, clipfrac = v92.clip_state(raw, lo, hi)
    return pred, clipfrac


def score_state(v92, pred, actual, prev, d):
    err = v92.relerr(pred, actual)
    persist = v92.relerr(prev, actual)
    gain = (persist-err)/persist if persist > EPS else 0.0
    J = v92.state_to_jacobi(pred,d)
    eig = np.linalg.eigvalsh(J)
    return {
        "error": err,
        "persistence_error": persist,
        "gain": gain,
        "positive": bool(np.min(eig)>0.0),
        "min_eig": float(np.min(eig)),
    }


def run_trajectory(v92, states, probs, cutoffs, dev_last, d, fixed_beta):
    blocks = blocks_for_depth(d)

    # Development-derived Fisher normalization and trust bounds.
    acts = v92.fisher_actions(probs[:dev_last+1], cutoffs[:dev_last+1])
    pos = [x for x in acts if x > 1e-14]
    fisher_med = float(np.median(pos)) if pos else 1.0
    lo, hi = v92.state_bounds(states[:dev_last+1], d)

    # First identify oracle beta at every target >=3.
    oracle_scalar = {}
    oracle_block = {}
    oracle_rows = []
    geoms = {}
    for i in range(3,len(cutoffs)):
        geom = transition_geometry(v92,states,probs,cutoffs,i,fisher_med)
        geoms[i] = geom
        bs, bb = oracle_betas(geom,blocks)
        oracle_scalar[i] = bs
        oracle_block[i] = bb

        # Oracle residual diagnostics in velocity space.
        v_scalar = velocity_from_beta(geom,scalar_beta=bs)
        v_block = velocity_from_beta(geom,block_beta=bb,blocks=blocks)
        base_err = float(np.linalg.norm(geom["vtrue"]-geom["base"]))
        scalar_err = float(np.linalg.norm(geom["vtrue"]-v_scalar))
        block_err = float(np.linalg.norm(geom["vtrue"]-v_block))

        row = {
            "target_index": i,
            "cutoff": cutoffs[i],
            "split": "dev" if i <= dev_last else "blind",
            "fisher_action": geom["fisher_action"],
            "fisher_gate": geom["gate"],
            "oracle_scalar_beta": bs,
            "velocity_base_error": base_err,
            "velocity_scalar_oracle_error": scalar_err,
            "velocity_block_oracle_error": block_err,
            "scalar_oracle_reduction": (
                (base_err-scalar_err)/base_err if base_err>EPS else 0.0
            ),
            "block_vs_scalar_reduction": (
                (scalar_err-block_err)/scalar_err if scalar_err>EPS else 0.0
            ),
        }
        for name,_ in blocks:
            row[f"beta_{name}"] = bb[name]
        oracle_rows.append(row)

    # Causal predictions can start at i=4 because previous oracle i-1 is known.
    pred_rows = []
    for i in range(4,len(cutoffs)):
        geom=geoms[i]
        actual=states[i]
        prev=states[i-1]
        split="dev" if i<=dev_last else "blind"

        methods = {}

        # Pure covariant transport.
        methods["covariant_beta0"] = velocity_from_beta(geom,scalar_beta=0.0)
        methods["fixed_beta_v92"] = velocity_from_beta(geom,scalar_beta=fixed_beta)

        # Causal previous scalar oracle.
        methods["previous_scalar_beta"] = velocity_from_beta(
            geom, scalar_beta=oracle_scalar[i-1]
        )

        # Causal previous mode-resolved oracle.
        methods["previous_block_beta"] = velocity_from_beta(
            geom, block_beta=oracle_block[i-1], blocks=blocks
        )

        for method,vhat in methods.items():
            pred,clipfrac=predict_state_from_velocity(
                v92,states,i,geom,vhat,lo,hi
            )
            met=score_state(v92,pred,actual,prev,d)
            pred_rows.append({
                "target_index":i,
                "cutoff":cutoffs[i],
                "split":split,
                "method":method,
                "clip_fraction":clipfrac,
                **met,
            })

    return {
        "oracle_rows":oracle_rows,
        "prediction_rows":pred_rows,
        "oracle_scalar":oracle_scalar,
        "oracle_block":oracle_block,
        "blocks":blocks,
        "fisher_med":fisher_med,
    }


def summarize_method(rows, method, split):
    z=[r for r in rows if r["method"]==method and r["split"]==split]
    if not z:
        return {
            "count":0,"mean_gain":float("nan"),"all_gain_positive":False,
            "mean_error":float("nan"),"positive_all":False
        }
    return {
        "count":len(z),
        "mean_gain":float(np.mean([r["gain"] for r in z])),
        "all_gain_positive":bool(all(r["gain"]>0 for r in z)),
        "mean_error":float(np.mean([r["error"] for r in z])),
        "positive_all":bool(all(r["positive"] for r in z)),
    }


def lag1_corr(values: Sequence[float]) -> float:
    x=np.asarray(values,float)
    if len(x)<3:
        return float("nan")
    a,b=x[:-1],x[1:]
    if np.std(a)<=EPS or np.std(b)<=EPS:
        return float("nan")
    return float(np.corrcoef(a,b)[0,1])


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v92-module",
        default="rot_rh_operator_recursive_inertia_jacobi_v92_1",
    )
    ap.add_argument(
        "--cutoffs",
        default="8000,12000,18000,27000,40000,60000,90000,135000,200000,300000,450000,675000",
    )
    ap.add_argument("--development-last",type=int,default=7)
    ap.add_argument("--depth",type=int,default=32)
    ap.add_argument("--grid-points",type=int,default=128)
    ap.add_argument("--fixed-beta",type=float,default=-0.5)
    ap.add_argument("--scrambled-controls",type=int,default=8)
    ap.add_argument("--seed",type=int,default=20260817)
    ap.add_argument("--prefix",default="rot_rh_mode_resolved_counterflow_v93")
    args=ap.parse_args()

    t0=time.time()
    cutoffs=parse_ints(args.cutoffs)
    if cutoffs!=sorted(cutoffs):
        raise ValueError("cutoffs must be increasing")
    if not (5<=args.development_last<len(cutoffs)-1):
        raise ValueError("development-last must leave blind cutoffs")

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)

    base=importlib.import_module(args.base_module)
    v92=importlib.import_module(args.v92_module)

    print("="*154)
    print("ROT-RH v93 — MODE-RESOLVED RECURSIVE COUNTERFLOW IDENTIFICATION")
    print("="*154)
    print("cutoffs                       :",cutoffs)
    print("development                  :",cutoffs[:args.development_last+1])
    print("blind                         :",cutoffs[args.development_last+1:])
    print("depth                         :",args.depth)
    print("fixed v92 beta                :",args.fixed_beta)
    print("Xi/zeta/zero evaluations      : NONE")
    print("="*154)

    print("[1] Real arithmetic trajectory",flush=True)
    states,probs,roots,free=v92.build_trajectory(
        base,cutoffs,args.depth,args.grid_points,"signal",args.seed
    )
    real=run_trajectory(
        v92,states,probs,cutoffs,args.development_last,args.depth,args.fixed_beta
    )

    methods=[
        "covariant_beta0",
        "fixed_beta_v92",
        "previous_scalar_beta",
        "previous_block_beta",
    ]
    summaries={}
    for method in methods:
        summaries[(method,"dev")]=summarize_method(
            real["prediction_rows"],method,"dev"
        )
        summaries[(method,"blind")]=summarize_method(
            real["prediction_rows"],method,"blind"
        )

    print("[2] Real causal prediction summary")
    for method in methods:
        d=summaries[(method,"dev")]
        b=summaries[(method,"blind")]
        print(
            f"  {method:<22} "
            f"dev_gain={d['mean_gain']:+.3%} "
            f"blind_gain={b['mean_gain']:+.3%} "
            f"blind_all={b['all_gain_positive']}"
        )

    # Oracle-beta persistence diagnostics.
    oracle_rows=real["oracle_rows"]
    scalar_seq=[r["oracle_scalar_beta"] for r in oracle_rows]
    scalar_corr=lag1_corr(scalar_seq)
    block_corr={}
    for name,_ in real["blocks"]:
        seq=[r[f"beta_{name}"] for r in oracle_rows]
        block_corr[name]=lag1_corr(seq)

    scalar_sign_changes=int(np.sum(
        np.sign(np.asarray(scalar_seq[1:])) != np.sign(np.asarray(scalar_seq[:-1]))
    ))

    print("[3] Oracle beta structure")
    print("  scalar beta lag-1 corr       :",f"{scalar_corr:+.6f}")
    print("  scalar beta sign changes     :",scalar_sign_changes)
    for name in block_corr:
        print(f"  {name:<20} lag1={block_corr[name]:+.6f}")

    # Scrambled controls: score causal previous-block-beta blind gain.
    print("[4] Scrambled prime-weight controls",flush=True)
    control_rows=[]
    control_block_gains=[]
    control_scalar_gains=[]
    for rep in range(args.scrambled_controls):
        cs,cp,cr,cf=v92.build_trajectory(
            base,cutoffs,args.depth,args.grid_points,
            "permuted_weights",args.seed+100000*(rep+1)
        )
        rr=run_trajectory(
            v92,cs,cp,cutoffs,args.development_last,args.depth,args.fixed_beta
        )
        mb=summarize_method(rr["prediction_rows"],"previous_block_beta","blind")
        ms=summarize_method(rr["prediction_rows"],"previous_scalar_beta","blind")
        control_block_gains.append(mb["mean_gain"])
        control_scalar_gains.append(ms["mean_gain"])
        control_rows.append({
            "rep":rep,
            "block_blind_mean_gain":mb["mean_gain"],
            "block_blind_all_positive":mb["all_gain_positive"],
            "scalar_blind_mean_gain":ms["mean_gain"],
            "scalar_blind_all_positive":ms["all_gain_positive"],
        })
        print(
            f"  control {rep+1:02d}/{args.scrambled_controls}: "
            f"block_gain={mb['mean_gain']:+.3%} "
            f"scalar_gain={ms['mean_gain']:+.3%}"
        )

    real_block=summaries[("previous_block_beta","blind")]["mean_gain"]
    real_scalar=summaries[("previous_scalar_beta","blind")]["mean_gain"]

    cb=np.asarray(control_block_gains,float)
    cs=np.asarray(control_scalar_gains,float)
    cb_mean=float(np.mean(cb)); cb_sd=float(np.std(cb,ddof=1)) if len(cb)>1 else 0.0
    cs_mean=float(np.mean(cs)); cs_sd=float(np.std(cs,ddof=1)) if len(cs)>1 else 0.0
    z_block=(real_block-cb_mean)/cb_sd if cb_sd>EPS else float("inf")
    z_scalar=(real_scalar-cs_mean)/cs_sd if cs_sd>EPS else float("inf")
    p_block=float(np.mean(cb<=real_block))
    p_scalar=float(np.mean(cs<=real_scalar))

    # Mode-resolved oracle advantage.
    blind_oracle=[r for r in oracle_rows if r["split"]=="blind"]
    block_vs_scalar=float(np.mean([
        r["block_vs_scalar_reduction"] for r in blind_oracle
    ])) if blind_oracle else float("nan")

    gates={
        "mode_resolved_oracle_beats_scalar_on_blind":block_vs_scalar>0.05,
        "causal_block_beta_blind_gain_positive":real_block>0.0,
        "causal_block_beta_improves_every_blind_step":
            summaries[("previous_block_beta","blind")]["all_gain_positive"],
        "causal_block_beta_operators_positive":
            summaries[("previous_block_beta","blind")]["positive_all"],
        "real_block_beta_beats_scrambled_z2":z_block>2.0,
        "real_block_beta_beats_scrambled_percentile95":p_block>=0.95,
    }

    if all(gates.values()):
        verdict=(
            "PASS_V93_MODE_RESOLVED_RECURSIVE_COUNTERFLOW_SUPPORTED__"
            "NEXT_FREEZE_CAUSAL_BLOCK_LAW_AND_POSTFREEZE_XI"
        )
    elif real_block>0 and block_vs_scalar>0:
        verdict=(
            "PARTIAL_V93_MODE_RESOLUTION_HELPS__"
            "BUT_CAUSAL_OR_CONTROL_GATES_FAIL"
        )
    else:
        verdict=(
            "NO_GO_V93_V92_REVERSAL_IS_NOT_EXPLAINED_BY_PERSISTENT_MODE_RESOLVED_COUNTERFLOW"
        )

    oracle_csv=Path(str(prefix)+"_ORACLE_BETAS.csv")
    pred_csv=Path(str(prefix)+"_CAUSAL_PREDICTIONS.csv")
    controls_csv=Path(str(prefix)+"_SCRAMBLED_CONTROLS.csv")
    summary_json=Path(str(prefix)+"_SUMMARY.json")

    write_csv(oracle_csv,real["oracle_rows"])
    write_csv(pred_csv,real["prediction_rows"])
    write_csv(controls_csv,control_rows)

    packet={
        "version":VERSION,
        "build":BUILD,
        "verdict":verdict,
        "RH_proof":False,
        "Xi_evaluated":False,
        "zeta_evaluated":False,
        "known_zero_ordinates_used":False,
        "real_method_summaries":{
            f"{m}_{s}":summaries[(m,s)]
            for m in methods for s in ["dev","blind"]
        },
        "oracle_structure":{
            "scalar_lag1_correlation":scalar_corr,
            "scalar_sign_changes":scalar_sign_changes,
            "block_lag1_correlations":block_corr,
            "blind_mean_block_vs_scalar_oracle_reduction":block_vs_scalar,
        },
        "scrambled_controls":{
            "repetitions":args.scrambled_controls,
            "real_block_blind_gain":real_block,
            "control_block_gain_mean":cb_mean,
            "control_block_gain_sd":cb_sd,
            "block_gain_z":z_block,
            "block_gain_percentile":p_block,
            "real_scalar_blind_gain":real_scalar,
            "control_scalar_gain_mean":cs_mean,
            "control_scalar_gain_sd":cs_sd,
            "scalar_gain_z":z_scalar,
            "scalar_gain_percentile":p_scalar,
        },
        "gates":gates,
        "outputs":{
            "oracle_betas":str(oracle_csv),
            "causal_predictions":str(pred_csv),
            "scrambled_controls":str(controls_csv),
            "summary":str(summary_json),
        },
        "runtime_seconds":time.time()-t0,
    }
    summary_json.write_text(
        json.dumps(json_safe(packet),indent=2),
        encoding="utf-8",
    )

    print("\n"+"="*154)
    print("FINAL ZERO-FREE VERDICT")
    print("="*154)
    print("verdict                         :",verdict)
    print("blind block-vs-scalar oracle   :",f"{block_vs_scalar:+.6%}")
    print("causal previous-block blind    :",f"{real_block:+.6%}")
    print("causal block blind every step  :",
          summaries[("previous_block_beta","blind")]["all_gain_positive"])
    print("causal previous-scalar blind   :",f"{real_scalar:+.6%}")
    print("block control mean/sd           :",f"{cb_mean:+.6%}",f"{cb_sd:.6%}")
    print("real block z / percentile      :",f"{z_block:+.6f}",f"{p_block:.6f}")
    print("scalar oracle lag1 corr         :",f"{scalar_corr:+.6f}")
    print("scalar oracle sign changes      :",scalar_sign_changes)
    print("gates                           :",gates)
    print("Xi evaluated                    : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("summary                         :",summary_json)
    print("runtime seconds                 :",f"{time.time()-t0:.2f}")
    print("="*154)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
