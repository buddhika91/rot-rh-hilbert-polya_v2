#!/usr/bin/env python3
"""
rot_rh_spatial_square_autopsy_v14.py

ROT-RH v14 — spatial square-completion autopsy for the exponential Weil probe.

Purpose
-------
Audit the proposed "global positive square" decomposition of the Weil
quadratic form and identify exactly which rearrangements are legitimate.

No zero ordinates.
No zeta / xi evaluations.

Probe
-----
    phi_a(x) = exp(-a |x|),  a > 1/2

Autocorrelation
---------------
    k_a(v) = <phi_a, T_v phi_a>
           = (|v| + 1/a) exp(-a |v|).

Archimedean multiplier
----------------------
    Omega(r) = Re psi(1/4+i r/2) - log pi.

Using the DLMF digamma integral,

    Omega(r)
      = Omega(0)
        + 2 int_0^infinity
            w(x) [1-cos(r x)] dx,

    w(x) = exp(-x/2)/(1-exp(-2x)) > 0,

and therefore for any suitable f,

    <f,Omega(D)f>
      = Omega(0)||f||^2
        + int_0^infinity w(x)||f-T_x f||^2 dx.

This is a VALID positive-difference representation plus a finite negative
mass Omega(0)||f||^2.

Prime sector
------------
At finite cutoff X,

  P_X[f]
    = -2 sum_{n<=X} Lambda(n)/sqrt(n) Re<f,T_log(n) f>

has the exact identity

  P_X[f]
    = sum_{n<=X} Lambda(n)/sqrt(n)||f-T_log(n)f||^2
      - 2 W_X ||f||^2,

  W_X = sum_{n<=X} Lambda(n)/sqrt(n).

But as X->infinity,

    W_X ~ 2 sqrt(X),

and ||f-T_log(n)f||^2 -> 2||f||^2, so BOTH terms on the right diverge
like 4 sqrt(X)||f||^2.  Only their difference converges for the localized
probe.  They may not be separated into a positive infinite series plus a
finite scalar "regularized mass".

This script numerically verifies:
  1. Fourier and spatial Archimedean formulas agree.
  2. The finite-cutoff prime square identity is exact.
  3. W_X/(2 sqrt X) approaches 1.
  4. The positive prime-difference and negative diagonal pieces diverge
     while their combined prime correlation stabilizes.
  5. The pole kernel is not positive definite by itself:
        cosh(v/2)
     gives a 2x2 matrix with a negative eigenvalue for v != 0.

Outputs
-------
<prefix>_CUTOFF.csv
<prefix>_KERNEL.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.integrate import quad


def parse_ints(s):
    return [int(float(x.strip())) for x in str(s).split(",") if x.strip()]


def prime_power_atoms(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    for p in tqdm(
        range(2, int(math.isqrt(nmax)) + 1),
        desc="Prime sieve",
        unit="p",
    ):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False

    ns, lams = [], []
    for p in tqdm(np.flatnonzero(sieve), desc="Prime powers", unit="prime"):
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // p:
                break
            q *= p

    ns = np.asarray(ns, dtype=np.int64)
    lams = np.asarray(lams, dtype=np.float64)
    order = np.argsort(ns)
    return ns[order], lams[order]


def k(v, a):
    av = np.abs(v)
    return (av + 1.0/a) * np.exp(-a*av)


def q_fourier(r, a):
    return 4.0*a*a / (a*a + r*r)**2


def omega(r):
    return np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)


def omega0_exact():
    # psi(1/4) = -gamma - pi/2 - 3 log 2
    return (
        -0.577215664901532860606512090082402431
        - math.pi/2.0
        - 3.0*math.log(2.0)
        - math.log(math.pi)
    )


def arch_fourier(v, a, rmax, rpoints):
    nodes, weights = np.polynomial.legendre.leggauss(rpoints)
    r = 0.5*rmax*(nodes + 1.0)
    w = 0.5*rmax*weights
    # even integral: 1/(2pi) int_R = 1/pi int_0^inf
    val = np.dot(
        w,
        q_fourier(r, a)*np.cos(r*v)*omega(r)
    ) / math.pi
    return float(val)


def arch_spatial(v, a):
    """
    Kernel entry corresponding to
      Omega0 <phi_0,phi_v>
      + int w(x) <Delta_x phi_0, Delta_x phi_v> dx.

    <Delta_x phi_0,Delta_x phi_v>
      = 2 k(v)-k(v+x)-k(v-x).
    """
    om0 = omega0_exact()

    def weight(x):
        # stable w=e^-x/2/(1-e^-2x)
        if x < 1e-6:
            # 1/(2x)+1/4+O(x)
            return 1.0/(2.0*x) + 0.25
        return math.exp(-0.5*x) / (-math.expm1(-2.0*x))

    kv = float(k(v, a))

    def integrand(x):
        diff = 2.0*kv - float(k(v+x, a)) - float(k(v-x, a))
        return weight(x)*diff

    # There are derivative cusps at x=|v| for k(v-x), split there.
    if abs(v) > 1e-10:
        I1, _ = quad(integrand, 0.0, abs(v), epsabs=2e-11, epsrel=2e-11, limit=400)
        I2, _ = quad(integrand, abs(v), np.inf, epsabs=2e-11, epsrel=2e-11, limit=400)
        integ = I1 + I2
    else:
        integ, _ = quad(integrand, 0.0, np.inf, epsabs=2e-11, epsrel=2e-11, limit=400)

    return om0*kv + integ


def pole_kernel(v, a):
    qi = 4.0*a*a / (a*a - 0.25)**2
    return 2.0*qi*math.cosh(0.5*v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", type=float, default=4.0)
    ap.add_argument(
        "--X-values",
        default="1000,3000,10000,30000,100000,300000,1000000,3000000,5000000",
    )
    ap.add_argument("--v-values", default="0,0.2,0.6,1.0,2.0")
    ap.add_argument("--rmax", type=float, default=160.0)
    ap.add_argument("--rpoints", type=int, default=1400)
    ap.add_argument("--prefix", default="rot_rh_spatial_square_autopsy_v14")
    args = ap.parse_args()

    if args.a <= 0.5:
        raise SystemExit("--a must be > 1/2.")

    Xs = sorted(set(parse_ints(args.X_values)))
    vs = [float(x.strip()) for x in args.v_values.split(",") if x.strip()]
    Xmax = max(Xs)

    print("="*122)
    print("ROT-RH v14 — SPATIAL SQUARE-COMPLETION AUTOPSY")
    print("="*122)
    print(f"a                            : {args.a}")
    print(f"X checkpoints                : {Xs}")
    print(f"v values                     : {vs}")
    print("zero ordinates used          : NO")
    print("zeta / xi used               : NO")
    print()

    ns, lams = prime_power_atoms(Xmax)
    weights = lams / np.sqrt(ns.astype(float))
    logs = np.log(ns.astype(float))

    cutoff_rows = []
    k0 = float(k(0.0, args.a))

    # Autopsy at f=phi_a itself.
    for X in tqdm(Xs, desc="Prime cutoffs", unit="X"):
        idx = np.searchsorted(ns, X, side="right")
        ww = weights[:idx]
        LL = logs[:idx]

        W = float(np.sum(ww))
        corr = k(LL, args.a)

        # Original finite prime term at f=phi:
        prime_direct = float(-2.0*np.dot(ww, corr))

        # Positive difference piece:
        # ||phi - T_L phi||^2 = 2k(0)-2k(L)
        prime_positive = float(np.dot(ww, 2.0*k0 - 2.0*corr))
        prime_mass = float(-2.0*W*k0)
        prime_reconstructed = prime_positive + prime_mass

        cutoff_rows.append([
            X, idx, W, W/(2.0*math.sqrt(X)),
            prime_direct,
            prime_positive,
            prime_mass,
            prime_reconstructed,
            abs(prime_direct-prime_reconstructed),
            prime_positive/(4.0*k0*math.sqrt(X)),
            prime_mass/(-4.0*k0*math.sqrt(X)),
        ])

    cutoff_csv = Path(f"{args.prefix}_CUTOFF.csv")
    np.savetxt(
        cutoff_csv,
        np.asarray(cutoff_rows),
        delimiter=",",
        header=(
            "X,atom_count,W_X,W_over_2sqrtX,"
            "prime_direct,prime_positive_difference,prime_negative_mass,"
            "prime_reconstructed,reconstruction_error,"
            "positive_over_4k0sqrtX,mass_over_minus4k0sqrtX"
        ),
        comments="",
    )

    kernel_rows = []
    max_arch_resid = 0.0

    for v in tqdm(vs, desc="Arch spatial identity", unit="v"):
        af = arch_fourier(v, args.a, args.rmax, args.rpoints)
        asp = arch_spatial(v, args.a)
        resid = af-asp
        max_arch_resid = max(max_arch_resid, abs(resid))

        # Pole 2x2 eigenvalues for points 0 and v:
        p0 = pole_kernel(0.0, args.a)
        pv = pole_kernel(v, args.a)
        pole_eigs = np.linalg.eigvalsh(np.array([[p0, pv], [pv, p0]]))

        kernel_rows.append([
            v, af, asp, resid,
            p0, pv,
            pole_eigs[0], pole_eigs[1],
        ])

    kernel_csv = Path(f"{args.prefix}_KERNEL.csv")
    np.savetxt(
        kernel_csv,
        np.asarray(kernel_rows),
        delimiter=",",
        header=(
            "v,arch_fourier,arch_spatial,residual,"
            "pole_K0,pole_Kv,pole_2x2_lambda_min,pole_2x2_lambda_max"
        ),
        comments="",
    )

    last = cutoff_rows[-1]

    summary = {
        "version": 14,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "exact_arch_identity": {
            "Omega0": omega0_exact(),
            "weight": "w(x)=exp(-x/2)/(1-exp(-2x))",
            "formula": (
                "<f,Omega(D)f> = Omega(0)||f||^2 "
                "+ integral_0^inf w(x)||f-T_x f||^2 dx"
            ),
            "max_numerical_kernel_residual": max_arch_resid,
        },
        "prime_autopsy": {
            "finite_identity": (
                "-2 sum_{n<=X} w_n Re<f,T_log n f> = "
                "sum_{n<=X} w_n||f-T_log n f||^2 "
                "-2(sum_{n<=X}w_n)||f||^2"
            ),
            "W_asymptotic": "W_X=sum Lambda(n)/sqrt(n) ~ 2 sqrt(X) by PNT",
            "infinite_limit": (
                "positive difference and negative mass diverge separately; "
                "only their combined bracket is legitimate in the infinite sum."
            ),
            "last_X": int(last[0]),
            "last_W_over_2sqrtX": float(last[3]),
            "last_positive_piece": float(last[5]),
            "last_negative_mass": float(last[6]),
            "last_combined_prime": float(last[4]),
        },
        "fatal_errors_in_proposed_factorization": [
            (
                "The positive prime difference series does not converge; "
                "its summands tend to 2||f||^2 times Lambda(n)/sqrt(n)."
            ),
            (
                "The proposed C_reg contains sum_{log n>epsilon} Lambda(n)/sqrt(n), "
                "which is infinite for every epsilon<log 2."
            ),
            (
                "The pole kernel 2 q(i/2) cosh(v/2) is not positive definite; "
                "for every v!=0 its 2x2 Toeplitz matrix has one negative eigenvalue."
            ),
            (
                "For complex f, all spatial correlation identities require "
                "Re<f,T_x f>; replacing this by <f,T_x f> is not valid."
            ),
        ],
        "correct_spatial_form": (
            "Q[f] = pole[f] + Omega(0)||f||^2 "
            "+ int w(x)||Delta_x f||^2 dx "
            "+ sum_n w_n( ||Delta_log(n) f||^2 - 2||f||^2 ), "
            "where the prime series must be interpreted as the convergent "
            "combined bracket -2 w_n Re<f,T_log(n)f>, not as two sums."
        ),
        "files": {
            "cutoff": str(cutoff_csv),
            "kernel": str(kernel_csv),
        },
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n"+"-"*122)
    print("RESULT")
    print("-"*122)
    print(f"Omega(0) exact               : {omega0_exact():+.12e}")
    print(f"max Arch Fourier/spatial err : {max_arch_resid:.3e}")
    print(f"W_X/(2 sqrt X), largest X    : {last[3]:.9f}")
    print(f"prime positive piece         : {last[5]:+.12e}")
    print(f"prime negative mass          : {last[6]:+.12e}")
    print(f"combined prime term          : {last[4]:+.12e}")
    print(f"prime identity error         : {last[8]:.3e}")
    print()
    print("Verdict:")
    print("  REJECT the proposed global positive square.")
    print("  KEEP the exact Archimedean continuous-difference identity.")
    print("  The prime sector is an infinity-minus-infinity cancellation internally;")
    print("  separating it destroys the convergent explicit-formula term.")
    print("  The remaining positivity problem is still the full Weil problem.")
    print(f"\ncutoff  : {cutoff_csv}")
    print(f"kernel  : {kernel_csv}")
    print(f"summary : {js}")
    print("="*122)


if __name__ == "__main__":
    main()
