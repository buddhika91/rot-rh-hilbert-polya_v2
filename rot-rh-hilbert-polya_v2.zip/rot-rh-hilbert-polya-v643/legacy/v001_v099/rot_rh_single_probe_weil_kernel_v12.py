#!/usr/bin/env python3
import argparse, json, math
from pathlib import Path
import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.linalg import toeplitz

def prime_power_atoms(nmax):
    sieve=np.ones(nmax+1,dtype=bool); sieve[:2]=False
    for p in tqdm(range(2,int(math.isqrt(nmax))+1),desc="Prime sieve",unit="p"):
        if sieve[p]: sieve[p*p:nmax+1:p]=False
    ns=[]; ls=[]
    for p in tqdm(np.flatnonzero(sieve),desc="Prime powers",unit="prime"):
        p=int(p); lp=math.log(p); q=p
        while q<=nmax:
            ns.append(q); ls.append(lp)
            if q>nmax//p: break
            q*=p
    o=np.argsort(ns)
    return np.asarray(ns,dtype=np.int64)[o],np.asarray(ls,dtype=float)[o]

def kauto(x,a):
    x=np.asarray(x,float); y=a*x; out=np.empty_like(x)
    sm=np.abs(y)<1e-6
    yy=y[sm]
    out[sm]=(2/a)*(1-yy*yy/6+7*yy**4/360)
    z=y[~sm]; xx=x[~sm]; az=np.abs(z)
    vals=np.empty_like(z); md=az<40
    vals[md]=2*xx[md]/np.sinh(z[md])
    vals[~md]=4*np.abs(xx[~md])*np.exp(-az[~md])
    out[~sm]=vals
    return out

def pole(v,a):
    fac=(math.pi/a)**2
    return 2*fac/(math.cos(math.pi/(4*a))**2)*math.cosh(v/2)

def arch_setup(a,rmax,npts):
    nodes,w=np.polynomial.legendre.leggauss(npts)
    r=.5*rmax*(nodes+1); w=.5*rmax*w
    Om=np.real(digamma(.25+.5j*r))-math.log(math.pi)
    base=(math.pi/a)**2/np.cosh(math.pi*r/(2*a))**2*Om
    return r,w,base

def arch(v,r,w,base):
    return float(np.sum(w*base*np.cos(r*v))/math.pi)

def prime(v,logn,coeff,a,chunk):
    s=0.0
    for i in range(0,len(logn),chunk):
        x=logn[i:i+chunk]; c=coeff[i:i+chunk]
        g=.5*(kauto(x-v,a)+kauto(x+v,a))
        s+=float(np.dot(c,g))
    return -2*s

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--a",type=float,default=4.0)
    ap.add_argument("--nmax",type=int,default=5_000_000)
    ap.add_argument("--spacing",type=float,default=.20)
    ap.add_argument("--matrix-size",type=int,default=32)
    ap.add_argument("--rmax",type=float,default=100.0)
    ap.add_argument("--rpoints",type=int,default=900)
    ap.add_argument("--prime-chunk",type=int,default=200_000)
    ap.add_argument("--prefix",default="rot_rh_single_probe_weil_kernel_v12")
    A=ap.parse_args()
    if A.a<=.5: raise SystemExit("--a must be > 1/2")

    print("="*116)
    print("ROT-RH v12 — SINGLE-PROBE WEIL POSITIVITY KERNEL")
    print("="*116)
    print(f"a={A.a}  nmax={A.nmax:,}  matrix={A.matrix_size}  spacing={A.spacing}")
    print("zero ordinates used : NO")
    print("zeta / xi used      : NO")

    ns,lams=prime_power_atoms(A.nmax)
    logn=np.log(ns.astype(float)); coeff=lams/np.sqrt(ns.astype(float))
    r,w,base=arch_setup(A.a,A.rmax,A.rpoints)

    rows=[]; kvals=[]
    for j in tqdm(range(A.matrix_size),desc="Kernel shifts",unit="v"):
        v=j*A.spacing
        po=pole(v,A.a); ar=arch(v,r,w,base)
        pr=prime(v,logn,coeff,A.a,A.prime_chunk)
        K=po+ar+pr
        scale=abs(po)+abs(ar)+abs(pr)
        rows.append([v,K,po,ar,pr,scale,abs(K)/scale if scale else np.nan])
        kvals.append(K)

    kvals=np.asarray(kvals)
    T=toeplitz(kvals)
    eig=np.linalg.eigvalsh(T)

    kcsv=Path(f"{A.prefix}_KERNEL.csv")
    ecsv=Path(f"{A.prefix}_EIGEN.csv")
    js=Path(f"{A.prefix}_SUMMARY.json")
    np.savetxt(kcsv,np.asarray(rows),delimiter=",",
        header="v,K,pole,arch,prime,cancellation_scale,relative_survivor",comments="")
    np.savetxt(ecsv,np.column_stack([np.arange(len(eig)),eig]),delimiter=",",
        header="index,eigenvalue",comments="")

    summary={
      "version":12,
      "zero_ordinates_used":False,
      "zeta_xi_used":False,
      "probe":{
        "phi":"sech(a x)",
        "a":A.a,
        "autocorrelation":"k_a(x)=2x/sinh(a x), k_a(0)=2/a",
        "fourier_weight":"(pi/a)^2 sech^2(pi r/(2a))"
      },
      "kernel_identity":{
        "g_v":"0.5[k_a(x-v)+k_a(x+v)]",
        "h_v":"(pi/a)^2 sech^2(pi r/(2a)) cos(rv)",
        "arithmetic":"h_v(-i/2)+h_v(i/2)+(1/(2pi))int h_v Omega - 2 sum Lambda(n)/sqrt(n) g_v(log n)",
        "Omega":"Re digamma(1/4+i r/2)-log(pi)",
        "RH_spectral":"sum_gamma (pi/a)^2 sech^2(pi gamma/(2a)) cos(gamma v)"
      },
      "toeplitz":{
        "matrix_size":A.matrix_size,
        "spacing":A.spacing,
        "lambda_min":float(eig[0]),
        "lambda_max":float(eig[-1]),
        "negative_eigenvalues":int(np.sum(eig<0))
      },
      "warning":"Finite numerical PSD is only an audit. Large explicit-formula cancellations require tail/quadrature certification before interpreting small eigenvalues.",
      "next_theorem_target":"Represent the exact arithmetic kernel K(v) directly as a Gram/correlation kernel without invoking zeta zeros. That would force positive definiteness and hence RH.",
      "files":{"kernel":str(kcsv),"eigen":str(ecsv)}
    }
    js.write_text(json.dumps(summary,indent=2))
    print(f"\nK(0)                : {kvals[0]:+.12e}")
    print(f"Toeplitz lambda_min : {eig[0]:+.12e}")
    print(f"Toeplitz lambda_max : {eig[-1]:+.12e}")
    print(f"negative eigs       : {np.sum(eig<0)}")
    print(f"\nkernel  : {kcsv}\neigen   : {ecsv}\nsummary : {js}")

if __name__=="__main__":
    main()
