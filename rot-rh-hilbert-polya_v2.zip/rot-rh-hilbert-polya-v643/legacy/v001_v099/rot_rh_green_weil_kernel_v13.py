#!/usr/bin/env python3
"""
rot_rh_green_weil_kernel_v13.py

ROT-RH v13 — Green-regularized single-kernel Weil positivity audit.

No zero ordinates. No zeta/xi evaluations.

Choose
    phi_a(x) = exp(-a |x|),   a > 1/2.

Then
    phi_hat(r) = 2a/(a^2+r^2),
    k_a(x) = (phi_a * phi_a~)(x)
           = (|x| + 1/a) exp(-a|x|),
    q_a(r) = |phi_hat(r)|^2
           = 4a^2/(a^2+r^2)^2.

For translation difference v, define the even test
    g_v(x) = 1/2 [k_a(x-v)+k_a(x+v)],
with transform
    h_v(r)=q_a(r) cos(rv).

The arithmetic Weil kernel is

 K_a(v) =
      2 q_a(i/2) cosh(v/2)
    + (1/(2*pi)) int_R q_a(r) cos(rv) Omega(r) dr
    - sum_{n>=2} Lambda(n)/sqrt(n)
          [k_a(log n-v)+k_a(log n+v)],

 Omega(r)=Re digamma(1/4+i r/2)-log(pi).

For a>1/2 the prime-power sum is absolutely convergent, because its
terms are O((log n)^2 n^(-a-1/2)).  The Archimedean integral is also
absolutely convergent since q_a(r)=O(r^-4).

Most importantly,

    1/q_a(r) = (a^2+r^2)^2/(4a^2),

so in distributions

    W = ((a^2-d_v^2)^2/(4a^2)) K_a,

where W is the Weil distribution.

Thus:
  RH => W positive definite => K_a positive definite.
  K_a positive definite => its Fourier transform is a positive measure;
  multiplying that measure by the positive polynomial 1/q_a gives a
  positive Fourier transform for W => W positive definite => RH.

So positivity of ONE explicit continuous arithmetic kernel K_a is
equivalent to Weil positivity/RH (subject only to the standard explicit
formula extension to this exponentially decaying test, obtainable by
smooth approximation).

Outputs:
  <prefix>_KERNEL.csv
  <prefix>_EIGEN.csv
  <prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.linalg import toeplitz


def prime_power_atoms(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in tqdm(range(2, r + 1), desc="Prime sieve", unit="p"):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False

    primes = np.flatnonzero(sieve)
    ns, lams = [], []
    for p in tqdm(primes, desc="Prime powers", unit="prime"):
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // p:
                break
            q *= p

    ns = np.asarray(ns, dtype=np.int64)
    lams = np.asarray(lams, dtype=np.float64)
    order = np.argsort(ns)
    return ns[order], lams[order]


def k_a(x, a):
    x = np.asarray(x, dtype=np.float64)
    ax = np.abs(x)
    return (ax + 1.0/a) * np.exp(-a*ax)


def q_real(r, a):
    return 4.0*a*a / (a*a + r*r)**2


def q_i_half(a):
    return 4.0*a*a / (a*a - 0.25)**2


def pole_term(v, a):
    return 2.0*q_i_half(a)*math.cosh(0.5*v)


def arch_setup(a, rmax, npts):
    nodes, weights = np.polynomial.legendre.leggauss(npts)
    r = 0.5*rmax*(nodes + 1.0)
    w = 0.5*rmax*weights
    Omega = np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)
    base = q_real(r, a) * Omega
    return r, w, base


def arch_term(v, r, w, base):
    # even integral: (1/2pi)*int_R = (1/pi)*int_0^inf
    return float(np.dot(w, base*np.cos(r*v)) / math.pi)


def prime_term(v, logn, coeff, a, chunk):
    total = 0.0
    for i in range(0, len(logn), chunk):
        x = logn[i:i+chunk]
        c = coeff[i:i+chunk]
        total += float(np.dot(
            c,
            k_a(x-v, a) + k_a(x+v, a)
        ))
    return -total


def crude_prime_tail_bound(N, V, a):
    """
    Rigorous-style elementary majorant using Lambda(n)<=log n and summing
    over ALL integers n>N instead of only prime powers.

    For n > exp(V), both log n +/- v are positive for |v|<=V and
      k(log n +/- v)
        <= exp(aV) * (log n + V + 1/a) * n^-a
           + exp(-aV) * (...) n^-a
        <= 2 exp(aV)(log n+V+1/a)n^-a.

    Multiply by Lambda(n)/sqrt(n) <= log(n)/sqrt(n), then upper-bound
    the sum by first term + integral.
    """
    if N < max(3, math.ceil(math.exp(V))):
        return float("inf")

    b = a + 0.5
    c = V + 1.0/a
    C = 2.0*math.exp(a*V)

    # f(x) = log x (log x+c) x^-b.
    def f(x):
        lx = math.log(x)
        return lx*(lx+c)*x**(-b)

    # Integral_N^inf x^-b[(log x)^2+c log x] dx.
    # Let d=b-1>0. Standard moments:
    # int_Ninf x^-b dx = N^(1-b)/d
    # int log x = N^(1-b)[log N/d + 1/d^2]
    # int log^2 = N^(1-b)[log^2/d + 2log/d^2 + 2/d^3]
    d = b - 1.0
    L = math.log(N)
    pref = N**(1.0-b)
    I1 = pref*(L/d + 1.0/d**2)
    I2 = pref*(L*L/d + 2.0*L/d**2 + 2.0/d**3)
    integral = I2 + c*I1

    return C*(f(float(N)) + integral)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", type=float, default=4.0)
    ap.add_argument("--nmax", type=int, default=5_000_000)
    ap.add_argument("--spacing", type=float, default=0.20)
    ap.add_argument("--matrix-size", type=int, default=32)
    ap.add_argument("--rmax", type=float, default=120.0)
    ap.add_argument("--rpoints", type=int, default=1000)
    ap.add_argument("--arch-check-factor", type=float, default=1.5)
    ap.add_argument("--prime-chunk", type=int, default=200_000)
    ap.add_argument("--prefix", default="rot_rh_green_weil_kernel_v13")
    A = ap.parse_args()

    if A.a <= 0.5:
        raise SystemExit("--a must be > 1/2.")
    if A.matrix_size < 2:
        raise SystemExit("--matrix-size must be >=2.")

    vmax = (A.matrix_size - 1)*A.spacing

    print("="*124)
    print("ROT-RH v13 — GREEN-REGULARIZED SINGLE WEIL KERNEL")
    print("="*124)
    print(f"a                            : {A.a}")
    print(f"nmax                         : {A.nmax:,}")
    print(f"translation range            : [0,{vmax:g}]")
    print(f"Toeplitz size / spacing      : {A.matrix_size} / {A.spacing}")
    print(f"Arch quadrature              : rmax={A.rmax}, points={A.rpoints}")
    print("Riemann zero ordinates used  : NO")
    print("zeta / xi evaluations used   : NO")
    print()

    ns, lams = prime_power_atoms(A.nmax)
    logn = np.log(ns.astype(np.float64))
    coeff = lams / np.sqrt(ns.astype(np.float64))
    print(f"prime-power atoms            : {len(ns):,}")

    print("Building primary Archimedean quadrature...")
    r, w, base = arch_setup(A.a, A.rmax, A.rpoints)

    rmax2 = A.rmax*A.arch_check_factor
    npts2 = max(A.rpoints+100, int(A.rpoints*A.arch_check_factor))
    print("Building independent enlarged Archimedean check...")
    r2, w2, base2 = arch_setup(A.a, rmax2, npts2)

    rows = []
    kvals = []
    max_arch_delta = 0.0

    for j in tqdm(range(A.matrix_size), desc="Kernel shifts", unit="v"):
        v = j*A.spacing
        po = pole_term(v, A.a)
        ar = arch_term(v, r, w, base)
        ar2 = arch_term(v, r2, w2, base2)
        pr = prime_term(v, logn, coeff, A.a, A.prime_chunk)
        K = po + ar2 + pr
        ad = abs(ar2-ar)
        max_arch_delta = max(max_arch_delta, ad)

        scale = abs(po)+abs(ar2)+abs(pr)
        rows.append([
            v, K, po, ar2, pr, ad, scale,
            abs(K)/scale if scale else np.nan
        ])
        kvals.append(K)

    kvals = np.asarray(kvals, dtype=np.float64)
    T = toeplitz(kvals)
    eigs = np.linalg.eigvalsh(T)

    tail_bound = crude_prime_tail_bound(A.nmax, vmax, A.a)
    # Entrywise perturbation <= tail+arch_delta implies spectral-norm
    # perturbation <= matrix_size*(tail+arch_delta) by row-sum bound.
    entry_error = tail_bound + max_arch_delta
    eig_error_bound = A.matrix_size*entry_error
    certified_lower = float(eigs[0] - eig_error_bound)

    kcsv = Path(f"{A.prefix}_KERNEL.csv")
    ecsv = Path(f"{A.prefix}_EIGEN.csv")
    js = Path(f"{A.prefix}_SUMMARY.json")

    np.savetxt(
        kcsv, np.asarray(rows), delimiter=",",
        header=(
            "v,K,pole,arch_enlarged,prime,arch_crosscheck_delta,"
            "cancellation_scale,relative_survivor"
        ),
        comments=""
    )
    np.savetxt(
        ecsv,
        np.column_stack([np.arange(len(eigs)), eigs]),
        delimiter=",",
        header="index,eigenvalue",
        comments=""
    )

    summary = {
        "version": 13,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "probe": {
            "phi": "exp(-a|x|)",
            "a": A.a,
            "k": "(|x|+1/a) exp(-a|x|)",
            "q": "4a^2/(a^2+r^2)^2",
            "inverse_symbol": "(a^2+r^2)^2/(4a^2)"
        },
        "single_kernel_equivalence": {
            "distribution_identity":
                "W=((a^2-d_v^2)^2/(4a^2)) K_a",
            "reason":
                "q(r)>0 and 1/q(r) is a positive polynomial. "
                "K_a positive definite implies its Fourier transform is "
                "a positive measure; multiplying by 1/q preserves positivity, "
                "so W is positive definite. Weil positivity is RH-equivalent."
        },
        "absolute_convergence": {
            "prime_tail":
                "For a>1/2, prime-power terms are O((log n)^2 n^(-a-1/2)).",
            "arch_tail":
                "q(r)Omega(r)=O(log r/r^4)."
        },
        "numerics": {
            "nmax": A.nmax,
            "prime_power_atoms": int(len(ns)),
            "vmax": vmax,
            "arch_crosscheck_max": max_arch_delta,
            "crude_uniform_prime_tail_bound": tail_bound,
            "entry_error_bound": entry_error,
            "toeplitz_eigenvalue_error_bound": eig_error_bound,
        },
        "toeplitz": {
            "matrix_size": A.matrix_size,
            "spacing": A.spacing,
            "lambda_min": float(eigs[0]),
            "lambda_max": float(eigs[-1]),
            "negative_eigenvalues_raw": int(np.sum(eigs < 0.0)),
            "certified_lower_via_crude_bound": certified_lower
        },
        "next_target":
            "Derive K_a(v) as an arithmetic Gram/correlation kernel, or prove "
            "the Toeplitz quadratic form nonnegative directly. This is no "
            "longer a cutoff-removal problem: it is exactly Weil positivity "
            "compressed into one smooth absolutely-convergent kernel.",
        "files": {"kernel": str(kcsv), "eigen": str(ecsv)}
    }
    js.write_text(json.dumps(summary, indent=2))

    print("\n"+"-"*124)
    print("RESULT")
    print("-"*124)
    print(f"K(0)                         : {kvals[0]:+.12e}")
    print(f"raw lambda_min               : {eigs[0]:+.12e}")
    print(f"raw lambda_max               : {eigs[-1]:+.12e}")
    print(f"Arch crosscheck max          : {max_arch_delta:.3e}")
    print(f"crude uniform prime tail     : {tail_bound:.3e}")
    print(f"Toeplitz eig error bound     : {eig_error_bound:.3e}")
    print(f"crude certified lower        : {certified_lower:+.12e}")
    print()
    print("Analytic status:")
    print("  * K_a is an unconditional continuous arithmetic kernel.")
    print("  * Its prime-power sum is absolutely convergent for a>1/2.")
    print("  * RH is equivalent to positive definiteness of this one kernel.")
    print("  * The remaining theorem is positivity itself; no generic operator")
    print("    or cutoff theorem can supply it automatically.")
    print(f"\nkernel  : {kcsv}\neigen   : {ecsv}\nsummary : {js}")
    print("="*124)


if __name__ == "__main__":
    main()
