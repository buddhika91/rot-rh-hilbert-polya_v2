#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v92 — Operator-Valued Recursive Inertia Jacobi / Xi Audit
=================================================================

WHY THIS BRANCH
---------------
v91 falsified the simple projective connection as ROT-specific:
its blind improvement was tiny and statistically indistinguishable from
randomized edge placements.

The earlier E-free Fisher/Jacobi audit had already identified the next
structural target: stop using a scalar Fisher fixed-point fit and instead make
the JACOBI OPERATOR FLOW itself recursive, with an operator-valued
counterflow/inertia law, selected only by arithmetic next-shell prediction
before any Xi/zero scoring.

v92 implements that target.

ZERO-FREE OPERATOR TRAJECTORY
-----------------------------
For each arithmetic cutoff X_s:
  1. build the zero-free prime/Gamma quantized support E_k(X_s);
  2. realize that support as a positive Jacobi operator J_s with fixed positive
     boundary weights;
  3. encode the operator state in positivity-preserving coordinates

         c_s = [a_1,...,a_d, log b_1,...,log b_{d-1}],

     where b_j > 0 are the Jacobi off-diagonals.

ROT RECURSIVE INERTIA
---------------------
Let

    v_s = (c_s-c_{s-1}) / Delta log X_s

be the operator velocity.

The minimal orthogonal transport R_s mapping the previous normalized velocity
direction to the current one is the discrete information connection in
coefficient space.

The covariant acceleration is

    A_s = v_s - R_s v_{s-1}.

The next velocity is predicted by

    v_hat_{s+1}
      = R_s [ v_s + beta * g_s * A_s ],

where beta is selected ONLY from development next-shell arithmetic prediction,
and

    g_s = 1/sqrt(1 + F_s/F_dev)

is a Fisher/Hellinger information gate derived from the zero-free prime-induced
spectral displacement probabilities.

beta < 0 is recursive counterflow/damping.
beta > 0 is recursive inertia.
beta = 0 is pure covariant transport.

The next Jacobi state is

    c_hat_{s+1}
      = c_s + Delta log X_{s+1} v_hat_{s+1}.

This is an actual recursive law on operator coefficients; it is not a diagonal
root list dressed after the fact.

SELECTION FIREWALL
------------------
beta is selected using DEVELOPMENT cutoffs only:
  * minimum mean one-step Jacobi coefficient relative error;
  * all predicted development Jacobi matrices must remain positive.

No Xi, zeta, Riemann zeros, zero RMSE, or Xi determinant enters selection.

BLIND ARITHMETIC TEST
---------------------
The selected beta is frozen and evaluated on untouched later arithmetic
cutoffs.  It must beat persistence on every blind transition.

SCRAMBLED CONTROL
-----------------
The same frozen beta law is evaluated on independent prime-weight permutation
trajectories.  The real arithmetic blind gain must beat these controls.

HARD FREEZE
-----------
All real/control operators and the selected beta are serialized and SHA256
hashed BEFORE Xi is imported/evaluated.

POST-FREEZE Xi
--------------
The final blind one-step predicted Jacobi operator is tested against:
  * post-freeze Xi sign-change roots;
  * inverse even trace moments;
  * the finite determinant

        D_H(t) = det(I - t^2 H^{-2})
               = product_n (1 - t^2/E_n(H)^2)

    versus Xi(t)/Xi(0).

The final predicted operator must beat the raw/persistence operator at the same
cutoff.  This remains numerical evidence only, not an RH proof.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import mpmath as mp
import numpy as np

VERSION = "v92"
BUILD = "2026-08-17-operator-valued-recursive-inertia-jacobi-v92"
EPS = 1e-14


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, mp.mpf):
        return mp.nstr(x, 50)
    if isinstance(x, mp.mpc):
        return {"real": mp.nstr(mp.re(x), 50), "imag": mp.nstr(mp.im(x), 50)}
    return x


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def relerr(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a-b) / max(np.linalg.norm(b), EPS))


def hellinger_angle(p: np.ndarray, q: np.ndarray) -> float:
    p = np.maximum(np.asarray(p,float), 0.0)
    q = np.maximum(np.asarray(q,float), 0.0)
    p /= max(float(np.sum(p)), EPS)
    q /= max(float(np.sum(q)), EPS)
    bc = float(np.sum(np.sqrt(p*q)))
    bc = min(1.0, max(-1.0, bc))
    return float(math.acos(bc))


def displacement_probability(roots: np.ndarray, free: np.ndarray) -> np.ndarray:
    z = np.asarray(roots,float)-np.asarray(free,float)
    p = z*z
    s = float(np.sum(p))
    if s <= EPS:
        return np.ones(len(z),float)/len(z)
    return p/s


def jacobi_state(base, roots: np.ndarray) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    d = len(roots)
    w = base.stable_positive_weights(d)
    a,b,_ = base.jacobi_from_atoms(np.asarray(roots,float), w)
    c = np.r_[a, np.log(np.maximum(b, 1e-300))]
    return c, a, b


def state_to_jacobi(c: np.ndarray, d: int) -> np.ndarray:
    c = np.asarray(c,float)
    a = c[:d]
    logb = c[d:]
    b = np.exp(np.clip(logb, -50.0, 50.0))
    J = np.diag(a)
    if d > 1:
        J += np.diag(b,1)+np.diag(b,-1)
    return J


def state_bounds(states: Sequence[np.ndarray], d: int) -> Tuple[np.ndarray,np.ndarray]:
    X = np.vstack(states)
    lo = np.min(X,axis=0)
    hi = np.max(X,axis=0)
    span = np.maximum(hi-lo, 1e-10)
    # Development-derived numerical trust region only.
    return lo-2.0*span, hi+2.0*span


def clip_state(c: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> Tuple[np.ndarray,float]:
    z=np.asarray(c,float)
    zz=np.minimum(np.maximum(z,lo),hi)
    frac=float(np.mean(np.abs(zz-z)>1e-14))
    return zz,frac


def minimal_rotation(u: np.ndarray, v: np.ndarray) -> np.ndarray:
    """
    Orthogonal minimal plane rotation mapping unit u to unit v.
    """
    u=np.asarray(u,float)
    v=np.asarray(v,float)
    n=len(u)
    nu=float(np.linalg.norm(u)); nv=float(np.linalg.norm(v))
    if nu<=EPS or nv<=EPS:
        return np.eye(n)
    a=u/nu; b=v/nv
    c=float(np.clip(np.dot(a,b),-1.0,1.0))
    if c>1.0-1e-12:
        return np.eye(n)
    if c<-1.0+1e-10:
        # Stable reflection fallback for an almost-antipodal event.
        w=a-b
        nw=float(np.linalg.norm(w))
        if nw<=EPS:
            return -np.eye(n)
        w/=nw
        return np.eye(n)-2.0*np.outer(w,w)
    K=np.outer(b,a)-np.outer(a,b)
    R=np.eye(n)+K+(K@K)/(1.0+c)
    return R


def operator_velocities(states: Sequence[np.ndarray], cutoffs: Sequence[int]) -> List[np.ndarray]:
    out=[]
    for i in range(1,len(states)):
        dl=math.log(float(cutoffs[i])/float(cutoffs[i-1]))
        out.append((states[i]-states[i-1])/dl)
    return out


def fisher_actions(probs: Sequence[np.ndarray], cutoffs: Sequence[int]) -> List[float]:
    out=[]
    for i in range(1,len(probs)):
        dl=math.log(float(cutoffs[i])/float(cutoffs[i-1]))
        out.append(hellinger_angle(probs[i-1],probs[i])/dl)
    return out


def predict_state(
    states: Sequence[np.ndarray],
    probs: Sequence[np.ndarray],
    cutoffs: Sequence[int],
    target_idx: int,
    beta: float,
    fisher_dev_median: float,
    lo: np.ndarray,
    hi: np.ndarray,
) -> Tuple[np.ndarray,Dict[str,float]]:
    """
    Predict state[target_idx] from states up to target_idx-1.
    Requires target_idx >= 3.
    """
    i=target_idx
    c0=states[i-3]
    c1=states[i-2]
    c2=states[i-1]

    dl1=math.log(float(cutoffs[i-2])/float(cutoffs[i-3]))
    dl2=math.log(float(cutoffs[i-1])/float(cutoffs[i-2]))
    dln=math.log(float(cutoffs[i])/float(cutoffs[i-1]))

    v1=(c1-c0)/dl1
    v2=(c2-c1)/dl2

    R=minimal_rotation(v1,v2)
    cov_acc=v2-R@v1

    fcur=hellinger_angle(probs[i-2],probs[i-1])/dl2
    gate=1.0/math.sqrt(1.0+max(fcur,0.0)/max(fisher_dev_median,EPS))

    vhat=R@(v2 + float(beta)*gate*cov_acc)
    raw=c2+dln*vhat
    pred,clipfrac=clip_state(raw,lo,hi)

    cos=float(np.dot(v1,v2)/max(np.linalg.norm(v1)*np.linalg.norm(v2),EPS))
    return pred,{
        "fisher_action":float(fcur),
        "fisher_gate":float(gate),
        "velocity_cosine":cos,
        "covariant_acceleration_norm":float(np.linalg.norm(cov_acc)),
        "predicted_velocity_norm":float(np.linalg.norm(vhat)),
        "clip_fraction":clipfrac,
    }


def evaluate_beta(
    states, probs, cutoffs, beta, target_indices, fisher_dev_median, lo, hi, d
):
    rows=[]
    valid=True
    for i in target_indices:
        pred,diag=predict_state(
            states,probs,cutoffs,i,beta,fisher_dev_median,lo,hi
        )
        actual=states[i]
        err=relerr(pred,actual)
        persist=relerr(states[i-1],actual)
        gain=(persist-err)/persist if persist>EPS else 0.0
        J=state_to_jacobi(pred,d)
        eig=np.linalg.eigvalsh(J)
        positive=bool(np.min(eig)>0.0)
        valid=valid and positive and np.all(np.isfinite(pred))
        rows.append({
            "target_index":i,
            "cutoff":cutoffs[i],
            "beta":beta,
            "prediction_error":err,
            "persistence_error":persist,
            "gain":gain,
            "positive_operator":positive,
            "minimum_eigenvalue":float(np.min(eig)),
            **diag,
        })
    return rows,{
        "mean_error":float(np.mean([r["prediction_error"] for r in rows])),
        "mean_persistence":float(np.mean([r["persistence_error"] for r in rows])),
        "mean_gain":float(np.mean([r["gain"] for r in rows])),
        "all_gain_positive":bool(rows and all(r["gain"]>0 for r in rows)),
        "all_positive_operator":valid,
    }


def build_trajectory(base, cutoffs, depth, grid_points, family, seed):
    states=[]; probs=[]; roots=[]; free_ref=None
    for j,X in enumerate(cutoffs):
        rr,resid,counts,free,meta=base.quantize_levels(
            depth=depth,
            cutoff=X,
            family=family,
            seed=seed+1009*j+X,
            grid_points=grid_points,
        )
        if free_ref is None:
            free_ref=np.asarray(free,float)
        c,a,b=jacobi_state(base,rr)
        states.append(c)
        probs.append(displacement_probability(rr,free_ref))
        roots.append(np.asarray(rr,float))
    return states,probs,roots,np.asarray(free_ref,float)


def bisect_xi_zero(v86,a,b,iters=80):
    aa,bb=mp.mpf(a),mp.mpf(b)
    fa=mp.re(v86.Xi_t(aa)); fb=mp.re(v86.Xi_t(bb))
    if fa*fb>0: raise ValueError("not bracketed")
    for _ in range(iters):
        m=(aa+bb)/2
        fm=mp.re(v86.Xi_t(m))
        if fa*fm<=0:
            bb=m; fb=fm
        else:
            aa=m; fa=fm
    return float((aa+bb)/2)


def xi_zeros(v86,tmax,step):
    out=[]; x0=0.0; f0=mp.re(v86.Xi_t(0)); x=step
    while x<=tmax+1e-12:
        f=mp.re(v86.Xi_t(mp.mpf(x)))
        if f==0 or f0*f<0:
            out.append(bisect_xi_zero(v86,x0,x))
        x0,f0=x,f
        x+=step
    return out


def zero_metrics(E,truth,count):
    p=np.sort(np.asarray(E,float))
    p=p[p>1e-10]
    q=np.asarray(truth,float)
    n=min(count,len(p),len(q))
    if n==0:
        return {"count":0,"relative_rmse":float("nan"),"rmse":float("nan")}
    e=p[:n]-q[:n]
    return {
        "count":int(n),
        "rmse":float(np.sqrt(np.mean(e*e))),
        "relative_rmse":float(np.sqrt(np.mean((e/q[:n])**2))),
        "mae":float(np.mean(np.abs(e))),
        "max_abs":float(np.max(np.abs(e))),
    }


def determinant(E,t):
    e=np.sort(np.asarray(E,float))
    e=e[e>1e-10]
    z=complex(t)
    return complex(np.prod(1.0-(z*z)/(e*e)))


def symerr(a,b):
    return abs(a-b)/max(1.0,abs(a),abs(b))


def rms(vals):
    x=np.asarray(vals,float)
    x=x[np.isfinite(x)]
    return float(np.sqrt(np.mean(x*x))) if len(x) else float("nan")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v86-module",
        default="rot_rh_rot_native_recursive_hp_xi_identity_v86",
    )
    ap.add_argument(
        "--cutoffs",
        default="8000,12000,18000,27000,40000,60000,90000,135000,200000,300000,450000,675000",
    )
    ap.add_argument("--development-last",type=int,default=7)
    ap.add_argument("--depth",type=int,default=32)
    ap.add_argument("--grid-points",type=int,default=128)
    ap.add_argument("--beta-grid",default="-1,-0.5,-0.25,0,0.25,0.5,1")
    ap.add_argument("--scrambled-controls",type=int,default=8)
    ap.add_argument("--seed",type=int,default=20260817)

    ap.add_argument("--xi-dps",type=int,default=100)
    ap.add_argument("--xi-radius",default="4")
    ap.add_argument("--xi-samples",type=int,default=2048)
    ap.add_argument("--moment-order",type=int,default=8)
    ap.add_argument("--zero-scan-max",type=float,default=120.0)
    ap.add_argument("--zero-scan-step",type=float,default=0.10)
    ap.add_argument("--zero-match-count",type=int,default=32)
    ap.add_argument("--identity-max",type=float,default=100.0)
    ap.add_argument("--identity-step",type=float,default=0.50)

    ap.add_argument("--min-development-gain",type=float,default=0.0)
    ap.add_argument("--min-control-z",type=float,default=2.0)
    ap.add_argument("--prefix",default="rot_rh_operator_recursive_inertia_jacobi_v92")
    args=ap.parse_args()

    t0=time.time()
    cutoffs=parse_ints(args.cutoffs)
    betas=parse_floats(args.beta_grid)
    if cutoffs!=sorted(cutoffs) or len(cutoffs)<8:
        raise ValueError("Use >=8 increasing cutoffs.")
    if not (4<=args.development_last<len(cutoffs)-1):
        raise ValueError("development-last must leave blind cutoffs.")

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)

    base=importlib.import_module(args.base_module)

    print("="*154)
    print("ROT-RH v92 — OPERATOR-VALUED RECURSIVE INERTIA JACOBI / Xi AUDIT")
    print("="*154)
    print("cutoffs                       :",cutoffs)
    print("development                  :",cutoffs[:args.development_last+1])
    print("blind                         :",cutoffs[args.development_last+1:])
    print("depth                         :",args.depth)
    print("beta grid                     :",betas)
    print("law                           : covariant Jacobi-coefficient inertia")
    print("selection                     : DEVELOPMENT arithmetic prediction only")
    print("Xi/zeta/zeros pre-freeze      : NONE")
    print("="*154)

    print("[1] Build real arithmetic Jacobi trajectory",flush=True)
    states,probs,roots,free=build_trajectory(
        base,cutoffs,args.depth,args.grid_points,"signal",args.seed
    )

    # Fisher normalization and trust region use development only.
    dev_probs=probs[:args.development_last+1]
    dev_cutoffs=cutoffs[:args.development_last+1]
    acts=fisher_actions(dev_probs,dev_cutoffs)
    apos=[x for x in acts if x>1e-14]
    fisher_med=float(np.median(apos)) if apos else 1.0
    lo,hi=state_bounds(states[:args.development_last+1],args.depth)

    dev_targets=list(range(3,args.development_last+1))
    blind_targets=list(range(args.development_last+1,len(cutoffs)))

    print("[2] Development-only beta selection",flush=True)
    scan_rows=[]
    scan=[]
    for beta in betas:
        rows,met=evaluate_beta(
            states,probs,cutoffs,beta,dev_targets,fisher_med,lo,hi,args.depth
        )
        for r in rows:
            r["split"]="dev"
            scan_rows.append(r)
        scan.append({"beta":beta,**met})
        print(
            f"  beta={beta:+.3f} err={met['mean_error']:.6e} "
            f"persist={met['mean_persistence']:.6e} gain={met['mean_gain']:+.3%} "
            f"positive={met['all_positive_operator']}"
        )

    eligible=[
        z for z in scan
        if z["all_positive_operator"] and math.isfinite(z["mean_error"])
    ]
    if not eligible:
        raise RuntimeError("No positive development candidate.")
    eligible.sort(key=lambda z:(z["mean_error"],-z["mean_gain"],abs(z["beta"])))
    selected=eligible[0]
    beta=float(selected["beta"])
    print("[select] beta                     :",beta)
    print("[select] development gain         :",f"{selected['mean_gain']:+.6%}")

    print("[3] Blind arithmetic audit",flush=True)
    blind_rows,blind_met=evaluate_beta(
        states,probs,cutoffs,beta,blind_targets,fisher_med,lo,hi,args.depth
    )
    for r in blind_rows:
        r["split"]="blind"
        scan_rows.append(r)
        print(
            f"  X={r['cutoff']:<7} err={r['prediction_error']:.6e} "
            f"persist={r['persistence_error']:.6e} gain={r['gain']:+.3%} "
            f"minE={r['minimum_eigenvalue']:.6f}"
        )

    # Final predicted operator at final blind target.
    final_idx=len(cutoffs)-1
    final_pred,final_diag=predict_state(
        states,probs,cutoffs,final_idx,beta,fisher_med,lo,hi
    )
    J_pred=state_to_jacobi(final_pred,args.depth)
    J_raw=state_to_jacobi(states[final_idx],args.depth)
    J_persist=state_to_jacobi(states[final_idx-1],args.depth)

    # Scrambled prime-weight controls.  Same selected beta, no reselection.
    print("[4] Scrambled prime-weight controls",flush=True)
    control_rows=[]
    control_gains=[]
    for rep in range(args.scrambled_controls):
        cs,cp,cr,cf=build_trajectory(
            base,cutoffs,args.depth,args.grid_points,
            "permuted_weights",args.seed+100000*(rep+1)
        )
        # Apply the REAL development normalization/trust policy; do not learn from controls.
        rr,mm=evaluate_beta(
            cs,cp,cutoffs,beta,blind_targets,fisher_med,lo,hi,args.depth
        )
        gain=float(mm["mean_gain"])
        control_gains.append(gain)
        control_rows.append({
            "rep":rep,
            "blind_mean_gain":gain,
            "blind_mean_error":mm["mean_error"],
            "blind_mean_persistence":mm["mean_persistence"],
            "all_gain_positive":mm["all_gain_positive"],
            "all_positive_operator":mm["all_positive_operator"],
        })
        print(f"  control {rep+1:02d}/{args.scrambled_controls}: gain={gain:+.3%}")

    cg=np.asarray(control_gains,float)
    cmean=float(np.mean(cg))
    csd=float(np.std(cg,ddof=1)) if len(cg)>1 else 0.0
    real_gain=float(blind_met["mean_gain"])
    control_z=(real_gain-cmean)/csd if csd>EPS else float("inf")
    control_percentile=float(np.mean(cg<=real_gain))

    prexi_gates={
        "development_improves_persistence": selected["mean_gain"]>args.min_development_gain,
        "blind_improves_persistence": blind_met["mean_gain"]>0.0,
        "blind_gain_positive_every_step": blind_met["all_gain_positive"],
        "blind_predicted_operators_positive": blind_met["all_positive_operator"],
        "real_beats_scrambled_z": control_z>=args.min_control_z,
        "real_beats_scrambled_percentile": control_percentile>=0.95,
    }

    # HARD FREEZE BEFORE Xi.
    frozen_npz=Path(str(prefix)+"_FROZEN_PRE_XI.npz")
    payload={
        "selected_beta":np.asarray([beta],float),
        "cutoffs":np.asarray(cutoffs,int),
        "J_pred_final":J_pred,
        "J_raw_final":J_raw,
        "J_persistence_final":J_persist,
        "eig_pred_final":np.linalg.eigvalsh(J_pred),
        "eig_raw_final":np.linalg.eigvalsh(J_raw),
        "eig_persistence_final":np.linalg.eigvalsh(J_persist),
        "fisher_dev_median":np.asarray([fisher_med],float),
        "xi_used_during_freeze":np.asarray([False]),
        "zero_ordinates_used":np.asarray([False]),
    }
    np.savez_compressed(frozen_npz,**payload)
    fhash=sha256_file(frozen_npz)

    manifest_path=Path(str(prefix)+"_FROZEN_MANIFEST.json")
    manifest={
        "version":VERSION,
        "build":BUILD,
        "sha256":fhash,
        "selected_beta":beta,
        "selection_rule":"minimum DEVELOPMENT next-shell Jacobi coefficient error among positive operators",
        "fisher_dev_median":fisher_med,
        "prexi_gates":prexi_gates,
        "firewall":{
            "Xi":False,
            "zeta":False,
            "known_zero_ordinates":False,
            "zero_based_selection":False,
        },
        "parameters":vars(args),
    }
    manifest_path.write_text(json.dumps(json_safe(manifest),indent=2),encoding="utf-8")

    print("[pre-Xi] blind mean gain            :",f"{real_gain:+.6%}")
    print("[pre-Xi] scrambled gain mean/sd     :",f"{cmean:+.6%}",f"{csd:.6%}")
    print("[pre-Xi] real-vs-control z          :",f"{control_z:+.6f}")
    print("[pre-Xi] gates                      :",prexi_gates)
    print("[freeze] SHA256                    :",fhash)
    print("[freeze] Xi firewall CLOSED.")

    # ------------------------------------------------------------------
    # POST-FREEZE Xi
    # ------------------------------------------------------------------
    v86=importlib.import_module(args.v86_module)
    mp.mp.dps=args.xi_dps
    xi0=v86.Xi_t(0)
    truth=xi_zeros(v86,args.zero_scan_max,args.zero_scan_step)
    xi_sums,oddmax=v86.xi_power_sums(
        args.moment_order,mp.mpf(args.xi_radius),args.xi_samples
    )

    models={
        "recursive_predicted":np.linalg.eigvalsh(J_pred),
        "raw_final":np.linalg.eigvalsh(J_raw),
        "persistence_previous":np.linalg.eigvalsh(J_persist),
    }

    score_rows=[]
    identity_rows=[]
    scores={}
    for name,E in models.items():
        zm=zero_metrics(E,truth,args.zero_match_count)

        merr=[]
        pos=np.sort(np.asarray(E,float))
        pos=pos[pos>1e-10]
        for n in range(1,args.moment_order+1):
            pred=float(np.sum(pos**(-2*n)))
            target=float(xi_sums[n-1])
            rel=abs(pred-target)/max(abs(target),1e-300)
            merr.append(rel)
            score_rows.append({
                "model":name,
                "metric":"inverse_moment",
                "n":n,
                "predicted":pred,
                "target":target,
                "relative_error":rel,
            })

        errs=[]
        t=0.0
        while t<=args.identity_max+1e-12:
            xx=v86.Xi_t(mp.mpf(t))/xi0
            target=complex(float(mp.re(xx)),float(mp.im(xx)))
            D=determinant(pos,t)
            e=symerr(D,target)
            errs.append(e)
            identity_rows.append({
                "model":name,
                "t":t,
                "D_real":D.real,
                "D_imag":D.imag,
                "Xi_real":target.real,
                "Xi_imag":target.imag,
                "symmetric_error":e,
            })
            t+=args.identity_step

        scores[name]={
            "zero":zm,
            "moment_relative_rms":rms(merr),
            "identity_symmetric_rms":rms(errs),
        }

    rec=scores["recursive_predicted"]
    raw=scores["raw_final"]
    post_gates={
        "recursive_beats_raw_zero":(
            rec["zero"]["relative_rmse"]<raw["zero"]["relative_rmse"]
        ),
        "recursive_beats_raw_moments":(
            rec["moment_relative_rms"]<raw["moment_relative_rms"]
        ),
        "recursive_beats_raw_identity":(
            rec["identity_symmetric_rms"]<raw["identity_symmetric_rms"]
        ),
    }

    if all(prexi_gates.values()) and all(post_gates.values()):
        verdict=(
            "PASS_V92_OPERATOR_VALUED_ROT_RECURSION_SURVIVES_BLIND_CONTROLS_AND_XI__"
            "NEXT_AUTONOMOUS_INFINITE_JACOBI_FLOW"
        )
    elif all(prexi_gates.values()):
        verdict=(
            "PARTIAL_V92_GENUINE_BLIND_OPERATOR_RECURSION_SIGNAL__"
            "POSTFREEZE_XI_DOES_NOT_IMPROVE"
        )
    else:
        verdict=(
            "NO_GO_V92_OPERATOR_VALUED_COUNTERFLOW_NOT_ARITHMETIC_SPECIFIC"
        )

    # Outputs
    scan_csv=Path(str(prefix)+"_SCAN_AND_TRANSITIONS.csv")
    controls_csv=Path(str(prefix)+"_SCRAMBLED_CONTROLS.csv")
    scores_csv=Path(str(prefix)+"_XI_SCORES.csv")
    identity_csv=Path(str(prefix)+"_XI_IDENTITY.csv")
    verdict_json=Path(str(prefix)+"_VERDICT.json")
    theorem_md=Path(str(prefix)+"_THEOREM_TARGET.md")

    write_csv(scan_csv,scan_rows)
    write_csv(controls_csv,control_rows)
    write_csv(scores_csv,score_rows)
    write_csv(identity_csv,identity_rows)

    packet={
        "version":VERSION,
        "build":BUILD,
        "verdict":verdict,
        "RH_proof":False,
        "complete_Hilbert_Polya_theorem":False,
        "operator_is_recursive_in_coefficient_space":True,
        "operator_is_diagonal_root_packaging":False,
        "selected_beta":beta,
        "development_metrics":selected,
        "blind_metrics":blind_met,
        "scrambled_control":{
            "reps":args.scrambled_controls,
            "gain_mean":cmean,
            "gain_sd":csd,
            "real_gain":real_gain,
            "z":control_z,
            "percentile":control_percentile,
        },
        "prexi_gates":prexi_gates,
        "postfreeze_scores":scores,
        "postfreeze_gates":post_gates,
        "xi_crossings_found_postfreeze":len(truth),
        "odd_log_xi_coefficient_max":mp.nstr(oddmax,40),
        "frozen_sha256":fhash,
        "outputs":{
            "frozen_npz":str(frozen_npz),
            "manifest":str(manifest_path),
            "scan":str(scan_csv),
            "controls":str(controls_csv),
            "scores":str(scores_csv),
            "identity":str(identity_csv),
            "theorem":str(theorem_md),
            "verdict":str(verdict_json),
        },
        "runtime_seconds":time.time()-t0,
    }
    verdict_json.write_text(json.dumps(json_safe(packet),indent=2),encoding="utf-8")

    theorem_md.write_text(r"""# ROT-RH v92 theorem target

The finite zero-free arithmetic observations produce a causal Jacobi trajectory
\(J_s\).  In positivity-preserving Jacobi coordinates

\[
c_s=(a_s,\log b_s),
\]

define operator velocity \(v_s=\Delta c_s/\Delta\log X_s\).  Let \(R_s\) be
the minimal orthogonal information transport carrying the previous velocity
direction into the current one, and let

\[
A_s=v_s-R_sv_{s-1}
\]

be the covariant operator acceleration.

The tested recursive law is

\[
v_{s+1}=R_s(v_s+\beta g_s A_s),
\]

where \(g_s\) is the zero-free Fisher/Hellinger information gate and \(\beta\)
is frozen from arithmetic development prediction only.

A genuine Hilbert--Polya theory would require replacing the teacher-forced
finite flow by an autonomous infinite recursion on Jacobi coefficients,
proving positivity and essential self-adjointness of the limiting Jacobi
operator, and proving the correctly regularized determinant identity with
\(\Xi\).
""",encoding="utf-8")

    print("\n"+"="*154)
    print("FINAL CONSERVATIVE VERDICT")
    print("="*154)
    print("verdict                         :",verdict)
    print("selected beta                   :",beta)
    print("development mean gain           :",f"{selected['mean_gain']:+.6%}")
    print("blind mean gain                 :",f"{blind_met['mean_gain']:+.6%}")
    print("blind gain every step           :",blind_met["all_gain_positive"])
    print("scrambled gain mean/sd          :",f"{cmean:+.6%}",f"{csd:.6%}")
    print("real-vs-control z/percentile    :",f"{control_z:+.6f}",f"{control_percentile:.6f}")
    print("recursive zero relative RMSE    :",f"{rec['zero']['relative_rmse']:.9e}")
    print("raw zero relative RMSE          :",f"{raw['zero']['relative_rmse']:.9e}")
    print("recursive Xi identity RMS       :",f"{rec['identity_symmetric_rms']:.9e}")
    print("raw Xi identity RMS             :",f"{raw['identity_symmetric_rms']:.9e}")
    print("recursive inverse-moment RMS    :",f"{rec['moment_relative_rms']:.9e}")
    print("raw inverse-moment RMS          :",f"{raw['moment_relative_rms']:.9e}")
    print("pre-Xi gates                    :",prexi_gates)
    print("post-freeze gates               :",post_gates)
    print("Xi used in construction         : FALSE")
    print("known zeros used in selection   : FALSE")
    print("RH proof                        : FALSE")
    print("frozen manifest                 :",manifest_path)
    print("verdict file                    :",verdict_json)
    print("runtime seconds                 :",f"{time.time()-t0:.2f}")
    print("="*154)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
