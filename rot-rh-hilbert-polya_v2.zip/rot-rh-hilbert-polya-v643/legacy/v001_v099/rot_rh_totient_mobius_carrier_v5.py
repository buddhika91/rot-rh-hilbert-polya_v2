#!/usr/bin/env python3
"""
rot_rh_totient_mobius_carrier_v5.py

ROT–RH v5 — exact Möbius-carrier decomposition of the omega=1/2 Suzuki kernel.

No Riemann zero ordinates.
No zeta/xi evaluations.
No fitting to zero data.

At omega = 1/2,

    Y(x) = 2 sum_{n<=x} phi(n)/n * K(n/x),

    K(r) = 2 sqrt(1-r^2) - arcosh(1/r),   0<r<=1.

Using

    phi(n)/n = sum_{d|n} mu(d)/d,

we have the exact identity

    Y(x) = 2 sum_{d<=x} mu(d)/d * S(x/d),

where

    S(X) = sum_{m<=X} K(m/X).

The kernel Riemann sum has the endpoint expansion

    S(X)
      = 1/2 log X + c0 + c1 X^(-1/2) + R(X),

with

    c0 = 1/2 log(4*pi) - 1,
    c1 = sqrt(2) zeta(-1/2)
       = -0.293995518793519...

The c1 value is hard-coded numerically so this script performs no zeta call.

Therefore, exactly,

    Y(x)-1 = A0(x) + Ahalf(x) + Rlocal(x),

where

    M1(x)    = sum_{d<=x} mu(d)/d,
    L1(x)    = sum_{d<=x} mu(d) log(d)/d,
    Mhalf(x) = sum_{d<=x} mu(d)/sqrt(d),

    A0(x)
      = (log x + 2*c0) M1(x) - L1(x) - 1,

    Ahalf(x)
      = 2*c1*x^(-1/2) Mhalf(x),

and

    Rlocal(x)
      = 2 sum_{d<=x} mu(d)/d * R(x/d)

is obtained exactly by subtraction:

    Rlocal = (Y-1) - A0 - Ahalf.

Interpretation
--------------
The RH-scale bound

    Y(x)-1 = O_eps(x^(-1/2+eps))

requires RH-strength cancellation in these Möbius carriers.  v5 determines
numerically which component dominates prospective holdouts, rather than
relying on one fitted exponent.

The script also audits the next endpoint coefficient.  Near r=1,

    K(1-u)
      = sqrt(2) u^(1/2)
        - 11 sqrt(2)/12 u^(3/2) + ...

so generalized Euler summation predicts

    c3 = -(11 sqrt(2)/12) zeta(-3/2)
       = +0.033038058306383...

again hard-coded numerically.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_BLOCK_ENVELOPES.csv
<prefix>_KERNEL_ENDPOINT.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


C0 = 0.5 * math.log(4.0 * math.pi) - 1.0

# Hard-coded constants; no zeta evaluation is performed by the script.
C1 = -0.2939955187935193
C3 = +0.03303805830638346


def parse_floats(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def geom_checkpoints(xmin, xmax, points, forced=None):
    vals = np.geomspace(float(xmin), float(xmax), int(points))
    vals = np.unique(np.rint(vals).astype(np.int64))
    if forced:
        vals = np.unique(
            np.concatenate(
                [
                    vals,
                    np.asarray([int(v) for v in forced], dtype=np.int64),
                ]
            )
        )
    vals = vals[(vals >= xmin) & (vals <= xmax)]
    if len(vals) == 0 or vals[0] != xmin:
        vals = np.insert(vals, 0, xmin)
    if vals[-1] != xmax:
        vals = np.append(vals, xmax)
    return vals


def linear_phi_mu(nmax):
    """
    Exact linear sieve producing phi(n) and mu(n).

    Uses numpy arrays for compactness and a Python prime list.
    """
    phi = np.zeros(nmax + 1, dtype=np.int64)
    mu = np.zeros(nmax + 1, dtype=np.int8)
    comp = np.zeros(nmax + 1, dtype=np.bool_)

    phi[1] = 1
    mu[1] = 1
    primes = []

    for i in tqdm(range(2, nmax + 1), desc="phi/mu linear sieve", unit="n"):
        if not comp[i]:
            primes.append(i)
            phi[i] = i - 1
            mu[i] = -1

        for p in primes:
            ip = i * p
            if ip > nmax:
                break

            comp[ip] = True

            if i % p == 0:
                phi[ip] = phi[i] * p
                mu[ip] = 0
                break

            phi[ip] = phi[i] * (p - 1)
            mu[ip] = -mu[i]

    return phi, mu


def K_of_r(r):
    r = np.asarray(r, dtype=np.float64)
    r = np.clip(r, np.finfo(float).tiny, 1.0)
    return (
        2.0 * np.sqrt(np.maximum(0.0, 1.0 - r * r))
        - np.arccosh(1.0 / r)
    )


def Y_totient_chunked(x, phi, chunk_terms):
    x = int(x)
    total = 0.0

    for start in range(1, x + 1, chunk_terms):
        stop = min(x + 1, start + chunk_terms)
        n = np.arange(start, stop, dtype=np.float64)
        r = n / float(x)
        weights = phi[start:stop].astype(np.float64) / n
        total += float(np.dot(weights, K_of_r(r)))

    return 2.0 * total


def S_kernel(X):
    X = float(X)
    mmax = int(math.floor(X))
    if mmax < 1:
        return 0.0
    m = np.arange(1, mmax + 1, dtype=np.float64)
    return float(np.sum(K_of_r(m / X)))


def collect_mobius_sums(mu, checkpoints):
    """
    One sequential pass only; no O(N) cumulative float arrays.
    """
    wanted = {int(x): j for j, x in enumerate(checkpoints)}
    out = np.zeros((len(checkpoints), 3), dtype=np.float64)

    M1 = 0.0
    L1 = 0.0
    Mhalf = 0.0

    for n in tqdm(range(1, int(checkpoints[-1]) + 1), desc="Mobius carriers", unit="n"):
        m = int(mu[n])
        if m:
            nf = float(n)
            M1 += m / nf
            if n > 1:
                L1 += m * math.log(nf) / nf
            Mhalf += m / math.sqrt(nf)

        j = wanted.get(n)
        if j is not None:
            out[j, 0] = M1
            out[j, 1] = L1
            out[j, 2] = Mhalf

    return out


def fit_power(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    mask = (x > 0) & (y > 1e-15)
    if np.count_nonzero(mask) < 4:
        return None, None

    lx = np.log(x[mask])
    ly = np.log(y[mask])

    A = np.column_stack([np.ones_like(lx), lx])
    coef, *_ = np.linalg.lstsq(A, ly, rcond=None)
    fit = A @ coef

    ss_res = float(np.sum((ly - fit) ** 2))
    ss_tot = float(np.sum((ly - np.mean(ly)) ** 2))
    r2 = None if ss_tot == 0 else float(1.0 - ss_res / ss_tot)

    return float(coef[1]), r2


def block_maxima(x, y, blocks):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    edges = np.geomspace(float(np.min(x)), float(np.max(x)), int(blocks) + 1)
    rows = []

    for j in range(int(blocks)):
        lo = edges[j]
        hi = edges[j + 1]
        if j == blocks - 1:
            mask = (x >= lo) & (x <= hi)
        else:
            mask = (x >= lo) & (x < hi)

        if not np.any(mask):
            continue

        xx = x[mask]
        yy = y[mask]
        k = int(np.argmax(yy))
        rows.append((j, lo, hi, float(xx[k]), float(yy[k])))

    return rows


def main():
    ap = argparse.ArgumentParser(
        description="ROT-RH exact Mobius-carrier decomposition v5."
    )
    ap.add_argument("--x-min", type=int, default=500)
    ap.add_argument("--development-x-max", type=int, default=2_000_000)
    ap.add_argument("--x-max", type=int, default=5_000_000)
    ap.add_argument("--checkpoints", type=int, default=90)
    ap.add_argument("--chunk-terms", type=int, default=250_000)
    ap.add_argument("--envelope-blocks", type=int, default=14)
    ap.add_argument(
        "--epsilons",
        default="0.10,0.05,0.02,0.01",
        help="Scaled residual diagnostics x^(1/2-eps)|component|.",
    )
    ap.add_argument(
        "--kernel-X-values",
        default="100,300,1000,3000,10000,30000,100000,300000,1000000",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_totient_mobius_carrier_v5",
    )
    args = ap.parse_args()

    if not (2 <= args.x_min <= args.development_x_max < args.x_max):
        raise SystemExit(
            "Require 2 <= x-min <= development-x-max < x-max."
        )

    epsilons = parse_floats(args.epsilons)
    kernel_X = [int(v) for v in parse_floats(args.kernel_X_values)]

    checkpoints = geom_checkpoints(
        args.x_min,
        args.x_max,
        args.checkpoints,
        forced=[args.development_x_max],
    )

    print("=" * 124)
    print("ROT-RH TOTIENT / MOBIUS CRITICAL-CARRIER DECOMPOSITION v5")
    print("=" * 124)
    print("omega                         : 1/2")
    print(f"x range                       : [{args.x_min:,}, {args.x_max:,}]")
    print(f"development x max             : {args.development_x_max:,}")
    print(f"checkpoints                   : {len(checkpoints)}")
    print(f"chunk terms                   : {args.chunk_terms:,}")
    print(f"c0                            : {C0:.15f}")
    print(f"c1 = sqrt(2) zeta(-1/2)       : {C1:.15f}")
    print(f"c3 endpoint coefficient       : {C3:.15f}")
    print("Riemann zero ordinates used   : NO")
    print("zeta / xi evaluations used    : NO")
    print()

    phi, mu = linear_phi_mu(args.x_max)

    mob = collect_mobius_sums(mu, checkpoints)

    rows = []
    print("\nComputing exact totient kernel and carrier decomposition")

    for j, x in enumerate(tqdm(checkpoints, desc="Checkpoints", unit="x")):
        x = int(x)
        xf = float(x)

        Y = Y_totient_chunked(x, phi, args.chunk_terms)
        resid = Y - 1.0

        M1, L1, Mhalf = mob[j]

        A0 = (math.log(xf) + 2.0 * C0) * M1 - L1 - 1.0
        Ahalf = 2.0 * C1 * Mhalf / math.sqrt(xf)
        carrier = A0 + Ahalf
        Rlocal = resid - carrier

        row = [
            xf,
            Y,
            resid,
            abs(resid),
            M1,
            L1,
            Mhalf,
            A0,
            Ahalf,
            carrier,
            Rlocal,
            abs(A0),
            abs(Ahalf),
            abs(carrier),
            abs(Rlocal),
            math.sqrt(xf) * abs(resid),
            abs(Mhalf),
        ]

        for eps in epsilons:
            scale = xf ** (0.5 - eps)
            row.extend(
                [
                    scale * abs(resid),
                    scale * abs(A0),
                    scale * abs(Ahalf),
                    scale * abs(Rlocal),
                ]
            )

        rows.append(row)

    arr = np.asarray(rows, dtype=np.float64)

    columns = [
        "x",
        "Y",
        "Y_minus_1",
        "abs_Y_minus_1",
        "M1_sum_mu_over_n",
        "L1_sum_mu_logn_over_n",
        "Mhalf_sum_mu_over_sqrtn",
        "A0_global",
        "Ahalf_endpoint",
        "carrier_A0_plus_Ahalf",
        "Rlocal_exact",
        "abs_A0",
        "abs_Ahalf",
        "abs_carrier",
        "abs_Rlocal",
        "sqrtx_abs_Y_minus_1",
        "abs_Mhalf",
    ]

    for eps in epsilons:
        columns.extend(
            [
                f"scaled_total_eps_{eps:g}",
                f"scaled_A0_eps_{eps:g}",
                f"scaled_Ahalf_eps_{eps:g}",
                f"scaled_Rlocal_eps_{eps:g}",
            ]
        )

    track_csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        track_csv,
        arr,
        delimiter=",",
        header=",".join(columns),
        comments="",
    )

    # Fits and block envelopes.
    series = {
        "total": arr[:, 3],
        "A0": arr[:, 11],
        "Ahalf": arr[:, 12],
        "carrier": arr[:, 13],
        "Rlocal": arr[:, 14],
    }

    fit_summary = {}
    envelope_rows = []

    for name, y in series.items():
        slope, r2 = fit_power(arr[:, 0], y)
        fit_summary[name] = {
            "raw_power": slope,
            "raw_r2": r2,
        }

        blocks = block_maxima(
            arr[:, 0],
            y,
            args.envelope_blocks,
        )

        bx = np.asarray([r[3] for r in blocks], dtype=float)
        by = np.asarray([r[4] for r in blocks], dtype=float)
        bslope, br2 = fit_power(bx, by)

        fit_summary[name]["block_envelope_power"] = bslope
        fit_summary[name]["block_envelope_r2"] = br2

        for block, lo, hi, x_at, ymax in blocks:
            envelope_rows.append(
                [
                    {"total": 0, "A0": 1, "Ahalf": 2, "carrier": 3, "Rlocal": 4}[name],
                    block,
                    lo,
                    hi,
                    x_at,
                    ymax,
                ]
            )

    envelope_arr = np.asarray(envelope_rows, dtype=float)
    envelope_csv = Path(f"{args.prefix}_BLOCK_ENVELOPES.csv")
    np.savetxt(
        envelope_csv,
        envelope_arr,
        delimiter=",",
        header="series_code,block,x_lo,x_hi,x_at_max,max_abs_value",
        comments="",
    )

    # Kernel endpoint audit.
    kernel_rows = []
    print("\nKernel endpoint expansion audit")
    for X in tqdm(kernel_X, desc="Kernel X", unit="X"):
        S = S_kernel(X)
        m0 = 0.5 * math.log(float(X)) + C0
        m1 = m0 + C1 / math.sqrt(float(X))
        m3 = m1 + C3 / (float(X) ** 1.5)

        kernel_rows.append(
            [
                X,
                S,
                S - m0,
                math.sqrt(float(X)) * (S - m0),
                S - m1,
                (float(X) ** 1.5) * (S - m1),
                S - m3,
            ]
        )

    kernel_arr = np.asarray(kernel_rows, dtype=float)
    kernel_csv = Path(f"{args.prefix}_KERNEL_ENDPOINT.csv")
    np.savetxt(
        kernel_csv,
        kernel_arr,
        delimiter=",",
        header=(
            "X,S_X,error_after_log_c0,sqrtX_error_after_log_c0,"
            "error_after_c1,Xpow3over2_error_after_c1,error_after_c3"
        ),
        comments="",
    )

    dev_mask = arr[:, 0] <= args.development_x_max
    hold_mask = arr[:, 0] > args.development_x_max
    dev = arr[dev_mask]
    hold = arr[hold_mask]

    holdout = {}
    for idx, name in [(3, "total"), (11, "A0"), (12, "Ahalf"), (14, "Rlocal")]:
        dev_max = float(np.max(dev[:, idx]))
        hold_max = float(np.max(hold[:, idx]))
        holdout[name] = {
            "development_max_abs": dev_max,
            "holdout_max_abs": hold_max,
            "holdout_over_development": (
                hold_max / dev_max if dev_max > 0 else None
            ),
        }

    # Scaled prospective tests for all components.
    scaled_tests = []
    base = 17
    for j, eps in enumerate(epsilons):
        cols = {
            "total": base + 4 * j,
            "A0": base + 4 * j + 1,
            "Ahalf": base + 4 * j + 2,
            "Rlocal": base + 4 * j + 3,
        }
        row = {"epsilon": eps}
        for name, col in cols.items():
            dmax = float(np.max(dev[:, col]))
            hmax = float(np.max(hold[:, col]))
            row[name] = {
                "development_max": dmax,
                "holdout_max": hmax,
                "holdout_over_development": hmax / dmax if dmax > 0 else None,
            }
        scaled_tests.append(row)

    summary = {
        "version": 5,
        "construction": "exact omega=1/2 totient kernel with Mobius carrier decomposition",
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "constants": {
            "c0": C0,
            "c1_sqrt2_zeta_minus_half": C1,
            "c3_endpoint": C3,
        },
        "x_min": args.x_min,
        "development_x_max": args.development_x_max,
        "x_max": args.x_max,
        "checkpoints": [int(x) for x in checkpoints],
        "Y_last": float(arr[-1, 1]),
        "last_total_residual": float(arr[-1, 2]),
        "last_components": {
            "A0": float(arr[-1, 7]),
            "Ahalf": float(arr[-1, 8]),
            "carrier": float(arr[-1, 9]),
            "Rlocal": float(arr[-1, 10]),
            "Mhalf": float(arr[-1, 6]),
        },
        "power_fits": fit_summary,
        "holdout": holdout,
        "scaled_tests": scaled_tests,
        "kernel_last": {
            "X": int(kernel_arr[-1, 0]),
            "sqrtX_error_after_log_c0": float(kernel_arr[-1, 3]),
            "Xpow3over2_error_after_c1": float(kernel_arr[-1, 5]),
            "error_after_c3": float(kernel_arr[-1, 6]),
        },
        "series_codes": {
            "total": 0,
            "A0": 1,
            "Ahalf": 2,
            "carrier": 3,
            "Rlocal": 4,
        },
        "interpretation": {
            "exact_identity": (
                "Y-1 = A0 + Ahalf + Rlocal at every sampled x."
            ),
            "critical_carrier": (
                "Ahalf = 2*c1*x^(-1/2)*sum_{n<=x} mu(n)/sqrt(n). "
                "RH predicts the weighted Mobius sum is x^epsilon-scale."
            ),
            "global_carrier": (
                "A0 contains sum mu(n)/n and sum mu(n)log(n)/n; "
                "their RH-scale tail bounds are also critical."
            ),
            "local_remainder": (
                "Rlocal is the exact convolution with the kernel remainder after "
                "removing the log, constant, and X^-1/2 endpoint term."
            ),
            "warning": (
                "A finite carrier decomposition cannot prove RH.  Its purpose is "
                "to identify which exact arithmetic term must receive a new theorem."
            ),
        },
        "files": {
            "track": str(track_csv),
            "block_envelopes": str(envelope_csv),
            "kernel_endpoint": str(kernel_csv),
        },
    }

    summary_json = Path(f"{args.prefix}_SUMMARY.json")
    summary_json.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 124)
    print("SUMMARY")
    print("-" * 124)
    print(f"Y(x_max)                         : {arr[-1,1]:+.12f}")
    print(f"Y(x_max)-1                       : {arr[-1,2]:+.6e}")
    print(f"A0(x_max)                        : {arr[-1,7]:+.6e}")
    print(f"Ahalf(x_max)                     : {arr[-1,8]:+.6e}")
    print(f"Rlocal(x_max)                    : {arr[-1,10]:+.6e}")
    print(
        "identity residual                 : "
        f"{(arr[-1,2] - arr[-1,7] - arr[-1,8] - arr[-1,10]):+.3e}"
    )
    print(f"Mhalf(x_max)                     : {arr[-1,6]:+.6e}")

    print("\nBlock-envelope powers:")
    for name, data in fit_summary.items():
        p = data["block_envelope_power"]
        r2 = data["block_envelope_r2"]
        if p is None:
            print(f"  {name:<9s}: insufficient data")
        else:
            print(f"  {name:<9s}: x^({p:+.5f})  R2={r2:.4f}")

    print("\nProspective holdout raw maxima:")
    for name, d in holdout.items():
        print(
            f"  {name:<9s}: dev={d['development_max_abs']:.4e}  "
            f"hold={d['holdout_max_abs']:.4e}  "
            f"ratio={d['holdout_over_development']:.3f}"
        )

    print("\nScaled carrier tests:")
    for row in scaled_tests:
        eps = row["epsilon"]
        print(f"  eps={eps:g}  scale=x^{0.5-eps:.3f}")
        for name in ("total", "A0", "Ahalf", "Rlocal"):
            d = row[name]
            print(
                f"    {name:<7s} dev={d['development_max']:.4e}  "
                f"hold={d['holdout_max']:.4e}  "
                f"ratio={d['holdout_over_development']:.3f}"
            )

    print("\nKernel endpoint coefficients:")
    print(f"  predicted c1                        : {C1:+.12f}")
    print(
        "  observed sqrt(X) first remainder    : "
        f"{kernel_arr[-1,3]:+.12f}"
    )
    print(f"  predicted c3                        : {C3:+.12f}")
    print(
        "  observed X^(3/2) second remainder   : "
        f"{kernel_arr[-1,5]:+.12f}"
    )

    print(f"\ntrack CSV                          : {track_csv}")
    print(f"block envelopes CSV                : {envelope_csv}")
    print(f"kernel endpoint CSV                : {kernel_csv}")
    print(f"summary JSON                       : {summary_json}")
    print()
    print("Decision rule:")
    print("  * If Ahalf dominates, attack sum mu(n)/sqrt(n) directly.")
    print("  * If A0 dominates, attack the PNT-tail combinations M1/L1.")
    print("  * If Rlocal dominates, derive a positivity/contraction theorem for the residual kernel.")
    print("  * If large components cancel, the theorem must preserve that coupled cancellation; bounding them separately will be too crude.")
    print("=" * 124)


if __name__ == "__main__":
    main()
