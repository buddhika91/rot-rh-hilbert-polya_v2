#!/usr/bin/env python3
"""
rot_rh_finite_window_jump_frame_v15.py

ROT-RH v15 — finite-window positive jump-frame / spectral-gap audit.

No Riemann zero ordinates.
No zeta / xi evaluations.

For f supported in [-L,L] and extended by zero, impose the two pole-neutral
constraints

    ∫ f(x)e^(+x/2) dx = 0,
    ∫ f(x)e^(-x/2) dx = 0.

Let

    Omega(r) = Re psi(1/4+i r/2) - log(pi),
    Omega0   = psi(1/4)-log(pi),

and
    c_n = Lambda(n)/sqrt(n),
    a_n = log n.

The spatial digamma identity gives

    <f,Omega(D)f>
      = Omega0 ||f||^2
        + ∫_0^∞ w(x)||f-T_x f||^2 dx,

    w(x)=exp(-x/2)/(1-exp(-2x)) > 0.

Because supp(f)⊂[-L,L],

    <f,T_{a_n}f> = 0  whenever a_n >= 2L.

Hence only FINITELY MANY prime powers enter the Weil form.  For every
active n (a_n<2L),

   -2 c_n Re<f,T_{a_n}f>
      = c_n||f-T_{a_n}f||^2 - 2c_n||f||^2.

Therefore on the pole-neutral subspace,

    W_L[f] = A_L[f] - kappa_L ||f||^2,

where

    A_L[f]
      = ∫_0^∞ w(x)||f-T_x f||^2 dx
        + Σ_{a_n<2L} c_n||f-T_{a_n}f||^2          >= 0,

    kappa_L
      = 2 Σ_{a_n<2L} c_n - Omega0.

Equivalently, if B_L is the continuous+discrete difference-frame map,

    A_L[f] = ||B_L f||^2.

So finite-window Weil positivity is exactly the lower-frame inequality

    ||B_L f||^2 >= kappa_L ||f||^2

on the two-codimensional pole-neutral subspace.

Threshold continuity
--------------------
When 2L=a_n exactly, T_{a_n}f has disjoint support from f, hence

    ||f-T_{a_n}f||^2 = 2||f||^2.

The new channel contributes +2c_n||f||^2 while kappa_L jumps by +2c_n.
Thus W_L has no jump across a prime-power threshold.  The difficulty begins
only once the supports overlap.

Numerical audit
---------------
We use the orthonormal Fourier basis

    phi_k(x)=exp(i*pi*k*x/L)/sqrt(2L), |x|<=L,

project exactly to the nullspace of the two pole constraints, and assemble:

  * the Archimedean matrix from direct real-frequency quadrature;
  * each active prime-power correlation analytically;
  * the positive frame matrix A_L;
  * the renormalized Weil matrix W_L=A_L-kappa_L I.

The script verifies the matrix identity

    A_L - kappa_L I = W_L

independently from the prime square decomposition.

Finite Galerkin positivity is an audit only; it does not prove full-space
Weil positivity.

Outputs
-------
<prefix>_SCAN.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.linalg import null_space


GAMMA_E = 0.577215664901532860606512090082402431
OMEGA0 = -GAMMA_E - math.pi/2.0 - 3.0*math.log(2.0) - math.log(math.pi)


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def prime_power_atoms(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in range(2, r + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False

    ns, lams = [], []
    for p in np.flatnonzero(sieve):
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // p:
                break
            q *= p

    ns = np.asarray(ns, dtype=np.int64)
    lams = np.asarray(lams, dtype=np.float64)
    order = np.argsort(ns)
    return ns[order], lams[order]


def basis_frequencies(L, modes):
    ks = np.arange(-modes, modes + 1, dtype=int)
    omega = math.pi * ks / L
    return ks, omega


def ft_basis_real(r, omega, L):
    """
    F_k(r)=∫ phi_k(x)e^{irx}dx
          = sqrt(2L) * sinc((r+omega_k)L/pi)
    using numpy's normalized sinc sin(pi x)/(pi x).
    r can be vector.
    """
    r = np.asarray(r, dtype=float)[:, None]
    z = (r + omega[None, :]) * L / math.pi
    return math.sqrt(2.0*L) * np.sinc(z)


def ft_basis_complex(z, omega, L):
    """
    Integral exp((i omega_k + i z)x)/sqrt(2L), x∈[-L,L].
    Stable direct sinh form for complex z.
    """
    lam = 1j * (omega + z)
    out = np.empty(len(omega), dtype=np.complex128)
    small = np.abs(lam) < 1e-13
    out[small] = math.sqrt(2.0*L)
    out[~small] = (
        2.0*np.sinh(lam[~small]*L)
        / lam[~small]
        / math.sqrt(2.0*L)
    )
    return out


def pole_nullspace(omega, L):
    # F(i/2)=∫f e^{-x/2}; F(-i/2)=∫f e^{+x/2}.
    c1 = ft_basis_complex(0.5j, omega, L)
    c2 = ft_basis_complex(-0.5j, omega, L)
    C = np.vstack([c1, c2])
    Z = null_space(C)
    # Columns orthonormal in coefficient l2; original basis is orthonormal.
    return Z, C


def arch_matrix(omega, L, rmax, rpoints):
    """
    Gauss-Legendre on [-rmax,rmax].
    """
    nodes, weights = np.polynomial.legendre.leggauss(rpoints)
    r = rmax * nodes
    w = rmax * weights

    F = ft_basis_real(r, omega, L)
    Om = np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)

    weighted = (w*Om)[:, None] * F
    G = (F.conj().T @ weighted) / (2.0*math.pi)
    G = 0.5*(G + G.conj().T)
    return G


def prime_correlation_matrix(a, omega, L):
    """
    Hermitian R_a with c* R_a c = Re <f,T_a f>, a>=0.

    If a>=2L, supports are disjoint and R=0.
    """
    d = len(omega)
    if a >= 2.0*L - 1e-14:
        return np.zeros((d, d), dtype=np.complex128)

    ell = 2.0*L - a
    oj = omega[:, None]
    ok = omega[None, :]
    delta = ok - oj

    # integral over overlap [a-L,L], center a/2, length ell.
    # M_jk=<phi_j,T_a phi_k>
    sinc_arg = delta * ell / (2.0*math.pi)
    M = (
        (ell/(2.0*L))
        * np.sinc(sinc_arg)
        * np.exp(-0.5j*(ok + oj)*a)
    )
    R = 0.5*(M + M.conj().T)
    return R


def active_atoms(L, ns, lams):
    mask = np.log(ns.astype(float)) < 2.0*L - 1e-13
    n = ns[mask]
    lam = lams[mask]
    if len(n) == 0:
        return n, lam, np.array([], dtype=float), np.array([], dtype=float)
    aa = np.log(n.astype(float))
    cc = lam / np.sqrt(n.astype(float))
    return n, lam, aa, cc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--L-values",
        default="0.30,0.3465735903,0.37,0.40,0.45,0.50,0.545,0.5493061443,0.58,0.60,0.70,0.90,1.20",
    )
    ap.add_argument("--modes", type=int, default=30)
    ap.add_argument("--rmax", type=float, default=220.0)
    ap.add_argument("--rpoints", type=int, default=1800)
    ap.add_argument("--arch-check-factor", type=float, default=1.35)
    ap.add_argument(
        "--prefix",
        default="rot_rh_finite_window_jump_frame_v15",
    )
    args = ap.parse_args()

    Lvals = parse_floats(args.L_values)
    Lmax = max(Lvals)
    nmax = max(10, int(math.ceil(math.exp(2.0*Lmax))) + 10)
    ns, lams = prime_power_atoms(nmax)

    print("="*126)
    print("ROT-RH v15 — FINITE-WINDOW POSITIVE JUMP FRAME / SPECTRAL GAP")
    print("="*126)
    print(f"L values                     : {Lvals}")
    print(f"Fourier modes                : {-args.modes}..{args.modes}")
    print(f"Arch quadrature              : {args.rpoints} points, |r|<={args.rmax}")
    print("Riemann zero ordinates used  : NO")
    print("zeta / xi evaluations used   : NO")
    print(f"Omega(0)                     : {OMEGA0:+.12e}")
    print()

    rows = []
    case_summaries = []

    for L in tqdm(Lvals, desc="L scan", unit="L"):
        ks, omega = basis_frequencies(L, args.modes)
        Z, Cpole = pole_nullspace(omega, L)

        G = arch_matrix(omega, L, args.rmax, args.rpoints)

        # Independent enlarged Arch check.
        G2 = arch_matrix(
            omega,
            L,
            args.rmax*args.arch_check_factor,
            max(args.rpoints + 200, int(args.rpoints*args.arch_check_factor)),
        )

        Gp = Z.conj().T @ G @ Z
        Gp2 = Z.conj().T @ G2 @ Z
        arch_delta = float(np.linalg.norm(Gp2-Gp, ord=2))
        Gp = Gp2

        active_n, active_lam, active_a, active_c = active_atoms(
            L, ns, lams
        )
        Csum = float(np.sum(active_c))
        kappa = 2.0*Csum - OMEGA0

        dproj = Z.shape[1]
        Iproj = np.eye(dproj, dtype=np.complex128)

        # Positive Arch jump matrix: G_arch = Omega0 I + A_arch.
        A_arch = Gp - OMEGA0*Iproj

        Qprime = np.zeros_like(Gp)
        Aprime = np.zeros_like(Gp)

        max_prime_identity = 0.0

        for n, a, c in zip(active_n, active_a, active_c):
            R = prime_correlation_matrix(float(a), omega, L)
            Rp = Z.conj().T @ R @ Z

            Qn = -2.0*float(c)*Rp
            Dn = float(c)*(2.0*Iproj - 2.0*Rp)

            # Dn - 2c I = Qn.
            resid = np.linalg.norm(
                Dn - 2.0*float(c)*Iproj - Qn,
                ord=2,
            )
            max_prime_identity = max(max_prime_identity, float(resid))

            Qprime += Qn
            Aprime += Dn

        Wmat = 0.5*((Gp + Qprime) + (Gp + Qprime).conj().T)
        Amat = 0.5*((A_arch + Aprime) + (A_arch + Aprime).conj().T)

        frame_identity = float(
            np.linalg.norm(
                Wmat - (Amat - kappa*Iproj),
                ord=2,
            )
        )

        eigW = np.linalg.eigvalsh(Wmat)
        eigA = np.linalg.eigvalsh(Amat)
        eigAarch = np.linalg.eigvalsh(0.5*(A_arch+A_arch.conj().T))
        eigAprime = (
            np.linalg.eigvalsh(0.5*(Aprime+Aprime.conj().T))
            if len(active_n)
            else np.zeros(dproj)
        )

        ratio = float(eigA[0]/kappa) if kappa > 0 else float("nan")

        rows.append([
            L,
            math.exp(2.0*L),
            dproj,
            len(active_n),
            Csum,
            kappa,
            eigAarch[0],
            eigAprime[0] if len(active_n) else 0.0,
            eigA[0],
            eigA[-1],
            ratio,
            eigW[0],
            eigW[-1],
            arch_delta,
            max_prime_identity,
            frame_identity,
        ])

        case_summaries.append({
            "L": L,
            "exp_2L": math.exp(2.0*L),
            "projected_dimension": int(dproj),
            "active_prime_powers": [int(x) for x in active_n.tolist()],
            "Csum": Csum,
            "kappa": kappa,
            "frame_lambda_min": float(eigA[0]),
            "frame_ratio_lambda_min_over_kappa": ratio,
            "weil_lambda_min": float(eigW[0]),
            "arch_crosscheck_norm": arch_delta,
            "frame_identity_residual": frame_identity,
        })

    arr = np.asarray(rows, dtype=float)
    csv = Path(f"{args.prefix}_SCAN.csv")
    np.savetxt(
        csv,
        arr,
        delimiter=",",
        header=(
            "L,exp_2L,projected_dim,active_atom_count,Csum,kappa,"
            "Aarch_lambda_min,Aprime_lambda_min,A_lambda_min,A_lambda_max,"
            "frame_ratio_Amin_over_kappa,"
            "Weil_lambda_min,Weil_lambda_max,"
            "arch_crosscheck_norm,prime_square_identity_residual,"
            "frame_identity_residual"
        ),
        comments="",
    )

    summary = {
        "version": 15,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "Omega0": OMEGA0,
        "theorem": {
            "positive_form": (
                "A_L[f]=int w(x)||f-T_xf||^2 dx "
                "+sum_{log n<2L} Lambda(n)/sqrt(n)||f-T_log(n)f||^2"
            ),
            "mass": (
                "kappa_L=2 sum_{log n<2L} Lambda(n)/sqrt(n)-Omega(0)"
            ),
            "identity": (
                "On the pole-neutral subspace, Weil_L[f]=A_L[f]-kappa_L||f||^2."
            ),
            "frame_criterion": (
                "Finite-window Weil positivity iff the lower frame bound of "
                "the continuous+prime difference map B_L is at least kappa_L."
            ),
            "threshold_continuity": (
                "At 2L=log n the new shift is disjoint, so its positive energy "
                "equals 2c_n||f||^2, exactly cancelling the +2c_n jump in kappa_L."
            ),
        },
        "interpretation": (
            "This is a legitimate finite-window Gram/dilation.  Unlike the failed "
            "infinite square completion, the prime set is finite because of support. "
            "The RH difficulty becomes a sharp lower-frame/spectral-gap inequality."
        ),
        "literature_calibration": (
            "Compact-support Weil positivity, small-support theorems, and finite "
            "operator/Galerkin formulations are established research directions; "
            "do not claim the general framework as novel without a focused comparison."
        ),
        "cases": case_summaries,
        "files": {"scan": str(csv)},
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n"+"-"*126)
    print("SCAN")
    print("-"*126)
    for c in case_summaries:
        atoms = ",".join(map(str, c["active_prime_powers"])) or "-"
        print(
            f"L={c['L']:<10.6f} atoms=[{atoms:<12}] "
            f"Amin/kappa={c['frame_ratio_lambda_min_over_kappa']:+.7f}  "
            f"Wmin={c['weil_lambda_min']:+.7e}  "
            f"archΔ={c['arch_crosscheck_norm']:.2e}"
        )

    print()
    print("Exact structural conclusion:")
    print("  * Compact support makes the prime square completion FINITE and legitimate.")
    print("  * The positive auxiliary-space map B_L is explicit.")
    print("  * Weil positivity is exactly a lower-frame inequality for B_L.")
    print("  * Prime-power threshold entry is exactly continuous after mass renormalization.")
    print("  * The next attack should target the lower frame bound, not another cutoff limit.")
    print(f"\nscan    : {csv}")
    print(f"summary : {js}")
    print("="*126)


if __name__ == "__main__":
    main()
