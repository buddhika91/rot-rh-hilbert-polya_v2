#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v96 — Rank-Resolved Nyquist-Mode Specificity Audit
=========================================================

MOTIVATION
----------
v95 found two very different facts:

  1. DMD prediction itself was mostly generic:
       real teacher gain did not beat scrambled controls;
       real autonomous gain had z ~ 1.6, below the preregistered z>2 gate.

  2. The REAL prime-driven Jacobi flow had an unusual spectral composition:
       near-Nyquist DMD mode fraction = 0.625,
       significantly larger than scrambled controls.

However v95 hit the imposed DMD rank cap (rank=8=max_rank), so the mode spectrum
was not rank-resolved.

v96 therefore asks a narrower zero-free question:

    Are the high-frequency / near-Nyquist modes a robust,
    arithmetic-specific part of the Jacobi operator dynamics?

NO Xi, zeta, or known Riemann-zero ordinate is evaluated.

STEP 1 — DEVELOPMENT-ONLY RANK SELECTION
----------------------------------------
For each candidate rank r=1..r_max, use rolling-origin DEVELOPMENT prediction:

  fit DMD on velocities v_1..v_j,
  predict v_{j+1},
  integrate one arithmetic step,
  compare with the observed development Jacobi state.

Select r only by mean development state-prediction error.
The same procedure is applied independently to every scrambled control.

STEP 2 — FULL DEVELOPMENT DMD
-----------------------------
Fit the selected rank on all development velocities.

DMD modes are classified using the fixed v95 threshold

    near-Nyquist: |arg(lambda)| > theta_N, theta_N = 2.4 rad by default.

No threshold is tuned against blind data.

STEP 3 — MODE ABLATION
----------------------
Construct three reduced dynamical maps:

  full
  slow_only       : remove near-Nyquist modes
  nyquist_only    : retain only near-Nyquist modes

Then autonomously roll each model from the final development state through all
blind arithmetic cutoffs.

Primary structural statistic:

    Nyquist ablation penalty
      = blind_error(slow_only) - blind_error(full).

If this penalty is positive, the high-frequency modes help the real flow.

The decisive specificity test compares the REAL ablation penalty to the same
quantity on scrambled-prime controls.

A PASS means only:
  * rank selection is development-only;
  * real high-frequency modes survive rank resolution;
  * removing them damages blind autonomous prediction;
  * that damage is significantly larger than in scrambled controls.

This is not RH proof and not yet a Hilbert-Polya theorem.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

VERSION = "v96"
BUILD = "2026-08-17-rank-resolved-nyquist-specificity-v96"
EPS = 1e-14


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def log_cutoffs(xmin: int, xmax: int, count: int) -> List[int]:
    vals = np.geomspace(float(xmin), float(xmax), int(count))
    out = []
    for x in vals:
        n = int(round(float(x)))
        if not out or n > out[-1]:
            out.append(n)
    if len(out) < 10:
        raise ValueError("Too few distinct cutoffs.")
    return out


def velocities(states: Sequence[np.ndarray], cutoffs: Sequence[int]) -> List[np.ndarray]:
    out = []
    for i in range(1, len(states)):
        dl = math.log(float(cutoffs[i]) / float(cutoffs[i-1]))
        out.append((np.asarray(states[i],float)-np.asarray(states[i-1],float))/dl)
    return out


def standardizer(vs: Sequence[np.ndarray]) -> Tuple[np.ndarray,np.ndarray]:
    V = np.vstack(vs)
    mu = np.mean(V,axis=0)
    sd = np.sqrt(np.mean((V-mu)**2,axis=0))
    pos = sd[sd > 1e-12]
    floor = float(np.median(pos))*1e-3 if len(pos) else 1.0
    sd = np.maximum(sd,max(floor,1e-12))
    return mu,sd


def zscore(v,mu,sd):
    return (np.asarray(v,float)-mu)/sd


def unzscore(z,mu,sd):
    return mu+sd*np.asarray(z)


def fit_dmd_exact_rank(vs: Sequence[np.ndarray], rank: int):
    if len(vs) < 3:
        raise ValueError("Need >=3 velocities.")
    mu,sd = standardizer(vs)
    Z = np.vstack([zscore(v,mu,sd) for v in vs])
    X = Z[:-1].T
    Y = Z[1:].T
    U,s,Vh = np.linalg.svd(X,full_matrices=False)
    r = max(1,min(int(rank),len(s),X.shape[1]))
    Ur=U[:,:r]
    sr=s[:r]
    Vr=Vh[:r,:].T
    Sinv=np.diag(1.0/np.maximum(sr,1e-12))
    Atilde=Ur.T@Y@Vr@Sinv
    Afull=Y@Vr@Sinv@Ur.T

    evals,W=np.linalg.eig(Atilde)
    Phi=Y@Vr@Sinv@W

    fit = (Afull@X).T
    fiterr=float(np.linalg.norm(fit-Y.T)/max(np.linalg.norm(Y.T),EPS))
    return {
        "mu":mu,"sd":sd,"rank":r,"svals":s,
        "Afull":Afull,"Atilde":Atilde,
        "evals":evals,"Phi":Phi,
        "fit_error":fiterr,
    }


def filtered_map(model, mode_mask: np.ndarray) -> np.ndarray:
    """
    Modal reconstruction A = Phi Lambda Phi^+.
    Conjugate pairs are retained together because classification depends on |angle|.
    """
    mask=np.asarray(mode_mask,bool)
    if np.sum(mask)==0:
        return np.zeros_like(model["Afull"],dtype=float)
    Phi=np.asarray(model["Phi"],complex)[:,mask]
    lam=np.asarray(model["evals"],complex)[mask]
    A=Phi@np.diag(lam)@np.linalg.pinv(Phi)
    # Numerical DMD pairs should make this effectively real.
    return np.real_if_close(A,tol=1000).real


def state_err(a,b):
    return float(np.linalg.norm(np.asarray(a,float)-np.asarray(b,float))/
                 max(np.linalg.norm(np.asarray(b,float)),EPS))


def rolling_rank_cv(states,vels,cutoffs,dev_last,ranks,min_train_vels):
    rows=[]
    scores=[]
    for r in ranks:
        errs=[]
        valid=0
        for target_state in range(min_train_vels+1,dev_last+1):
            # Predict state[target_state] using velocities through target_state-2.
            # Velocity index k corresponds state k -> k+1.
            train_vels=vels[:target_state-1]
            if len(train_vels)<min_train_vels:
                continue
            model=fit_dmd_exact_rank(train_vels,r)
            zprev=zscore(vels[target_state-2],model["mu"],model["sd"])
            zhat=model["Afull"]@zprev
            vhat=unzscore(zhat,model["mu"],model["sd"]).real
            dl=math.log(float(cutoffs[target_state])/float(cutoffs[target_state-1]))
            pred=states[target_state-1]+dl*vhat
            e=state_err(pred,states[target_state])
            errs.append(e); valid+=1
            rows.append({
                "rank":r,
                "target_index":target_state,
                "cutoff":cutoffs[target_state],
                "error":e,
                "fit_rank":model["rank"],
            })
        mean=float(np.mean(errs)) if errs else float("inf")
        scores.append({"rank":r,"mean_cv_error":mean,"count":valid})
    eligible=[x for x in scores if np.isfinite(x["mean_cv_error"]) and x["count"]>=2]
    if not eligible:
        raise RuntimeError("No rank candidate had enough rolling CV points.")
    eligible.sort(key=lambda x:(x["mean_cv_error"],x["rank"]))
    return eligible[0]["rank"],rows,scores


def autonomous_rollout(v92,model,A,states,vels,cutoffs,dev_last,depth):
    mu,sd=model["mu"],model["sd"]
    c=np.asarray(states[dev_last],float).copy()
    z=zscore(vels[dev_last-1],mu,sd)
    rows=[]
    for i in range(dev_last+1,len(states)):
        dl=math.log(float(cutoffs[i])/float(cutoffs[i-1]))
        z=A@z
        v=unzscore(z,mu,sd).real
        c=c+dl*v
        J=v92.state_to_jacobi(c,depth)
        eig=np.linalg.eigvalsh(J)
        rows.append({
            "target_index":i,
            "cutoff":cutoffs[i],
            "error":state_err(c,states[i]),
            "positive":bool(np.min(eig)>0),
            "minimum_eigenvalue":float(np.min(eig)),
        })
    return rows


def summarize_roll(rows):
    if not rows:
        return {"mean_error":float("nan"),"positive_all":False,"count":0}
    return {
        "mean_error":float(np.mean([r["error"] for r in rows])),
        "positive_all":bool(all(r["positive"] for r in rows)),
        "count":len(rows),
    }


def evaluate(
    base,v92,cutoffs,dev_last,depth,grid_points,family,seed,
    rank_max,min_train_vels,theta_nyquist
):
    states,probs,roots,free=v92.build_trajectory(
        base,cutoffs,depth,grid_points,family,seed
    )
    vels=velocities(states,cutoffs)

    max_possible=min(rank_max,dev_last-1)
    ranks=list(range(1,max_possible+1))
    selected,cv_rows,cv_scores=rolling_rank_cv(
        states,vels,cutoffs,dev_last,ranks,min_train_vels
    )

    dev_vels=vels[:dev_last]
    model=fit_dmd_exact_rank(dev_vels,selected)
    evals=np.asarray(model["evals"],complex)
    angles=np.abs(np.angle(evals))
    nyq=angles>float(theta_nyquist)
    slow=~nyq

    maps={
        "full":model["Afull"],
        "slow_only":filtered_map(model,slow),
        "nyquist_only":filtered_map(model,nyq),
    }
    rolls={}
    summaries={}
    for name,A in maps.items():
        rr=autonomous_rollout(
            v92,model,A,states,vels,cutoffs,dev_last,depth
        )
        rolls[name]=rr
        summaries[name]=summarize_roll(rr)

    full_err=summaries["full"]["mean_error"]
    slow_err=summaries["slow_only"]["mean_error"]
    nyq_err=summaries["nyquist_only"]["mean_error"]
    ablation=slow_err-full_err
    ablation_fraction=ablation/max(full_err,EPS)

    mode_rows=[]
    for j,lam in enumerate(evals):
        mode_rows.append({
            "mode":j,
            "lambda_real":float(np.real(lam)),
            "lambda_imag":float(np.imag(lam)),
            "magnitude":float(abs(lam)),
            "angle":float(np.angle(lam)),
            "abs_angle":float(abs(np.angle(lam))),
            "near_nyquist":bool(nyq[j]),
            "distance_to_minus1":float(abs(lam+1)),
            "distance_to_plus1":float(abs(lam-1)),
        })

    return {
        "selected_rank":selected,
        "cv_rows":cv_rows,
        "cv_scores":cv_scores,
        "model":model,
        "mode_rows":mode_rows,
        "nyquist_fraction":float(np.mean(nyq)) if len(nyq) else 0.0,
        "nyquist_count":int(np.sum(nyq)),
        "slow_count":int(np.sum(slow)),
        "summaries":summaries,
        "rolls":rolls,
        "ablation_penalty":ablation,
        "ablation_penalty_fraction":ablation_fraction,
        "min_distance_to_minus1":float(np.min(np.abs(evals+1))) if len(evals) else float("nan"),
        "max_spectral_radius":float(np.max(np.abs(evals))) if len(evals) else float("nan"),
    }


def zstats(real,controls):
    c=np.asarray(controls,float)
    mean=float(np.mean(c))
    sd=float(np.std(c,ddof=1)) if len(c)>1 else 0.0
    z=(float(real)-mean)/sd if sd>EPS else float("inf")
    pct=float(np.mean(c<=float(real)))
    return mean,sd,z,pct


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v92-module",
        default="rot_rh_operator_recursive_inertia_jacobi_v92_1",
    )
    ap.add_argument("--cutoff-min",type=int,default=8000)
    ap.add_argument("--cutoff-max",type=int,default=675000)
    ap.add_argument("--cutoff-count",type=int,default=20)
    ap.add_argument("--development-last",type=int,default=13)
    ap.add_argument("--depth",type=int,default=32)
    ap.add_argument("--grid-points",type=int,default=128)
    ap.add_argument("--rank-max",type=int,default=12)
    ap.add_argument("--min-train-vels",type=int,default=6)
    ap.add_argument("--nyquist-angle",type=float,default=2.4)
    ap.add_argument("--scrambled-controls",type=int,default=16)
    ap.add_argument("--seed",type=int,default=20260817)
    ap.add_argument("--prefix",default="rot_rh_rank_resolved_nyquist_v96")
    args=ap.parse_args()

    t0=time.time()
    cutoffs=log_cutoffs(args.cutoff_min,args.cutoff_max,args.cutoff_count)
    if not (8<=args.development_last<len(cutoffs)-2):
        raise ValueError("development-last must leave blind points.")

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)

    base=importlib.import_module(args.base_module)
    v92=importlib.import_module(args.v92_module)

    print("="*158)
    print("ROT-RH v96 — RANK-RESOLVED NYQUIST-MODE SPECIFICITY AUDIT")
    print("="*158)
    print("cutoffs                       :",cutoffs)
    print("development                  :",cutoffs[:args.development_last+1])
    print("blind                         :",cutoffs[args.development_last+1:])
    print("rank candidates              :",f"1..{args.rank_max}")
    print("rolling min train velocities :",args.min_train_vels)
    print("Nyquist angle threshold      :",args.nyquist_angle)
    print("Xi/zeta/known zeros          : NONE")
    print("="*158)

    print("[1] Real arithmetic rank selection + mode ablation",flush=True)
    real=evaluate(
        base,v92,cutoffs,args.development_last,args.depth,args.grid_points,
        "signal",args.seed,args.rank_max,args.min_train_vels,args.nyquist_angle
    )

    print("[real] selected rank                :",real["selected_rank"])
    print("[real] Nyquist fraction/count       :",
          f"{real['nyquist_fraction']:.6f}",real["nyquist_count"])
    print("[real] full blind mean error        :",
          f"{real['summaries']['full']['mean_error']:.9e}")
    print("[real] slow-only blind mean error   :",
          f"{real['summaries']['slow_only']['mean_error']:.9e}")
    print("[real] Nyquist-only blind mean error:",
          f"{real['summaries']['nyquist_only']['mean_error']:.9e}")
    print("[real] Nyquist ablation penalty     :",
          f"{real['ablation_penalty']:+.9e}",
          f"({real['ablation_penalty_fraction']:+.3%})")

    print("[2] Scrambled-prime controls",flush=True)
    controls=[]
    ctrl_ablation=[]
    ctrl_fraction=[]
    ctrl_nyquist=[]
    ctrl_rank=[]
    ctrl_fullerr=[]
    for rep in range(args.scrambled_controls):
        rr=evaluate(
            base,v92,cutoffs,args.development_last,args.depth,args.grid_points,
            "permuted_weights",args.seed+100000*(rep+1),
            args.rank_max,args.min_train_vels,args.nyquist_angle
        )
        ctrl_ablation.append(rr["ablation_penalty"])
        ctrl_fraction.append(rr["ablation_penalty_fraction"])
        ctrl_nyquist.append(rr["nyquist_fraction"])
        ctrl_rank.append(rr["selected_rank"])
        ctrl_fullerr.append(rr["summaries"]["full"]["mean_error"])
        controls.append({
            "rep":rep,
            "selected_rank":rr["selected_rank"],
            "nyquist_fraction":rr["nyquist_fraction"],
            "nyquist_count":rr["nyquist_count"],
            "full_blind_mean_error":rr["summaries"]["full"]["mean_error"],
            "slow_only_blind_mean_error":
                rr["summaries"]["slow_only"]["mean_error"],
            "nyquist_only_blind_mean_error":
                rr["summaries"]["nyquist_only"]["mean_error"],
            "ablation_penalty":rr["ablation_penalty"],
            "ablation_penalty_fraction":rr["ablation_penalty_fraction"],
            "full_positive_all":rr["summaries"]["full"]["positive_all"],
        })
        print(
            f"  control {rep+1:02d}/{args.scrambled_controls}: "
            f"rank={rr['selected_rank']:2d} nyq={rr['nyquist_fraction']:.3f} "
            f"penalty={rr['ablation_penalty_fraction']:+.3%}"
        )

    amean,asd,az,apct=zstats(real["ablation_penalty"],ctrl_ablation)
    fmean,fsd,fz,fpct=zstats(real["ablation_penalty_fraction"],ctrl_fraction)
    nmean,nsd,nz,npct=zstats(real["nyquist_fraction"],ctrl_nyquist)

    gates={
        "selected_rank_not_hard_capped":
            real["selected_rank"] < args.rank_max,
        "real_has_nyquist_modes":
            real["nyquist_count"] > 0,
        "full_autonomous_positive_jacobi":
            real["summaries"]["full"]["positive_all"],
        "nyquist_ablation_hurts_real":
            real["ablation_penalty"] > 0.0,
        "nyquist_ablation_fraction_positive":
            real["ablation_penalty_fraction"] > 0.0,
        "ablation_penalty_beats_controls_z2":
            az > 2.0,
        "ablation_penalty_beats_controls_percentile95":
            apct >= 0.95,
        "nyquist_fraction_beats_controls_z2":
            nz > 2.0,
        "nyquist_fraction_beats_controls_percentile95":
            npct >= 0.95,
    }

    if all(gates.values()):
        verdict=(
            "PASS_V96_ARITHMETIC_SPECIFIC_NYQUIST_MICROMOTION__"
            "NEXT_SEPARATE_FAST_AND_SLOW_ROT_GENERATORS"
        )
    elif real["ablation_penalty"]>0 and real["nyquist_count"]>0:
        verdict=(
            "PARTIAL_V96_NYQUIST_MODES_HELP_REAL_FLOW__"
            "BUT_RANK_OR_CONTROL_SPECIFICITY_FAILS"
        )
    else:
        verdict=(
            "NO_GO_V96_HIGH_FREQUENCY_DMD_CONTENT_IS_NOT_CAUSALLY_NECESSARY"
        )

    rank_csv=Path(str(prefix)+"_REAL_RANK_CV.csv")
    modes_csv=Path(str(prefix)+"_REAL_MODES.csv")
    full_csv=Path(str(prefix)+"_REAL_FULL_ROLLOUT.csv")
    slow_csv=Path(str(prefix)+"_REAL_SLOW_ONLY_ROLLOUT.csv")
    nyq_csv=Path(str(prefix)+"_REAL_NYQUIST_ONLY_ROLLOUT.csv")
    controls_csv=Path(str(prefix)+"_CONTROLS.csv")
    summary_json=Path(str(prefix)+"_SUMMARY.json")

    write_csv(rank_csv,real["cv_rows"])
    write_csv(modes_csv,real["mode_rows"])
    write_csv(full_csv,real["rolls"]["full"])
    write_csv(slow_csv,real["rolls"]["slow_only"])
    write_csv(nyq_csv,real["rolls"]["nyquist_only"])
    write_csv(controls_csv,controls)

    packet={
        "version":VERSION,
        "build":BUILD,
        "verdict":verdict,
        "RH_proof":False,
        "Xi_evaluated":False,
        "zeta_evaluated":False,
        "known_zero_ordinates_used":False,
        "cutoffs":cutoffs,
        "development_last":args.development_last,
        "real":{
            "selected_rank":real["selected_rank"],
            "nyquist_fraction":real["nyquist_fraction"],
            "nyquist_count":real["nyquist_count"],
            "slow_count":real["slow_count"],
            "min_distance_to_minus1":real["min_distance_to_minus1"],
            "spectral_radius":real["max_spectral_radius"],
            "summaries":real["summaries"],
            "ablation_penalty":real["ablation_penalty"],
            "ablation_penalty_fraction":real["ablation_penalty_fraction"],
        },
        "controls":{
            "repetitions":args.scrambled_controls,
            "selected_rank_mean":float(np.mean(ctrl_rank)),
            "nyquist_fraction_mean":nmean,
            "nyquist_fraction_sd":nsd,
            "nyquist_fraction_z":nz,
            "nyquist_fraction_percentile":npct,
            "ablation_penalty_mean":amean,
            "ablation_penalty_sd":asd,
            "ablation_penalty_z":az,
            "ablation_penalty_percentile":apct,
            "ablation_fraction_mean":fmean,
            "ablation_fraction_sd":fsd,
            "ablation_fraction_z":fz,
            "ablation_fraction_percentile":fpct,
        },
        "gates":gates,
        "outputs":{
            "rank_cv":str(rank_csv),
            "modes":str(modes_csv),
            "full_rollout":str(full_csv),
            "slow_rollout":str(slow_csv),
            "nyquist_rollout":str(nyq_csv),
            "controls":str(controls_csv),
            "summary":str(summary_json),
        },
        "runtime_seconds":time.time()-t0,
    }
    summary_json.write_text(
        json.dumps(json_safe(packet),indent=2),
        encoding="utf-8"
    )

    print("\n"+"="*158)
    print("FINAL ZERO-FREE VERDICT")
    print("="*158)
    print("verdict                         :",verdict)
    print("selected rank / cap             :",real["selected_rank"],args.rank_max)
    print("Nyquist fraction/count          :",f"{real['nyquist_fraction']:.6f}",real["nyquist_count"])
    print("Nyquist fraction control z/pct  :",f"{nz:+.6f}",f"{npct:.6f}")
    print("full blind mean error           :",f"{real['summaries']['full']['mean_error']:.9e}")
    print("slow-only blind mean error      :",f"{real['summaries']['slow_only']['mean_error']:.9e}")
    print("Nyquist-only blind mean error   :",f"{real['summaries']['nyquist_only']['mean_error']:.9e}")
    print("Nyquist ablation penalty        :",f"{real['ablation_penalty']:+.9e}")
    print("Nyquist ablation penalty frac   :",f"{real['ablation_penalty_fraction']:+.6%}")
    print("ablation control mean/sd        :",f"{amean:+.9e}",f"{asd:.9e}")
    print("ablation control z/percentile   :",f"{az:+.6f}",f"{apct:.6f}")
    print("ablation-frac control z/pct     :",f"{fz:+.6f}",f"{fpct:.6f}")
    print("gates                           :",gates)
    print("Xi evaluated                    : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("summary                         :",summary_json)
    print("runtime seconds                 :",f"{time.time()-t0:.2f}")
    print("="*158)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
