#!/usr/bin/env python3
"""
rot_rh_relative_spectral_shift_v11.py

ROT-RH v11 — reciprocal-coordinate relative spectral-shift audit.

No Riemann zero ordinates.
No zeta / xi / prime-zeta evaluations.

Primitive-prime centered functional
------------------------------------
Let

    theta(x) = sum_{p<=x} log p,
    r(x)     = theta(x) - x + 2.

For Re(s)>1,

    F(s)
      = sum_p log(p) p^(-s) - int_2^infinity x^(-s) dx
      = s int_2^infinity r(x) x^(-s-1) dx.

Introduce the reciprocal spectral coordinate

    y = 1/x,    0 < y <= 1/2,

and define the arithmetic spectral-shift profile

    xi_ar(y) = r(1/y).

Then

    F(s) = int_0^(1/2) f_s'(y) xi_ar(y) dy,
    f_s(y)=y^s.

Moreover

    ||xi_ar||_L1
      = int_2^infinity |r(x)| x^(-2) dx < infinity

unconditionally by the quantitative PNT.  Hence xi_ar is an honest L1
spectral-shift function candidate.  The inverse Lifshits-Krein theorem says
that any compactly-supported L1 real function can occur as the SSF of a
bounded self-adjoint trace-class pair.

The barrier is shifted into the test function:
    f_s'(y)=s y^(s-1).

For sigma=Re(s)<1 this is singular at y=0.  The universal trace-norm bound is

    |s| int_0^(1/2) |xi_ar(y)| y^(sigma-1) dy
      = |s| int_2^infinity |r(x)| x^(-sigma-1) dx.

Classical PNT bounds prove this only at/above sigma=1.  RH-scale
theta(x)-x=O_eps(x^(1/2+eps)) would make it finite for every sigma>1/2.

v11 audits:
  * convergence of the reciprocal-coordinate L1 SSF norm (sigma=1);
  * weighted absolute SSF moments for sigma approaching 1/2;
  * the signed centered Mellin functional F_X(s);
  * exact piecewise integration of r(x) between successive primes.

This is an audit of the theorem boundary, not an RH test.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_ints(text):
    return [int(float(x.strip())) for x in str(text).split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in tqdm(range(2, r + 1), desc="Prime sieve", unit="p"):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve).astype(np.int64)


def signed_power_integral(s, a, b):
    """Integral_a^b x^(-s) dx."""
    z = 1.0 - complex(s)
    if abs(z) < 1e-14:
        return complex(math.log(b / a))
    return (complex(b)**z - complex(a)**z) / z


def abs_piece_integral(A, lo, hi, sigma):
    """
    Integral_lo^hi |A-x| x^(-sigma-1) dx,
    where theta is constant on the interval and r(x)=A-x.

    A = theta_const + 2.
    """
    if hi <= lo:
        return 0.0

    def pos_primitive(x):
        # Integral (A-x) x^(-sigma-1) dx.
        if abs(sigma - 1.0) < 1e-14:
            return -A / x - math.log(x)
        return (
            -A / sigma * x**(-sigma)
            - x**(1.0 - sigma) / (1.0 - sigma)
        )

    def neg_primitive(x):
        # Integral (x-A) x^(-sigma-1) dx.
        if abs(sigma - 1.0) < 1e-14:
            return math.log(x) + A / x
        return (
            x**(1.0 - sigma) / (1.0 - sigma)
            + A / sigma * x**(-sigma)
        )

    if A <= lo:
        return neg_primitive(hi) - neg_primitive(lo)
    if A >= hi:
        return pos_primitive(hi) - pos_primitive(lo)

    return (
        pos_primitive(A) - pos_primitive(lo)
        + neg_primitive(hi) - neg_primitive(A)
    )


def build_piecewise_absolute_moments(primes, checkpoints, sigmas):
    """
    One pass over prime intervals.  theta(x) includes p at x=p.
    r(x)=theta(x)-x+2.

    We integrate over [2, X], splitting at each prime.
    """
    sigmas = np.asarray(sigmas, dtype=float)
    accum = np.zeros(len(sigmas), dtype=float)
    results = {}

    theta = 0.0
    left = 2.0
    pidx = 0

    all_stops = sorted(set([int(x) for x in checkpoints]))
    stop_idx = 0

    # At x=2, theta jumps by log 2.  Process each prime as the new
    # constant theta for the interval [p, next_prime).
    while stop_idx < len(all_stops):
        X = float(all_stops[stop_idx])

        while pidx < len(primes) and primes[pidx] <= X:
            p = float(primes[pidx])

            # Integrate previous interval [left, p) if non-empty.
            if p > left:
                A = theta + 2.0
                for j, sigma in enumerate(sigmas):
                    accum[j] += abs_piece_integral(A, left, p, sigma)

            # Jump theta at p.
            theta += math.log(p)
            left = p
            pidx += 1

        # Integrate from current left to checkpoint using current theta,
        # but don't permanently advance left because there may be a prime
        # after X and next checkpoint > X.  We need checkpoint snapshots.
        snap = accum.copy()
        if X > left:
            A = theta + 2.0
            for j, sigma in enumerate(sigmas):
                snap[j] += abs_piece_integral(A, left, X, sigma)

        results[int(X)] = snap
        stop_idx += 1

        # Advance permanent state only up to X if next prime is beyond X.
        # To avoid double counting, set left=X; theta unchanged.
        if X > left:
            A = theta + 2.0
            for j, sigma in enumerate(sigmas):
                accum[j] += abs_piece_integral(A, left, X, sigma)
            left = X

    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--X-values",
        default="1000,3000,10000,30000,100000,300000,1000000,3000000,10000000",
    )
    ap.add_argument(
        "--sigmas",
        default="1.20,1.05,1.00,0.90,0.75,0.60,0.55",
    )
    ap.add_argument("--energies", default="0,5,10,20")
    ap.add_argument(
        "--prefix",
        default="rot_rh_relative_spectral_shift_v11",
    )
    args = ap.parse_args()

    checkpoints = sorted(set(parse_ints(args.X_values)))
    sigmas = parse_floats(args.sigmas)
    energies = parse_floats(args.energies)
    Xmax = max(checkpoints)

    print("=" * 126)
    print("ROT-RH RECIPROCAL-COORDINATE RELATIVE SPECTRAL-SHIFT AUDIT v11")
    print("=" * 126)
    print(f"X checkpoints               : {checkpoints}")
    print(f"sigmas                      : {sigmas}")
    print(f"energies                    : {energies}")
    print("Riemann zero ordinates used : NO")
    print("zeta / xi evaluations used  : NO")
    print()

    primes = prime_sieve(Xmax)
    print(f"primes <= Xmax              : {len(primes):,}")

    abs_moments = build_piecewise_absolute_moments(
        primes, checkpoints, sigmas
    )

    # Prime cumulative sums for signed Mellin functionals.
    logp = np.log(primes.astype(float))

    rows = []
    summaries = []

    for X in tqdm(checkpoints, desc="Checkpoints", unit="X"):
        idx = np.searchsorted(primes, X, side="right")
        ps = primes[:idx].astype(float)
        lps = logp[:idx]

        theta_X = float(np.sum(lps))
        r_X = theta_X - float(X) + 2.0

        for sigma_i, sigma in enumerate(sigmas):
            abs_moment = float(abs_moments[X][sigma_i])

            for E in energies:
                s = sigma - 1j * E

                prime_sum = np.sum(lps * np.exp(-s * lps))
                cont = signed_power_integral(s, 2.0, float(X))
                F_X = complex(prime_sum - cont)

                # Integration-by-parts finite-X endpoint relation:
                # F_X = X^-s r(X) + s int_2^X r(x)x^-s-1 dx,
                # because r(2^-)=0 in the convention r=theta-x+2.
                endpoint = complex(X) ** (-s) * r_X

                rows.append(
                    [
                        X, sigma, E, idx,
                        theta_X, r_X,
                        abs_moment,
                        prime_sum.real, prime_sum.imag,
                        cont.real, cont.imag,
                        F_X.real, F_X.imag, abs(F_X),
                        endpoint.real, endpoint.imag,
                    ]
                )

    arr = np.asarray(rows, dtype=float)
    csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        csv,
        arr,
        delimiter=",",
        header=(
            "X,sigma,E,prime_count,theta_X,r_X,"
            "weighted_abs_SSF_moment,"
            "prime_sum_real,prime_sum_imag,"
            "continuum_real,continuum_imag,"
            "F_X_real,F_X_imag,F_X_abs,"
            "endpoint_real,endpoint_imag"
        ),
        comments="",
    )

    # Summarize the absolute-moment increments independent of E.
    for sigma_i, sigma in enumerate(sigmas):
        vals = np.array(
            [abs_moments[X][sigma_i] for X in checkpoints],
            dtype=float,
        )
        inc = np.diff(vals)
        summaries.append(
            {
                "sigma": sigma,
                "abs_moment_last": float(vals[-1]),
                "tail_max_increment": float(
                    np.max(inc[-3:]) if len(inc) else float("nan")
                ),
                "tail_increment_ratio": float(
                    inc[-1] / inc[-2]
                    if len(inc) >= 2 and inc[-2] != 0
                    else float("nan")
                ),
            }
        )

    summary = {
        "version": 11,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "arithmetic_profile": (
            "r(x)=theta(x)-x+2, xi_ar(y)=r(1/y), 0<y<=1/2"
        ),
        "analytic_results": {
            "L1_spectral_shift": (
                "int_0^(1/2)|xi_ar(y)|dy = "
                "int_2^infinity |r(x)| x^-2 dx < infinity "
                "unconditionally by quantitative PNT."
            ),
            "inverse_SSF": (
                "Every compactly supported real L1 function is the "
                "Lifshits-Krein SSF of some bounded self-adjoint trace-class pair. "
                "Hence xi_ar admits an infinite relative self-adjoint realization."
            ),
            "Mellin_trace": (
                "For Re(s)>1, F(s)=sum_p log p p^-s-int_2^inf x^-s dx "
                "= int f_s'(y) xi_ar(y)dy with f_s(y)=y^s."
            ),
            "threshold": (
                "The universal trace estimate for f_s requires the weighted "
                "moment int |xi_ar(y)| y^(Re(s)-1)dy, equivalently "
                "int |r(x)| x^(-Re(s)-1)dx. Classical PNT proves this at "
                "Re(s)>=1; RH-scale error bounds imply it for every Re(s)>1/2."
            ),
            "interpretation": (
                "The relative pair exists unconditionally. The RH barrier is "
                "threshold regularity of its relative functional calculus at y=0, "
                "not existence/self-adjointness of the pair."
            ),
        },
        "sigma_summaries": summaries,
        "files": {"track": str(csv)},
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 126)
    print("SUMMARY")
    print("-" * 126)
    for s in summaries:
        print(
            f"sigma={s['sigma']:<5g} "
            f"absSSF={s['abs_moment_last']:.6e}  "
            f"tail_d={s['tail_max_increment']:.3e}  "
            f"last_ratio={s['tail_increment_ratio']:.3f}"
        )

    print()
    print("Analytic conclusion:")
    print("  * Reciprocal coordinate y=1/x makes the infinite centered PNT staircase")
    print("    an honest L1 spectral-shift function.")
    print("  * Therefore an infinite bounded self-adjoint trace-class relative pair")
    print("    exists unconditionally (inverse Lifshits-Krein theorem).")
    print("  * The half-plane barrier has moved into f_s(y)=y^s at the threshold y=0.")
    print("  * A pair-independent S1 functional-calculus bound stops at Re(s)=1.")
    print("  * Crossing to Re(s)>1/2 requires arithmetic-specific threshold cancellation;")
    print("    that is the actual surviving RH-strength problem.")
    print(f"\ntrack   : {csv}")
    print(f"summary : {js}")
    print("=" * 126)


if __name__ == "__main__":
    main()
