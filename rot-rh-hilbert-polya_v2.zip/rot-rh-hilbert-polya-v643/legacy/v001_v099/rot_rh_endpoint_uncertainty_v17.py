#!/usr/bin/env python3
"""
rot_rh_endpoint_uncertainty_v17.py

ROT-RH v17 — endpoint reduction / pole-neutral uncertainty audit.

No Riemann zero ordinates.
No zeta / xi evaluations.

Main exact reduction
--------------------
Let

    L*  = (1/2) log 3,
    tau = log 2,
    w2  = log 2 / sqrt 2.

For supp f ⊂ [-L,L], the one-prime Weil form in the first prime window is

    W_L[f]
      = (1/(2*pi)) int_R Omega(r)|F(r)|^2 dr
        - 2 w2 Re <f,T_tau f>

on the pole-neutral subspace F(±i/2)=0.

At L=L*, the n=3 correlation is still zero because log 3 = 2L*.
Since the support spaces are nested,

    positivity at L*
      ==> positivity for every L <= L*.

Thus the whole first-prime window reduces to ONE endpoint theorem.

Fourier multiplier
------------------
Using
    Re <f,T_tau f>
      = (1/(2*pi)) int cos(tau r)|F(r)|^2 dr,

the endpoint form is

    W[f] = (1/(2*pi)) int m(r)|F(r)|^2 dr,

    m(r)=Omega(r)-2 w2 cos(tau r),

    Omega(r)=Re digamma(1/4+i r/2)-log(pi).

The pole constraints imply the exact Paley-Wiener factorization

    F(z) = (z^2+1/4) G(z),

where G is the transform of a function g supported on the same interval
with clamped boundary conditions g(±L*)=g'(±L*)=0.

This script:
  1. computes the endpoint constrained form in parity sectors;
  2. finds all negative bands of m(r);
  3. computes the maximum possible spectral concentration into each
     negative band on the finite Galerkin pole-neutral subspace;
  4. computes the actual band masses of the lowest Weil eigenvector;
  5. computes the sharp relative invariant
         mu = lambda_min(G_arch^(-1/2) Q_2 G_arch^(-1/2));
  6. cross-checks the Archimedean matrix with an enlarged quadrature.

The expected structural picture is:
  * odd sector has comfortable margin;
  * even sector is near-critical;
  * pole neutrality strongly suppresses the low negative band;
  * the hard mode nearly saturates concentration in the second negative
    band (~7 to ~10.5).

This is an uncertainty-principle diagnostic, not an RH proof.

Outputs
-------
<prefix>_SUMMARY.json
<prefix>_BANDS.csv
<prefix>_SPECTRUM.csv
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.linalg import null_space, eigh
from scipy.optimize import brentq


LSTAR = 0.5 * math.log(3.0)
TAU = math.log(2.0)
W2 = TAU / math.sqrt(2.0)


def sine_indices(nmax, parity):
    n = np.arange(1, nmax + 1, dtype=int)
    # phi_n(x)=sin(n*pi*(x+L)/(2L)).
    # odd n -> even about x=0; even n -> odd about x=0.
    if parity == "even":
        return n[n % 2 == 1]
    return n[n % 2 == 0]


def expint_real(a, D):
    z = a * D / 2.0
    return D * np.exp(1j * a * D / 2.0) * np.sinc(z / math.pi)


def ft_sine_real(r, ns, L):
    """
    Matrix F[j,n] = ∫ phi_n(x) exp(i r_j x) dx,
    phi_n=sin(k_n(x+L))/sqrt(L), x∈[-L,L].
    """
    r = np.asarray(r, dtype=float)[:, None]
    ns = np.asarray(ns, dtype=float)[None, :]
    D = 2.0 * L
    k = ns * math.pi / D

    Ip = expint_real(r + k, D)
    Im = expint_real(r - k, D)
    I = (Ip - Im) / (2j)
    return np.exp(-1j * r * L) * I / math.sqrt(L)


def ft_sine_complex(z, ns, L):
    """
    Closed form at complex z; z is never at ±k here.
    """
    ns = np.asarray(ns, dtype=int)
    D = 2.0 * L
    k = ns.astype(float) * math.pi / D
    parity = (-1.0) ** ns
    return (
        np.exp(-1j * z * L)
        / math.sqrt(L)
        * k
        * (1.0 - parity * np.exp(1j * z * D))
        / (k * k - z * z)
    )


def omega(r):
    return np.real(digamma(0.25 + 0.5j * r)) - math.log(math.pi)


def multiplier(r):
    return omega(r) - 2.0 * W2 * np.cos(TAU * r)


def gauss_interval(a, b, n):
    nodes, weights = np.polynomial.legendre.leggauss(n)
    r = 0.5 * (b - a) * nodes + 0.5 * (a + b)
    w = 0.5 * (b - a) * weights
    return r, w


def arch_matrix(ns, L, rmax, rpoints):
    r, w = gauss_interval(-rmax, rmax, rpoints)
    F = ft_sine_real(r, ns, L)
    Om = omega(r)
    M = F.conj().T @ ((w * Om)[:, None] * F) / (2.0 * math.pi)
    return 0.5 * (M + M.conj().T)


def prime_corr_matrix(ns, L, tau, qpoints=700):
    """
    R with c*Rc = Re <f,T_tau f>.
    For T_tau f(x)=f(x-tau), overlap x∈[tau-L,L].
    """
    a = tau - L
    b = L
    r, w = gauss_interval(a, b, qpoints)

    D = 2.0 * L
    nsf = np.asarray(ns, dtype=float)
    k = nsf * math.pi / D

    Phi = np.sin((r[:, None] + L) * k[None, :]) / math.sqrt(L)
    Phi_shift = (
        np.sin((r[:, None] - tau + L) * k[None, :]) / math.sqrt(L)
    )
    M = Phi.conj().T @ (w[:, None] * Phi_shift)
    return 0.5 * (M + M.conj().T)


def constraint_nullspace(ns, L):
    # In a fixed parity sector F(+i/2)=0 and F(-i/2)=0 are dependent,
    # so one complex/real constraint is sufficient.
    c = ft_sine_complex(0.5j, ns, L)[None, :]
    return null_space(c), c


def band_matrix(ns, L, a, b, qpoints=800):
    """
    Spectral-energy matrix for symmetric band [-b,-a] U [a,b].
    """
    r, w = gauss_interval(a, b, qpoints)
    F = ft_sine_real(r, ns, L)
    M = F.conj().T @ (w[:, None] * F) / (2.0 * math.pi)
    M = 2.0 * M
    return 0.5 * (M + M.conj().T)


def find_negative_bands(rmax=80.0, scan=40000):
    x = np.linspace(0.0, rmax, scan + 1)
    y = multiplier(x)
    roots = []

    for i in range(scan):
        if y[i] == 0.0:
            roots.append(float(x[i]))
        elif y[i] * y[i + 1] < 0:
            roots.append(
                float(
                    brentq(
                        lambda z: float(multiplier(np.array([z]))[0]),
                        x[i],
                        x[i + 1],
                    )
                )
            )

    # Deduplicate.
    rr = []
    for x0 in roots:
        if not rr or abs(x0 - rr[-1]) > 1e-8:
            rr.append(x0)

    bands = []
    left = 0.0
    sign = float(multiplier(np.array([1e-10]))[0]) < 0.0
    for r0 in rr:
        if sign:
            bands.append((left, r0))
        sign = not sign
        left = r0

    if sign:
        bands.append((left, rmax))

    return rr, bands


def spectral_mass(coef, ns, L, a, b, qpoints=1200):
    r, w = gauss_interval(a, b, qpoints)
    F = ft_sine_real(r, ns, L) @ coef
    return 2.0 * float(np.dot(w, np.abs(F) ** 2) / (2.0 * math.pi))


def analyze_sector(
    parity,
    nmax,
    rmax,
    rpoints,
    check_factor,
    roots,
    neg_bands,
):
    ns = sine_indices(nmax, parity)

    G1 = arch_matrix(ns, LSTAR, rmax, rpoints)
    G2 = arch_matrix(
        ns,
        LSTAR,
        rmax * check_factor,
        max(rpoints + 300, int(rpoints * check_factor)),
    )
    arch_delta = float(np.linalg.norm(G2 - G1, ord=2))
    G = G2

    R = prime_corr_matrix(ns, LSTAR, TAU)
    Q = -2.0 * W2 * R

    Z, C = constraint_nullspace(ns, LSTAR)
    Gp = 0.5 * (Z.conj().T @ G @ Z + (Z.conj().T @ G @ Z).conj().T)
    Qp = 0.5 * (Z.conj().T @ Q @ Z + (Z.conj().T @ Q @ Z).conj().T)
    Wp = 0.5 * (Gp + Qp + (Gp + Qp).conj().T)

    g_eigs = np.linalg.eigvalsh(Gp)
    w_eigs, w_vecs = np.linalg.eigh(Wp)

    if g_eigs[0] <= 0:
        mu_min = float("nan")
        mu_vec = None
    else:
        mu_eigs, mu_vecs = eigh(Qp, Gp)
        mu_min = float(mu_eigs[0])
        mu_vec = mu_vecs[:, 0]

    # Lowest full-Weil vector, normalized in physical L2.
    zmin = w_vecs[:, 0]
    coef = Z @ zmin
    coef = coef / np.linalg.norm(coef)

    corr = float(np.real(coef.conj().T @ R @ coef))
    arch = float(np.real(coef.conj().T @ G @ coef))
    wval = arch - 2.0 * W2 * corr

    band_rows = []
    for bi, (a, b) in enumerate(neg_bands):
        B = band_matrix(ns, LSTAR, a, b)
        Bp = 0.5 * (Z.conj().T @ B @ Z + (Z.conj().T @ B @ Z).conj().T)
        max_conc = float(np.linalg.eigvalsh(Bp)[-1])
        actual = spectral_mass(coef, ns, LSTAR, a, b)
        band_rows.append(
            {
                "band_index": bi,
                "a": a,
                "b": b,
                "max_admissible_concentration": max_conc,
                "extremal_actual_concentration": actual,
            }
        )

    # Positive intervals for diagnostic mass accounting.
    intervals = []
    points = [0.0] + roots + [max(60.0, rmax)]
    for j in range(len(points) - 1):
        a, b = points[j], points[j + 1]
        mid = 0.5 * (a + b)
        sgn = float(multiplier(np.array([mid]))[0])
        actual = spectral_mass(coef, ns, LSTAR, a, b)
        intervals.append(
            {
                "a": a,
                "b": b,
                "multiplier_sign": "negative" if sgn < 0 else "positive",
                "extremal_mass": actual,
            }
        )

    return {
        "parity": parity,
        "basis_indices": [int(x) for x in ns.tolist()],
        "basis_dimension": len(ns),
        "admissible_dimension": Z.shape[1],
        "constraint_residual": float(np.linalg.norm(C @ coef)),
        "arch_crosscheck_norm": arch_delta,
        "arch_lambda_min": float(g_eigs[0]),
        "mu_min": mu_min,
        "weil_lambda_min": float(w_eigs[0]),
        "weil_extremal_arch": arch,
        "weil_extremal_prime_correlation": corr,
        "weil_extremal_prime_correlation_fraction_of_half_bound": corr / 0.5,
        "weil_extremal_value_recomputed": wval,
        "negative_band_concentrations": band_rows,
        "interval_masses": intervals,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basis-nmax", type=int, default=80)
    ap.add_argument("--rmax", type=float, default=260.0)
    ap.add_argument("--rpoints", type=int, default=2600)
    ap.add_argument("--check-factor", type=float, default=1.30)
    ap.add_argument(
        "--prefix",
        default="rot_rh_endpoint_uncertainty_v17",
    )
    args = ap.parse_args()

    print("=" * 126)
    print("ROT-RH v17 — FIRST-PRIME ENDPOINT / UNCERTAINTY REDUCTION")
    print("=" * 126)
    print(f"L* = 0.5 log 3             : {LSTAR:.12f}")
    print(f"tau = log 2                : {TAU:.12f}")
    print(f"w2 = log2/sqrt2            : {W2:.12f}")
    print(f"support diameter 2L*       : {2*LSTAR:.12f} = log 3")
    print(f"boundary overlap width      : {math.log(1.5):.12f} = log(3/2)")
    print(f"center width                : {math.log(4/3):.12f} = log(4/3)")
    print(f"basis n max                 : {args.basis_nmax}")
    print("Riemann zero ordinates used : NO")
    print("zeta / xi evaluations used  : NO")
    print()

    roots, neg_bands = find_negative_bands()
    print("Multiplier roots r>0:")
    for x in roots:
        print(f"  {x:.12f}")
    print("Negative bands:")
    for a, b in neg_bands:
        print(f"  [{a:.12f}, {b:.12f}]")

    cases = []
    all_band_rows = []

    for parity in tqdm(["even", "odd"], desc="Parity sectors", unit="sector"):
        c = analyze_sector(
            parity,
            args.basis_nmax,
            args.rmax,
            args.rpoints,
            args.check_factor,
            roots,
            neg_bands,
        )
        cases.append(c)
        for b in c["negative_band_concentrations"]:
            all_band_rows.append(
                [
                    0 if parity == "even" else 1,
                    b["band_index"],
                    b["a"],
                    b["b"],
                    b["max_admissible_concentration"],
                    b["extremal_actual_concentration"],
                ]
            )

    bands_csv = Path(f"{args.prefix}_BANDS.csv")
    np.savetxt(
        bands_csv,
        np.asarray(all_band_rows, dtype=float),
        delimiter=",",
        header=(
            "parity_code_0even_1odd,band_index,a,b,"
            "max_admissible_concentration,extremal_actual_concentration"
        ),
        comments="",
    )

    spectrum_rows = []
    for c in cases:
        code = 0 if c["parity"] == "even" else 1
        for it in c["interval_masses"]:
            spectrum_rows.append(
                [
                    code,
                    it["a"],
                    it["b"],
                    -1 if it["multiplier_sign"] == "negative" else 1,
                    it["extremal_mass"],
                ]
            )

    spectrum_csv = Path(f"{args.prefix}_SPECTRUM.csv")
    np.savetxt(
        spectrum_csv,
        np.asarray(spectrum_rows, dtype=float),
        delimiter=",",
        header="parity_code_0even_1odd,a,b,multiplier_sign,extremal_mass",
        comments="",
    )

    summary = {
        "version": 17,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "endpoint_reduction": {
            "Lstar": LSTAR,
            "statement": (
                "Positivity at L*=0.5 log 3 implies positivity for the whole "
                "first-prime window by nesting of compact-support spaces. "
                "At L*, the n=3 correlation is zero because log 3=2L*."
            ),
        },
        "parity_reduction": {
            "even_constraint": "integral f(x) cosh(x/2) dx = 0",
            "odd_constraint": "integral f(x) sinh(x/2) dx = 0",
        },
        "pole_factorization": {
            "statement": (
                "F(±i/2)=0 implies F(z)=(z^2+1/4)G(z); equivalently "
                "f=(-d^2+1/4)g with g supported on the same interval and "
                "g(±L*)=g'(±L*)=0."
            )
        },
        "multiplier": {
            "formula": "m(r)=Omega(r)-2(log2/sqrt2)cos(r log2)",
            "positive_roots": roots,
            "negative_bands": neg_bands,
        },
        "cases": cases,
        "next_theorem_target": (
            "Prove a pole-neutral time-frequency concentration inequality at "
            "L*=0.5 log 3 controlling the second negative band.  This single "
            "endpoint theorem proves the entire first-prime window."
        ),
        "files": {
            "bands": str(bands_csv),
            "spectrum": str(spectrum_csv),
        },
        "warning": (
            "Galerkin concentration/eigenvalue values are diagnostics only. "
            "The analytic reduction to one endpoint is exact."
        ),
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 126)
    print("RESULT")
    print("-" * 126)
    for c in cases:
        print(
            f"{c['parity']:<4}  "
            f"mu={c['mu_min']:+.9f}  "
            f"Wmin={c['weil_lambda_min']:+.6e}  "
            f"ArchMin={c['arch_lambda_min']:+.6e}  "
            f"corr/(1/2)={c['weil_extremal_prime_correlation_fraction_of_half_bound']:.4f}  "
            f"archΔ={c['arch_crosscheck_norm']:.2e}"
        )
        for b in c["negative_band_concentrations"]:
            print(
                f"      band[{b['a']:.3f},{b['b']:.3f}]  "
                f"maxConc={b['max_admissible_concentration']:.4f}  "
                f"extremal={b['extremal_actual_concentration']:.4f}"
            )

    print()
    print("Analytic verdict:")
    print("  * STOP scanning L across the one-prime window.")
    print("  * The whole window reduces exactly to L*=0.5 log 3.")
    print("  * The hard sector is even parity.")
    print("  * Pole neutrality suppresses the low negative frequency band.")
    print("  * The surviving obstruction is concentration in the second negative band.")
    print("  * Next proof route: a certified Slepian/uncertainty bound at this single endpoint.")
    print(f"\nbands    : {bands_csv}")
    print(f"spectrum : {spectrum_csv}")
    print(f"summary  : {js}")
    print("=" * 126)


if __name__ == "__main__":
    main()
