#!/usr/bin/env python3
"""
rot_rh_pole_neutral_schatten_v18.py

ROT-RH v18 — pole-neutral bandpass concentration / Schatten-moment audit.

No Riemann zero ordinates.
No zeta / xi evaluations.

Endpoint:
    L* = (1/2) log 3.

Hard negative band:
    B = [-r3,-r2] U [r2,r3],
where r2,r3 are positive roots of
    m(r)=Omega(r)-sqrt(2)log(2) cos(r log 2).

For even f supported on [-L*,L*], identify f with g=sqrt(2)f|_[0,L*].
The symmetric-band concentration operator on H=L2(0,L*) has kernel

  K_e(x,y) =
      [sin(r3(x-y))-sin(r2(x-y))]/[pi(x-y)]
    + [sin(r3(x+y))-sin(r2(x+y))]/[pi(x+y)].

The even pole constraint is
    <g,u> = 0,
    u(x) = cosh(x/2)/||cosh(. /2)||.

Let P=I-|u><u| and C=P K_e P.
Then C is positive trace class and

    lambda_max(C) <= (Tr C^p)^(1/p),  p=1,2,...

The p=1 trace admits the exact parity formula

  Tr K_e
    = L*(r3-r2)/pi
      + [Si(2 r3 L)-Si(2 r2 L)]/(2pi).

The pole constraint subtracts exactly <u,K_e u>.

For p=2,3:
  Tr C^2 = Tr K^2 - 2<u,K^2u> + <u,Ku>^2

  Tr C^3 = Tr K^3 - 3<u,K^3u>
           + 3<u,Ku><u,K^2u> - <u,Ku>^3.

All quantities are finite integrals of an elementary sinc-difference kernel.
This script evaluates them by high-order Gauss-Legendre Nyström quadrature
and cross-checks against an enlarged quadrature.

Important:
  The trace/Schatten inequalities are exact.
  Floating numerical values are an audit until interval-arithmetic
  quadrature encloses the moments.

This route is more faithful than applying standard single-band PSWF bounds
directly: our operator is a symmetric BANDPASS operator, restricted to even
parity and then to a codimension-one pole-neutral subspace.

Outputs:
  <prefix>_SUMMARY.json
  <prefix>_EIGEN.csv
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import digamma, sici
from scipy.optimize import brentq
from scipy.linalg import eigh


LSTAR = 0.5 * math.log(3.0)
TAU = math.log(2.0)
W2 = TAU / math.sqrt(2.0)


def omega(r):
    return np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)


def multiplier(r):
    return omega(r) - 2.0*W2*np.cos(TAU*r)


def positive_roots(rmax=30.0, scan=200000):
    x = np.linspace(0.0, rmax, scan+1)
    y = multiplier(x)
    rr = []
    for i in range(scan):
        if y[i] == 0.0:
            rr.append(float(x[i]))
        elif y[i]*y[i+1] < 0:
            rr.append(float(brentq(
                lambda z: float(multiplier(np.array([z]))[0]),
                x[i], x[i+1]
            )))
    out=[]
    for z in rr:
        if not out or abs(z-out[-1])>1e-9:
            out.append(z)
    return out


def sinc_band_kernel(d, a, b):
    d = np.asarray(d, dtype=float)
    out = np.empty_like(d)
    small = np.abs(d) < 1e-12
    out[small] = (b-a)/math.pi
    ds = d[~small]
    out[~small] = (
        np.sin(b*ds)-np.sin(a*ds)
    )/(math.pi*ds)
    return out


def build_operator(nq, a, b):
    z, w = np.polynomial.legendre.leggauss(nq)
    x = 0.5*LSTAR*(z+1.0)
    w = 0.5*LSTAR*w

    X = x[:,None]
    Y = x[None,:]

    Ke = (
        sinc_band_kernel(X-Y, a, b)
        + sinc_band_kernel(X+Y, a, b)
    )

    sw = np.sqrt(w)
    K = (sw[:,None]*Ke)*sw[None,:]
    K = 0.5*(K+K.T)

    u = sw*np.cosh(x/2.0)
    u = u/np.linalg.norm(u)

    P = np.eye(nq)-np.outer(u,u)
    C = P@K@P
    C = 0.5*(C+C.T)

    return x,w,K,u,C


def moment_data(K,u,C,max_p):
    a1 = float(u @ (K @ u))
    Ku = K@u
    K2u = K@Ku
    K3u = K@K2u

    trK = float(np.trace(K))
    trK2 = float(np.trace(K@K))
    trK3 = float(np.trace(K@K@K))

    uK2u = float(u@K2u)
    uK3u = float(u@K3u)

    exact_formulas = {
        1: trK-a1,
        2: trK2-2.0*uK2u+a1*a1,
        3: trK3-3.0*uK3u+3.0*a1*uK2u-a1**3,
    }

    moments={}
    bounds={}
    Cp=np.eye(C.shape[0])
    for p in range(1,max_p+1):
        Cp=Cp@C
        tr=float(np.trace(Cp))
        moments[p]=tr
        bounds[p]=tr**(1.0/p) if tr>=0 else float("nan")

    return {
        "a1_pole_concentration":a1,
        "trK":trK,
        "trK2":trK2,
        "trK3":trK3,
        "uK2u":uK2u,
        "uK3u":uK3u,
        "formula_moments":exact_formulas,
        "direct_moments":moments,
        "bounds":bounds,
    }


def one_run(nq,a,b,max_p):
    x,w,K,u,C=build_operator(nq,a,b)
    evals=np.linalg.eigvalsh(C)
    md=moment_data(K,u,C,max_p)
    return {
        "nq":nq,
        "lambda_max":float(evals[-1]),
        "lambda_second":float(evals[-2]),
        "lambda_min":float(evals[0]),
        "moments":md,
        "evals":evals,
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--quadrature",type=int,default=500)
    ap.add_argument("--check-quadrature",type=int,default=700)
    ap.add_argument("--max-p",type=int,default=6)
    ap.add_argument(
        "--prefix",
        default="rot_rh_pole_neutral_schatten_v18"
    )
    A=ap.parse_args()

    roots=positive_roots()
    if len(roots)<3:
        raise SystemExit("Could not locate the three expected positive roots.")
    r1,r2,r3=roots[:3]
    delta=r3-r2

    # Full symmetric two-band trace on L2[-L,L].
    tr_full=2.0*LSTAR*delta/math.pi

    # Even parity trace.
    si3=sici(2.0*r3*LSTAR)[0]
    si2=sici(2.0*r2*LSTAR)[0]
    tr_even=(
        LSTAR*delta/math.pi
        +(si3-si2)/(2.0*math.pi)
    )

    # Standard single-band prolate scaling parameter after modulation.
    c_standard=LSTAR*delta/2.0

    print("="*126)
    print("ROT-RH v18 — POLE-NEUTRAL SCHATTEN CONCENTRATION")
    print("="*126)
    print(f"L*                           : {LSTAR:.12f}")
    print(f"negative band positive half  : [{r2:.12f},{r3:.12f}]")
    print(f"band width                   : {delta:.12f}")
    print(f"full symmetric-band trace    : {tr_full:.12f}")
    print(f"even-parity trace exact      : {tr_even:.12f}")
    print(f"single-band prolate c        : {c_standard:.12f}")
    print("zero ordinates used          : NO")
    print("zeta / xi used               : NO")
    print()

    R1=one_run(A.quadrature,r2,r3,A.max_p)
    R2=one_run(A.check_quadrature,r2,r3,A.max_p)

    # Use enlarged run as displayed values.
    R=R2

    eig_csv=Path(f"{A.prefix}_EIGEN.csv")
    np.savetxt(
        eig_csv,
        np.column_stack([
            np.arange(len(R["evals"]),dtype=int),
            R["evals"]
        ]),
        delimiter=",",
        header="index,eigenvalue",
        comments=""
    )

    formula_resids={}
    for p in (1,2,3):
        formula_resids[str(p)]=abs(
            R["moments"]["formula_moments"][p]
            -R["moments"]["direct_moments"][p]
        )

    cross={}
    for p in range(1,A.max_p+1):
        cross[str(p)]=abs(
            R1["moments"]["bounds"][p]
            -R2["moments"]["bounds"][p]
        )

    summary={
        "version":18,
        "zero_ordinates_used":False,
        "zeta_xi_evaluations_used":False,
        "endpoint":{
            "Lstar":LSTAR,
            "roots":[r1,r2,r3],
            "hard_band":[r2,r3],
            "symmetric_band":[[-r3,-r2],[r2,r3]],
        },
        "normalization_correction":{
            "full_symmetric_trace":tr_full,
            "even_trace_exact":tr_even,
            "comment":(
                "The ~0.627 Landau-Pollak number is parity-scale, not the "
                "trace of the full symmetric two-band operator, whose trace "
                "is ~1.254.  The exact even trace has a small sine-integral correction."
            ),
        },
        "pole_neutral":{
            "constraint":"g perpendicular to cosh(x/2) on [0,L*]",
            "pole_vector_band_concentration":
                R["moments"]["a1_pole_concentration"],
            "constrained_trace":
                R["moments"]["direct_moments"][1],
        },
        "schatten":{
            "moments":{
                str(p):R["moments"]["direct_moments"][p]
                for p in range(1,A.max_p+1)
            },
            "lambda_upper_bounds":{
                str(p):R["moments"]["bounds"][p]
                for p in range(1,A.max_p+1)
            },
            "formula_residuals_p1_p3":formula_resids,
            "quadrature_crosscheck_bound_deltas":cross,
            "direct_lambda_max_audit":R["lambda_max"],
        },
        "exact_low_order_identities":{
            "TrC":"TrK-<u,Ku>",
            "TrC2":"TrK2-2<u,K2u>+<u,Ku>^2",
            "TrC3":"TrK3-3<u,K3u>+3<u,Ku><u,K2u>-<u,Ku>^3",
        },
        "standard_pswf_c":c_standard,
        "pswf_warning":(
            "Published PSWF bounds usually address one centered low-pass band "
            "on the full time interval.  Our exact hard operator is a symmetric "
            "bandpass, parity-restricted, then pole-neutral compression. "
            "Directly transplanting a lambda_0(c) bound is therefore not automatic."
        ),
        "next_target":(
            "Turn p=2 or p=3 moment integrals into interval-arithmetic enclosures, "
            "then combine the certified concentration bound with a weighted "
            "lower bound for the Weil multiplier.  The concentration bound alone "
            "does not yet prove endpoint Weil positivity."
        ),
        "files":{"eigen":str(eig_csv)},
    }

    js=Path(f"{A.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary,indent=2))

    print("Pole-neutral concentration:")
    print(f"  pole-vector band mass       : {R['moments']['a1_pole_concentration']:.12f}")
    print(f"  constrained trace (p=1)     : {R['moments']['bounds'][1]:.12f}")
    for p in range(2,A.max_p+1):
        print(
            f"  Schatten p={p} bound         : "
            f"{R['moments']['bounds'][p]:.12f}"
        )
    print(f"  direct lambda_max audit     : {R['lambda_max']:.12f}")
    print()
    print("Cross-check deltas:")
    for p in range(1,A.max_p+1):
        print(f"  p={p}: {cross[str(p)]:.3e}")
    print()
    print("Verdict:")
    print("  * Claude's trace idea is valid after correcting the symmetric-band/parity normalization.")
    print("  * Pole neutrality improves the trace bound from ~0.6276 to ~0.58368.")
    print("  * Schatten moments are dramatically sharper; p=3 is already near the true lambda_max.")
    print("  * Standard PSWF lambda_0 bounds are not directly the exact constrained bandpass problem.")
    print("  * Next proof step: certify these finite moment integrals, then attack the WEIGHTED multiplier inequality.")
    print(f"\neigen   : {eig_csv}")
    print(f"summary : {js}")
    print("="*126)


if __name__=="__main__":
    main()
