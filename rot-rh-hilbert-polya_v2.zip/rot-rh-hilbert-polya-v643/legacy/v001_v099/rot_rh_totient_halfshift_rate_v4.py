#!/usr/bin/env python3
"""
rot_rh_totient_halfshift_rate_v4.py

ROT–RH v4: safe-boundary omega=1/2 rate attack.

This reduces Suzuki's omega=1/2 integrated kernel to one elementary
totient-weighted sum.  No Riemann zero ordinates, zeta, xi, or special
incomplete-beta evaluations are used.

Definitions
-----------
At omega = 1/2,

    c_{1/2}(n) = phi(n) / sqrt(n),

and Suzuki's integrated kernel simplifies to

    g_{1/2}^{<1>}(r)
      = 2/sqrt(r) *
        [ 2 sqrt(1-r^2) - arcosh(1/r) ],       0 < r <= 1.

Therefore

    Y(x) := sqrt(x) h_{1/2}^{<1>}(x)

has the elementary form

    Y(x) =
      2 sum_{n<=x} phi(n)/n *
      [ 2 sqrt(1-(n/x)^2) - arcosh(x/n) ].

The RH-scale target is

    Y(x) - 1 = O_eps(x^{-1/2+eps})  for every eps > 0.

Why this target matters
-----------------------
Suzuki's Mellin identity gives

    int_1^inf Y(x) x^{iz} dx/x = (i/z) Theta_{1/2}(z),

hence

    int_1^inf (Y(x)-1) x^{iz} dx/x
       = (i/z)(Theta_{1/2}(z)-1).

An O_eps(x^{-1/2+eps}) bound analytically continues the RHS to
Im z > -1/2.  At omega=1/2, any nontrivial zero rho=beta+i gamma
with beta>1/2 produces a non-cancelled pole of Theta_{1/2} in that
region.  Thus this rate is a sufficient RH criterion.

This script does NOT prove that rate.  It performs a prospective,
arithmetic-only finite test of scaled residuals

    R_eps(x) = x^(1/2-eps) |Y(x)-1|

on a frozen development range and larger holdouts.

It also tests the elementary kernel Riemann-sum asymptotic

    S(X) = sum_{m<=X} K(m/X)
         = 1/2 log X + c0 + O(X^(-1/2)),

where

    K(r) = 2 sqrt(1-r^2) - arcosh(1/r),
    c0 = 1/2 log(4 pi) - 1.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_RATE_SUMMARY.csv
<prefix>_KERNEL_SUMMARY.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


C0 = 0.5 * math.log(4.0 * math.pi) - 1.0


def parse_floats(text):
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def geom_checkpoints(xmin, xmax, points, forced=None):
    vals = np.geomspace(float(xmin), float(xmax), int(points))
    vals = np.unique(np.rint(vals).astype(np.int64))
    if forced:
        vals = np.unique(
            np.concatenate(
                [vals, np.asarray([int(v) for v in forced], dtype=np.int64)]
            )
        )
    vals = vals[(vals >= xmin) & (vals <= xmax)]
    if vals[0] != xmin:
        vals = np.insert(vals, 0, xmin)
    if vals[-1] != xmax:
        vals = np.append(vals, xmax)
    return vals


def phi_linear_python(nmax):
    """Pure-Python linear sieve fallback."""
    phi = np.zeros(nmax + 1, dtype=np.int64)
    phi[1] = 1
    primes = []
    is_comp = np.zeros(nmax + 1, dtype=np.bool_)

    for i in tqdm(range(2, nmax + 1), desc="Totient sieve", unit="n"):
        if not is_comp[i]:
            primes.append(i)
            phi[i] = i - 1
        for p in primes:
            ip = i * p
            if ip > nmax:
                break
            is_comp[ip] = True
            if i % p == 0:
                phi[ip] = phi[i] * p
                break
            phi[ip] = phi[i] * (p - 1)
    return phi


def build_phi(nmax):
    """
    Prefer numba JIT when available; fall back to exact Python linear sieve.
    """
    try:
        from numba import njit

        @njit(cache=True)
        def _phi_numba(N):
            phi = np.zeros(N + 1, dtype=np.int64)
            comp = np.zeros(N + 1, dtype=np.uint8)
            primes = np.empty(N + 1, dtype=np.int64)
            pc = 0
            phi[1] = 1

            for i in range(2, N + 1):
                if comp[i] == 0:
                    primes[pc] = i
                    pc += 1
                    phi[i] = i - 1

                j = 0
                while j < pc:
                    p = primes[j]
                    ip = i * p
                    if ip > N:
                        break
                    comp[ip] = 1
                    if i % p == 0:
                        phi[ip] = phi[i] * p
                        break
                    else:
                        phi[ip] = phi[i] * (p - 1)
                    j += 1

            return phi

        print("Totient backend             : numba linear sieve")
        # First call compiles; tqdm around the call would not show useful progress.
        return _phi_numba(int(nmax))
    except Exception as exc:
        print(f"Totient backend             : Python linear sieve ({exc})")
        return phi_linear_python(int(nmax))


def K_of_r(r):
    r = np.asarray(r, dtype=np.float64)
    r = np.clip(r, np.finfo(float).tiny, 1.0)
    sq = np.sqrt(np.maximum(0.0, 1.0 - r * r))
    return 2.0 * sq - np.arccosh(1.0 / r)


def Y_totient(x, phi):
    x = int(x)
    n = np.arange(1, x + 1, dtype=np.float64)
    r = n / float(x)
    kvals = K_of_r(r)
    weights = phi[1 : x + 1].astype(np.float64) / n
    return float(2.0 * np.dot(weights, kvals))


def S_kernel(X):
    X = int(X)
    m = np.arange(1, X + 1, dtype=np.float64)
    return float(np.sum(K_of_r(m / float(X))))


def fit_power(x, abs_resid):
    x = np.asarray(x, dtype=float)
    y = np.asarray(abs_resid, dtype=float)
    mask = y > 1e-15
    if np.count_nonzero(mask) < 4:
        return None, None

    lx = np.log(x[mask])
    ly = np.log(y[mask])
    A = np.column_stack([np.ones_like(lx), lx])
    coef, *_ = np.linalg.lstsq(A, ly, rcond=None)
    fit = A @ coef
    ss_res = float(np.sum((ly - fit) ** 2))
    ss_tot = float(np.sum((ly - np.mean(ly)) ** 2))
    r2 = None if ss_tot == 0 else float(1.0 - ss_res / ss_tot)
    return float(coef[1]), r2


def block_envelope(x, abs_resid, blocks):
    x = np.asarray(x, dtype=float)
    y = np.asarray(abs_resid, dtype=float)
    if len(x) < 2:
        return []

    edges = np.geomspace(x.min(), x.max(), blocks + 1)
    out = []
    for j in range(blocks):
        lo = edges[j]
        hi = edges[j + 1]
        if j == blocks - 1:
            mask = (x >= lo) & (x <= hi)
        else:
            mask = (x >= lo) & (x < hi)
        if np.any(mask):
            xx = x[mask]
            yy = y[mask]
            k = int(np.argmax(yy))
            out.append((float(xx[k]), float(yy[k])))
    return out


def main():
    ap = argparse.ArgumentParser(
        description="ROT-RH omega=1/2 elementary totient rate attack."
    )
    ap.add_argument("--x-min", type=int, default=200)
    ap.add_argument("--development-x-max", type=int, default=200000)
    ap.add_argument("--x-max", type=int, default=2000000)
    ap.add_argument("--checkpoints", type=int, default=120)
    ap.add_argument(
        "--epsilons",
        default="0.20,0.10,0.05,0.02,0.01",
        help="Tests x^(1/2-eps)|Y-1|.",
    )
    ap.add_argument("--envelope-safety", type=float, default=1.50)
    ap.add_argument("--envelope-blocks", type=int, default=12)
    ap.add_argument(
        "--kernel-X-values",
        default="100,300,1000,3000,10000,30000,100000,300000",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_totient_halfshift_rate_v4",
    )
    args = ap.parse_args()

    if not (2 <= args.x_min <= args.development_x_max < args.x_max):
        raise SystemExit(
            "Require 2 <= x-min <= development-x-max < x-max."
        )

    epsilons = parse_floats(args.epsilons)
    kernel_X = [int(v) for v in parse_floats(args.kernel_X_values)]

    checkpoints = geom_checkpoints(
        args.x_min,
        args.x_max,
        args.checkpoints,
        forced=[args.development_x_max],
    )

    print("=" * 120)
    print("ROT-RH ELEMENTARY TOTIENT HALF-SHIFT / RH-RATE AUDIT v4")
    print("=" * 120)
    print("omega                       : 1/2 (frozen)")
    print(f"x range                     : [{args.x_min:,}, {args.x_max:,}]")
    print(f"development x max           : {args.development_x_max:,}")
    print(f"checkpoints                 : {len(checkpoints)}")
    print(f"epsilons                    : {epsilons}")
    print(f"envelope safety             : {args.envelope_safety}")
    print(f"kernel asymptotic constant  : c0 = {C0:.15f}")
    print("Riemann zero ordinates used : NO")
    print("zeta / xi evaluations used  : NO")
    print("special beta functions used : NO")
    print()

    phi = build_phi(args.x_max)

    rows = []
    print("\nComputing Y_{1/2}(x) from Euler totients")
    for x in tqdm(checkpoints, desc="Totient checkpoints", unit="x"):
        Y = Y_totient(int(x), phi)
        resid = Y - 1.0
        abs_resid = abs(resid)

        row = [
            float(x),
            math.log(float(x)),
            Y,
            resid,
            abs_resid,
            math.sqrt(float(x)) * resid,
            math.sqrt(float(x)) * abs_resid,
        ]
        for eps in epsilons:
            row.append((float(x) ** (0.5 - eps)) * abs_resid)
        rows.append(row)

    arr = np.asarray(rows, dtype=float)

    # Write TRACK
    track_csv = Path(f"{args.prefix}_TRACK.csv")
    header = [
        "x",
        "log_x",
        "Y",
        "Y_minus_1",
        "abs_Y_minus_1",
        "sqrtx_signed_residual",
        "sqrtx_abs_residual",
    ] + [f"scaled_eps_{eps:g}" for eps in epsilons]
    np.savetxt(
        track_csv,
        arr,
        delimiter=",",
        header=",".join(header),
        comments="",
    )

    dev_mask = arr[:, 0] <= args.development_x_max
    hold_mask = arr[:, 0] > args.development_x_max

    if not np.any(dev_mask) or not np.any(hold_mask):
        raise SystemExit("Need both development and holdout checkpoints.")

    dev = arr[dev_mask]
    hold = arr[hold_mask]

    # Raw slope fits, with block-max envelope slope as a more robust diagnostic.
    raw_slope, raw_r2 = fit_power(arr[:, 0], arr[:, 4])
    env = block_envelope(
        arr[:, 0], arr[:, 4], int(args.envelope_blocks)
    )
    if env:
        ex = np.asarray([p[0] for p in env])
        ey = np.asarray([p[1] for p in env])
        env_slope, env_r2 = fit_power(ex, ey)
    else:
        env_slope = env_r2 = None

    rate_rows = []
    rate_details = []

    # columns 7 onward correspond epsilons
    for j, eps in enumerate(epsilons):
        col = 7 + j

        dev_max = float(np.max(dev[:, col]))
        hold_max = float(np.max(hold[:, col]))
        allowed = args.envelope_safety * dev_max
        pass_hold = bool(hold_max <= allowed)
        ratio = hold_max / dev_max if dev_max > 0 else float("inf")

        # Also compare late-development max, not just all development.
        dev_late = dev[dev[:, 0] >= max(args.x_min, args.development_x_max / 4)]
        dev_late_max = float(np.max(dev_late[:, col]))
        allowed_late = args.envelope_safety * dev_late_max
        pass_late = bool(hold_max <= allowed_late)

        rate_rows.append(
            [
                eps,
                0.5 - eps,
                dev_max,
                dev_late_max,
                hold_max,
                ratio,
                allowed,
                int(pass_hold),
                allowed_late,
                int(pass_late),
            ]
        )

        rate_details.append(
            {
                "epsilon": eps,
                "tested_decay_exponent": 0.5 - eps,
                "development_max_scaled_residual": dev_max,
                "late_development_max_scaled_residual": dev_late_max,
                "holdout_max_scaled_residual": hold_max,
                "holdout_over_development": ratio,
                "global_development_envelope_pass": pass_hold,
                "late_development_envelope_pass": pass_late,
            }
        )

    rate_arr = np.asarray(rate_rows, dtype=float)
    rate_csv = Path(f"{args.prefix}_RATE_SUMMARY.csv")
    np.savetxt(
        rate_csv,
        rate_arr,
        delimiter=",",
        header=(
            "epsilon,decay_exponent,development_max_scaled,"
            "late_development_max_scaled,holdout_max_scaled,"
            "holdout_over_development,allowed_global,pass_global,"
            "allowed_late,pass_late"
        ),
        comments="",
    )

    # Kernel Riemann-sum asymptotic audit.
    kernel_rows = []
    print("\nKernel Riemann-sum asymptotic audit")
    for X in tqdm(kernel_X, desc="Kernel X", unit="X"):
        S = S_kernel(X)
        model = 0.5 * math.log(float(X)) + C0
        err = S - model
        kernel_rows.append(
            [
                X,
                S,
                model,
                err,
                abs(err),
                math.sqrt(float(X)) * err,
                math.sqrt(float(X)) * abs(err),
            ]
        )

    kernel_arr = np.asarray(kernel_rows, dtype=float)
    kernel_csv = Path(f"{args.prefix}_KERNEL_SUMMARY.csv")
    np.savetxt(
        kernel_csv,
        kernel_arr,
        delimiter=",",
        header=(
            "X,S_X,half_logX_plus_c0,signed_error,abs_error,"
            "sqrtX_signed_error,sqrtX_abs_error"
        ),
        comments="",
    )

    all_sampled_positive = bool(np.all(arr[:, 2] > 0.0))
    holdout_positive = bool(np.all(hold[:, 2] > 0.0))

    summary = {
        "version": 4,
        "omega": 0.5,
        "construction": "elementary Euler-totient Suzuki half-shift kernel",
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "special_beta_functions_used": False,
        "x_min": args.x_min,
        "development_x_max": args.development_x_max,
        "x_max": args.x_max,
        "checkpoints": [int(x) for x in checkpoints],
        "epsilons": epsilons,
        "all_sampled_Y_positive": all_sampled_positive,
        "holdout_sampled_Y_positive": holdout_positive,
        "Y_last": float(arr[-1, 2]),
        "last_abs_residual": float(arr[-1, 4]),
        "sqrtx_last_abs_residual": float(arr[-1, 6]),
        "raw_loglog_residual_slope": raw_slope,
        "raw_loglog_residual_slope_r2": raw_r2,
        "block_envelope_slope": env_slope,
        "block_envelope_slope_r2": env_r2,
        "rate_tests": rate_details,
        "kernel_constant_c0": C0,
        "kernel_last_sqrtX_abs_error": float(kernel_arr[-1, 6]),
        "interpretation": {
            "rigorous_target": (
                "Prove Y(x)-1 = O_epsilon(x^(-1/2+epsilon)) "
                "for every epsilon>0. This is a sufficient RH criterion "
                "through Suzuki's Mellin identity at omega=1/2."
            ),
            "finite_pass": (
                "Scaled residuals on prospective holdouts remain below "
                "frozen development envelopes. This is numerical evidence only."
            ),
            "caution": (
                "The checkpoints are discrete. Positivity at sampled x values "
                "does not establish eventual positivity for every real x, and "
                "bounded finite scaled residuals do not establish an asymptotic bound."
            ),
        },
        "files": {
            "track": str(track_csv),
            "rate_summary": str(rate_csv),
            "kernel_summary": str(kernel_csv),
        },
    }

    summary_json = Path(f"{args.prefix}_SUMMARY.json")
    summary_json.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 120)
    print("SUMMARY")
    print("-" * 120)
    print(f"Y(x_max)                             : {arr[-1,2]:+.12f}")
    print(f"|Y(x_max)-1|                         : {arr[-1,4]:.6e}")
    print(f"sqrt(x_max)|Y(x_max)-1|              : {arr[-1,6]:.6e}")
    print(f"all sampled Y positive               : {all_sampled_positive}")
    print(f"holdout sampled Y positive           : {holdout_positive}")
    if raw_slope is not None:
        print(f"raw fitted residual power            : x^({raw_slope:+.5f})  R2={raw_r2:.4f}")
    if env_slope is not None:
        print(f"block-envelope fitted power          : x^({env_slope:+.5f})  R2={env_r2:.4f}")

    print("\nProspective RH-rate envelopes:")
    for d in rate_details:
        print(
            f"  eps={d['epsilon']:<6g} "
            f"target x^-{d['tested_decay_exponent']:.3f}  "
            f"dev={d['development_max_scaled_residual']:.4e}  "
            f"late-dev={d['late_development_max_scaled_residual']:.4e}  "
            f"hold={d['holdout_max_scaled_residual']:.4e}  "
            f"ratio={d['holdout_over_development']:.3f}  "
            f"late-pass={d['late_development_envelope_pass']}"
        )

    print("\nKernel asymptotic:")
    print(f"  c0 = 1/2 log(4 pi)-1              : {C0:.15f}")
    print(
        f"  last sqrt(X)|S-.5logX-c0|         : "
        f"{kernel_arr[-1,6]:.6e}"
    )

    print(f"\ntrack CSV                             : {track_csv}")
    print(f"rate summary CSV                      : {rate_csv}")
    print(f"kernel summary CSV                    : {kernel_csv}")
    print(f"summary JSON                          : {summary_json}")
    print()
    print("What would be genuinely significant:")
    print("  1. Prospective holdout envelopes remain stable as x_max is increased by orders of magnitude.")
    print("  2. The same remains true as epsilon is pushed toward zero.")
    print("  3. Analytically prove the x^(-1/2+epsilon) bound; finite computation cannot substitute for this.")
    print("=" * 120)


if __name__ == "__main__":
    main()
