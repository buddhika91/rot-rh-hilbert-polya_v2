#!/usr/bin/env python3
"""
rot_rh_primitive_trace_barrier_v10.py

ROT-RH v10 — primitive-prime Hilbert-Schmidt / trace barrier audit.

No Riemann zero ordinates.
No zeta / xi / prime-zeta evaluations.
No fitting to zero data.

For z = E + i eta (eta>0), define the diagonal prime-loop operator

    A(z) e_p = a_p(z) e_p,
    a_p(z) = p^(-1/2 + i z)
           = p^(-1/2-eta+iE).

Then for every eta>0,

    A(z), A'(z) in S_2,

because
    ||A'(z)||_2^2
      = sum_p (log p)^2 p^(-1-2 eta) < infinity.

But A'(z) is trace class only when eta>1/2:

    ||A'(z)||_1
      = sum_p log p p^(-1/2-eta).

The modified determinant

    D_2(z)=det_2(I-A(z))

therefore exists holomorphically throughout C_+, and

    -d_z log D_2(z)
      = Tr[ A'(z) A(z) (I-A(z))^(-1) ]
      = i sum_p sum_{m>=2}
            log p p^(-m/2 + i m z).

Thus every prime-power winding m>=2 is already an honest trace throughout
the upper half-plane.

The missing primitive winding is precisely

    Tr A'(z)
      = i sum_p log p p^(-1/2+i z),

which exists as an ordinary trace only for Im z>1/2.

PNT-centered trace
------------------
Let s = 1/2 + eta - iE.  We audit

    L_X(s) = sum_{p<=X} log(p) p^(-s),

and its centered finite part

    Lc_X(s) = L_X(s) - int_2^X x^(-s) dx.

At eta=1/2 (Re s=1), quantitative PNT is sufficient for convergence of
this centered finite part.  Extending a holomorphic centered trace to every
eta>0 is RH-strength: the meromorphic continuation of the primitive-prime
logarithmic derivative has poles in Re s>1/2 exactly at zeta zeros there
(after the known s=1 pole is removed).

Functional-analytic no-go
-------------------------
There is no continuous linear functional tau:S_2->C agreeing with the
ordinary trace on finite-rank operators.  If P_N is a rank-N projection,

    ||P_N||_2 = sqrt(N),   Tr(P_N)=N,

contradicting |tau(P_N)| <= C ||P_N||_2 for large N.

So the primitive sector cannot be recovered by an ordinary bounded
"renormalized trace" on the Hilbert-Schmidt ideal.  A successful mechanism
must supply additional non-Schatten structure: a singular boundary
functional, canonical-system/Weyl construction, or equivalent arithmetic
renormalization.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_ints(text):
    return [int(float(x.strip())) for x in str(text).split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in tqdm(range(2, r + 1), desc="Prime sieve", unit="p"):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve).astype(np.int64)


def power_integral(s, X, lower=2.0):
    """
    integral_lower^X x^{-s} dx.
    """
    one_minus_s = 1.0 - complex(s)
    if abs(one_minus_s) < 1e-14:
        return complex(math.log(X / lower))
    return (
        complex(X) ** one_minus_s
        - complex(lower) ** one_minus_s
    ) / one_minus_s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--energies", default="0,5,10,20")
    ap.add_argument("--etas", default="0.75,0.55,0.50,0.40,0.25,0.10,0.05")
    ap.add_argument(
        "--X-values",
        default="1000,3000,10000,30000,100000,300000,1000000,3000000,10000000",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_primitive_trace_barrier_v10",
    )
    args = ap.parse_args()

    energies = parse_floats(args.energies)
    etas = parse_floats(args.etas)
    checkpoints = sorted(set(parse_ints(args.X_values)))
    Xmax = max(checkpoints)

    print("=" * 124)
    print("ROT-RH PRIMITIVE-PRIME HILBERT-SCHMIDT / TRACE BARRIER AUDIT v10")
    print("=" * 124)
    print(f"energies                    : {energies}")
    print(f"etas                         : {etas}")
    print(f"X checkpoints               : {checkpoints}")
    print("Riemann zero ordinates used : NO")
    print("zeta / xi evaluations used  : NO")
    print()

    primes = prime_sieve(Xmax)
    print(f"primes <= Xmax              : {len(primes):,}")

    rows = []
    summaries = []

    for eta in tqdm(etas, desc="eta", unit="eta"):
        for E in energies:
            prev_centered = None
            prev_det2 = None

            for X in checkpoints:
                idx = np.searchsorted(primes, X, side="right")
                ps = primes[:idx].astype(np.float64)
                lp = np.log(ps)

                s = 0.5 + eta - 1j * E
                a = np.exp((-0.5 - eta + 1j * E) * lp)

                # Schatten diagnostics for A'(z).
                s2_sq = float(np.sum((lp * lp) * ps ** (-1.0 - 2.0 * eta)))
                s2_norm = math.sqrt(s2_sq)
                s1_partial = float(np.sum(lp * ps ** (-0.5 - eta)))

                # Primitive first winding.
                primitive = np.sum(lp * np.exp(-s * lp))
                centered = primitive - power_integral(s, X)

                # det_2 logarithmic derivative: exact m>=2 tower.
                det2_logder = 1j * np.sum(lp * a * a / (1.0 - a))

                # Finite full Euler derivative and exact split check.
                full_finite = 1j * np.sum(lp * a / (1.0 - a))
                primitive_i = 1j * primitive
                split_error = abs(full_finite - (primitive_i + det2_logder))

                if prev_centered is None:
                    centered_inc = float("nan")
                    det2_inc = float("nan")
                else:
                    centered_inc = abs(centered - prev_centered)
                    det2_inc = abs(det2_logder - prev_det2)

                prev_centered = centered
                prev_det2 = det2_logder

                rows.append(
                    [
                        eta, E, X, idx,
                        s2_norm, s1_partial,
                        primitive.real, primitive.imag,
                        centered.real, centered.imag, abs(centered),
                        centered_inc,
                        det2_logder.real, det2_logder.imag, abs(det2_logder),
                        det2_inc,
                        split_error,
                    ]
                )

    arr = np.asarray(rows, dtype=float)
    csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        csv,
        arr,
        delimiter=",",
        header=(
            "eta,E,X,prime_count,"
            "A_prime_S2_norm,A_prime_S1_partial,"
            "primitive_real,primitive_imag,"
            "centered_real,centered_imag,centered_abs,centered_increment,"
            "det2_logder_real,det2_logder_imag,det2_logder_abs,det2_increment,"
            "full_split_identity_error"
        ),
        comments="",
    )

    for eta in etas:
        for E in energies:
            sub = arr[
                np.isclose(arr[:, 0], eta)
                & np.isclose(arr[:, 1], E)
            ]
            cinc = sub[:, 11]
            dinc = sub[:, 15]
            finite_c = cinc[np.isfinite(cinc)]
            finite_d = dinc[np.isfinite(dinc)]

            summaries.append(
                {
                    "eta": eta,
                    "E": E,
                    "S2_norm_last": float(sub[-1, 4]),
                    "S1_partial_last": float(sub[-1, 5]),
                    "centered_last": [
                        float(sub[-1, 8]),
                        float(sub[-1, 9]),
                    ],
                    "centered_tail_max_increment": float(
                        np.max(finite_c[-3:]) if len(finite_c) else float("nan")
                    ),
                    "det2_tail_max_increment": float(
                        np.max(finite_d[-3:]) if len(finite_d) else float("nan")
                    ),
                    "split_identity_error_last": float(sub[-1, 16]),
                }
            )

    summary = {
        "version": 10,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "operator_family": (
            "A(z)=diag_p p^(-1/2+i z), z=E+i eta"
        ),
        "theorems": {
            "S2_upper_half_plane": (
                "A'(z) is Hilbert-Schmidt for every eta>0 because "
                "sum_p (log p)^2 p^(-1-2eta)<infinity."
            ),
            "trace_threshold": (
                "A'(z) is trace class iff eta>1/2; eta=1/2 is the "
                "PNT-renormalized threshold."
            ),
            "det2_identity": (
                "-d_z log det_2(I-A(z)) = "
                "Tr[A'(z)A(z)(I-A(z))^-1], giving exactly all m>=2 windings."
            ),
            "no_continuous_trace": (
                "No continuous linear tau:S2->C can agree with the ordinary "
                "trace on finite-rank operators: rank-N projections give "
                "N <= C sqrt(N), impossible."
            ),
            "RH_trace_criterion": (
                "After subtracting the known s=1 continuum pole, a holomorphic "
                "renormalized primitive trace on the whole eta>0 half-plane "
                "that agrees with Tr A'(z) for eta>1/2 would analytically "
                "continue the primitive-prime logarithmic derivative through "
                "Re s>1/2.  Its only possible interior singularities there "
                "are nontrivial zeta zeros with Re rho>1/2; by functional "
                "equation symmetry, absence of such poles is equivalent to RH."
            ),
        },
        "case_summaries": summaries,
        "files": {"track": str(csv)},
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 124)
    print("SUMMARY")
    print("-" * 124)

    for eta in etas:
        sub_eta = [s for s in summaries if abs(s["eta"] - eta) < 1e-14]
        max_s2 = max(s["S2_norm_last"] for s in sub_eta)
        max_s1 = max(s["S1_partial_last"] for s in sub_eta)
        max_c = max(s["centered_tail_max_increment"] for s in sub_eta)
        max_d = max(s["det2_tail_max_increment"] for s in sub_eta)
        print(
            f"eta={eta:<5g}  "
            f"S2={max_s2:.4e}  "
            f"S1partial={max_s1:.4e}  "
            f"centered_tail_d={max_c:.4e}  "
            f"det2_tail_d={max_d:.4e}"
        )

    print()
    print("Exact conclusion:")
    print("  * The operator-valued primitive sector exists in S2 for every Im z>0.")
    print("  * The scalar trace disappears precisely below Im z=1/2.")
    print("  * det_2 still gives every m>=2 prime-power winding throughout C_+.")
    print("  * Therefore the entire critical obstruction is a singular scalarization")
    print("    of A'(z), not existence of the prime-channel operator itself.")
    print("  * A bounded Schatten-class trace cannot provide that scalarization.")
    print("  * A holomorphic arithmetic renormalized trace on all C_+ would be RH-strength.")
    print(f"\ntrack   : {csv}")
    print(f"summary : {js}")
    print("=" * 124)


if __name__ == "__main__":
    main()
