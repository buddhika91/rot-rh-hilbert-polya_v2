#!/usr/bin/env python3
"""
rot_rh_centered_dirac_transfer_v8.py

ROT–RH v8 — centered half-log Dirac transfer / nonlinear contamination audit.

No Riemann zero ordinates.
No zeta or xi evaluations.
No fitting to spectral data.

Model
-----
Take the massless two-channel Dirac equation on t >= 0,

    H psi = E psi,
    H = -i sigma_3 d/dt + sigma_1 q,

with the centered half-log von Mangoldt measure

    dq(t) = g [
        gamma_E delta_0
        + sum_{n>=2} Lambda(n)/n delta_{(1/2)log n}
        - 2 dt
    ].

The primitive is C(2t), where

    C(T) = gamma_E + sum_{n<=exp(T)} Lambda(n)/n - T,

so the interaction is PNT-centered.

For a smooth segment with q=-2g,

    psi' = (i E sigma_3 - 2 g sigma_2) psi.

Across an arithmetic atom alpha = g Lambda(n)/n,

    psi(t_n+) = exp(alpha sigma_2) psi(t_n-).

Both segment and kick transfer matrices preserve the Dirac current:

    M^* sigma_3 M = sigma_3.

Interaction picture
-------------------
For g=0,

    P_E(t)=exp(i E sigma_3 t).

The first variation of the relative transfer is

    B1(E,T) = int_0^T Q_E(t) dnu(t),

    Q_E(t)=P_E(-t) sigma_2 P_E(t).

At t_n=(1/2)log n the lower-left phase is

    exp(2 i E t_n) = n^(iE),

so the first Born term contains exactly the centered Mangoldt Mellin phase

    J(E,T)
      = gamma_E
        + sum_{n<=exp(2T)} Lambda(n)/n * n^(iE)
        - (exp(2 i E T)-1)/(iE).

The upper-right entry is its conjugate.

The full self-adjoint transfer is nonlinear.  This script measures

    S_g(E,T) - I - g B1(E,T),

where

    S_g(E,T) = P_E(-T) M_g(E,T).

For small g, a non-zero limiting

    ||S_g-I-gB1|| / g^2

is the numerical signature of unavoidable second-order multiple scattering.
Those higher Magnus terms contain commutators

    [Q_E(t),Q_E(s)] ~ sigma_3 sin(2E(t-s)),

hence pairwise phases log(n/m), absent from the Riemann explicit formula.

The script also audits the "one-way nilpotent" escape route.  The raising
matrix sigma_+ would make all interaction-picture kicks proportional to the
same nilpotent generator and hence exactly linear, but it fails the
self-adjoint current condition

    N^* sigma_3 + sigma_3 N = 0.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


GAMMA_E = 0.577215664901532860606512090082402431

I2 = np.eye(2, dtype=np.complex128)
S2 = np.array([[0.0, -1j], [1j, 0.0]], dtype=np.complex128)
S3 = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)
SPLUS = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=np.complex128)


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_ints(text):
    return [int(float(x.strip())) for x in str(text).split(",") if x.strip()]


def prime_power_atoms(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))

    for p in tqdm(range(2, r + 1), desc="Sieve", unit="p"):
        if sieve[p]:
            sieve[p * p : nmax + 1 : p] = False

    primes = np.flatnonzero(sieve)
    ns = []
    lams = []

    for p in tqdm(primes, desc="Prime powers", unit="prime"):
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // p:
                break
            q *= p

    ns = np.asarray(ns, dtype=np.int64)
    lams = np.asarray(lams, dtype=np.float64)
    order = np.argsort(ns)
    ns = ns[order]
    lams = lams[order]

    weights = lams / ns.astype(np.float64)
    times = 0.5 * np.log(ns.astype(np.float64))
    return ns, lams, weights, times


def free_prop(E, t):
    return np.array(
        [[np.exp(1j * E * t), 0.0], [0.0, np.exp(-1j * E * t)]],
        dtype=np.complex128,
    )


def segment_prop(E, g, dt):
    """
    exp[(iE sigma3 - 2g sigma2) dt].
    A^2 = (4g^2-E^2) I.
    """
    if abs(dt) < 1e-18:
        return I2.copy()

    A = 1j * E * S3 - 2.0 * g * S2
    r2 = complex(4.0 * g * g - E * E)
    r = np.sqrt(r2 + 0j)

    if abs(r) < 1e-14:
        return I2 + A * dt

    return np.cosh(r * dt) * I2 + (np.sinh(r * dt) / r) * A


def kick(alpha):
    return np.cosh(alpha) * I2 + np.sinh(alpha) * S2


def current_residual(M):
    R = M.conj().T @ S3 @ M - S3
    return float(np.linalg.norm(R, ord="fro"))


def first_born_matrix(E, X, ns, weights, times):
    """
    B1 = int Q_E dnu on [0,T], T=0.5 log X.

    lower-left = i Jplus
    upper-right = -i conj(Jplus)
    """
    T = 0.5 * math.log(float(X))
    idx = np.searchsorted(ns, X, side="right")

    if idx:
        phase = np.exp(2j * E * times[:idx])
        atom_sum = np.dot(weights[:idx], phase)
    else:
        atom_sum = 0.0j

    if abs(E) < 1e-14:
        continuum = 2.0 * T
    else:
        continuum = (np.exp(2j * E * T) - 1.0) / (1j * E)

    Jp = GAMMA_E + atom_sum - continuum

    B = np.zeros((2, 2), dtype=np.complex128)
    B[1, 0] = 1j * Jp
    B[0, 1] = -1j * np.conj(Jp)
    return B, Jp


def transfer_track(E, g, checkpoints, ns, weights, times):
    """
    Cumulative physical transfer including gamma kick and centered
    continuum background.
    """
    M = kick(g * GAMMA_E)
    prev_t = 0.0
    ptr = 0
    rows = []

    for X in checkpoints:
        X = int(X)
        T = 0.5 * math.log(float(X))

        # Process all prime-power events up to X.
        while ptr < len(ns) and ns[ptr] <= X:
            te = float(times[ptr])
            if te > prev_t:
                M = segment_prop(E, g, te - prev_t) @ M
                prev_t = te

            M = kick(g * float(weights[ptr])) @ M
            ptr += 1

        # Propagate centered continuum to the checkpoint.
        if T > prev_t:
            M = segment_prop(E, g, T - prev_t) @ M
            prev_t = T

        Srel = free_prop(E, -T) @ M
        B1, Jp = first_born_matrix(E, X, ns, weights, times)

        linear = I2 + g * B1
        nonlinear = Srel - linear

        bnorm = float(np.linalg.norm(g * B1, ord="fro"))
        nnorm = float(np.linalg.norm(nonlinear, ord="fro"))

        rows.append(
            {
                "X": X,
                "T": T,
                "S": Srel.copy(),
                "J": Jp,
                "B1": B1.copy(),
                "current_residual": current_residual(Srel),
                "nonlinear_norm": nnorm,
                "linear_norm": bnorm,
                "nonlinear_over_linear": (
                    nnorm / bnorm if bnorm > 1e-300 else float("nan")
                ),
                "second_order_scaled": (
                    nnorm / (g * g) if abs(g) > 1e-300 else float("nan")
                ),
            }
        )

    return rows


def main():
    ap = argparse.ArgumentParser(
        description="Centered half-log self-adjoint Dirac transfer audit v8."
    )
    ap.add_argument("--energies", default="10,20,40")
    ap.add_argument("--g-values", default="1,0.3,0.1,0.03")
    ap.add_argument(
        "--X-values",
        default="1000,3000,10000,30000,100000,300000,1000000",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_centered_dirac_transfer_v8",
    )
    args = ap.parse_args()

    energies = parse_floats(args.energies)
    g_values = parse_floats(args.g_values)
    checkpoints = sorted(set(parse_ints(args.X_values)))

    if not checkpoints:
        raise SystemExit("No X checkpoints.")
    if min(checkpoints) < 2:
        raise SystemExit("All X checkpoints must be >=2.")

    Xmax = max(checkpoints)

    print("=" * 122)
    print("ROT-RH CENTERED HALF-LOG DIRAC TRANSFER / NONLINEARITY AUDIT v8")
    print("=" * 122)
    print(f"energies                      : {energies}")
    print(f"g values                      : {g_values}")
    print(f"X checkpoints                 : {checkpoints}")
    print("prime positions                : t_n = 0.5 log n")
    print("arithmetic weights             : Lambda(n)/n")
    print("centered background            : -2 dt")
    print("Riemann zero ordinates used    : NO")
    print("zeta / xi evaluations used     : NO")
    print()

    ns, lams, weights, times = prime_power_atoms(Xmax)
    print(f"prime-power atoms <= Xmax      : {len(ns):,}")

    # Exact algebraic no-go for one-way nilpotent coupling.
    infinitesimal_defect = np.linalg.norm(
        SPLUS.conj().T @ S3 + S3 @ SPLUS,
        ord="fro",
    )

    a_test = 0.1
    Ttri = I2 + a_test * SPLUS
    finite_defect = current_residual(Ttri)

    all_rows = []
    summaries = []

    jobs = [(E, g) for E in energies for g in g_values]

    for E, g in tqdm(jobs, desc="E/g cases", unit="case"):
        track = transfer_track(E, g, checkpoints, ns, weights, times)

        previous_S = None
        max_current = 0.0
        for item in track:
            S = item["S"]
            if previous_S is None:
                cauchy = float("nan")
            else:
                cauchy = float(np.linalg.norm(S - previous_S, ord="fro"))
            previous_S = S.copy()

            max_current = max(max_current, item["current_residual"])

            all_rows.append(
                [
                    E,
                    g,
                    item["X"],
                    item["T"],
                    item["J"].real,
                    item["J"].imag,
                    S[0, 0].real,
                    S[0, 0].imag,
                    S[0, 1].real,
                    S[0, 1].imag,
                    S[1, 0].real,
                    S[1, 0].imag,
                    S[1, 1].real,
                    S[1, 1].imag,
                    item["linear_norm"],
                    item["nonlinear_norm"],
                    item["nonlinear_over_linear"],
                    item["second_order_scaled"],
                    item["current_residual"],
                    cauchy,
                ]
            )

        last = track[-1]
        tail_changes = []
        for j in range(max(1, len(track) - 3), len(track)):
            tail_changes.append(
                float(
                    np.linalg.norm(
                        track[j]["S"] - track[j - 1]["S"],
                        ord="fro",
                    )
                )
            )

        summaries.append(
            {
                "E": E,
                "g": g,
                "Xmax": int(last["X"]),
                "J_last_real": float(last["J"].real),
                "J_last_imag": float(last["J"].imag),
                "nonlinear_norm_last": last["nonlinear_norm"],
                "nonlinear_over_linear_last": last["nonlinear_over_linear"],
                "second_order_scaled_last": last["second_order_scaled"],
                "max_current_residual": max_current,
                "tail_max_relative_transfer_increment": max(tail_changes),
            }
        )

    arr = np.asarray(all_rows, dtype=float)
    csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        csv,
        arr,
        delimiter=",",
        header=(
            "E,g,X,T,J_real,J_imag,"
            "S00_real,S00_imag,S01_real,S01_imag,"
            "S10_real,S10_imag,S11_real,S11_imag,"
            "linear_norm,nonlinear_norm,nonlinear_over_linear,"
            "second_order_scaled,current_residual,"
            "relative_transfer_increment"
        ),
        comments="",
    )

    # For each E, inspect whether nonlinear/g^2 stabilizes as g -> 0.
    small_g_analysis = []
    for E in energies:
        cases = [s for s in summaries if abs(s["E"] - E) < 1e-12]
        cases.sort(key=lambda d: d["g"])
        vals = [
            (d["g"], d["second_order_scaled_last"])
            for d in cases
            if d["g"] > 0
        ]
        small_g_analysis.append(
            {
                "E": E,
                "g_vs_second_order_scaled": vals,
                "smallest_g_second_order_scaled": vals[0][1] if vals else None,
            }
        )

    result = {
        "version": 8,
        "construction": (
            "self-adjoint massless Dirac with centered half-log "
            "von Mangoldt measure"
        ),
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "prime_positions": "t_n=0.5 log n",
        "weights": "Lambda(n)/n",
        "centered_measure": (
            "gamma_E delta_0 + sum Lambda(n)/n delta_(0.5 log n) - 2 dt"
        ),
        "first_born_identity": (
            "lower-left B1 = i[gamma_E + sum_{n<=X} Lambda(n)/n*n^(iE) "
            "- (exp(i E log X)-1)/(iE)]"
        ),
        "current_preservation": {
            "self_adjoint_transfer_condition": "M^* sigma3 M=sigma3",
            "one_way_sigma_plus_infinitesimal_defect": float(
                infinitesimal_defect
            ),
            "one_way_test_amplitude": a_test,
            "one_way_finite_current_defect": float(finite_defect),
        },
        "case_summaries": summaries,
        "small_g_analysis": small_g_analysis,
        "interpretation": {
            "positive_result": (
                "The self-adjoint half-log Dirac geometry produces the exact "
                "n^(iE)=exp(iE log n) Mangoldt phase at first order, while the "
                "PNT-centered measure gives a canonical infinite arithmetic input."
            ),
            "nonlinear_obstruction": (
                "At finite coupling, self-adjoint reciprocal channel mixing "
                "produces noncommuting transfer matrices and higher-order "
                "multiple-scattering phases involving log(n/m).  A nonzero "
                "g^-2-scaled residual as g->0 demonstrates the second-order term."
            ),
            "one_way_no_go": (
                "A one-way nilpotent generator would linearize the transfer "
                "exactly, but it violates current preservation and therefore "
                "cannot define the desired self-adjoint Dirac interaction."
            ),
            "spectral_no_go": (
                "The centered interaction is asymptotically short-range after "
                "a bounded gauge/transfer transformation; a local half-line "
                "Dirac realization therefore retains a continuum.  Discreteness "
                "must arise from a genuinely nonlocal/canonical-system closure, "
                "not another local decaying point-interaction tail."
            ),
        },
        "files": {"track": str(csv)},
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(result, indent=2))

    print("\n" + "-" * 122)
    print("SUMMARY")
    print("-" * 122)
    print(
        "one-way sigma_+ infinitesimal current defect : "
        f"{infinitesimal_defect:.6e}"
    )
    print(
        "one-way sigma_+ finite current defect         : "
        f"{finite_defect:.6e}  (amplitude={a_test})"
    )
    print()
    for s in summaries:
        print(
            f"E={s['E']:<6g} g={s['g']:<6g} "
            f"|NL|/|linear|={s['nonlinear_over_linear_last']:.3e}  "
            f"|NL|/g^2={s['second_order_scaled_last']:.3e}  "
            f"tail_dS={s['tail_max_relative_transfer_increment']:.3e}  "
            f"current={s['max_current_residual']:.2e}"
        )

    print()
    print("Decision:")
    print("  * If |NL|/g^2 approaches a non-zero value as g decreases, finite-coupling")
    print("    self-adjoint mirrors inevitably generate multiple-prime contamination.")
    print("  * The half-log phase is exact only in the linear response unless a new")
    print("    self-adjoint mechanism cancels all higher transfer/Magnus terms.")
    print("  * Do not try to compactify this with a local confining potential; v7 showed")
    print("    that doing so destroys the all-prime logarithmic propagation channel.")
    print(f"\ntrack   : {csv}")
    print(f"summary : {js}")
    print("=" * 122)


if __name__ == "__main__":
    main()
