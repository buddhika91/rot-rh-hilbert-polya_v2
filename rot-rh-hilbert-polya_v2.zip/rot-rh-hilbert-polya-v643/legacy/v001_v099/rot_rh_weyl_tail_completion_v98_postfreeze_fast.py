#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v98 post-freeze FAST checker
-----------------------------------
Loads an already-frozen v98 Weyl-tail completion and performs only:
  * Xi(t)/Xi(0) on a coarser grid;
  * first few Xi log-moments;
  * raw vs tail-completed determinant RMS;
  * raw vs completed moment error.

No operator reconstruction and no zero-free stage is repeated.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np

EPS=1e-15

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def xi(mp,t):
    s=mp.mpf("0.5")+1j*mp.mpf(str(t))
    return mp.re(
        mp.mpf("0.5")*s*(s-1)
        *mp.power(mp.pi,-s/2)
        *mp.gamma(s/2)*mp.zeta(s)
    )

def xi_moments(mp,order):
    x0=xi(mp,0)
    vals=[]
    for m in range(1,order+1):
        print(f"[moment] {m}/{order}",flush=True)
        d=mp.diff(lambda t: mp.log(xi(mp,t)/x0),mp.mpf("0"),2*m)
        vals.append(float(-m*d/mp.factorial(2*m)))
    return np.asarray(vals,float)

def finite_det(roots,tgrid):
    inv2=1.0/(roots*roots)
    return np.asarray([float(np.prod(1-(t*t)*inv2)) for t in tgrid])

def sym_rms(a,b):
    return float(np.sqrt(np.mean(((a-b)/(1+np.abs(a)+np.abs(b)))**2)))

def rel_l2(a,b):
    return float(np.linalg.norm(a-b)/max(np.linalg.norm(b),EPS))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--v98-prefix",default="rot_rh_weyl_tail_completion_v98")
    ap.add_argument("--depth",type=int,default=48)
    ap.add_argument("--xi-dps",type=int,default=60)
    ap.add_argument("--post-moment-order",type=int,default=4)
    ap.add_argument("--identity-max",type=float,default=50.0)
    ap.add_argument("--identity-step",type=float,default=0.5)
    args=ap.parse_args()

    p=Path(args.v98_prefix).expanduser().resolve()
    archive=Path(str(p)+"_FROZEN_PRE_XI.npz")
    manifest=Path(str(p)+"_FROZEN_MANIFEST.json")
    if not archive.exists() or not manifest.exists():
        raise FileNotFoundError("Frozen v98 archive/manifest not found.")

    man=json.loads(manifest.read_text(encoding="utf-8"))
    sha=sha256_file(archive)
    if sha!=man["sha256"]:
        raise RuntimeError("Frozen v98 SHA mismatch.")

    data=np.load(archive,allow_pickle=False)
    d=args.depth
    roots=np.asarray(data[f"roots_d{d}"],float)
    cm=np.asarray(data[f"completed_moments_d{d}"],float)
    raw_saved=np.asarray(data[f"raw_det_d{d}"],float)
    comp_saved=np.asarray(data[f"completed_det_d{d}"],float)
    saved_t=np.asarray(data["tgrid"],float)

    # Interpolate saved zero-free determinant values onto a coarser subset only.
    mask=(saved_t<=args.identity_max+1e-12)
    idx=np.flatnonzero(mask)
    stride=max(1,int(round(args.identity_step/(saved_t[1]-saved_t[0]))))
    idx=idx[::stride]
    tgrid=saved_t[idx]
    raw=raw_saved[idx]
    comp=comp_saved[idx]

    print("="*120)
    print("ROT-RH v98 FAST POST-FREEZE CHECK")
    print("="*120)
    print("SHA verified        :",True)
    print("depth               :",d)
    print("Xi dps              :",args.xi_dps)
    print("Xi moments          :",args.post_moment_order)
    print("Xi grid points      :",len(tgrid))
    print("="*120)

    import mpmath as mp
    mp.mp.dps=args.xi_dps
    x0=xi(mp,0)

    print("[Xi] determinant grid",flush=True)
    xiv=np.asarray([float(xi(mp,float(t))/x0) for t in tgrid],float)

    print("[Xi] low-order moments",flush=True)
    xim=xi_moments(mp,args.post_moment_order)

    partial=np.asarray([
        float(np.sum(roots**(-2*m)))
        for m in range(1,args.post_moment_order+1)
    ])

    raw_det=sym_rms(raw,xiv)
    comp_det=sym_rms(comp,xiv)
    raw_mom=rel_l2(partial,xim)
    comp_mom=rel_l2(cm[:args.post_moment_order],xim)

    print("\n"+"="*120)
    print("RESULT")
    print("="*120)
    print("raw determinant symmetric RMS       :",f"{raw_det:.12e}")
    print("completed determinant symmetric RMS :",f"{comp_det:.12e}")
    print("determinant improvement factor      :",f"{raw_det/max(comp_det,EPS):.3f}x")
    print("raw moment relative L2              :",f"{raw_mom:.12e}")
    print("completed moment relative L2        :",f"{comp_mom:.12e}")
    print("moment improvement factor           :",f"{raw_mom/max(comp_mom,EPS):.3f}x")
    print("completed S1                        :",f"{cm[0]:.15e}")
    print("Xi S1                               :",f"{xim[0]:.15e}")
    print("S1 relative error                   :",f"{abs(cm[0]-xim[0])/abs(xim[0]):.12e}")
    print("RH proof                            : FALSE")
    print("="*120)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
