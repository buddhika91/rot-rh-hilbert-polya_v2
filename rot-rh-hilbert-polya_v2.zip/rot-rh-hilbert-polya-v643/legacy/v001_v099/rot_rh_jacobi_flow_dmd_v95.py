#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v95 — Zero-Free Spectral Decomposition of the Jacobi Operator Flow
=========================================================================

WHY
---
v93/v94 found genuine anti-persistence in the arithmetic-only recursive
counterflow amplitude, but neither persistence nor a simple period-2 reflection
law produced a valid causal model.

So v95 stops guessing recurrence formulas.

It treats the ZERO-FREE Jacobi-operator velocity trajectory itself as a
dynamical signal and asks:

    Does the real prime-driven operator flow possess coherent slow/oscillatory
    modes that extrapolate to untouched arithmetic cutoffs?

No Xi, zeta, or known Riemann-zero ordinate is evaluated anywhere in this file.

DENSE LOG-RESOLUTION LADDER
---------------------------
A log-uniform arithmetic cutoff ladder is generated between cutoff_min and
cutoff_max.  At every cutoff X_s the existing zero-free prime/Gamma construction
produces a positive Jacobi state

    c_s = [a_1,...,a_d, log b_1,...,log b_{d-1}].

Define operator velocity

    v_s = (c_s-c_{s-1}) / Delta log X_s.

DEVELOPMENT-ONLY DMD
--------------------
Using development velocities only:

  1. center/scale each Jacobi coefficient by development statistics;
  2. form snapshot matrices X=[z_1,...,z_{m-1}],
                           Y=[z_2,...,z_m];
  3. choose the reduced rank by a fixed singular-energy threshold;
  4. fit the standard truncated Dynamic Mode Decomposition map

         z_{s+1} = A_DMD z_s.

The DMD eigenvalues reveal temporal structure:
  * angle near 0      -> slow/persistent mode,
  * angle near pi     -> alternating / period-2 micromotion,
  * intermediate angle -> coherent oscillatory mode.

There is no zero-based rank selection or model selection.

BLIND TESTS
-----------
Two distinct untouched arithmetic tests are performed.

(A) Teacher-forced one-step:
    predict v_s from the ACTUAL previous blind velocity, then predict c_s from
    the actual previous state.  This tests whether the learned local dynamical
    law transfers.

(B) Autonomous rollout:
    starting only from the final development state/velocity, recursively evolve
    the DMD model through every blind cutoff.  This tests whether the operator
    flow itself can run without seeing blind states.

Baselines:
  * frozen endpoint state;
  * constant last-development velocity.

All predicted Jacobi matrices must remain positive.

SCRAMBLED CONTROLS
------------------
Independent permuted-prime-weight trajectories receive the identical DMD
procedure, including their own development-only SVD/rank.  The real arithmetic
blind gains are compared with the control distribution.

SCIENTIFIC INTERPRETATION
-------------------------
A PASS does not prove RH and does not establish a Hilbert-Polya operator.
It would establish a narrower, useful fact: the zero-free prime-driven Jacobi
operator trajectory contains arithmetic-specific low-dimensional dynamics that
survive autonomous blind extrapolation.  Those DMD modes could then guide the
form of a genuinely ROT-native autonomous recursion instead of guessing one.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

VERSION = "v95"
BUILD = "2026-08-17-zero-free-jacobi-flow-dmd-v95"
EPS = 1e-14


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def log_cutoffs(xmin: int, xmax: int, count: int) -> List[int]:
    if xmin <= 1 or xmax <= xmin or count < 10:
        raise ValueError("Need 1 < cutoff_min < cutoff_max and count >= 10.")
    vals = np.geomspace(float(xmin), float(xmax), int(count))
    out = []
    for x in vals:
        n = int(round(float(x)))
        if not out or n > out[-1]:
            out.append(n)
    if len(out) < count - 1:
        raise ValueError("Too many duplicate rounded cutoffs.")
    return out


def velocities(states: Sequence[np.ndarray], cutoffs: Sequence[int]) -> List[np.ndarray]:
    out = []
    for i in range(1, len(states)):
        dl = math.log(float(cutoffs[i]) / float(cutoffs[i-1]))
        out.append((np.asarray(states[i], float)-np.asarray(states[i-1], float))/dl)
    return out


def feature_standardizer(dev_vels: Sequence[np.ndarray]) -> Tuple[np.ndarray,np.ndarray]:
    V = np.vstack(dev_vels)
    mu = np.mean(V, axis=0)
    # RMS scale, with a robust floor tied to median nonzero scale.
    sd = np.sqrt(np.mean((V-mu)**2, axis=0))
    pos = sd[sd > 1e-12]
    floor = float(np.median(pos))*1e-3 if len(pos) else 1.0
    sd = np.maximum(sd, max(floor, 1e-12))
    return mu, sd


def standardize(v: np.ndarray, mu: np.ndarray, sd: np.ndarray) -> np.ndarray:
    return (np.asarray(v,float)-mu)/sd


def unstandardize(z: np.ndarray, mu: np.ndarray, sd: np.ndarray) -> np.ndarray:
    return mu + sd*np.asarray(z,float)


def choose_rank(svals: np.ndarray, energy: float, max_rank: int) -> int:
    s = np.asarray(svals,float)
    if len(s) == 0:
        return 1
    e = s*s
    total = float(np.sum(e))
    if total <= EPS:
        return 1
    frac = np.cumsum(e)/total
    r = int(np.searchsorted(frac, float(energy)) + 1)
    return max(1, min(r, int(max_rank), len(s)))


def fit_dmd(dev_vels: Sequence[np.ndarray], energy: float, max_rank: int):
    mu, sd = feature_standardizer(dev_vels)
    Z = np.vstack([standardize(v,mu,sd) for v in dev_vels])
    if len(Z) < 4:
        raise ValueError("Need >=4 development velocities for DMD.")

    X = Z[:-1].T
    Y = Z[1:].T
    U, s, Vh = np.linalg.svd(X, full_matrices=False)
    r = choose_rank(s, energy, max_rank)

    Ur = U[:, :r]
    sr = s[:r]
    Vr = Vh[:r, :].T

    Sinv = np.diag(1.0/np.maximum(sr,1e-12))
    Atilde = Ur.T @ Y @ Vr @ Sinv
    Afull = Y @ Vr @ Sinv @ Ur.T

    eigvals, eigvecs = np.linalg.eig(Atilde)

    fit_pred = (Afull @ X).T
    fit_true = Y.T
    fit_rel = float(
        np.linalg.norm(fit_pred-fit_true) /
        max(np.linalg.norm(fit_true), EPS)
    )

    return {
        "mu": mu,
        "sd": sd,
        "rank": r,
        "singular_values": s,
        "Afull": Afull,
        "Atilde": Atilde,
        "eigvals": eigvals,
        "fit_relative_error": fit_rel,
        "development_standardized": Z,
    }


def dmd_mode_rows(model) -> List[Dict[str,object]]:
    vals = np.asarray(model["eigvals"], complex)
    rows = []
    for j, lam in enumerate(vals):
        mag = float(abs(lam))
        angle = float(np.angle(lam))
        rows.append({
            "mode": j,
            "eigenvalue_real": float(np.real(lam)),
            "eigenvalue_imag": float(np.imag(lam)),
            "magnitude": mag,
            "angle_radians": angle,
            "angle_over_pi": angle/math.pi,
            "slow_score": float(math.exp(-(abs(angle)/0.35)**2)),
            "alternating_score": float(math.exp(-((math.pi-abs(angle))/0.35)**2)),
        })
    rows.sort(key=lambda r: -r["magnitude"])
    return rows


def spectral_summary(model) -> Dict[str,float]:
    vals = np.asarray(model["eigvals"],complex)
    if len(vals) == 0:
        return {
            "rank":0,
            "max_magnitude":float("nan"),
            "min_distance_to_minus1":float("nan"),
            "min_distance_to_plus1":float("nan"),
            "largest_angle_abs":float("nan"),
            "oscillatory_fraction":float("nan"),
        }
    angles = np.abs(np.angle(vals))
    return {
        "rank": int(model["rank"]),
        "max_magnitude": float(np.max(np.abs(vals))),
        "min_distance_to_minus1": float(np.min(np.abs(vals+1.0))),
        "min_distance_to_plus1": float(np.min(np.abs(vals-1.0))),
        "largest_angle_abs": float(np.max(angles)),
        "oscillatory_fraction": float(np.mean(angles > 0.6)),
        "near_nyquist_fraction": float(np.mean(angles > 2.4)),
        "development_fit_relative_error": float(model["fit_relative_error"]),
    }


def state_error(pred: np.ndarray, actual: np.ndarray) -> float:
    return float(
        np.linalg.norm(np.asarray(pred,float)-np.asarray(actual,float)) /
        max(np.linalg.norm(np.asarray(actual,float)), EPS)
    )


def state_to_positive(v92, c: np.ndarray, d: int) -> Tuple[bool,float]:
    J = v92.state_to_jacobi(np.asarray(c,float), d)
    eig = np.linalg.eigvalsh(J)
    return bool(np.min(eig) > 0.0), float(np.min(eig))


def predict_teacher_forced(
    v92,
    model,
    states,
    vels,
    cutoffs,
    dev_last,
    d,
):
    rows = []
    A = model["Afull"]
    mu, sd = model["mu"], model["sd"]

    # state index i corresponds to velocity index i-1 for transition i-1 -> i.
    for i in range(dev_last+1, len(states)):
        prev_vel = vels[i-2]
        zprev = standardize(prev_vel,mu,sd)
        zhat = A @ zprev
        vhat = unstandardize(zhat,mu,sd)
        dl = math.log(float(cutoffs[i])/float(cutoffs[i-1]))
        pred = states[i-1] + dl*vhat

        actual = states[i]
        frozen = states[i-1]
        # Constant local velocity baseline.
        const = states[i-1] + dl*prev_vel

        e = state_error(pred,actual)
        ep = state_error(frozen,actual)
        ec = state_error(const,actual)
        gain_p = (ep-e)/ep if ep>EPS else 0.0
        gain_c = (ec-e)/ec if ec>EPS else 0.0
        pos,mine = state_to_positive(v92,pred,d)

        rows.append({
            "cutoff":cutoffs[i],
            "target_index":i,
            "prediction_error":e,
            "persistence_error":ep,
            "constant_velocity_error":ec,
            "gain_vs_persistence":gain_p,
            "gain_vs_constant_velocity":gain_c,
            "positive_operator":pos,
            "minimum_eigenvalue":mine,
        })
    return rows


def predict_autonomous(
    v92,
    model,
    states,
    vels,
    cutoffs,
    dev_last,
    d,
):
    rows = []
    A = model["Afull"]
    mu, sd = model["mu"], model["sd"]

    c = np.asarray(states[dev_last],float).copy()
    z = standardize(vels[dev_last-1],mu,sd)

    c_frozen = np.asarray(states[dev_last],float).copy()
    v_const = np.asarray(vels[dev_last-1],float).copy()
    c_const = c_frozen.copy()

    for i in range(dev_last+1,len(states)):
        dl = math.log(float(cutoffs[i])/float(cutoffs[i-1]))

        z = A @ z
        vhat = unstandardize(z,mu,sd)
        c = c + dl*vhat

        c_const = c_const + dl*v_const

        actual = states[i]
        e = state_error(c,actual)
        ef = state_error(c_frozen,actual)
        ec = state_error(c_const,actual)
        gain_f = (ef-e)/ef if ef>EPS else 0.0
        gain_c = (ec-e)/ec if ec>EPS else 0.0
        pos,mine = state_to_positive(v92,c,d)

        rows.append({
            "cutoff":cutoffs[i],
            "target_index":i,
            "prediction_error":e,
            "frozen_endpoint_error":ef,
            "constant_velocity_error":ec,
            "gain_vs_frozen":gain_f,
            "gain_vs_constant_velocity":gain_c,
            "positive_operator":pos,
            "minimum_eigenvalue":mine,
        })
    return rows


def summarize_prediction(rows, gain_key):
    if not rows:
        return {
            "count":0,
            "mean_error":float("nan"),
            "mean_gain":float("nan"),
            "all_gain_positive":False,
            "positive_all":False,
        }
    return {
        "count":len(rows),
        "mean_error":float(np.mean([r["prediction_error"] for r in rows])),
        "mean_gain":float(np.mean([r[gain_key] for r in rows])),
        "all_gain_positive":bool(all(r[gain_key]>0 for r in rows)),
        "positive_all":bool(all(r["positive_operator"] for r in rows)),
    }


def evaluate_trajectory(
    base, v92, cutoffs, dev_last, depth, grid_points, family, seed,
    svd_energy, max_rank
):
    states, probs, roots, free = v92.build_trajectory(
        base, cutoffs, depth, grid_points, family, seed
    )
    vels = velocities(states,cutoffs)

    # development state indices 0..dev_last -> velocities 0..dev_last-1
    dev_vels = vels[:dev_last]
    model = fit_dmd(dev_vels,svd_energy,max_rank)

    teacher = predict_teacher_forced(
        v92,model,states,vels,cutoffs,dev_last,depth
    )
    auto = predict_autonomous(
        v92,model,states,vels,cutoffs,dev_last,depth
    )

    return {
        "states":states,
        "vels":vels,
        "model":model,
        "spectral":spectral_summary(model),
        "mode_rows":dmd_mode_rows(model),
        "teacher_rows":teacher,
        "autonomous_rows":auto,
        "teacher_summary_persistence":
            summarize_prediction(teacher,"gain_vs_persistence"),
        "teacher_summary_const":
            summarize_prediction(teacher,"gain_vs_constant_velocity"),
        "autonomous_summary_frozen":
            summarize_prediction(auto,"gain_vs_frozen"),
        "autonomous_summary_const":
            summarize_prediction(auto,"gain_vs_constant_velocity"),
    }


def z_and_percentile(real: float, controls: Sequence[float]):
    c = np.asarray(controls,float)
    mean = float(np.mean(c))
    sd = float(np.std(c,ddof=1)) if len(c)>1 else 0.0
    z = (real-mean)/sd if sd>EPS else float("inf")
    pct = float(np.mean(c<=real))
    return mean,sd,z,pct


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v92-module",
        default="rot_rh_operator_recursive_inertia_jacobi_v92_1",
    )
    ap.add_argument("--cutoff-min",type=int,default=8000)
    ap.add_argument("--cutoff-max",type=int,default=675000)
    ap.add_argument("--cutoff-count",type=int,default=20)
    ap.add_argument("--development-last",type=int,default=13)
    ap.add_argument("--depth",type=int,default=32)
    ap.add_argument("--grid-points",type=int,default=128)
    ap.add_argument("--svd-energy",type=float,default=0.95)
    ap.add_argument("--max-rank",type=int,default=8)
    ap.add_argument("--scrambled-controls",type=int,default=8)
    ap.add_argument("--seed",type=int,default=20260817)
    ap.add_argument("--prefix",default="rot_rh_jacobi_flow_dmd_v95")
    args=ap.parse_args()

    t0=time.time()
    cutoffs=log_cutoffs(args.cutoff_min,args.cutoff_max,args.cutoff_count)
    if not (6<=args.development_last<len(cutoffs)-2):
        raise ValueError("development-last must leave at least two blind states.")

    prefix=Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True,exist_ok=True)

    base=importlib.import_module(args.base_module)
    v92=importlib.import_module(args.v92_module)

    print("="*156)
    print("ROT-RH v95 — ZERO-FREE SPECTRAL DECOMPOSITION OF JACOBI OPERATOR FLOW")
    print("="*156)
    print("cutoffs                       :",cutoffs)
    print("development                  :",cutoffs[:args.development_last+1])
    print("blind                         :",cutoffs[args.development_last+1:])
    print("depth                         :",args.depth)
    print("SVD energy / max rank         :",args.svd_energy,args.max_rank)
    print("Xi/zeta/known zeros           : NONE")
    print("="*156)

    print("[1] Real arithmetic DMD",flush=True)
    real=evaluate_trajectory(
        base,v92,cutoffs,args.development_last,args.depth,args.grid_points,
        "signal",args.seed,args.svd_energy,args.max_rank
    )

    sp=real["spectral"]
    tf=real["teacher_summary_const"]
    au=real["autonomous_summary_const"]

    print("[real] rank                         :",sp["rank"])
    print("[real] development fit rel err      :",f"{sp['development_fit_relative_error']:.6e}")
    print("[real] min |lambda+1|               :",f"{sp['min_distance_to_minus1']:.6e}")
    print("[real] min |lambda-1|               :",f"{sp['min_distance_to_plus1']:.6e}")
    print("[real] near-Nyquist mode fraction   :",f"{sp['near_nyquist_fraction']:.6f}")
    print("[real] teacher gain vs const-v      :",f"{tf['mean_gain']:+.6%}",
          "all=",tf["all_gain_positive"])
    print("[real] autonomous gain vs const-v   :",f"{au['mean_gain']:+.6%}",
          "all=",au["all_gain_positive"])

    print("[2] Scrambled-prime DMD controls",flush=True)
    control_rows=[]
    teacher_gains=[]
    auto_gains=[]
    nyquist_fracs=[]
    minus1_dist=[]
    for rep in range(args.scrambled_controls):
        rr=evaluate_trajectory(
            base,v92,cutoffs,args.development_last,args.depth,args.grid_points,
            "permuted_weights",args.seed+100000*(rep+1),
            args.svd_energy,args.max_rank
        )
        tg=rr["teacher_summary_const"]["mean_gain"]
        ag=rr["autonomous_summary_const"]["mean_gain"]
        teacher_gains.append(tg)
        auto_gains.append(ag)
        nyquist_fracs.append(rr["spectral"]["near_nyquist_fraction"])
        minus1_dist.append(rr["spectral"]["min_distance_to_minus1"])
        control_rows.append({
            "rep":rep,
            "rank":rr["spectral"]["rank"],
            "development_fit_relative_error":
                rr["spectral"]["development_fit_relative_error"],
            "min_distance_to_minus1":
                rr["spectral"]["min_distance_to_minus1"],
            "near_nyquist_fraction":
                rr["spectral"]["near_nyquist_fraction"],
            "teacher_gain_vs_constant_velocity":tg,
            "teacher_all_gain_positive":
                rr["teacher_summary_const"]["all_gain_positive"],
            "autonomous_gain_vs_constant_velocity":ag,
            "autonomous_all_gain_positive":
                rr["autonomous_summary_const"]["all_gain_positive"],
            "autonomous_positive_all":
                rr["autonomous_summary_const"]["positive_all"],
        })
        print(
            f"  control {rep+1:02d}/{args.scrambled_controls}: "
            f"rank={rr['spectral']['rank']} "
            f"teacher={tg:+.3%} auto={ag:+.3%} "
            f"nyq={rr['spectral']['near_nyquist_fraction']:.3f}"
        )

    tmean,tsd,tz,tp=z_and_percentile(tf["mean_gain"],teacher_gains)
    amean,asd,az,apct=z_and_percentile(au["mean_gain"],auto_gains)

    # For near-Nyquist fraction, larger means stronger high-frequency mode content.
    nmean,nsd,nz,npct=z_and_percentile(
        sp["near_nyquist_fraction"],nyquist_fracs
    )

    # For distance to -1, SMALLER is more alternating; transform to negative distance.
    mmean,msd,mz,mpct=z_and_percentile(
        -sp["min_distance_to_minus1"],
        [-x for x in minus1_dist]
    )

    gates={
        "teacher_gain_positive":tf["mean_gain"]>0.0,
        "teacher_gain_positive_every_blind_step":tf["all_gain_positive"],
        "autonomous_gain_positive":au["mean_gain"]>0.0,
        "autonomous_gain_positive_every_blind_step":au["all_gain_positive"],
        "autonomous_predicted_jacobi_positive":au["positive_all"],
        "teacher_beats_scrambled_z2":tz>2.0,
        "teacher_beats_scrambled_percentile95":tp>=0.95,
        "autonomous_beats_scrambled_z2":az>2.0,
        "autonomous_beats_scrambled_percentile95":apct>=0.95,
    }

    if all(gates.values()):
        verdict=(
            "PASS_V95_ARITHMETIC_SPECIFIC_LOW_DIMENSIONAL_JACOBI_DYNAMICS__"
            "NEXT_DERIVE_ROT_GENERATOR_FROM_DMD_MODES"
        )
    elif tf["mean_gain"]>0 or au["mean_gain"]>0:
        verdict=(
            "PARTIAL_V95_JACOBI_FLOW_HAS_PREDICTIVE_MODES__"
            "BUT_AUTONOMOUS_OR_CONTROL_GATES_FAIL"
        )
    else:
        verdict=(
            "NO_GO_V95_LOW_DIMENSIONAL_DMD_DOES_NOT_EXPLAIN_ARITHMETIC_OPERATOR_FLOW"
        )

    modes_csv=Path(str(prefix)+"_REAL_DMD_MODES.csv")
    teacher_csv=Path(str(prefix)+"_REAL_TEACHER_BLIND.csv")
    auto_csv=Path(str(prefix)+"_REAL_AUTONOMOUS_BLIND.csv")
    controls_csv=Path(str(prefix)+"_SCRAMBLED_CONTROLS.csv")
    summary_json=Path(str(prefix)+"_SUMMARY.json")

    write_csv(modes_csv,real["mode_rows"])
    write_csv(teacher_csv,real["teacher_rows"])
    write_csv(auto_csv,real["autonomous_rows"])
    write_csv(controls_csv,control_rows)

    packet={
        "version":VERSION,
        "build":BUILD,
        "verdict":verdict,
        "RH_proof":False,
        "Xi_evaluated":False,
        "zeta_evaluated":False,
        "known_zero_ordinates_used":False,
        "cutoffs":cutoffs,
        "development_last_index":args.development_last,
        "real_spectral":sp,
        "real_teacher_vs_constant_velocity":tf,
        "real_autonomous_vs_constant_velocity":au,
        "control_comparisons":{
            "teacher":{
                "mean":tmean,"sd":tsd,"z":tz,"percentile":tp,
            },
            "autonomous":{
                "mean":amean,"sd":asd,"z":az,"percentile":apct,
            },
            "near_nyquist_fraction":{
                "real":sp["near_nyquist_fraction"],
                "mean":nmean,"sd":nsd,"z":nz,"percentile":npct,
            },
            "near_minus_one":{
                "real_distance":sp["min_distance_to_minus1"],
                "negative_distance_z":mz,
                "percentile":mpct,
            },
        },
        "gates":gates,
        "outputs":{
            "modes":str(modes_csv),
            "teacher_blind":str(teacher_csv),
            "autonomous_blind":str(auto_csv),
            "controls":str(controls_csv),
            "summary":str(summary_json),
        },
        "runtime_seconds":time.time()-t0,
    }
    summary_json.write_text(
        json.dumps(json_safe(packet),indent=2),
        encoding="utf-8",
    )

    print("\n"+"="*156)
    print("FINAL ZERO-FREE VERDICT")
    print("="*156)
    print("verdict                         :",verdict)
    print("DMD rank                        :",sp["rank"])
    print("development fit rel error       :",f"{sp['development_fit_relative_error']:.9e}")
    print("min distance to -1              :",f"{sp['min_distance_to_minus1']:.9e}")
    print("min distance to +1              :",f"{sp['min_distance_to_plus1']:.9e}")
    print("near-Nyquist fraction           :",f"{sp['near_nyquist_fraction']:.6f}")
    print("teacher gain vs constant-v      :",f"{tf['mean_gain']:+.6%}")
    print("teacher all blind positive      :",tf["all_gain_positive"])
    print("teacher control z/percentile    :",f"{tz:+.6f}",f"{tp:.6f}")
    print("autonomous gain vs constant-v   :",f"{au['mean_gain']:+.6%}")
    print("autonomous all blind positive   :",au["all_gain_positive"])
    print("autonomous positive Jacobi      :",au["positive_all"])
    print("autonomous control z/percentile :",f"{az:+.6f}",f"{apct:.6f}")
    print("Nyquist fraction control z/pct  :",f"{nz:+.6f}",f"{npct:.6f}")
    print("near-minus-one control z/pct    :",f"{mz:+.6f}",f"{mpct:.6f}")
    print("gates                           :",gates)
    print("Xi evaluated                    : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("summary                         :",summary_json)
    print("runtime seconds                 :",f"{time.time()-t0:.2f}")
    print("="*156)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
