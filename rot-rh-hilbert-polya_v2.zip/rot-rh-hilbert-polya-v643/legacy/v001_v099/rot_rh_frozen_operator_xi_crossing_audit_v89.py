#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v89 — Frozen-Operator Anti-False-Positive / Xi Crossing Audit
====================================================================

PURPOSE
-------
Do NOT change the v88 operator.

v88 produced a large improvement on the post-freeze Xi determinant metric, but:
  * the dimension-shape drift was still large;
  * effective rank was only moderate;
  * no-curvature and no-observer-feedback controls beat the full model;
  * the previous determinant grid stopped at t=12, before the first nontrivial
    critical-line zero.

v89 is therefore an anti-false-positive audit of the already-frozen v88
operators.

It tests:

PRE-XI / OPERATOR-ONLY
----------------------
1. SHA256 integrity of the frozen v88 NPZ.
2. Nested central-block consistency across d=17,25,33,49.
3. Scale-free leading spectral-ratio consistency across dimensions.
4. Trace/effective-rank/top-eigen diagnostics.

POST-FREEZE Xi
--------------
5. Higher held-out trace moments through configurable order (default 12).
6. Direct determinant comparison on:
       near-origin window,
       first-crossing window,
       multi-crossing window.
7. Extract Xi critical-line sign changes directly from Xi AFTER freeze
   (no stored zero ordinates) and compare them with operator determinant zeros
       E_j = s*/sqrt(lambda_j).
8. Compare against generic controls:
       isotropic K = I/d
       effective-rank isotropic K = diag(1/r,...,1/r,0,...)
   to detect whether a low-t Xi match is merely generic spectral flattening.
9. Score the already-frozen v88 ablation controls from the NPZ if present.

SCIENTIFIC BOUNDARY
-------------------
This script never changes K.  It is a falsification/diagnostic audit, not an RH
proof.  Xi is evaluated only after the frozen-file hash is verified.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import mpmath as mp
import numpy as np

VERSION = "v89"
BUILD = "2026-08-17-frozen-operator-anti-false-positive-xi-crossing-v89"
EPS = 1.0e-14


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in str(text).split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for k in row:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (complex, np.complexfloating)):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, mp.mpf):
        return mp.nstr(x, 50)
    if isinstance(x, mp.mpc):
        return {"real": mp.nstr(mp.re(x), 50), "imag": mp.nstr(mp.im(x), 50)}
    return x


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def trace_normalize(K: np.ndarray) -> np.ndarray:
    K = 0.5 * (K + K.conj().T)
    tr = float(np.trace(K).real)
    if tr <= EPS:
        raise ValueError("nonpositive trace")
    return K / tr


def spectral_stats(K: np.ndarray) -> Dict[str, float]:
    K = trace_normalize(K)
    lam = np.linalg.eigvalsh(K).real
    lam = np.maximum(lam, 0.0)
    p = lam / max(float(np.sum(lam)), EPS)
    pp = p[p > 1e-15]
    erank = float(np.exp(-np.sum(pp * np.log(pp))))
    return {
        "trace": float(np.sum(lam)),
        "effective_rank": erank,
        "top_fraction": float(np.max(p)),
        "min_eigenvalue": float(np.min(lam)),
        "max_eigenvalue": float(np.max(lam)),
    }


def central_block(Kbig: np.ndarray, dsmall: int) -> np.ndarray:
    dbig = Kbig.shape[0]
    if dsmall > dbig or (dbig - dsmall) % 2 != 0:
        raise ValueError(
            f"Cannot take centered nested block d={dsmall} from d={dbig}; "
            "dimensions must differ by an even number."
        )
    start = (dbig - dsmall) // 2
    return Kbig[start:start+dsmall, start:start+dsmall]


def relative_fro(A: np.ndarray, B: np.ndarray) -> float:
    return float(np.linalg.norm(A-B, "fro") / max(np.linalg.norm(A, "fro"), EPS))


def leading_ratio_vector(K: np.ndarray, count: int) -> np.ndarray:
    lam = np.linalg.eigvalsh(trace_normalize(K)).real
    lam = np.sort(np.maximum(lam, 0.0))[::-1]
    k = min(count, len(lam))
    if k < 2 or lam[0] <= EPS:
        return np.asarray([], dtype=float)
    # Scale-free ratios; first value is identically 1 and omitted.
    return lam[1:k] / lam[0]


def ratio_rms(a: np.ndarray, b: np.ndarray) -> float:
    k = min(len(a), len(b))
    if k == 0:
        return float("nan")
    aa, bb = a[:k], b[:k]
    return float(np.sqrt(np.mean(
        ((bb-aa)/np.maximum(np.abs(aa), 1e-15))**2
    )))


def determinant_from_eigs(lam: np.ndarray, t: complex, scale: float) -> complex:
    z = complex(t)
    x = (z*z)/(scale*scale)
    factors = 1.0 - x * lam
    return complex(np.prod(factors.astype(np.complex128)))


def xi_norm(v86, t: complex, xi0: mp.mpc) -> complex:
    z = mp.mpc(float(np.real(t)), float(np.imag(t)))
    y = v86.Xi_t(z) / xi0
    return complex(float(mp.re(y)), float(mp.im(y)))


def symmetric_error(a: complex, b: complex) -> float:
    # Stable through target zeros; unlike relative error it does not blow up.
    return abs(a-b) / max(1.0, abs(a), abs(b))


def absolute_rms(vals: Sequence[float]) -> float:
    x = np.asarray(vals, dtype=float)
    x = x[np.isfinite(x)]
    return float(np.sqrt(np.mean(x*x))) if len(x) else float("nan")


def sign_agreement(a: Sequence[complex], b: Sequence[complex]) -> float:
    ok, n = 0, 0
    for x, y in zip(a, b):
        if abs(np.imag(x)) > 1e-10 or abs(np.imag(y)) > 1e-10:
            continue
        rx, ry = float(np.real(x)), float(np.real(y))
        if abs(rx) < 1e-12 or abs(ry) < 1e-12:
            continue
        n += 1
        ok += int(np.sign(rx) == np.sign(ry))
    return float(ok/n) if n else float("nan")


def bisect_xi_zero(v86, a: float, b: float, iterations: int = 70) -> float:
    fa = mp.re(v86.Xi_t(mp.mpf(a)))
    fb = mp.re(v86.Xi_t(mp.mpf(b)))
    if fa == 0:
        return float(a)
    if fb == 0:
        return float(b)
    if fa*fb > 0:
        raise ValueError("interval does not bracket a Xi sign change")
    aa, bb = mp.mpf(a), mp.mpf(b)
    for _ in range(iterations):
        m = (aa+bb)/2
        fm = mp.re(v86.Xi_t(m))
        if fm == 0:
            aa = bb = m
            break
        if fa*fm <= 0:
            bb = m
            fb = fm
        else:
            aa = m
            fa = fm
    return float((aa+bb)/2)


def xi_sign_change_zeros(v86, tmax: float, step: float) -> List[float]:
    zeros: List[float] = []
    x0 = 0.0
    f0 = mp.re(v86.Xi_t(mp.mpf(x0)))
    x = step
    while x <= tmax + 1e-12:
        f = mp.re(v86.Xi_t(mp.mpf(x)))
        if f0 == 0:
            zeros.append(x0)
        elif f == 0 or f0*f < 0:
            zeros.append(bisect_xi_zero(v86, x0, x))
        x0, f0 = x, f
        x += step
    # remove accidental duplicates
    out = []
    for z in zeros:
        if not out or abs(z-out[-1]) > 1e-6:
            out.append(z)
    return out


def operator_energies(K: np.ndarray, scale: float) -> np.ndarray:
    lam = np.linalg.eigvalsh(trace_normalize(K)).real
    lam = np.sort(np.maximum(lam, 0.0))[::-1]
    lam = lam[lam > 1e-15]
    return scale / np.sqrt(lam)


def zero_match_metrics(pred: np.ndarray, target: Sequence[float], count: int) -> Dict[str, float]:
    n = min(count, len(pred), len(target))
    if n == 0:
        return {
            "count": 0,
            "rmse": float("nan"),
            "relative_rmse": float("nan"),
            "mae": float("nan"),
            "max_abs": float("nan"),
        }
    p = np.asarray(pred[:n], float)
    q = np.asarray(target[:n], float)
    e = p-q
    return {
        "count": int(n),
        "rmse": float(np.sqrt(np.mean(e*e))),
        "relative_rmse": float(np.sqrt(np.mean((e/q)**2))),
        "mae": float(np.mean(np.abs(e))),
        "max_abs": float(np.max(np.abs(e))),
    }


def generic_kernels(d: int, effective_rank: float) -> Dict[str, np.ndarray]:
    iso = np.eye(d, dtype=np.complex128) / d
    r = max(1, min(d, int(round(effective_rank))))
    low = np.zeros(d, dtype=float)
    low[:r] = 1.0/r
    rank_iso = np.diag(low).astype(np.complex128)
    return {
        "generic_isotropic": iso,
        f"generic_rank{r}_isotropic": rank_iso,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--frozen-npz",
        default="rot_rh_novelty_filtered_transport_kernel_v88_FROZEN_PRE_XI.npz",
    )
    ap.add_argument(
        "--manifest",
        default="rot_rh_novelty_filtered_transport_kernel_v88_FROZEN_MANIFEST.json",
    )
    ap.add_argument(
        "--v86-module",
        default="rot_rh_rot_native_recursive_hp_xi_identity_v86",
    )
    ap.add_argument("--dimensions", default="17,25,33,49")
    ap.add_argument("--leading-ratios", type=int, default=10)

    ap.add_argument("--xi-dps", type=int, default=100)
    ap.add_argument("--xi-radius", default="4")
    ap.add_argument("--xi-samples", type=int, default=2048)
    ap.add_argument("--moment-order", type=int, default=12)

    ap.add_argument("--real-grid-step", type=float, default=0.25)
    ap.add_argument("--near-max", type=float, default=12.0)
    ap.add_argument("--crossing-max", type=float, default=22.0)
    ap.add_argument("--multi-max", type=float, default=50.0)
    ap.add_argument("--complex-imag", default="0.5,1.0")
    ap.add_argument("--complex-real-step", type=float, default=1.0)

    ap.add_argument("--zero-scan-max", type=float, default=50.0)
    ap.add_argument("--zero-scan-step", type=float, default=0.10)
    ap.add_argument("--zero-match-count", type=int, default=8)

    # These are diagnostic gates, not theorem thresholds.
    ap.add_argument("--nested-block-gate", type=float, default=0.25)
    ap.add_argument("--leading-ratio-gate", type=float, default=0.25)
    ap.add_argument("--zero-relative-rmse-gate", type=float, default=0.05)
    ap.add_argument("--crossing-symmetric-rms-gate", type=float, default=0.25)
    ap.add_argument("--prefix", default="rot_rh_frozen_operator_xi_crossing_audit_v89")
    args = ap.parse_args()

    t0 = time.time()
    frozen_path = Path(args.frozen_npz).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    if not frozen_path.exists():
        raise FileNotFoundError(frozen_path)
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    actual_hash = sha256_file(frozen_path)
    expected_hash = str(manifest.get("sha256", manifest.get("frozen_sha256", "")))
    hash_ok = bool(expected_hash) and actual_hash.lower() == expected_hash.lower()

    print("="*152)
    print("ROT-RH v89 — FROZEN-OPERATOR ANTI-FALSE-POSITIVE / Xi CROSSING AUDIT")
    print("="*152)
    print("build                         :", BUILD)
    print("frozen operator              :", frozen_path)
    print("manifest                     :", manifest_path)
    print("expected SHA256              :", expected_hash)
    print("actual SHA256                :", actual_hash)
    print("hash verified                :", hash_ok)
    print("operator modification        : NONE")
    print("zero ordinates supplied      : NONE")
    print("="*152)

    if not hash_ok:
        raise RuntimeError("Frozen operator hash does not match the v88 manifest.")

    data = np.load(frozen_path, allow_pickle=False)
    dims = parse_ints(args.dimensions)
    Ks: Dict[int, np.ndarray] = {}
    for d in dims:
        key = f"K_full_d{d}"
        if key not in data:
            raise KeyError(f"{key} missing from {frozen_path}")
        Ks[d] = trace_normalize(np.asarray(data[key], dtype=np.complex128))

    dmax = max(dims)
    Kfull = Ks[dmax]
    full_stats = spectral_stats(Kfull)

    # ------------------------------------------------------------------
    # PRE-Xi A: nested compression and spectral ratios.
    # ------------------------------------------------------------------
    nested_rows = []
    nested_vals = []
    ratio_vals = []

    for da, db in zip(dims[:-1], dims[1:]):
        A = Ks[da]
        Bblock = trace_normalize(central_block(Ks[db], da))
        block_drift = relative_fro(A, Bblock)

        ra = leading_ratio_vector(A, args.leading_ratios)
        rb = leading_ratio_vector(Ks[db], args.leading_ratios)
        rdrift = ratio_rms(ra, rb)

        nested_vals.append(block_drift)
        ratio_vals.append(rdrift)
        nested_rows.append({
            "dimension_a": da,
            "dimension_b": db,
            "centered_block_relative_fro_drift": block_drift,
            "leading_eigenratio_relative_rms_drift": rdrift,
        })

    latest_nested = nested_vals[-1]
    latest_ratio = ratio_vals[-1]

    print("[pre-Xi] dmax effective rank         :", f"{full_stats['effective_rank']:.9g}")
    print("[pre-Xi] dmax top eigen fraction     :", f"{full_stats['top_fraction']:.9g}")
    print("[pre-Xi] latest centered-block drift :", f"{latest_nested:.9e}")
    print("[pre-Xi] latest leading-ratio drift  :", f"{latest_ratio:.9e}")

    # Discover already-frozen v88 control K matrices.
    frozen_models: Dict[str, np.ndarray] = {"full": Kfull}
    suffix = f"_d{dmax}"
    for key in data.files:
        if key.startswith("K_") and key.endswith(suffix) and key != f"K_full_d{dmax}":
            name = key[2:-len(suffix)]
            frozen_models[name] = trace_normalize(np.asarray(data[key], dtype=np.complex128))

    # Add generic non-ROT controls AFTER freeze. They are not candidate operators.
    for name, K in generic_kernels(dmax, full_stats["effective_rank"]).items():
        frozen_models[name] = K

    # No Xi has been called before this point.
    v86 = importlib.import_module(args.v86_module)
    mp.mp.dps = args.xi_dps

    # ------------------------------------------------------------------
    # POST-FREEZE B: higher Xi trace moments.
    # ------------------------------------------------------------------
    print("[post-freeze] computing Xi moments", flush=True)
    xi_sums, odd_max = v86.xi_power_sums(
        args.moment_order,
        mp.mpf(args.xi_radius),
        args.xi_samples,
    )
    S1 = float(xi_sums[0])
    if S1 <= 0:
        raise RuntimeError("Xi S1 is nonpositive; unexpected normalization failure.")

    # Every trace-normalized K has same one-constant scale.
    scale_star = math.sqrt(1.0 / S1)
    print("[post-freeze] one-constant scale*     :", f"{scale_star:.12g}")
    print("[post-freeze] odd log-Xi coeff max   :", mp.nstr(odd_max, 12))

    moment_rows = []
    model_moment_holdout: Dict[str, float] = {}
    for name, K in frozen_models.items():
        lam = np.linalg.eigvalsh(K).real
        lam = np.maximum(lam, 0.0)
        errs = []
        for n in range(1, args.moment_order+1):
            pred = float(np.sum((lam/(scale_star*scale_star))**n))
            target = float(xi_sums[n-1])
            rel = abs(pred-target)/max(abs(target), 1e-300)
            if n >= 2:
                errs.append(rel)
            moment_rows.append({
                "model": name,
                "n": n,
                "xi_power_sum": target,
                "operator_power_sum": pred,
                "relative_error": rel,
                "scale_setting_moment": (n == 1),
            })
        model_moment_holdout[name] = absolute_rms(errs)

    # ------------------------------------------------------------------
    # POST-FREEZE C: Xi sign changes / operator determinant zeros.
    # ------------------------------------------------------------------
    print("[post-freeze] scanning Xi sign changes directly", flush=True)
    xi_zeros = xi_sign_change_zeros(
        v86, args.zero_scan_max, args.zero_scan_step
    )
    print("[post-freeze] Xi sign-change roots found :", len(xi_zeros))

    zero_rows = []
    zero_metrics: Dict[str, Dict[str, float]] = {}
    for name, K in frozen_models.items():
        E = operator_energies(K, scale_star)
        met = zero_match_metrics(E, xi_zeros, args.zero_match_count)
        zero_metrics[name] = met
        n = int(met["count"])
        for j in range(n):
            zero_rows.append({
                "model": name,
                "index": j+1,
                "operator_energy": float(E[j]),
                "xi_sign_change_root_postfreeze": float(xi_zeros[j]),
                "absolute_error": float(E[j]-xi_zeros[j]),
                "relative_error": float((E[j]-xi_zeros[j])/xi_zeros[j]),
            })

    # ------------------------------------------------------------------
    # POST-FREEZE D: determinant windows.
    # ------------------------------------------------------------------
    xi0 = v86.Xi_t(0)
    windows = [
        ("near", 0.0, args.near_max, args.real_grid_step),
        ("crossing", 0.0, args.crossing_max, args.real_grid_step),
        ("multi", 0.0, args.multi_max, args.real_grid_step),
    ]

    identity_rows = []
    model_window_metrics: Dict[str, Dict[str, Dict[str, float]]] = {
        name: {} for name in frozen_models
    }

    # cache Xi real-grid values by t
    xi_cache: Dict[Tuple[float,float], complex] = {}

    for wname, lo, hi, step in windows:
        ts = []
        x = lo
        while x <= hi + 1e-12:
            ts.append(round(x, 12))
            x += step

        for name, K in frozen_models.items():
            lam = np.maximum(np.linalg.eigvalsh(K).real, 0.0)
            derrs, dvals, xvals = [], [], []
            for t in ts:
                key = (t, 0.0)
                if key not in xi_cache:
                    xi_cache[key] = xi_norm(v86, complex(t,0.0), xi0)
                target = xi_cache[key]
                D = determinant_from_eigs(lam, complex(t,0.0), scale_star)
                err = symmetric_error(D, target)
                derrs.append(err)
                dvals.append(D)
                xvals.append(target)
                identity_rows.append({
                    "window": wname,
                    "model": name,
                    "t_real": t,
                    "t_imag": 0.0,
                    "xi_norm_real": target.real,
                    "xi_norm_imag": target.imag,
                    "D_real": D.real,
                    "D_imag": D.imag,
                    "symmetric_error": err,
                })
            model_window_metrics[name][wname] = {
                "symmetric_rms": absolute_rms(derrs),
                "sign_agreement": sign_agreement(dvals, xvals),
            }

    # Complex held-out strip: avoid zero-relative-error pathology.
    complex_rows = []
    imag_grid = parse_floats(args.complex_imag)
    complex_errs: Dict[str, List[float]] = {name: [] for name in frozen_models}
    xr = 0.0
    real_points = []
    while xr <= args.crossing_max + 1e-12:
        real_points.append(round(xr, 12))
        xr += args.complex_real_step

    for y in imag_grid:
        for x in real_points:
            key = (x, y)
            if key not in xi_cache:
                xi_cache[key] = xi_norm(v86, complex(x,y), xi0)
            target = xi_cache[key]
            for name, K in frozen_models.items():
                lam = np.maximum(np.linalg.eigvalsh(K).real, 0.0)
                D = determinant_from_eigs(lam, complex(x,y), scale_star)
                err = symmetric_error(D, target)
                complex_errs[name].append(err)
                complex_rows.append({
                    "model": name,
                    "t_real": x,
                    "t_imag": y,
                    "xi_norm_real": target.real,
                    "xi_norm_imag": target.imag,
                    "D_real": D.real,
                    "D_imag": D.imag,
                    "symmetric_error": err,
                })

    # ------------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------------
    full_zero = zero_metrics["full"]
    full_cross = model_window_metrics["full"]["crossing"]["symmetric_rms"]
    full_multi = model_window_metrics["full"]["multi"]["symmetric_rms"]
    full_near = model_window_metrics["full"]["near"]["symmetric_rms"]
    full_complex = absolute_rms(complex_errs["full"])

    generic_names = [n for n in frozen_models if n.startswith("generic_")]
    generic_best_near = min(
        (model_window_metrics[n]["near"]["symmetric_rms"], n)
        for n in generic_names
    )
    generic_best_cross = min(
        (model_window_metrics[n]["crossing"]["symmetric_rms"], n)
        for n in generic_names
    )

    gates = {
        "nested_centered_block": latest_nested <= args.nested_block_gate,
        "leading_spectral_ratios": latest_ratio <= args.leading_ratio_gate,
        "first_zero_sequence": (
            math.isfinite(full_zero["relative_rmse"])
            and full_zero["relative_rmse"] <= args.zero_relative_rmse_gate
        ),
        "crossing_window_identity": full_cross <= args.crossing_symmetric_rms_gate,
        "beats_generic_near_origin": full_near < generic_best_near[0],
        "beats_generic_crossing_window": full_cross < generic_best_cross[0],
    }

    if all(gates.values()):
        verdict = (
            "PASS_V89_FROZEN_ROT_OPERATOR_SURVIVES_ANTI_FALSE_POSITIVE_AUDIT__"
            "NEXT_TEST_DIMENSION_AND_PRIME_CUTOFF_SCALING"
        )
    elif gates["first_zero_sequence"] and gates["beats_generic_crossing_window"]:
        verdict = (
            "PARTIAL_V89_NONTRIVIAL_XI_ZERO_SIGNAL__"
            "BUT_OPERATOR_LIMIT_OR_IDENTITY_GATES_FAIL"
        )
    elif gates["beats_generic_near_origin"] is False:
        verdict = (
            "NO_GO_V89_LOW_T_XI_MATCH_IS_NOT_BETTER_THAN_GENERIC_FLAT_KERNEL"
        )
    else:
        verdict = (
            "FAIL_V89_FROZEN_V88_OPERATOR_DOES_NOT_SURVIVE_BROAD_XI_IDENTITY_AUDIT"
        )

    # Outputs
    nested_csv = Path(str(prefix)+"_NESTED_DIMENSION.csv")
    moments_csv = Path(str(prefix)+"_MOMENTS.csv")
    zeros_csv = Path(str(prefix)+"_ZERO_CROSSINGS.csv")
    identity_csv = Path(str(prefix)+"_REAL_IDENTITY.csv")
    complex_csv = Path(str(prefix)+"_COMPLEX_IDENTITY.csv")
    verdict_json = Path(str(prefix)+"_VERDICT.json")

    write_csv(nested_csv, nested_rows)
    write_csv(moments_csv, moment_rows)
    write_csv(zeros_csv, zero_rows)
    write_csv(identity_csv, identity_rows)
    write_csv(complex_csv, complex_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "operator_modified": False,
        "frozen_hash_verified": hash_ok,
        "individual_zero_ordinates_supplied": False,
        "xi_zero_crossings_extracted_only_postfreeze": True,
        "pre_Xi": {
            "effective_rank": full_stats["effective_rank"],
            "top_eigen_fraction": full_stats["top_fraction"],
            "latest_centered_block_drift": latest_nested,
            "latest_leading_ratio_drift": latest_ratio,
        },
        "postfreeze_scale_star": scale_star,
        "full": {
            "moment_holdout_relative_rms": model_moment_holdout["full"],
            "zero_match": full_zero,
            "near_symmetric_rms": full_near,
            "crossing_symmetric_rms": full_cross,
            "multi_symmetric_rms": full_multi,
            "complex_strip_symmetric_rms": full_complex,
            "near_sign_agreement": model_window_metrics["full"]["near"]["sign_agreement"],
            "crossing_sign_agreement": model_window_metrics["full"]["crossing"]["sign_agreement"],
            "multi_sign_agreement": model_window_metrics["full"]["multi"]["sign_agreement"],
        },
        "generic_controls": {
            "best_near": {
                "name": generic_best_near[1],
                "symmetric_rms": generic_best_near[0],
            },
            "best_crossing": {
                "name": generic_best_cross[1],
                "symmetric_rms": generic_best_cross[0],
            },
        },
        "all_models": {
            name: {
                "moment_holdout_relative_rms": model_moment_holdout[name],
                "zero_match": zero_metrics[name],
                "near": model_window_metrics[name]["near"],
                "crossing": model_window_metrics[name]["crossing"],
                "multi": model_window_metrics[name]["multi"],
                "complex_strip_symmetric_rms": absolute_rms(complex_errs[name]),
            }
            for name in frozen_models
        },
        "gates": gates,
        "outputs": {
            "nested_dimension": str(nested_csv),
            "moments": str(moments_csv),
            "zero_crossings": str(zeros_csv),
            "real_identity": str(identity_csv),
            "complex_identity": str(complex_csv),
            "verdict": str(verdict_json),
        },
        "runtime_seconds": time.time()-t0,
    }
    verdict_json.write_text(
        json.dumps(json_safe(packet), indent=2),
        encoding="utf-8",
    )

    print("\n"+"="*152)
    print("FINAL CONSERVATIVE VERDICT")
    print("="*152)
    print("verdict                         :", verdict)
    print("operator modified               : FALSE")
    print("frozen hash verified            :", hash_ok)
    print("latest centered-block drift     :", f"{latest_nested:.9e}")
    print("latest leading-ratio drift      :", f"{latest_ratio:.9e}")
    print("effective rank                  :", f"{full_stats['effective_rank']:.9g}")
    print("top eigen fraction              :", f"{full_stats['top_fraction']:.9g}")
    print("post-freeze scale*              :", f"{scale_star:.12g}")
    print("higher moment holdout RMS       :", f"{model_moment_holdout['full']:.9e}")
    print("Xi roots found post-freeze      :", len(xi_zeros))
    print("operator/Xi zero match count    :", full_zero["count"])
    print("zero relative RMSE              :", f"{full_zero['relative_rmse']:.9e}")
    print("near [0,12] symmetric RMS       :", f"{full_near:.9e}")
    print("crossing window symmetric RMS   :", f"{full_cross:.9e}")
    print("multi window symmetric RMS      :", f"{full_multi:.9e}")
    print("complex strip symmetric RMS     :", f"{full_complex:.9e}")
    print("best generic near               :", generic_best_near[1], f"{generic_best_near[0]:.9e}")
    print("best generic crossing           :", generic_best_cross[1], f"{generic_best_cross[0]:.9e}")
    print("gates                           :", gates)
    print("Xi used to modify operator      : FALSE")
    print("zero ordinates supplied         : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", verdict_json)
    print("runtime seconds                 :", f"{time.time()-t0:.2f}")
    print("="*152)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
