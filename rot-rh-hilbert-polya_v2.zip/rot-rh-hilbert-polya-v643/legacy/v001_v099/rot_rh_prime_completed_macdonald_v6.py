#!/usr/bin/env python3
"""
ROT-RH v6 — prime-completed Macdonald audit.

Zero-free numerical audit of four analytic milestones:
  1) compact-resolvent self-adjoint confining completion,
  2) Riemann-von Mangoldt mean Weyl law,
  3) regulator-independent spectral convergence,
  4) convergence of finite-rank Fredholm determinant products.

No zeta, xi, or Riemann-zero data are used.
"""
import argparse, json, math
from pathlib import Path
import numpy as np
from tqdm import tqdm
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh

GAMMA=0.5772156649015328606

def floats(s): return [float(x) for x in s.split(',') if x.strip()]
def complexes(s): return [complex(x.strip().replace('i','j')) for x in s.split(',') if x.strip()]

def mangoldt_atoms(nmax):
    if nmax<2: return np.array([],int),np.array([],float)
    sieve=np.ones(nmax+1,bool); sieve[:2]=False
    for p in range(2,int(math.isqrt(nmax))+1):
        if sieve[p]: sieve[p*p:nmax+1:p]=False
    ns=[]; ls=[]
    for p in np.flatnonzero(sieve):
        q=int(p); lp=math.log(q)
        while q<=nmax:
            ns.append(q); ls.append(lp)
            if q>nmax//int(p): break
            q*=int(p)
    o=np.argsort(ns)
    return np.asarray(ns,int)[o],np.asarray(ls,float)[o]

def w(profile,r):
    r=np.asarray(r,float)
    if profile=='infinite': return np.ones_like(r)
    if profile=='exp': return np.exp(-r)
    if profile=='gauss': return np.exp(-r*r)
    if profile=='rational': return (1+r)**-2
    raise ValueError(profile)

def add(mat,ids,b):
    for i,ii in enumerate(ids):
        if ii is None: continue
        for j,jj in enumerate(ids):
            if jj is not None: mat[ii,jj]+=b[i,j]

def fem(tmax,ne,g,profile,L,arith=True):
    x=np.linspace(0,tmax,ne+1); h=x[1]-x[0]; nd=ne
    A=lil_matrix((nd,nd)); M=lil_matrix((nd,nd))
    K=np.array([[1,-1],[-1,1]],float)/h
    Ml=h*np.array([[2,1],[1,2]],float)/6
    for e in range(ne):
        tm=(x[e]+x[e+1])/2
        ids=[e, e+1 if e+1<nd else None]
        V=16*math.pi**2*math.exp(4*tm)
        if arith:
            hh=1.0 if profile=='infinite' else float(w(profile,[math.exp(tm)/L])[0])
            V-=g*hh
        add(A,ids,K+V*Ml); add(M,ids,Ml)
    if arith:
        h0=1.0 if profile=='infinite' else float(w(profile,[1/L])[0])
        A[0,0]+=g*GAMMA*h0
        ns,ls=mangoldt_atoms(int(math.floor(math.exp(tmax))))
        for n,lam in zip(ns,ls):
            t=math.log(int(n))
            if t>=tmax: continue
            e=min(int(t/h),ne-1); xi=(t-x[e])/h
            vals=np.array([1-xi,xi]); ids=[e,e+1 if e+1<nd else None]
            hh=1.0 if profile=='infinite' else float(w(profile,[n/L])[0])
            add(A,ids,g*(lam/n)*hh*np.outer(vals,vals))
    return csr_matrix(A),csr_matrix(M)

def eigs(A,M,k):
    k=min(k,A.shape[0]-2)
    return np.sort(np.real(eigsh(A,k=k,M=M,which='SA',return_eigenvectors=False)))

def meanN(E):
    E=np.asarray(E,float)
    return E/(2*math.pi)*np.log(E/(2*math.pi))-E/(2*math.pi)

def detK(vals,beta,E):
    z=complex(E)**2
    terms=1-(z+beta)/(vals+beta)
    return complex(np.exp(np.sum(np.log(terms.astype(complex)))))

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--t-max',type=float,default=3.0)
    p.add_argument('--elements',type=int,default=1200)
    p.add_argument('--eigs',type=int,default=80)
    p.add_argument('--g',type=float,default=1.0)
    p.add_argument('--L-values',default='4,8,16,32,64,128,256')
    p.add_argument('--profiles',default='exp,gauss,rational')
    p.add_argument('--beta',type=float,default=10.0)
    p.add_argument('--det-E-values',default='20+0.5j,40+0.5j,80+0.5j')
    p.add_argument('--prefix',default='rot_rh_prime_completed_macdonald_v6')
    a=p.parse_args(); Ls=floats(a.L_values); profiles=[s.strip() for s in a.profiles.split(',')]; tests=complexes(a.det_E_values)
    print('='*108); print('ROT-RH PRIME-COMPLETED MACDONALD AUDIT v6'); print('='*108)
    print('zero ordinates used        : NO'); print('zeta / xi evaluations used: NO')
    print(f't_max={a.t_max}, elements={a.elements}, eigs={a.eigs}, g={a.g}')
    A0,M=fem(a.t_max,a.elements,a.g,'infinite',1,False); v0=eigs(A0,M,a.eigs)
    Ai,Mi=fem(a.t_max,a.elements,a.g,'infinite',1,True); vi=eigs(Ai,Mi,a.eigs)
    E0=np.sqrt(np.maximum(v0,0)); Ei=np.sqrt(np.maximum(vi,0)); n=np.arange(1,len(vi)+1)
    np.savetxt(f'{a.prefix}_EIGENVALUES.csv',np.c_[n,v0,E0,vi,Ei,Ei-E0],delimiter=',',header='n,lambda_base,E_base,lambda_PC,E_PC,E_shift',comments='')
    np.savetxt(f'{a.prefix}_WEYL.csv',np.c_[n,E0,n-meanN(E0),Ei,n-meanN(Ei)],delimiter=',',header='n,E_base,NminusM_base,E_PC,NminusM_PC',comments='')
    cr=[]; dr=[]
    for prof,L in tqdm([(q,L) for q in profiles for L in Ls],desc='regulated operators'):
        AL,ML=fem(a.t_max,a.elements,a.g,prof,L,True); vl=eigs(AL,ML,a.eigs); El=np.sqrt(np.maximum(vl,0)); dE=El-Ei
        code={'exp':0,'gauss':1,'rational':2}[prof]
        cr.append([code,L,np.max(np.abs(dE)),np.sqrt(np.mean(dE*dE))])
        for Et in tests:
            d0=detK(vi,a.beta,Et); d1=detK(vl,a.beta,Et); err=abs(d1-d0)
            dr.append([code,L,Et.real,Et.imag,d1.real,d1.imag,d0.real,d0.imag,err,err/max(abs(d0),1e-300)])
    cr=np.asarray(cr); dr=np.asarray(dr)
    np.savetxt(f'{a.prefix}_CUTOFF.csv',cr,delimiter=',',header='profile_code,L,max_abs_E_error,rms_E_error',comments='')
    np.savetxt(f'{a.prefix}_DETERMINANT.csv',dr,delimiter=',',header='profile_code,L,E_real,E_imag,Delta_L_real,Delta_L_imag,Delta_inf_real,Delta_inf_imag,abs_error,relative_error',comments='')
    Lmax=max(Ls); last=cr[np.isclose(cr[:,1],Lmax)]; lastd=dr[np.isclose(dr[:,1],Lmax)]
    s={'version':6,'zero_ordinates_used':False,'zeta_xi_used':False,'t_max':a.t_max,'elements':a.elements,'eigs':a.eigs,'g':a.g,'L_values':Ls,'profiles':profiles,'lowest_PC_lambda':float(vi[0]),'last_E':float(Ei[-1]),'last_Weyl_residual':float(n[-1]-meanN(Ei[-1])),'largest_L_max_E_error':float(np.max(last[:,2])),'largest_L_max_partial_det_relative_error':float(np.max(lastd[:,9])),'warning':'Finite FEM/partial determinant audit only; the continuum theorems are analytic and no Xi identity is asserted.'}
    Path(f'{a.prefix}_SUMMARY.json').write_text(json.dumps(s,indent=2))
    print('-'*108); print('SUMMARY'); print('-'*108)
    print(f'lowest PC lambda                 : {vi[0]:.9f}')
    print(f'last computed E                  : {Ei[-1]:.9f}')
    print(f'last N-M(E)                      : {s["last_Weyl_residual"]:+.6e}')
    print(f'largest-L max |E_L-E_inf|        : {s["largest_L_max_E_error"]:.6e}')
    print(f'largest-L max partial det relerr : {s["largest_L_max_partial_det_relative_error"]:.6e}')
    print(f'summary                          : {a.prefix}_SUMMARY.json')

if __name__=='__main__': main()
