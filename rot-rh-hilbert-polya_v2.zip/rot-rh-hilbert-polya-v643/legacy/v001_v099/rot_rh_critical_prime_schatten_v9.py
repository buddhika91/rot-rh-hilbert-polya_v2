#!/usr/bin/env python3
"""
rot_rh_critical_prime_schatten_v9.py

ROT-RH v9 — critical prime-channel Schatten / det_3 decomposition audit.

No Riemann zero ordinates.
No zeta / xi evaluations.
No prime-zeta evaluations.

Critical diagonal prime-loop operator
-------------------------------------
For real E define

    a_p(E) = p^(-1/2 + iE)

on l^2(primes).  Then

    sum_p |a_p|^q = sum_p p^(-q/2),

so A(E) is in S_q for every q>2, in particular S_3, but not S_2.

The third-order regularized determinant is

    det_3(I-A)
      = product_p (1-a_p) exp(a_p + a_p^2/2).

Its logarithmic derivative is exactly

    -d/dE log det_3(I-A)
      = i sum_p log(p) * a_p^3/(1-a_p)
      = i sum_p sum_{m>=3} log(p) p^(-m/2) exp(i m E log p).

Thus det_3 captures every critical prime-power winding m>=3 exactly.

Second winding
--------------
The m=2 logarithmic-derivative sector is

    Q2_X(E) = sum_{p<=X} log(p)/p * exp(2iE log p)
              - int_2^X x^(-1+2iE) dx.

PNT plus the classical zero-free-region error for theta(x)-x implies
Q2_X(E) converges for each fixed real E.  v9 audits this numerically.

Primitive first winding
-----------------------
The m=1 centered sector is

    Q1_X(E) = sum_{p<=X} log(p)/sqrt(p) * exp(iE log p)
              - int_2^X x^(-1/2+iE) dx.

This should NOT be expected to converge pointwise on the critical line.
Under an explicit-formula term x^rho, a zero rho=1/2+i gamma contributes
an X^{i(E+gamma)} oscillation.  Thus pointwise cutoff independence is
the wrong topology for the primitive-prime sector.

Outputs
-------
<prefix>_TRACK.csv
<prefix>_DET3.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm


def parse_floats(s):
    return [float(x.strip()) for x in str(s).split(",") if x.strip()]


def parse_ints(s):
    return [int(float(x.strip())) for x in str(s).split(",") if x.strip()]


def prime_sieve(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in tqdm(range(2, r + 1), desc="Prime sieve", unit="p"):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False
    return np.flatnonzero(sieve).astype(np.int64)


def power_integral(alpha, X, lower=2.0):
    """
    Integral lower^X x^alpha dx, complex alpha.
    """
    z = alpha + 1.0
    if abs(z) < 1e-14:
        return complex(math.log(X / lower))
    return (complex(X) ** z - complex(lower) ** z) / z


def complex_logdet3_partial(E, primes):
    p = primes.astype(np.float64)
    logp = np.log(p)
    a = np.exp((-0.5 + 1j * E) * logp)

    # Principal log on partial products. Since |a|<1, 1-a stays
    # in the right half-plane disk centered at 1 and does not cross 0.
    terms = np.log(1.0 - a) + a + 0.5 * a * a
    return np.sum(terms)


def det3_log_derivative_tail(E, primes):
    p = primes.astype(np.float64)
    logp = np.log(p)
    a = np.exp((-0.5 + 1j * E) * logp)

    # -d_E log det_3(I-A)
    return 1j * np.sum(logp * a**3 / (1.0 - a))


def direct_m_ge_3(E, primes, mmax=24):
    p = primes.astype(np.float64)
    logp = np.log(p)
    out = 0.0j
    for m in range(3, mmax + 1):
        out += 1j * np.sum(
            logp * np.exp((-0.5*m + 1j*m*E) * logp)
        )
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--energies", default="0,5,10,20,40")
    ap.add_argument(
        "--X-values",
        default="1000,3000,10000,30000,100000,300000,1000000,3000000,10000000",
    )
    ap.add_argument("--direct-m-max", type=int, default=24)
    ap.add_argument(
        "--prefix",
        default="rot_rh_critical_prime_schatten_v9",
    )
    args = ap.parse_args()

    energies = parse_floats(args.energies)
    checkpoints = sorted(set(parse_ints(args.X_values)))
    Xmax = max(checkpoints)

    print("=" * 124)
    print("ROT-RH CRITICAL PRIME-CHANNEL SCHATTEN / det_3 AUDIT v9")
    print("=" * 124)
    print(f"energies                     : {energies}")
    print(f"X checkpoints                : {checkpoints}")
    print(f"direct m max                 : {args.direct_m_max}")
    print("critical amplitudes           : a_p=p^(-1/2+iE)")
    print("Riemann zero ordinates used   : NO")
    print("zeta / xi evaluations used    : NO")
    print()

    primes = prime_sieve(Xmax)
    print(f"primes <= Xmax               : {len(primes):,}")

    rows = []
    detrows = []

    previous = {}

    for E in tqdm(energies, desc="E cases", unit="E"):
        logdet_prev = None
        q2_prev = None
        q1_prev = None

        for X in checkpoints:
            idx = np.searchsorted(primes, X, side="right")
            ps = primes[:idx]
            pf = ps.astype(np.float64)
            lp = np.log(pf)

            # Critical Schatten partial sums.
            s2 = float(np.sum(1.0 / pf))
            s3 = float(np.sum(pf ** (-1.5)))

            # det3 partial logarithm.
            ld3 = complex_logdet3_partial(E, ps)
            dld3 = det3_log_derivative_tail(E, ps)
            direct = direct_m_ge_3(E, ps, args.direct_m_max)
            identity_err = abs(dld3 - direct)

            # m=2 and m=1 centered sectors.
            m2sum = np.sum(np.exp((-1.0 + 2j*E) * lp) * lp)
            m2cont = power_integral(-1.0 + 2j*E, X, 2.0)
            q2 = complex(m2sum - m2cont)

            m1sum = np.sum(np.exp((-0.5 + 1j*E) * lp) * lp)
            m1cont = power_integral(-0.5 + 1j*E, X, 2.0)
            q1 = complex(m1sum - m1cont)

            if logdet_prev is None:
                dlogdet = float("nan")
                dq2 = float("nan")
                dq1 = float("nan")
            else:
                dlogdet = abs(ld3 - logdet_prev)
                dq2 = abs(q2 - q2_prev)
                dq1 = abs(q1 - q1_prev)

            logdet_prev = ld3
            q2_prev = q2
            q1_prev = q1

            rows.append(
                [
                    E, X, idx,
                    s2, s3,
                    q2.real, q2.imag, abs(q2), dq2,
                    q1.real, q1.imag, abs(q1), dq1,
                ]
            )

            detrows.append(
                [
                    E, X,
                    ld3.real, ld3.imag, abs(ld3), dlogdet,
                    dld3.real, dld3.imag,
                    direct.real, direct.imag,
                    identity_err,
                ]
            )

    track = np.asarray(rows, dtype=float)
    detarr = np.asarray(detrows, dtype=float)

    track_csv = Path(f"{args.prefix}_TRACK.csv")
    np.savetxt(
        track_csv,
        track,
        delimiter=",",
        header=(
            "E,X,prime_count,S2_partial_sum_1_over_p,S3_partial_sum_p_minus_3over2,"
            "Q2_real,Q2_imag,Q2_abs,Q2_increment,"
            "Q1_real,Q1_imag,Q1_abs,Q1_increment"
        ),
        comments="",
    )

    det_csv = Path(f"{args.prefix}_DET3.csv")
    np.savetxt(
        det_csv,
        detarr,
        delimiter=",",
        header=(
            "E,X,logdet3_real,logdet3_imag,logdet3_abs,logdet3_increment,"
            "minus_dE_logdet3_real,minus_dE_logdet3_imag,"
            "direct_mge3_real,direct_mge3_imag,identity_error"
        ),
        comments="",
    )

    summaries = []
    for E in energies:
        tr = track[np.isclose(track[:, 0], E)]
        de = detarr[np.isclose(detarr[:, 0], E)]

        # Tail increments, last three available increments.
        q2incs = tr[:, 8]
        q1incs = tr[:, 12]
        d3incs = de[:, 5]

        finite_q2 = q2incs[np.isfinite(q2incs)]
        finite_q1 = q1incs[np.isfinite(q1incs)]
        finite_d3 = d3incs[np.isfinite(d3incs)]

        summaries.append(
            {
                "E": E,
                "Q2_last": [float(tr[-1, 5]), float(tr[-1, 6])],
                "Q2_last_abs": float(tr[-1, 7]),
                "Q2_tail_max_increment": float(
                    np.max(finite_q2[-3:]) if len(finite_q2) else float("nan")
                ),
                "Q1_last": [float(tr[-1, 9]), float(tr[-1, 10])],
                "Q1_last_abs": float(tr[-1, 11]),
                "Q1_tail_max_increment": float(
                    np.max(finite_q1[-3:]) if len(finite_q1) else float("nan")
                ),
                "logdet3_last": [float(de[-1, 2]), float(de[-1, 3])],
                "logdet3_tail_max_increment": float(
                    np.max(finite_d3[-3:]) if len(finite_d3) else float("nan")
                ),
                "mge3_identity_error_last": float(de[-1, 10]),
            }
        )

    summary = {
        "version": 9,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "critical_operator": {
            "definition": "A(E)=diag_p p^(-1/2+iE)",
            "Schatten": (
                "A(E) in S_q for every q>2, hence S_3; "
                "A(E) not in S_2 because sum_p 1/p diverges."
            ),
        },
        "det3_theorem": {
            "formula": (
                "det_3(I-A)=prod_p (1-a_p) exp(a_p+a_p^2/2)"
            ),
            "log_derivative": (
                "-d_E log det_3(I-A) = "
                "i sum_p sum_{m>=3} log(p) p^(-m/2+i m E)"
            ),
            "meaning": (
                "all prime powers m>=3 are captured exactly by a canonical "
                "critical Schatten determinant."
            ),
        },
        "m2_theorem": {
            "definition": (
                "Q2_X=sum_{p<=X} log(p)/p exp(2iE log p)"
                "-int_2^X x^(-1+2iE) dx"
            ),
            "status": (
                "converges for fixed real E by quantitative PNT / theta(x)-x "
                "zero-free-region bounds."
            ),
        },
        "m1_obstruction": {
            "definition": (
                "Q1_X=sum_{p<=X} log(p)/sqrt(p) exp(iE log p)"
                "-int_2^X x^(-1/2+iE) dx"
            ),
            "status": (
                "ordinary pointwise cutoff independence is the wrong target. "
                "An explicit-formula contribution from rho gives "
                "X^(rho-1/2+iE)/(rho-1/2+iE); on RH this is oscillatory "
                "rather than convergent."
            ),
            "required_topology": (
                "boundary value / scattering distribution / canonical-system "
                "m-function rather than scalar pointwise X->infinity."
            ),
        },
        "case_summaries": summaries,
        "files": {
            "track": str(track_csv),
            "det3": str(det_csv),
        },
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 124)
    print("SUMMARY")
    print("-" * 124)
    print(f"S2 partial sum at Xmax = sum_p<=X 1/p     : {track[-1,3]:.9f}  (diverges slowly)")
    print(f"S3 partial sum at Xmax = sum_p<=X p^-3/2 : {track[-1,4]:.9f}  (convergent)")
    print()
    for s in summaries:
        print(
            f"E={s['E']:<6g} "
            f"det3_tail_d={s['logdet3_tail_max_increment']:.3e}  "
            f"m>=3_id={s['mge3_identity_error_last']:.3e}  "
            f"Q2_tail_d={s['Q2_tail_max_increment']:.3e}  "
            f"Q1_tail_d={s['Q1_tail_max_increment']:.3e}"
        )

    print()
    print("Decision:")
    print("  1. Critical prime loop is canonically S_3, not S_2.")
    print("  2. det_3 removes exactly m=1,2 and captures every m>=3 winding.")
    print("  3. m=2 admits an unconditional PNT-centered finite part.")
    print("  4. m=1 is the sole primitive-prime boundary carrier; do NOT demand")
    print("     ordinary pointwise cutoff convergence from it.")
    print("  5. Next construction must realize m=1 as a self-adjoint boundary-value")
    print("     object (Weyl/scattering/canonical-system), not as another convergent sum.")
    print(f"\ntrack   : {track_csv}")
    print(f"det3    : {det_csv}")
    print(f"summary : {js}")
    print("=" * 124)


if __name__ == "__main__":
    main()
