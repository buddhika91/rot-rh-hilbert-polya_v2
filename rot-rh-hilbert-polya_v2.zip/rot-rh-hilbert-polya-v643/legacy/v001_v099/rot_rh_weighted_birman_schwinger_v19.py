#!/usr/bin/env python3
"""
rot_rh_weighted_birman_schwinger_v19.py

ROT-RH v19 — weighted Birman-Schwinger / Schatten reconnaissance
for the first-prime endpoint L* = 0.5 log 3.

No Riemann zero ordinates.
No zeta / xi evaluations.

Endpoint even-sector form
-------------------------
On the pole-neutral even subspace, let

    m(r) = Omega(r) - sqrt(2) log(2) cos(r log 2),

    Omega(r) = Re digamma(1/4+i r/2) - log(pi).

Split
    m = m_+ - m_-,
    m_+ = max(m,0),
    m_- = max(-m,0).

Let A and N be the corresponding positive compressed Fourier-multiplier
forms on time support [-L*,L*], restricted to even parity and the single
pole-neutral constraint.

Then endpoint Weil positivity is

    A - N >= 0.

Formally, where A is positive,

    B = A^(-1/2) N A^(-1/2),

and
    A-N >=0  <=>  ||B|| <= 1.

A sufficient condition is the Hilbert-Schmidt estimate

    ||B|| <= ||B||_{S2} = sqrt(Tr B^2) < 1.

Finite positive-window monotonicity
-----------------------------------
For numerical work we use

    A_R = P [m_+(D) 1_{|r|<=R}] P <= A.

Hence, on any fixed finite-dimensional Galerkin subspace where A_R>0,

    lambda_max(N,A) <= lambda_max(N,A_R).

Thus truncating the POSITIVE frequency tail is conservative for the
generalized eigenvalue on that Galerkin space.

Important limitation
--------------------
This script is NOT a proof of the infinite-dimensional inequality.
A_R is compact in the full space and its inverse is unbounded; finite
Galerkin convergence by itself does not certify the complement.

The purpose of v19 is to test whether a rigorous full-space
Birman-Schwinger/Schatten certificate is numerically plausible and to
measure the required tail margin.

Observed target signature
-------------------------
Previous high-resolution reconnaissance suggests:
  dominant generalized eigenvalue  ~ 0.9955
  second generalized eigenvalue    ~ 0.03
  finite-section S2 norm           ~ 0.996
so the S2 margin to 1 is of order 4e-3.

Outputs
-------
<prefix>_SCAN.csv
<prefix>_SPECTRA.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm
from scipy.special import digamma
from scipy.linalg import null_space, eigh


LSTAR = 0.5 * math.log(3.0)
TAU = math.log(2.0)
W2 = TAU / math.sqrt(2.0)


def parse_ints(text):
    return [int(float(x.strip())) for x in str(text).split(",") if x.strip()]


def omega(r):
    return np.real(digamma(0.25 + 0.5j*r)) - math.log(math.pi)


def multiplier(r):
    return omega(r) - 2.0*W2*np.cos(TAU*r)


def even_sine_indices(nmax):
    # phi_n(x)=sin(n*pi*(x+L)/(2L)).
    # Odd n are even about x=0.
    n = np.arange(1, nmax + 1, dtype=int)
    return n[n % 2 == 1]


def expint_real(a, D):
    z = a * D / 2.0
    return D * np.exp(1j*a*D/2.0) * np.sinc(z / math.pi)


def ft_sine_real(r, ns):
    r = np.asarray(r, dtype=float)[:, None]
    ns = np.asarray(ns, dtype=float)[None, :]
    D = 2.0 * LSTAR
    k = ns * math.pi / D

    Ip = expint_real(r + k, D)
    Im = expint_real(r - k, D)
    I = (Ip - Im) / (2j)

    return np.exp(-1j*r*LSTAR) * I / math.sqrt(LSTAR)


def ft_sine_complex(z, ns):
    ns = np.asarray(ns, dtype=int)
    D = 2.0 * LSTAR
    k = ns.astype(float) * math.pi / D
    parity = (-1.0) ** ns

    return (
        np.exp(-1j*z*LSTAR)
        / math.sqrt(LSTAR)
        * k
        * (1.0 - parity*np.exp(1j*z*D))
        / (k*k - z*z)
    )


def pole_nullspace(ns):
    c = ft_sine_complex(0.5j, ns)[None, :]
    return null_space(c), c


def gauss_symmetric(R, npts):
    z, w = np.polynomial.legendre.leggauss(npts)
    return R*z, R*w


def weighted_matrices(ns, R, npts):
    r, w = gauss_symmetric(R, npts)
    F = ft_sine_real(r, ns)
    mm = multiplier(r)

    plus = np.maximum(mm, 0.0)
    minus = np.maximum(-mm, 0.0)

    A = F.conj().T @ ((w*plus)[:, None] * F) / (2.0*math.pi)
    N = F.conj().T @ ((w*minus)[:, None] * F) / (2.0*math.pi)

    A = 0.5*(A + A.conj().T)
    N = 0.5*(N + N.conj().T)
    return A, N


def whitened_spectrum(A, N, tol=1e-12):
    av, U = np.linalg.eigh(A)
    amin = float(av[0])

    if amin <= tol:
        return {
            "A_min": amin,
            "status": "A_not_numerically_coercive",
            "generalized": None,
            "B_eigs": None,
        }

    invsqrt = (U / np.sqrt(av)) @ U.conj().T
    B = invsqrt @ N @ invsqrt
    B = 0.5*(B + B.conj().T)

    be = np.linalg.eigvalsh(B)
    ge = eigh(N, A, eigvals_only=True)

    return {
        "A_min": amin,
        "status": "ok",
        "generalized": ge,
        "B_eigs": be,
    }


def one_case(nmax, r_factor, min_R, points_per_unit, min_points, max_p):
    ns = even_sine_indices(nmax)
    Z, C = pole_nullspace(ns)

    kmax = float(ns[-1]) * math.pi / (2.0*LSTAR)
    R = max(min_R, r_factor*kmax)
    npts = max(min_points, int(points_per_unit*R))

    A, N = weighted_matrices(ns, R, npts)

    Ap = Z.conj().T @ A @ Z
    Np = Z.conj().T @ N @ Z
    Ap = 0.5*(Ap + Ap.conj().T)
    Np = 0.5*(Np + Np.conj().T)

    spec = whitened_spectrum(Ap, Np)

    out = {
        "nmax": nmax,
        "basis_dimension": len(ns),
        "admissible_dimension": Z.shape[1],
        "kmax": kmax,
        "R": R,
        "quadrature_points": npts,
        "constraint_rank": int(np.linalg.matrix_rank(C)),
        "A_min": spec["A_min"],
        "status": spec["status"],
    }

    if spec["status"] != "ok":
        return out, []

    be = np.asarray(spec["B_eigs"], dtype=float)
    ge = np.asarray(spec["generalized"], dtype=float)

    pos = np.clip(be, 0.0, None)
    moments = {}
    bounds = {}
    for p in range(1, max_p + 1):
        trp = float(np.sum(pos**p))
        moments[str(p)] = trp
        bounds[str(p)] = trp**(1.0/p)

    out.update({
        "lambda_max_generalized": float(ge[-1]),
        "lambda_second_generalized":
            float(ge[-2]) if len(ge) >= 2 else float("nan"),
        "S1_bound": bounds.get("1", float("nan")),
        "S2_bound": bounds.get("2", float("nan")),
        "S3_bound": bounds.get("3", float("nan")),
        "S4_bound": bounds.get("4", float("nan")),
        "margin_operator": 1.0 - float(ge[-1]),
        "margin_S2": 1.0 - bounds.get("2", float("nan")),
        "moments": moments,
        "schatten_bounds": bounds,
        "negative_eigenvalues_B": int(np.sum(be < -1e-10)),
    })

    spectrum = []
    for i, ev in enumerate(be):
        spectrum.append([
            nmax,
            i,
            ev,
        ])

    return out, spectrum


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--basis-nmax-values",
        default="20,30,40,50,60,80,100",
    )
    ap.add_argument("--r-factor", type=float, default=1.45)
    ap.add_argument("--min-R", type=float, default=80.0)
    ap.add_argument("--points-per-unit", type=float, default=7.0)
    ap.add_argument("--min-points", type=int, default=1800)
    ap.add_argument("--max-p", type=int, default=6)
    ap.add_argument(
        "--prefix",
        default="rot_rh_weighted_birman_schwinger_v19",
    )
    A = ap.parse_args()

    nvals = parse_ints(A.basis_nmax_values)

    print("="*126)
    print("ROT-RH v19 — WEIGHTED BIRMAN-SCHWINGER / SCHATTEN RECONNAISSANCE")
    print("="*126)
    print(f"L*                           : {LSTAR:.12f}")
    print(f"basis nmax scan              : {nvals}")
    print(f"positive-window R factor     : {A.r_factor}")
    print(f"minimum R                    : {A.min_R}")
    print(f"points per frequency unit    : {A.points_per_unit}")
    print("Riemann zero ordinates used  : NO")
    print("zeta / xi evaluations used   : NO")
    print()

    cases = []
    spectra = []

    for nmax in tqdm(nvals, desc="Galerkin scan", unit="case"):
        case, specrows = one_case(
            nmax,
            A.r_factor,
            A.min_R,
            A.points_per_unit,
            A.min_points,
            A.max_p,
        )
        cases.append(case)
        spectra.extend(specrows)

    rows = []
    for c in cases:
        rows.append([
            c["nmax"],
            c["basis_dimension"],
            c["admissible_dimension"],
            c["kmax"],
            c["R"],
            c["quadrature_points"],
            c["A_min"],
            c.get("lambda_max_generalized", np.nan),
            c.get("lambda_second_generalized", np.nan),
            c.get("S1_bound", np.nan),
            c.get("S2_bound", np.nan),
            c.get("S3_bound", np.nan),
            c.get("S4_bound", np.nan),
            c.get("margin_operator", np.nan),
            c.get("margin_S2", np.nan),
        ])

    scan_csv = Path(f"{A.prefix}_SCAN.csv")
    np.savetxt(
        scan_csv,
        np.asarray(rows, dtype=float),
        delimiter=",",
        header=(
            "nmax,basis_dim,admissible_dim,kmax,R,quadrature_points,"
            "A_min,lambda_max_generalized,lambda_second_generalized,"
            "S1_bound,S2_bound,S3_bound,S4_bound,"
            "margin_operator,margin_S2"
        ),
        comments="",
    )

    spec_csv = Path(f"{A.prefix}_SPECTRA.csv")
    if spectra:
        np.savetxt(
            spec_csv,
            np.asarray(spectra, dtype=float),
            delimiter=",",
            header="nmax,index,B_eigenvalue",
            comments="",
        )
    else:
        spec_csv.write_text("nmax,index,B_eigenvalue\n")

    summary = {
        "version": 19,
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "endpoint": {
            "Lstar": LSTAR,
            "sector": "even pole-neutral",
            "multiplier":
                "m(r)=Omega(r)-sqrt(2)log(2)cos(r log 2)",
        },
        "relative_problem": {
            "A": "compression of m_+(D)",
            "N": "compression of m_-(D)",
            "B": "A^(-1/2) N A^(-1/2)",
            "target": "||B|| <= 1",
            "sufficient": "Tr(B^2) < 1",
        },
        "finite_positive_window": {
            "A_R": "compression of m_+(D) 1_{|r|<=R}",
            "monotonicity": (
                "A_R <= A, so on a fixed finite Galerkin subspace "
                "lambda_max(N,A) <= lambda_max(N,A_R)."
            ),
        },
        "cases": cases,
        "interpretation": (
            "Finite-section S2<1 is a strong reconnaissance signal, not a "
            "full-space certificate. The remaining theorem work is to control "
            "the Galerkin/complement error for the weighted relative operator."
        ),
        "next_certificate_target": [
            "Prove an explicit coercive lower bound for A on the full even pole-neutral space.",
            "Bound the high-mode tail of the compact negative multiplier N in a basis compatible with the support interval.",
            "Use a block/KKT or Schur enclosure to upper-bound the full-space Tr(B^2) by the certified finite block plus the tail.",
            "Perform all final quadratures/eigenvalue inequalities in ball or interval arithmetic.",
        ],
        "files": {
            "scan": str(scan_csv),
            "spectra": str(spec_csv),
        },
    }

    js = Path(f"{A.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-"*126)
    print("SCAN")
    print("-"*126)
    for c in cases:
        if c["status"] != "ok":
            print(
                f"nmax={c['nmax']:<4d} R={c['R']:<8.2f} "
                f"Amin={c['A_min']:+.3e}  STATUS={c['status']}"
            )
            continue
        print(
            f"nmax={c['nmax']:<4d} R={c['R']:<8.2f} "
            f"lambda1={c['lambda_max_generalized']:.9f}  "
            f"lambda2={c['lambda_second_generalized']:.3e}  "
            f"S2={c['S2_bound']:.9f}  "
            f"marginS2={c['margin_S2']:+.3e}"
        )

    print()
    print("Interpretation:")
    print("  * S2<1 on a finite section is stronger than checking only lambda_max<1.")
    print("  * A_R uses only a finite positive-frequency window, so it is conservative")
    print("    for the generalized eigenvalue on that same Galerkin subspace.")
    print("  * The remaining obstacle is infinite-dimensional certification, not")
    print("    identification of the dangerous mode.")
    print(f"\nscan    : {scan_csv}")
    print(f"spectra : {spec_csv}")
    print(f"summary : {js}")
    print("="*126)


if __name__ == "__main__":
    main()
