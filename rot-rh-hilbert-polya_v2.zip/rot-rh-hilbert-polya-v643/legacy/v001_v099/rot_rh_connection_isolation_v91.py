#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v91 — Frozen Connection-Isolation / Randomized-Transport Audit
=====================================================================

PURPOSE
-------
Do NOT rebuild or modify the v90 candidate.

v90 showed:
  * full Fisher-metric + connection operator: catastrophic spectral failure;
  * connection_only: by far the best v90 control.

v91 asks whether the connection-only improvement is:
  (a) real across arithmetic cutoffs,
  (b) stable enough to define an operator flow,
  (c) better than the raw arithmetic diagonal,
  (d) specific to the actual ROT information-connection alignment rather than
      a generic nearest-neighbor Hermitian perturbation.

INPUT
-----
The exact v90 frozen NPZ and manifest.

PRE-XI
------
1. Verify SHA256.
2. For raw_diagonal and connection_only at every cutoff:
   * Hermiticity / positivity / simple spectrum
   * adjacent cutoff spectral drift
   * connection Frobenius norm relative to raw diagonal
   * eigenvalue displacement induced by the connection
3. No Xi/zeta/zero access.

POST-FREEZE
-----------
4. Extract Xi critical-line sign-change roots only after hash verification.
5. Compare raw_diagonal vs connection_only at every cutoff.
6. Require connection improvement on every blind cutoff, not just the endpoint.
7. At the final cutoff, extract the actual nearest-neighbor connection edges
       H_conn - H_raw = i A.
   Generate fixed-seed permutation controls by shuffling the edge magnitudes
   among level positions while preserving:
       * Hermiticity,
       * nearest-neighbor structure,
       * the multiset of connection strengths,
       * the raw diagonal spectrum.
   These controls are generated only for falsification after freeze; they do not
   alter or select the real operator.
8. Compare real connection improvement against the permutation distribution.
9. Test determinant identity over 0..T and zero sequence over all available
   positive eigenvalues.

SCIENTIFIC BOUNDARY
-------------------
A PASS means the frozen ROT projective connection contains non-generic spectral
information beyond the raw arithmetic diagonal.  It is NOT an RH proof and does
not establish an infinite operator limit.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import mpmath as mp
import numpy as np

VERSION = "v91"
BUILD = "2026-08-17-frozen-connection-isolation-randomized-transport-v91"
EPS = 1e-14


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.complexfloating):
        return {"real": float(np.real(x)), "imag": float(np.imag(x))}
    if isinstance(x, mp.mpf):
        return mp.nstr(x, 50)
    if isinstance(x, mp.mpc):
        return {"real": mp.nstr(mp.re(x), 50), "imag": mp.nstr(mp.im(x), 50)}
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def hermitian(H: np.ndarray) -> np.ndarray:
    H = np.asarray(H, np.complex128)
    return 0.5 * (H + H.conj().T)


def spectral_rel_drift(a: np.ndarray, b: np.ndarray) -> float:
    ea = np.linalg.eigvalsh(hermitian(a)).real
    eb = np.linalg.eigvalsh(hermitian(b)).real
    return float(np.linalg.norm(eb-ea) / max(np.linalg.norm(ea), EPS))


def bisect_xi_zero(v86, a: float, b: float, iters: int = 80) -> float:
    aa, bb = mp.mpf(a), mp.mpf(b)
    fa = mp.re(v86.Xi_t(aa))
    fb = mp.re(v86.Xi_t(bb))
    if fa * fb > 0:
        raise ValueError("interval does not bracket Xi sign change")
    for _ in range(iters):
        m = (aa + bb) / 2
        fm = mp.re(v86.Xi_t(m))
        if fa * fm <= 0:
            bb, fb = m, fm
        else:
            aa, fa = m, fm
    return float((aa + bb) / 2)


def xi_sign_change_zeros(v86, tmax: float, step: float) -> List[float]:
    out = []
    x0 = 0.0
    f0 = mp.re(v86.Xi_t(mp.mpf(0)))
    x = step
    while x <= tmax + 1e-12:
        f = mp.re(v86.Xi_t(mp.mpf(x)))
        if f == 0 or f0 * f < 0:
            out.append(bisect_xi_zero(v86, x0, x))
        x0, f0 = x, f
        x += step
    return out


def zero_metrics(E: np.ndarray, truth: Sequence[float], count: int) -> Dict[str, float]:
    p = np.sort(np.asarray(E, float))
    p = p[p > 1e-10]
    q = np.asarray(truth, float)
    n = min(int(count), len(p), len(q))
    if n == 0:
        return {
            "count": 0,
            "rmse": float("nan"),
            "relative_rmse": float("nan"),
            "mae": float("nan"),
            "max_abs": float("nan"),
        }
    e = p[:n] - q[:n]
    return {
        "count": int(n),
        "rmse": float(np.sqrt(np.mean(e*e))),
        "relative_rmse": float(np.sqrt(np.mean((e/q[:n])**2))),
        "mae": float(np.mean(np.abs(e))),
        "max_abs": float(np.max(np.abs(e))),
    }


def determinant_from_energies(E: np.ndarray, t: float) -> complex:
    e = np.sort(np.asarray(E, float))
    e = e[e > 1e-10]
    return complex(np.prod(1.0 - (complex(t)*complex(t))/(e*e)))


def symmetric_error(a: complex, b: complex) -> float:
    return abs(a-b) / max(1.0, abs(a), abs(b))


def rms(vals: Sequence[float]) -> float:
    x = np.asarray(vals, float)
    x = x[np.isfinite(x)]
    return float(np.sqrt(np.mean(x*x))) if len(x) else float("nan")


def identity_rms(v86, E: np.ndarray, xi0, tmax: float, step: float) -> float:
    errs = []
    t = 0.0
    while t <= tmax + 1e-12:
        xt = v86.Xi_t(mp.mpf(t)) / xi0
        target = complex(float(mp.re(xt)), float(mp.im(xt)))
        D = determinant_from_energies(E, t)
        errs.append(symmetric_error(D, target))
        t += step
    return rms(errs)


def extract_edge_couplings(Hraw: np.ndarray, Hconn: np.ndarray) -> np.ndarray:
    """
    Hconn = D + iA with real antisymmetric nearest-neighbor A.
    For upper edge H[k,k+1] = i * a_k.
    """
    delta = hermitian(Hconn) - hermitian(Hraw)
    d = delta.shape[0]
    edges = np.zeros(d-1, float)
    for k in range(d-1):
        edges[k] = float(np.imag(delta[k, k+1]))
    return edges


def rebuild_from_edges(Hraw: np.ndarray, edges: np.ndarray) -> np.ndarray:
    H = hermitian(Hraw).copy()
    for k, a in enumerate(np.asarray(edges, float)):
        H[k, k+1] += 1j*a
        H[k+1, k] -= 1j*a
    return hermitian(H)


def improvement_fraction(raw: float, candidate: float) -> float:
    if not math.isfinite(raw) or raw <= EPS:
        return float("nan")
    return (raw-candidate)/raw


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--frozen-npz",
        default="rot_rh_fisher_metric_covariant_hp_v90_FROZEN_PRE_XI.npz",
    )
    ap.add_argument(
        "--manifest",
        default="rot_rh_fisher_metric_covariant_hp_v90_FROZEN_MANIFEST.json",
    )
    ap.add_argument(
        "--v86-module",
        default="rot_rh_rot_native_recursive_hp_xi_identity_v86",
    )
    ap.add_argument(
        "--cutoffs",
        default="20000,30000,45000,67500,100000,150000,200000",
    )
    ap.add_argument("--development-last", type=int, default=4)
    ap.add_argument("--xi-dps", type=int, default=100)
    ap.add_argument("--zero-scan-max", type=float, default=120.0)
    ap.add_argument("--zero-scan-step", type=float, default=0.10)
    ap.add_argument("--zero-match-count", type=int, default=32)
    ap.add_argument("--identity-max", type=float, default=100.0)
    ap.add_argument("--identity-step", type=float, default=0.50)
    ap.add_argument("--permutation-controls", type=int, default=128)
    ap.add_argument("--seed", type=int, default=20260817)

    # Diagnostic gates; none are used to modify the operator.
    ap.add_argument("--max-connection-blind-drift", type=float, default=0.02)
    ap.add_argument("--min-blind-improvement-fraction", type=float, default=0.0)
    ap.add_argument("--min-permutation-z", type=float, default=2.0)
    ap.add_argument("--min-permutation-percentile", type=float, default=0.95)
    ap.add_argument("--prefix", default="rot_rh_connection_isolation_v91")
    args = ap.parse_args()

    t0 = time.time()
    cutoffs = parse_ints(args.cutoffs)
    if cutoffs != sorted(cutoffs):
        raise ValueError("cutoffs must be increasing")
    if not (0 <= args.development_last < len(cutoffs)-1):
        raise ValueError("development-last must leave blind cutoffs")

    frozen = Path(args.frozen_npz).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    if not frozen.exists():
        raise FileNotFoundError(frozen)
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected = str(manifest.get("sha256", ""))
    actual = sha256_file(frozen)
    hash_ok = bool(expected) and expected.lower() == actual.lower()
    if not hash_ok:
        raise RuntimeError("v90 frozen NPZ hash mismatch")

    print("="*152)
    print("ROT-RH v91 — FROZEN CONNECTION-ISOLATION / RANDOMIZED-TRANSPORT AUDIT")
    print("="*152)
    print("frozen NPZ                    :", frozen)
    print("hash verified                 :", hash_ok)
    print("cutoffs                       :", cutoffs)
    print("development indices           :", f"0..{args.development_last}")
    print("blind indices                 :", f"{args.development_last+1}..{len(cutoffs)-1}")
    print("operator modification         : NONE")
    print("Xi/zeros before pre-Xi audit  : NONE")
    print("="*152)

    data = np.load(frozen, allow_pickle=False)

    # ------------------------------------------------------------------
    # PRE-Xi
    # ------------------------------------------------------------------
    pre_rows = []
    drift_rows = []
    raw_by_X = {}
    conn_by_X = {}

    for X in cutoffs:
        kr = f"H_raw_diagonal_X{X}"
        kc = f"H_connection_only_X{X}"
        if kr not in data or kc not in data:
            raise KeyError(f"Missing {kr} or {kc} in v90 frozen NPZ")
        Hr = hermitian(np.asarray(data[kr], np.complex128))
        Hc = hermitian(np.asarray(data[kc], np.complex128))
        raw_by_X[X] = Hr
        conn_by_X[X] = Hc

        er = np.linalg.eigvalsh(Hr).real
        ec = np.linalg.eigvalsh(Hc).real
        delta = Hc-Hr
        pre_rows.append({
            "cutoff": X,
            "raw_min_energy": float(np.min(er)),
            "conn_min_energy": float(np.min(ec)),
            "raw_min_spacing": float(np.min(np.diff(np.sort(er)))),
            "conn_min_spacing": float(np.min(np.diff(np.sort(ec)))),
            "connection_fro_over_raw_fro": float(
                np.linalg.norm(delta, "fro") / max(np.linalg.norm(Hr, "fro"), EPS)
            ),
            "connection_induced_spectral_shift_rel_l2": float(
                np.linalg.norm(ec-er) / max(np.linalg.norm(er), EPS)
            ),
            "connection_edge_rms": float(np.sqrt(np.mean(extract_edge_couplings(Hr,Hc)**2))),
            "connection_edge_max_abs": float(np.max(np.abs(extract_edge_couplings(Hr,Hc)))),
        })

    for i, (Xa, Xb) in enumerate(zip(cutoffs[:-1], cutoffs[1:]), start=1):
        split = "dev" if i <= args.development_last else "blind"
        rd = spectral_rel_drift(raw_by_X[Xa], raw_by_X[Xb])
        cd = spectral_rel_drift(conn_by_X[Xa], conn_by_X[Xb])
        drift_rows.append({
            "cutoff_a": Xa,
            "cutoff_b": Xb,
            "split": split,
            "raw_spectrum_relative_drift": rd,
            "connection_spectrum_relative_drift": cd,
            "connection_minus_raw_drift": cd-rd,
        })

    blind_drift = [r for r in drift_rows if r["split"] == "blind"]
    latest_conn_drift = float(blind_drift[-1]["connection_spectrum_relative_drift"])
    latest_raw_drift = float(blind_drift[-1]["raw_spectrum_relative_drift"])

    print("[pre-Xi] latest raw drift             :", f"{latest_raw_drift:.9e}")
    print("[pre-Xi] latest connection drift      :", f"{latest_conn_drift:.9e}")
    print("[pre-Xi] final connection/raw norm    :",
          f"{pre_rows[-1]['connection_fro_over_raw_fro']:.9e}")

    # Xi begins only now.
    v86 = importlib.import_module(args.v86_module)
    mp.mp.dps = args.xi_dps
    xi0 = v86.Xi_t(0)

    print("[post-freeze] scanning Xi crossings", flush=True)
    xi_zeros = xi_sign_change_zeros(v86, args.zero_scan_max, args.zero_scan_step)
    print("[post-freeze] Xi crossings found      :", len(xi_zeros))

    # ------------------------------------------------------------------
    # POST-FREEZE cutoff-by-cutoff real connection effect.
    # ------------------------------------------------------------------
    score_rows = []
    blind_improvements = []

    for i, X in enumerate(cutoffs):
        split = "dev" if i <= args.development_last else "blind"
        Er = np.linalg.eigvalsh(raw_by_X[X]).real
        Ec = np.linalg.eigvalsh(conn_by_X[X]).real
        mr = zero_metrics(Er, xi_zeros, args.zero_match_count)
        mc = zero_metrics(Ec, xi_zeros, args.zero_match_count)
        ir = identity_rms(v86, Er, xi0, args.identity_max, args.identity_step)
        ic = identity_rms(v86, Ec, xi0, args.identity_max, args.identity_step)

        zimp = improvement_fraction(mr["relative_rmse"], mc["relative_rmse"])
        iimp = improvement_fraction(ir, ic)
        if split == "blind":
            blind_improvements.append((zimp, iimp))

        score_rows.append({
            "cutoff": X,
            "split": split,
            "raw_zero_relative_rmse": mr["relative_rmse"],
            "connection_zero_relative_rmse": mc["relative_rmse"],
            "zero_improvement_fraction": zimp,
            "raw_identity_symmetric_rms": ir,
            "connection_identity_symmetric_rms": ic,
            "identity_improvement_fraction": iimp,
            "zero_count": mc["count"],
        })

        print(
            f"[score] X={X:<7} {split:<5} "
            f"zero raw={mr['relative_rmse']:.6e} conn={mc['relative_rmse']:.6e} "
            f"gain={zimp:+.3%}  "
            f"D raw={ir:.6e} conn={ic:.6e} gain={iimp:+.3%}"
        )

    # ------------------------------------------------------------------
    # POST-FREEZE randomized edge-position controls at final cutoff.
    # ------------------------------------------------------------------
    Xf = cutoffs[-1]
    Hr = raw_by_X[Xf]
    Hc = conn_by_X[Xf]
    real_edges = extract_edge_couplings(Hr, Hc)

    Er = np.linalg.eigvalsh(Hr).real
    Ec = np.linalg.eigvalsh(Hc).real
    raw_z = zero_metrics(Er, xi_zeros, args.zero_match_count)["relative_rmse"]
    real_z = zero_metrics(Ec, xi_zeros, args.zero_match_count)["relative_rmse"]
    raw_i = identity_rms(v86, Er, xi0, args.identity_max, args.identity_step)
    real_i = identity_rms(v86, Ec, xi0, args.identity_max, args.identity_step)
    real_gain_z = improvement_fraction(raw_z, real_z)
    real_gain_i = improvement_fraction(raw_i, real_i)

    rng = np.random.default_rng(args.seed)
    perm_rows = []
    perm_gain_z = []
    perm_gain_i = []

    for rep in range(args.permutation_controls):
        ep = real_edges[rng.permutation(len(real_edges))]
        Hp = rebuild_from_edges(Hr, ep)
        E = np.linalg.eigvalsh(Hp).real
        z = zero_metrics(E, xi_zeros, args.zero_match_count)["relative_rmse"]
        ii = identity_rms(v86, E, xi0, args.identity_max, args.identity_step)
        gz = improvement_fraction(raw_z, z)
        gi = improvement_fraction(raw_i, ii)
        perm_gain_z.append(gz)
        perm_gain_i.append(gi)
        perm_rows.append({
            "rep": rep,
            "zero_relative_rmse": z,
            "identity_symmetric_rms": ii,
            "zero_improvement_fraction_vs_raw": gz,
            "identity_improvement_fraction_vs_raw": gi,
        })

    pz = np.asarray(perm_gain_z, float)
    pi = np.asarray(perm_gain_i, float)
    mean_z = float(np.mean(pz))
    sd_z = float(np.std(pz, ddof=1))
    mean_i = float(np.mean(pi))
    sd_i = float(np.std(pi, ddof=1))
    zscore_z = (real_gain_z-mean_z)/sd_z if sd_z > EPS else float("inf")
    zscore_i = (real_gain_i-mean_i)/sd_i if sd_i > EPS else float("inf")
    percentile_z = float(np.mean(pz <= real_gain_z))
    percentile_i = float(np.mean(pi <= real_gain_i))

    # ------------------------------------------------------------------
    # Gates / verdict
    # ------------------------------------------------------------------
    blind_zero_all = all(
        math.isfinite(zg) and zg > args.min_blind_improvement_fraction
        for zg, _ in blind_improvements
    )
    blind_identity_all = all(
        math.isfinite(ig) and ig > args.min_blind_improvement_fraction
        for _, ig in blind_improvements
    )

    gates = {
        "connection_cutoff_stable": latest_conn_drift <= args.max_connection_blind_drift,
        "connection_improves_zero_on_every_blind_cutoff": blind_zero_all,
        "connection_improves_identity_on_every_blind_cutoff": blind_identity_all,
        "real_connection_beats_permuted_zero_z": zscore_z >= args.min_permutation_z,
        "real_connection_beats_permuted_identity_z": zscore_i >= args.min_permutation_z,
        "real_connection_zero_percentile": percentile_z >= args.min_permutation_percentile,
        "real_connection_identity_percentile": percentile_i >= args.min_permutation_percentile,
    }

    if all(gates.values()):
        verdict = (
            "PASS_V91_ROT_CONNECTION_IS_NON_GENERIC_AND_BLIND_STABLE__"
            "NEXT_BUILD_CONNECTION_NATIVE_INFINITE_JACOBI_OPERATOR"
        )
    elif (
        gates["connection_improves_zero_on_every_blind_cutoff"]
        and gates["connection_improves_identity_on_every_blind_cutoff"]
    ):
        verdict = (
            "PARTIAL_V91_CONNECTION_IMPROVES_BLINDLY__"
            "BUT_STABILITY_OR_RANDOMIZED_SPECIFICITY_FAILS"
        )
    else:
        verdict = (
            "NO_GO_V91_PROJECTIVE_CONNECTION_DOES_NOT_ADD_ROBUST_ROT_SPECTRAL_INFORMATION"
        )

    # Outputs
    pre_csv = Path(str(prefix) + "_PRE_XI.csv")
    drift_csv = Path(str(prefix) + "_DRIFT.csv")
    scores_csv = Path(str(prefix) + "_CUTOFF_SCORES.csv")
    perms_csv = Path(str(prefix) + "_PERMUTATION_CONTROLS.csv")
    verdict_json = Path(str(prefix) + "_VERDICT.json")

    write_csv(pre_csv, pre_rows)
    write_csv(drift_csv, drift_rows)
    write_csv(scores_csv, score_rows)
    write_csv(perms_csv, perm_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "operator_modified": False,
        "frozen_hash_verified": hash_ok,
        "Xi_used_before_hash_and_preXi_audit": False,
        "zero_ordinates_supplied": False,
        "latest_raw_blind_spectral_drift": latest_raw_drift,
        "latest_connection_blind_spectral_drift": latest_conn_drift,
        "final_real_connection": {
            "raw_zero_relative_rmse": raw_z,
            "connection_zero_relative_rmse": real_z,
            "zero_improvement_fraction": real_gain_z,
            "raw_identity_symmetric_rms": raw_i,
            "connection_identity_symmetric_rms": real_i,
            "identity_improvement_fraction": real_gain_i,
        },
        "permutation_test": {
            "repetitions": args.permutation_controls,
            "zero_gain_mean": mean_z,
            "zero_gain_sd": sd_z,
            "real_zero_gain_zscore": zscore_z,
            "real_zero_gain_percentile": percentile_z,
            "identity_gain_mean": mean_i,
            "identity_gain_sd": sd_i,
            "real_identity_gain_zscore": zscore_i,
            "real_identity_gain_percentile": percentile_i,
        },
        "gates": gates,
        "outputs": {
            "pre_xi": str(pre_csv),
            "drift": str(drift_csv),
            "cutoff_scores": str(scores_csv),
            "permutation_controls": str(perms_csv),
            "verdict": str(verdict_json),
        },
        "runtime_seconds": time.time()-t0,
    }
    verdict_json.write_text(
        json.dumps(json_safe(packet), indent=2),
        encoding="utf-8",
    )

    print("\n"+"="*152)
    print("FINAL CONSERVATIVE VERDICT")
    print("="*152)
    print("verdict                         :", verdict)
    print("operator modified               : FALSE")
    print("frozen hash verified            :", hash_ok)
    print("latest raw blind drift          :", f"{latest_raw_drift:.9e}")
    print("latest connection blind drift   :", f"{latest_conn_drift:.9e}")
    print("final raw zero rel RMSE         :", f"{raw_z:.9e}")
    print("final connection zero rel RMSE  :", f"{real_z:.9e}")
    print("real zero improvement           :", f"{real_gain_z:+.6%}")
    print("final raw identity RMS          :", f"{raw_i:.9e}")
    print("final connection identity RMS   :", f"{real_i:.9e}")
    print("real identity improvement       :", f"{real_gain_i:+.6%}")
    print("permutation zero gain mean/sd   :", f"{mean_z:+.6%}", f"{sd_z:.6%}")
    print("real zero gain z / percentile   :", f"{zscore_z:+.6f}", f"{percentile_z:.6f}")
    print("permutation identity mean/sd    :", f"{mean_i:+.6%}", f"{sd_i:.6%}")
    print("real identity z / percentile    :", f"{zscore_i:+.6f}", f"{percentile_i:.6f}")
    print("gates                           :", gates)
    print("Xi used to modify operator      : FALSE")
    print("RH proof                        : FALSE")
    print("verdict file                    :", verdict_json)
    print("runtime seconds                 :", f"{time.time()-t0:.2f}")
    print("="*152)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
