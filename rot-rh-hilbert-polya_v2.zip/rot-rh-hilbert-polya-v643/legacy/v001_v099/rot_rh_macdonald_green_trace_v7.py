#!/usr/bin/env python3
"""
rot_rh_macdonald_green_trace_v7.py

Exact Green-function audit for the prime-completed Macdonald proposal.

Purpose
-------
Test the proposed bridge

    Fredholm determinant -> Macdonald Green trace -> prime phase cos(E log n).

No Riemann zero ordinates, zeta, or xi evaluations are used.

Base operator
-------------
    H_Gamma = -d^2/dt^2 + 16*pi^2*exp(4t),   t >= 0,

with the natural Neumann boundary condition at t=0.

For spectral parameter lambda=E^2, put

    x  = 2*pi*exp(2t),
    x0 = 2*pi,
    nu = i E/2.

The decaying right solution is K_nu(x).  Using the real imaginary-order
solution Itilde_nu(x)=Re I_{iE/2}(x), the Neumann left solution is

    phi(x) = K'_nu(x0) Itilde_nu(x)
             - Itilde'_nu(x0) K_nu(x).

The DLMF Wronskian W_x{K,Itilde}=1/x gives the exact diagonal Green kernel

    G(E;t,t)
      = 1/2 Itilde_nu(x) K_nu(x)
        - Itilde'_nu(x0)/(2 K'_nu(x0)) K_nu(x)^2.

For fixed E and t->infinity,

    G(E;t,t) = 1/(8*pi*exp(2t)) + O_E(exp(-4t)),

so at the original prime location t=log n,

    G(E;log n,log n)
      = 1/(8*pi*n^2) + O_E(n^-4).

Thus a first determinant variation weighted by Lambda(n)/n has a tail
Lambda(n)/(8*pi*n^3), rather than an unsuppressed Mellin phase
Lambda(n)/n*cos(E log n) (or the critical Lambda(n)/sqrt(n) phase).

The script numerically verifies this asymptotic and also audits the
"half-log" placement t=(1/2)log n.  Half-log makes the reflected WKB
round-trip phase 2Et approximately E log n in the classically allowed
region, but its fixed-E far tail is still suppressed as 1/n and therefore
does not solve the exact all-prime trace problem.

Outputs
-------
<prefix>_GREEN.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import mpmath as mp
import numpy as np
from tqdm import tqdm


def parse_floats(text):
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def prime_power_atoms(nmax):
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False
    r = int(math.isqrt(nmax))
    for p in range(2, r + 1):
        if sieve[p]:
            sieve[p*p:nmax+1:p] = False

    primes = np.flatnonzero(sieve)
    atoms = []
    for p in primes:
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            atoms.append((q, lp))
            if q > nmax // p:
                break
            q *= p
    atoms.sort()
    return atoms


def itilde(nu, x):
    return mp.re(mp.besseli(nu, x))


def itilde_prime(nu, x):
    return mp.re((mp.besseli(nu - 1, x) + mp.besseli(nu + 1, x)) / 2)


def kfun(nu, x):
    return mp.re(mp.besselk(nu, x))


def kprime(nu, x):
    return mp.re(-(mp.besselk(nu - 1, x) + mp.besselk(nu + 1, x)) / 2)


def green_diag(E, t):
    nu = 0.5j * mp.mpf(E)
    x0 = 2 * mp.pi
    x = 2 * mp.pi * mp.e ** (2 * mp.mpf(t))

    K = kfun(nu, x)
    I = itilde(nu, x)

    K0p = kprime(nu, x0)
    I0p = itilde_prime(nu, x0)

    if abs(K0p) < mp.mpf("1e-40"):
        raise ZeroDivisionError(
            "E is too close to a Neumann eigenvalue of the base Macdonald operator."
        )

    direct = mp.mpf("0.5") * I * K
    reflected = -(I0p / (2 * K0p)) * K * K
    return direct + reflected, direct, reflected, x


def phase_fit(logn, y, frequency):
    """
    y ~= a cos(frequency*log n) + b sin(...) + c.
    Returns R^2 and fitted amplitude.
    """
    logn = np.asarray(logn, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(y) < 4 or np.std(y) == 0:
        return None, None

    X = np.column_stack(
        [
            np.cos(frequency * logn),
            np.sin(frequency * logn),
            np.ones_like(logn),
        ]
    )
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    fit = X @ coef
    ss_res = float(np.sum((y - fit) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = None if ss_tot == 0 else 1.0 - ss_res / ss_tot
    amp = float(math.hypot(coef[0], coef[1]))
    return r2, amp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--energies", default="20,40,80")
    ap.add_argument("--n-max", type=int, default=80)
    ap.add_argument("--mp-dps", type=int, default=50)
    ap.add_argument(
        "--embeddings",
        default="1.0,0.5",
        help="Prime location t=a log n. 1=original, 0.5=half-log.",
    )
    ap.add_argument(
        "--allowed-fraction",
        type=float,
        default=0.8,
        help="For phase fits require V(t) <= allowed_fraction*E^2.",
    )
    ap.add_argument(
        "--prefix",
        default="rot_rh_macdonald_green_trace_v7",
    )
    args = ap.parse_args()

    mp.mp.dps = args.mp_dps
    energies = parse_floats(args.energies)
    embeddings = parse_floats(args.embeddings)
    atoms = prime_power_atoms(args.n_max)

    print("=" * 118)
    print("ROT-RH EXACT MACDONALD GREEN-TRACE BRIDGE AUDIT v7")
    print("=" * 118)
    print(f"energies                     : {energies}")
    print(f"prime-power n max            : {args.n_max}")
    print(f"embeddings t=a log n         : {embeddings}")
    print(f"mp dps                       : {args.mp_dps}")
    print("Riemann zero ordinates used  : NO")
    print("zeta / xi evaluations used   : NO")
    print()

    rows = []
    phase_summaries = []

    jobs = [(E, a) for E in energies for a in embeddings]
    for E, a in tqdm(jobs, desc="E/embedding", unit="case"):
        allowed_logn = []
        allowed_ref = []

        for n, lam in atoms:
            t = a * math.log(n)
            try:
                G, Gdir, Gref, x = green_diag(E, t)
            except ZeroDivisionError:
                continue

            Gf = float(mp.re(G))
            Gdirf = float(mp.re(Gdir))
            Greff = float(mp.re(Gref))
            xf = float(x)

            # Fixed-E asymptotic: G ~ 1/(4x) = 1/(8*pi*n^(2a)).
            asym = 1.0 / (8.0 * math.pi * (n ** (2.0 * a)))
            ratio = Gf / asym if asym != 0 else float("nan")

            # Arithmetic first-variation atom coefficient.
            trace_atom = (lam / n) * Gf
            asym_trace = lam / (8.0 * math.pi * (n ** (1.0 + 2.0*a)))

            # Classical allowed-region diagnostic:
            # V(t)=16*pi^2*exp(4t)=16*pi^2*n^(4a).
            V = 16.0 * math.pi**2 * (n ** (4.0 * a))
            allowed = V <= args.allowed_fraction * E * E

            rows.append(
                [
                    E,
                    a,
                    n,
                    lam,
                    t,
                    xf,
                    Gf,
                    Gdirf,
                    Greff,
                    asym,
                    ratio,
                    trace_atom,
                    asym_trace,
                    int(allowed),
                    math.cos(E * math.log(n)),
                    math.cos(2.0 * E * a * math.log(n)),
                ]
            )

            if allowed:
                allowed_logn.append(math.log(n))
                allowed_ref.append(Greff)

        # The reflected local Green term naturally has round-trip phase 2 E t.
        # Compare against both desired E log n and predicted 2 a E log n.
        if len(allowed_ref) >= 4:
            r2_desired, amp_desired = phase_fit(
                allowed_logn, allowed_ref, E
            )
            r2_round, amp_round = phase_fit(
                allowed_logn, allowed_ref, 2.0 * a * E
            )
        else:
            r2_desired = amp_desired = None
            r2_round = amp_round = None

        phase_summaries.append(
            {
                "E": E,
                "embedding_a": a,
                "allowed_atoms": len(allowed_ref),
                "desired_phase_frequency": E,
                "roundtrip_phase_frequency": 2.0 * a * E,
                "desired_cos_Elogn_R2": r2_desired,
                "desired_amplitude": amp_desired,
                "roundtrip_R2": r2_round,
                "roundtrip_amplitude": amp_round,
            }
        )

    arr = np.asarray(rows, dtype=float)
    csv = Path(f"{args.prefix}_GREEN.csv")
    np.savetxt(
        csv,
        arr,
        delimiter=",",
        header=(
            "E,embedding_a,n,Lambda_n,t,x,"
            "G_diag,G_direct,G_reflected,"
            "fixedE_asymptotic,G_over_asymptotic,"
            "Lambda_over_n_times_G,asymptotic_trace_atom,"
            "classically_allowed,cos_E_logn,cos_roundtrip"
        ),
        comments="",
    )

    # Large-n ratio diagnostics using the last 20% of available atoms.
    tail_summary = []
    for E in energies:
        for a in embeddings:
            sub = arr[
                np.isclose(arr[:, 0], E)
                & np.isclose(arr[:, 1], a)
            ]
            sub = sub[np.argsort(sub[:, 2])]
            if len(sub):
                start = max(0, int(0.8 * len(sub)))
                tail = sub[start:]
                ratios = tail[:, 10]
                tail_summary.append(
                    {
                        "E": E,
                        "embedding_a": a,
                        "tail_n_min": int(tail[0, 2]),
                        "tail_n_max": int(tail[-1, 2]),
                        "mean_G_over_asymptotic": float(np.mean(ratios)),
                        "max_abs_ratio_minus_1": float(
                            np.max(np.abs(ratios - 1.0))
                        ),
                    }
                )

    summary = {
        "version": 7,
        "construction": "exact Neumann half-line Macdonald Green diagonal",
        "zero_ordinates_used": False,
        "zeta_xi_evaluations_used": False,
        "exact_formula": (
            "G=0.5*Itilde_nu(x)*K_nu(x)"
            "-Itilde'_nu(2pi)/(2*K'_nu(2pi))*K_nu(x)^2"
        ),
        "fixed_E_original_embedding_asymptotic": (
            "G(E;log n,log n)=1/(8*pi*n^2)+O_E(n^-4)"
        ),
        "fixed_E_half_log_asymptotic": (
            "G(E;0.5 log n,0.5 log n)=1/(8*pi*n)+O_E(n^-2)"
        ),
        "phase_summaries": phase_summaries,
        "tail_summaries": tail_summary,
        "verdict": {
            "original_embedding": (
                "FAILS exact prime-phase bridge: the fixed-E prime tail is "
                "suppressed by n^-2 in G, so Lambda(n)/n atoms become n^-3-scale; "
                "the reflected local phase is a round-trip phase 2Et, giving "
                "2E log n at t=log n rather than E log n."
            ),
            "half_log_embedding": (
                "PARTIAL PHASE ALIGNMENT ONLY: t=0.5 log n makes the reflected "
                "round-trip phase 2Et equal E log n in the classically allowed "
                "high-energy regime, but the fixed-E far tail still decays as 1/n "
                "in G and therefore cannot reproduce the exact unsuppressed all-prime "
                "Mellin trace."
            ),
            "design_requirement": (
                "A successful Archimedean completion must preserve a free/dilation "
                "logarithmic propagation channel at arbitrarily large prime locations; "
                "compactness should come from a separate boundary/canonical-system/"
                "feedback mechanism rather than a local potential that grows along "
                "the same logarithmic coordinate."
            ),
        },
        "files": {"green_csv": str(csv)},
    }

    js = Path(f"{args.prefix}_SUMMARY.json")
    js.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 118)
    print("VERDICT")
    print("-" * 118)
    print("Original embedding t=log n:")
    print("  G(E;log n,log n) ~ 1/(8*pi*n^2).")
    print("  With Lambda(n)/n atoms, the determinant first-variation tail is ~ Lambda(n)/(8*pi*n^3).")
    print("  This cannot equal an all-prime Mellin phase Lambda(n)/n*cos(E log n),")
    print("  and is even farther from the critical Lambda(n)/sqrt(n)*cos(E log n) trace.")
    print()
    print("Half-log embedding t=(1/2)log n:")
    print("  The reflected WKB round-trip phase 2Et becomes E log n — a real structural clue.")
    print("  But the fixed-E far tail remains suppressed: G ~ 1/(8*pi*n).")
    print("  So local exponential confinement still fails the exact all-prime trace.")
    print()
    print("Conclusion:")
    print("  REJECT the Macdonald potential as the final Archimedean completion.")
    print("  KEEP v6 as a valid operator-theory construction.")
    print("  NEXT architecture must separate:")
    print("    (i) a free/dilation log channel carrying e^{iE log n}, from")
    print("    (ii) a compactifying/self-adjoint feedback or canonical-system channel.")
    print(f"\nCSV     : {csv}")
    print(f"summary : {js}")
    print("=" * 118)


if __name__ == "__main__":
    main()
