# ROT → Hilbert–Pólya → RH Full Closure Pipeline (v97)

## Goal

Construct an operator from ROT/arithmetic inputs only and prove

\[
H_{\mathrm{HP}}=H_{\mathrm{HP}}^*,
\qquad
\frac{\Xi(t)}{\Xi(0)}=\det\!\left(I-t^2H_{\mathrm{HP}}^{-2}\right).
\]

The determinant identity forces the zeros of \(\Xi(t)\) to be real because the
spectrum of a self-adjoint operator is real. This is the Hilbert–Pólya route to
RH.

---

## Stage 0 — ROT principles that must become mathematical input

Use the following ROT structural principles, but do not pretend that every one
has already been derived microscopically:

1. **Recursive observation resolution** — a monotone scale variable controls how
   much arithmetic information is accessible.
2. **Compact phase / phase connection** — the spectral sector is phase-valued,
   so defects are topological phase defects rather than arbitrary fitted roots.
3. **Self-dual heat response** — recursive coarse graining is represented by a
   positive heat metric and ultimately must derive the square heat spectrum and
   modular inversion law.
4. **Positive observer geometry** — the spectral realization must remain a
   positive-measure Jacobi/canonical system, not an arbitrary non-Hermitian fit.
5. **Defect-free interior / boundary localization** — the fundamental ROT action
   must ultimately forbid phase defects away from the critical observer boundary.

The current project has operational realizations of these ideas, but the final
microscopic ROT action-to-operator derivation is still a theorem obligation.

---

## Stage 1 — Zero-free arithmetic phase

For finite observation scale \(L>0\), define

\[
F_L(E)
=
\frac{\theta(E)}{\pi}+1
-
\frac1\pi
\sum_{n\ge2}
\frac{\Lambda(n)}{\log n\sqrt n}
 e^{-n/L}\sin(E\log n).
\]

Only Gamma/Archimedean data and the von Mangoldt function enter.

No \(\Xi\), zeta values, or zero ordinates are allowed.

Because the regulator is exponential, the arithmetic correction converges
absolutely and uniformly for every fixed finite \(L\).

---

## Stage 2 — Infinite ordered arithmetic support

Define recursively

\[
F_L(E_k(L))=k-\frac12,
\qquad
E_1(L)<E_2(L)<\cdots.
\]

The construction is the *first later crossing* at each level, not a closest-zero
fit.

For fixed finite \(L\),

\[
E_k(L)\sim \frac{2\pi k}{\log k}.
\]

---

## Stage 3 — ROT heat measure and Jacobi operator

Use the recursive heat metric

\[
w_k^{(\tau,L)}
\propto
\exp\!\left[-\tau\left(\frac{E_k(L)}{E_1(L)}\right)^2\right],
\qquad \tau>0.
\]

Define

\[
\mu_{\tau,L}
=
\sum_{k\ge1}w_k^{(\tau,L)}\delta_{E_k(L)}.
\]

The Stieltjes/Favard recurrence gives

\[
E P_n(E)
=
 b_{n+1}P_{n+1}(E)
+a_nP_n(E)
+b_nP_{n-1}(E),
\qquad b_n>0,
\]

and therefore the half-line Jacobi operator

\[
(J_{\tau,L}\psi)_n
=
 b_n\psi_{n-1}+a_n\psi_n+b_{n+1}\psi_{n+1}.
\]

---

## Stage 4 — Fixed-\(L\) infinite self-adjoint theorem

The heat measure has finite exponential moments. Its Hamburger moment problem is
therefore determinate. Consequently the minimal Jacobi operator is essentially
self-adjoint and has a unique closure

\[
H_{\mathrm{ROT}}(L,\tau)=\overline{J_{\tau,L}}.
\]

This stage is already a genuine infinite-dimensional zero-free operator theorem
for every fixed finite \(L\) and \(\tau>0\).

---

## Stage 5 — Pass to the compact inverse-square operator

Define

\[
K_{L,\tau}=H_{\mathrm{ROT}}(L,\tau)^{-2}.
\]

Since

\[
E_k(L)\sim\frac{2\pi k}{\log k},
\]

we have

\[
\sum_k E_k(L)^{-2}<\infty.
\]

Hence \(K_{L,\tau}\) is trace class and

\[
D_L(t)
=
\det(I-t^2K_{L,\tau})
=
\prod_{k\ge1}\left(1-\frac{t^2}{E_k(L)^2}\right)
\]

is an ordinary Fredholm determinant.

### Important structural warning

The heat weights affect the cyclic/Jacobi representation but **do not change the
spectral support**. Therefore ROT is not yet spectrally indispensable merely by
choosing these weights. The missing recursive ROT law must act on the support or
operator geometry itself.

---

## Stage 6 — Recursive observation flow

Study the family

\[
L\mapsto H_{\mathrm{ROT}}(L,\tau),
\qquad
L\mapsto K_{L,\tau}.
\]

Before any \(\Xi\) access, audit only gauge-invariant quantities:

- ordered support drift;
- Weyl/Stieltjes \(m\)-function drift;
- inverse trace moments \(\operatorname{Tr}K_L^n\);
- determinant drift on compact \(t\)-windows;
- depth convergence;
- arithmetic controls and scrambled-prime controls.

The desired theorem is stronger than numerical convergence:

\[
K_{L,\tau}\longrightarrow K_\infty
\quad\text{in trace norm}
\]

or an equivalent operator-limit theorem sufficient to control the Fredholm
determinant.

It must also be independent of the regulator/window implementation.

---

## Stage 7 — Define the candidate Hilbert–Pólya operator

If the limit is positive, compact and injective, define

\[
H_{\mathrm{HP}}=K_\infty^{-1/2}.
\]

Then \(H_{\mathrm{HP}}\) is self-adjoint and unbounded, with discrete real
spectral levels tending to infinity.

---

## Stage 8 — Hard freeze

Before evaluating \(\Xi\):

- freeze all source choices;
- freeze \(L\)-ladder and depth ladder;
- freeze ROT heat parameter or derive it upstream;
- freeze recursive law;
- freeze regulator and boundary conditions;
- serialize all operator data;
- hash the entire construction.

No post-freeze value may feed back into the operator.

---

## Stage 9 — Exact theta/Mellin target

After freeze, the exact completed-zeta/theta representation supplies an external
target \(\Xi(t)/\Xi(0)\).

Numerically test, but do not confuse with proof:

\[
D_N(t)
\stackrel{?}{\approx}
\frac{\Xi(t)}{\Xi(0)},
\]

\[
\operatorname{Tr}K_N^m
\stackrel{?}{\approx}
S_m,
\]

and

\[
\frac{D_N'(t)}{D_N(t)}
\stackrel{?}{\approx}
\frac{\Xi'(t)}{\Xi(t)}.
\]

---

## Stage 10 — The exact determinant theorem

The true finish line is to prove, as an identity of entire functions,

\[
\boxed{
\frac{\Xi(t)}{\Xi(0)}
=
\det(I-t^2K_\infty)
}
\]

with no zero information used in constructing \(K_\infty\).

Possible rigorous routes include:

1. identify all inverse trace moments and prove the resulting entire functions
   have the same canonical product/growth;
2. derive a Fredholm kernel from ROT and prove it equals the theta/Mellin kernel;
3. derive the corresponding canonical system/de Branges function and prove the
   global Hermite–Biehler inequality.

Finite-order total positivity is not enough; the required global theorem must be
proved.

---

## Stage 11 — RH

If

\[
K_\infty>0,
\qquad
K_\infty\ \text{compact and injective},
\]

and

\[
\frac{\Xi(t)}{\Xi(0)}
=
\det(I-t^2K_\infty),
\]

then every zero of \(\Xi(t)\) is of the form

\[
t=\pm E_n,
\qquad E_n\in\mathbb R,
\]

because these are the spectral zeros of a self-adjoint operator. Therefore all
nontrivial zeta zeros lie on

\[
\operatorname{Re}s=\frac12.
\]

That is RH.

---

# Current theorem ledger

| Stage | Status |
|---|---|
| Zero-free Gamma/Mangoldt phase at fixed finite \(L\) | established |
| Infinite ordered support for fixed finite \(L\) | established |
| Infinite heat-weighted Jacobi operator | established |
| Essential self-adjointness for fixed \(L,\tau\) | established |
| \(H_L^{-2}\) trace class / Fredholm determinant exists | follows from support asymptotic |
| ROT is spectrally indispensable | **open** |
| First-principles ROT autonomous recursive operator law | **open** |
| \(L\to\infty\) regulator-independent operator limit | **open** |
| Exact ROT operator ↔ theta kernel bridge | **open** |
| Exact \(\Xi\) Fredholm determinant identity | **open** |
| RH | **open** |

The v97 executable harness is designed to attack and quantify the open middle
stages without allowing post-freeze \(\Xi\) information to leak backward into
the construction.
