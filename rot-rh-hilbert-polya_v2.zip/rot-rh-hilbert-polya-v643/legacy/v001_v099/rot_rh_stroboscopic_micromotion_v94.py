#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROT-RH v94 — Stroboscopic / Period-2 Jacobi Micromotion Audit
=============================================================

MOTIVATION
----------
v93 found:
  * scalar oracle beta lag-1 correlation ~ -0.71;
  * frequent beta sign reversals;
  * causal persistence beta_s <- beta_{s-1} fails;
  * mode-resolved persistence fails even more strongly.

An earlier zero-free ROT-RH flow audit independently warned that the arithmetic
spectral trajectory contains alternating shell micromotion and recommended
removing that micromotion before differentiating the slow flow.

v94 tests that hypothesis directly.

NO Xi, zeta, or known Riemann zeros are evaluated anywhere in this script.

PERIOD-2 HYPOTHESIS
-------------------
Let beta_s be the arithmetic-only oracle coefficient multiplying the v92
covariant correction direction at transition s.

If there is period-2 micromotion, then causally one expects either

    beta_hat_s = - beta_{s-1}              (reflection law)

or

    beta_hat_s = beta_{s-2}                (same-parity/stroboscopic law).

The same tests are performed for the six v93 Jacobi blocks.

FIXED CANDIDATE LAWS
--------------------
  scalar_previous
  scalar_reflect
  scalar_same_parity
  block_previous
  block_reflect
  block_same_parity
  fixed_beta_v92
  covariant_beta0

No continuous parameter is fitted.

DEVELOPMENT / BLIND
-------------------
The candidate family is evaluated on development transitions and untouched
blind transitions.  A mechanism is considered supported only if one of the
fixed period-2 laws:
  * improves persistence on development,
  * improves persistence on every blind step,
  * preserves positive Jacobi operators,
  * beats the corresponding results on scrambled-prime controls.

This is an operator-dynamics identification test only.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import time
from pathlib import Path
from typing import Dict, List, Sequence

import numpy as np

VERSION = "v94"
BUILD = "2026-08-17-stroboscopic-period2-jacobi-micromotion-v94"
EPS = 1e-14


def parse_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in str(s).split(",") if x.strip()]


def json_safe(x):
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [json_safe(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    return x


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                fields.append(k)
                seen.add(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def corr_lag(x: Sequence[float], lag: int) -> float:
    a = np.asarray(x, float)
    if len(a) <= lag + 1:
        return float("nan")
    u, v = a[:-lag], a[lag:]
    if np.std(u) <= EPS or np.std(v) <= EPS:
        return float("nan")
    return float(np.corrcoef(u, v)[0, 1])


def sign_flip_fraction(x: Sequence[float]) -> float:
    a = np.asarray(x, float)
    if len(a) < 2:
        return float("nan")
    good = np.abs(a[:-1]) > 1e-12
    good &= np.abs(a[1:]) > 1e-12
    if not np.any(good):
        return float("nan")
    return float(np.mean((a[:-1][good] * a[1:][good]) < 0.0))


def negate_blocks(bb: Dict[str, float]) -> Dict[str, float]:
    return {k: -float(v) for k, v in bb.items()}


def summarize(rows, method, split):
    z = [r for r in rows if r["method"] == method and r["split"] == split]
    if not z:
        return {
            "count": 0,
            "mean_gain": float("nan"),
            "mean_error": float("nan"),
            "all_gain_positive": False,
            "positive_all": False,
        }
    return {
        "count": len(z),
        "mean_gain": float(np.mean([r["gain"] for r in z])),
        "mean_error": float(np.mean([r["error"] for r in z])),
        "all_gain_positive": bool(all(r["gain"] > 0 for r in z)),
        "positive_all": bool(all(r["positive"] for r in z)),
    }


def evaluate_trajectory(v92, v93, states, probs, cutoffs, dev_last, d, fixed_beta):
    # Same development-only normalization / trust region as v93.
    acts = v92.fisher_actions(probs[:dev_last+1], cutoffs[:dev_last+1])
    pos = [x for x in acts if x > 1e-14]
    fisher_med = float(np.median(pos)) if pos else 1.0
    lo, hi = v92.state_bounds(states[:dev_last+1], d)
    blocks = v93.blocks_for_depth(d)

    geoms = {}
    scalar = {}
    block = {}
    oracle_rows = []

    for i in range(3, len(cutoffs)):
        g = v93.transition_geometry(
            v92, states, probs, cutoffs, i, fisher_med
        )
        geoms[i] = g
        bs, bb = v93.oracle_betas(g, blocks)
        scalar[i] = bs
        block[i] = bb
        oracle_rows.append({
            "target_index": i,
            "cutoff": cutoffs[i],
            "split": "dev" if i <= dev_last else "blind",
            "scalar_beta": bs,
            **{f"beta_{k}": v for k, v in bb.items()},
        })

    rows = []
    # Period-2 methods need i-2 oracle, so start at 5 for fair comparison.
    for i in range(5, len(cutoffs)):
        g = geoms[i]
        split = "dev" if i <= dev_last else "blind"
        actual = states[i]
        prev = states[i-1]

        methods = {
            "covariant_beta0": v93.velocity_from_beta(g, scalar_beta=0.0),
            "fixed_beta_v92": v93.velocity_from_beta(
                g, scalar_beta=fixed_beta
            ),
            "scalar_previous": v93.velocity_from_beta(
                g, scalar_beta=scalar[i-1]
            ),
            "scalar_reflect": v93.velocity_from_beta(
                g, scalar_beta=-scalar[i-1]
            ),
            "scalar_same_parity": v93.velocity_from_beta(
                g, scalar_beta=scalar[i-2]
            ),
            "block_previous": v93.velocity_from_beta(
                g, block_beta=block[i-1], blocks=blocks
            ),
            "block_reflect": v93.velocity_from_beta(
                g, block_beta=negate_blocks(block[i-1]), blocks=blocks
            ),
            "block_same_parity": v93.velocity_from_beta(
                g, block_beta=block[i-2], blocks=blocks
            ),
        }

        for method, vhat in methods.items():
            pred, clipfrac = v93.predict_state_from_velocity(
                v92, states, i, g, vhat, lo, hi
            )
            met = v93.score_state(v92, pred, actual, prev, d)
            rows.append({
                "target_index": i,
                "cutoff": cutoffs[i],
                "split": split,
                "method": method,
                "clip_fraction": clipfrac,
                **met,
            })

    seq = [scalar[i] for i in sorted(scalar)]
    structure = {
        "scalar_lag1_corr": corr_lag(seq, 1),
        "scalar_lag2_corr": corr_lag(seq, 2),
        "scalar_sign_flip_fraction": sign_flip_fraction(seq),
    }
    for name, _ in blocks:
        bseq = [block[i][name] for i in sorted(block)]
        structure[f"{name}_lag1_corr"] = corr_lag(bseq, 1)
        structure[f"{name}_lag2_corr"] = corr_lag(bseq, 2)
        structure[f"{name}_sign_flip_fraction"] = sign_flip_fraction(bseq)

    return {
        "rows": rows,
        "oracle_rows": oracle_rows,
        "structure": structure,
        "scalar": scalar,
        "block": block,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--base-module",
        default="rot_rh_pure_mangoldt_prime_phase_dirac_jacobi_operator_audit",
    )
    ap.add_argument(
        "--v92-module",
        default="rot_rh_operator_recursive_inertia_jacobi_v92_1",
    )
    ap.add_argument(
        "--v93-module",
        default="rot_rh_mode_resolved_counterflow_v93",
    )
    ap.add_argument(
        "--cutoffs",
        default="8000,12000,18000,27000,40000,60000,90000,135000,200000,300000,450000,675000",
    )
    ap.add_argument("--development-last", type=int, default=7)
    ap.add_argument("--depth", type=int, default=32)
    ap.add_argument("--grid-points", type=int, default=128)
    ap.add_argument("--fixed-beta", type=float, default=-0.5)
    ap.add_argument("--scrambled-controls", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260817)
    ap.add_argument("--prefix", default="rot_rh_stroboscopic_micromotion_v94")
    args = ap.parse_args()

    t0 = time.time()
    cutoffs = parse_ints(args.cutoffs)
    if cutoffs != sorted(cutoffs):
        raise ValueError("cutoffs must be increasing")
    if not (6 <= args.development_last < len(cutoffs)-1):
        raise ValueError("development-last must leave blind cutoffs")

    prefix = Path(args.prefix).expanduser().resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)

    base = importlib.import_module(args.base_module)
    v92 = importlib.import_module(args.v92_module)
    v93 = importlib.import_module(args.v93_module)

    print("=" * 154)
    print("ROT-RH v94 — STROBOSCOPIC / PERIOD-2 JACOBI MICROMOTION AUDIT")
    print("=" * 154)
    print("cutoffs                       :", cutoffs)
    print("development                  :", cutoffs[:args.development_last+1])
    print("blind                         :", cutoffs[args.development_last+1:])
    print("depth                         :", args.depth)
    print("fixed beta v92                :", args.fixed_beta)
    print("Xi/zeta/known zeros           : NONE")
    print("=" * 154)

    print("[1] Real arithmetic trajectory", flush=True)
    states, probs, roots, free = v92.build_trajectory(
        base, cutoffs, args.depth, args.grid_points, "signal", args.seed
    )
    real = evaluate_trajectory(
        v92, v93, states, probs, cutoffs,
        args.development_last, args.depth, args.fixed_beta
    )

    methods = [
        "covariant_beta0",
        "fixed_beta_v92",
        "scalar_previous",
        "scalar_reflect",
        "scalar_same_parity",
        "block_previous",
        "block_reflect",
        "block_same_parity",
    ]
    summaries = {}
    print("[2] Fixed-law summary")
    for m in methods:
        summaries[(m, "dev")] = summarize(real["rows"], m, "dev")
        summaries[(m, "blind")] = summarize(real["rows"], m, "blind")
        d = summaries[(m, "dev")]
        b = summaries[(m, "blind")]
        print(
            f"  {m:<22} dev={d['mean_gain']:+.3%} "
            f"blind={b['mean_gain']:+.3%} blind_all={b['all_gain_positive']}"
        )

    s = real["structure"]
    print("[3] Micromotion structure")
    print("  scalar lag1 corr             :", f"{s['scalar_lag1_corr']:+.6f}")
    print("  scalar lag2 corr             :", f"{s['scalar_lag2_corr']:+.6f}")
    print("  scalar sign-flip fraction    :", f"{s['scalar_sign_flip_fraction']:.6f}")

    # Period-2 candidate family only.
    period2 = [
        "scalar_reflect",
        "scalar_same_parity",
        "block_reflect",
        "block_same_parity",
    ]

    # Development-only selection among FIXED, parameter-free period-2 laws.
    eligible = []
    for m in period2:
        d = summaries[(m, "dev")]
        if d["positive_all"] and math.isfinite(d["mean_error"]):
            eligible.append((d["mean_error"], -d["mean_gain"], m))
    if not eligible:
        raise RuntimeError("No positive period-2 candidate.")
    eligible.sort()
    selected = eligible[0][2]
    selected_dev = summaries[(selected, "dev")]
    selected_blind = summaries[(selected, "blind")]
    print("[select] development-only period2  :", selected)

    print("[4] Scrambled-prime controls", flush=True)
    control_rows = []
    control_gains = []
    # Fair control: each scrambled trajectory selects its own best member of
    # the same fixed period-2 family using its own development transitions.
    for rep in range(args.scrambled_controls):
        cs, cp, cr, cf = v92.build_trajectory(
            base, cutoffs, args.depth, args.grid_points,
            "permuted_weights", args.seed + 100000*(rep+1)
        )
        rr = evaluate_trajectory(
            v92, v93, cs, cp, cutoffs,
            args.development_last, args.depth, args.fixed_beta
        )
        csum = {}
        celig = []
        for m in period2:
            csum[(m, "dev")] = summarize(rr["rows"], m, "dev")
            csum[(m, "blind")] = summarize(rr["rows"], m, "blind")
            d = csum[(m, "dev")]
            if d["positive_all"] and math.isfinite(d["mean_error"]):
                celig.append((d["mean_error"], -d["mean_gain"], m))
        celig.sort()
        cm = celig[0][2]
        cb = csum[(cm, "blind")]
        control_gains.append(cb["mean_gain"])
        control_rows.append({
            "rep": rep,
            "selected_period2_method": cm,
            "development_gain": csum[(cm, "dev")]["mean_gain"],
            "blind_gain": cb["mean_gain"],
            "blind_all_gain_positive": cb["all_gain_positive"],
        })
        print(
            f"  control {rep+1:02d}/{args.scrambled_controls}: "
            f"selected={cm:<20} blind_gain={cb['mean_gain']:+.3%}"
        )

    cg = np.asarray(control_gains, float)
    cmean = float(np.mean(cg))
    csd = float(np.std(cg, ddof=1)) if len(cg) > 1 else 0.0
    real_gain = selected_blind["mean_gain"]
    z = (real_gain-cmean)/csd if csd > EPS else float("inf")
    pct = float(np.mean(cg <= real_gain))

    gates = {
        "lag1_is_antipersistent": s["scalar_lag1_corr"] < -0.4,
        "lag2_is_more_persistent_than_lag1":
            s["scalar_lag2_corr"] > s["scalar_lag1_corr"],
        "period2_development_gain_positive":
            selected_dev["mean_gain"] > 0.0,
        "period2_blind_gain_positive":
            selected_blind["mean_gain"] > 0.0,
        "period2_blind_every_step":
            selected_blind["all_gain_positive"],
        "period2_operator_positive":
            selected_blind["positive_all"],
        "period2_beats_scrambled_z2": z > 2.0,
        "period2_beats_scrambled_percentile95": pct >= 0.95,
    }

    if all(gates.values()):
        verdict = (
            "PASS_V94_PERIOD2_MICROMOTION_SUPPORTED__"
            "NEXT_DERIVE_STROBOSCOPIC_AUTONOMOUS_ROT_JACOBI_FLOW"
        )
    elif (
        gates["lag1_is_antipersistent"]
        and gates["period2_blind_gain_positive"]
    ):
        verdict = (
            "PARTIAL_V94_ANTIPERSISTENT_MICROMOTION_PRESENT__"
            "BUT_PERIOD2_CAUSAL_LAW_NOT_FULLY_VALIDATED"
        )
    else:
        verdict = (
            "NO_GO_V94_SIMPLE_PERIOD2_MICROMOTION_DOES_NOT_EXPLAIN_V93_ANTIPERSISTENCE"
        )

    oracle_csv = Path(str(prefix) + "_ORACLE.csv")
    predictions_csv = Path(str(prefix) + "_PREDICTIONS.csv")
    controls_csv = Path(str(prefix) + "_CONTROLS.csv")
    summary_json = Path(str(prefix) + "_SUMMARY.json")

    write_csv(oracle_csv, real["oracle_rows"])
    write_csv(predictions_csv, real["rows"])
    write_csv(controls_csv, control_rows)

    packet = {
        "version": VERSION,
        "build": BUILD,
        "verdict": verdict,
        "RH_proof": False,
        "Xi_evaluated": False,
        "zeta_evaluated": False,
        "known_zero_ordinates_used": False,
        "micromotion_structure": real["structure"],
        "selected_period2_method": selected,
        "selected_development": selected_dev,
        "selected_blind": selected_blind,
        "all_method_summaries": {
            f"{m}_{split}": summaries[(m, split)]
            for m in methods for split in ["dev", "blind"]
        },
        "controls": {
            "repetitions": args.scrambled_controls,
            "mean_blind_gain": cmean,
            "sd_blind_gain": csd,
            "real_blind_gain": real_gain,
            "z": z,
            "percentile": pct,
        },
        "gates": gates,
        "outputs": {
            "oracle": str(oracle_csv),
            "predictions": str(predictions_csv),
            "controls": str(controls_csv),
            "summary": str(summary_json),
        },
        "runtime_seconds": time.time()-t0,
    }
    summary_json.write_text(
        json.dumps(json_safe(packet), indent=2),
        encoding="utf-8",
    )

    print("\n" + "="*154)
    print("FINAL ZERO-FREE VERDICT")
    print("="*154)
    print("verdict                         :", verdict)
    print("scalar lag1 / lag2 corr         :",
          f"{s['scalar_lag1_corr']:+.6f}", f"{s['scalar_lag2_corr']:+.6f}")
    print("scalar sign-flip fraction       :", f"{s['scalar_sign_flip_fraction']:.6f}")
    print("selected period2 method         :", selected)
    print("selected development gain       :", f"{selected_dev['mean_gain']:+.6%}")
    print("selected blind gain             :", f"{selected_blind['mean_gain']:+.6%}")
    print("selected blind every step       :", selected_blind["all_gain_positive"])
    print("control gain mean/sd            :", f"{cmean:+.6%}", f"{csd:.6%}")
    print("real-vs-control z/percentile    :", f"{z:+.6f}", f"{pct:.6f}")
    print("gates                           :", gates)
    print("Xi evaluated                    : FALSE")
    print("known zeros used                : FALSE")
    print("RH proof                        : FALSE")
    print("summary                         :", summary_json)
    print("runtime seconds                 :", f"{time.time()-t0:.2f}")
    print("="*154)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
