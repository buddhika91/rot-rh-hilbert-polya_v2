#!/usr/bin/env python3
"""
rot_rh_pnt_centered_infinite_form_v2.py

Clean-sheet ROT–RH cutoff-independence audit, v2.

Main correction from v1
-----------------------
v1 evaluated

    A_inf(E) = E ∫ C(t) sin(E t) dt

with a uniform-grid trapezoid rule.  C(t) is a staircase-minus-linear function
with jumps at log prime powers, so that quadrature develops a frequency-dependent
aliasing error.

v2 uses the exact event-by-event Stieltjes identity.  If

    C(T) = gamma_E + Σ_{n<=exp(T)} Lambda(n)/n - T,

then

    E ∫_0^T C(t) sin(E t) dt
      = gamma_E
        + Σ_{n<=exp(T)} Lambda(n)/n cos(E log n)
        - sin(E T)/E
        - C(T) cos(E T)                         (E != 0).

No t-grid is used for this scalar reference.

The same exact endpoint identity is used for the unregulated Gaussian probe
quadratic forms:

    -∫_0^T C(t) g'(t) dt
      = gamma_E g(0)
        + Σ w_n g(log n)
        - ∫_0^T g(t)dt
        - C(T) g(T).

The t-grid is retained only for:
  * regulated continuum probe integrals,
  * numerical form-convergence coefficient diagnostics a_L and b_L.

No Riemann zero ordinates are used.

Centered arithmetic measure
---------------------------
    dnu(t) = gamma_E delta_0
             + Σ Lambda(n)/n delta_{log n}
             - dt.

For a regulator h_L(t),

    v_L[u] = ∫ h_L |u|^2 dnu.

The infinite form is

    v_inf[u] = -2 Re ∫ C(t) conj(u) u' dt.

Define

    a_L = sup_t |C(t)(h_L(t)-1)|,
    b_L = ∫ |C(t) h_L'(t)| dt.

Then formally

    |v_L[u]-v_inf[u]|
      <= (a_L+b_L) (||u'||_2^2 + ||u||_2^2),

using the 1D H^1 sup bound.  Thus a_L,b_L -> 0 is the numerical signature of
norm-form cutoff removal.

Outputs
-------
<prefix>_C_PRIMITIVE.csv
<prefix>_SCALAR_CUTOFF.csv
<prefix>_FORM_CUTOFF.csv
<prefix>_FORM_BOUND_COEFFICIENTS.csv
<prefix>_SUMMARY.json
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
from tqdm import tqdm

try:
    import mpmath as mp
except Exception:
    mp = None


GAMMA_E = 0.577215664901532860606512090082402431


def parse_float_list(text):
    if text is None or str(text).strip() == "":
        return []
    return [float(x.strip()) for x in str(text).split(",") if x.strip()]


def build_prime_power_atoms(nmax):
    nmax = int(nmax)
    sieve = np.ones(nmax + 1, dtype=np.bool_)
    sieve[:2] = False

    for p in tqdm(
        range(2, int(math.isqrt(nmax)) + 1),
        desc="Sieve",
        unit="p",
    ):
        if sieve[p]:
            sieve[p * p : nmax + 1 : p] = False

    primes = np.flatnonzero(sieve)
    ns = []
    lams = []

    for p in tqdm(primes, desc="Prime powers", unit="prime"):
        p = int(p)
        lp = math.log(p)
        q = p
        while q <= nmax:
            ns.append(q)
            lams.append(lp)
            if q > nmax // p:
                break
            q *= p

    ns = np.asarray(ns, dtype=np.int64)
    lams = np.asarray(lams, dtype=np.float64)
    order = np.argsort(ns)
    ns = ns[order]
    lams = lams[order]
    weights = lams / ns.astype(np.float64)
    logn = np.log(ns.astype(np.float64))
    return ns, lams, weights, logn


def primitive_on_grid(t_grid, n_arr, weight_arr):
    cum = np.cumsum(weight_arr, dtype=np.float64)
    x_floor = np.floor(np.exp(t_grid)).astype(np.int64)
    idx = np.searchsorted(n_arr, x_floor, side="right")
    sums = np.zeros_like(t_grid)
    mask = idx > 0
    sums[mask] = cum[idx[mask] - 1]
    return GAMMA_E + sums - t_grid


def trapz(y, x):
    if hasattr(np, "trapezoid"):
        return np.trapezoid(y, x)
    return np.trapz(y, x)


def continuum_exp_cutoff(L, E, dps):
    if mp is None:
        raise RuntimeError("mpmath is required for the exponential continuum integral.")
    mp.mp.dps = int(dps)
    Lm = mp.mpf(L)
    Em = mp.mpf(E)
    if abs(E) < 1e-15:
        return float(mp.e1(1 / Lm))
    z = 1j * Em
    return float(mp.re((Lm ** z) * mp.gammainc(z, 1 / Lm, mp.inf)))


def scalar_exp_cutoff(L, E, n_arr, weight_arr, logn_arr, dps):
    h_atoms = np.exp(-n_arr.astype(np.float64) / float(L))
    atom = float(np.dot(weight_arr * h_atoms, np.cos(E * logn_arr)))
    continuum = continuum_exp_cutoff(L, E, dps)
    boundary = GAMMA_E * math.exp(-1.0 / float(L))
    return boundary + atom - continuum


def scalar_exact_truncated(E, Tmax, C_T, weight_arr, logn_arr):
    """
    Exact A_T(E) = E int_0^T C(t) sin(E t) dt, evaluated through events.
    """
    if abs(E) < 1e-15:
        return 0.0
    atom = float(np.dot(weight_arr, np.cos(E * logn_arr)))
    return (
        GAMMA_E
        + atom
        - math.sin(E * Tmax) / E
        - C_T * math.cos(E * Tmax)
    )


def zeta_boundary_A(E, dps):
    if mp is None:
        raise RuntimeError("mpmath is required for --zeta-audit.")
    mp.mp.dps = int(dps)
    if abs(E) < 1e-15:
        return 0.0
    s = 1 - 1j * mp.mpf(E)
    zp = mp.diff(mp.zeta, s)
    return float(GAMMA_E - mp.re(zp / mp.zeta(s)))


def profile_h(profile, r):
    if profile == "exp":
        return np.exp(-r)
    if profile == "gauss":
        return np.exp(-(r * r))
    if profile == "rational":
        return 1.0 / (1.0 + r) ** 2
    raise ValueError(profile)


def profile_hprime_t(profile, r):
    """dh/dt when r=e^t/L, so dr/dt=r."""
    if profile == "exp":
        return -r * np.exp(-r)
    if profile == "gauss":
        return -2.0 * r * r * np.exp(-(r * r))
    if profile == "rational":
        return -2.0 * r / (1.0 + r) ** 3
    raise ValueError(profile)


def profile_h_scalar(profile, r):
    if profile == "exp":
        return math.exp(-r)
    if profile == "gauss":
        return math.exp(-(r * r))
    if profile == "rational":
        return 1.0 / (1.0 + r) ** 2
    raise ValueError(profile)


def probe_g(t, decay, center):
    return np.exp(-decay * (t - center) ** 2)


def gaussian_integral_0_T(decay, center, T):
    a = float(decay)
    sa = math.sqrt(a)
    return (
        math.sqrt(math.pi)
        / (2.0 * sa)
        * (math.erf(sa * (T - center)) + math.erf(sa * center))
    )


def exact_unregulated_probe_form(
    decay, center, Tmax, C_T, weight_arr, logn_arr
):
    g0 = math.exp(-decay * center * center)
    gT = math.exp(-decay * (Tmax - center) ** 2)
    g_atoms = np.exp(-decay * (logn_arr - center) ** 2)

    atom = float(np.dot(weight_arr, g_atoms))
    continuum = gaussian_integral_0_T(decay, center, Tmax)

    return GAMMA_E * g0 + atom - continuum - C_T * gT


def regulated_probe_form(
    profile,
    L,
    decay,
    center,
    t_grid,
    n_arr,
    weight_arr,
    logn_arr,
):
    r_atoms = n_arr.astype(np.float64) / float(L)
    h_atoms = profile_h(profile, r_atoms)
    g_atoms = np.exp(-decay * (logn_arr - center) ** 2)
    atom = float(np.dot(weight_arr * h_atoms, g_atoms))

    r_grid = np.exp(t_grid) / float(L)
    h_grid = profile_h(profile, r_grid)
    g_grid = probe_g(t_grid, decay, center)
    continuum = float(trapz(h_grid * g_grid, t_grid))

    h0 = profile_h_scalar(profile, 1.0 / float(L))
    g0 = math.exp(-decay * center * center)

    return GAMMA_E * h0 * g0 + atom - continuum


def main():
    ap = argparse.ArgumentParser(
        description="ROT-RH PNT-centered infinite form cutoff audit v2."
    )
    ap.add_argument("--L-values", default="2000,4000,8000,16000,32000,64000,128000")
    ap.add_argument("--tail-factor", type=float, default=24.0)
    ap.add_argument("--N-max", type=int, default=0)
    ap.add_argument("--energies", default="5,10,20,30,50,80,120")
    ap.add_argument("--t-grid-points", type=int, default=30001)
    ap.add_argument("--probe-decays", default="0.15,0.35,0.75")
    ap.add_argument("--probe-centers", default="1.0,3.0,6.0")
    ap.add_argument("--profiles", default="exp,gauss,rational")
    ap.add_argument("--mp-dps", type=int, default=70)
    ap.add_argument("--zeta-audit", action="store_true")
    ap.add_argument("--prefix", default="rot_rh_pnt_centered_infinite_form_v2")
    args = ap.parse_args()

    L_values = parse_float_list(args.L_values)
    energies = parse_float_list(args.energies)
    probe_decays = parse_float_list(args.probe_decays)
    probe_centers = parse_float_list(args.probe_centers)
    profiles = [x.strip() for x in args.profiles.split(",") if x.strip()]

    if not L_values:
        raise SystemExit("No L values.")
    if not energies:
        raise SystemExit("No energies.")

    Lmax = max(L_values)
    nmax = int(args.N_max) if args.N_max > 0 else int(math.ceil(args.tail_factor * Lmax))
    nmax = max(nmax, 100)

    print("=" * 118)
    print("ROT-RH PNT-CENTERED INFINITE FORM / NORM-FORM CUTOFF AUDIT v2")
    print("=" * 118)
    print(f"L values                         : {L_values}")
    print(f"N max                            : {nmax:,}")
    print(f"tail factor vs max L             : {nmax / Lmax:.3f}")
    print(f"energies                          : {energies}")
    print(f"t-grid points                     : {args.t_grid_points}")
    print(f"profiles                          : {profiles}")
    print(f"zeta audit                        : {args.zeta_audit}")
    print("zero ordinates used               : NO")
    print()

    n_arr, lam_arr, weight_arr, logn_arr = build_prime_power_atoms(nmax)
    print(f"prime-power atoms                 : {len(n_arr):,}")

    Tmax = math.log(nmax)
    total_weight = float(np.sum(weight_arr))
    C_T = GAMMA_E + total_weight - Tmax

    t_grid = np.linspace(0.0, Tmax, int(args.t_grid_points), dtype=np.float64)
    C_grid = primitive_on_grid(t_grid, n_arr, weight_arr)

    primitive_csv = Path(f"{args.prefix}_C_PRIMITIVE.csv")
    np.savetxt(
        primitive_csv,
        np.column_stack([t_grid, np.exp(t_grid), C_grid]),
        delimiter=",",
        header="t,x,C_t",
        comments="",
    )

    # ------------------------------------------------------------------
    # Scalar audit: exact event reference, no staircase quadrature.
    # ------------------------------------------------------------------
    scalar_rows = []
    print("\nScalar centered-transform audit (exact event reference)")
    for E in tqdm(energies, desc="Energies", unit="E"):
        A_T = scalar_exact_truncated(E, Tmax, C_T, weight_arr, logn_arr)
        A_zeta = (
            zeta_boundary_A(E, args.mp_dps) if args.zeta_audit else float("nan")
        )

        for L in L_values:
            A_L = scalar_exp_cutoff(
                L, E, n_arr, weight_arr, logn_arr, args.mp_dps
            )
            scalar_rows.append(
                [
                    E,
                    L,
                    A_L,
                    A_T,
                    A_L - A_T,
                    abs(A_L - A_T),
                    A_zeta,
                    A_T - A_zeta if args.zeta_audit else float("nan"),
                    abs(A_T - A_zeta) if args.zeta_audit else float("nan"),
                    A_L - A_zeta if args.zeta_audit else float("nan"),
                    abs(A_L - A_zeta) if args.zeta_audit else float("nan"),
                ]
            )

    scalar_arr = np.asarray(scalar_rows, dtype=float)
    scalar_csv = Path(f"{args.prefix}_SCALAR_CUTOFF.csv")
    np.savetxt(
        scalar_csv,
        scalar_arr,
        delimiter=",",
        header=(
            "E,L,A_L,A_T_exact,signed_AL_minus_AT,abs_AL_minus_AT,"
            "A_zeta_optional,signed_AT_minus_Azeta,abs_AT_minus_Azeta,"
            "signed_AL_minus_Azeta,abs_AL_minus_Azeta"
        ),
        comments="",
    )

    # ------------------------------------------------------------------
    # Exact unregulated probe form + regulated probe forms.
    # ------------------------------------------------------------------
    form_rows = []
    print("\nQuadratic-form regulator audit (exact unregulated reference)")
    probes = [(a, c) for a in probe_decays for c in probe_centers]

    for decay, center in tqdm(probes, desc="Probes", unit="probe"):
        v_inf_T = exact_unregulated_probe_form(
            decay, center, Tmax, C_T, weight_arr, logn_arr
        )
        for profile in profiles:
            pcode = {"exp": 0.0, "gauss": 1.0, "rational": 2.0}[profile]
            for L in L_values:
                vL = regulated_probe_form(
                    profile,
                    L,
                    decay,
                    center,
                    t_grid,
                    n_arr,
                    weight_arr,
                    logn_arr,
                )
                form_rows.append(
                    [
                        decay,
                        center,
                        pcode,
                        L,
                        vL,
                        v_inf_T,
                        vL - v_inf_T,
                        abs(vL - v_inf_T),
                    ]
                )

    form_arr = np.asarray(form_rows, dtype=float)
    form_csv = Path(f"{args.prefix}_FORM_CUTOFF.csv")
    np.savetxt(
        form_csv,
        form_arr,
        delimiter=",",
        header=(
            "probe_decay,probe_center,profile_code,L,v_L,v_inf_exact_T,"
            "signed_error,abs_error"
        ),
        comments="",
    )

    # ------------------------------------------------------------------
    # Numerical norm-form coefficient diagnostics:
    #
    # a_L = sup |C(h_L-1)|
    # b_L = int |C h'_L|
    # delta_L = a_L+b_L
    #
    # These are diagnostics on [0,Tmax].  Increase tail-factor to test
    # stability, especially for the rational profile.
    # ------------------------------------------------------------------
    bound_rows = []
    print("\nNorm-form coefficient audit")
    exp_t = np.exp(t_grid)

    for profile in tqdm(profiles, desc="Profiles", unit="profile"):
        pcode = {"exp": 0.0, "gauss": 1.0, "rational": 2.0}[profile]
        for L in L_values:
            r = exp_t / float(L)
            h = profile_h(profile, r)
            hp = profile_hprime_t(profile, r)

            aL = float(np.max(np.abs(C_grid * (h - 1.0))))
            bL = float(trapz(np.abs(C_grid * hp), t_grid))
            delta = aL + bL

            bound_rows.append([pcode, L, aL, bL, delta])

    bound_arr = np.asarray(bound_rows, dtype=float)
    bound_csv = Path(f"{args.prefix}_FORM_BOUND_COEFFICIENTS.csv")
    np.savetxt(
        bound_csv,
        bound_arr,
        delimiter=",",
        header="profile_code,L,a_L,b_L,delta_L",
        comments="",
    )

    # ------------------------------------------------------------------
    # Summaries
    # ------------------------------------------------------------------
    largest_L = max(L_values)
    scalar_last = scalar_arr[np.isclose(scalar_arr[:, 1], largest_L)]
    form_last = form_arr[np.isclose(form_arr[:, 3], largest_L)]
    bound_last = bound_arr[np.isclose(bound_arr[:, 1], largest_L)]

    scalar_contraction = {}
    for E in energies:
        rows = scalar_arr[np.isclose(scalar_arr[:, 0], E)]
        rows = rows[np.argsort(rows[:, 1])]
        first = float(rows[0, 5])
        last = float(rows[-1, 5])
        scalar_contraction[str(E)] = {
            "first_abs_AL_minus_AT": first,
            "last_abs_AL_minus_AT": last,
            "ratio_last_over_first": last / first if first > 0 else None,
        }

    form_contraction = {}
    for profile in profiles:
        pcode = {"exp": 0.0, "gauss": 1.0, "rational": 2.0}[profile]
        rows = bound_arr[np.isclose(bound_arr[:, 0], pcode)]
        rows = rows[np.argsort(rows[:, 1])]
        form_contraction[profile] = {
            "first_delta_L": float(rows[0, 4]),
            "last_delta_L": float(rows[-1, 4]),
            "ratio_last_over_first": (
                float(rows[-1, 4] / rows[0, 4]) if rows[0, 4] > 0 else None
            ),
        }

    # Cross-profile spread at each L and each probe, then max at each L.
    profile_spread_by_L = {}
    for L in L_values:
        max_spread = 0.0
        for decay, center in probes:
            rows = form_arr[
                np.isclose(form_arr[:, 0], decay)
                & np.isclose(form_arr[:, 1], center)
                & np.isclose(form_arr[:, 3], L)
            ]
            if len(rows) > 1:
                spread = float(np.max(rows[:, 4]) - np.min(rows[:, 4]))
                max_spread = max(max_spread, abs(spread))
        profile_spread_by_L[str(L)] = max_spread

    zeta_max_AT = None
    zeta_max_AL_last = None
    if args.zeta_audit:
        zeta_max_AT = float(np.max(scalar_last[:, 8]))
        zeta_max_AL_last = float(np.max(scalar_last[:, 10]))

    summary = {
        "construction": "PNT-centered log-prime measure",
        "version": 2,
        "zero_ordinates_used": False,
        "nmax": int(nmax),
        "prime_power_atoms": int(len(n_arr)),
        "Tmax": float(Tmax),
        "C_T_exact": float(C_T),
        "L_values": L_values,
        "energies": energies,
        "scalar_reference": "exact event-by-event truncated Stieltjes identity",
        "scalar_largest_L_max_abs_AL_minus_AT": float(np.max(scalar_last[:, 5])),
        "scalar_largest_L_rms_abs_AL_minus_AT": float(
            np.sqrt(np.mean(scalar_last[:, 5] ** 2))
        ),
        "scalar_contraction": scalar_contraction,
        "form_reference": "exact event-by-event unregulated Gaussian probe form",
        "form_largest_L_max_abs_error": float(np.max(form_last[:, 7])),
        "form_largest_L_rms_abs_error": float(
            np.sqrt(np.mean(form_last[:, 7] ** 2))
        ),
        "max_cross_profile_spread_by_L": profile_spread_by_L,
        "norm_form_bound_coefficients_at_largest_L": [
            {
                "profile_code": int(row[0]),
                "a_L": float(row[2]),
                "b_L": float(row[3]),
                "delta_L": float(row[4]),
            }
            for row in bound_last
        ],
        "norm_form_delta_contraction": form_contraction,
        "zeta_audit_enabled": bool(args.zeta_audit),
        "max_abs_AT_minus_Azeta": zeta_max_AT,
        "largest_L_max_abs_AL_minus_Azeta": zeta_max_AL_last,
        "profile_codes": {"exp": 0, "gauss": 1, "rational": 2},
        "files": {
            "primitive": str(primitive_csv),
            "scalar": str(scalar_csv),
            "form": str(form_csv),
            "bounds": str(bound_csv),
        },
        "interpretation": {
            "primary_operator_test": (
                "delta_L=a_L+b_L should decrease toward zero for every regulator profile. "
                "This directly audits the coefficient entering the common-domain norm-form estimate."
            ),
            "scalar_test": (
                "A_L should converge toward the exact event reference A_T.  A_T itself is truncated at Tmax; "
                "with --zeta-audit, A_T can be independently checked against the zero-free boundary identity."
            ),
            "warning": (
                "A passing arithmetic-sector cutoff audit does not yet give a Hilbert-Polya operator. "
                "A separate archimedean/confining operator H_Gamma with the required theta phase and compact "
                "resolvent (or another mechanism producing the correct discrete spectrum) remains to be constructed."
            ),
        },
    }

    summary_json = Path(f"{args.prefix}_SUMMARY.json")
    summary_json.write_text(json.dumps(summary, indent=2))

    print("\n" + "-" * 118)
    print("SUMMARY")
    print("-" * 118)
    print(f"C(Tmax) exact                              : {C_T: .6e}")
    print(
        "scalar max |A_L-A_T| at largest L          : "
        f"{summary['scalar_largest_L_max_abs_AL_minus_AT']:.6e}"
    )
    print(
        "form max |v_L-v_inf,T| at largest L        : "
        f"{summary['form_largest_L_max_abs_error']:.6e}"
    )
    print(
        "max cross-profile spread at largest L      : "
        f"{profile_spread_by_L[str(largest_L)]:.6e}"
    )
    for row in bound_last:
        pname = {0: "exp", 1: "gauss", 2: "rational"}[int(row[0])]
        print(
            f"delta_L={pname:<8s} at largest L              : "
            f"{row[4]:.6e}  (a={row[2]:.3e}, b={row[3]:.3e})"
        )

    if args.zeta_audit:
        print(f"max |A_T-A_zeta|                         : {zeta_max_AT:.6e}")
        print(f"max |A_Lmax-A_zeta|                      : {zeta_max_AL_last:.6e}")

    print(f"primitive CSV                             : {primitive_csv}")
    print(f"scalar CSV                                : {scalar_csv}")
    print(f"form CSV                                  : {form_csv}")
    print(f"bound coefficients CSV                    : {bound_csv}")
    print(f"summary JSON                              : {summary_json}")
    print()
    print("Primary pass signature:")
    print("  1. delta_L decreases with L for exp, gauss, and rational regulators.")
    print("  2. cross-profile form spread decreases with L.")
    print("  3. A_L approaches exact event reference A_T.")
    print("  4. Optional --zeta-audit validates A_T without using zero ordinates.")
    print("=" * 118)


if __name__ == "__main__":
    main()
